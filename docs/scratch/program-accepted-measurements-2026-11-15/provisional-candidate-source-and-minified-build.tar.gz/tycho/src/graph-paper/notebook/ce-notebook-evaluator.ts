/**
 * The real Compute-Engine-backed {@link NotebookEvaluator} (Notebook §5.8) — N-3.
 *
 * Wraps the CE so the compute graph (`notebook-compute-graph.ts`) stays blind to
 * it (§13). Built on the de-risk findings
 * (the canonical implementation notes) plus the CE team's guidance;
 * the non-obvious parts:
 *
 * - **Side-effect-free discovery via `form: "raw"`.** A canonical
 *   `ce.parse()` auto-declares symbols, which collides with the §5.4
 *   declare-first pass. `ce.parse(input, { form: "raw" })` does **not**
 *   declare anything and is fully walkable, so `analyze` runs on the **same**
 *   engine as evaluation — no second instance.
 * - **Function-call edges (§1.1).** `referenceCandidates` = `freeVariables` ∪ MathJSON
 *   operator heads, minus `defines`. (With `form: "raw"` a call leaves its
 *   name in `freeVariables`; but `f'(x)` keeps `f` only as a head, so the
 *   head-walk is
 *   still needed.) This is a deliberate **over-approximation**: the graph keeps
 *   only candidates that match a name some cell defines (the CE team's
 *   intersect-with-`definedNames` recipe), so built-in heads are harmless and no
 *   built-in/user classification is needed.
 * - **Status (§5.6).** evaluate is wrapped in try/catch mapping
 *   `cause:'recursion-depth-exceeded'` (+ a native `RangeError` backstop) →
 *   `diverged`, `cause:'timeout'|'iteration-limit-exceeded'` → `timeout`. An
 *   undefined reference is **not** an error — the result stays free and the cell
 *   is `unresolved` (upgraded to a "define `f(…)`?" prompt via
 *   `appliedNonFunctions`).
 *
 * Runs in node, so this whole module is node-tested with a real CE — the primary
 * N-3 signal alongside the stub-driven graph tests.
 */

import type {
  ComputeEngine,
  Expression,
  MathJsonExpression,
} from "@cortex-js/compute-engine";
import { executeEpsil as executeCortex } from "@cortex-js/compute-engine/epsil";
import type { ExecuteEpsilResult as ExecuteCortexResult } from "@cortex-js/compute-engine/epsil";
import {
  isFunction,
  isString,
  isSymbol,
  sym,
} from "../../plot-core/ce-type-guards.js";
import { isReservedVariableName } from "../../plot-core/classification-names.js";
import { runEvalSpan } from "../../plot-core/ce-deadline.js";
import type { NotebookTable } from "./types.js";
import type {
  BindingAnalysis,
  CellAnalysis,
  CortexAnalysis,
  CortexLimits,
  CortexRunOutcome,
  CortexSnapshot,
  EvalOptions,
  EvalOutcome,
  EvalResult,
  EvalStatus,
  ExplainOperation,
  ExplainOutcome,
  NotebookEvaluator,
  PlotEvalSeries,
  ScopeHandle,
} from "./notebook-evaluator.js";
import {
  scanBindings,
  substituteBindings,
} from "./cell-plugins/binding-scan.js";
import { formatNumberForDisplay } from "../editors/settings/format-number.js";
import {
  DEFAULT_NOTEBOOK_CALCULATION,
  effectiveFormulaTimeLimitMs,
  settingsKeyOf,
  type NotebookCalculationSettings,
} from "./notebook-calculation.js";
import { analyzeCortex, lastStatementIsDefinition } from "./cortex-analysis.js";
import {
  checkCandidates,
  type CheckBaseline,
  type SuggestionCandidate,
} from "./suggestion-checks.js";
import {
  extractNumberRows,
  isMatrixElems,
  pushPointsSeries,
} from "./ce-collection-data.js";
import {
  ANS_SYMBOL,
  isPrefixPipelineInput,
  substituteAnswers,
  type AnswerLookup,
} from "./ce-ans-references.js";

let evaluatorSeq = 0;

/**
 * The plot-builder heads (§6.2). Declared as functions in every section scope so
 * `\mathrm{Plot}(…)` parses as an application head, not the §5.7 multi-letter
 * product (`P·l·o·t·…`), AND `appliedNonFunctions` stops flagging them for the
 * define-`f` prompt (de-risk §1.1). Scope-local — gone on `popScope`.
 */
const PLOT_HEADS = ["Plot", "Plot3D"] as const;

/** Default per-run caps (R2a-7); also the clamp fallback for absent/invalid settings. */
const DEFAULT_CORTEX_LIMITS = {
  timeLimitMs: 2000,
  iterationLimit: 1_000_000,
  recursionLimit: 256,
} as const;

/** Clamp a settings limit to a finite integer in `[min, max]`; non-positive/NaN/absent → `def` (CE reads non-positive as ∞ — never passed through). */
function clampLimit(v: number, min: number, max: number, def: number): number {
  if (typeof v !== "number" || !Number.isFinite(v) || v <= 0) return def;
  return Math.min(Math.max(Math.round(v), min), max);
}

/**
 * XML-escape a substituted binding value (Phase 2b §4.3, finding [K5]) before it
 * lands in svg markup: `& < > " '` → entities. Without this, a string like
 * `"A & B"` makes the svg unparseable and `parseSvgMarkup` returns an empty node
 * (a silent blank). Numbers/booleans are format-safe but escaped uniformly for
 * safety, and escaping neutralizes the correctness case of a `${expr}`→`"<script>"`
 * (the renderer's untrusted-bar re-sanitize is the security backstop).
 */
function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** The literal text of a diagnostic's message (`["code", …parts]` joined, or a plain string). */
function diagText(message: unknown): string {
  if (Array.isArray(message)) return message.map((p) => String(p)).join(" ");
  return typeof message === "string" ? message : "";
}

/** The diagnostic's code = the first element of its `message` tuple (`runtime-error`, `symbol-expected`, …). */
function diagCode(message: unknown): string {
  if (Array.isArray(message) && typeof message[0] === "string")
    return message[0];
  return "";
}

// Structured cancellation causes (CE 0.76.0, probe-pinned — replaces the
// 0.75 message match, which 0.76 broke for the NON-final path by moving it
// off the generic `runtime-error` code). Two shapes:
//  - FINAL-statement breach (errors-are-values): the Error VALUE carries the
//    cause as operand[2] — `["Error","'Operation canceled'",
//    "'iteration-limit-exceeded'"]` (cause single-quoted).
//  - NON-final breach: a dedicated `evaluation-canceled` diagnostic with the
//    cause as its second message part (unquoted).
// Unrecognized causes stay opaque (an arbitrary AbortSignal.reason must not
// classify as a cap breach) — the CE-documented union is the gate.
type CancellationCause =
  "timeout" | "iteration-limit-exceeded" | "recursion-depth-exceeded";
const CANCELLATION_CAUSES: ReadonlySet<string> = new Set([
  "timeout",
  "iteration-limit-exceeded",
  "recursion-depth-exceeded",
]);

/** Strip the MathJSON string-literal quotes (`'timeout'` → `timeout`). */
function unquoteCause(s: unknown): string {
  return typeof s === "string" ? s.replace(/^'|'$/g, "") : "";
}

// ── Invalid-expression detail (`expr.isValid === false`) ─────────────────────
//
// CE reports parse/box problems as `["Error"]` VALUES inside the expression,
// not throws. Shapes seen in the wild (probe 2026-07-14):
//   ["Error", "'expected-closing-delimiter'", ["LatexString", "'{x+}'"]]
//   ["Error", ["ErrorCode", "'incompatible-type'", "''symbol''", "'unknown'"],
//    "'Set(a, b, c)'"]
// The flattened text is the `detail` contract (notebook-evaluator.ts: "raw CE
// text") — it feeds the cell's cached error message and, critically, the AI
// `evaluate_math` tool result, where an empty detail once burned a whole
// 8-round Margin turn on blind capability spelunking (2026-07-14 diagnostic).

/** Strip EVERY layer of MathJSON string-literal quoting (`''symbol''` → `symbol`). */
function unquoteAll(v: unknown): string {
  if (typeof v !== "string") return "";
  let s = v;
  while (s.length >= 2 && s.startsWith("'") && s.endsWith("'"))
    s = s.slice(1, -1);
  return s;
}

/** One term of a BOXED Error node: a string or symbol code/cause, an
 *  `ErrorCode(code, …params)` node, or a `LatexString('…')` wrapper. Reads
 *  the boxed operands — an error's culprit can be a large expression, and
 *  `.json` on it would serialize the whole tree. */
function errorTermOf(node: Expression): string {
  if (isString(node)) return unquoteAll(node.string);
  if (isSymbol(node)) return node.symbol;
  if (isFunction(node, "ErrorCode") && node.nops >= 1) {
    const code = errorTermOf(node.op1);
    const params = node.ops
      .slice(1)
      .map(errorTermOf)
      .filter((s) => s.length > 0);
    return params.length > 0 ? `${code} (${params.join(", ")})` : code;
  }
  if (isFunction(node, "LatexString") && node.nops >= 1)
    return errorTermOf(node.op1);
  return "";
}

/** Flatten an invalid expression's `["Error"]` subexpressions into one detail
 *  line, deduplicated (`code: cause; code2`). Never empty: an invalid
 *  expression with no legible Error nodes still names itself. */
function invalidDetail(errors: readonly Expression[]): string {
  const lines: string[] = [];
  for (const err of errors) {
    if (!isFunction(err, "Error") || err.nops < 1) continue;
    const code = errorTermOf(err.op1);
    if (code.length === 0) continue;
    const cause = err.nops >= 2 ? errorTermOf(err.op2) : "";
    const line = cause.length > 0 ? `${code}: ${cause}` : code;
    if (!lines.includes(line)) lines.push(line);
  }
  return lines.length > 0 ? lines.join("; ") : "invalid expression";
}

/**
 * Assignment (`=`) targets inside a function body that escape containment — a name
 * that is neither one of the function's params nor a body-local `let`/Declare target
 * (finding 5). Walks the parse-derived, metadata-stripped `["Function", body,
 * …params]` MathJSON; nested functions scope their own params. A non-empty result
 * means calling this function would mutate the section scope, so it is not published.
 */
function functionAssignsOuterNames(fnExpr: MathJsonExpression): string[] {
  const arr = fnExpr as unknown;
  if (!Array.isArray(arr) || arr[0] !== "Function") return [];
  const locals = new Set<string>();
  for (let i = 2; i < arr.length; i++) {
    const p = plainParamName(arr[i]);
    if (p !== null) locals.add(p);
  }
  collectPlainDeclareTargets(arr[1], locals); // all `let` targets at any body depth
  const escaping = new Set<string>();
  collectPlainAssignTargets(arr[1], locals, escaping);
  return [...escaping];
}

/**
 * A clause parameter's NAME in plain-array MathJSON: a bare string, or the
 * typed/literal clause-parameter shape `["Typed", name, {str: type}]`
 * (clause dispatch, CE 0.100+) — mirrors the object-format handling in
 * `cortex-analysis.ts`'s walkRefs, so a typed parameter reassigned in its own
 * body is a LOCAL write, not a spurious escape.
 */
function plainParamName(node: unknown): string | null {
  if (typeof node === "string") return node;
  if (Array.isArray(node) && node[0] === "Typed" && typeof node[1] === "string")
    return node[1];
  return null;
}

/** Collect every `Declare` (`let`) target name at any depth in plain-array MathJSON. */
function collectPlainDeclareTargets(node: unknown, acc: Set<string>): void {
  if (!Array.isArray(node) || typeof node[0] !== "string") return;
  if (node[0] === "Declare" && typeof node[1] === "string") acc.add(node[1]);
  for (let i = 1; i < node.length; i++)
    collectPlainDeclareTargets(node[i], acc);
}

/** Collect `Assign` targets not in `locals`; a nested `Function` extends `locals` with its params. */
function collectPlainAssignTargets(
  node: unknown,
  locals: ReadonlySet<string>,
  acc: Set<string>,
): void {
  if (!Array.isArray(node) || typeof node[0] !== "string") return;
  if (node[0] === "Function") {
    const inner = new Set(locals);
    for (let i = 2; i < node.length; i++) {
      const p = plainParamName(node[i]);
      if (p !== null) inner.add(p);
    }
    collectPlainAssignTargets(node[1], inner, acc);
    return;
  }
  if (
    node[0] === "Assign" &&
    typeof node[1] === "string" &&
    !locals.has(node[1])
  )
    acc.add(node[1]);
  for (let i = 1; i < node.length; i++)
    collectPlainAssignTargets(node[i], locals, acc);
}

/**
 * Cancellation cause + text if a cap breached, else `null` (§5). Detected
 * from an `evaluation-canceled` diagnostic (non-final breach, F7) OR a final
 * `["Error", msg, cause]` cancellation value (F13 — final breaches carry
 * EMPTY diagnostics). Reads the STRUCTURED cause CE 0.76.0 added (Low #0
 * response — retires the 0.75 message match).
 */
function cortexCancellation(
  diagnostics: readonly { severity?: string; message?: unknown }[],
  value: Expression,
): { cause: CancellationCause; text: string } | null {
  for (const d of diagnostics) {
    if (diagCode(d.message) !== "evaluation-canceled") continue;
    const parts = d.message as unknown[];
    const cause = unquoteCause(parts[1]);
    if (CANCELLATION_CAUSES.has(cause))
      return { cause: cause as CancellationCause, text: diagText(d.message) };
  }
  // Probe the VALUE's head boxed: it may be a large evaluated result, and
  // `.json` would serialize all of it to answer a two-operand question.
  if (isFunction(value, "Error") && value.nops >= 2) {
    const cause = unquoteCause(value.op2.json);
    if (CANCELLATION_CAUSES.has(cause)) {
      return {
        cause: cause as CancellationCause,
        text: ["Error", ...value.ops.map((op) => op.json)]
          .map((p) => String(p))
          .join(" "),
      };
    }
  }
  return null;
}

/**
 * Walk a MathJSON tree collecting string operator heads into `acc` as reference
 * CANDIDATES (function-call refs, §1.1 — `freeVariables` misses call heads).
 * Deliberately dirty: builtin heads (`Add`, `Sqrt`, `Assign`, `Delimiter`, …)
 * flow through, because a candidate only becomes a dependency edge when a cell
 * actually defines that name (notebook-compute-graph.ts) — which is also what
 * makes user shadowing of CE builtin names work. Filtering by CE's dictionary
 * here would sever the edge to a user-defined `T := 3` because CE also
 * defines `T`.
 *
 * `N` is the single semantic exception: users define a symbol named `N` often
 * enough that letting the head of the numeric-approximation builtin `N(…)`
 * into the candidates would wire a spurious edge to that cell.
 */
function collectAppliedHeads(json: unknown, acc: Set<string>): void {
  if (!Array.isArray(json)) return;
  const head = json[0];
  if (typeof head === "string" && head !== "N") acc.add(head);
  for (let i = 1; i < json.length; i++) collectAppliedHeads(json[i], acc);
}

/** Collect the previous-answer markers of a raw tree: `Ans` → `null`, `["Ans", n]` → `n`. */
function collectAnsRefs(json: unknown, acc: (number | null)[]): void {
  if (json === ANS_SYMBOL) {
    acc.push(null);
    return;
  }
  if (!Array.isArray(json)) return;
  if (json[0] === ANS_SYMBOL) {
    const n = json[1];
    acc.push(typeof n === "number" && Number.isInteger(n) ? n : null);
    return;
  }
  for (let i = 1; i < json.length; i++) collectAnsRefs(json[i], acc);
}

/** Collect names that are **function-shaped** definitions — `["Assign", n, ["Function", …]]`, through Program and Block containers. */
function collectFunctionDefines(json: unknown, acc: Set<string>): void {
  if (!Array.isArray(json)) return;
  const head = json[0];
  if (head === "Assign" && typeof json[1] === "string") {
    const value = json[2];
    if (Array.isArray(value) && value[0] === "Function") acc.add(json[1]);
  }
  if (head === "Program" || head === "Block")
    for (let i = 1; i < json.length; i++) collectFunctionDefines(json[i], acc);
}

/** Rewrite every occurrence of `oldName` (head or leaf symbol) to `newName` in a MathJSON tree. */
function renameInJson(
  json: unknown,
  oldName: string,
  newName: string,
): unknown {
  if (typeof json === "string") return json === oldName ? newName : json;
  if (Array.isArray(json))
    return json.map((x) => renameInJson(x, oldName, newName));
  return json;
}

// Numeric / plot-point extraction helpers (`toNumber`, `isMatrixElems`,
// `extractNumberRows`, `pushPointsSeries`) live in `ce-collection-data.ts` now —
// shared with the equation value layer so a render-time plot view derives points
// without re-evaluating (plan 3.3, the `output.as` inversion).

/** An authored table cell → MathJSON: a number column to a number (empty → 0, non-numeric → string), a string column to a CE string literal. */
function tableCellToJson(
  cell: string,
  type: "string" | "number",
): MathJsonExpression {
  if (type === "number") {
    if (cell.trim() === "") return 0;
    const n = Number(cell);
    return Number.isNaN(n) ? { str: cell } : n;
  }
  return { str: cell };
}

/** The CE scope handle: carries the captured lexical scope for optional §5.3
 *  re-entry. Typed off `pushScope`'s own parameter so it stays in lockstep with
 *  the engine's `Scope` type without naming CE's internal `Scope` alias. */
interface CeScopeHandle extends ScopeHandle {
  readonly captured: Parameters<ComputeEngine["pushScope"]>[0];
}

/** What `ce.precision` reads back after `ce.precision = "machine"`. */
const MACHINE_PRECISION_DIGITS = 15;

export interface CeNotebookEvaluatorOptions {
  /** The engine's version (`"0.167.0"`), for the currency keys. */
  engineVersion?: string;
  /**
   * The calculation settings. Absent: {@link DEFAULT_NOTEBOOK_CALCULATION}.
   * The page gives the user's settings, and replaces them with
   * `setCalculation` when they change; the evaluator never reads a
   * module-level settings store, so it runs in the notebook worker, and in
   * the headless agent host of the API Worker, where one isolate serves
   * many users at the same time (roadmap/EXTERNAL_AGENT_ACCESS.md § 11.5,
   * "Isolation between requests").
   */
  calculation?: NotebookCalculationSettings;
}

/**
 * Build a CE-backed evaluator over a **single** engine (§2.1, revised). `makeEngine`
 * mints a **bare** engine (no `f/g/h` predeclaration — §2.5). Node tests pass
 * `() => new ComputeEngine()`.
 */
export function createCeNotebookEvaluator(
  makeEngine: () => ComputeEngine,
  options: CeNotebookEvaluatorOptions = {},
): NotebookEvaluator {
  let calculation = options.calculation ?? DEFAULT_NOTEBOOK_CALCULATION;
  const numericPrecision = (): "machine" | number =>
    calculation.numericPrecision;
  const ceConfig = () => calculation.ceConfig;
  /**
   * The time limit of one formula cell, the same setting that bounds a run
   * of a script cell (Settings → Calculation; owner decision 2026-10-24).
   * Without a limit, a costly formula cell would run until it ends:
   * `\sum_{k=1}^{10000}\frac{1}{k^2}`, computed exactly, did not finish in
   * 60 s (ROADMAP row HV). Absent in the settings of the agent host: no limit.
   */
  const formulaTimeLimitMs = (): number | undefined =>
    effectiveFormulaTimeLimitMs(calculation);
  const evaluatorId = `ce-nb-eval-${++evaluatorSeq}`;
  // One engine for the evaluator's whole life: the computing model keeps a
  // persistent scope per scope group on it and never replaces it.
  const ce = makeEngine();
  /** The engine's root lexical scope, for {@link atRoot}, captured on the
   *  fresh engine (nothing is pushed yet). */
  const rootScope = ce.context?.lexicalScope;
  /**
   * Run `fn` with the engine's lookups resolving from the ROOT scope, whatever
   * is pushed at the time. CE's `freeVariables` omits a symbol that is bound in
   * the current scope, so a parse-only analysis made while a group scope is
   * pushed (the graph pushes a group's scope around the cells it evaluates,
   * and a chat tool may analyse inside its own scope) would miss every
   * reference to a name that scope binds; through a frame that re-enters the
   * root scope, the analysis reads as it did on a bare engine. The frame is
   * pushed and popped around `fn`.
   */
  function atRoot<T>(fn: () => T): T {
    if (ce.context?.lexicalScope === rootScope || rootScope === undefined)
      return fn();
    ce.pushScope(rootScope);
    try {
      return fn();
    } finally {
      ce.popScope();
    }
  }
  /**
   * Settings → Calculation → Precision governs THIS engine (user ruling
   * 2026-09-07; before it the setting reached no engine but the plot
   * document's, which was a bug — plot documents now compute at machine
   * precision by engine profile). Applied at every evaluation, so a
   * `setCalculation` reaches the engine at the next one. The compare
   * makes the steady state free — `ce.precision` reads back a NUMBER, and
   * `"machine"` reads back as `MACHINE_PRECISION_DIGITS`.
   */
  function syncPrecision(): void {
    const wanted = numericPrecision();
    const current = ce.precision;
    if (current !== (wanted === "machine" ? MACHINE_PRECISION_DIGITS : wanted))
      ce.precision = wanted;
  }
  /**
   * Authored tables bound this evaluator's lifetime, by symbol name — retained so
   * a `Plot(name)` data series can label its columns by header (the CE binding
   * keeps only the values). Overwritten on re-bind; a stale entry is never
   * consulted (an unbound name never resolves to a collection), so no clearing.
   */
  const tableData = new Map<ScopeHandle, Map<string, NotebookTable>>();
  /** The authored tables bound in one group's scope, by symbol name: the
   *  scopes of two groups may bind the same name to different tables. */
  function tablesOf(scope: ScopeHandle): Map<string, NotebookTable> {
    let m = tableData.get(scope);
    if (!m) {
      m = new Map();
      tableData.set(scope, m);
    }
    return m;
  }

  /**
   * Parse-only analysis via `form: "raw"` — side-effect-free, scope-independent
   * (§2.1). The reads are the names that OCCUR on the right-hand side of a
   * definition (`roadmap/NOTEBOOK_COMPUTE_MODEL.md` § 3.2): the raw parse of
   * `a := …` is `["Assign", "a", rhs]`, and the root's `freeVariables` lists
   * the TARGET `a` too, so the reads are taken from the right-hand side
   * operand, whose own `freeVariables` excludes the target and the parameters
   * of a function (`f(x) := x + k` reads `k`). A cell that reads the name it
   * defines (`a := a + 1`) therefore reads `a`, which the graph reports as a
   * cycle. The previous-answer references (`\%`, `\%n`, the implicit read of
   * a prefix pipeline) come back as `ansRefs`, never as a symbol read.
   */
  function analyze(input: string): CellAnalysis {
    if (!input.trim())
      return { defines: [], functionDefines: [], referenceCandidates: [] };
    // At the root, and READ there too: `freeVariables` is computed when it is
    // read, against the scope current at that moment, so the reads below must
    // happen inside the root frame and not after it is popped.
    const read = atRoot(() => {
      let expr: Expression;
      try {
        expr = ce.parse(input, { form: "raw" });
      } catch {
        return undefined;
      }
      const defines = [...(expr.defines ?? [])];
      const json = expr.json;
      // The reads of a definition are its right-hand side's free variables; an
      // evaluation cell's are the whole expression's.
      const isAssign =
        Array.isArray(json) && json[0] === "Assign" && defines.length > 0;
      const rhs = isAssign && isFunction(expr) ? expr.ops[1] : undefined;
      const freeVariables = [...((rhs ?? expr).freeVariables ?? [])];
      const functionBodies = new Map<string, MathJsonExpression>();
      if (isAssign && Array.isArray(json)) {
        const value = json[2];
        if (Array.isArray(value) && value[0] === "Function")
          functionBodies.set(
            json[1] as string,
            value as unknown as MathJsonExpression,
          );
      }
      return { defines, freeVariables, json, functionBodies };
    });
    if (read === undefined)
      return { defines: [], functionDefines: [], referenceCandidates: [] };
    const defines = read.defines;
    const exprJson = read.json;
    const fnSet = new Set<string>();
    collectFunctionDefines(exprJson, fnSet);
    const refs = new Set<string>(read.freeVariables);
    collectAppliedHeads(exprJson, refs);
    // The target of the definition is never a read of itself through the head
    // walk (`["Assign", "a", …]` has `Assign` as its head, not `a`); a function
    // name applied inside its own body (`f(n) := n f(n-1)`) stays, which is
    // the allowed self-edge of a recursive function.
    for (const d of defines) if (!fnSet.has(d)) refs.delete(d);
    if (read.freeVariables.includes(defines[0] ?? "")) {
      // A value cell whose right-hand side reads its own name: keep the read.
      for (const d of defines) if (read.freeVariables.includes(d)) refs.add(d);
    }
    // `Ans` (the `\%` / `\%n` marker) is an answer reference, listed on its
    // own below, never a symbol read.
    refs.delete(ANS_SYMBOL);
    const ansRefs: (number | null)[] = [];
    if (isPrefixPipelineInput(input)) ansRefs.push(null);
    collectAnsRefs(exprJson, ansRefs);
    return {
      defines,
      functionDefines: [...fnSet],
      referenceCandidates: [...refs],
      ansRefs,
      functionBodies: read.functionBodies,
    };
  }

  function enterScope(existing?: ScopeHandle): ScopeHandle {
    const captured = (existing as CeScopeHandle | undefined)?.captured;
    return pushFrame(captured);
  }

  /** Push one scope frame (a fresh one, or a re-entry of `captured`) and set it up. */
  function pushFrame(
    captured?: Parameters<ComputeEngine["pushScope"]>[0],
  ): CeScopeHandle {
    ce.pushScope(captured);
    // Declare the plot heads (§6.2) so `\mathrm{Plot}(…)` parses as an application
    // and isn't flagged by the define-`f` prompt (de-risk §1.1). A re-entered scope
    // already has them — the throw is caught.
    for (const name of PLOT_HEADS) {
      try {
        ce.declare(name, "function");
      } catch {
        // Already declared (re-entered scope) — no-op.
      }
    }
    const handle: CeScopeHandle = {
      evaluatorId,
      captured: ce.context?.lexicalScope,
    };
    return handle;
  }

  function exitScope(_h: ScopeHandle): void {
    ce.popScope();
  }

  /**
   * The settings that change a cell's result outside the cells: the precision
   * (`syncPrecision()` applies it to the engine), the display config a binding
   * cell formats its numbers with (`gateBindingValue`), and the formula time
   * limit (after a change, a cell that timed out may now finish, or the
   * reverse). Part of every currency key (§ 3.6 of the model).
   */
  function settingsKey(): string {
    return settingsKeyOf(calculation);
  }

  /** Whether `name` is bound in the scope on top of the engine's stack. */
  function boundHere(name: string): boolean {
    return ce.context?.lexicalScope?.bindings?.has(name) === true;
  }

  /** `ce.undeclare(name)` when the name is bound in the top scope (it throws otherwise). */
  function undeclareHere(name: string): void {
    if (!boundHere(name)) return;
    try {
      ce.undeclare(name);
    } catch {
      // The engine refused (the variable of an operator under evaluation);
      // the following assign then overwrites the binding in place.
    }
  }

  function beginDefine(
    names: readonly string[],
    functionNames: readonly string[],
    _scope: ScopeHandle,
  ): void {
    for (const name of names) undeclareHere(name);
    for (const name of functionNames) {
      undeclareHere(name);
      try {
        ce.declare(name, "function");
      } catch {
        // Declared in a parent scope by the library; the assign shadows it.
      }
    }
  }

  function unbind(
    names: readonly string[],
    functionNames: readonly string[],
    keepDeclared: ReadonlySet<string>,
    _scope: ScopeHandle,
  ): void {
    for (const name of names) {
      undeclareHere(name);
      tablesOf(_scope).delete(name);
    }
    for (const name of functionNames) {
      undeclareHere(name);
      if (keepDeclared.has(name)) {
        try {
          ce.declare(name, "function");
        } catch {
          // Declared in a parent scope; nothing to do.
        }
      }
    }
  }

  function restore(
    name: string,
    value: MathJsonExpression,
    isFunctionValue: boolean,
    _scope: ScopeHandle,
  ): boolean {
    try {
      undeclareHere(name);
      if (isFunctionValue) ce.declare(name, "function");
      ce.assign(name, ce.expr(value));
      return true;
    } catch {
      return false;
    }
  }

  function declareFunctions(names: string[], _scope: ScopeHandle): void {
    for (const name of names) {
      if (boundHere(name)) continue; // already declared in this scope
      try {
        ce.declare(name, "function");
      } catch {
        // A predeclared library name — no-op (§1.2).
      }
    }
  }

  function bindTable(
    name: string,
    table: NotebookTable,
    _scope: ScopeHandle,
  ): void {
    // Bind the table's data as a List-of-rows under the canonical symbol `name`
    // (the `\mathrm{name}` reference site resolves to it, de-risk §1.3). Coerce
    // each cell by its column type — number columns to numbers, string columns to
    // CE string literals — so a numeric column plots and a label column reads back.
    tablesOf(_scope).set(name, table);
    try {
      const rows: MathJsonExpression[] = table.cells.map((row) => [
        "List",
        ...row.map((cell, ci) =>
          tableCellToJson(cell, table.columns[ci]?.type ?? "string"),
        ),
      ]);
      ce.assign(name, ce.expr(["List", ...rows]));
    } catch {
      // Leave the name unbound on any failure — a reference then resolves to
      // `unresolved`, never a corrupt binding.
    }
  }

  function bindScalar(name: string, value: number, _scope: ScopeHandle): void {
    // Bind the slider's scalar under the canonical symbol `name` (the reference
    // site resolves to it, like a value definition at this model position, §3.3).
    try {
      ce.assign(name, ce.expr(value));
    } catch {
      // Leave the name unbound on any failure — a reference then resolves to
      // `unresolved`, never a corrupt binding (mirrors bindTable).
    }
  }

  /**
   * Parse-only binding analysis (Phase 2b §4.2). The reference set is each
   * `${var}` name plus each `${expr}` body's free LaTeX variables — obtained by
   * routing the body through {@link analyze} (the same `freeVariables` ∪ applied-
   * heads contract as an equation cell, so a `${\sqrt{t}}` yields `t`). Runs on
   * the declare pass before values bind, where free variables resolve correctly.
   */
  function analyzeBindings(source: string): BindingAnalysis {
    const scan = scanBindings(source);
    if (scan.error) return { references: [], spans: [], error: scan.error };
    const refs = new Set<string>();
    for (const span of scan.bindings) {
      if (span.kind === "var" && span.name) refs.add(span.name);
      else for (const r of exprReferences(span.body)) refs.add(r);
    }
    return { references: [...refs], spans: scan.bindings };
  }

  /** Free value symbols (+ applied heads) of a `${expr}` LaTeX body — the equation `analyze` contract. */
  function exprReferences(body: string): readonly string[] {
    return analyze(body).referenceCandidates;
  }

  function evaluateBindings(
    source: string,
    scope: ScopeHandle,
    analysis: BindingAnalysis,
  ): { markup: string; status: EvalStatus; unresolvedSymbols: string[] } {
    // A malformed binding (unclosed / empty) fails the whole cell (§4.2).
    if (analysis.error)
      return { markup: "", status: "invalid", unresolvedSymbols: [] };
    syncPrecision();

    const unresolved = new Set<string>();
    let status: EvalStatus = "ok";
    const bump = (s: EvalStatus): void => {
      // `invalid` and `timeout` are terminal (a bad or too costly binding
      // fails the cell); `unresolved` upgrades `ok` but never overrides them.
      if (status === "invalid" || status === "timeout") return;
      if (s === "invalid" || s === "timeout") status = s;
      else if (s === "unresolved" && status === "ok") status = "unresolved";
    };

    // The cell's bindings evaluate under one time limit, as a formula cell
    // does (`evaluate` above): a costly `${expr}` would otherwise block the
    // page on every pass.
    const bindSpan: Parameters<typeof substituteBindings>[1] = (span) => {
      // 1. Determine this span's free references; any unbound ⇒ the cell is
      //    `unresolved` and the span renders a placeholder (empty string) — never a
      //    last-good figure (§4.3). `${var}` references itself; `${expr}` its frees.
      const refs =
        span.kind === "var" && span.name
          ? [span.name]
          : exprReferences(span.body);
      const free = unboundNames(refs, scope);
      if (free.length > 0) {
        for (const n of free) unresolved.add(n);
        bump("unresolved");
        return "";
      }

      // 2. Resolve the span to a boxed value. `N()`, not `evaluate()`: the gate
      //    reads only a boolean, a number or a string, and a value with no
      //    exact closed form (`\ln 2`) stays symbolic under `evaluate()`,
      //    whose `.re` is NaN. An integral with no closed form becomes a
      //    `Measurement` (a value and an error bound) under `N()`, and the
      //    gate shows its value.
      let value: Expression;
      try {
        if (span.kind === "var" && span.name)
          value = ce.expr(span.name).N();
        else {
          // `${expr}` — evaluate the LaTeX body in a pushed CHILD scope, popped
          // immediately, so a side-effectful body (`${a=5}`) is CONTAINED (G6). CE
          // reads `=` as `Equal` (a predicate), not `Assign`, so the outer scope is
          // byte-unchanged either way — the child scope is belt-and-suspenders.
          ce.pushScope();
          try {
            value = ce.parse(span.body).N();
          } finally {
            ce.popScope();
          }
        }
      } catch (err) {
        // A pathological read-back (self-referential binding, etc.) fails THIS
        // binding — never the whole recompute pass (mirrors the cortex read-back).
        // A spent time limit fails the cell as `timeout`.
        const cause = causeOf(err);
        bump(
          cause === "timeout" || cause === "iteration-limit-exceeded"
            ? "timeout"
            : "invalid",
        );
        return "";
      }

      // 3. Gate the boxed value (§4.3/G4) and XML-escape the substituted text.
      const text = gateBindingValue(value);
      if (text === null) {
        bump("invalid");
        return "";
      }
      return escapeXml(text);
    };
    const substitute = (): string => substituteBindings(source, bindSpan);

    const limit = formulaTimeLimitMs();
    let markup: string;
    try {
      if (limit === undefined) markup = substitute();
      else {
        // `runEvalSpan` also reports a span that ran past its limit while a
        // catch inside it swallowed the cancellation.
        const span = runEvalSpan(ce, limit, substitute, {
          label: "notebook-binding-cell",
        });
        if (!span.ok)
          return {
            markup: "",
            status: "timeout",
            unresolvedSymbols: [...unresolved],
          };
        markup = span.value;
      }
    } catch (err) {
      // An error that leaves the span outside a binding's own `try`.
      const cause = causeOf(err);
      return {
        markup: "",
        status:
          cause === "timeout" || cause === "iteration-limit-exceeded"
            ? "timeout"
            : "invalid",
        unresolvedSymbols: [...unresolved],
      };
    }
    return { markup, status, unresolvedSymbols: [...unresolved] };
  }

  /**
   * Gate a resolved binding value to substitutable text (§4.3/G4): a boolean →
   * `"True"`/`"False"`; a number → {@link formatNumberForDisplay} of `.re`; a
   * string → its `.string`; a `Measurement` (what `N()` gives for an integral
   * with no closed form: a value and its error bound) → its value, when both
   * are finite; a collection / function / symbolic / `Nothing` → `null` (the
   * caller marks the cell `invalid`). Checked boolean-first because a
   * boolean is the symbol `True`/`False` (not a number nor a `.string`).
   */
  function gateBindingValue(value: Expression): string | null {
    const symbolName = sym(value);
    if (symbolName === "True") return "True";
    if (symbolName === "False") return "False";
    if (value.isNumber === true && typeof value.re === "number")
      return formatNumberForDisplay(value.re, ceConfig());
    if (isString(value)) return value.string;
    if (isFunction(value, "Measurement") && value.nops === 2) {
      const [central, error] = value.ops;
      if (Number.isFinite(central.re) && Number.isFinite(error.re))
        return formatNumberForDisplay(central.re, ceConfig());
    }
    return null;
  }

  /**
   * Build the `\%` / `\%n` resolver for a cell from its eval options. A bare `\%`
   * (index `null`) maps to the cell at `referenceIndex − 1` (the previous answer);
   * `\%n` maps to index `n`. Returns the stored answer MathJSON, or `undefined`
   * (unresolved) when there is no history or no such answer.
   */
  function makeAnswerLookup(options?: EvalOptions): AnswerLookup {
    const answers = options?.answers;
    const selfIndex = options?.referenceIndex;
    return (index) => {
      if (!answers) return undefined;
      const target =
        index === null
          ? typeof selfIndex === "number"
            ? selfIndex - 1
            : null
          : index;
      return target === null ? undefined : answers.get(target);
    };
  }

  /**
   * Evaluate a formula cell under its time limit ({@link formulaTimeLimitMs}).
   * The limit bounds the whole cell, as one `withTimeLimit` span: parsing,
   * evaluation and the formatting of the result. A spent limit gives the
   * `timeout` status; the engine stops at its next cancellation check, so
   * the cell can run a little past the limit. Some steps inside the cell
   * catch the engine's errors themselves (a failed parse reads as `invalid`,
   * a failed `.N()` falls back to the exact form), so a cancellation there
   * does not leave the span; `runEvalSpan` also reports a span that ran past
   * its limit as a timeout, and the cell gets `timeout` either way.
   * Each cell has its own limit, so N costly cells still block the page for
   * N times the limit (ROADMAP row HV).
   */
  function evaluate(
    input: string,
    scope: ScopeHandle,
    analysis?: CellAnalysis,
    options?: EvalOptions,
  ): EvalOutcome {
    const limit = formulaTimeLimitMs();
    if (limit === undefined)
      return evaluateCell(input, scope, analysis, options);
    try {
      const span = runEvalSpan(
        ce,
        limit,
        () => evaluateCell(input, scope, analysis, options),
        { label: "notebook-formula-cell" },
      );
      if (span.ok) return span.value;
      return errorOutcome(
        (analysis ?? analyze(input)).defines,
        "timeout",
        `Timeout exceeded (${limit}ms)`,
      );
    } catch (err) {
      // An error that `evaluateCell` did not map itself.
      return mapEvalError(err, (analysis ?? analyze(input)).defines);
    }
  }

  function evaluateCell(
    input: string,
    _scope: ScopeHandle,
    analysis?: CellAnalysis,
    options?: EvalOptions,
  ): EvalOutcome {
    syncPrecision();
    const approximate = options?.approximate === true;
    // defines for the graph come from the same (form:'raw') analysis —
    // guarantees consistency, scope-independent. Reuse the caller's analysis when
    // provided (the graph already ran pass 1) to avoid a redundant parse.
    const { defines, functionDefines } = analysis ?? analyze(input);
    const base = {
      defines,
      unresolvedSymbols: [] as string[],
      undefinedFunctions: [] as string[],
    };

    if (!input.trim())
      return { ...base, result: { kind: "empty" }, status: "ok" };

    // Prefix pipeline (`|> f`): a cell that STARTS with the pipeline operator pipes
    // the PREVIOUS ANSWER into the stage. Rewritten to the INFIX pipeline `\% |> f`,
    // so CE lowers the stage against a concrete left operand once the `\%` is
    // substituted below. (The former `Apply(<prefix lambda>, Ans)` route is
    // unusable: canonicalizing the lambda body runs unknown-inference on the
    // pipe-topic placeholder, so `|> Solve` became `Solve(_, _)` and the piped
    // value filled BOTH slots — docs/COMPUTE_ENGINE.md § "Prefix pipeline:
    // unknown-inference binds to the topic placeholder".)
    const effectiveInput = isPrefixPipelineInput(input)
      ? `\\% ${input}`
      : input;

    // Resolve `\%` / `\%n` previous-answer references (ce-ans-references.ts) against
    // the section's answer history BEFORE canonicalization — not merely before
    // evaluation. Canonicalization makes shape decisions from the symbolic marker
    // that are wrong once the real value lands: an unknown-inferring operator
    // (`Solve`, `D`, …) infers its unknown from the marker's own free variables,
    // so `Solve(\%)` canonicalized to `Solve(Ans, Ans)` and substitution then
    // filled the answer into both slots. So an answer-referencing cell parses
    // NON-canonically, substitutes, and only then boxes (canonicalizes) the
    // resolved tree. A reference that cannot be resolved (dangling / forward / no
    // history) stays symbolic and makes the cell `unresolved`. The common no-`%`
    // cell keeps the single canonical parse — the `\\%` string probe is exact
    // because the notebook engine's dictionary reserves `\%` for answer references.
    let expr: Expression;
    let ansUnresolved = false;
    try {
      if (effectiveInput.includes("\\%")) {
        const raw = ce.parse(effectiveInput, {
          form: "raw",
        });
        const resolved = substituteAnswers(raw.json, makeAnswerLookup(options));
        ansUnresolved = resolved.unresolved;
        // `substituteAnswers` preserves MathJSON shape (walks + splices MathJSON).
        expr = ce.expr(resolved.json as MathJsonExpression);
      } else expr = ce.parse(effectiveInput);
    } catch (err) {
      return errorOutcome(defines, "invalid", messageOf(err));
    }

    if (expr.isValid === false)
      return errorOutcome(defines, "invalid", invalidDetail(expr.errors));

    // Transient action-suggestion handle (NOTEBOOK_ACTION_SUGGESTIONS.md §2.4):
    // the canonical input MathJSON + its section-scope-correct free variables.
    // `expr` is parsed in the live (pushed) section scope, so bound symbols are
    // not free — the authoritative `unknowns` for the catalog's free-var gates.
    const inputJson = expr.json;
    const inputUnknowns = expr.freeVariables ? [...expr.freeVariables] : [];

    // ── Definition cells (§6.2): evaluate to BIND the value (snapshot semantics,
    //    §5.5), then render input + "defined" — no result value. ──
    if (defines.length > 0) {
      let evaluated: Expression;
      try {
        evaluated = expr.evaluate();
      } catch (err) {
        return mapEvalError(err, defines);
      }
      // A FUNCTION definition late-binds (§5.4): an undefined name in its body is
      // not an error here — it surfaces at the call site. A VALUE definition
      // *snapshots* its RHS at this position, so a still-free value ref
      // (`b := a + 1` with no preceding `a`) makes the cell `unresolved`.
      const isFunctionDef = defines.every((d) => functionDefines.includes(d));
      const unresolvedSymbols = isFunctionDef
        ? []
        : [...(evaluated.freeVariables ?? [])].filter((n) => n !== ANS_SYMBOL);
      // Suggestion handle (§2.4): result-pills fire on a VALUE definition that
      // binds a concrete value (single name, not a function, fully resolved) — the
      // bound value + a by-symbol ref. Function / multi-name / unresolved defs
      // publish no result handle (no pills on a lambda or a still-free RHS).
      const valueDef =
        !isFunctionDef &&
        defines.length === 1 &&
        unresolvedSymbols.length === 0 &&
        !ansUnresolved;
      return {
        defines,
        result: { kind: "definition", names: defines },
        status:
          unresolvedSymbols.length > 0 || ansUnresolved ? "unresolved" : "ok",
        unresolvedSymbols,
        undefinedFunctions: [],
        inputJson,
        unknowns: inputUnknowns,
        boundValues: readBoundValues(defines, functionDefines, inputJson),
        ...(valueDef
          ? {
              resultJson: evaluated.json,
              sourceRef: { name: defines[0] },
            }
          : {}),
      };
    }

    // ── PLOT (§6.2): a `Plot(…)`/`Plot3D(…)` head — the value IS a plot spec.
    //    Detected at evaluate-time (post-declare), where the head is an application
    //    (de-risk §1.1). The whole `Plot(…)` is NOT CE-evaluated (it would stay
    //    symbolic) — instead each argument is evaluated in-scope to inline
    //    definitions. This is value construction, NOT view steering: `output.as`
    //    no longer forces a plain expression down this arm (plan 3.3 — the plot
    //    VIEW of a plain expression is derived render-side from its evaluated
    //    LaTeX, `derivePlotSeries`). ──
    const op = typeof expr.operator === "string" ? expr.operator : "";
    const isPlotHead = op === "Plot" || op === "Plot3D";
    if (isPlotHead) {
      // An undefined reference inside a plot body is `unresolved`, exactly as it is
      // in the ordinary arm below (D20(f)): before N-5 this arm returned `ok`
      // unconditionally, so `Plot(f)` over an undefined `f` drew a degenerate plot
      // of the free symbol while a plain `f` reference reported `unresolved`.
      //
      // A free name is LEGITIMATE here iff the plot itself binds it as an axis or
      // parameter variable — `isReservedVariableName` (`x`/`y`/`z`/`t`/`u`/`v`/
      // `theta`/`phi`, plus the polar radius `r`), the same set the plot classifier
      // uses, so a cartesian `Plot(x^2)`, a parametric `Plot((\cos t, \sin t))` and
      // a 3D `Plot3D(f(u,v))` all stay `ok`. Every OTHER free name is a reference.
      // `inputUnknowns` is the LIVE-scope free set, so a name bound earlier in the
      // section (a value definition, a slider, a bound table) is already absent;
      // `unboundNames` re-probes the survivors and drops declared functions.
      const plotUnresolvedSymbols = unboundNames(
        inputUnknowns.filter(
          (n) => n !== ANS_SYMBOL && !isReservedVariableName(n),
        ),
        _scope,
      );
      const plotUndefinedFunctions = appliedNonFunctions(input).filter(
        (n) => n !== ANS_SYMBOL,
      );
      if (
        plotUnresolvedSymbols.length > 0 ||
        plotUndefinedFunctions.length > 0 ||
        ansUnresolved
      )
        // Report the ordinary arm's shape — a `math` result plus the diagnostics —
        // NOT a plot result: the render layer deliberately suppresses the
        // unresolved indicator on a plot value (its async `replaceChildren` would
        // clobber the note), so a plot-kind result here would hide the diagnosis
        // behind the degenerate plot this fix exists to stop drawing.
        return {
          defines,
          result: {
            kind: "math",
            latex: typeof expr.latex === "string" ? expr.latex : "",
          },
          status: "unresolved",
          unresolvedSymbols: plotUnresolvedSymbols,
          undefinedFunctions: plotUndefinedFunctions,
          inputJson,
          unknowns: inputUnknowns,
        };
      try {
        return {
          ...base,
          result: buildPlotResult(expr, op === "Plot3D", _scope),
          status: "ok",
        };
      } catch (err) {
        // A plotted argument that diverges/times out surfaces the §5.6 status,
        // not a silent ok plot.
        return mapEvalError(err, defines);
      }
    }

    // ── Evaluation cell — evaluate the body (try/catch maps §5.6 divergence). ──
    let evaluated: Expression;
    try {
      evaluated = expr.evaluate();
    } catch (err) {
      return mapEvalError(err, defines);
    }

    // ── COMPUTED TABLE (§6.2): a tabular result (a collection of rank ≥ 1,
    //    de-risk §1.4). Distinct from an authored table. This classifies the
    //    VALUE (`output.as` no longer forces a scalar into a 1×1 table — that is
    //    the table renderer's job over a scalar value, plan 3.3). The equation
    //    value layer sub-classifies this collection into `list`/`matrix`/`tabular`
    //    from `resultJson` (§13.1). ──
    const isColl =
      evaluated.isCollection === true && (evaluated.rank ?? 0) >= 1;
    if (isColl) {
      return {
        ...base,
        result: buildTableResult(evaluated),
        status: "ok",
        inputJson,
        resultJson: evaluated.json,
        unknowns: inputUnknowns,
        resultFreeSymbols: freeSymbolsOf(evaluated),
      };
    }

    // ── MATH (§5.1) — a value or symbolic result. `as:"approximate"` is handled
    //    by re-formatting via `.N()`. Free value symbols / undefined-fn calls that
    //    stayed unresolved (§5.6) set the status + quality fields only; the result
    //    still renders (the §5.1 table shows `f'(x)` → `2x+2`). ──
    const latex = resultLatex(evaluated, approximate);
    const unresolvedSymbols = [...(evaluated.freeVariables ?? [])].filter(
      (n) => n !== ANS_SYMBOL,
    );
    // `Ans(n)` has a call shape, so `appliedNonFunctions` would otherwise flag `Ans`
    // for the "define `Ans(…)`?" prompt — drop it (it is resolved, not a user fn).
    const undefinedFunctions = appliedNonFunctions(input).filter(
      (n) => n !== ANS_SYMBOL,
    );
    const status: EvalOutcome["status"] =
      unresolvedSymbols.length > 0 ||
      undefinedFunctions.length > 0 ||
      ansUnresolved
        ? "unresolved"
        : "ok";
    return {
      defines,
      result: { kind: "math", latex },
      status,
      unresolvedSymbols,
      undefinedFunctions,
      inputJson,
      resultJson: evaluated.json,
      unknowns: inputUnknowns,
      resultFreeSymbols: unresolvedSymbols,
    };
  }

  /** The free symbols of an evaluated result, without the answer marker. */
  function freeSymbolsOf(evaluated: Expression): string[] {
    return [...(evaluated.freeVariables ?? [])].filter((n) => n !== ANS_SYMBOL);
  }

  /**
   * The values the engine holds for the names a definition cell just bound
   * (`EvalOutcome.boundValues`): a value's JSON, read back from the symbol; a
   * function's right-hand side as parsed (`["Function", …]`, the part of the
   * definition that is its own text; the engine's operator record has no JSON
   * form). A name the engine did not bind is left out.
   */
  function readBoundValues(
    defines: readonly string[],
    functionDefines: readonly string[],
    inputJson: MathJsonExpression,
  ): Map<string, MathJsonExpression> {
    const out = new Map<string, MathJsonExpression>();
    const fnSet = new Set(functionDefines);
    for (const name of defines) {
      if (fnSet.has(name)) {
        const rhs =
          Array.isArray(inputJson) && inputJson[0] === "Assign"
            ? (inputJson[2] as MathJsonExpression)
            : undefined;
        if (rhs !== undefined) out.set(name, rhs);
        continue;
      }
      try {
        const value = ce.box(name).value;
        if (value !== undefined) out.set(name, value.json);
      } catch {
        // Not bound: left out.
      }
    }
    return out;
  }

  /** Map a CE evaluate() throw to a `diverged` / `timeout` / `invalid` error outcome (§5.6). */
  function mapEvalError(err: unknown, defines: string[]): EvalOutcome {
    return errorOutcome(
      defines,
      limitStatus(causeOf(err), err instanceof RangeError),
      messageOf(err),
    );
  }

  /** A scalar/symbolic result's LaTeX; `approximate` re-formats via `.N()` (§14 / D5). */
  function resultLatex(evaluated: Expression, approximate: boolean): string {
    if (approximate) {
      try {
        const approximateValue = evaluated.N.bind(evaluated);
        const n = approximateValue();
        if (typeof n.latex === "string") return n.latex;
      } catch {
        /* fall through to the exact form */
      }
    }
    return typeof evaluated.latex === "string" ? evaluated.latex : "";
  }

  /**
   * Build a `plot` result from a `Plot(…)`/`Plot3D(…)` head expression. Each
   * argument is evaluated in-scope so section definitions inline (de-risk §1.2);
   * a tabular argument (`Plot(myTable)`) becomes one `points` series per data
   * column, others an `expr` (function) series. Only reached for a genuine plot
   * head now (the `as:"plot"` forcing of a bare expression is gone — plan 3.3).
   */
  function buildPlotResult(
    expr: Expression,
    is3d: boolean,
    scope: ScopeHandle,
  ): EvalResult {
    const dim = is3d ? 3 : 2;
    const args: readonly Expression[] = isFunction(expr) ? expr.ops : [];
    const series: PlotEvalSeries[] = [];
    for (const arg of args) {
      // May throw on a diverging/timing-out argument — the caller maps it (§5.6).
      const argEval = arg.evaluate();
      if (argEval.isCollection === true && (argEval.rank ?? 0) >= 1) {
        // The points are read from MathJSON numbers, so the elements are read
        // through their numeric approximation: an exact element
        // (`["Rational", 1, 3]`, `["Sqrt", 2]`) is not a MathJSON number, and
        // the reader would give NaN for it. The `expr` branch below keeps the
        // exact value, whose LaTeX the plot view parses again.
        pushPointsSeries(
          series,
          extractNumberRows(argEval.N().json),
          headersForArg(arg, scope),
        );
      } else if (argEval.isCollection === true) {
        // A degenerate collection (empty list / rank-0 set) has nothing plottable.
        continue;
      } else {
        const latex =
          (typeof argEval.latex === "string" && argEval.latex) ||
          (typeof arg.latex === "string" && arg.latex) ||
          "";
        if (latex) series.push({ kind: "expr", latex });
      }
    }
    return { kind: "plot", dim, series };
  }

  /** Column headers for a `Plot(name)` data argument, if `name` is a bound authored table. */
  function headersForArg(
    arg: Expression,
    scope: ScopeHandle,
  ): string[] | undefined {
    const name = sym(arg);
    const table = name ? tablesOf(scope).get(name) : undefined;
    return table?.columns.map((c) => c.header);
  }

  /**
   * A tabular CE result → a read-only computed table (cells as LaTeX). Carries the
   * collection's evaluated `latex` so the math VIEW of this value renders without
   * CE access (plan 3.3 §3); a degenerate (non-List) result falls back to a 1×1
   * grid. Only reached for a genuine collection now (`as:"table"` no longer forces
   * a scalar here — the table renderer builds the 1×1 grid from a scalar value).
   */
  function buildTableResult(evaluated: Expression): EvalResult {
    const latex = typeof evaluated.latex === "string" ? evaluated.latex : "";
    const rows = extractLatexRows(evaluated.json);
    if (rows.length > 0) return { kind: "table", headers: [], rows, latex };
    return {
      kind: "table",
      headers: [],
      rows: [[cellToLatex(evaluated.json)]],
      latex,
    };
  }

  /** One CE cell value → display LaTeX (`ce.expr(v).latex`), falling back to a
   *  string. `value` is a MathJSON node from a `.json`/tree walk — boxed at the
   *  boundary. */
  function cellToLatex(value: unknown): string {
    try {
      const latex = ce.expr(value as MathJsonExpression).latex;
      if (latex.length > 0) return latex;
    } catch {
      /* fall through */
    }
    return typeof value === "string" ? value : JSON.stringify(value);
  }

  /** A `["List", …]` MathJSON tree → display-LaTeX rows: a matrix → rows×cols, a vector → one column. */
  function extractLatexRows(json: unknown): string[][] {
    if (!Array.isArray(json) || json[0] !== "List") return [];
    const elems = json.slice(1);
    if (isMatrixElems(elems)) {
      return elems.map((row) =>
        (row as unknown[]).slice(1).map((c) => cellToLatex(c)),
      );
    }
    return elems.map((v) => [cellToLatex(v)]);
  }

  /**
   * Names applied as functions that the notebook has not defined — the
   * "define `f(x)`?" prompt's input.
   *
   * CE's own answer, and only that. CE ≥ 0.131.2 reports a head whose
   * function-ness the parse only INFERRED from the application (CE ask 302),
   * so a head with nothing behind it reaches the prompt without a Tycho tree
   * walk beside it.
   */
  function appliedNonFunctions(input: string): string[] {
    const out = new Set<string>();
    try {
      const reported = ce.appliedNonFunctions(input);
      if (Array.isArray(reported)) for (const name of reported) out.add(name);
    } catch {
      // unparseable: nothing to prompt for
    }
    return [...out];
  }

  function rewriteReference(
    input: string,
    oldName: string,
    newName: string,
    asFunction: boolean,
  ): string {
    if (oldName === newName || !input.trim()) return input;
    const a = analyze(input);
    if (
      !a.referenceCandidates.includes(oldName) &&
      !a.defines.includes(oldName)
    )
      return input;
    // Both paths run inside a throwaway scope so any auto-declaration (`box`,
    // `symbol`, a canonical parse) never pollutes a group's persistent scope.
    // The throwaway scope is a child of the ROOT scope, not of a group scope
    // that may be pushed at the time, so the rewrite reads the cell as a bare
    // engine would.
    return atRoot(() => rewriteInThrowawayScope());

    function rewriteInThrowawayScope(): string {
      ce.pushScope();
      try {
        if (asFunction) {
          // A function rename must rewrite call-site heads (`f(1024)` → `g(1024)`),
          // which `subs` cannot do (de-risk §1). Declare both names as functions so
          // call syntax parses as an application, head-rewrite the MathJSON, re-serialize.
          try {
            ce.declare(oldName, "function");
          } catch {
            /* already declared */
          }
          try {
            ce.declare(newName, "function");
          } catch {
            /* already declared */
          }
          const json = renameInJson(ce.parse(input).json, oldName, newName);
          // `renameInJson` preserves MathJSON shape (only rewrites symbol strings).
          const out = ce.expr(json as MathJsonExpression).latex;
          return out.length > 0 ? out : input;
        }
        // Value rename: substitute the symbol (covers value refs + the definition
        // target — `a + 1` → `b + 1`, `b := a + 1` → `b := c + 1`).
        const out = ce.parse(input, { form: "raw" }).subs({
          [oldName]: ce.symbol(newName),
        })?.latex;
        return typeof out === "string" && out.length > 0 ? out : input;
      } catch {
        return input;
      } finally {
        ce.popScope();
      }
    }
  }

  // ── Cortex cell (Phase 2a — the Cortex cell as a graph participant, §3) ──────

  /**
   * Pre-seed a child-local declaration for every assignment target (§2 ①b) so a
   * bare `Assign` / `function` sugar mutates the CHILD binding, never the outer one
   * (F11). Seeded from the outer value when bound (preserves `a = a + 1`
   * read-before-write); a function-shaped outer binding (or a function define) is
   * re-declared as a child-local function so the reassignment stays contained.
   * Top-level `let` targets are EXCLUDED (`analysis.declaredNames`): they are
   * child-local already (F2) and pre-declaring them makes the program's own `let`
   * emit an "already declared" runtime-error (probe-confirmed).
   *
   * Returns the names whose pre-seed FAILED. A failed pre-seed means the child scope
   * could not be isolated for that name, so the run is no longer contained — the
   * caller ABORTS the run rather than executing uncontained (ratified §2.2). Failure
   * is NOT swallowed.
   */
  function preseedCortex(analysis: CortexAnalysis): string[] {
    const letNames = new Set(analysis.declaredNames);
    const fnDefines = new Set(analysis.functionDefines);
    const seeded = new Set<string>();
    const failed: string[] = [];
    for (const name of analysis.assignedNames) {
      if (letNames.has(name) || seeded.has(name)) continue;
      seeded.add(name);
      try {
        const box = ce.expr(name);
        const outerIsFunction =
          box.operatorDefinition != null || box.type.matches("function");
        if (outerIsFunction || fnDefines.has(name)) {
          ce.declare(name, "function");
          continue;
        }
        const evaluated = box.evaluate();
        // An unbound symbol evaluates to itself — otherwise it is bound to a
        // value (number, list, aliased symbol, an Error value, …). Read
        // `.symbol`, never `.json`: `.json` serializes the VALUE to a MathJSON
        // tree just to compare it with a name.
        const boundValue = sym(evaluated) !== name;
        if (boundValue) ce.declare(name, { value: evaluated });
        else ce.declare(name, "unknown");
      } catch {
        // Containment for this name could not be established — record and abort.
        failed.push(name);
      }
    }
    return failed;
  }

  /**
   * Read the published snapshot from the child scope (§2 ③, before pop): top-level
   * VALUE defines read back as MathJSON (`.evaluate().json`); FUNCTION defines come
   * from the parse (F10 — functions can't be read back), verbatim including any
   * `["Error", …]` value (errors are values).
   */
  function snapshotCortex(
    analysis: CortexAnalysis,
    escapeDiagnostics: string[],
  ): CortexSnapshot {
    const values = new Map<string, MathJsonExpression>();
    const functions = new Map<string, readonly MathJsonExpression[]>();
    const fnDefines = new Set(analysis.functionDefines);
    for (const name of analysis.defines) {
      if (fnDefines.has(name)) {
        const clauses = analysis.functionSnapshots.get(name);
        if (clauses !== undefined && clauses.length > 0) {
          // A function whose body assigns a non-local outer name would escape
          // containment when a consumer calls it (call-time Assign walks the
          // section scope) — exclude it from the publication (finding 5). The
          // function is ONE unit: any offending clause excludes the whole set.
          const outer = [
            ...new Set(clauses.flatMap((c) => functionAssignsOuterNames(c))),
          ];
          if (outer.length > 0) {
            escapeDiagnostics.push(
              `function '${name}' assigns outer name '${outer.join(", ")}' — not published`,
            );
          } else functions.set(name, clauses);
        }
        continue;
      }
      try {
        values.set(name, ce.expr(name).evaluate().json);
      } catch {
        // Unreadable binding — leave it unpublished (a consumer resolves to unresolved).
      }
    }
    return { values, functions };
  }

  /**
   * The §5 overlay signal (orthogonal to status): of `names`, those that resolve to
   * NO binding at this position. A name is bound if it has an operator/function
   * definition or evaluates to something other than its own symbol. Occurrence-aware
   * by input: callers pass `analysis.readCandidates` (top-level reads only — a name
   * used solely inside a function body is excluded there because it late-binds at the
   * call site), so an unbound RHS read in `a = a + 1` survives the overlay while a
   * pure write target does not.
   */
  function unboundNames(
    names: readonly string[],
    _scope: ScopeHandle,
  ): string[] {
    const out: string[] = [];
    for (const name of names) {
      const box = ce.expr(name);
      if (box.operatorDefinition != null || box.type.matches("function"))
        continue;
      // Binding probe WITHOUT evaluating: `valueDefinition.value` is the stored,
      // unevaluated binding, present iff the name resolves to a value here — the
      // question we are actually asking. Probing it is side-effect-free and cheap,
      // and it stays correct for a self-referential leftover binding (`a = a + 1`
      // over an unbound `a` binds `a` to the symbolic `a + 1`), which a degenerate
      // `box.value` read would report as UNBOUND since CE 0.77.
      const vd = box.valueDefinition;
      if (vd?.value == null) out.push(name);
    }
    return out;
  }

  function cortexError(
    status: EvalStatus,
    diagnostics: string[],
  ): CortexRunOutcome {
    return {
      latex: "",
      diagnostics,
      status,
      renderState: "error",
      unresolvedSymbols: [],
      undefinedFunctions: [],
    };
  }

  function executeCortexCell(
    source: string,
    _scope: ScopeHandle,
    analysis: CortexAnalysis,
    limits: CortexLimits,
  ): CortexRunOutcome {
    if (!source.trim()) {
      return {
        latex: "",
        diagnostics: [],
        status: "ok",
        renderState: "empty",
        snapshot: { values: new Map(), functions: new Map() },
        unresolvedSymbols: [],
        undefinedFunctions: [],
      };
    }

    // NOTE: `timeLimit` is NOT saved/restored here — it is no longer set (see
    // the `withTimeLimit` span below). `iterationLimit`/`recursionLimit` have
    // no span equivalent, so they keep the save/restore.
    const saved = {
      i: ce.iterationLimit,
      r: ce.recursionLimit,
    };
    ce.pushScope();
    try {
      // Containment first (§2.2): if any assignment target could not be isolated in
      // the child scope, the run would mutate the outer scope — abort as a failed
      // outcome instead. (Diagnostics-channel internal string, i18n-exempt.)
      const preseedFailed = preseedCortex(analysis);
      if (preseedFailed.length > 0) {
        return cortexError("invalid", [
          `internal: could not isolate script execution (${preseedFailed.join(", ")})`,
        ]);
      }
      ce.iterationLimit = clampLimit(
        limits.iterationLimit,
        1_000,
        1e8,
        DEFAULT_CORTEX_LIMITS.iterationLimit,
      );
      ce.recursionLimit = clampLimit(
        limits.recursionLimit,
        1,
        100_000,
        DEFAULT_CORTEX_LIMITS.recursionLimit,
      );

      // `timeLimitMs` bounds the WHOLE script run, as one `withTimeLimit`
      // span (2026-07-20, ahead of CE dropping `ce.timeLimit`). This is a
      // deliberate SEMANTIC change, not a mechanical port: the former
      // `ce.timeLimit` armed a fresh budget per evaluate, so a script doing N
      // evaluations got N × the limit and total run time was effectively
      // unbounded — the same hole the import spans were built to close. A
      // setting named "time limit" should bound how long the script runs,
      // which is what users already read it as. The clamp range is unchanged.
      // The span is run through `runEvalSpan`, as a formula cell's is: it
      // returns `ok: false` for a timeout of this span, also when an inner
      // catch swallowed the engine's throw and the run returned after its
      // deadline (it checks the clock after the span).
      const timeLimitMs = clampLimit(
        limits.timeLimitMs,
        50,
        60_000,
        DEFAULT_CORTEX_LIMITS.timeLimitMs,
      );
      let result: ExecuteCortexResult;
      try {
        const span = runEvalSpan(
          ce,
          timeLimitMs,
          () => executeCortex(ce, source),
          {
            label: "notebook-script-cell",
          },
        );
        if (!span.ok)
          return cortexError("timeout", [
            `Timeout exceeded (${timeLimitMs}ms)`,
          ]);
        result = span.value;
      } catch (err) {
        // `executeCortex` reports its own errors as diagnostics and is not
        // expected to throw, but a cancellation did reach this catch once,
        // under heavy box load (the 200 ms run of the test "timeLimitMs
        // bounds the WHOLE run" in `notebook-cortex-analysis.test.ts` came
        // back `invalid`). Where it left `executeCortex` is not known. A
        // limit breach keeps its meaning: `limitStatus` maps a time or
        // iteration limit to `timeout` and a recursion limit to `diverged`;
        // any other throw is `invalid`.
        return cortexError(
          limitStatus(causeOf(err), err instanceof RangeError),
          [messageOf(err)],
        );
      }

      const diagnostics = result.diagnostics;

      // (1) Parse-error diagnostics (severity error; runtime errors and the
      //     non-final `evaluation-canceled` cancellation are handled below) →
      //     invalid (§5 precedence 1).
      const parseErrors = diagnostics.filter(
        (d) =>
          d.severity === "error" &&
          diagCode(d.message) !== "runtime-error" &&
          diagCode(d.message) !== "evaluation-canceled",
      );
      if (parseErrors.length > 0) {
        return cortexError(
          "invalid",
          parseErrors.map((d) => diagText(d.message)),
        );
      }

      // (2) Cancellation — an `evaluation-canceled` diagnostic (non-final,
      //     F7) OR a final ["Error", msg, cause] value (F13). Structured
      //     cause: recursion → diverged, timeout/iteration → timeout.
      const cancel = cortexCancellation(diagnostics, result.value);
      if (cancel !== null) {
        return cortexError(limitStatus(cancel.cause), [cancel.text]);
      }

      // (3) ok — read back + publish (all reads happen before the child pop). An
      //     unresolved reference is an OVERLAY (§5 last row), orthogonal to status:
      //     the run completed and publishes, so the status stays `ok` (R2a-5).
      //     THROW-SAFE: CE serialization/read-back can throw on pathological
      //     bindings (a self-referential `a = a + 1` over an unbound `a`
      //     stack-overflows `.latex` — probed). executeCortex itself never
      //     throws (F9), but the read-back is our code reading CE surfaces; a
      //     throw here must fail THIS cell, never the whole recompute pass.
      try {
        const latex =
          typeof result.value.latex === "string" ? result.value.latex : "";
        const escapeDiagnostics: string[] = [];
        const snapshot = snapshotCortex(analysis, escapeDiagnostics);
        const unresolvedSymbols = unboundNames(analysis.readCandidates, _scope);
        const renderState: CortexRunOutcome["renderState"] =
          lastStatementIsDefinition(source) ? "definition" : "value";
        return {
          latex,
          diagnostics: [
            ...diagnostics.map((d) => diagText(d.message)),
            ...escapeDiagnostics,
          ],
          status: "ok",
          renderState,
          snapshot,
          unresolvedSymbols,
          undefinedFunctions: [],
        };
      } catch (err) {
        return cortexError("invalid", [messageOf(err)]);
      }
    } finally {
      ce.iterationLimit = saved.i;
      ce.recursionLimit = saved.r;
      ce.popScope();
    }
  }

  function bindCortexPublications(
    snapshot: CortexSnapshot,
    _scope: ScopeHandle,
  ): void {
    for (const [name, value] of snapshot.values) {
      try {
        ce.assign(name, ce.expr(value));
      } catch {
        // Leave the name unbound on failure (mirrors bindTable) — never corrupt.
      }
    }
    for (const [name, clauses] of snapshot.functions) {
      // D-207: publish the clause SET via native clause dispatch — one
      // ["DefineFunction", name, clause] evaluation per clause, program order
      // (the CE-item-141 publication target; replaces the single-clause F10
      // Function-assign). Domains are distinct by construction (a same-domain
      // duplicate errors the producing cell — CE 0.109.0), and re-publication
      // is safe: across-program same-domain re-defines are last-wins.
      //
      // Failure handling must cover BOTH failure shapes: CE reports most
      // problems as ["Error"] VALUES (checked via `.isValid` — a plain
      // `.evaluate()` never throws for those), and only rarely throws. Either
      // way the name must not end up bound to a PARTIAL clause set (some
      // clauses landed, the rest did not — e.g. a fib missing its base
      // cases). `ce.forget` does NOT undo a DefineFunction-registered clause
      // (probe-measured, the implementation-time probe), so rollback
      // is impossible — instead PRE-VALIDATE the whole set in a pushed child
      // scope (popped either way, so the real scope is untouched by the
      // probe), and apply to the real scope only when every clause validated.
      let allValid = true;
      ce.pushScope();
      try {
        for (const clause of clauses) {
          const probed = ce
            .box(["DefineFunction", name, clause] as MathJsonExpression)
            .evaluate();
          if (!probed.isValid) {
            allValid = false;
            break;
          }
        }
      } catch {
        allValid = false;
      } finally {
        ce.popScope();
      }
      if (!allValid) continue; // leave the name unbound — never a partial set
      try {
        for (const clause of clauses)
          ce.box([
            "DefineFunction",
            name,
            clause,
          ] as MathJsonExpression).evaluate();
      } catch {
        // A throw the child-scope probe did not reproduce — nothing more we
        // can do (rollback is impossible); the partial-set window is the
        // probe-diverges-from-apply case only, which the probe makes
        // practically unreachable.
      }
    }
  }

  function shadowCortexDeclarations(
    valueNames: readonly string[],
    functionNames: readonly string[],
    _scope: ScopeHandle,
  ): string[] {
    // Forget every declared name so an earlier definer's value goes symbolic
    // for a later consumer (F12). `ce.forget` removes the assumptions about a
    // name, which is what holds a VALUE. It does not remove an operator
    // definition: a function defined by an earlier `f(x) := …` still applies
    // after `forget("f")` (measured on CE 0.153.0 and 0.154.0: `f(2)` reads
    // `4`). The loop below removes the function definitions.
    for (const name of [...valueNames, ...functionNames]) {
      try {
        ce.forget(name);
      } catch {
        // Not bound — nothing to forget.
      }
    }
    // Unbind each function name, then declare it a bare `function` again, so
    // that a later `f(x)` still parses as an application and not as an
    // implicit multiplication (§3.3/N3), and every call stays unevaluated
    // (`f(2)` reads `f(2)`).
    //
    // A name that is bound in THIS scope is first removed with
    // `ce.undeclare`, whatever the binding holds: a function given with
    // `f(x) := …`, a function defined by one or more clauses, or a value (a
    // name declared `function` by `declareFunctions` and then assigned a
    // lambda). The following `declare` is then a new declaration, and a later
    // `f(x) := …` or clause publication binds the name again. `undeclare` is
    // called only for a name in the bindings of the current lexical scope,
    // because it throws for a name that is not declared there. A name that is
    // unbound, or bound only in a parent scope or by the library, is declared
    // a bare `function` here directly, which shadows the outer binding.
    //
    // Before CE 0.155.0 the engine had no way to remove a function defined by
    // two or more clauses (it refused to declare it again or to patch it), so
    // that definition stayed in effect for the consumers. CE ledger row 378,
    // `docs/COMPUTE_ENGINE.md`, asked for `ce.undeclare`.
    //
    // The function still returns the names that stayed bound to an operator
    // definition, so that the caller can report them in the cell's
    // diagnostics. Whether a name stayed bound is READ from its definition
    // after the calls, not inferred from a throw. With `undeclare` the list is
    // expected to be empty; a throw (for example for a name that is the
    // variable of a `Sum` under evaluation, which cannot occur during a
    // shadow) leaves the name in it.
    const stillBound: string[] = [];
    for (const name of functionNames) {
      try {
        if (ce.context.lexicalScope.bindings.has(name)) ce.undeclare(name);
        ce.declare(name, "function");
        continue;
      } catch {
        // The engine refused to unbind or to declare the name; read below
        // whether a definition stayed in effect.
      }
      const def = ce.lookupDefinition(name);
      if (def !== undefined && "operator" in def) stillBound.push(name);
    }
    return stillBound;
  }

  /**
   * Trace CE's step-by-step working for `operation` on `latex`
   * (notebook-evaluator.ts § `explain`). The caller (compute graph `probe`) has
   * already entered the section `scope`, so it is the CE scope-stack top here;
   * we parse in a pushed CHILD scope popped immediately, so any parse side
   * effect is contained and the section scope stays byte-unchanged (mirrors
   * `evaluateBindings`' `${expr}` handling). The child inherits the section's
   * definitions, so `f(x):=…` / sliders / tables resolve in the steps.
   */
  function explain(
    latex: string,
    operation: ExplainOperation,
    _scope: ScopeHandle,
  ): ExplainOutcome {
    ce.pushScope();
    try {
      const expr = ce.parse(latex);
      if (!expr.isValid)
        return { ok: false, error: "the expression could not be parsed" };
      const exp = expr.explain(operation);
      return {
        ok: true,
        operation,
        initial: exp.initial.latex,
        result: exp.result.latex,
        steps: exp.steps.map((s) => ({
          latex: s.value.latex,
          id: s.id,
          description: s.description,
        })),
      };
    } catch (err) {
      // A pathological expression (deep recursion, an operation the input does
      // not support) fails THIS call only — never the recompute pass.
      const cause = causeOf(err);
      return {
        ok: false,
        error:
          cause === "timeout" || cause === "iteration-limit-exceeded"
            ? "explaining this expression timed out"
            : "the Compute Engine could not explain this expression",
      };
    } finally {
      ce.popScope();
    }
  }

  return {
    enterScope,
    exitScope,
    evaluatorVersion: options.engineVersion ?? "",
    settingsKey,
    checkCandidates(
      baseline: CheckBaseline,
      candidates: readonly SuggestionCandidate[],
      timeLimitMs?: number,
      section?: ScopeHandle,
    ): string[] {
      // Each check runs in a child scope that is popped after it, so a check
      // binds nothing that stays. The parent is `section` (the restored scope
      // of the cell's group) when the caller gives it, else the root.
      syncPrecision();
      if (section !== undefined) {
        const captured = (section as CeScopeHandle).captured;
        if (ce.context?.lexicalScope !== captured)
          throw new Error(
            "checkCandidates: the section scope is not the current scope",
          );
      }
      const inChild = (fn: () => string[]): string[] => {
        ce.pushScope();
        try {
          return fn();
        } finally {
          ce.popScope();
        }
      };
      const passed: string[] = [];
      for (const candidate of candidates) {
        const check = (): string[] =>
          checkCandidates(ce, baseline, [candidate], timeLimitMs);
        passed.push(
          ...(section !== undefined
            ? inChild(check)
            : atRoot(() => inChild(check))),
        );
      }
      return passed;
    },
    setCalculation(next: NotebookCalculationSettings): void {
      // The precision reaches the engine at the next evaluation
      // (`syncPrecision`); the other settings are read where they apply.
      calculation = next;
    },
    beginDefine,
    unbind,
    restore,
    analyze,
    declareFunctions,
    bindTable,
    bindScalar,
    analyzeBindings,
    evaluateBindings,
    evaluate,
    explain,
    rewriteReference,
    analyzeCortex,
    executeCortexCell,
    bindCortexPublications,
    shadowCortexDeclarations,
    unboundNames,
  };

  function errorOutcome(
    defines: string[],
    status: "invalid" | "diverged" | "timeout",
    detail: string,
  ): EvalOutcome {
    return {
      defines,
      result: { kind: "error", detail },
      status,
      unresolvedSymbols: [],
      undefinedFunctions: [],
    };
  }
}

/** Pull a CE error's `cause` discriminant (the §5.6 `recursion-depth-exceeded`/`timeout` tag). */
/**
 * The cell status for a breached engine limit, from the cancellation cause:
 * a recursion limit (or a JavaScript `RangeError`, a stack overflow) is
 * `diverged`, a time or iteration limit is `timeout`, and anything else is
 * `invalid`. The cause `step-budget` maps to `invalid`: no notebook route
 * arms a step budget, so a spent one is not a limit the cell asked for.
 * Every route of this file that turns an engine limit into a status uses
 * this function, so the routes cannot disagree.
 */
function limitStatus(
  cause: string | undefined,
  rangeError = false,
): "diverged" | "timeout" | "invalid" {
  if (cause === "recursion-depth-exceeded" || rangeError) return "diverged";
  if (cause === "timeout" || cause === "iteration-limit-exceeded")
    return "timeout";
  return "invalid";
}

function causeOf(err: unknown): string | undefined {
  const c = (err as { cause?: unknown } | null)?.cause;
  return typeof c === "string" ? c : undefined;
}

function messageOf(err: unknown): string {
  const m = (err as { message?: unknown } | null)?.message;
  return typeof m === "string" ? m : "";
}
