/**
 * Parse-only analysis of Cortex source for the compute graph (Phase 2a — the
 * Cortex cell as a graph participant; see
 * `requirements/archive/NOTEBOOK_CELL_PLUGINS.md` §4).
 *
 * `parseCortex(source)` returns MathJSON in **object format** — `{ fn: […] }` for
 * applications, `{ sym }` / `{ num } / { str }` wrappers for leaves, each carrying
 * `sourceOffsets` — NOT the plain-array MathJSON the LaTeX-path collectors in
 * `ce-notebook-evaluator.ts` walk. So this module has its own object-format walker
 * and a metadata-stripping normalizer (`stripMeta`) that turns a parse subtree back
 * into plain MathJSON for `ce.assign` (function snapshots, §3.2).
 *
 * `function f(…) {…}` sugar lowers to `["DefineFunction", f, ["Function", body, …params]]`
 * as of CE 0.100.0 (multi-clause dispatch needed a head distinct from `Assign`; ≤0.99
 * emitted `["Assign", f, ["Function", …]]`). Both heads are handled everywhere a
 * top-level write is recognized — `defines`, `assignedNames`, the reference walk, and
 * `lastStatementIsDefinition`.
 *
 * `while`/`for` lower to the engine's imperative `["Loop", …]` primitive (probed
 * against CE 0.75.0): a `for i in […]` puts the loop variable in an
 * `["Element", i, collection]` control node, and the loop body's assignments are
 * ordinary `Assign` nodes at depth. The walk does NOT special-case loop variables:
 * they flow through as reference candidates (a sanctioned over-approximation — the
 * dirty-candidates contract, §4). Loop-body assignment targets ARE collected into
 * `assignedNames` so the executor's child-scope pre-seed (§2 ①b) contains them.
 *
 * Pure: no ComputeEngine instance, no DOM — `parseCortex` is a standalone function,
 * so this whole module is node-testable in isolation.
 */

import { parseEpsil as parseCortex } from "@cortex-js/compute-engine/epsil";
import type { MathJsonExpression } from "@cortex-js/compute-engine";
import type { CortexAnalysis } from "./notebook-evaluator.js";

/**
 * Heads that structure the program rather than name a user binding — dropped from
 * `referenceCandidates` both as fn heads and as bare leaf symbols. Everything else
 * (including CE builtins like `Add`/`Less`) flows through as a dirty candidate and
 * is filtered at the graph, exactly like the LaTeX analysis path (so user shadowing
 * of a builtin name still wires an edge).
 */
const STRUCTURAL_HEADS = new Set<string>([
  "Program",
  "Block",
  "Declare",
  "Assign",
  "DefineFunction",
  "Dictionary",
  "KeyValuePair",
  "List",
  "Loop",
  "Function",
  "String",
  "Error",
]);

/** Bare leaf symbols that are never a user reference (the empty-program marker). */
const IGNORED_SYMBOLS = new Set<string>(["Nothing"]);

type Offsets = readonly [number, number];

/** A parsed application node `{ fn: [head, …args] }` OR a plain-array `[head, …]` (Loop lowering). */
interface FnView {
  head: string;
  args: unknown[];
}

/** View a node as an application, or `null`. Handles both object-format and the plain arrays CE emits inside `Loop`. */
function asFn(node: unknown): FnView | null {
  if (node && typeof node === "object" && !Array.isArray(node)) {
    const fn = (node as { fn?: unknown }).fn;
    if (Array.isArray(fn) && typeof fn[0] === "string")
      return { head: fn[0], args: fn.slice(1) };
    return null;
  }
  if (Array.isArray(node) && typeof node[0] === "string")
    return { head: node[0], args: node.slice(1) };
  return null;
}

/** View a node as a symbol leaf (object-format `{ sym }` or a bare string), or `null`. */
function asSym(node: unknown): { name: string; offsets?: Offsets } | null {
  if (typeof node === "string") return { name: node };
  if (node && typeof node === "object" && !Array.isArray(node)) {
    const sym = (node as { sym?: unknown }).sym;
    if (typeof sym === "string") {
      const off = (node as { sourceOffsets?: unknown }).sourceOffsets;
      return Array.isArray(off) && off.length === 2
        ? { name: sym, offsets: [off[0], off[1]] as Offsets }
        : { name: sym };
    }
  }
  return null;
}

/**
 * Strip `sourceOffsets` metadata, returning plain-array MathJSON usable by
 * `ce.assign` / `ce.box`. Object-format `{ fn }` → `[head, …args]`; `{ sym }` →
 * the symbol string; `{ num }` / `{ str }` kept as canonical MathJSON literals.
 */
function stripMeta(node: unknown): MathJsonExpression {
  return stripMetaRaw(node) as MathJsonExpression;
}

/** {@link stripMeta} returning raw MathJSON via the untyped {@link stripMetaRaw} walk. */
function stripMetaRaw(node: unknown): unknown {
  if (
    typeof node === "string" ||
    typeof node === "number" ||
    typeof node === "boolean"
  )
    return node;
  if (Array.isArray(node)) return node.map(stripMetaRaw);
  if (node && typeof node === "object") {
    const obj = node as Record<string, unknown>;
    if (Array.isArray(obj.fn)) return obj.fn.map(stripMetaRaw);
    if (typeof obj.sym === "string") return obj.sym;
    if (typeof obj.num === "string") return { num: obj.num };
    if (typeof obj.str === "string") return { str: obj.str };
    // A dictionary/other object-literal MathJSON node — keep it minus metadata.
    const rest: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj))
      if (k !== "sourceOffsets") rest[k] = stripMetaRaw(v);
    return rest;
  }
  return "Nothing";
}

/** A `let`'s RHS is buried in `["Declare", target, ["Dictionary", ["KeyValuePair", "value", <rhs>]]]` — dig it out. */
function declareRhs(valuePart: unknown): unknown {
  const f = asFn(valuePart);
  if (f?.head !== "Dictionary") return valuePart;
  for (const kv of f.args) {
    const kvf = asFn(kv);
    if (kvf?.head === "KeyValuePair") {
      const key = asSym(kvf.args[0]);
      if (key?.name === "value") return kvf.args[1];
    }
  }
  return valuePart;
}

/** The operands of a parsed Program; accept the legacy Block container too. */
function topLevelStatements(program: unknown): unknown[] {
  const f = asFn(program);
  if (f?.head === "Program" || f?.head === "Block") return f.args;
  if (program == null || program === "Nothing") return [];
  return [program];
}

/** Push one occurrence's offsets into the per-name list. */
function pushOffset(
  map: Map<string, [number, number][]>,
  name: string,
  offsets: Offsets,
): void {
  const list = map.get(name);
  if (list) list.push([offsets[0], offsets[1]]);
  else map.set(name, [[offsets[0], offsets[1]]]);
}

/**
 * Occurrence-sensitive reference walk (§4): collects free reference candidates
 * (`refs`) and every non-param-shadowed symbol occurrence's source offsets
 * (`offsets`, for the §3.4 rename splice). Assignment/declaration TARGET
 * occurrences are excluded from `refs` (the write site) but ARE recorded in
 * `offsets` (rename rewrites the define site too); RHS reads survive as references
 * (`a = a + 1` references the outer `a`). Function parameters are scoped out within
 * the body — excluded from both. Structural heads are dropped.
 */
function walkRefs(
  node: unknown,
  excluded: ReadonlySet<string>,
  refs: Set<string>,
  offsets: Map<string, [number, number][]>,
  topRefs: Set<string>,
  inFunction: boolean,
): void {
  const sym = asSym(node);
  if (sym) {
    if (
      !excluded.has(sym.name) &&
      !STRUCTURAL_HEADS.has(sym.name) &&
      !IGNORED_SYMBOLS.has(sym.name)
    ) {
      refs.add(sym.name);
      if (!inFunction) topRefs.add(sym.name);
      if (sym.offsets) pushOffset(offsets, sym.name, sym.offsets);
    }
    return;
  }
  const f = asFn(node);
  if (!f) return;
  const { head, args } = f;

  if (head === "Assign" || head === "DefineFunction") {
    // args[0] is the write target: not a reference, but its occurrence is renameable.
    // (`DefineFunction` is the head CE 0.100.0 lowers `function f(…) {…}` sugar to,
    // replacing the `["Assign", f, ["Function", …]]` shape ≤0.99 emitted — see the
    // multi-clause dispatch feature. Both are top-level writes of a name.)
    recordTargetOffset(args[0], excluded, offsets);
    for (let i = 1; i < args.length; i++)
      walkRefs(args[i], excluded, refs, offsets, topRefs, inFunction);
    return;
  }
  if (head === "Declare") {
    // `let` target is a write (renameable); its RHS reads the OUTER scope.
    recordTargetOffset(args[0], excluded, offsets);
    walkRefs(declareRhs(args[1]), excluded, refs, offsets, topRefs, inFunction);
    return;
  }
  if (head === "Function") {
    // args[0] = body, args[1..] = params — scope params out within the body. Body
    // reads are function-body reads (late-binding), never top-level. A parameter
    // is either a bare symbol or an annotated/literal clause parameter
    // `["Typed", name, {str: type}]` (clause dispatch, CE 0.100+) — scope out
    // the NAME in both shapes so a typed parameter's body occurrences neither
    // wire spurious edges nor get spliced by a same-named cell rename.
    const params = new Set(excluded);
    for (let i = 1; i < args.length; i++) {
      const p = asSym(args[i]);
      if (p) {
        params.add(p.name);
        continue;
      }
      const tf = asFn(args[i]);
      if (tf?.head === "Typed") {
        const tp = asSym(tf.args[0]);
        if (tp) params.add(tp.name);
      }
    }
    walkRefs(args[0], params, refs, offsets, topRefs, true);
    return;
  }

  // A generic application: the head is itself a call reference (`f(2)` → `f`) unless
  // structural or a scoped-out param.
  if (!STRUCTURAL_HEADS.has(head) && !excluded.has(head)) {
    refs.add(head);
    if (!inFunction) topRefs.add(head);
  }
  for (const a of args)
    walkRefs(a, excluded, refs, offsets, topRefs, inFunction);
}

/** Record a define/assign target symbol's offset for rename (never a param-shadowed name). */
function recordTargetOffset(
  target: unknown,
  excluded: ReadonlySet<string>,
  offsets: Map<string, [number, number][]>,
): void {
  const t = asSym(target);
  if (t?.offsets && !excluded.has(t.name))
    pushOffset(offsets, t.name, t.offsets);
}

/** Collect every `Assign` target name at ANY depth (the §2 ①b pre-seed list). */
function collectAssignedNames(node: unknown, acc: Set<string>): void {
  const f = asFn(node);
  if (!f) return;
  if (f.head === "Assign" || f.head === "DefineFunction") {
    const t = asSym(f.args[0]);
    if (t) acc.add(t.name);
  }
  for (const a of f.args) collectAssignedNames(a, acc);
}

/**
 * Whether the program's LAST top-level statement is a definition (`Assign`/`Declare`)
 * — drives the §5 `renderState: "definition"` vs `"value"` distinction. Empty
 * source, or a source with a `#error` directive (it makes the parser throw),
 * → `false`. A source with a syntax error is judged on the
 * statements the parser recovered before the error: `a = 1 +` → `true`.
 */
export function lastStatementIsDefinition(source: string): boolean {
  if (!source.trim()) return false;
  let program: unknown;
  try {
    [program] = parseCortex(source);
  } catch {
    return false;
  }
  const statements = topLevelStatements(program);
  const last = statements[statements.length - 1];
  const f = asFn(last);
  return (
    !!f &&
    (f.head === "Assign" || f.head === "Declare" || f.head === "DefineFunction")
  );
}

/**
 * Rename every non-param-shadowed occurrence of `oldName` to `newName` in Cortex
 * `source` (§3.4). A pure text splice over the analyzer's `symbolOffsets`
 * (define sites + reads; strings/comments untouched by construction, function
 * params scoped out by the §4 walk). Splices from the END so earlier offsets stay
 * valid. No occurrences, or a `#error` directive (the parser throws) → `source`
 * returned UNCHANGED. Same name → unchanged.
 *
 * A syntax error does NOT block the rename. The parser recovers: it keeps the
 * statements before the error and reports the error as a diagnostic, so a
 * half-typed cell still follows a slider rename: `a = = 3` → `b = = 3`. Only
 * the occurrences in the recovered part are renamed; an occurrence after the
 * error point is not seen and stays as written: `a = 3\nb = = a` →
 * `b = 3\nb = = a`.
 */
export function rewriteCortexSource(
  source: string,
  oldName: string,
  newName: string,
): string {
  if (oldName === newName || !source.trim()) return source;
  const offsets = analyzeCortex(source).symbolOffsets.get(oldName);
  if (!offsets || offsets.length === 0) return source;
  // Descending by start so each splice leaves the not-yet-rewritten prefix intact.
  const ordered = [...offsets].sort((a, b) => b[0] - a[0]);
  let out = source;
  for (const [start, end] of ordered)
    out = out.slice(0, start) + newName + out.slice(end);
  return out;
}

/**
 * Parse-only analysis of a Cortex program (§3/§4). Returns empty analysis for
 * empty/whitespace source. Never throws (a `#error` FatalParsingError is swallowed
 * to an empty analysis — the executor surfaces it as a diagnostic). A syntax
 * error does not throw: the parser recovers, and the analysis covers only the
 * statements before the error (`a = 3\nb = = a` defines `a` and sees no read
 * of `a`).
 */
export function analyzeCortex(source: string): CortexAnalysis {
  const empty: CortexAnalysis = {
    defines: [],
    functionDefines: [],
    referenceCandidates: [],
    readCandidates: [],
    functionSnapshots: new Map(),
    symbolOffsets: new Map(),
    assignedNames: [],
    declaredNames: [],
  };
  if (!source.trim()) return empty;

  let program: unknown;
  try {
    [program] = parseCortex(source);
  } catch {
    return empty;
  }

  const statements = topLevelStatements(program);

  // ── Top-level defines / functionDefines / functionSnapshots. `DefineFunction`
  //    statements ACCUMULATE as clause SETS per name (D-207, ruled 2026-08-02:
  //    `f(0)=1; f(1)=1; f(n)=…` is three clauses of ONE function — last-wins
  //    silently dropped the base cases). Clause order is program order.
  //    Snapshot semantics mirror the ENGINE's, probe-measured on CE 0.109.0
  //    (the implementation-time probe):
  //    - `DefineFunction` (`f(0) = 1` / `function f(…) {…}`) ADDS a clause —
  //      including onto a previously Assign-bound lambda (`h = (n)=>2` then
  //      `h(0)=7` gives h(0)=7, h(5)=2);
  //    - `Assign`/`Declare` of a Function RHS (`g = (n) => 2`) REPLACES the
  //      whole definition (`g(0)=7` then the assign gives g(0)=2);
  //    - a non-Function RHS supersedes the set entirely (value define).
  //    Same-parameter-domain duplicates need no handling here: CE 0.109.0
  //    errors the cell itself (`function-redefinition`), so a snapshotted set
  //    always has distinct domains — and clause identity is the engine's
  //    `sameParameterDomain` (mutual subtyping of parameter TYPES), never
  //    parameter text, which is exactly why this walk must never try to
  //    compare clauses itself. ──
  const defineOrder: string[] = [];
  const defineSeen = new Set<string>();
  const fnClauses = new Map<string, MathJsonExpression[]>();
  const letNames = new Set<string>();
  const noteDefine = (
    name: string,
    fnRhs: unknown | null,
    mode: "add-clause" | "replace",
  ): void => {
    if (!defineSeen.has(name)) {
      defineSeen.add(name);
      defineOrder.push(name);
    }
    if (fnRhs === null) {
      // Last definition of this name is a value — prior clauses are superseded.
      fnClauses.delete(name);
    } else if (mode === "replace") {
      fnClauses.set(name, [stripMeta(fnRhs)]);
    } else {
      const clauses = fnClauses.get(name);
      if (clauses) clauses.push(stripMeta(fnRhs));
      else fnClauses.set(name, [stripMeta(fnRhs)]);
    }
  };
  const functionRhs = (rhs: unknown): unknown | null => {
    const rf = asFn(rhs);
    return rf?.head === "Function" ? rhs : null;
  };
  for (const stmt of statements) {
    const f = asFn(stmt);
    if (!f) continue;
    if (f.head === "DefineFunction") {
      const t = asSym(f.args[0]);
      if (t) noteDefine(t.name, functionRhs(f.args[1]), "add-clause");
    } else if (f.head === "Assign") {
      const t = asSym(f.args[0]);
      if (t) noteDefine(t.name, functionRhs(f.args[1]), "replace");
    } else if (f.head === "Declare") {
      const t = asSym(f.args[0]);
      if (t) {
        noteDefine(t.name, functionRhs(declareRhs(f.args[1])), "replace");
        letNames.add(t.name);
      }
    }
  }

  // ── References + offsets (whole program, occurrence-sensitive). `refs` excludes
  //    write targets; `symbolOffsets` includes them (rename rewrites the define site). ──
  const refs = new Set<string>();
  const topRefs = new Set<string>();
  const symbolOffsets = new Map<string, [number, number][]>();
  walkRefs(program, new Set(), refs, symbolOffsets, topRefs, false);

  // ── AssignedNames at any depth (containment pre-seed list). ──
  const assigned = new Set<string>();
  collectAssignedNames(program, assigned);

  return {
    defines: defineOrder,
    functionDefines: [...fnClauses.keys()],
    referenceCandidates: [...refs],
    readCandidates: [...topRefs],
    functionSnapshots: fnClauses,
    symbolOffsets,
    assignedNames: [...assigned],
    declaredNames: [...letNames],
  };
}
