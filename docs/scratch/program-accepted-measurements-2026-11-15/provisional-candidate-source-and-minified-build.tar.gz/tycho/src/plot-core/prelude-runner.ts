/**
 * The runner of an Epsil prelude (ROADMAP row FG, `requirements/archive/EPSIL_PRELUDE.md`
 * §§ 3.2, 3.3, 4.1 to 4.4 and 4.9).
 *
 * {@link runPrelude} validates ONE Epsil program, runs it on the engine that
 * the caller gives, and returns what a caller needs to replay the result on
 * another engine: the diagnostics, the top-level names, each function as its
 * resolved `DefineFunction` statement, and each value as MathJSON with its
 * type. The engine is changed: the functions are defined on it and the values
 * are assigned on it, also when the text is invalid, and the runner never
 * removes them. So each call needs an engine that no earlier run has used and
 * that holds only the document settings (angle unit, precision, complex
 * mode): a second run on the same engine would see the names of the first.
 *
 * The steps, in order. A step that gives an error stops the run, because a
 * later step needs the result of the earlier one; every diagnostic of that
 * step is reported. Warnings never stop the run.
 *
 * 1. Size: a text of more than {@link PRELUDE_MAX_SOURCE_BYTES} UTF-8 bytes.
 * 2. Parse (`parseEpsil`), then `resolveLibraryNames` on the tree, so `max`
 *    becomes `Max` and `random` becomes `Random`.
 * 3. The static check of the engine (`checkEpsil`): type errors, a second
 *    declaration of a name, an assignment to a name that no `let` declares
 *    (`assignment-to-undeclared-variable`, with a fix that adds `let`), and a
 *    direct read of a name before the statement that declares it (given as
 *    `read-before-definition` at the read, the code of step 8b). Its
 *    warnings (`equation-not-assignment`) are kept.
 * 4. Classification of each top-level statement as a function, a value
 *    statement or an expression statement. An expression statement does not
 *    run and gets a warning.
 * 5. Names: a reserved plot name, the ticker's `dt`, and a library name are
 *    refused at the definition.
 * 6. Self-containment: a free name (not a prelude name, not a library name)
 *    is refused at its first occurrence.
 * 7. Function bodies: a function that assigns a top-level name, that has the
 *    `scope` specifier (`function f(p) scope { … }`, which writes to the
 *    scope of its caller), or that names a random operator, is refused.
 * 8. A random operator in a value statement is refused. Rules 7 and 8 refuse
 *    a random-family name in any role: a call, a read, or a function given
 *    to `Apply` or `map` (`Apply(Random)`).
 * 8b. Order: a value statement that reads a top-level value whose first
 *    definition comes later in the program, directly or through the
 *    functions it calls, is refused at the read or the call (§ 4.1: the
 *    values run in program order). A function name is exempt, because the
 *    functions are defined before the first value statement runs.
 * 9. Run: the functions are defined first, then each value statement runs in
 *    order, compiled to JavaScript when it can be, else on the interpreter.
 *    One kind of value statement runs before the functions, in program
 *    order: a top-level `const` whose value is a literal (a number, possibly
 *    negative, a string, a boolean). A default parameter value can name a
 *    constant (`function f(k = c)`), and the engine requires the symbol to
 *    be declared constant when the function is installed. A literal has no
 *    dependency, so the results do not change; `statements` stays in
 *    program order.
 * 10. Element cap: a value with more than `maxElements` elements (counted over
 *    nested lists and tuples) is refused. Then a function that reads a
 *    top-level value that is not a number or a boolean is refused at the read
 *    (the type is known only after the run).
 *
 * **The scope-aware walker.** One walker ({@link walkNode}) reads the MathJSON
 * of a statement with the scopes of Epsil, and serves steps 4, 6, 7, 8 and the
 * rewrite of step 9. It calls a visitor for each symbol, with the role of the
 * symbol (a read, a call head, an assignment target, a declaration, a
 * parameter) and the scope frame that binds it (the top-level frame for a
 * prelude name, a local frame, or none for a free name). It never reads a
 * string literal (`{str}`, or a `'…'` string) or the key of a `KeyValuePair`
 * (`{n: 1}` and the `value` key of a `Declare`) as a name. The shapes it
 * handles, as the parser of CE 0.182.0 gives them (probed on 2026-11-06):
 *
 * - The program is `Program(...)`, including empty and single-statement source.
 * - `let a = v` and `const a = v`: `Declare(a, Dictionary(KeyValuePair(value,
 *   v)))`; `const` adds `KeyValuePair(constant, True)`; `let a: T = v` puts
 *   `{str: T}` before the dictionary. The value is read before the name is
 *   bound, except for a lambda value, whose name is bound first.
 * - `let (a, b) = v`: `Declare(Tuple(a, b), …)`. Each name of the pattern is
 *   bound, except the wildcard `_` (`let (_, a) = v`), which binds nothing
 *   and is not a top-level name.
 * - `x1 = 1`: `Assign(x1, 1)`. It writes the variable that a scope declares;
 *   it never makes one. An assignment to a name that no scope declares is the
 *   engine's error `assignment-to-undeclared-variable` (step 3), at the top
 *   level and in a block alike.
 * - `L[2] = 5`: `Assign(L, ReplaceAt(L, 2, 5))`, an assignment of `L`.
 * - `function f(p) {…}` and `f(p) = …`: `DefineFunction(f, Function(body,
 *   p))`. A parameter is a symbol or `Typed(p, {str: T})`; a rest parameter
 *   (`...args`) is `Spread(args)`, which binds `args`; with a default value
 *   (`n: number = 2`) it is `Optional(p, 2)` around one of these;
 *   the default is read in the enclosing scope when the function is called,
 *   so the checks of function bodies apply to it. The body can be
 *   `Typed(body, {str: T})`: `T` is the result type (`-> integer` gives
 *   `"integer"`), or, when the function has a specifier, the whole signature
 *   (`function f(p) scope {…}` gives `"(p: unknown) scope -> unknown"`).
 *   `hold f(e) = …` adds a third operand, `Dictionary(KeyValuePair(hold,
 *   True))`. The name is bound before the body is read, so a recursion
 *   resolves to the function. A function statement in a block is a local of
 *   the block from that statement on, as a `let` is: it is not hoisted, and
 *   the engine reports a call before it (step 3).
 * - A lambda `c => …`: `Function(body, c)`, a function scope.
 * - `for k in 1..n {…}`: `Loop(Block(…), Element(k, Range(1, n)))`; `for (p,
 *   q) in L {…}` has `Element(Tuple(p, q), L)`. The collection is read in the
 *   enclosing scope, the pattern names are bound for the body.
 * - `while c {…}`: `Loop(Block(If(Not(c), Break), Block(…)))`, no binder.
 * - `[k^2 for k in 1..3]`: `Comprehension(body, Element(k, …))`, as a loop.
 * - `sum(k^2, k, 1, 3)`: `Sum(body, k, 1, 3)`. A call of a library operator
 *   can bind variables (`Sum`, `Product`, `Integrate`, `D`, `Limit`,
 *   `Solve`, the quantifiers). The engine's `binderSitesOf()` gives, for
 *   each variable, the operands that see it, with the rules the engine
 *   itself applies; each of those operands is walked with a frame that
 *   binds the variable, and every other name is a read (`sum(k, k, 1, n)`
 *   binds `k` in all four operands and reads `n`; `sum(k^2, {k, 1, 3})`
 *   binds `k` in the body and in the `Set`). `binderSitesOf()` does not see
 *   the bindings of the program, so a call whose callee the program defines
 *   (`function D(p, q)`) is a call of that function, and its operands are
 *   reads.
 *
 *   `D` and `Limit` keep a rule of their own, because `binderSitesOf()`
 *   binds the order of a derivative (`D(x^n, {x, n})` binds `n`, so a free
 *   `n` is not reported), and gives no site when the body does not hold the
 *   variable (`limit(5, h, 0)`, which the engine evaluates to 5). `D` binds
 *   each bare symbol operand after the body (`D(f, x, y)`) and the first
 *   element of each brace operand (`D(f, {x, 2})`), in the body and in that
 *   operand; the other elements of a brace operand are reads. `Limit` with a
 *   variable operand binds the symbol of its second operand
 *   (`Limit(f, h, 0)`), or the first operand of an index form there
 *   (`limit(f, (h, 0))`, a `Tuple`), in the body and in that operand.
 *
 *   Two forms keep a rule of their own, because the engine chooses their
 *   variable from the body and `binderSitesOf()` gives that choice:
 *   - `Limit(body, point)` has no variable operand. The candidates are the
 *     names of the body that no scope binds, without the library names and
 *     the random-family names. When there is exactly one candidate, the
 *     limit binds it; when there are more, it binds none, so that step 6
 *     reports each of them as a free name (`limit(x^2 + d, 0)`). The engine
 *     instead takes the first candidate in sorted order (`d`), and step 6
 *     would then report only `x`. The point is read in the enclosing scope.
 *   - `NLimit`, `ND` and `NIntegrate` take a function or an expression and
 *     points. They bind nothing here, so each name of an expression operand
 *     is a read (`nIntegrate(sin(x), 0, 1)` reports `x`), for the same
 *     reason: when the body has several free names, the engine's choice is
 *     the first in sorted order.
 * - `match s { (a, b) if g => e; _ => 0 }`: `Match(s, MatchCase(Tuple(_a,
 *   _b), g, e), MatchCase(_, 0))`. A symbol `_a` of a pattern binds `a` for
 *   the guard and the body; `_` binds nothing; any other symbol of a pattern
 *   is a read.
 * - `{ s = 1 }` at top level is a `Set` literal, not a block (an expression
 *   statement).
 *
 * **The value route** (§ 4.3). Each value statement is compiled to JavaScript
 * as a `Block`: each top-level name that the statement assigns and that
 * already has a value becomes a typed input, declared with no value in a
 * pushed scope, which a fresh local copies; the reads and writes of that name
 * in the statement go to the local; the last statement of the block is the
 * `Tuple` of the locals and of the names the statement declares. A name that
 * the statement only reads stays an engine value, and a function is never
 * declared as an input. The rewrite renames the name only where it resolves
 * to the top-level binding: a local that has the same name, and a string
 * that spells it, are not changed. The compiled result is re-boxed from the
 * static type of each tuple element (numbers as float64 with the non-finite
 * values kept, booleans, and lists and tuples of those at any depth) and
 * bound on the engine before the next statement compiles. A compile that
 * declines, a type that the compiled code cannot carry (a string, a complex
 * number, a dictionary, an exact rational) and a result that does not match
 * its type run the statement on the interpreter instead.
 *
 * **The worker pool.** {@link runPrelude} runs each compiled value statement
 * with `runAsync()` of the compiled result (Compute Engine 0.185.0) and
 * awaits it; a result that has no `runAsync` runs with `run()`. When the
 * engine has a worker pool (`ce.workers`), `runAsync()` sends each
 * `parallel for` that can run on the pool to the workers, one range of
 * consecutive passes for each worker, and adds the sums of the ranges to the
 * accumulators; every other statement runs as with `run()`, on this thread.
 * The engine's rules for such a loop are in the document COMPILATION-MODEL
 * of the Compute Engine repository, section "The worker pool and
 * `parallel for`: `runAsync()`". For example, the
 * statement `const H_1 = step(H_0, 1200000)` of the `buddhabrot` showcase
 * entry, whose `step` holds a `parallel for` over the samples, runs on the
 * pool of the prelude worker (`src/graph-paper/graph/prelude/prelude-worker.ts`).
 * A compile with a pass counter (`iterationBudget` other than `Infinity`)
 * keeps each loop on this thread, because the workers cannot share one
 * counter. {@link runPreludeLoaded} has no `await` and always uses `run()`.
 * Both share one sequence of steps ({@link preludeSteps}): it yields each
 * compiled run, and the caller runs it in its own way.
 *
 * Library names. Rule 5 refuses four kinds of name:
 *
 * - one of Tycho's standard aliases (`total`, `sort`, `unique`, `stdev`;
 *   `ce-aliases.ts`), which the document engine binds as operators. This
 *   test runs before the static check (step 2b), because the check runs on
 *   that engine and would report the redeclaration as a type error;
 * - a constant that a fresh engine binds (`e`, `Pi`, `i`);
 * - an operator name of more than one letter that a fresh engine binds
 *   (`Max`, `Fill`). A single letter (`D`, `N`) is admitted, because a
 *   document row may also name a value `D` or `N` (the declaration shadows
 *   the operator; see the variable-cell declarations in
 *   `src/graph-paper/graph/document-ce-manager.ts`);
 * - an Epsil spelling of a library operator that a row would read as that
 *   operator: the LaTeX of the symbol, parsed on a fresh engine, gives a
 *   library name (`max` gives `Max`, `sin` gives `Sin`).
 *
 * A spelling such as `fill`, `count` or `fract` is a plain symbol in a row
 * (`\operatorname{fill}` stays `fill`), so it is admitted, although
 * `canonicalLibraryName` maps it to an operator. The gasket program
 * (`scripts/repros/2026-09-28-epsil-gasket-compile/e-natural-recursion.epsil`)
 * defines `fill` and `D`.
 *
 * The Epsil entry of the engine is imported lazily (see {@link loadEpsil}),
 * so a bundle that imports this module and never runs a prelude does not load
 * the Epsil parser.
 *
 * @module plot-core/prelude-runner
 */

import type {
  ComputeEngine,
  Expression,
  MathJsonExpression,
} from "@cortex-js/compute-engine";
import type { CheckEpsilResult } from "@cortex-js/compute-engine/epsil";
import {
  isReservedCallHeadName,
  isReservedVariableName,
} from "./classification-names.js";
import {
  isFunction,
  isNumber,
  isSymbol,
  RANDOM_HEADS,
} from "./ce-type-guards.js";
import { withIterationLimit } from "./ce-deadline.js";
import { EXTENDED_REAL_TYPE } from "./ce-types.js";
import {
  resolveCECompile,
  resolveComputeEngineCtor,
} from "./ce-module-registry.js";
import { isStandardAliasName } from "./ce-aliases.js";

/** The largest prelude text, in UTF-8 bytes (§ 3.2 rule 1). */
export const PRELUDE_MAX_SOURCE_BYTES = 65_536;

/**
 * The largest number of loop passes that the compiled code of ONE value
 * statement makes when the prelude runs on the calling thread (a bare plot
 * element, the in-process check service): compiled code cannot be stopped
 * from outside, so this count is the only bound of such a run. Over it the
 * compiled code throws a `CancellationError`, and the statement gets a
 * diagnostic. The prelude worker of a Graph Paper document passes
 * `iterationBudget: Infinity` instead (no count: the page terminates the
 * worker at its deadline, `PRELUDE_CHECK_DEADLINE_MS` in
 * `src/graph-paper/graph/prelude/prelude-check.ts`).
 *
 * Sized on the `buddhabrot` showcase entry, whose prelude computes 1.2
 * million samples in one statement, about 28 million passes, in 0.45 to
 * 0.52 s (Node 26, Apple M5 Max at a load average of about 20, 2026-11-08,
 * `scripts/repros/2026-11-08-buddhabrot-loop-probe.mts`). A cheap endless
 * loop (`while true { s = s + 1 }`) reaches 10 million passes in about 200
 * to 300 ms, so this budget stops it after a few seconds.
 */
export const PRELUDE_ITERATION_BUDGET = 100_000_000;

/**
 * The largest number of elements of one value, counted over nested lists and
 * tuples (each element of a list or tuple counts, at every depth). Same number
 * as `FIRING_MAX_ELEMENTS` in `src/graph-paper/actions/firing.ts`; plot-core
 * cannot import graph-paper, so a caller can pass its own number in
 * {@link PreludeRunOptions.maxElements}.
 */
export const PRELUDE_MAX_ELEMENTS = 484_000;

export interface PreludeDiagnostic {
  severity: "error" | "warning";
  /** An Epsil diagnostic code (`static-type-error`, …) or a runner code
   *  (`reserved-name`, `free-name`, …). */
  code: string;
  message: string;
  /** Offsets into the source text, end excluded. */
  range: [start: number, end: number];
  notes?: { message: string; range?: [number, number] }[];
  /** A fix in one step: each edit replaces the text of its range (an empty
   *  range inserts). An `assignment-to-undeclared-variable` gets the fix
   *  that writes `let ` before the first assignment of the name. */
  fix?: PreludeFix;
}

export interface PreludeFix {
  /** The label of the fix, for a menu or a button. */
  title: string;
  edits: { range: [start: number, end: number]; text: string }[];
}

export interface PreludeFunction {
  name: string;
  params: readonly string[];
  /** The body, without the `Typed` wrapper of a result type or a
   *  specifier. */
  bodyJson: MathJsonExpression;
  /** The result type of the annotation (`-> integer` gives `integer`), when
   *  the function has one. */
  resultType?: string;
  /** The resolved `DefineFunction` statement, with all its operands (a
   *  `hold` attribute dictionary is kept), which
   *  `ce.box(definitionJson).evaluate()` replays on another engine. A
   *  top-level lambda (`let g = c => c + 1`) is given as the
   *  `DefineFunction` of its `Function`; a type annotation on the `let` is
   *  not kept. */
  definitionJson: MathJsonExpression;
  /** `true` when the function calls itself, directly or through other
   *  prelude functions (`f` calls `g`, which calls `f`). */
  recursive: boolean;
}

export interface PreludeValue {
  name: string;
  json: MathJsonExpression;
  type: string;
  /** The route of the last statement that wrote the value. */
  route: "compiled" | "interpreted";
  /** `true` for a `const`. */
  constant: boolean;
  /** The type annotation of the `let` or `const`, when there is one. */
  declaredType?: string;
}

/** What happened to one value statement. */
export interface PreludeStatementRun {
  /** The top-level names the statement declares or assigns. */
  names: string[];
  range: [number, number];
  route: "compiled" | "interpreted";
  compileMs: number;
  runMs: number;
  /** Why the compiled route was not used, for a statement that ran on the
   *  interpreter. */
  declineReason?: string;
  /** Each run of a `parallel for` of the statement that could run on the
   *  worker pool, in the order of the runs, as `runAsync()` reports it
   *  (`onLoop`). Absent when there is none, and always absent from
   *  {@link runPreludeLoaded}, which does not use `runAsync()`. */
  parallelLoops?: PreludeParallelLoop[];
}

/** One run of a `parallel for` loop under `runAsync()`: its count of passes,
 *  and where it ran. `reason` tells why a loop ran on the calling thread
 *  (`'no-pool'`, `'below-threshold'`, `'too-large'`, `'pool-declined'`,
 *  `'pool-unusable'`). Plain data, so that it crosses the boundary of the
 *  prelude worker. */
export interface PreludeParallelLoop {
  passes: number;
  route: "pool" | "calling-thread";
  reason?: string;
}

/**
 * A run of a compiled value statement that {@link preludeSteps} yields to its
 * caller: the caller calls `result.run(inputs)` (no `await`) or awaits
 * `result.runAsync(inputs)`, and resumes the steps with the value, or throws
 * the error of the run into them. The asynchronous caller appends each loop
 * report of `runAsync()` to `loops`.
 */
interface CompiledRunRequest {
  result: {
    run: (inputs: Record<string, unknown>) => unknown;
    runAsync?: (
      inputs: Record<string, unknown>,
      options?: { onLoop?: (report: PreludeParallelLoop) => void },
    ) => Promise<unknown>;
  };
  inputs: Record<string, unknown>;
  loops: PreludeParallelLoop[];
}

/** The steps of a prelude run, which yield each compiled run. */
type PreludeSteps<T> = Generator<CompiledRunRequest, T, unknown>;

export interface PreludeTimings {
  parseMs: number;
  checkMs: number;
  compileMs: number;
  runMs: number;
  totalMs: number;
}

export interface PreludeRunResult {
  valid: boolean;
  diagnostics: PreludeDiagnostic[];
  /** Every top-level name in source order, as written. */
  names: string[];
  functions: PreludeFunction[];
  values: PreludeValue[];
  /** One entry for each value statement that ran, in program order. */
  statements: PreludeStatementRun[];
  timings: PreludeTimings;
}

export interface PreludeRunOptions {
  maxElements?: number;
  /** The loop passes that one compiled value statement may make; the
   *  default is {@link PRELUDE_ITERATION_BUDGET}. `Infinity` compiles the
   *  statements with no pass counter, for a caller that another bound stops
   *  (a worker with a deadline). */
  iterationBudget?: number;
}

type EpsilModule = typeof import("@cortex-js/compute-engine/epsil");

/** The clock of the timings. */
function now(): number {
  return globalThis.performance.now();
}

let epsilModule: Promise<EpsilModule> | undefined;
/** The Epsil entry once its import resolved, for {@link runPreludeLoaded}. */
let loadedEpsilModule: EpsilModule | undefined;

/**
 * The Epsil entry of the engine, imported on the first call and cached. A
 * failed import is not cached, so a later call tries again.
 */
function loadEpsil(): Promise<EpsilModule> {
  epsilModule ??= import("@cortex-js/compute-engine/epsil").then(
    (module) => {
      loadedEpsilModule = module;
      return module;
    },
    (error: unknown) => {
      epsilModule = undefined;
      throw error;
    },
  );
  return epsilModule;
}

/**
 * Import the Epsil entry of the engine, which {@link runPreludeLoaded} needs.
 * A caller that must run a prelude with no `await` (inside a step budget of
 * the engine, which accepts only a synchronous function) waits for this
 * first.
 */
export async function loadPreludeParser(): Promise<void> {
  await loadEpsil();
}

// ---------------------------------------------------------------------------
// MathJSON access. The parser gives `{fn: [head, ...ops], sourceOffsets}`,
// `{sym}`, `{num}` and `{str}` objects; a head is a plain string. The helpers
// also accept the compact forms (arrays and plain strings), which a rewrite
// builds.

type Json = unknown;

function fnOf(node: Json): readonly Json[] | undefined {
  if (Array.isArray(node)) return node;
  if (node !== null && typeof node === "object") {
    const fn = (node as { fn?: unknown }).fn;
    if (Array.isArray(fn)) return fn;
  }
  return undefined;
}

/** The name of a symbol node, or `undefined` for anything else. A plain
 *  string in quotes is a string literal, not a symbol. */
function symbolOf(node: Json): string | undefined {
  if (typeof node === "string") return node.startsWith("'") ? undefined : node;
  if (node !== null && typeof node === "object" && !Array.isArray(node)) {
    const sym = (node as { sym?: unknown }).sym;
    if (typeof sym === "string") return sym;
  }
  return undefined;
}

function headOf(node: Json): string | undefined {
  const fn = fnOf(node);
  if (fn === undefined) return undefined;
  return typeof fn[0] === "string" ? fn[0] : symbolOf(fn[0]);
}

function opsOf(node: Json): readonly Json[] {
  return fnOf(node)?.slice(1) ?? [];
}

function offsetsOf(node: Json): [number, number] | undefined {
  if (node !== null && typeof node === "object" && !Array.isArray(node)) {
    const o = (node as { sourceOffsets?: unknown }).sourceOffsets;
    if (
      Array.isArray(o) &&
      typeof o[0] === "number" &&
      typeof o[1] === "number"
    )
      return [o[0], o[1]];
  }
  return undefined;
}

/** A function node with new operands, in the form of the original node. */
function withFn(node: Json, fn: readonly Json[]): Json {
  if (Array.isArray(node)) return fn;
  return { ...(node as object), fn };
}

function withSymbol(node: Json, name: string | undefined): Json {
  if (name === undefined || name === symbolOf(node)) return node;
  if (typeof node === "string") return name;
  return { ...(node as object), sym: name };
}

/** A deep copy without the `sourceOffsets` keys, for the JSON the runner
 *  returns. */
function stripOffsets(node: Json): MathJsonExpression {
  if (Array.isArray(node))
    return node.map(stripOffsets) as unknown as MathJsonExpression;
  if (node !== null && typeof node === "object") {
    const out: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(node))
      if (key !== "sourceOffsets") out[key] = stripOffsets(value);
    return out as MathJsonExpression;
  }
  return node as MathJsonExpression;
}

/** The value operand of `Dictionary(KeyValuePair(key, value), …)`. */
function dictionaryEntry(node: Json, key: string): Json | undefined {
  if (headOf(node) !== "Dictionary") return undefined;
  for (const pair of opsOf(node)) {
    if (headOf(pair) !== "KeyValuePair") continue;
    const [k, v] = opsOf(pair);
    if (symbolOf(k) === key || (k as { str?: unknown })?.str === key) return v;
  }
  return undefined;
}

/** The parts of a `Declare` statement: the target, the type annotation, the
 *  value and the `constant` flag. */
function declareParts(node: Json): {
  target: Json;
  declaredType: string | undefined;
  value: Json | undefined;
  constant: boolean;
} {
  const [target, ...rest] = opsOf(node);
  let declaredType: string | undefined;
  let value: Json | undefined;
  let constant = false;
  for (const op of rest) {
    const str = (op as { str?: unknown } | null)?.str;
    if (typeof str === "string") declaredType = str;
    else if (headOf(op) === "Dictionary") {
      value = dictionaryEntry(op, "value");
      constant = symbolOf(dictionaryEntry(op, "constant")) === "True";
    }
  }
  return { target, declaredType, value, constant };
}

/** The symbol nodes a binding pattern binds: a symbol, `Typed(p, T)`, a rest
 *  parameter `Spread(p)` (`...args`), or a `Tuple` or `List` of patterns. The
 *  wildcard `_` (`let (_, a) = …`) binds nothing. */
function patternSymbols(node: Json): Json[] {
  const name = symbolOf(node);
  if (name !== undefined) return name === "_" ? [] : [node];
  const head = headOf(node);
  if (head === "Typed" || head === "Spread")
    return patternSymbols(opsOf(node)[0]);
  if (head === "Tuple" || head === "List" || head === "Sequence")
    return opsOf(node).flatMap(patternSymbols);
  return [];
}

// ---------------------------------------------------------------------------
// The scope-aware walker.

type SymbolRole = "read" | "call" | "assign" | "declare" | "param";

interface Frame {
  readonly kind: "top" | "function" | "block" | "binder";
  readonly names: Set<string>;
}

interface SymbolSite {
  readonly name: string;
  readonly role: SymbolRole;
  /** The symbol node, or the call node for a `call`. */
  readonly node: Json;
  /** The enclosing function node (the `Assign` of an `assign`). */
  readonly parent: Json;
  /** The frame that binds the name, or `undefined` for a free name. */
  readonly binding: Frame | undefined;
  /** The frames of the scopes around the site, outermost first; the last
   *  one is the frame that a `let` at the site would declare in. */
  readonly frames: readonly Frame[];
  /** Whether the site is inside a function body (a `Function` node). */
  readonly inFunction: boolean;
}

/** Returns a new name for the symbol, or `undefined` to keep it. */
type SymbolVisitor = (site: SymbolSite) => string | undefined;

interface WalkState {
  readonly frames: readonly Frame[];
  readonly inFunction: boolean;
  /** The prelude text, which `binderSitesOf()` reads to find a callee
   *  written verbatim (`` `integrate`(…) ``). */
  readonly source: string;
}

/** Operators whose operands after the first are `Element(pattern, set)`
 *  clauses that bind the pattern for the first operand. */
const CLAUSE_HEADS: ReadonlySet<string> = new Set(["Loop", "Comprehension"]);

/** Operators that take a function or an expression and points, and whose
 *  variable the engine chooses from the expression (the first of its free
 *  names in sorted order). The walk binds nothing for them, so that each
 *  free name of the expression is reported; the module comment gives the
 *  reason. */
const IMPLICIT_VARIABLE_HEADS: ReadonlySet<string> = new Set([
  "NLimit",
  "ND",
  "NIntegrate",
]);

/** The index forms of the variable operand of `Limit`, whose first operand
 *  is the variable (`Limit(f, Tuple(h, 0))`, which `limit(f, (h, 0))`
 *  gives). */
const LIMIT_INDEX_FORMS: ReadonlySet<string> = new Set([
  "Tuple",
  "Triple",
  "Limits",
  "Hold",
]);

/** The variable of a `Limit` call that names it: the symbol of the second
 *  operand when a point follows it (`Limit(f, h, 0)`), or the first operand
 *  of an index form at that position (`Limit(f, Tuple(h, 0))`). For
 *  `Limit(f, a)`, the symbol `a` is the point, not a variable. */
function limitVariableOf(ops: readonly Json[]): string | undefined {
  const op = ops[1];
  if (op === undefined) return undefined;
  if (ops.length >= 3 && symbolOf(op) !== undefined) return symbolOf(op);
  const head = headOf(op);
  if (head !== undefined && LIMIT_INDEX_FORMS.has(head))
    return symbolOf(opsOf(op)[0] ?? null);
  return undefined;
}

/** The variables of a `D` call: each bare symbol operand after the body
 *  (`D(f, x, y)`), and the first element of each brace operand
 *  (`D(f, {x, 2})`, which the parser gives as a `Set` or a `List`). Each
 *  variable is bound in the body and in its own operand. The other elements
 *  of a brace operand are the order of the derivative, which is a read. */
function derivativeVariablesOf(
  ops: readonly Json[],
): { name: string; operands: readonly number[] }[] {
  const sites: { name: string; operands: readonly number[] }[] = [];
  ops.forEach((op, i) => {
    if (i === 0) return;
    const head = headOf(op);
    const name =
      head === "Set" || head === "List"
        ? symbolOf(opsOf(op)[0] ?? null)
        : symbolOf(op);
    if (name !== undefined) sites.push({ name, operands: [0, i] });
  });
  return sites;
}

function resolveName(
  frames: readonly Frame[],
  name: string,
): Frame | undefined {
  for (let i = frames.length - 1; i >= 0; i--)
    if (frames[i].names.has(name)) return frames[i];
  return undefined;
}

function innerState(state: WalkState, kind: Frame["kind"]): [WalkState, Frame] {
  const frame: Frame = { kind, names: new Set() };
  return [
    {
      frames: [...state.frames, frame],
      inFunction: state.inFunction || kind === "function",
      source: state.source,
    },
    frame,
  ];
}

function visitSymbol(
  node: Json,
  role: SymbolRole,
  parent: Json,
  state: WalkState,
  visit: SymbolVisitor,
): Json {
  const name = symbolOf(node);
  if (name === undefined) return node;
  return withSymbol(
    node,
    visit({
      name,
      role,
      node,
      parent,
      binding: resolveName(state.frames, name),
      frames: state.frames,
      inFunction: state.inFunction,
    }),
  );
}

/** Bind each name of a pattern in `frame`, then visit it with `role`. */
function walkPattern(
  pattern: Json,
  frame: Frame,
  role: SymbolRole,
  parent: Json,
  state: WalkState,
  visit: SymbolVisitor,
): Json {
  const name = symbolOf(pattern);
  // The wildcard `_` binds nothing; the pattern keeps it for the engine.
  if (name === "_") return pattern;
  if (name !== undefined) {
    frame.names.add(name);
    return visitSymbol(pattern, role, parent, state, visit);
  }
  const head = headOf(pattern);
  const ops = opsOf(pattern);
  // `Spread(p)` is a rest parameter (`function f(...args)`): it binds `p`.
  if (head === "Typed" || head === "Spread")
    return withFn(pattern, [
      head,
      walkPattern(ops[0], frame, role, parent, state, visit),
      ...ops.slice(1),
    ]);
  if (head === "Tuple" || head === "List" || head === "Sequence")
    return withFn(pattern, [
      head,
      ...ops.map((op) => walkPattern(op, frame, role, parent, state, visit)),
    ]);
  return walkNode(pattern, state, visit, parent);
}

/** An assignment target: it writes the variable that a scope declares, and
 *  never declares one (the static check refuses an assignment to a name that
 *  no scope declares). */
function walkAssignTarget(
  target: Json,
  assign: Json,
  state: WalkState,
  visit: SymbolVisitor,
): Json {
  const name = symbolOf(target);
  if (name === "_") return target;
  if (name !== undefined)
    return visitSymbol(target, "assign", assign, state, visit);
  const head = headOf(target);
  if (head === "Tuple" || head === "List")
    return withFn(target, [
      head,
      ...opsOf(target).map((op) => walkAssignTarget(op, assign, state, visit)),
    ]);
  return walkNode(target, state, visit, assign);
}

/** A `MatchCase` pattern: `_a` binds `a`; other symbols are reads. */
function walkMatchPattern(
  pattern: Json,
  frame: Frame,
  parent: Json,
  outer: WalkState,
  visit: SymbolVisitor,
): Json {
  const name = symbolOf(pattern);
  if (name !== undefined) {
    if (name.startsWith("_")) {
      const bound = name.replace(/^_+/, "");
      if (bound !== "") frame.names.add(bound);
      return pattern;
    }
    return visitSymbol(pattern, "read", parent, outer, visit);
  }
  const fn = fnOf(pattern);
  if (fn === undefined) return pattern;
  return withFn(pattern, [
    fn[0],
    ...fn
      .slice(1)
      .map((op) => walkMatchPattern(op, frame, pattern, outer, visit)),
  ]);
}

/**
 * Walk a MathJSON node with the scopes of Epsil and return it rebuilt with
 * the names the visitor returns. See the module comment for the shapes.
 */
function walkNode(
  node: Json,
  state: WalkState,
  visit: SymbolVisitor,
  parent: Json = node,
): Json {
  const fn = fnOf(node);
  if (fn === undefined) return visitSymbol(node, "read", parent, state, visit);
  const headNode = fn[0];
  const head = typeof headNode === "string" ? headNode : undefined;
  const ops = fn.slice(1);
  const walk = (op: Json, s: WalkState = state) => walkNode(op, s, visit, node);

  if (head === undefined) {
    // A call whose head is an expression: a symbol head is a call of that
    // name, any other head is walked as a value.
    const newHead =
      symbolOf(headNode) !== undefined
        ? withSymbol(
            headNode,
            visit({
              name: symbolOf(headNode)!,
              role: "call",
              node,
              parent,
              binding: resolveName(state.frames, symbolOf(headNode)!),
              frames: state.frames,
              inFunction: state.inFunction,
            }),
          )
        : walk(headNode);
    return withFn(node, [newHead, ...ops.map((op) => walk(op))]);
  }

  switch (head) {
    case "Block": {
      // A local `function h(p) {…}` is bound from its statement on, as a
      // `let` is: the engine does not hoist it in a block.
      const [inner] = innerState(state, "block");
      return withFn(node, [head, ...ops.map((op) => walk(op, inner))]);
    }
    case "Declare": {
      const frame = state.frames[state.frames.length - 1];
      const [target, ...rest] = ops;
      const { value } = declareParts(node);
      const lambda = headOf(value) === "Function";
      // A lambda's name is bound before its body is read, so that it can
      // call itself; any other value is read before the name is bound.
      let newTarget: Json | undefined;
      if (lambda)
        newTarget = walkPattern(target, frame, "declare", node, state, visit);
      const newRest = rest.map((op) => walk(op));
      newTarget ??= walkPattern(target, frame, "declare", node, state, visit);
      return withFn(node, [head, newTarget, ...newRest]);
    }
    case "DefineFunction": {
      const frame = state.frames[state.frames.length - 1];
      const [name, ...rest] = ops;
      const newName = walkPattern(name, frame, "declare", node, state, visit);
      return withFn(node, [head, newName, ...rest.map((op) => walk(op))]);
    }
    case "Function": {
      const [inner, frame] = innerState(state, "function");
      const [body, ...params] = ops;
      // A default value runs when the function is called, so its sites are
      // in the function (the checks of function bodies apply to them), but
      // it reads the enclosing scope, not the parameters.
      const defaultState: WalkState = {
        frames: state.frames,
        inFunction: true,
        source: state.source,
      };
      const newParams = params.map((param) => {
        // A parameter with a default value: the parser gives
        // `Optional(k, 2)` (`Optional(Typed(k, {str: T}), 2)` with a type);
        // `Assign(k, 2)` is the same.
        const paramHead = headOf(param);
        if (paramHead === "Assign" || paramHead === "Optional") {
          const [p, ...defaults] = opsOf(param);
          return withFn(param, [
            paramHead,
            walkPattern(p, frame, "param", param, inner, visit),
            ...defaults.map((d) => walkNode(d, defaultState, visit, param)),
          ]);
        }
        return walkPattern(param, frame, "param", node, inner, visit);
      });
      return withFn(node, [head, walk(body, inner), ...newParams]);
    }
    case "Match": {
      const [subject, ...cases] = ops;
      const newCases = cases.map((matchCase) => {
        if (headOf(matchCase) !== "MatchCase") return walk(matchCase);
        const [inner, frame] = innerState(state, "binder");
        const [pattern, ...tail] = opsOf(matchCase);
        const newPattern = walkMatchPattern(
          pattern,
          frame,
          matchCase,
          state,
          visit,
        );
        return withFn(matchCase, [
          "MatchCase",
          newPattern,
          ...tail.map((op) => walkNode(op, inner, visit, matchCase)),
        ]);
      });
      return withFn(node, [head, walk(subject), ...newCases]);
    }
    case "KeyValuePair": {
      const [key, ...rest] = ops;
      return withFn(node, [head, key, ...rest.map((op) => walk(op))]);
    }
    case "Typed": {
      const [expr, ...rest] = ops;
      return withFn(node, [head, walk(expr), ...rest]);
    }
    case "Assign": {
      const [target, value, ...rest] = ops;
      const newValue = walk(value);
      const newTarget = walkAssignTarget(target, node, state, visit);
      return withFn(node, [head, newTarget, newValue, ...rest]);
    }
  }

  if (CLAUSE_HEADS.has(head)) {
    const [inner, frame] = innerState(state, "binder");
    const [body, ...clauses] = ops;
    const newClauses = clauses.map((clause) => {
      if (headOf(clause) !== "Element")
        return walkNode(clause, inner, visit, node);
      const [pattern, collection, ...rest] = opsOf(clause);
      const newCollection = walkNode(collection, inner, visit, clause);
      return withFn(clause, [
        "Element",
        walkPattern(pattern, frame, "declare", clause, inner, visit),
        newCollection,
        ...rest.map((op) => walkNode(op, inner, visit, clause)),
      ]);
    });
    return withFn(node, [head, walk(body, inner), ...newClauses]);
  }

  // The state in which each operand of the call is walked. A callee that
  // the program defines (a prelude function named `D`) is a call of that
  // function, and its operands are reads; `binderSitesOf()` would give the
  // variables of the library operator instead, because it does not see the
  // bindings of the program.
  let stateOf: (i: number) => WalkState = () => state;
  let sites: readonly {
    name: string;
    operands: "all" | readonly number[];
  }[] = [];
  const libraryCall = resolveName(state.frames, head) === undefined;
  const limitVariable = head === "Limit" ? limitVariableOf(ops) : undefined;
  if (
    libraryCall &&
    head === "Limit" &&
    ops.length === 2 &&
    limitVariable === undefined
  ) {
    // `Limit(body, point)` has no variable operand: the engine takes the
    // variable from the body. The candidates are the names of the body that
    // no scope binds, without the library names (`Pi`) and the random-family
    // names (rules 7 and 8 refuse those). When there is exactly one
    // candidate, the limit binds it in the body; when there are more, it
    // binds none, so that step 6 reports each of them as a free name
    // (`limit(x^2 + d, 0)`). `binderSitesOf()` gives the engine's choice,
    // the first candidate in sorted order, so that step 6 would report only
    // the others. The names are found on a throwaway frame, so that the
    // first walk adds nothing to the scopes of the real walk. `runPrelude`
    // creates the fresh engine of the library test before it walks the
    // first statement. The point is read in the enclosing scope.
    const [probe] = innerState(state, "binder");
    const candidates = new Set<string>();
    walkNode(ops[0], probe, (site) => {
      if (
        site.role === "read" &&
        site.binding === undefined &&
        !RANDOM_HEADS.has(site.name) &&
        !(
          freshEngineCache !== undefined &&
          isLibraryReference(freshEngineCache, site.name)
        )
      )
        candidates.add(site.name);
      return undefined;
    });
    if (candidates.size === 1) {
      const [inner, frame] = innerState(state, "binder");
      frame.names.add([...candidates][0]);
      stateOf = (i) => (i === 0 ? inner : state);
    }
  } else if (libraryCall && (head === "D" || head === "Limit")) {
    // `D` and `Limit` keep Tycho's own rule, because `binderSitesOf()`
    // differs from the way the engine evaluates them in two ways:
    // - It binds the order of a derivative as a variable: for
    //   `D(x^n, {x, n})` it binds both `x` and `n`, so a free `n`, or an `n`
    //   that a later statement defines, is not reported.
    // - It gives no site when the body does not hold the variable
    //   (`limit(5, h, 0)`, `limit(5, (h, 0))`, `D(5, {h, 2})`,
    //   `D(x^3, {x, 1}, {h, 2})`), so step 6 would report `h` as a free name,
    //   although the engine evaluates these calls to 5 and to 0.
    // The rule: `D` binds each bare symbol operand after the body and the
    // first element of each brace operand, in the body and in that operand;
    // the other elements of a brace operand (the order) are reads. `Limit`
    // with a variable operand binds the symbol of its second operand, or the
    // first operand of an index form there, in the body and in that operand;
    // the point is read in the enclosing scope. Pinned by
    // tests/node/plot/prelude-runner.test.ts: the tests "binderSitesOf binds
    // the order of a derivative" and "a limit with a variable operand binds
    // it also when the body does not hold it" assert these engine answers.
    // When they fail, the engine has changed, and this rule can be compared
    // with `binderSitesOf()` again.
    if (head === "D") sites = derivativeVariablesOf(ops);
    else if (limitVariable !== undefined)
      sites = [{ name: limitVariable, operands: [0, 1] }];
  } else if (
    libraryCall &&
    !IMPLICIT_VARIABLE_HEADS.has(head) &&
    loadedEpsilModule !== undefined &&
    freshEngineCache !== undefined
  ) {
    // The engine's own answer: each variable that the call binds, and the
    // operands that see it (`sum(k, k, 1, n)` binds `k` in the four
    // operands, so the bound `n` is a read). `undefined` (not a library
    // operator) and `[]` (a library operator that binds nothing here) leave
    // every operand a read.
    sites =
      loadedEpsilModule.binderSitesOf(
        freshEngineCache,
        node as MathJsonExpression,
        state.source,
        undefined,
        (name) => resolveName(state.frames, name) !== undefined,
      ) ?? [];
  }
  if (sites.length > 0)
    stateOf = (i) => {
      const names = sites
        .filter((s) => s.operands === "all" || s.operands.includes(i))
        .map((s) => s.name);
      if (names.length === 0) return state;
      const [inner, frame] = innerState(state, "binder");
      for (const name of names) frame.names.add(name);
      return inner;
    };

  const newHead = withSymbol(
    head,
    visit({
      name: head,
      role: "call",
      node,
      parent,
      binding: resolveName(state.frames, head),
      frames: state.frames,
      inFunction: state.inFunction,
    }),
  );
  return withFn(node, [newHead, ...ops.map((op, i) => walk(op, stateOf(i)))]);
}

/** Every symbol site of a top-level statement, in walk order. */
function sitesOf(statement: Json, top: Frame, source: string): SymbolSite[] {
  const sites: SymbolSite[] = [];
  walkNode(statement, { frames: [top], inFunction: false, source }, (site) => {
    sites.push(site);
    return undefined;
  });
  return sites;
}

// ---------------------------------------------------------------------------
// Library names.

type FreshEngine = ComputeEngine;
let freshEngineCache: FreshEngine | undefined;

/** An engine with nothing declared, for the library-name tests. Only
 *  `lookupDefinition` and a `box` inside a pushed scope run on it, so it stays
 *  fresh. */
function freshEngine(ce: ComputeEngine): FreshEngine {
  if (freshEngineCache) return freshEngineCache;
  const Ctor =
    resolveComputeEngineCtor() ??
    (ce.constructor as unknown as new () => ComputeEngine);
  freshEngineCache = new Ctor() as unknown as FreshEngine;
  return freshEngineCache;
}

/** Whether a name that the program reads or calls is part of the library:
 *  a fresh engine binds it (after `resolveLibraryNames`, `max` is `Max`, and
 *  `e`, `Pi` and the grammar heads `Block`, `Loop`, … are bound), or it is one
 *  of Tycho's standard aliases (`total`, `stdev`, …). */
function isLibraryReference(fresh: FreshEngine, name: string): boolean {
  if (STRUCTURAL_HEADS.has(name)) return true;
  if (isStandardAliasName(name)) return true;
  return fresh.lookupDefinition(name) !== undefined;
}

/** Heads that the parser produces and that a fresh engine may not define as
 *  operators. They are never free names. */
const STRUCTURAL_HEADS: ReadonlySet<string> = new Set([
  "Typed",
  "MatchCase",
  "Match",
  "KeyValuePair",
  "Nothing",
]);

/** Whether a prelude name would hide or stand for a library name (rule 5,
 *  § 3.3). See the module comment for the two tests. */
function libraryNameCollision(
  fresh: FreshEngine,
  canonicalLibraryName: EpsilModule["canonicalLibraryName"],
  name: string,
): string | undefined {
  // Step 2b has already refused an alias name; this keeps the rule whole for
  // a caller of this function alone.
  if (isStandardAliasName(name)) return name;
  const definition = fresh.lookupDefinition(name);
  if (definition !== undefined) {
    // A constant (`e`, `Pi`, `i`) is always refused. An operator is refused
    // when its name has more than one letter (`Max`, `Fill`); a document
    // row may name a value `D` or `N`, and so may a prelude.
    if ("value" in definition) return name;
    if ([...name].length > 1) return name;
    return undefined;
  }
  const library = canonicalLibraryName(name);
  if (library === undefined) return undefined;
  fresh.pushScope();
  try {
    const parsed = fresh.parse(fresh.box(name).latex);
    const read = isSymbol(parsed) ? parsed.symbol : parsed.operator;
    if (read !== name && fresh.lookupDefinition(read) !== undefined)
      return read;
    return undefined;
  } finally {
    fresh.popScope();
  }
}

// ---------------------------------------------------------------------------
// Typed carriers of compiled values.

/** The shape of a value that compiled JavaScript can carry exactly. */
type Carrier =
  | {
      readonly kind: "number";
      /** `false` for the type `number`, which does not prove the value
       *  real: a NaN of the compiled code can then stand for a complex value
       *  of the interpreter, and the statement runs on the interpreter. */
      readonly real: boolean;
    }
  | { readonly kind: "boolean" }
  | { readonly kind: "list"; readonly element: Carrier }
  | { readonly kind: "tuple"; readonly elements: readonly Carrier[] };

const NUMBER_CARRIER: Carrier = { kind: "number", real: true };
const UNPROVEN_NUMBER_CARRIER: Carrier = { kind: "number", real: false };
const BOOLEAN_CARRIER: Carrier = { kind: "boolean" };

/** Numeric types that a float64 represents. `rational` is left out (an
 *  exact fraction must stay exact), and so are `complex`, `imaginary` and
 *  `infinity` (the complex infinity). `number` is carried with a guard
 *  (see {@link UNPROVEN_NUMBER_CARRIER}): an author annotation such as
 *  `list<tuple<number, number, number>>` is common, and a strict JavaScript
 *  compile computes it as a real. */
const FLOAT_LEAF_TYPES: ReadonlySet<string> = new Set([
  "integer",
  "real",
  "signed_infinity",
  "nan",
]);

/** A CE type node (`BoxedType.type`), as far as the carrier reads it. */
interface TypeNode {
  readonly kind?: string;
  readonly type?: unknown;
  readonly types?: readonly unknown[];
  readonly elements?: unknown;
  readonly dimensions?: readonly number[];
  readonly value?: unknown;
  readonly def?: unknown;
  readonly alias?: boolean;
}

function mergeCarriers(a: Carrier, b: Carrier): Carrier | null {
  if (a.kind === "number" && b.kind === "number")
    return a.real && b.real ? NUMBER_CARRIER : UNPROVEN_NUMBER_CARRIER;
  if (a.kind === "boolean" && b.kind === "boolean") return a;
  if (a.kind === "list" && b.kind === "list") {
    const element = mergeCarriers(a.element, b.element);
    return element ? { kind: "list", element } : null;
  }
  if (
    a.kind === "tuple" &&
    b.kind === "tuple" &&
    a.elements.length === b.elements.length
  ) {
    const elements: Carrier[] = [];
    for (let i = 0; i < a.elements.length; i++) {
      const merged = mergeCarriers(a.elements[i], b.elements[i]);
      if (!merged) return null;
      elements.push(merged);
    }
    return { kind: "tuple", elements };
  }
  return null;
}

/** The carrier of a CE type, or `null` when compiled code cannot carry a
 *  value of that type exactly. */
function carrierOfType(type: unknown): Carrier | null {
  if (typeof type === "string") {
    if (FLOAT_LEAF_TYPES.has(type)) return NUMBER_CARRIER;
    if (type === "number") return UNPROVEN_NUMBER_CARRIER;
    if (type === "boolean") return BOOLEAN_CARRIER;
    return null;
  }
  if (type === null || typeof type !== "object") return null;
  const t = type as TypeNode;
  switch (t.kind) {
    case "numeric":
      if (typeof t.type !== "string") return null;
      if (FLOAT_LEAF_TYPES.has(t.type)) return NUMBER_CARRIER;
      return t.type === "number" ? UNPROVEN_NUMBER_CARRIER : null;
    case "value":
      if (typeof t.value === "number") return NUMBER_CARRIER;
      if (typeof t.value === "boolean") return BOOLEAN_CARRIER;
      return null;
    case "reference":
      return t.alias === true ? carrierOfType(t.def) : null;
    case "union": {
      let merged: Carrier | null = null;
      for (const member of t.types ?? []) {
        if (member === "never") continue;
        const c = carrierOfType(member);
        if (!c) return null;
        merged = merged ? mergeCarriers(merged, c) : c;
        if (!merged) return null;
      }
      return merged;
    }
    case "list": {
      let element = carrierOfType(t.elements);
      if (!element) return null;
      // A tensor type gives the type of its cells and the number of axes.
      for (let i = 1; i < (t.dimensions?.length ?? 1); i++)
        element = { kind: "list", element };
      return { kind: "list", element };
    }
    case "tuple": {
      const elements: Carrier[] = [];
      for (const named of (t.elements as readonly { type: unknown }[]) ?? []) {
        const c = carrierOfType(named.type);
        if (!c) return null;
        elements.push(c);
      }
      return { kind: "tuple", elements };
    }
  }
  return null;
}

/** Whether a CE type has a `rational` leaf (an exact fraction, which a
 *  float64 does not keep), in a list, a tuple or a union. */
function hasExactFraction(type: unknown): boolean {
  if (type === "rational") return true;
  if (type === null || typeof type !== "object") return false;
  const t = type as TypeNode;
  switch (t.kind) {
    case "numeric":
      return t.type === "rational";
    case "union":
      return (t.types ?? []).some(hasExactFraction);
    case "list":
      return hasExactFraction(t.elements);
    case "tuple":
      return ((t.elements as readonly { type: unknown }[]) ?? []).some((e) =>
        hasExactFraction(e.type),
      );
    case "reference":
      return t.alias === true && hasExactFraction(t.def);
  }
  return false;
}

/** The type that declares an input of this carrier in the compile scope. A
 *  number is declared `real`, or with the extended real type when the value
 *  holds a non-finite number, so that a statement can store a real in a name
 *  that holds an integer; a list has no fixed length, so that it can grow. */
function inputTypeOf(carrier: Carrier, nonFinite: boolean): string {
  switch (carrier.kind) {
    case "number":
      return nonFinite ? `(${EXTENDED_REAL_TYPE})` : "real";
    case "boolean":
      return "boolean";
    case "list":
      return `list<${inputTypeOf(carrier.element, nonFinite)}>`;
    case "tuple":
      return `tuple<${carrier.elements
        .map((c) => inputTypeOf(c, nonFinite))
        .join(", ")}>`;
  }
  return unknownCarrier(carrier);
}

class CarrierMismatch extends Error {}

/** The end of an exhaustive `switch` over the carrier kinds. */
function unknownCarrier(carrier: never): never {
  throw new Error(`unknown carrier ${JSON.stringify(carrier)}`);
}

/** A JavaScript value of the compiled code as MathJSON, shaped by its
 *  carrier. Throws {@link CarrierMismatch} when the value has another
 *  shape. */
function reboxValue(value: unknown, carrier: Carrier): MathJsonExpression {
  switch (carrier.kind) {
    case "number":
      if (typeof value !== "number") throw new CarrierMismatch();
      if (Number.isNaN(value)) {
        if (!carrier.real) throw new CarrierMismatch();
        return "NaN";
      }
      if (value === Infinity) return "PositiveInfinity";
      if (value === -Infinity) return "NegativeInfinity";
      return value;
    case "boolean":
      if (typeof value !== "boolean") throw new CarrierMismatch();
      return value ? "True" : "False";
    case "list": {
      const items = arrayOf(value);
      return ["List", ...items.map((v) => reboxValue(v, carrier.element))];
    }
    case "tuple": {
      const items = arrayOf(value);
      if (items.length !== carrier.elements.length) throw new CarrierMismatch();
      return [
        "Tuple",
        ...items.map((v, i) => reboxValue(v, carrier.elements[i])),
      ];
    }
  }
  return unknownCarrier(carrier);
}

function arrayOf(value: unknown): readonly unknown[] {
  if (Array.isArray(value)) return value;
  if (ArrayBuffer.isView(value) && !(value instanceof DataView))
    return Array.from(value as unknown as ArrayLike<number>);
  throw new CarrierMismatch();
}

/** An engine value as the JavaScript value the compiled code reads, or
 *  `undefined` when it does not fit the carrier. Also tells whether it holds a
 *  non-finite number. */
function engineValueToJs(
  expr: Expression,
  carrier: Carrier,
  state: { nonFinite: boolean },
): unknown {
  switch (carrier.kind) {
    case "number": {
      const sym = isSymbol(expr) ? expr.symbol : undefined;
      if (
        sym === "NaN" ||
        sym === "PositiveInfinity" ||
        sym === "NegativeInfinity"
      ) {
        state.nonFinite = true;
        return sym === "NaN"
          ? NaN
          : sym === "PositiveInfinity"
            ? Infinity
            : -Infinity;
      }
      if (!isNumber(expr) || expr.im !== 0) return undefined;
      const re = expr.re;
      if (!Number.isFinite(re)) state.nonFinite = true;
      return re;
    }
    case "boolean":
      return isSymbol(expr, "True")
        ? true
        : isSymbol(expr, "False")
          ? false
          : undefined;
    case "list":
    case "tuple": {
      if (!isFunction(expr, carrier.kind === "list" ? "List" : "Tuple"))
        return undefined;
      const ops = expr.ops;
      if (carrier.kind === "tuple" && ops.length !== carrier.elements.length)
        return undefined;
      const out: unknown[] = [];
      for (let i = 0; i < ops.length; i++) {
        const v = engineValueToJs(
          ops[i],
          carrier.kind === "list" ? carrier.element : carrier.elements[i],
          state,
        );
        if (v === undefined) return undefined;
        out.push(v);
      }
      return out;
    }
  }
  return unknownCarrier(carrier);
}

/** The number of elements of a value, counted over nested lists and tuples;
 *  `Infinity` for a collection with no finite size. Stops counting above
 *  `limit`. */
function elementCount(expr: Expression, limit: number): number {
  let total = 0;
  const walk = (e: Expression): void => {
    if (total > limit) return;
    if (isFunction(e, "List") || isFunction(e, "Tuple")) {
      const ops = e.ops;
      total += ops.length;
      for (const op of ops) walk(op);
      return;
    }
    if (e.isCollection === true) {
      const count = e.count;
      total += typeof count === "number" ? count : Infinity;
    }
  };
  walk(expr);
  return total;
}

/** The text of the first `Error` node of an expression. */
function errorText(json: unknown): string | undefined {
  const fn = fnOf(json);
  if (fn === undefined) return undefined;
  if (fn[0] === "Error") {
    const parts: string[] = [];
    const unquote = (s: unknown) =>
      typeof s === "string" ? s.replace(/^'|'$/g, "") : JSON.stringify(s);
    for (const op of fn.slice(1)) {
      const sub = fnOf(op);
      if (sub && sub[0] === "ErrorCode") {
        const [code, ...args] = sub.slice(1).map(unquote);
        parts.push(args.length > 0 ? `${code} (${args.join(", ")})` : code);
      } else if (sub && sub[0] === "ErrorTrace") continue;
      else parts.push(unquote((op as { str?: unknown })?.str ?? op));
    }
    return parts.join(": ");
  }
  for (const op of fn.slice(1)) {
    const text = errorText(op);
    if (text !== undefined) return text;
  }
  return undefined;
}

// ---------------------------------------------------------------------------
// The program.

interface TopStatement {
  readonly node: Json;
  readonly kind: "function" | "value" | "expression";
  readonly range: [number, number];
  /** The names it defines (a function, the `Declare` target, a top-level
   *  `Assign` target), with their symbol nodes. */
  readonly defines: readonly { name: string; node: Json }[];
  readonly sites: readonly SymbolSite[];
}

/** The text of a range, or of the name when the node has no range. */
function writtenName(source: string, node: Json, name: string): string {
  const range = offsetsOf(node);
  if (range) {
    const text = source.slice(range[0], range[1]);
    if (text !== "") return text;
  }
  return name;
}

function topStatementsOf(ast: Json): Json[] {
  if (symbolOf(ast) === "Nothing") return [];
  const head = headOf(ast);
  if (head === "Program" || head === "Block") return [...opsOf(ast)];
  return [ast];
}

/** The range of a call's head: the start of the call, as long as the name,
 *  when the text there spells it; else the range of the call. */
function callHeadRange(
  source: string,
  node: Json,
  name: string,
  fallback: [number, number],
): [number, number] {
  const range = offsetsOf(node) ?? fallback;
  if (source.startsWith(name, range[0]))
    return [range[0], range[0] + name.length];
  return range;
}

function epsilDiagnostic(
  d: CheckEpsilResult["diagnostics"][number],
): PreludeDiagnostic {
  const [code, ...details] = Array.isArray(d.message)
    ? (d.message as unknown[])
    : [d.message];
  const sentence = details.find(
    (x): x is string => typeof x === "string" && x.includes(" "),
  );
  let message =
    code === "variable-redeclaration"
      ? `\`${String(details[0])}\` is declared more than once`
      : (sentence ??
        (details.length > 0
          ? `${String(code)}: ${details.map((x) => String(x)).join(", ")}`
          : String(code)));
  // A `static-type-error` of the scope rules has its precise code in the
  // field `code` (`read-before-declaration`). A read before the `let` gets
  // the code and the sentence of step 8b, which reports the same error
  // through a call.
  let outCode = String(code);
  const precise = (d as { code?: string }).code;
  if (code === "static-type-error" && precise === "read-before-declaration") {
    outCode = "read-before-definition";
    const name = /^`([^`]+)`/.exec(sentence ?? "")?.[1];
    if (name !== undefined)
      message = `\`${name}\` is read before its definition`;
  } else if (
    code === "static-type-error" &&
    precise === "assignment-to-undeclared-variable"
  )
    outCode = precise;
  const out: PreludeDiagnostic = {
    severity: d.severity,
    code: outCode,
    message,
    range: [d.range[0], d.range[1]],
  };
  if (d.notes && d.notes.length > 0)
    out.notes = d.notes.map((n) =>
      n.range
        ? { message: n.message, range: [n.range[0], n.range[1]] }
        : { message: n.message },
    );
  return out;
}

/**
 * The diagnostics of the static check with Tycho's fixes: an
 * `assignment-to-undeclared-variable` can get the fix that writes `let `
 * before the assignment; `attachLetFixes()` gives the rule. The engine gives
 * the range of the name for a `read-before-definition` (the engine's
 * `read-before-declaration`), as step 8b reports it.
 */
function refineCheckDiagnostics(
  diagnostics: PreludeDiagnostic[],
  statements: readonly Json[],
  source: string,
): PreludeDiagnostic[] {
  const undeclared: { d: PreludeDiagnostic; name: string }[] = [];
  for (const d of diagnostics) {
    if (d.code !== "assignment-to-undeclared-variable") continue;
    const name = /^`([^`]+)`/.exec(d.message)?.[1];
    if (name !== undefined) undeclared.push({ d, name });
  }
  attachLetFixes(undeclared, statements, source);
  return diagnostics;
}

/**
 * Attach the fix that writes `let ` before an assignment to an undeclared
 * name. The fix is decided per scope (the frame that a `let` at the
 * assignment would declare in), so that applying every fix once makes each
 * fixed assignment valid and turns no assignment of an outer variable into a
 * local. In each scope, the fix goes on the first assignment of the name, in
 * source order, that:
 * - is a statement of the program or of a block (the scope is the top level
 *   or that block);
 * - is a plain `name = value` whose value does not read the name (`let s =
 *   s + k` would read `s` before its `let`);
 * - is in a scope where no `let` declares the name (the fix would declare it
 *   again);
 * - is in a scope that no other scope with an assignment or a `let` of the
 *   name encloses: there the name is meant to be the outer variable, and a
 *   `let` would make a local that hides it (`for k in 1..3 { t = k }` with
 *   `t = 0` at the top level fixes only `t = 0`).
 * The other assignments keep their error without a fix.
 */
function attachLetFixes(
  errors: readonly { d: PreludeDiagnostic; name: string }[],
  statements: readonly Json[],
  source: string,
): void {
  if (errors.length === 0) return;
  // One top frame for the whole program, so that the frames of all the
  // sites can be compared.
  const top: Frame = { kind: "top", names: new Set() };
  const sites = statements
    .flatMap((node) => sitesOf(node, top, source))
    .filter((site) => site.role === "assign" || site.role === "declare");
  const statementNodes = new Set<Json>(statements);
  const addBlockStatements = (node: Json): void => {
    const fn = fnOf(node);
    if (fn === undefined) return;
    if (fn[0] === "Block") for (const op of fn.slice(1)) statementNodes.add(op);
    for (const op of fn) addBlockStatements(op);
  };
  for (const node of statements) addBlockStatements(node);
  const scopeOf = (site: SymbolSite) => site.frames[site.frames.length - 1];
  const fixed = new Map<Frame, Set<string>>();
  const ordered = [...errors].sort((a, b) => a.d.range[0] - b.d.range[0]);
  for (const { d, name } of ordered) {
    const site = sites.find(
      (s) =>
        s.role === "assign" &&
        s.name === name &&
        offsetsOf(s.parent)?.[0] === d.range[0],
    );
    if (site === undefined || !statementNodes.has(site.parent)) continue;
    const scope = scopeOf(site);
    if (scope.kind !== "top" && scope.kind !== "block") continue;
    if (fixed.get(scope)?.has(name)) continue;
    if (
      sites.some(
        (s) =>
          s.name === name &&
          ((s.role === "declare" && scopeOf(s) === scope) ||
            (scopeOf(s) !== scope && site.frames.includes(scopeOf(s)))),
      )
    )
      continue;
    // The range starts at the target: `x1 = 2`, not `x1 == 2`.
    const text = source.slice(d.range[0], d.range[1]);
    const head = new RegExp(`^${escapeRegExp(name)}\\s*=(?!=)`).exec(text);
    if (head === null) continue;
    const read = new RegExp(`(^|[^\\w])${escapeRegExp(name)}(?!\\w)`);
    if (read.test(text.slice(head[0].length))) continue;
    d.fix = {
      title: `Declare \`${name}\` with let`,
      edits: [{ range: [d.range[0], d.range[0]], text: "let " }],
    };
    if (!fixed.has(scope)) fixed.set(scope, new Set());
    fixed.get(scope)!.add(name);
  }
}

function escapeRegExp(text: string): string {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function utf8Length(source: string): number {
  return new TextEncoder().encode(source).length;
}

/**
 * Validate and run one Epsil prelude program on `ce`. See the module comment
 * for the steps. The engine keeps the functions and values of the program,
 * also when the result is invalid: the runner declares and assigns names on
 * it and never removes them. So each call needs an engine that no earlier run
 * has used, with only the document settings (angle unit, precision, complex
 * mode).
 */
export async function runPrelude(
  ce: ComputeEngine,
  source: string,
  options: PreludeRunOptions = {},
): Promise<PreludeRunResult> {
  // A text over the size limit is refused before the parser loads.
  if (utf8Length(source) <= PRELUDE_MAX_SOURCE_BYTES) await loadEpsil();
  const steps = preludeSteps(ce, source, options);
  let step = steps.next();
  while (!step.done) {
    const request = step.value;
    let value: unknown;
    try {
      const { result, inputs, loops } = request;
      value =
        typeof result.runAsync === "function"
          ? await result.runAsync(inputs, {
              onLoop: (report) => {
                const loop: PreludeParallelLoop = {
                  passes: report.passes,
                  route: report.route,
                };
                if (report.reason !== undefined) loop.reason = report.reason;
                loops.push(loop);
              },
            })
          : result.run(inputs);
    } catch (e) {
      step = steps.throw(e);
      continue;
    }
    step = steps.next(value);
  }
  return step.value;
}

/**
 * {@link runPrelude} with no `await`: every step runs in this call, and each
 * compiled statement runs with `run()`, so a `parallel for` runs its passes
 * in order on this thread. The Epsil entry must be loaded first
 * ({@link loadPreludeParser}); otherwise a text within the size limit
 * throws. The agent host uses it to run a prelude inside a step budget of
 * the scratch engine (`checkPlotPrelude` in
 * `src/graph-paper/agent-host/plot-host.ts`).
 */
export function runPreludeLoaded(
  ce: ComputeEngine,
  source: string,
  options: PreludeRunOptions = {},
): PreludeRunResult {
  const steps = preludeSteps(ce, source, options);
  let step = steps.next();
  while (!step.done) {
    let value: unknown;
    try {
      value = step.value.result.run(step.value.inputs);
    } catch (e) {
      step = steps.throw(e);
      continue;
    }
    step = steps.next(value);
  }
  return step.value;
}

/**
 * The steps of {@link runPrelude} and {@link runPreludeLoaded} (see the
 * module comment). The generator yields each run of a compiled value
 * statement ({@link CompiledRunRequest}) and expects the value of the run,
 * or the error of the run thrown into it; nothing else in it waits.
 */
function* preludeSteps(
  ce: ComputeEngine,
  source: string,
  options: PreludeRunOptions,
): PreludeSteps<PreludeRunResult> {
  const maxElements = options.maxElements ?? PRELUDE_MAX_ELEMENTS;
  const iterationBudget = options.iterationBudget ?? PRELUDE_ITERATION_BUDGET;
  const start = now();
  const diagnostics: PreludeDiagnostic[] = [];
  const timings: PreludeTimings = {
    parseMs: 0,
    checkMs: 0,
    compileMs: 0,
    runMs: 0,
    totalMs: 0,
  };
  const result: PreludeRunResult = {
    valid: false,
    diagnostics,
    names: [],
    functions: [],
    values: [],
    statements: [],
    timings,
  };
  const finish = (valid: boolean): PreludeRunResult => {
    // The literal constants run before the other value statements (step 9);
    // the statements are given in program order.
    result.statements.sort((a, b) => a.range[0] - b.range[0]);
    result.valid = valid && !diagnostics.some((d) => d.severity === "error");
    timings.totalMs = now() - start;
    return result;
  };
  const error = (
    code: string,
    message: string,
    range: [number, number],
  ): void => {
    diagnostics.push({ severity: "error", code, message, range });
  };

  // 1. Size.
  const bytes = utf8Length(source);
  if (bytes > PRELUDE_MAX_SOURCE_BYTES) {
    error(
      "prelude-too-large",
      `the prelude has ${bytes} bytes; the limit is ${PRELUDE_MAX_SOURCE_BYTES}`,
      [0, source.length],
    );
    return finish(false);
  }

  const epsil = loadedEpsilModule;
  if (epsil === undefined)
    throw new Error("runPreludeLoaded: the Epsil entry is not loaded");

  // 2. Parse.
  const parseStart = now();
  let ast: Json;
  try {
    const [tree, parseDiagnostics] = epsil.parseEpsil(source);
    if (parseDiagnostics.some((d) => d.severity === "error")) {
      diagnostics.push(...parseDiagnostics.map(epsilDiagnostic));
      timings.parseMs = now() - parseStart;
      return finish(false);
    }
    ast = epsil.resolveLibraryNames(tree, source, ce);
  } catch (e) {
    // A `#error` directive throws a `FatalParsingError`.
    error("parse-error", String((e as Error)?.message ?? e), [
      0,
      source.length,
    ]);
    timings.parseMs = now() - parseStart;
    return finish(false);
  }
  timings.parseMs = now() - parseStart;

  /** The top-level names a statement defines, each with the node that
   *  carries the name's source offsets. */
  const definesOf = (node: Json): { name: string; node: Json }[] => {
    const head = headOf(node);
    const targets =
      head === "DefineFunction"
        ? [opsOf(node)[0]]
        : head === "Declare" || head === "Assign"
          ? patternSymbols(opsOf(node)[0])
          : [];
    return targets.map((t) => ({ name: symbolOf(t)!, node: t }));
  };
  const rawStatements = topStatementsOf(ast);

  // 2b. Tycho's standard aliases (`total`, `sort`, `unique`, `stdev`;
  // `ce-aliases.ts`) are declared on the document engine, so `let total = 0`
  // would reach the static check as a redeclaration of a bound operator and
  // get a type error that does not name the cause. They are refused here,
  // before the check, with the diagnostic of rule 5.
  const aliasRefused = new Set<string>();
  for (const node of rawStatements)
    for (const { name, node: target } of definesOf(node)) {
      if (!isStandardAliasName(name) || aliasRefused.has(name)) continue;
      aliasRefused.add(name);
      error(
        "library-name",
        `\`${writtenName(source, target, name)}\` is a library name; choose another name`,
        offsetsOf(target) ?? offsetsOf(node) ?? [0, source.length],
      );
    }
  if (diagnostics.some((d) => d.severity === "error")) return finish(false);

  // 3. The static check. Its diagnostics include the parse warnings.
  const checkStart = now();
  let check: CheckEpsilResult;
  try {
    check = epsil.checkEpsil(ce, source);
  } catch (e) {
    error("check-error", String((e as Error)?.message ?? e), [
      0,
      source.length,
    ]);
    timings.checkMs = now() - checkStart;
    return finish(false);
  }
  diagnostics.push(
    ...refineCheckDiagnostics(
      check.diagnostics.map(epsilDiagnostic),
      rawStatements,
      source,
    ),
  );
  if (diagnostics.some((d) => d.severity === "error")) {
    timings.checkMs = now() - checkStart;
    return finish(false);
  }

  // 4. Classification. The top-level names are collected first, so that a
  // statement resolves a name that a later statement defines.
  const fresh = freshEngine(ce);
  const top: Frame = { kind: "top", names: new Set() };
  for (const node of rawStatements)
    for (const { name } of definesOf(node)) top.names.add(name);

  const functionNames = new Set<string>();
  const statements: TopStatement[] = rawStatements.map((node) => {
    const head = headOf(node);
    const range = offsetsOf(node) ?? [0, source.length];
    const sites = sitesOf(node, top, source);
    const defines = definesOf(node);
    let kind: TopStatement["kind"];
    if (
      head === "DefineFunction" ||
      (head === "Declare" &&
        symbolOf(opsOf(node)[0]) !== undefined &&
        headOf(declareParts(node).value) === "Function")
    )
      kind = "function";
    else if (head === "Declare" || head === "Assign") kind = "value";
    else if (
      sites.some(
        (s) => s.role === "assign" && s.binding === top && !s.inFunction,
      )
    )
      kind = "value";
    else kind = "expression";
    if (kind === "function") functionNames.add(defines[0].name);
    return { node, kind, range, defines, sites };
  });
  for (const s of statements)
    if (s.kind === "expression")
      diagnostics.push({
        severity: "warning",
        code: "expression-statement",
        message: "this statement has no effect in a prelude",
        range: s.range,
      });

  // The top-level names in source order, as written.
  const valueNames: string[] = [];
  const seenNames = new Set<string>();
  for (const s of statements)
    for (const { name, node } of s.defines) {
      if (seenNames.has(name)) continue;
      seenNames.add(name);
      result.names.push(writtenName(source, node, name));
      if (!functionNames.has(name)) valueNames.push(name);
    }
  const valueNameSet = new Set(valueNames);

  const groupFailed = (): boolean => {
    if (!diagnostics.some((d) => d.severity === "error")) return false;
    timings.checkMs = now() - checkStart;
    return true;
  };

  // 5. Name admission, once for each name, at its first definition.
  const admitted = new Set<string>();
  for (const s of statements)
    for (const { name, node } of s.defines) {
      if (admitted.has(name)) continue;
      admitted.add(name);
      const range = offsetsOf(node) ?? s.range;
      const written = writtenName(source, node, name);
      const isFunction = functionNames.has(name);
      if (name === "dt")
        error(
          "reserved-name",
          "`dt` is the time step of the ticker; choose another name",
          range,
        );
      else if (
        isFunction ? isReservedCallHeadName(name) : isReservedVariableName(name)
      )
        error(
          "reserved-name",
          `\`${written}\` is a plot variable; choose another name`,
          range,
        );
      else {
        const library = libraryNameCollision(
          fresh,
          epsil.canonicalLibraryName,
          name,
        );
        if (library !== undefined)
          error(
            "library-name",
            library === name
              ? `\`${written}\` is a library name; choose another name`
              : `\`${written}\` stands for the library name \`${library}\`; choose another name`,
            range,
          );
      }
    }
  if (groupFailed()) return finish(false);

  // 6. Self-containment: one diagnostic for each free name, at its first
  // occurrence in the text.
  const free = new Map<string, [number, number]>();
  for (const s of statements)
    for (const site of s.sites) {
      if (site.binding !== undefined) continue;
      if (site.role !== "read" && site.role !== "call") continue;
      if (isLibraryReference(fresh, site.name)) continue;
      const range =
        site.role === "call"
          ? callHeadRange(source, site.node, site.name, s.range)
          : (offsetsOf(site.node) ?? s.range);
      const known = free.get(site.name);
      if (known === undefined || range[0] < known[0])
        free.set(site.name, range);
    }
  for (const [name, range] of [...free].sort((a, b) => a[1][0] - b[1][0]))
    error(
      "free-name",
      `\`${source.slice(range[0], range[1]) || name}\` is not defined in the prelude; pass it as a parameter`,
      range,
    );
  if (groupFailed()) return finish(false);

  // 7. Function bodies: no assignment of a top-level name, no random
  // operator. The reads of top-level values are kept for step 10.
  const functionReads: { fn: string; name: string; range: [number, number] }[] =
    [];
  for (const s of statements) {
    const fnName = s.kind === "function" ? s.defines[0].name : undefined;
    // The `scope` specifier makes the body run in the scope of the caller,
    // so its assignments change the caller's names. The walker reads such
    // an assignment as a local of the body, so the specifier is refused
    // here, and the other checks of the body are not reported: an
    // assignment in such a body reads as a write of a top-level name.
    if (
      fnName !== undefined &&
      signatureOf(functionNodeOf(s.node)).specifiers.includes("scope")
    ) {
      error(
        "function-scope",
        `\`${writtenName(source, s.defines[0].node, fnName)}\` writes to the scope of its caller; a prelude function may change only its own locals`,
        s.range,
      );
      continue;
    }
    for (const site of s.sites) {
      if (!site.inFunction) continue;
      if (site.role === "assign" && site.binding === top)
        error(
          "function-assigns-top-level",
          `a function may not change the top-level name \`${site.name}\``,
          offsetsOf(site.parent) ?? s.range,
        );
      else if (
        fnName !== undefined &&
        RANDOM_HEADS.has(site.name) &&
        site.binding === undefined
      )
        error(
          "random-call",
          "a prelude may not call a random operator; its values must be the same on each run",
          offsetsOf(site.node) ?? s.range,
        );
      else if (
        fnName !== undefined &&
        site.role === "read" &&
        site.binding === top &&
        valueNameSet.has(site.name)
      )
        functionReads.push({
          fn: fnName,
          name: site.name,
          range: offsetsOf(site.node) ?? s.range,
        });
    }
  }
  if (groupFailed()) return finish(false);

  // 8. Random operators in value statements (and in a lambda inside one), in
  // any role: a call, or a name given to `Apply` or `map`.
  for (const s of statements) {
    if (s.kind === "function") continue;
    for (const site of s.sites)
      if (RANDOM_HEADS.has(site.name) && site.binding === undefined)
        error(
          "random-call",
          "a prelude may not call a random operator; its values must be the same on each run",
          offsetsOf(site.node) ?? s.range,
        );
  }
  if (groupFailed()) return finish(false);

  // The calls between prelude functions, for the order check and for the
  // `recursive` flag. A function given by name (`map(L, f)`) is a call, as
  // in step 8b.
  const calls = new Map<string, Set<string>>();
  for (const s of statements) {
    if (s.kind !== "function") continue;
    const callees = new Set<string>();
    for (const site of s.sites)
      if (
        (site.role === "call" || site.role === "read") &&
        site.binding === top &&
        functionNames.has(site.name)
      )
        callees.add(site.name);
    calls.set(s.defines[0].name, callees);
  }
  /** The prelude functions that `fn` calls, directly or not. */
  const reachableFrom = (fn: string): Set<string> => {
    const seen = new Set<string>();
    const pending = [...(calls.get(fn) ?? [])];
    while (pending.length > 0) {
      const next = pending.pop()!;
      if (seen.has(next)) continue;
      seen.add(next);
      pending.push(...(calls.get(next) ?? []));
    }
    return seen;
  };

  // 8b. Order: a value statement may read only the values that statements
  // before it define, also through the functions it calls.
  const firstDefinition = new Map<string, number>();
  statements.forEach((s, i) => {
    for (const { name } of s.defines)
      if (!firstDefinition.has(name)) firstDefinition.set(name, i);
  });
  const readsOf = new Map<string, Set<string>>();
  for (const read of functionReads) {
    const names = readsOf.get(read.fn) ?? new Set<string>();
    names.add(read.name);
    readsOf.set(read.fn, names);
  }
  statements.forEach((s, i) => {
    if (s.kind !== "value") return;
    const reported = new Set<string>();
    const later = (name: string, range: [number, number]) => {
      if (reported.has(name) || (firstDefinition.get(name) ?? -1) <= i) return;
      reported.add(name);
      error(
        "read-before-definition",
        `\`${name}\` is read before its definition`,
        range,
      );
    };
    for (const site of s.sites) {
      if (site.binding !== top) continue;
      if (site.role === "read" && valueNameSet.has(site.name))
        later(site.name, offsetsOf(site.node) ?? s.range);
      else if (
        (site.role === "call" || site.role === "read") &&
        functionNames.has(site.name)
      ) {
        // A call, or a function given by name (`map(L, f)`).
        const range =
          site.role === "call"
            ? callHeadRange(source, site.node, site.name, s.range)
            : (offsetsOf(site.node) ?? s.range);
        for (const fn of [site.name, ...reachableFrom(site.name)])
          for (const name of readsOf.get(fn) ?? []) later(name, range);
      }
    }
  });
  if (groupFailed()) return finish(false);
  timings.checkMs = now() - checkStart;

  // 9. Run. A top-level `const` with a literal value first, then the
  // functions, then the other value statements, each group in program order.
  // A default parameter value can name a constant (`function f(k = c)`), and
  // the engine refuses the function when the symbol is not declared constant
  // at that time. A literal reads nothing, so it gives the same value before
  // the functions as in its place.
  const routeOf = new Map<string, "compiled" | "interpreted">();
  const declaredOf: DeclaredNames = new Map();
  const programSymbols = collectSymbols(ast);
  /** The top-level values that the functions called by `s` read, directly
   *  or through other functions. */
  const valuesReadByCalls = (s: TopStatement): Set<string> => {
    const names = new Set<string>();
    for (const site of s.sites) {
      if (site.binding !== top || !functionNames.has(site.name)) continue;
      if (site.role !== "call" && site.role !== "read") continue;
      for (const fn of [site.name, ...reachableFrom(site.name)])
        for (const name of readsOf.get(fn) ?? []) names.add(name);
    }
    return names;
  };
  /** Run one value statement; `false` when it gives an error. */
  function* runValue(s: TopStatement): PreludeSteps<boolean> {
    const outcome = yield* runValueStatement(ce, s, {
      top,
      valuesReadByCalls: valuesReadByCalls(s),
      programSymbols,
      iterationBudget,
      source,
    });
    timings.compileMs += outcome.run.compileMs;
    timings.runMs += outcome.run.runMs;
    result.statements.push(outcome.run);
    if (outcome.error !== undefined) {
      error(outcome.error.code, outcome.error.message, s.range);
      return false;
    }
    for (const name of outcome.run.names) routeOf.set(name, outcome.run.route);
    for (const [name, d] of outcome.declared) declaredOf.set(name, d);

    // 10. Element cap.
    for (const name of outcome.run.names) {
      const count = elementCount(ce.box(name).evaluate(), maxElements);
      if (count > maxElements) {
        error(
          "element-cap",
          Number.isFinite(count)
            ? `\`${name}\` has more than ${maxElements} elements`
            : `\`${name}\` is a collection with no finite number of elements`,
          s.range,
        );
        return false;
      }
    }
    return true;
  }
  const literalConstants = new Set(
    statements.filter((s) => s.kind === "value" && isLiteralConstant(s.node)),
  );
  for (const s of literalConstants)
    if (!(yield* runValue(s))) return finish(false);

  const runStart = now();
  for (const s of statements) {
    if (s.kind !== "function") continue;
    const name = s.defines[0].name;
    const fn = toPreludeFunction(s, reachableFrom(name).has(name));
    result.functions.push(fn);
    try {
      const value = ce.box(fn.definitionJson).evaluate();
      const text = value.isValid
        ? undefined
        : (errorText(value.json) ?? "error");
      if (text !== undefined)
        error(
          "statement-error",
          `the function gives an error: ${text}`,
          s.range,
        );
    } catch (e) {
      error(
        "statement-error",
        `the function gives an error: ${messageOf(e)}`,
        s.range,
      );
    }
  }
  timings.runMs += now() - runStart;
  if (diagnostics.some((d) => d.severity === "error")) return finish(false);

  for (const s of statements) {
    if (s.kind !== "value" || literalConstants.has(s)) continue;
    if (!(yield* runValue(s))) return finish(false);
  }

  // A function that reads a top-level value that is not a number or a
  // boolean (§ 4.2): the function takes the value as a parameter instead.
  for (const read of functionReads) {
    const type = ce.box(read.name).type;
    if (
      type.matches("number") ||
      type.matches(EXTENDED_REAL_TYPE) ||
      type.matches("boolean")
    )
      continue;
    error(
      "function-reads-value",
      `the function \`${read.fn}\` reads \`${read.name}\`, which is not a number or a boolean; pass it as a parameter`,
      read.range,
    );
  }
  if (diagnostics.some((d) => d.severity === "error")) return finish(false);

  // 11. The values.
  for (const name of valueNames) {
    const value = ce.box(name).evaluate();
    const declared = declaredOf.get(name);
    let json: MathJsonExpression;
    try {
      json = withIterationLimit(ce, maxElements, () =>
        snapshotPreludeValue(value, maxElements),
      );
    } catch (e) {
      error(
        "statement-error",
        `the value of \`${name}\` could not be saved: ${messageOf(e)}`,
        [0, source.length],
      );
      return finish(false);
    }
    const entry: PreludeValue = {
      name,
      json,
      type: value.type.toString(),
      route: routeOf.get(name) ?? "interpreted",
      constant: declared?.constant ?? false,
    };
    if (declared?.type !== undefined) entry.declaredType = declared.type;
    result.values.push(entry);
  }
  return finish(true);
}

/** Drain lazy lists while the checked prelude scope still owns their names.
 * Replay must receive values, never a comprehension that runs again on a
 * document engine with a different scope or iteration limit. The element cap
 * was checked before this walk; the worker deadline still bounds its work. */
function snapshotPreludeValue(
  value: Expression,
  maxElements: number,
): MathJsonExpression {
  let remaining = maxElements;
  const snapshot = (expr: Expression): MathJsonExpression => {
    const eager = isFunction(expr, "List") || isFunction(expr, "Tuple");
    const lazy =
      !eager &&
      expr.isCollection === true &&
      expr.type.matches("list<unknown>");
    if (!eager && !lazy) return expr.json;
    const elements: MathJsonExpression[] = [];
    for (const element of eager ? expr.ops : expr.each()) {
      if (--remaining < 0)
        throw new Error(`value exceeds ${maxElements} elements`);
      elements.push(snapshot(lazy ? element.evaluate() : element));
    }
    return [eager ? expr.operator : "List", ...elements];
  };
  return snapshot(value);
}

function messageOf(e: unknown): string {
  if (e instanceof Error) return e.message;
  return String(e);
}

/** The `Function` node of a function statement: the second operand of a
 *  `DefineFunction`, or the value of a lambda `Declare`. */
function functionNodeOf(statement: Json): Json {
  return headOf(statement) === "DefineFunction"
    ? opsOf(statement)[1]
    : declareParts(statement).value;
}

/**
 * The specifiers and the result type of a function, read from the `Typed`
 * wrapper of its body. With no specifier, the type string is the result type
 * alone (`-> integer` gives `"integer"`, `-> (real) -> real` gives
 * `"(real) -> real"`). With a specifier, it is the whole signature: the
 * parameter list, the specifiers, `->` and the result type (`"(n: unknown)
 * scope -> unknown"`; the parser writes `unknown` when no result type is
 * written). So a string is a signature when words stand between the closing
 * parenthesis of its first parenthesized group and the next `->`.
 */
function signatureOf(fnNode: Json): {
  specifiers: readonly string[];
  resultType: string | undefined;
} {
  const body = opsOf(fnNode)[0];
  const type =
    headOf(body) === "Typed"
      ? (opsOf(body)[1] as { str?: unknown } | null)?.str
      : undefined;
  if (typeof type !== "string")
    return { specifiers: [], resultType: undefined };
  const text = type.trim();
  if (text.startsWith("(")) {
    let depth = 0;
    let close = -1;
    for (let i = 0; i < text.length && close < 0; i++) {
      if (text[i] === "(") depth++;
      else if (text[i] === ")" && --depth === 0) close = i;
    }
    const arrow = close < 0 ? -1 : text.indexOf("->", close);
    if (arrow > 0) {
      const between = text.slice(close + 1, arrow).trim();
      if (between !== "") {
        const result = text.slice(arrow + 2).trim();
        return {
          specifiers: between.split(/\s+/),
          resultType: result === "unknown" ? undefined : result,
        };
      }
    }
  }
  return {
    specifiers: [],
    resultType: text === "unknown" ? undefined : text,
  };
}

function toPreludeFunction(
  s: TopStatement,
  recursive: boolean,
): PreludeFunction {
  const name = s.defines[0].name;
  const fnNode = functionNodeOf(s.node);
  const [body, ...params] = opsOf(fnNode);
  const paramNames = params.flatMap((p) =>
    patternSymbols(
      headOf(p) === "Assign" || headOf(p) === "Optional" ? opsOf(p)[0] : p,
    ).map((n) => symbolOf(n)!),
  );
  // A `DefineFunction` statement is kept whole, so that an attribute operand
  // (`hold f(e) = …` adds `Dictionary(KeyValuePair(hold, True))`) reaches the
  // engine. A top-level lambda is given as the `DefineFunction` of its
  // `Function`.
  const definition =
    headOf(s.node) === "DefineFunction"
      ? stripOffsets(s.node)
      : ["DefineFunction", name, stripOffsets(fnNode)];
  const { resultType } = signatureOf(fnNode);
  const fn: PreludeFunction = {
    name,
    params: paramNames,
    bodyJson: stripOffsets(headOf(body) === "Typed" ? opsOf(body)[0] : body),
    definitionJson: definition as unknown as MathJsonExpression,
    recursive,
  };
  if (resultType !== undefined) fn.resultType = resultType;
  return fn;
}

/** Whether a MathJSON statement has an `Assign` outside of a function. */
function hasAssignment(node: Json): boolean {
  const head = headOf(node);
  if (head === "Assign") return true;
  if (head === "Function") return false;
  return opsOf(node).some(hasAssignment);
}

/** Whether a top-level statement is a `const` of one name whose value is a
 *  literal: a number (the parser gives `-2` as `{num: "-2"}`; `Negate` of a
 *  number is also accepted), a string or a boolean. */
function isLiteralConstant(node: Json): boolean {
  if (headOf(node) !== "Declare") return false;
  const { target, value, constant } = declareParts(node);
  if (!constant || symbolOf(target) === undefined) return false;
  const isNumberLiteral = (v: Json): boolean =>
    typeof v === "number" ||
    (v !== null &&
      typeof v === "object" &&
      typeof (v as { num?: unknown }).num === "string");
  if (isNumberLiteral(value)) return true;
  if (headOf(value) === "Negate")
    return opsOf(value).length === 1 && isNumberLiteral(opsOf(value)[0]);
  if (typeof (value as { str?: unknown } | null)?.str === "string") return true;
  if (typeof value === "string" && value.startsWith("'")) return true;
  const sym = symbolOf(value);
  return sym === "True" || sym === "False";
}

/** Whether a boxed statement assigns an exact fraction outside of a
 *  function, at any depth (inside a `Loop`, an `If` or a `Block`): the value
 *  of an `Assign`, or the value of a `let` or `const` (`Declare`). */
function assignsExactFraction(expr: Expression): boolean {
  if (expr.operator === "Function") return false;
  if (!isFunction(expr)) return false;
  if (expr.operator === "Assign" && expr.ops.length >= 2)
    if (hasExactFraction(expr.ops[1].type.type)) return true;
  // The local of a `let` takes a wider type than its value (`let t = 1/k`
  // types `t` as `real`), so the value is read from the type of the
  // `Dictionary` operand, a record whose `value` field has the type of the
  // value.
  if (expr.operator === "Declare")
    for (const op of expr.ops) {
      if (op.operator !== "Dictionary") continue;
      const type = op.type.type as {
        kind?: string;
        elements?: Record<string, unknown>;
      };
      if (type.kind === "record" && hasExactFraction(type.elements?.value))
        return true;
    }
  return expr.ops.some(assignsExactFraction);
}

/** Every symbol name of the program, for fresh local names. */
function collectSymbols(node: Json, out = new Set<string>()): Set<string> {
  const sym = symbolOf(node);
  if (sym !== undefined) out.add(sym);
  const fn = fnOf(node);
  if (fn) for (const op of fn) collectSymbols(op, out);
  return out;
}

/** What a value statement declares: the type annotation and the `const`
 *  flag of each name. */
type DeclaredNames = Map<
  string,
  { type?: string | undefined; constant: boolean }
>;

interface ValueOutcome {
  run: PreludeStatementRun;
  declared: DeclaredNames;
  error?: { code: string; message: string };
}

/** Run one value statement: compiled when it can be, else interpreted. */
function* runValueStatement(
  ce: ComputeEngine,
  s: TopStatement,
  context: {
    top: Frame;
    /** The top-level values that the functions called by the statement
     *  read. */
    valuesReadByCalls: ReadonlySet<string>;
    programSymbols: Set<string>;
    iterationBudget: number;
    source: string;
  },
): PreludeSteps<ValueOutcome> {
  const { top } = context;
  const head = headOf(s.node);
  // The names the statement declares (its root `Declare`) and the top-level
  // names it assigns (the inputs). An `Assign` writes a name that an earlier
  // `let` declared: the static check refuses any other.
  const declared: DeclaredNames = new Map();
  const statement = s.node;
  if (head === "Declare") {
    const parts = declareParts(s.node);
    const single = symbolOf(parts.target) !== undefined;
    for (const { name } of s.defines)
      declared.set(name, {
        type: single ? parts.declaredType : undefined,
        constant: parts.constant,
      });
  }
  const inputs: string[] = [];
  for (const site of s.sites)
    if (
      site.role === "assign" &&
      site.binding === top &&
      !site.inFunction &&
      !declared.has(site.name) &&
      !inputs.includes(site.name)
    )
      inputs.push(site.name);
  // The top-level names that the statement only reads (`circles` in
  // `const G_1 = generations(circles, 1, 1)`). compileValueStatement passes
  // the lists among them to the compiled code as arguments.
  const reads: string[] = [];
  for (const site of s.sites)
    if (
      site.role === "read" &&
      site.binding === top &&
      !site.inFunction &&
      !declared.has(site.name) &&
      !inputs.includes(site.name) &&
      !reads.includes(site.name)
    )
      reads.push(site.name);
  const names = [...inputs, ...declared.keys()];
  const run: PreludeStatementRun = {
    names,
    range: s.range,
    route: "compiled",
    compileMs: 0,
    runMs: 0,
  };
  const outcome: ValueOutcome = { run, declared };

  // The compiled form copies each input to a local and changes the local,
  // and binds the result on the engine when the statement ends. A function
  // that the statement calls reads the engine's value, so it would not see
  // the changes: `for j in 1..3 { s = s + f(1) }` with `f` that reads `s`.
  // Such a statement runs on the interpreter, where `f` reads the value of
  // each pass. This does not depend on the engine declining the compile.
  const staleRead = inputs.find((name) => context.valuesReadByCalls.has(name));
  const compiled: CompiledOutcome =
    staleRead !== undefined
      ? {
          kind: "decline",
          reason: `a function that the statement calls reads \`${staleRead}\`, which the statement assigns`,
          compileMs: 0,
        }
      : yield* compileValueStatement(
          ce,
          statement,
          inputs,
          [...declared.keys()],
          reads,
          context,
        );
  run.compileMs = compiled.compileMs;
  const loops = compiled.kind === "decline" ? undefined : compiled.loops;
  if (loops !== undefined && loops.length > 0) run.parallelLoops = loops;
  if (compiled.kind === "error") {
    run.runMs = compiled.runMs;
    outcome.error = compiled.error;
    return outcome;
  }
  if (compiled.kind === "values") {
    const bindStart = now();
    try {
      for (const name of inputs)
        ce.assign(name, ce.box(compiled.json.get(name)!));
      for (const [name, d] of declared) {
        const dictionary: unknown[] = [
          "Dictionary",
          ["KeyValuePair", "value", compiled.json.get(name)!],
        ];
        if (d.constant) dictionary.push(["KeyValuePair", "constant", "True"]);
        const declare: unknown[] = ["Declare", name];
        if (d.type !== undefined) declare.push({ str: d.type });
        declare.push(dictionary);
        const r = ce.box(declare as unknown as MathJsonExpression).evaluate();
        if (!r.isValid) throw new Error(errorText(r.json) ?? "error");
      }
    } catch (e) {
      run.runMs = compiled.runMs + now() - bindStart;
      outcome.error = {
        code: "statement-error",
        message: `the statement gives an error: ${messageOf(e)}`,
      };
      return outcome;
    }
    run.runMs = compiled.runMs + now() - bindStart;
    return outcome;
  }

  // The interpreter.
  run.route = "interpreted";
  run.declineReason = compiled.reason;
  const interpretStart = now();
  try {
    const value = ce.box(statement as MathJsonExpression).evaluate();
    let text =
      value.operator === "Error"
        ? (errorText(value.json) ?? "error")
        : undefined;
    for (const name of names) {
      if (text !== undefined) break;
      const v = ce.box(name).evaluate();
      if (!v.isValid) text = errorText(v.json) ?? "error";
    }
    if (text !== undefined)
      outcome.error = {
        code: "statement-error",
        message: `the statement gives an error: ${text}`,
      };
  } catch (e) {
    outcome.error = {
      code: "statement-error",
      message: `the statement gives an error: ${messageOf(e)}`,
    };
  }
  run.runMs = now() - interpretStart;
  return outcome;
}

type CompiledOutcome =
  | {
      kind: "values";
      json: Map<string, MathJsonExpression>;
      compileMs: number;
      runMs: number;
      /** The `parallel for` runs that `runAsync()` reported. */
      loops: PreludeParallelLoop[];
    }
  | {
      kind: "decline";
      reason: string;
      compileMs: number;
      /** The decline happened after the list arguments were declared (a
       *  statement that does not box, a compile that declines or throws, a
       *  result that does not match its static type), so the arguments can
       *  be its cause: {@link compileValueStatement} then compiles the
       *  statement again without them. */
      afterArguments?: true;
      /** The time of a run that ended in the decline. */
      runMs?: number;
    }
  | {
      kind: "error";
      error: { code: string; message: string };
      compileMs: number;
      runMs: number;
      loops?: PreludeParallelLoop[];
    };

/**
 * The compiled route of a value statement (§ 4.3 step 1): each input is
 * declared with its type and no value in a pushed scope and copied into a
 * fresh local; the statement reads and writes the local; the block ends with
 * the tuple of the locals and of the declared names.
 *
 * `reads` are the top-level names that the statement only reads. Each one
 * whose value is a list is passed to the compiled code as an argument, with
 * the type of its value, and not bound as a value on the engine: `compile()`
 * writes the value of a bound name into the code and folds it element by
 * element, which made the compile of `const G_3 = generations(circles, 3,
 * 3)` of the `apollonian-gasket` prelude 13.6 ms against 1.6 ms with
 * `circles` as an argument (Compute Engine 0.182.0). Compute Engine 0.183.0
 * made that fold about twice as fast, and CE measured that the argument still
 * saves about 7 ms on each such statement. A scalar stays bound: it folds
 * cheaply, and a folded constant can make the code simpler. When the compile
 * with these arguments declines for a reason that the arguments can cause
 * (the decline has `afterArguments`), the statement is compiled again without
 * them, so the arguments never send a statement to the interpreter; another
 * decline (an input with no compiled form, an exact fraction, a result type
 * that compiled code cannot carry) is the same without them and is returned
 * at once. The time to prepare the arguments, and of a first attempt that
 * declined, is part of the statement's compile time.
 */
function* compileValueStatement(
  ce: ComputeEngine,
  statement: Json,
  inputs: readonly string[],
  declaredNames: readonly string[],
  reads: readonly string[],
  context: {
    top: Frame;
    programSymbols: Set<string>;
    iterationBudget: number;
    source: string;
  },
): PreludeSteps<CompiledOutcome> {
  const prepareStart = now();
  const readLists: { name: string; type: string; value: unknown }[] = [];
  for (const name of reads) {
    const value = ce.box(name).evaluate();
    const carrier = carrierOfType(value.type.type);
    if (carrier?.kind !== "list") continue;
    const js = engineValueToJs(value, carrier, { nonFinite: false });
    if (js !== undefined)
      readLists.push({ name, type: value.type.toString(), value: js });
  }
  const prepareMs = now() - prepareStart;
  if (readLists.length === 0)
    return yield* compileStatementBlock(
      ce,
      statement,
      inputs,
      declaredNames,
      [],
      context,
    );
  const withArguments = yield* compileStatementBlock(
    ce,
    statement,
    inputs,
    declaredNames,
    readLists,
    context,
  );
  withArguments.compileMs += prepareMs;
  if (withArguments.kind !== "decline" || !withArguments.afterArguments)
    return withArguments;
  const plain = yield* compileStatementBlock(
    ce,
    statement,
    inputs,
    declaredNames,
    [],
    context,
  );
  plain.compileMs += withArguments.compileMs + (withArguments.runMs ?? 0);
  return plain;
}

/** {@link compileValueStatement} with the list arguments chosen: each of
 *  `readLists` is declared with its type and no value in the pushed scope,
 *  and its value is passed in the argument bag of the run. */
function* compileStatementBlock(
  ce: ComputeEngine,
  statement: Json,
  inputs: readonly string[],
  declaredNames: readonly string[],
  readLists: readonly { name: string; type: string; value: unknown }[],
  context: {
    top: Frame;
    programSymbols: Set<string>;
    iterationBudget: number;
    source: string;
  },
): PreludeSteps<CompiledOutcome> {
  const { top, programSymbols, iterationBudget, source } = context;
  // The current values of the inputs, as JavaScript values.
  const inputTypes: string[] = [];
  const inputCarriers: Carrier[] = [];
  const inputValues: Record<string, unknown> = {};
  for (const name of inputs) {
    const value = ce.box(name).evaluate();
    const carrier = carrierOfType(value.type.type);
    const state = { nonFinite: false };
    const js = carrier ? engineValueToJs(value, carrier, state) : undefined;
    if (!carrier || js === undefined)
      return {
        kind: "decline",
        reason: `the value of \`${name}\` (${value.type.toString()}) has no compiled form`,
        compileMs: 0,
      };
    inputTypes.push(inputTypeOf(carrier, state.nonFinite));
    inputCarriers.push(carrier);
    inputValues[name] = js;
  }
  const locals = inputs.map((name) => {
    let local = `${name}Local`;
    for (let i = 1; programSymbols.has(local); i++) local = `${name}Local${i}`;
    programSymbols.add(local);
    return local;
  });
  const localOf = new Map(inputs.map((name, i) => [name, locals[i]]));
  const rewritten = walkNode(
    statement,
    { frames: [top], inFunction: false, source },
    (site) =>
      site.binding === top && (site.role === "read" || site.role === "assign")
        ? localOf.get(site.name)
        : undefined,
  );
  const block = [
    "Block",
    ...inputs.map((name, i) => [
      "Declare",
      locals[i],
      ["Dictionary", ["KeyValuePair", "value", name]],
    ]),
    rewritten,
    ["Tuple", ...locals, ...declaredNames],
  ];
  const resultNames = [...inputs, ...declaredNames];

  const compileStart = now();
  // An assignment whose value is an exact fraction (`s1 = s1 + 1/k` with
  // `s1` an integer) runs on the interpreter, which keeps it exact. The
  // statement is boxed as written, before the inputs are declared `real`
  // below: that declaration widens the type of the value to `real`. The
  // pushed scope keeps any name that boxing declares off the engine.
  if (hasAssignment(statement)) {
    ce.pushScope();
    try {
      if (assignsExactFraction(ce.box(statement as MathJsonExpression)))
        return {
          kind: "decline",
          reason: "an assigned value is an exact fraction",
          compileMs: now() - compileStart,
        };
    } catch (e) {
      return {
        kind: "decline",
        reason: `the statement does not box: ${messageOf(e)}`,
        compileMs: now() - compileStart,
      };
    } finally {
      ce.popScope();
    }
  }
  let carriers: Carrier[];
  let program: CompiledRunRequest["result"];
  ce.pushScope();
  try {
    for (let i = 0; i < inputs.length; i++)
      ce.declare(inputs[i], inputTypes[i]);
    for (const read of readLists) ce.declare(read.name, read.type);
    const boxed = ce.box(block as unknown as MathJsonExpression);
    if (!boxed.isValid)
      return {
        kind: "decline",
        reason: `the statement does not box: ${errorText(boxed.json) ?? "error"}`,
        compileMs: now() - compileStart,
        afterArguments: true,
      };
    // The local of a `let` takes a wider type than its value (`let r = 1/3`
    // types the local `real`, the value `rational`), so an exact fraction is
    // found on the value itself.
    const declaredValue =
      headOf(statement) === "Declare"
        ? declareParts(statement).value
        : undefined;
    if (
      declaredValue !== undefined &&
      hasExactFraction(ce.box(declaredValue as MathJsonExpression).type.type)
    )
      return {
        kind: "decline",
        reason: "the value is an exact fraction",
        compileMs: now() - compileStart,
      };
    const compiled = resolveCECompile(boxed, {
      to: "javascript",
      iterationBudget,
    });
    if (compiled.success !== true || typeof compiled.run !== "function")
      return {
        kind: "decline",
        reason: "the compile declines",
        compileMs: now() - compileStart,
        afterArguments: true,
      };
    const tuple = isFunction(boxed, "Block")
      ? boxed.ops[boxed.ops.length - 1]
      : undefined;
    const elements = isFunction(tuple, "Tuple") ? tuple.ops : [];
    if (elements.length !== resultNames.length)
      return {
        kind: "decline",
        reason: "the block has no result tuple",
        compileMs: now() - compileStart,
      };
    carriers = [];
    for (let i = 0; i < elements.length; i++) {
      // A local that copies an input can lose its static type in the
      // statement (`L = fill(…, L)` types `L` as `collection<any>` when
      // the function has no result type). Its value then is read with the
      // carrier of the input, and a value of another shape runs the
      // statement on the interpreter.
      const carrier =
        carrierOfType(elements[i].type.type) ??
        (i < inputCarriers.length ? inputCarriers[i] : null);
      if (!carrier)
        return {
          kind: "decline",
          reason: `\`${resultNames[i]}\` has the type ${elements[i].type.toString()}, which compiled code cannot carry`,
          compileMs: now() - compileStart,
        };
      carriers.push(carrier);
    }
    // The result itself, so that the caller can call its `runAsync()`.
    program = compiled as unknown as CompiledRunRequest["result"];
  } catch (e) {
    return {
      kind: "decline",
      reason: `the compile throws: ${messageOf(e)}`,
      compileMs: now() - compileStart,
      afterArguments: true,
    };
  } finally {
    ce.popScope();
  }
  const compileMs = now() - compileStart;

  const runStart = now();
  let values: unknown;
  const loops: PreludeParallelLoop[] = [];
  try {
    values = yield {
      result: program,
      inputs: {
        ...inputValues,
        ...Object.fromEntries(readLists.map((read) => [read.name, read.value])),
      },
      loops,
    };
  } catch (e) {
    const runMs = now() - runStart;
    const cancelled = (e as { name?: unknown })?.name === "CancellationError";
    return {
      kind: "error",
      error: cancelled
        ? {
            code: "iteration-budget",
            message: `the statement did not finish: ${messageOf(e)}`,
          }
        : {
            code: "statement-error",
            message: `the statement gives an error: ${messageOf(e)}`,
          },
      compileMs,
      runMs,
      loops,
    };
  }
  const runMs = now() - runStart;
  const json = new Map<string, MathJsonExpression>();
  try {
    const items = arrayOf(values);
    if (items.length !== resultNames.length) throw new CarrierMismatch();
    for (let i = 0; i < items.length; i++)
      json.set(resultNames[i], reboxValue(items[i], carriers[i]));
  } catch (e) {
    if (!(e instanceof CarrierMismatch)) throw e;
    return {
      kind: "decline",
      reason: "the compiled result does not match its static type",
      compileMs,
      afterArguments: true,
      runMs,
    };
  }
  return { kind: "values", json, compileMs, runMs, loops };
}
