import type { MathJsonExpression } from '../math-json/types.js';
import {
  machineValue,
  operand,
  operands,
  operator,
  stringValue,
  symbol,
} from '../math-json/utils.js';

/**
 * A call an error can be attributed to: the operator being applied and the
 * 1-based index of the argument at fault.
 *
 * The two tiers obtain one differently — at run time it is read from the
 * error's `ErrorTrace` breadcrumb ({@link traceFrames}); at canonicalization
 * time there is no breadcrumb yet, so it comes from where the error node sits
 * in the canonical tree ({@link enclosingFrame}) — but it means the same
 * thing, so everything downstream is shared.
 */
export type ErrorFrameRef = { name: string; index: number };

/**
 * What the caller knows about the canonical form of the statement, for a call
 * whose canonical form does not keep the written order of its operands.
 *
 * Canonicalization sorts the operands of a commutative operator and flattens
 * the nested calls of an associative one. With `op` a user function marked
 * `commutative`, `op(z, w)` is `op(w, z)`, so its frame `op argument 1` names
 * `w`, the SECOND written operand. A canonical operand keeps the source range
 * of the written operand it was made from, and the caller that boxed the
 * statement can read it. This maps a frame's argument index back to the
 * written operand.
 */
export type CanonicalOrder = {
  /** Whether canonicalization sorts or flattens the operands of a call of
   * `operatorName`: a library operator such as `Xor`, or a user function
   * marked `commutative` or `associative`. */
  reorders(operatorName: string): boolean;
  /** The source range of operand `index` (1-based) of the canonical call of
   * `operatorName` whose source range is `callRange`. `undefined` when there
   * is no such canonical call, or when its operand has no source range (a
   * number made by folding `2 * x * 3`). The index of an error that the
   * evaluation of an operand of `Add` or `Multiply` made also counts the
   * operands of the canonical call when the engine finds the operand whose
   * evaluation returned the error: a call, or a symbol that holds the error
   * or the expression that made it (`_evaluatedOperandResultError()` in
   * `boxed-expression/boxed-function.ts`). When it finds no such operand,
   * the index counts the operands of the result of the evaluation. No such
   * case is known. The frame of an error that the handler of `Add` or
   * `Multiply` makes itself (`s * Cos(x)` with `s = "a"`) also counts the
   * operands of the canonical call: it names the operand whose value the
   * error names (`_operandValueTypeError()` in
   * `boxed-expression/boxed-function.ts`). */
  argumentOffsets(
    operatorName: string,
    callRange: [number, number],
    index: number
  ): [number, number] | undefined;
};

/**
 * The frames that {@link locateError} skipped because they did not make the
 * error in the statement (their selected argument is a literal that is not
 * the value the error names), by index in the frame list, and the written
 * calls those frames selected.
 */
type Rejected = {
  frames: Set<number>;
  calls: Set<MathJsonExpression>;
};

/**
 * The frames of an error's `ErrorTrace` breadcrumb (engine design §2a),
 * innermost first: `["ErrorTrace", ["ErrorFrame", "'Ln'", 1], ["ErrorFrame",
 * "'Add'", 2]]`. The breadcrumb is the LAST operand of the `["Error", …]`
 * value and is identified by its head, never by position.
 *
 * `ErrorBroadcast` entries are skipped: they locate an ELEMENT of a broadcast,
 * not a call in the source.
 */
export function traceFrames(error: MathJsonExpression): ErrorFrameRef[] {
  const ops = [...operands(error)];
  const trace = ops[ops.length - 1];
  if (trace === undefined || operator(trace) !== 'ErrorTrace') return [];

  const frames: ErrorFrameRef[] = [];
  for (const frame of operands(trace)) {
    if (operator(frame) !== 'ErrorFrame') continue;
    const name = stringValue(operand(frame, 1));
    const index = machineValue(operand(frame, 2));
    if (name === null || index === null) continue;
    frames.push({ name, index });
  }
  return frames;
}

/**
 * The value that an error names as its cause: the operand that follows the
 * error code (`["Error", code, where, trace]`), such as `'a'` for the error
 * of `Ln("a")`. `undefined` when the error has no such operand.
 *
 * Only an `incompatible-type` error gives a value: `ce.typeError()` puts the
 * argument itself after the code. Other errors put a text there, often the
 * `toString()` of the argument: the error of `Sqrt(2, "a")` is
 * `["Error", "'unexpected-argument'", "'\"a\"'"]`, with the quotes of the
 * string in the text, and the error of `Sqrt(2, 3)` has the text `'3'`, not
 * the number `3`. Such a text, compared with the written argument as a value,
 * would show that the argument is not the cause.
 */
export function offendingValue(
  error: MathJsonExpression
): MathJsonExpression | undefined {
  const cause = operand(error, 1);
  const code =
    operator(cause) === 'ErrorCode'
      ? stringValue(operand(cause, 1))
      : stringValue(cause);
  if (code !== 'incompatible-type') return undefined;
  const where = operand(error, 2);
  if (where === null || operator(where) === 'ErrorTrace') return undefined;
  return where;
}

/**
 * The call an error node sits inside — `(operator, 1-based operand index)` of
 * its parent — found by identity in the tree the error was collected from.
 *
 * This is the breadcrumb's stand-in for a **canonicalization-time** error,
 * which has none: the `ErrorTrace` frames are recorded as an error BUBBLES
 * during evaluation, so an error still embedded in the canonical tree —
 * `["Ln", ["Error", "'missing'"]]` — carries only its position. That position
 * says the same thing for an argument-validation error, because such an error
 * is minted while checking the arguments of the node it is embedded in.
 *
 * `undefined` when the node is not found, or is the root (no enclosing call).
 */
export function enclosingFrame(
  root: MathJsonExpression,
  error: MathJsonExpression
): ErrorFrameRef | undefined {
  const head = operator(root);
  if (head === '') return undefined;
  let index = 0;
  for (const op of operands(root)) {
    index += 1;
    if (op === error) return { name: head, index };
    const nested = enclosingFrame(op, error);
    if (nested !== undefined) return nested;
  }
  return undefined;
}

/**
 * Narrow an error's source anchor from the whole statement down to the
 * innermost frame that still maps onto the parsed source — the difference
 * between underlining all of `s |> Map(_ => Length(Characters(s)), _)` and
 * underlining the `s` inside `Characters(s)`, or between underlining a
 * 40-line function definition and underlining the one extra argument inside
 * it.
 *
 * The frames were recorded against a tree that is structurally different from
 * the raw AST (canonicalization applies pipe sugar, inserts `Block` wrappers,
 * rewrites operators), so they cannot be walked positionally. Instead they are
 * matched by operator NAME: innermost first, the first frame whose operator
 * occurs exactly ONCE in the statement subtree wins, and the frame's operand
 * (or, when that operand carries no offsets, the matched call) supplies the
 * range. A vanished name (a canonicalization-minted wrapper) falls through to
 * the next outer frame; the fallback is the statement range.
 *
 * An ambiguous name (two `If` calls in `if a { 0 } else if b { g("x") } else
 * { 1 }`, whose frames are `If argument 2, If argument 3`) is first resolved
 * by walking the frames from the outermost one down from the statement node
 * ({@link walkToFrame}): each frame selects its call inside the argument that
 * the next outer frame selected. Only when that walk cannot decide does the
 * frame fall through to the next outer frame.
 *
 * A frame that names no written call of the statement (a frame recorded in
 * the body of a called function, in an earlier statement whose value the
 * statement reads, or by a call that canonicalization made) is not used when
 * no call of its operator is inside the argument that an outer frame of the
 * statement selected ({@link rejectFramesOutsideScope}).
 *
 * A frame of a call that canonicalization renamed (`Exp(w)` is
 * `Power(ExponentialE, w)`, `w/2` is `Multiply(1/2, w)`) is first changed into
 * the frame of the written call ({@link renamedCallFrame}), so that it
 * selects the written argument. This is done only for a written call that is
 * the value of the statement or the argument that an outer frame of the
 * statement selected ({@link rejectFramesOutsideScope}).
 */
export function locateError(
  frames: readonly ErrorFrameRef[],
  stmt: MathJsonExpression,
  fallback: [number, number],
  /** The declared slot names of a callee, for anchoring inside a NAMED call
   * (`calleeSlotNames`, boxed-expression/named-arguments.ts, partially
   * applied to the engine). A frame's argument index counts DECLARATION
   * slots — the seam permutes a named call into declaration order before
   * anything downstream runs — while the raw call node here still lists the
   * arguments AS WRITTEN, wrapped in `NamedArgument` carriers. Without the
   * names the two orders cannot be reconciled, so the anchor stays on the
   * whole call rather than guessing an argument. `undefined` (or a resolver
   * answering `undefined`) only affects calls that contain a carrier;
   * all-positional calls index directly, as they always did. */
  slotNamesFor?: (
    operatorName: string
  ) => readonly (string | undefined)[] | undefined,
  /** Which order the frames' argument indexes count in. `'declaration'` (the
   * default) is every error of a successfully normalized call — the seam
   * permuted the operands before the error was minted, and `slotNamesFor`
   * maps the slot back to the written argument. `'written'` is the seam's own
   * normalization FAILURES (`errorIndexCountsWrittenArguments`,
   * boxed-expression/named-arguments.ts): the call was never permuted, so
   * the index already counts written positions and is used directly. */
  frameIndexOrder: 'declaration' | 'written' = 'declaration',
  /** Maps the argument index of a frame of a reordered call back to the
   * written operand (see {@link CanonicalOrder}). Without it, the index of a
   * frame of `Add`, `Multiply`, `Xor` or `Set` is used as a written position
   * when no inner frame names an operator of the statement, which is wrong
   * when canonicalization moved the operand. */
  canonicalOrder?: CanonicalOrder,
  /** The value that the error names as the cause (see
   * {@link offendingValue}), such as `"a"` for the error of `Ln("a")`. */
  offending?: MathJsonExpression
): { range: [number, number]; call?: MathJsonExpression } {
  // The frames as recorded name the canonical calls. `rejectFramesOutsideScope`
  // changes the frames of renamed calls in `written`, which is used from
  // here on, and compares the frames as recorded with the canonical operands.
  const written = [...frames];
  const rejected: Rejected = { frames: new Set(), calls: new Set() };
  rejectFramesOutsideScope(
    written,
    frames,
    stmt,
    frameIndexOrder,
    slotNamesFor,
    canonicalOrder,
    rejected
  );
  frames = written;
  for (let k = 0; k < frames.length; k++) {
    if (rejected.frames.has(k)) continue;
    const { name } = frames[k];
    const matches: MathJsonExpression[] = [];
    findWrittenCalls(stmt, name, matches);
    // When the argument is not sure, the whole call is the range: it
    // contains the error.
    const callOf = (call: MathJsonExpression) =>
      frameArgument(
        frames,
        k,
        call,
        stmt,
        stmt,
        frameIndexOrder,
        slotNamesFor,
        canonicalOrder,
        rejected
      ) ?? { call: clusterTop(stmt, call, name), arg: null };
    let found: { call: MathJsonExpression; arg: MathJsonExpression | null };
    if (matches.length === 1) {
      found = callOf(matches[0]);
    } else if (matches.length > 1) {
      const reached = { scope: stmt };
      const walked = walkToFrame(
        frames,
        k,
        stmt,
        frameIndexOrder,
        slotNamesFor,
        canonicalOrder,
        rejected,
        reached
      );
      if (walked !== undefined) found = walked;
      else {
        if (offending === undefined) continue;
        // In `Ln("a") + Ln(2)`, both calls match the frame `Ln argument 1`,
        // and the walk cannot select one. The `2` of `Ln(2)` is not the
        // value `"a"` that the error names, so `Ln(2)` did not make the
        // error. The argument of `Ln("a")` is the value, so `Ln("a")` is
        // the call of the frame.
        //
        // Only the calls in the argument that the outer frames selected are
        // compared (`reached.scope`): with `let x = Ln("a")`, the error of
        // `if n == 1 { Ln("a") } else { x + Ln(2) + Ln(3) }` has the frame
        // `If argument 3`, and the `Ln("a")` of the other branch did not
        // run. A call whose argument is not a literal (`Ln(y)`) is never
        // selected this way: the error of `x + Ln(y) + Ln(2)` is in `x`, not
        // in `y`. When no call can have made the error
        // (`x + Ln(2) + Ln(3)`), the frame is skipped, as for one call
        // below.
        const inScope: MathJsonExpression[] = [];
        // Every call is compared, not only the first two.
        findWrittenCalls(reached.scope, name, inScope, Infinity);
        const checks = inScope.map((call) =>
          literalArgumentMatch(
            call,
            frames[k],
            offending,
            frameIndexOrder,
            slotNamesFor,
            canonicalOrder
          )
        );
        if (checks.length > 0 && checks.every((check) => check === 'is-not')) {
          rejected.frames.add(k);
          for (const call of inScope) rejected.calls.add(call);
          continue;
        }
        const possible = checks.filter((check) => check !== 'is-not');
        if (possible.length !== 1 || possible[0] !== 'is') continue;
        found = callOf(inScope[checks.indexOf('is')]);
      }
    } else continue;

    // The frame can come from a call in an EARLIER statement: with
    // `let x = Ln("a")`, the error of `let v = x + Ln(2)` has the frames
    // `Ln argument 1, Add argument 1`, and the `Ln` frame selects the `2` of
    // `Ln(2)`. A literal argument that is not the value the error names did
    // not make the error. The frame is then skipped, and the outer frames
    // treat its call as a call that did not make the error.
    if (
      offending !== undefined &&
      found.arg !== null &&
      compareLiteral(found.arg, offending) === 'is-not'
    ) {
      rejected.frames.add(k);
      rejected.calls.add(found.call);
      continue;
    }

    const range = nodeOffsets(found.arg) ?? nodeOffsets(found.call);
    // The matched CALL travels with the range: a caller quoting the error's
    // surroundings wants `IndexOf(digits, cs[i], 23)`, not the one argument
    // the range underlines and not the whole enclosing statement.
    if (range !== undefined) return { range, call: found.call };
  }
  return { range: fallback };
}

/**
 * The frame of the written call `node` for `frame`, when canonicalization
 * made the call of `frame` from `node`, a written call of another operator.
 * `undefined` when the frame is kept as it is.
 *
 * The canonical form of `Exp(w)` is `Power(ExponentialE, w)`, and that of
 * `w/2` is `Multiply(1/2, w)`, so the frames of their errors are
 * `Power argument 2` and `Multiply argument 2`, and the statement has no
 * written call of these operators. A canonical call keeps the source range of
 * the written call it was made from, and its operand keeps the source range of
 * the written operand. The frame `Power argument 2` thus becomes
 * `Exp argument 1`, and `Multiply argument 2` becomes `Divide argument 1`.
 * The argument is the written operand that contains the canonical operand: in
 * `-w/2`, whose canonical form is `Multiply(-1/2, w)`, the written `-w`.
 *
 * The caller gives only a `node` that the error went through: the value of
 * the statement, or the argument that an outer frame selected. A frame
 * recorded in an earlier statement or in a called function can have the
 * operator of a canonical call of the statement, and that call did not make
 * the error: with `function g(x) { Ln(x) * 2 }`, the frame
 * `Multiply argument 2` of `[u/2, g("a")]` is not the frame of `u/2`.
 *
 * The frame is kept when `node` is not a call, when it is a call of the
 * operator of the frame, when the canonical call at its source range is not a
 * call of that operator or its operand has no source range, and when no
 * written operand contains the canonical operand. It is also kept when `node`
 * is a call of an operator whose canonical form sorts or merges its operands,
 * because the index of a frame of such an operator counts canonical operands.
 */
function renamedCallFrame(
  frame: ErrorFrameRef,
  node: MathJsonExpression,
  canonicalOrder: CanonicalOrder
): ErrorFrameRef | undefined {
  const { name, index } = frame;
  const head = operator(node);
  // A written subtraction is part of the canonical sum (see
  // `clusterOperators`).
  if (
    head === '' ||
    head === name ||
    REORDERED_OPERATORS.has(head) ||
    head === 'Subtract' ||
    canonicalOrder.reorders(head)
  )
    return undefined;
  const callRange = nodeOffsets(node);
  if (callRange === undefined) return undefined;
  const argRange = canonicalOrder.argumentOffsets(name, callRange, index);
  if (argRange === undefined) return undefined;
  const at = [...operands(node)].findIndex((op) => {
    const o = nodeOffsets(op);
    return o !== undefined && o[0] <= argRange[0] && argRange[1] <= o[1];
  });
  return at < 0 ? undefined : { name: head, index: at + 1 };
}

/**
 * The nodes that a frame of the statement `stmt` can name when its written
 * call is `scope` (see {@link isDirectlyAt}), or, when `scope` is
 * `undefined`, the value of the statement: `stmt`, or the value inside the
 * nodes that the parser adds around it (the `Declare` of a `let`, its
 * `Dictionary` and `KeyValuePair`, the `Assign` of an assignment).
 *
 * A written call that spans the whole statement is not such a node: the
 * elements of the list of the statement `[u/2, z]` are not the value of the
 * statement, and a list records no frame for its elements.
 */
function nodesAt(
  stmt: MathJsonExpression,
  scope: MathJsonExpression | undefined
): MathJsonExpression[] {
  const nodes: MathJsonExpression[] = [];
  if (scope !== undefined) {
    let node = scope;
    nodes.push(node);
    while (operator(node) === 'Program' || operator(node) === 'Block') {
      const ops = [...operands(node)];
      if (ops.length !== 1) break;
      node = ops[0];
      nodes.push(node);
    }
    return nodes;
  }
  const visit = (node: MathJsonExpression): void => {
    nodes.push(node);
    if (STATEMENT_WRAPPERS.has(operator(node)))
      for (const op of operands(node)) visit(op);
  };
  visit(stmt);
  return nodes;
}

/** The nodes that the parser adds around the value of a statement:
 * `let v = w/2` is `Declare(v, Dictionary(KeyValuePair("value", w/2)))`, and
 * `v = w/2` is `Assign(v, w/2)`. */
const STATEMENT_WRAPPERS = new Set([
  'Declare',
  'Dictionary',
  'KeyValuePair',
  'Assign',
]);

/**
 * Add to `rejected.frames` the frames that name no written call of the
 * statement. The frames of a runtime error record each call that the error
 * passes through, innermost first. The frames of the written calls of the
 * statement come last, and each one names a call inside the argument that
 * the next outer frame of the statement selected. The frames before them were
 * recorded in the body of a function that the statement calls, in an earlier
 * statement whose value the statement reads, or by a call that
 * canonicalization or evaluation made. The call of the function and the read
 * of the variable record no frame.
 *
 * Example: with `function g(x) { Ln(x) + 1 }`, the error of
 * `let v = y + g("a")` has the frames `Ln argument 1, Add argument 1,
 * Add argument 2`. The last frame selects the operand `g("a")` of the
 * statement. The frame `Add argument 1` comes from the body of `g`, but its
 * operator also occurs in the statement, and the argument 1 of the sum of the
 * statement is `y`. No call of `Add` is inside `g("a")`, so this frame is
 * rejected, and the error is located at `g("a")`.
 *
 * The frames are read from the outermost one, and a frame whose operator
 * does not occur in the statement is skipped. A frame is a frame of the
 * statement only when its written call is known:
 *
 * - The first such frame names the value of the statement (`y + g("a")`),
 *   not a call inside it. A call inside it can be a call that the evaluation
 *   made: the sum of the terms of `Sum(Ln(w) + k, k, 1, 3)` records frames
 *   of `Add` that are not the frames of the written `Ln(w) + k`.
 * - Each next frame names the argument that the frame before it selected,
 *   or the one statement of that argument when it is a block. A call between
 *   them that records no frame (the elements of a list) would leave the
 *   frame unsure.
 * - The canonical call at the source range of the written call has, at the
 *   frame's index, the operand made from the selected argument. A call that
 *   canonicalization made can have the operator of the written call:
 *   `Exp(Ln(w))^y` is `Power(ExponentialE, Ln(w)·y)`, and its frame
 *   `Power argument 2` does not name the written `y`.
 *
 * The argument that a frame of the statement selects is the scope of the
 * next inner frame. The error went through the scope, so a frame with no
 * written call inside the scope names no written call of the statement, and
 * it is rejected. Such a frame does no harm when it is rejected, also when a
 * function that the scope calls recorded it: in `y^2 + g(w)`, a frame
 * `Power argument 2` recorded in the body of `g` would select the `2` of
 * `y^2`.
 *
 * Before these tests, a frame of a call that canonicalization renamed is
 * changed into the frame of the written call at the scope, or of the value
 * of the statement for the outermost frame ({@link renamedCallFrame}): in
 * `y^2 + Exp(Ln(w))`, the frame `Power argument 2` of `Exp` becomes
 * `Exp argument 1`, and selects `Ln(w)`. A frame recorded outside the
 * statement is changed only when the written call at the scope is a renamed
 * call of its operator, and then only into a frame of that call, which the
 * error went through. When a frame has a written call inside the scope that is not
 * known to be its call, the reading stops, and rejects nothing more. The
 * inner frames are not used to
 * select the argument, because they are not yet known to come from the
 * statement. Without `canonicalOrder`, or when the frame indexes count
 * written arguments, nothing is rejected.
 */
function rejectFramesOutsideScope(
  /** A copy of the frames as recorded. The frame of a renamed call of the
   * statement is changed here into the frame of the written call. */
  frames: ErrorFrameRef[],
  /** The frames as recorded: they name the canonical calls. */
  canonicalFrames: readonly ErrorFrameRef[],
  stmt: MathJsonExpression,
  frameIndexOrder: 'declaration' | 'written',
  slotNamesFor:
    | ((operatorName: string) => readonly (string | undefined)[] | undefined)
    | undefined,
  canonicalOrder: CanonicalOrder | undefined,
  rejected: Rejected
): void {
  // The frame index of a named call counts declaration slots, and the source
  // range of the canonical operand is the only check of the argument.
  if (canonicalOrder === undefined || frameIndexOrder !== 'declaration') return;
  // The argument that the last frame of the statement selected; `undefined`
  // before a frame selected one.
  let scope: MathJsonExpression | undefined;
  for (let j = frames.length - 1; j >= 0; j--) {
    // The error went through the written call at `scope`: when
    // canonicalization renamed it, the frame names the written call.
    const renamed = nodesAt(stmt, scope)
      .map((node) => renamedCallFrame(frames[j], node, canonicalOrder))
      .filter((frame) => frame !== undefined);
    if (renamed.length === 1) frames[j] = renamed[0];
    const { name } = frames[j];
    const calls: MathJsonExpression[] = [];
    findWrittenCalls(stmt, name, calls, Infinity);
    if (calls.length === 0) continue;

    let candidates: MathJsonExpression[];
    if (scope === undefined) {
      candidates = calls.filter((call) => isStatementValue(stmt, call));
    } else {
      const inScope = calls.filter((call) => pathTo(scope!, call, []));
      if (inScope.length === 0) {
        // The error went through `scope`, and no written call of the frame
        // is inside it: the frame names no written call of the statement.
        rejected.frames.add(j);
        continue;
      }
      candidates = inScope.filter((call) => isDirectlyAt(scope!, call));
    }
    if (candidates.length !== 1) return;

    // The inner frames are treated as rejected, so that they do not select
    // the argument (see `frameArgument`): they are not yet known to come
    // from the statement.
    const withoutInner: Rejected = {
      frames: new Set(rejected.frames),
      calls: rejected.calls,
    };
    for (let i = 0; i < j; i++) withoutInner.frames.add(i);
    const selected = frameArgument(
      frames,
      j,
      candidates[0],
      scope ?? stmt,
      stmt,
      frameIndexOrder,
      slotNamesFor,
      canonicalOrder,
      withoutInner
    );
    if (selected === undefined || selected.arg === null) return;

    // The canonical call at the source range of the written call must have,
    // at the frame's index, the operand made from the selected argument.
    // `Exp(u)^y` is `Power(ExponentialE, u·y)`: the canonical operand 2 is
    // not the written `y`. The frame as recorded names the canonical call: the
    // frame `Exp argument 1` of a written `Exp(w)` was `Power argument 2`.
    const callRange = nodeOffsets(selected.call);
    const argRange = nodeOffsets(selected.arg);
    const canonicalRange =
      callRange === undefined
        ? undefined
        : canonicalOrder.argumentOffsets(
            canonicalFrames[j].name,
            callRange,
            canonicalFrames[j].index
          );
    if (
      argRange === undefined ||
      canonicalRange === undefined ||
      argRange[0] !== canonicalRange[0] ||
      argRange[1] !== canonicalRange[1]
    )
      return;

    scope = selected.arg;
  }
}

/**
 * Whether `call` is the value of the statement `stmt`: `stmt` itself, or a
 * node inside nodes that span the whole statement (the `Declare` of a `let`
 * and its `Dictionary`, the `Assign` of an assignment), and that are thus not
 * written calls.
 */
function isStatementValue(
  stmt: MathJsonExpression,
  call: MathJsonExpression
): boolean {
  const path: MathJsonExpression[] = [];
  if (!pathTo(stmt, call, path)) return false;
  const whole = nodeOffsets(stmt);
  return path.slice(0, -1).every((node) => {
    const o = nodeOffsets(node);
    return (
      o === undefined ||
      (whole !== undefined && o[0] === whole[0] && o[1] === whole[1])
    );
  });
}

/** Whether `call` is `arg`, or the one statement of a block `arg` (also
 * through nested blocks), such as the `Ln(w)` of the branch `{ Ln(w) }`. */
function isDirectlyAt(
  arg: MathJsonExpression,
  call: MathJsonExpression
): boolean {
  let node = arg;
  while (node !== call && (operator(node) === 'Program' || operator(node) === 'Block')) {
    const ops = [...operands(node)];
    if (ops.length !== 1) return false;
    node = ops[0];
  }
  return node === call;
}

/**
 * Find the call of frame `k` when its operator occurs more than once in the
 * statement, by walking the frames from the OUTERMOST one down to frame `k`.
 *
 * The walk starts with the whole statement as its scope. Each frame selects
 * the one call of its operator in the scope that is not inside another call
 * of the same operator in the scope (the shallowest call), and the argument
 * that the frame's index names becomes the scope of the next inner frame.
 * The shallowest call is the correct one because the frames of a runtime
 * error record each call that the error passes through: when an `If` on the
 * error's way is inside another `If`, the outer `If` is also on the way and
 * has the next outer frame. In `if a { 0 } else if b { g("x") } else { 1 }`
 * the frame `If argument 3` selects the outer `if` and its `else` argument,
 * and in that argument the frame `If argument 2` selects the inner `if` and
 * its `{ g("x") }` argument.
 *
 * A frame whose operator does not occur in the statement at all is a call
 * that canonicalization made (such as a `Block` wrapper), and the walk skips
 * it. The walk stops with `undefined` when a frame has no call or two
 * shallowest calls in its scope, and when an argument cannot be identified
 * (a named call whose declared slot names are not known).
 *
 * The frames can be incomplete: a call that does not record a frame is not in
 * the list, and the static check gives only the innermost frame. When no
 * outer frame selected a call, the shallowest call for frame `k` (the frame
 * whose argument is the result) can thus be an outer call of the same
 * operator, not the call that made the error. In that case the walk also
 * requires that every other call of the operator inside the selected call is
 * inside the selected argument, so that the result always contains the call
 * that made the error. For example, the static check reports
 * `Arctan2(1, Arctan2("a", 1))` with the one frame `Arctan2 argument 1`: the
 * outer call's argument 1 is `1`, which does not contain the inner call, so
 * the walk gives `undefined`. When an outer frame selected a call, its
 * argument holds the error, and this condition does not apply: in
 * `if a { 0 } else if b { g("x") } else if c { 1 } else { 2 }` the `if b`
 * that frame `If argument 2` selects has another `if` in its argument 3.
 */
function walkToFrame(
  frames: readonly ErrorFrameRef[],
  k: number,
  stmt: MathJsonExpression,
  frameIndexOrder: 'declaration' | 'written',
  slotNamesFor?: (
    operatorName: string
  ) => readonly (string | undefined)[] | undefined,
  canonicalOrder?: CanonicalOrder,
  rejected?: Rejected,
  /** Set to the last argument that an outer frame selected, also when the
   * walk then stops with `undefined`. It stays `stmt` when no outer frame
   * selected a call. */
  reached?: { scope: MathJsonExpression }
): { call: MathJsonExpression; arg: MathJsonExpression | null } | undefined {
  let scope = stmt;
  // Whether an outer frame selected a call (and its argument is `scope`).
  let narrowed = false;
  for (let j = frames.length - 1; j >= k; j--) {
    const { name } = frames[j];
    if (j > k) {
      // A rejected frame did not make the error in this statement.
      if (rejected?.frames.has(j)) continue;
      const inStatement: MathJsonExpression[] = [];
      findWrittenCalls(stmt, name, inStatement);
      if (inStatement.length === 0) continue;
    }

    // A written subtraction is also a call of an `Add` frame (see
    // `clusterOperators`), so the calls of both operators are searched
    // together. In `Sqrt(y + 2) - s`, the shallowest one is the subtraction,
    // not the `y + 2` inside `Sqrt`.
    const shallowest: MathJsonExpression[] = [];
    findShallowestByOperators(scope, clusterOperators(name), shallowest);
    if (shallowest.length !== 1) return undefined;
    const selected = frameArgument(
      frames,
      j,
      shallowest[0],
      scope,
      stmt,
      frameIndexOrder,
      slotNamesFor,
      canonicalOrder,
      rejected
    );
    if (selected === undefined) return undefined;
    const { call, arg } = selected;

    if (j === k) {
      // Without an argument the result is the whole call, which contains
      // every call inside it.
      if (!narrowed && arg !== null) {
        // For `Add` and `Multiply`, the operands are read through the nested
        // calls that canonicalization merges with `call`: in
        // `x * y * Sin(s)`, the written `x * y` is not a second product, so
        // it does not make the argument `Sin(s)` unsure. Other reordered
        // operators do not always merge their nested calls (`Set` keeps a
        // nested set), so their operands are read as written.
        const merges = name === 'Add' || name === 'Multiply';
        const parts = merges ? clusterLeaves(call, name) : operands(call);
        for (const op of parts) {
          // The operand that holds the argument (the argument itself, or a
          // nested call that canonicalization merges with `call`).
          if (pathTo(op, arg, [])) continue;
          const other: MathJsonExpression[] = [];
          findWrittenCalls(op, name, other);
          // Another call of `name` inside an operand can be the call of the
          // frame, so the argument is not sure. For a sum or a product, the
          // call contains that other call, and its range is the result:
          // `Ln(x * y) * Sin(s)` underlines the whole product, and so does
          // `Sqrt(y - 2) + s`, whose `y - 2` is a sum in canonical form.
          if (other.length > 0) return merges ? { call, arg: null } : undefined;
        }
      }
      return { call, arg };
    }

    if (arg === null) return undefined;
    scope = arg;
    narrowed = true;
    if (reached !== undefined) reached.scope = arg;
  }
  return undefined;
}

/**
 * The operators whose canonical form does not keep the written order of the
 * operands. `Add` and `Multiply` sort their operands, fold their number
 * operands, and flatten nested sums and products (`p + q - r` is written as
 * `Subtract(Add(p, q), r)` and is `Add(p, q, Negate(r))` in canonical form).
 * `Xor` and `Set` sort their operands. The argument index of a frame of
 * these operators counts the operands of the CANONICAL call, so it cannot
 * select an argument of the written call.
 */
const REORDERED_OPERATORS = new Set(['Add', 'Multiply', 'Xor', 'Set']);

/** The written operators that canonicalization merges into one call of a
 * reordered operator: a written subtraction is part of the canonical sum. */
function clusterOperators(name: string): readonly string[] {
  if (name === 'Add') return ['Add', 'Subtract'];
  return [name];
}

/**
 * The written call and the written argument that frame `j` names, with
 * `call` the written call that the frame selected in `scope`. `undefined`
 * when the argument is not sure.
 *
 * For most operators the frame's argument index selects the argument. For
 * an operator in {@link REORDERED_OPERATORS}, or one that `canonicalOrder`
 * says is reordered, the index counts the operands of the canonical call.
 * When an inner frame names an operator of the
 * statement, the error went through a call of that operator, so the
 * argument is the one written operand of the call that holds such a call.
 * The written operands are read through the nested calls that
 * canonicalization merges into one (`clusterLeaves`), and the selected call
 * is the outermost of them. Example: in
 * `(if n == 1 { g("a") } else { 0 }) + (if n == 2 { 2 } else { 3 })` the
 * frame `Add argument 2` can name the first written operand, and when both
 * operands hold an `if` the argument is not sure. When no inner frame names
 * an operator of the statement, the call made the error for its own operand:
 * `"a" + 1` gives `Add argument 1`. With `canonicalOrder`, the written
 * operand is the one whose source range the canonical operand has
 * ({@link writtenOperandAt}): in `Ln(w) * 2`, whose canonical form is
 * `2·Ln(w)`, the frame `Multiply argument 2` gives `Ln(w)`. Without it, the
 * index is used as a written position.
 *
 * When frame `j` is not the innermost frame, the error came from a call
 * inside the argument. An argument that cannot fail when it is evaluated
 * (a number, a string, a block or a list of them) is then not the argument
 * at fault, and the result is `undefined`.
 */
function frameArgument(
  frames: readonly ErrorFrameRef[],
  j: number,
  call: MathJsonExpression,
  scope: MathJsonExpression,
  stmt: MathJsonExpression,
  frameIndexOrder: 'declaration' | 'written',
  slotNamesFor?: (
    operatorName: string
  ) => readonly (string | undefined)[] | undefined,
  canonicalOrder?: CanonicalOrder,
  rejected?: Rejected
): { call: MathJsonExpression; arg: MathJsonExpression | null } | undefined {
  const { name, index } = frames[j];
  let inner: string | undefined;
  for (let i = j - 1; i >= 0 && inner === undefined; i--) {
    // A rejected frame did not make the error in this statement.
    if (rejected?.frames.has(i)) continue;
    const found: MathJsonExpression[] = [];
    findWrittenCalls(stmt, frames[i].name, found);
    if (found.length > 0) inner = frames[i].name;
  }

  const reordered =
    REORDERED_OPERATORS.has(name) || canonicalOrder?.reorders(name) === true;
  let result: { call: MathJsonExpression; arg: MathJsonExpression | null };
  if (
    reordered &&
    inner === undefined &&
    canonicalOrder !== undefined &&
    frameIndexOrder === 'declaration' &&
    !operands(call).some((op) => operator(op) === 'NamedArgument')
  ) {
    // The call made the error for one of its own operands, and the index
    // counts the operands of the canonical call. The canonical operand keeps
    // the source range of the written operand it was made from.
    const top = clusterTop(scope, call, name);
    result = {
      call: top,
      arg: writtenOperandAt(top, name, index, canonicalOrder, rejected),
    };
  } else if (reordered && inner !== undefined) {
    const top = clusterTop(scope, call, name);
    const holders = clusterLeaves(top, name).filter((leaf) => {
      // `inner` was found with `findWrittenCalls`, which can give a written
      // subtraction for an `Add` frame, so the operands are searched the
      // same way.
      const found: MathJsonExpression[] = [];
      findWrittenCalls(leaf, inner, found);
      return found.length > 0;
    });
    // When more than one operand holds a call of the inner operator, the
    // canonical operand that the index names keeps the source range of its
    // written operand, as in the branch above. In `Ln(w) + Ln(2)`, with
    // `w = "s"`, the frames are `Ln argument 1, Add argument 1`, and both
    // operands hold an `Ln`: the range selects `Ln(w)`. The operand must
    // also hold a call of the inner operator. This relies on the index of
    // the frame counting the operands of the canonical call, as the frame
    // that the evaluation of a sum or a product adds for the operand whose
    // evaluation returned the error does (`_evaluatedOperandResultError()`,
    // `boxed-expression/boxed-function.ts`).
    let arg: MathJsonExpression | null =
      holders.length === 1 ? holders[0] : null;
    if (
      holders.length > 1 &&
      canonicalOrder !== undefined &&
      frameIndexOrder === 'declaration' &&
      !operands(call).some((op) => operator(op) === 'NamedArgument')
    ) {
      const written = writtenOperandAt(top, name, index, canonicalOrder);
      if (written !== null && holders.includes(written)) arg = written;
    }
    if (arg === null) return undefined;
    result = { call: top, arg };
  } else {
    result = {
      call,
      arg: argumentAtSlot(
        [...operands(call)],
        index - 1,
        name,
        frameIndexOrder,
        slotNamesFor
      ),
    };
  }

  if (j > 0 && result.arg !== null && !mayFail(result.arg)) return undefined;
  return result;
}

/** The outermost call that contains `node` in `root` through a chain of the
 * calls that canonicalization merges with `node` (see
 * {@link clusterOperators}): `Subtract(Add(p, q), r)` for the `Add`. */
function clusterTop(
  root: MathJsonExpression,
  node: MathJsonExpression,
  name: string
): MathJsonExpression {
  const merged = clusterOperators(name);
  const path: MathJsonExpression[] = [];
  if (!pathTo(root, node, path)) return node;
  // `path` goes from `root` down to `node`.
  let top = path.length - 1;
  while (top > 0 && merged.includes(operator(path[top - 1]))) top -= 1;
  return path[top];
}

/** The operands of `top`, read through the nested calls that
 * canonicalization merges with it (see {@link clusterOperators}). */
function clusterLeaves(
  top: MathJsonExpression,
  name: string
): MathJsonExpression[] {
  const merged = clusterOperators(name);
  const leaves: MathJsonExpression[] = [];
  const visit = (node: MathJsonExpression): void => {
    for (const op of operands(node))
      if (merged.includes(operator(op))) visit(op);
      else leaves.push(op);
  };
  visit(top);
  return leaves;
}

/**
 * The written operand of the reordered call `top` that operand `index`
 * (1-based) of its canonical call was made from, found by source range (see
 * {@link CanonicalOrder}). The candidates are the operands of `top` and the
 * operands read through the nested calls that canonicalization merges with it
 * ({@link clusterLeaves}).
 *
 * When the operand is not known (`argumentOffsets` gives `undefined`), the
 * written operand is the one operand that can make an error when it is
 * evaluated ({@link mayFail}): in `Ln(w) * 2`, `2` cannot. A call of a
 * rejected frame (see {@link Rejected}) did not make the error either: in
 * `x + Ln(2)`, with `x` an error from an earlier statement, the operand is
 * `x`. `null` when no written operand, or more than one, is found
 * (`Ln(w) + Ln(w)`): the caller then uses the whole call, which contains the
 * error.
 */
function writtenOperandAt(
  top: MathJsonExpression,
  name: string,
  index: number,
  canonicalOrder: CanonicalOrder,
  rejected?: Rejected
): MathJsonExpression | null {
  const callRange = nodeOffsets(top);
  if (callRange === undefined) return null;
  const range = canonicalOrder.argumentOffsets(name, callRange, index);
  if (range === undefined) {
    const failing = clusterLeaves(top, name).filter(
      (leaf) => mayFail(leaf) && !rejected?.calls.has(leaf)
    );
    return failing.length === 1 ? failing[0] : null;
  }
  const candidates = new Set([...operands(top), ...clusterLeaves(top, name)]);
  const found = [...candidates].filter((node) => {
    const o = nodeOffsets(node);
    return o !== undefined && o[0] === range[0] && o[1] === range[1];
  });
  return found.length === 1 ? found[0] : null;
}

/** Fill `path` with the nodes from `root` down to `node` (found by
 * identity). `false` when `node` is not in `root`. */
function pathTo(
  root: MathJsonExpression,
  node: MathJsonExpression,
  path: MathJsonExpression[]
): boolean {
  path.push(root);
  if (root === node) return true;
  for (const op of operands(root)) if (pathTo(op, node, path)) return true;
  path.pop();
  return false;
}

/** Whether evaluating `node` can make an error: `false` for a number, a
 * string, and a block, a list or a tuple of them. A symbol can hold an error
 * value, and any other call can make one. */
function mayFail(node: MathJsonExpression): boolean {
  const head = operator(node);
  if (head === '') return symbol(node) !== null;
  if (['Block', 'List', 'Tuple'].includes(head))
    return operands(node).some(mayFail);
  return true;
}

/**
 * Whether the written argument `arg` is the value `value` that an error
 * names as its cause (see {@link offendingValue}).
 *
 * - `'is'`: `arg` is a number or string literal equal to `value`.
 * - `'is-not'`: `arg` is a number or string literal, and `value` is a
 *   different number or string.
 * - `'unsure'`: any other case. An argument such as a symbol or a call can
 *   evaluate to the value.
 */
function compareLiteral(
  arg: MathJsonExpression,
  value: MathJsonExpression
): 'is' | 'is-not' | 'unsure' {
  if (mayFail(arg)) return 'unsure';
  const valueString = stringValue(value);
  const valueNumber = machineValue(value);
  if (valueString === null && valueNumber === null) return 'unsure';
  const argString = stringValue(arg);
  if (argString !== null) return argString === valueString ? 'is' : 'is-not';
  const argNumber = machineValue(arg);
  if (argNumber === null) return 'unsure';
  if (valueNumber === null) return 'is-not';
  return Object.is(argNumber, valueNumber) ? 'is' : 'is-not';
}

/**
 * Whether the argument of the written call `call` that `frame` names is the
 * value `offending` that the error names (see {@link compareLiteral}).
 * `'unsure'` when the argument is not known: the argument index of an
 * operator that canonicalization reorders counts the operands of the
 * canonical call, and the argument of a named call is not known without the
 * declared slot names.
 */
function literalArgumentMatch(
  call: MathJsonExpression,
  frame: ErrorFrameRef,
  offending: MathJsonExpression,
  frameIndexOrder: 'declaration' | 'written',
  slotNamesFor?: (
    operatorName: string
  ) => readonly (string | undefined)[] | undefined,
  canonicalOrder?: CanonicalOrder
): 'is' | 'is-not' | 'unsure' {
  // `findWrittenCalls` can give a written `Subtract` for an `Add` frame.
  if (operator(call) !== frame.name) return 'unsure';
  if (
    REORDERED_OPERATORS.has(frame.name) ||
    canonicalOrder?.reorders(frame.name) === true
  )
    return 'unsure';
  const arg = argumentAtSlot(
    [...operands(call)],
    frame.index - 1,
    frame.name,
    frameIndexOrder,
    slotNamesFor
  );
  return arg === null ? 'unsure' : compareLiteral(arg, offending);
}

/** Collect the nodes of `expr` whose operator is one of `names` and that are
 * not inside another such node (early-exits once there are two). */
function findShallowestByOperators(
  expr: MathJsonExpression | null,
  names: readonly string[],
  matches: MathJsonExpression[]
): void {
  if (expr === null || matches.length > 1) return;
  if (operator(expr) === '') return;
  if (names.includes(operator(expr))) {
    matches.push(expr);
    return;
  }
  for (const op of operands(expr))
    findShallowestByOperators(op, names, matches);
}

/**
 * The written argument that fills declaration slot `slot` (0-based) of the
 * call whose raw operands are `rawOps`.
 *
 * An all-positional call is the identity mapping. A call containing a
 * `NamedArgument` carrier was permuted by the normalization seam, and the
 * permutation is reconstructed here from the same two facts the seam used: a
 * positional argument fills the next unfilled slot left to right (positional
 * arguments always precede named ones — the seam rejects the other order, so
 * a call that produced an ARGUMENT-indexed error has them as a prefix), and
 * a carrier fills the slot its written name selects among the declared
 * `slotNames`. When the slot names are not knowable, or nothing matches,
 * `null` — the caller then anchors on the whole call, which is wide but
 * never underlines the WRONG argument.
 */
function argumentAtSlot(
  rawOps: readonly MathJsonExpression[],
  slot: number,
  calleeName: string,
  frameIndexOrder: 'declaration' | 'written',
  slotNamesFor?: (
    operatorName: string
  ) => readonly (string | undefined)[] | undefined
): MathJsonExpression | null {
  // A written-order index needs no reconciliation — and neither does a call
  // with no carrier, whose written order IS declaration order.
  if (
    frameIndexOrder === 'written' ||
    !rawOps.some((op) => operator(op) === 'NamedArgument')
  )
    return rawOps[slot] ?? null;

  const names = slotNamesFor?.(calleeName);
  if (names === undefined) return null;

  let nextPositionalSlot = 0;
  for (const op of rawOps) {
    if (operator(op) !== 'NamedArgument') {
      if (nextPositionalSlot === slot) return op;
      nextPositionalSlot += 1;
      continue;
    }
    const written = stringValue(operand(op, 1));
    // Return the whole carrier (`x: "bad"`), not just its value: the name is
    // part of what the author wrote at that spot, and the in-order underline
    // covers it too.
    if (written !== null && names.indexOf(written) === slot) return op;
  }
  return null;
}

/** {@link locateError}'s range alone, for a caller that only needs to point. */
export function narrowToFrames(
  frames: readonly ErrorFrameRef[],
  stmt: MathJsonExpression,
  fallback: [number, number],
  slotNamesFor?: (
    operatorName: string
  ) => readonly (string | undefined)[] | undefined,
  frameIndexOrder: 'declaration' | 'written' = 'declaration',
  canonicalOrder?: CanonicalOrder,
  offending?: MathJsonExpression
): [number, number] {
  return locateError(
    frames,
    stmt,
    fallback,
    slotNamesFor,
    frameIndexOrder,
    canonicalOrder,
    offending
  ).range;
}

/** Collect every node of `expr` whose operator is `name`. The search stops
 * when it has `limit` matches: two matches tell that a name is ambiguous as
 * surely as ten. */
function findByOperator(
  expr: MathJsonExpression | null,
  name: string,
  matches: MathJsonExpression[],
  limit = 2
): void {
  if (expr === null || matches.length >= limit) return;
  if (operator(expr) === '') return;
  if (operator(expr) === name) matches.push(expr);
  for (const op of operands(expr)) findByOperator(op, name, matches, limit);
}

/**
 * Collect the written calls of `expr` that a frame of the operator `name`
 * can name (the search stops when it has `limit` matches).
 *
 * For most operators these are the calls of `name`. When canonicalization
 * merges other written operators into a call of `name` (see
 * {@link clusterOperators}), each match is one cluster: the outermost call
 * of a chain of nested calls of these operators ({@link clusterTop}). The
 * calls of the cluster become one canonical call, so they are one match:
 * `p + q - r` is one sum. A cluster inside an operand that is not merged is
 * another match: `Sqrt(y + 2) - s` has two sums, the `y + 2` and the
 * subtraction, and a frame of `Add` can name either one. A search for the
 * written `Add` alone would find only `y + 2`, and select an operand of the
 * wrong sum.
 */
function findWrittenCalls(
  expr: MathJsonExpression | null,
  name: string,
  matches: MathJsonExpression[],
  limit = 2
): void {
  const merged = clusterOperators(name);
  if (merged.length === 1) {
    findByOperator(expr, name, matches, limit);
    return;
  }
  // A call of `merged` whose parent is not a call of `merged` is the
  // outermost call of its cluster.
  const visit = (node: MathJsonExpression, inCluster: boolean): void => {
    if (matches.length >= limit || operator(node) === '') return;
    const isMerged = merged.includes(operator(node));
    if (isMerged && !inCluster) matches.push(node);
    for (const op of operands(node)) visit(op, isMerged);
  };
  if (expr !== null) visit(expr, false);
}

/** The `sourceOffsets` of a raw AST node, when it carries them. */
function nodeOffsets(
  node: MathJsonExpression | null
): [number, number] | undefined {
  return typeof node === 'object' && node !== null && !Array.isArray(node)
    ? (node as { sourceOffsets?: [number, number] }).sourceOffsets
    : undefined;
}
