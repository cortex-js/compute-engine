/**
 * Extended explanations for diagnostic codes, served by `epsil doc <code>`
 * and advertised by a `note:` footer on rendered diagnostics.
 *
 * Philosophy (ruled 2026-08-12): no opaque numeric codes and no separate
 * `--explain` registry — the kebab-case diagnostic codes ARE the stable
 * identifiers, and the doc command is the lookup surface. An entry exists
 * only when there is genuinely more to say than the diagnostic message
 * already does; the footer is emitted only for codes present here, so there
 * is never a "no extended information available" dead end.
 *
 * Entries are plain text (printed to a terminal): short paragraphs separated
 * by blank lines, with `code` spans in backticks. The first sentence should
 * stand alone — it doubles as the summary line.
 *
 * Backticks are the ONLY code marker — not double quotes. `scripts/
 * build-error-docs.ts` renders these into MDX for https://epsil.dev/errors/,
 * where a backtick span becomes a code span and is exempted from the entity
 * escaping that `<`, `>`, `{` and `}` need everywhere else. Code left in
 * double quotes still reads on a terminal, but on the site it renders as
 * prose in straight quotes. Double quotes are kept for what they actually
 * quote: fragments of diagnostic text (`"expected T, got U"`) and the tier
 * labels (`"Type error"`).
 */
export const ERROR_EXPLANATIONS: Record<string, string> = {
  'spread-tuple': `A spread (\`...x\`) in a list or set literal was given a tuple. Tuples are units — a point, a pair — so they do not splice into a surrounding collection; the spread would silently do nothing, which is why it is rejected instead.

To use a tuple's elements as list elements, convert explicitly: \`ListFrom(t)\` is the list of t's elements, so \`[...ListFrom(t), 3]\` splices them. (In a CALL argument list the rule is reversed: argument lists are tuple-shaped, so there \`f(...t)\` spreads exactly tuples.)`,

  'incompatible-type': `A value's type does not match what its context requires — a typed declaration (\`let x: string = …\`) whose initializer has a different type, an argument outside a function's signature, or a value that fails a type ascription.

The message reads "expected \`T\`, got \`U\`": T is what the context requires, U is what the value actually has. A site may follow — "at \`x\`" quotes the offending subexpression. A type like \`list<string^5>\` is a list of exactly 5 strings; \`integer\` is a whole number, finite like every bare numeric type name.

The check runs twice by design: once statically, when the program is canonicalized (reported before anything runs), and again during evaluation, where the mismatch becomes an error value that propagates outward (see \`epsil doc runtime-error\`).`,

  'expected-present': `A presence assertion \`x?!\` (\`AssertPresent(x)\`) was evaluated on an absent value: \`missing\`, \`NaN\`, or an indeterminate form such as \`0/0\`. The assertion says "this value is present, fail otherwise", and it failed; the error names the operand as written.

An absent value is a data state, not a bug in itself: an index out of range (\`xs[i]\`), a \`first(filter(…))\` that found nothing, a restricted value whose condition did not hold. Decide what the program should do when it happens. Write \`x ?? fallback\` to replace the absent value, test it with \`isMissing(x)\` and branch, or keep the assertion where absence really is a violated precondition and let the error propagate (\`if let v: !error = …\` catches it). \`Nothing\` is the value of an empty block, not an absent datum, and passes the assertion.`,
  'no-product-between-points': `Two points (tuples) were multiplied, and there is no implicit product between points. Multiplication of a point by a SCALAR is defined — it scales each component — and so is adding two points of the same arity, but \`(1, 2) * (3, 4)\` has no single meaning, so the engine rejects it rather than guessing.

Say which product you mean. \`Dot(a, b)\` is the inner product (\`(1,2)·(3,4)\` is 11) and is defined whenever the two points have the same number of components. \`Cross(a, b)\` is the cross product, defined only for two 3-component points; the message names it only when both operands have three components, because for a pair of plane points it would just produce an \`incompatible-dimensions\` error instead.

Juxtaposition, \`\\cdot\` and \`\\times\` all parse to the same multiplication, so writing \`a \\times b\` between two points does not select the cross product — spell \`Cross(a, b)\` for that.`,

  'no-division-by-point': `A point (tuple) was used as a divisor. Dividing a point BY a scalar is defined — it scales each component, so \`(4, 6) / 2\` is \`(2, 3)\` — but there is no reciprocal of a point, so neither \`x / (1, 2)\` nor \`(1, 2) / (3, 4)\` has a meaning to give them.

If you meant to scale by the reciprocal of one component, index it: \`p / q[1]\`. If you meant a component-wise quotient, build it explicitly from the components.`,

  'return-in-expression-body': `A \`Return\` appears in an operand of \`Sum\`, \`Product\`, \`Integrate\`, \`D\`, \`ND\`, \`NIntegrate\`, \`Limit\` or \`NLimit\` (the operator is named in the error): in the body, a bound or a variable. These operands are expressions, computed once per index value or integration point, not statement blocks of the enclosing function, so a \`Return\` there has no function to end. Before, it stayed in the value: \`Sum(1 + Return("q"), (k, 1, 2))\` was \`2 + 2Return("q")\`.

To leave a function early, test the condition outside the operator and return from the function body. A \`Return\` inside a function literal in the body (\`Sum(Apply(x ↦ { return 2x }, k), (k, 1, 3))\`) ends that function and is allowed.`,

  'missing': `A function was called with fewer arguments than its signature requires; the error marks the position of the argument that was not provided.

Check the signature with \`epsil doc <FunctionName>\`. Optional parameters never produce this error — only required ones do.`,

  'unexpected-argument': `A function was called with more arguments than its signature accepts; the quoted value is the first extra one.

Check the signature with \`epsil doc <FunctionName>\`. A common cause is passing a collection's elements separately where the function expects the collection itself (or the reverse).`,

  'callback-arity': `A collection operator was given a callback that declares a different number of parameters than the operator passes it — \`Map((p, q) => p + q, xs)\`, where Map applies the callback to one element at a time.

An ordinary call may supply fewer arguments than a function declares: \`f(1)\` on a two-parameter \`f\` is partial application, and yields a function awaiting the rest. Inside a collection operator that is never what was meant, because the OPERATOR decides how many arguments the callback receives — so \`Map\` would build a list of leftover functions rather than a list of results. The check is therefore specific to operator-owned callback slots; ordinary calls still curry.

If the elements are pairs (or tuples) and the callback meant to take one apart, write the parameter as a tuple pattern: \`Map(((p, q)) => p + q, pairs)\` — the extra parentheses make it ONE parameter that is destructured, not two parameters.

A few operators read the callback's arity as a choice between two modes and accept either: \`Sort\` takes a unary sort key or a binary comparator, and \`Iterate\` takes \`f(previous)\` or \`f(index, previous)\`. Those report this error only when the callback matches neither.

A pipe stage is checked on the same grounds but reports \`pipe-stage-arity\`, because the remedy there is different.`,

  'pipe-stage-arity': `A pipe stage declares a number of parameters it can never be called with — \`[100, 200] |> (x, y, z) => x + y + z\`. A pipe passes its stage exactly one value, so only a stage that accepts one argument can be applied.

As with a callback slot, an ordinary call may supply fewer arguments than a function declares — \`f(1)\` on a two-parameter \`f\` is partial application — but a pipe is not an ordinary call: the piped value is the whole argument list, so a leftover function is never the result the pipeline was written to produce.

A stage that genuinely takes several arguments is written as a CALL, with \`_\` marking the slot the piped value fills: \`xs |> Fold(f, 0, _)\`. The \`_\` may be left out when the call is missing exactly one required argument, so \`xs |> Take(10)\` means \`xs |> Take(_, 10)\`.

If the piped value is a collection whose elements are tuples and the stage meant to take one apart, write the parameter as a tuple pattern — \`pairs |> ((p, q)) => p + q\` — where the extra parentheses make it ONE parameter that is destructured.`,

  'argument-name-unknown': `A call passed an argument by name (\`f(rate: 0.05)\`), but the called function declares no parameter with that name; the message lists the names it does declare, and a "did you mean" points at the closest one.

Only parameters that carry a name in the function's declaration can be addressed by name — an unnamed parameter is positional-only. Check the signature with \`epsil doc <FunctionName>\`.`,

  'argument-order-invalid': `In a call that mixes positional and named arguments, all positional arguments must come first: once one argument is named, every later argument must be named too.

\`f(1, rate: 0.05)\` is fine; \`f(rate: 0.05, 1)\` is this error — after \`rate:\` there is no position left for a bare \`1\` to occupy unambiguously.`,

  'argument-name-duplicate': `The same parameter was supplied twice — either two named arguments used the same name, or a named argument repeats a parameter that an earlier positional argument already filled.

In \`f(1000, principal: 2000)\` the first positional argument already occupies \`principal\`, so naming it again is this error, not an override.`,

  'argument-names-unavailable': `A call passed arguments by name, but the called function has no declaration the engine can read parameter names from — it is undefined, a local function not yet declared, or held in a variable whose declared type gives no parameter names (\`function\`, or a signature such as \`(number, number) -> number\`).

Named arguments are checked against the declaration the call resolves through; with no declaration visible there is nothing to check the names against. For a variable, only its declared type counts, never the function it holds now: that function can change after the call is written. Call it positionally, move the definition before the call, or declare the variable with a signature that names its parameters (\`let g: (x: number, y: number) -> number = …\`).

The same error covers an OVERLOADED function whose overloads accept the call but disagree about which argument fills which parameter — the names then pick an argument order rather than just an implementation, and the engine will not guess. Call it positionally, or give the overloads distinct parameter types.`,

  'argument-names-required': `The called function requires every argument to be written with its parameter's name (\`Person(firstName: "Alan", age: 42)\`); the message lists the names, in declaration order.

Object-type constructors are the functions in this shape. An object type's fields are frequently several of the same type, so a positional call that transposed two of them would be accepted in silence and build a wrong object with no error anywhere. Because the arguments are named, their order does not matter.`,

  'argument-optional-skipped': `A named argument supplied an optional parameter while an optional parameter declared before it was left out.

Arguments are matched to declared positions, and there is no way to leave a hole in the argument list — so an optional parameter can only be named when every optional parameter declared before it is also supplied (by position or by name). Supply the earlier optional too, or omit both.

A parameter with a default value is never the cause: when a named argument skips it, it takes its default. With \`function f(x, density: number = 1, factor: number = 2)\`, the call \`f(3, factor: 5)\` is \`f(3, 1, 5)\`. Only an optional parameter WITHOUT a default (\`number?\` in a declared signature) leaves a hole.`,

  'default-value-invalid': `A parameter's default value (the part after \`=\` in \`function f(x, k: number = 2)\` or \`(x, k = 2) => …\`) is not one the language accepts here. A default is a constant: a number (with an optional sign), a string, \`true\` or \`false\`, the empty list \`[]\`, the empty dictionary \`{}\`, a constant (a constant of the library, \`Integers\`, \`Pi\`, or a symbol declared constant before the function is defined) or a symbol that the parameter type lists (\`mode: symbol<Auto> | symbol<Manual> = Auto\`) — a value that the signature can store and print, as in \`(x: number, k: number = 2) -> number\`. A default fills an argument that the call leaves out, and nothing else.

The message gives the reason:
- Any other expression (\`k = x + 1\`, \`xs = [1, 2]\`) has no spelling in a signature. For a computed or non-empty default, leave the parameter required and pass the value at each call.
- A symbol that names a variable (\`k = n\`, \`k = weights\`), or that is not declared and is not listed by a \`symbol<…>\` parameter type, is refused: a default is a constant, and such a symbol would be read when the call runs. Write a constant, or pass the argument.
- A default that names a parameter of the same list (\`(x, k = x) => …\`) is refused.
- A function with a rest parameter (\`(x, k = 2, ...rest) => …\`) has no defaults: drop the default or the rest parameter.
- \`Nothing\` and \`Missing\` are refused: \`Nothing\` is the value of an empty block, not an argument value, and \`Missing\` is a result only, not a value that a call supplies.
- A \`bind\` parameter of a \`hold\` definition cannot have a default: it names a variable that the caller writes.
- A default beside a literal parameter (\`function f(0, k = 2)\`) is refused: a literal parameter makes the definition a clause of a multi-clause function, and a default in a multi-clause function is not supported yet, because the clause that receives a call is not always known when the call is completed with the default. For the same reason, adding a second clause to a function with a default (or a clause with a default to a function that has several) is refused when the definition runs.`,

  'zero-index': `Indexing is 1-based: \`xs[1]\` is the first element of a collection and \`xs[n]\` the n-th, so the literal index 0 never names an element (it yields NaN).

The last element is \`xs[-1]\` — negative indices count from the end, which is usually what a 0-index habit is reaching for.`,

  'mapsto-arrow-expected': `\`->\` and \`=>\` are different operators: \`->\` pairs a key with a value (the key must be a string, as in a dictionary entry) and also writes function TYPES in annotations (\`(number) -> number\`), while \`=>\` is the mapsto arrow that builds a function value.

So \`(x) -> x^2\` reads as a key-value pair with a malformed key, not a lambda. Write \`(x) => x^2\` for the function; the fixit in the diagnostic applies exactly that rewrite.

In a call, \`name -> value\` is a rule argument — a key-value pair whose key is the name, as in \`f(GridLines -> 1, Axes -> 2)\`. So \`map(x -> x^2, xs)\` passes a key-value pair where \`map\` expects a function, and the diagnostic names the argument. Write \`map(x => x^2, xs)\`; the fixit applies that rewrite too.`,

  'mapsto-arrow-legacy': `\`|->\` was the mapsto arrow in earlier versions of the language. It is now spelled \`=>\`, the same arrow a \`match\` case uses for its body — one glyph, meaning "yields", in both places.

Write \`x => x + 1\`; the fixit in the diagnostic replaces the arrow for you. The expression was parsed as the function it was meant to be, so any other diagnostic reported here is a separate problem. (Function TYPES and dictionary entries are unaffected: they keep \`->\`, as in \`(number) -> number\` and \`{k -> v}\`.)`,

  'chained-assignment': `An assignment is a statement, not a value, so assignments do not chain. In \`a = b = 5\` the OUTER \`=\` assigns and the inner one compares: \`a\` would receive the boolean of \`b = 5\`. In \`a := b := 5\` the inner assignment is an operand, which is not allowed.

Write two statements, \`b := 5; a := b\`, or \`a := (b == 5)\` if the comparison was the intent.`,

  'assign-in-condition': `Inside a condition, \`:=\` assigns — and the assigned value, not a comparison, becomes the test: \`if flag := true { … }\` sets flag and then tests \`true\`.

Use \`==\` to compare, or perform the assignment on its own line before the condition. (A bare \`=\` in a condition already compares, so only an explicit \`:=\` reaches this diagnostic.)`,

  'floor-division-comment': `\`//\` starts a line comment, not floor division — everything after it on the line is ignored, which silently truncates an expression like \`a // b\`.

Use \`Floor(a / b)\` for the integer quotient.`,

  'control-outside-loop': `\`break\` and \`continue\` are only valid directly inside a \`while\` or \`for\` body — and the loop context resets at every function and lambda boundary, so a \`break\` inside a lambda DEFINED in a loop is still outside the loop.

To stop a pipeline early, restructure with a condition or a Take/Filter stage instead of breaking out of a callback.`,

  'match-not-exhaustive': `A \`match\` whose subject has a CLOSED type — a sum declared with \`type light = red | green | yellow\`, or \`boolean\` — has no case for some of the values the subject can hold; the message spells each uncovered value as the pattern that would match it (\`yellow()\`, \`node(_, _)\`, \`false\`). Such a subject evaluates to the \`match-no-case\` error value, which is rarely what was meant.

Add a case for each uncovered value, or a final \`_\` case if they share a result. A case covers a value only when it matches it UNCONDITIONALLY: a constructor pattern whose operands are all wildcards or bindings (\`node(v, cs)\`, \`node(v, ...)\`), a typed binding (\`x: green\`), a wildcard or bare binding, or an or-alternative of those. A case with an \`if\` guard, a literal operand (\`lit(0)\`) or a pin (\`== value\`) is conditional and counts for nothing, because the check does not reason about conditions.

The check reads the subject's type from its annotation — a parameter (\`function f(t: light)\`), a typed \`let\`/\`const\`, or a typed \`match\` binding — and only ever reports a type it can enumerate from a declaration. A subject without an annotation, or of an open type (\`integer\`, \`string\`, a union with a member that is not a variant such as \`light | nothing\`), is never reported. It is a warning: the program still runs.

No warning does not make the \`match\` total. A \`boolean\` subject that stays symbolic (an undecided comparison) is neither \`true\` nor \`false\`, and a declared name with no value (\`let u: light\` without an initializer) is not one of its constructors; both reach no case even when every alternative is covered. A final \`_\` case handles them.`,

  'equation-not-assignment': `In expression position \`=\` is an equation, and only a statement assigns. So in \`let a = 0; match 1 { 1 => a = 2 }; a\` the case body compares \`a\` with \`2\`, nothing reads the result, and \`a\` stays \`0\`.

Write \`1 => do { a = 2 }\` to assign, or \`1 => a == 2\` if the comparison was meant. The same applies to \`{ a = 2 }\` as a body, which is a set that holds an equation. A named \`function\` statement that writes an outer variable must declare the \`scope\` effect. An explicit function-type annotation on a variable must admit that effect too: \`let f: (number) scope -> nothing = x => do { a = 2 }\`. An unannotated function-valued variable keeps type \`function\`; its value carries its effects.

The warning applies to the whole body of a \`match\` case, of a branch of a conditional expression and of a function, when the left side is a variable that the program declares, other than a constant, and nothing reads the value of the body. The body of a function counts as unread when each read of the function's name is a call whose value is discarded. A body whose value is read (\`let r = match k { 1 => a = 2 }\`, a lambda passed to \`map\` or \`solve\`, the last statement of the program) and an equation of a free name, of a constant, of a parameter or of a pattern variable get no warning. It is a warning: the program still runs.`,

  'symbol-expected': `A name was required at this position — after \`let\` or \`const\`, as a \`for\` loop's variable, as a function's or parameter's name — but something else was found there (\`let = 42\`).

A subtler cause: the word written there is one the grammar itself consumes. \`for = 3\` is not an assignment to a variable named \`for\` — the \`for\` starts a for-loop, and the loop machinery then finds no variable name. To use such a word as a name anyway, spell it verbatim, wrapped in backquote characters: "let \`for\` = 3" (see \`epsil doc reserved-word\`).`,

  'reserved-word': `A word the language reserves was used where it cannot be a plain identifier. Two cases share this code: an active keyword where an expression was expected — \`y = while\` reads as the start of a \`while\` loop, not as a value named \`while\` — and a literal word (\`true\`, \`false\`, \`Infinity\`, \`oo\`, \`NaN\`) used to NAME a binding (\`let NaN = 1\`): a literal can never be a binding name, in any position.

Only the words the grammar actually consumes today are rejected. The longer documented reservation list (\`set\`, \`with\`, \`label\`, …) stays fully usable — a future construct claims its word contextually where possible (as \`type\` and \`alias\` do), so those words may never be taken at all.

The verbatim form always works: the name wrapped in backquote characters, "let \`while\` = 3", is an ordinary symbol in every position. Note that a BINDING position may accept an active keyword bare (\`let while = 3\` binds), but the bound name is then unreachable in expressions — \`while + 1\` reads as a loop again — so the verbatim spelling is the only robust one.`,

  'asymmetric-operator-whitespace': `An operator was written with whitespace on one side only — \`a+ b\`. An operator with whitespace on both sides or neither is infix (\`a + b\`, \`a+b\`); one with whitespace only BEFORE it starts a new statement instead (\`a +b\` is the value \`a\`, then the prefix expression \`+b\`). The asymmetric middle case matches neither reading, so it is flagged — and recovered as infix, which is almost always what was meant. The quick fix restores the symmetry.

The spacing rule is what lets line breaks alone separate statements: the parser decides where an expression ends from the spacing, so a program without semicolons still parses exactly one way. The same abutment idea splits postfix from prefix \`!\`: \`x!\` (abutting) is Factorial, while \`x !y\` ends the expression \`x\` and starts the prefix Not \`!y\`.`,

  'duplicate-dictionary-key': `A dictionary literal repeats a key: in \`{"a" -> 1, "a" -> 2}\` the second entry conflicts with the first. Within one uninterrupted run of literal entries, keys are unique by construction — a repeated key there is a typo or a leftover, never an override, so it is reported instead of silently picking one of the two values. (Under error recovery the FIRST entry is the one that remains.)

A spread is an override boundary: \`{"a" -> 1, ...d, "a" -> 2}\` is legal, and the second \`"a"\` deliberately overrides whatever the spread brought in — last wins, no diagnostic. And only literal keys are checked: a key computed at runtime cannot collide until the dictionary is actually built.`,

  'parameter-name-mismatch': `A lambda and its type annotation name the same parameter differently — \`const f: (a: number) -> number = (b) => b\`. A parameter name binds wherever it is written, so the annotation's \`a\` and the lambda's \`b\` would both claim the same slot, and the engine will not guess which one the body meant.

Rename one side so the two agree — the quick fix renames the annotation's parameters to match the lambda's — or leave the annotation's parameters unnamed (\`(number) -> number\`): an annotation's parameter names are optional documentation, while the lambda's are the real binding.`,

  'absence-marker-binding': `A binding names one of the absence markers \`Nothing\` or \`Missing\`: a \`let\`, a \`const\`, an assignment, a function, a parameter, a loop variable or a \`match\` pattern. The engine recognizes these markers by their name wherever they appear — an arithmetic operand named \`Nothing\` is refused as a non-number, and an arithmetic operand named \`Missing\` is read as absent — so a binding of one of them could never behave like the value it holds. With \`Module\` (see \`epsil doc module-binding\`), they are the only library names that cannot be rebound in any scope. Every other one, including \`Pi\` and \`Square\`, is shadowed by a user binding, with one exception: at the top level of a program, a \`let\` or \`const\` of a library constant that results carry by name (\`Pi\`, \`ExponentialE\`, \`GoldenRatio\`) is refused with a run-time error, because a result built with the library constant would read the user value when its MathJSON is boxed again.

Choose another name. In a \`match\`, a bare name is a new variable, not a comparison: to test for the marker, write \`== Missing\`.`,

  'module-binding': `A binding names \`Module\`: a \`let\`, a \`const\`, an assignment, a function, a parameter, a loop variable, a \`match\` pattern or the index of a \`sum\`. \`Module\` is the operator of every qualified name: \`std::pi\` is \`["Module", "Pi"]\` in MathJSON. It cannot be rebound in any scope. The static check reports every such binding. A \`let\`, a \`const\`, an assignment or a \`function\` statement also defines nothing when it runs, and it evaluates to a \`module-binding\` error value. A parameter, a loop variable, a pattern or an index named \`Module\` is still bound when the program runs, but no binding changes what a qualified name reads: the head of a qualified name always reads the library operator \`Module\`.

Choose another name.`,

  'variable-redeclaration': `A \`let\` or \`const\` declares a name that the same scope already declares: an earlier \`let\`/\`const\` of the same block or program, a parameter of the function whose body this is, or the index of the loop whose body this is. In \`function f(x) { let x = x + 1 … }\` the second \`x\` is such a re-declaration.

A second declaration in one scope is a mistake in practice — a \`let\` where an assignment was meant, or a copied line — and the language cannot tell it from a legitimate second run of the same statement (a loop body on its next turn), so it used to overwrite the binding without a word. To update a binding, assign to it: \`x = x + 1\`. To hold a second value, choose another name.

A \`let\` in a NESTED block is not a re-declaration: \`for k in xs { if c { let k = 1 … } }\` and a closure body that declares a name its enclosing scope also has are ordinary shadowing, and stay legal. The initializer of such a shadowing \`let\` reads the OUTER name. Across programs — a rerun notebook cell or a later REPL line — a top-level \`let\` or \`const\` may replace an earlier declaration and establish a new type. Assignment instead preserves the current binding and its contract. Only a repeat within one program is reported.`,

  'read-before-declaration': `A statement of a program or block uses a variable before the statement that declares it. A variable is declared by a \`let\` or a \`const\`. This includes a variable initialized with a function: \`let a = h(1); let h = (x) => x + 1; a\` uses \`h\` too early. A top-level \`function\` statement is different: it is prepared before the other statements and can be called above its definition. In \`do { let a = k; let k = 2; a }\` the first statement reads \`k\`, which the block declares only in the next statement. In \`do { k = 5; let k = 2 }\` the first statement assigns it.

The error is found before the program runs. Move the declaration before the first use, or give the local another name. The initializer of a \`let\` is not such a use: \`let t = t * 2\` in a nested block reads the OUTER \`t\`. A use in a function literal is not such a use either, because it runs when the function is called: a function can read a variable that a later statement of the program or block declares.`,

  'declaration-without-value': `A \`let\` or a \`const\` declares a name without a value: \`let x: integer\`. A declaration gives the name its value, so that a read of the name never finds a local with no value. Write the value in the declaration: \`let x: integer = 0\`. To give the value later in a branch, declare the name with a first value before the branch: \`let t = 0; if c { t = 1 }\`. One declaration needs no value: at the top level of a program, the signature of a function that a \`function\` statement of the same name defines, \`let f: (integer) -> integer; function f(x) { x + 1 }\`. In a function body or a block, a function statement declares a local, so give the type with the value: \`let f: (integer) -> integer = (x) => x + 1\`.`,

  'declaration-below-statement': `A \`let\` or a \`const\` is in a branch of an \`if\` or a \`match\`, or in the body of a loop, without a block around it. A local is declared by a statement of a block or of a function body, and is a local of that block in all of it. Write the declaration as a statement of the block: \`let t = 0; if c { t = 1 }; t\`, or put the branch in a block when the name is a local of the branch only: \`if c { let t = 1; f(t) }\`.`,

  'assignment-to-undeclared-variable': `An assignment writes a variable that is declared, and never declares one. In \`do { t = 1; t }\`, \`t\` has no declaration. Declare the variable with \`let\` or \`const\` in the block, or at the top level of the program, before the assignment: \`do { let t = 1; t }\`. A name declared by an earlier program on the same engine, or by the host, is declared.`,

  'assignment-to-library-function': `A definition in math style, \`Sin(x) := 5\` or \`Sin(x) = 5\`, has the name of a function of the library. At the top level of a program it would replace that function for every later computation on the engine: a later LaTeX \`\\sin(0)\` would give \`5\`. The statement is refused there and in a block or a function body too, and it defines no function.

To define a function of your own, give it another name: \`mySin(x) := 5\`. A name with an initial lowercase letter, \`sin(x) := 5\`, is a name of the program: it hides the library function \`Sin\` only where the program writes \`sin\`. To replace the library function on purpose, write a \`function\` statement: \`function Sin(x) { 5 }\`. A math-style definition after that statement in the same block adds to that function: \`function Sin(x) { 5 }\` then \`Sin(0) := 7\`. In a block inside it, the definition is accepted too, and defines a local function that hides it.

\`At(xs, k) := v\` is not a definition: it assigns to the element \`k\` of the list \`xs\`, as \`xs[k] := v\` does.`,

  'assignment-to-list-element': `An assignment to a list element, \`xs[i] = v\`, gives \`xs\` a new list with the element replaced, as \`xs = replaceAt(xs, i, v)\` does. This error is a write that cannot give a list, and the variable keeps its value.

The target is a name with no value (\`ys[1] = 9\` with \`ys\` not declared). The position is a string (\`xs["a"] = 1\`): \`replaceAt\` takes only an integer position, and \`epsil check\` reports this before anything runs.

A string and a tuple are written as \`replaceAt\` writes them, and give a list: with \`s = "abc"\`, \`s[1] = "z"\` gives the list of characters \`["z", "b", "c"]\`. A position past the end, zero or not an integer is the error \`out-of-range\`; the length of a string is its number of characters. A target that is a number, or a position that selects a number (\`xs[1, 1] = 5\` when \`xs\` is a flat list), is the error \`incompatible-type\` of \`replaceAt\`.`,

  'add-to-target': `The target of \`+=\` is not a variable or a list element. \`s += e\` is \`s = s + e\`, and \`L[i] += e\` is \`L[i] = L[i] + e\`, with the positions that \`L[i] = v\` accepts: \`m[j, i] += e\` and \`m[j][i] += e\` are the same element.

A field (\`p.x += 1\`), a call (\`f(x) += 1\`) and a string position (\`d["a"] += 1\`) are not accepted. Write the assignment in full, \`p.x = p.x + 1\`, where that form is valid.`,

  'parallel-clause-not-first': `In a comprehension, only the first clause can be \`parallel\`: \`[f(x, y) parallel for x in xs, y in ys]\`. The first clause gives the passes, which can run in any order; the other clauses run in order inside each pass, so they cannot be parallel.

To run the inner clause in parallel instead, make it the first clause, or write a parallel comprehension inside the body: \`[[f(x, y) parallel for y in ys] for x in xs]\`.`,

  'parallel-outer-write': `The body of a \`parallel for\` loop changes a variable that is declared outside the loop, and the change is not a \`+=\`. The passes of a parallel loop can run in any order, so a write such as \`L[c] = v\`, \`s = s + 1\` or \`L = replaceAt(L, c, v)\` would give a result that depends on that order.

Write the change as \`+=\`: \`L[c] += 1\`, \`s += x\`. A variable that the body changes with \`+=\` is an accumulator: each pass adds its contributions, and the final value is the value before the loop plus all the contributions. The body can declare and change its own locals with \`let\` and \`=\`.`,

  'parallel-accumulator-read': `The body of a \`parallel for\` loop reads a variable that it also changes with \`+=\` (an accumulator). While the loop runs, the value of an accumulator depends on which passes have run, so a read of it in the body gives an unspecified value. (This is the rule of the Dex language and of OpenMP.)

\`epsil check\` reports a read written by name in the body, also in a function literal written in the body: \`L[c] += L[d]\` and \`if s > 3 { … }\`. A read by another route cannot be found before the program runs, and is not reported: a function that the body calls (\`s += total(k)\` with \`function total(x) { s + x }\`), \`parse("s")\`, a function of the host. Its value is still unspecified. The interpreter and the JavaScript target run the passes in order and give the value that this order gives, but a target that runs the passes in parallel declines such a loop, and a later version can give another value.

Read the value after the loop. To use a value of the list from before the loop, copy it first: \`let H = L\` before the loop, then \`L[c] += H[d]\` in the body.`,

  'parallel-effect': `The body of a parallel loop or a parallel comprehension can have only the \`random\` effect. Its passes can run in any order, so an effect such as \`console\` (\`print\`) or \`state\` would happen in an order that is not specified. The message lists the effects that the engine inferred for the body, also for the functions that it calls: a function of the program has the effects of its body, and a loop variable or a parameter whose type is a function type has the effects of that type. \`any\` means that the body calls a function that can have any effect.

Move the effect out of the loop: collect the values with a parallel comprehension, then print them after it. A random draw is accepted: inside \`WithRandomSeed\`, each pass draws from its own frame, so the values do not depend on the order of the passes.

A call of a function value whose type is not known, such as a function that an unannotated parameter holds, is inferred \`pure\`: in \`function run(fs) { parallel for f in fs { f() } }\`, a \`print\` in a function of \`fs\` is not seen. Annotate the parameter with the effects that it admits (\`fs: list<() any -> any>\`) to have such a loop checked.`,

  'parallel-exit': `A \`break\`, \`continue\` or \`return\` in the body of a parallel loop would leave the loop, or skip the rest of a pass, in an order that depends on how the passes run. A parallel loop always runs every pass.

An inner loop of the body can use \`break\` and \`continue\`: they leave or skip that inner loop only. To skip the rest of a pass, put it in an \`if\`.`,

  'parallel-comprehension-write': `The body of a parallel comprehension changes a variable that is declared outside it. A parallel comprehension gives one element for each pass and changes nothing else, also with \`+=\`.

To add to a variable in each pass, use the statement form: \`parallel for x in xs { s += f(x) }\`. The body of the comprehension can declare and change its own locals in a \`do { … }\` block.`,

  'assignment-in-operand': `An assignment is a statement, not a value. In \`f(a := 2)\` and in \`x = (a := 2) + 1\` the assignment is an operand of another expression. Write the assignment as a statement of its own, then use the name: \`a := 2; f(a)\`. The compound assignment \`+=\` is an assignment too: write \`s += 1; f(s)\`, not \`f(s += 1)\`.`,

  'assignment-type-mismatch': `An assignment gives a variable a value outside its binding type, at the top level as in a block. The type is its explicit annotation (\`let n: integer = 0\`), or else the type of its first value, widened: a number gives \`number\`, a string gives \`string\`, a boolean gives \`boolean\`, and the elements of a list, a set or a tuple widen the same way. So \`let s = 0\` then \`s = s + 0.5\` is valid, and \`let s = 0\` then \`s = "x"\` is this error. An unannotated function initializer gives the variable type \`function\`, rather than fixing the initializer’s full signature: another function value is allowed, but a nonfunction is not. Each function value keeps its own annotations and checks its arguments when called. Use another name for a value of another type, or redeclare the name in a later program to establish a new contract.`,

  'constant-assignment': `A value was assigned to a constant: a name bound by \`const\`, or a constant of the library such as \`Pi\`. In \`const c = 1\` followed by \`c = 2\`, the assignment is refused and \`c\` keeps the value \`1\`. The same holds for an assignment of a function literal (\`const k = (n) => n + 1\` then \`k = (s) => s\`) and for each name of a destructuring assignment (\`(a, c) := (3, 4)\` writes neither \`a\` nor \`c\`).

\`epsil check\` reports an assignment to a \`const\` of the same program (at any depth, and each name of a destructuring \`const\`) before anything runs, wherever the assignment is: at the top level, in a block, a loop body or a function body. The run does not report it a second time. A function defined before a \`const\` of the same block is included, because the \`const\` of a block is declared when the block starts: an assignment in the function writes the constant when the call comes after the \`const\`. The declarations of a program are prepared together, so a function defined before a top-level \`const\` resolves that binding too. Moving the function above the declaration does not make the constant writable. A constant write that is not reported statically is reported when the assignment runs, as a \`runtime-error\` with this code.

To change the value, declare the name with \`let\` instead of \`const\`. To hold a second value, choose another name, or declare a local that shadows the constant: \`let c = 2\` in a function body or a block makes a new binding, and an assignment to it is valid. An indexed assignment such as \`c[1] = 2\` is the rebinding \`c = replaceAt(c, 1, 2)\`, so it is an assignment to \`c\` too, and gives this error.

A host that calls \`ce.assign()\` on a constant gets a thrown error with the same message, whose \`code\` property is \`constant-assignment\`.`,

  'function-redefinition': `Two clauses of one function in a single program have the same dispatch domain, so the second would silently replace the first — \`f(x) = x\` followed by \`f(x) = 2 * x\`. Parameter NAMES are not part of a clause's identity: \`g(n) = n\` then \`g(m) = 2 * m\` collides all the same, so renaming a parameter never resolves this error.

Only replacement is refused. Clauses that dispatch on genuinely different domains accumulate — a different arity (\`k(x)\` and \`k(x, y)\`), different parameter types (\`h(x: integer)\` and \`h(x: string)\`), or a literal pattern (\`g(0) = 99\` alongside \`g(x) = x\`). That is what multi-clause definitions are for.

The boundary is the program (one file, one cell). Within it, a same-domain redefinition is a mistake with no possible intent. Interactively, re-running an edited definition as a SEPARATE program — a later notebook cell, the next REPL line — replaces the earlier one; that is the intended redefinition gesture, and is legal.

In a function body or a block, a function statement declares a local, a variable that holds one function: a second definition of the name in the same block, with any domain, is the error \`variable-redeclaration\`, as two \`let\` of one name are. \`epsil check\` reports it, and the block is invalid: in \`function g() { f(y) = 1; f(x) = 3; f(0) }\`, \`g\` is not defined. A definition in a nested block, or in a function body, of a name of an enclosing scope is not a redefinition: it makes a local function that shadows the outer one. A statement that runs more than once, such as a definition in a loop body, does not collide with itself.`,

  'type-redefinition': `One program declares the same type name twice. A sum type's variant names count as names its statement declares, so a variant colliding with a later \`type\` statement reports this too.

The boundary is the program (one file, one cell): within it, a second declaration of a name is a mistake with no possible intent. To redefine a type interactively, re-run the edited declaration as a SEPARATE program (a later cell) — across programs, redefinition is the intended gesture and is legal. \`protocol\` declarations follow the same rule (see \`epsil doc protocol-redefinition\`).`,

  'protocol-redefinition': `One program declares the same protocol name twice — the protocol counterpart of \`epsil doc type-redefinition\`, with the same rule and the same boundary.

Within one program a redeclaration is a mistake; re-running an edited declaration as a separate program (a later notebook cell) replaces the earlier one and is the intended interactive gesture.`,

  'type-declaration-not-top-level': `A \`type\` statement appears inside a block or a function body. Types are engine-global — a type's name, constructor and conformances are visible to the whole session, never scoped to a block — so a nested declaration would promise a locality it cannot deliver. Declare the type at the top level of the program.

\`protocol\` declarations follow the same rule (see \`epsil doc protocol-declaration-not-top-level\`).`,

  'protocol-function-not-a-field': `A protocol's \`function\` member was read with a dot, as if it were a field or a property.

A protocol declares two kinds of member, and they are used differently. A \`function\` member is CALLED, with the receiver as its first argument: \`span(b)\`, or with the dot and parentheses, \`b.span()\`. A \`readonly\` or \`readwrite\` member is a PROPERTY, read with a dot and no parentheses: \`b.area\`. So \`b.span\` — no parentheses — is a spelling mistake rather than a missing field — the name exists, on a protocol the value conforms to. The parentheses are what make the dot a call; \`b.span\` is never a function value bound to \`b\`.

The mirror mistake, calling a property (\`area(b)\`), is reported as \`protocol-property-not-callable\`.`,

  'unknown-field': `A field was read, with a dot (\`r.b\`) or with a key (\`r["b"]\`), and the value has no field of that name.

A record type lists every field of its values: \`record{a: integer, b: string}\` holds the values with the keys \`a\` and \`b\`, and no other key. So with \`r: record{a: integer}\`, \`r.b\` is refused before the program runs. A field that a value can leave out is declared optional, with a \`?\` after its type: with \`r: record{a: integer, b: string?}\`, \`r.b\` is a \`string\`, and it reads as \`Missing\` when the value has no key \`b\` (as \`NaN\` for a numeric field).

A value that can have any keys is a dictionary: declare it \`dictionary<V>\`, and read a key with \`d["b"]\`.

An object, or a value of a declared type, also has a fixed list of fields; the message names them.`,

  'dot-call-not-a-protocol-function': `A function that is not a protocol member was called with a dot, as in \`xs.Sort()\`.

The dot reaches the MEMBERS of a value: its fields, its protocol properties, and — with parentheses — its protocol functions. \`c.area()\` calls the protocol function \`area\` with \`c\` as its first argument, and is the same call as \`area(c)\`. A library function or a plain user function is not a member of anything, so it is not reached this way: write the call directly, \`Sort(xs)\`, or pipe the value into it, \`xs |> Sort\`. Pipelines are the spelling for chaining such functions: \`xs |> Sort |> Reverse\`.

To make a function callable with the dot, declare it in a \`protocol\` and conform the type to that protocol.`,

  'protocol-declaration-not-top-level': `A \`protocol\` statement appears inside a block or a function body. Protocols, like types, are engine-global (see \`epsil doc type-declaration-not-top-level\`), so protocol declarations are legal only at the top level of a program.`,

  'runtime-error': `Runtime problems in Epsil are VALUES, not exceptions: a failing subexpression evaluates to an Error value, which propagates outward through the enclosing expressions. Nothing is thrown, and the rest of the program keeps running.

The parenthesized chain in the message ("in Characters argument 1, in Map argument 2") is the propagation path, innermost first — where the error was born, then the calls it traveled through. The caret in the report points at the innermost location the source can show.

Only the last statement's value is a program's result, so an error produced by an EARLIER statement would vanish silently; that is why it is reported as a diagnostic. The final statement's error simply is the program's value.

A program produces an error value of its own with \`RuntimeError("code")\` (or \`RuntimeError(ErrorCode("code", details))\`). Do not write \`Error("code")\` for that: a written \`Error\` is a STATIC diagnostic node and marks the expression around it as invalid, so a function whose body spells one is never defined.`,

  'capability-denied': `The program used a capability of the host — the quoted name, for example \`console\` for \`print\` and \`input\` — and the host that runs the program does not allow it. The call evaluates to this error value instead of reaching the host; nothing was printed or read.

Which capabilities a program may use is a decision of the embedding application, not of the program: an application that runs programs it does not trust denies the capabilities they must not reach. There is nothing to fix in the program except to remove the call, or to run the program in a host that allows the capability.

For the author of the host: capabilities are the handlers of \`ce.effects\`. A handler set to \`null\` is a denial; \`ce.withEffects({ console: null }, () => …)\` denies one for the duration of a callback.`,

  'static-type-error': `This problem was detected before anything ran, when the program was canonicalized — the same analysis \`epsil check\` performs.

A static diagnostic never suppresses evaluation: the program still runs exactly as written (errors are values — see \`epsil doc runtime-error\`), so the same mistake may be reported a second time by the run itself. The label distinguishes the tiers: "Type error"/"Static error" for the pre-run analysis, "Runtime error" for the run.`,

  'unknown-module': `A qualified name \`m::x\` names a module that does not exist. The only module is \`std\`, the standard library: \`std::pi\` is the library constant \`Pi\`, and \`std::floor(2.5)\` calls the library function \`Floor\`, also where the program binds \`pi\` or \`floor\` to something else.

A qualified name reads a name of a module, and \`.\` reads a field of a value: to read a field of a variable \`m\`, write \`m.x\`.`,

  'not-a-library-name': `A qualified name \`std::x\` names a definition of the standard library, and the library defines no \`x\`. Both spellings of a library name are valid after \`std::\`: \`std::pi\` and \`std::Pi\` are the constant \`Pi\`. A name of the program is never a library name, so \`std::\` cannot reach a variable or a function that the program defines.

The program still runs, and the qualified name evaluates to a \`not-a-library-name\` error value.`,

  'qualified-call-arguments-canonical': `A call of a library function was made with arguments that were already canonical, where the program binds the name of the function, and the library function holds or binds an argument: the index \`k\` of a sum, the branches of an \`If\`. The MathJSON \`["Apply", ["Module", "Sum"], "k", ["Limits", "k", 1, 3]]\` (the Epsil \`std::sum(k, k in 1..3)\`) is valid: the engine reads the arguments as written. A callee in another form that becomes the library function only when it is canonicalized, such as \`["Apply", ["Sequence", ["Module", "Sum"]], …]\`, gets the arguments after they were canonicalized in the scope of the call, where the index \`k\` is a variable of that scope. So the call is an error.

Write the callee as \`["Module", name]\`, in parentheses (\`["Delimiter", ["Module", name]]\`) or not. A library function whose arguments are all values (\`Floor\`, \`Equal\`, \`List\`) accepts canonical arguments, and is called with any form of the callee.`,

  'unknown-protocol': `A conformance test named a protocol that does not exist: \`Conforms(x, "Hashble")\` where no \`protocol Hashble\` was ever declared. A name that does not exist is a mistake to surface, so it is an error — never a quiet \`False\`, which would make a typo indistinguishable from a genuine non-conformance.

This error comes from the \`Conforms\` operator, whose protocol names ride as strings and so are only checkable when it runs. The \`is\` spelling of the same test (\`x is Hashable\`) resolves the name when the program is parsed, so a typo there is reported earlier, as a parse-time diagnostic, and never reaches this error.`,

  'polytype-comparison-unsupported': `A type comparison was given a QUANTIFIED type — a generic signature with a \`where\` clause, such as the type of a built-in like \`Sort\` — and comparing those is not supported: \`Subtype\`, the dynamic test (\`x is T\`, \`MatchesType\`), and \`Conforms\` all reject a quantified operand rather than guess.

Deciding whether one generic signature is a subtype of another engages existential matching — "is there an instantiation that works" — which is a different, harder question than the ground-type compatibility these operators answer. A quantified type is still a legal VALUE (\`Type(Sort)\` observes one, prints it, and round-trips through \`TypeFrom\`/\`StringFrom\`); only comparing it is rejected.

To ask about a SPECIFIC use of a generic, compare the instantiated ground type instead — the type of an actual call's argument or result.`,
};

/**
 * The explanation for a diagnostic code, or `undefined`. Case-insensitive:
 * codes are typed by hand from a rendered diagnostic.
 */
export function explainErrorCode(code: string): string | undefined {
  return ERROR_EXPLANATIONS[code.toLowerCase()];
}
