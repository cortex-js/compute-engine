---
title: Epsil Evaluation
sidebar_label: Evaluation
slug: /epsil/evaluation/
description: "How an Epsil program evaluates: top-level statements run sequentially in one session scope, values stay exact, and errors are ordinary values."
hide_title: true
date: Last Modified
---
# Evaluation

A whole program is prepared before any statement executes. Types and
protocols come first, then function definitions with their paired signature
declarations, then all remaining statements in source order. Statements are
evaluated **sequentially** in that canonical order, and the program's value
is the **last statement's** value:

```epsil
let x = 5
x = x + 3
x
// ➔ 8
```

No scope is pushed around the whole program: declarations persist across
statements, and across cells in a notebook or inputs in a REPL that share one
session. Blocks and function bodies still push their own lexical scopes (see
[Control Flow](/epsil/control-flow/)). A later program may redeclare a
session name and establish a new type; assignment keeps the existing
binding's contract. See [Declarations](/epsil/declarations/).

## Symbolic by default

Values stay **exact** unless you ask otherwise. A transcendental of an exact
argument stays symbolic —

```epsil
ln(2)
```

evaluates to the symbolic `ln(2)` (the MathJSON `["Ln", 2]`), not a decimal
approximation.

**Numeric approximation is explicit**, via `N(expr)` — it is a function
call, not a language mode:

```epsil
N(ln(2))
```

evaluates to `0.6931471805599453…`.

## Values and bindings

Epsil keeps apart two things many languages blur together:

- A **value** — a number, a string, a list, a dictionary, a function — is
  **immutable**. Once it exists, nothing anywhere can change it.
- A **binding** — the association between a name and a value — is the part
  that changes. `let` introduces a binding you may reassign; `const` one you
  may not. See [Declarations](/epsil/declarations/).

Everything below follows from those two sentences.

**There is no in-place modification.** An assignment to an element,
`xs[2] = 9`, does not change the list: it builds a new list and rebinds the
name, as `xs = replaceAt(xs, 2, 9)` does. Another name that holds the old
list keeps it:

```epsil
let xs = [1, 2, 3]
let ys = xs
xs[2] = 9
[xs, ys]
// ➔ [[1, 9, 3], [1, 2, 3]]
```

So the target must be a name that the program can assign: with
`const xs = [1, 2, 3]`, `xs[2] = 9` is the error `constant-assignment`. An
element of a nested list has the same form, `m[2][1] = 9` or `m[2, 1] = 9`,
which rebinds `m`.

A write that cannot give a list is an error, and the name keeps its value. A
position past the end, zero or not an integer is the error `out-of-range`
(`xs[5] = 9` when `xs` has three elements); the length of a string is its
number of characters. A target with no value is the error
`assignment-to-list-element`, and a target that is a number is the error
`incompatible-type` that `replaceAt` gives. A string and
a tuple are written as `replaceAt` writes them, and give a list: with
`s = "abc"`, `s[1] = "z"` gives the list of characters `["z", "b", "c"]`. A
string position (`xs["a"] = 9`) is the error `assignment-to-list-element`,
reported before the program runs, because `replaceAt` takes only an integer
position. A
position that is a name with no value (`xs[k] = 9` with `k` unknown) leaves
the write unevaluated, and `xs` holds it.

Operators never modify what you hand them — `append`, `sort`, `join`,
`map`, `filter` all return a **new** collection:

```epsil
let xs = [3, 1, 2]
let ys = sort(xs)
(xs, ys)
// ➔ ([3, 1, 2], [1, 2, 3])
```

**Reassigning one name never disturbs another.** Two names holding the same
value are independent, because there is no way to reach a value *through* a
name and alter it:

```epsil
let a = [1, 2, 3]
let b = a
a = [9, 9, 9]
b
// ➔ [1, 2, 3]
```

This is what makes a value safe to pass around: no function you call, and no
name you assign to, can change a collection out from under you. There are no
references, no aliasing and no object identity — two collections are the same
when they have the same contents, and that is all `==` ever asks:

```epsil
[1, 2, 3] == [1, 2, 3]
// ➔ True
```

**A parameter is a binding of its own.** A function may reassign its
parameter; the caller's binding is untouched:

```epsil
function reset(v) {
  v = 0
  v
}
let n = 7
let r = reset(n)
(n, r)
// ➔ (7, 0)
```

**A closure captures the binding, not a snapshot of its value.** This is the
one place where the distinction is directly visible. A function that refers
to an outer name reads that name's *current* value each time it runs:

```epsil
let x = 1
f() = x
x = 2
f()
// ➔ 2
```

Each call of an enclosing function creates fresh bindings, so closures made
by separate calls have separate state, while closures made by the same call
share it:

```epsil
function counter() {
  let n = 0
  function bump() scope { n = n + 1; n }
  bump
}
let c1 = counter()
let c2 = counter()
(c1(), c1(), c2())
// ➔ (1, 2, 1)
```

`c1` and `c2` count independently.

`bump` writes to `n`, which belongs to the enclosing call rather than to
`bump` itself. Writing to a binding outside the function is the `scope`
effect, and it must be declared — without the specifier the definition is
rejected and `counter()` never produces a callable. See
[Effect specifiers](/epsil/control-flow#effect-specifiers). A local of the
function body is declared with `let`: each call gets its own binding, a later
declaration of the same name is not written, and it is not the `scope` effect
(see
[Reassignment vs. declaration](/epsil/declarations/#reassignment-vs-declaration)):

```epsil
function step(k) { let s = k * 2; s + 1 }
let s = 10
(step(1), step(2), s)
// ➔ (3, 5, 10)
```

A read of such a local before its declaration in the function body
(`function step(k) { let r = s; let s = k; r }`) is the
`read-before-declaration` error, and an assignment to a name that is not
declared (`function g(c) { if c { t = 1 }; t }`) is the
`assignment-to-undeclared-variable` error; `epsil check` reports both before
the program runs.

Reach for `const` when a name should not move at all. Constness is a property
of the *binding*, not of the value it holds — every value is immutable
already — and writing to one yields an `Error` value rather than quietly
taking effect:

```epsil
const c = 1
c = 2
```

## Arguments are values — unless the function holds them {#arguments-are-values-unless-the-function-holds-them}

A call evaluates its arguments first and hands the function their values:
with `let a = 3`, `f(a + 1)` receives `4`. A function declared with the
`hold` prefix instead receives each argument **as written** — canonicalized
and bound in the caller's scope, but not evaluated — and evaluates it only
where its body reads it, so it can inspect the expression (`head(e)`),
transform it, or decide whether to evaluate it at all:

```epsil
let a = 3
hold f(e) = head(e)
f(a + 1)
// ➔ Add
```

Every parameter of a `hold` function is held (there is no per-parameter
form), and a parameter read twice is evaluated twice — read it once into a
`let` when that matters. See
[Hold functions](/epsil/control-flow/#hold-functions).

## Collections: literals are values, pipelines are generators

A collection **literal** — a list `[…]`, set `{…}`, tuple `(…)`, or
dictionary — evaluates its elements when the statement executes. Assigning
one to a variable stores a snapshot of the element *values*:

```epsil
let k = 1
let xs = [k, k + 1]
k = 10
xs
// ➔ [1, 2]
```

A spread inside a list literal, `[...xs, k]`, is a snapshot too: the literal
holds the elements of each finite spread operand, also of a lazy one such as
`take(xs, 2)`. Only an infinite spread (`[...1..oo]`) stays a lazy list. See
the [Style Guide](/epsil/style/#building-a-list-one-element-at-a-time) before
growing a list in a loop.

```epsil
let ys = [1, 2, 3, 4]
[...take(ys, 1), 9, ...drop(ys, 2)]
// ➔ [1, 9, 3, 4]
```

Lazy collection **operators** — `Range`, `map`, `filter`, `take`, `join` —
are *generators*: their operands (bounds, sources, functions) are evaluated
when the expression is, but enumeration is deferred until the collection is
materialized (displayed, indexed, aggregated, or iterated).

An **assignment** is a snapshot for them too. When the right-hand side of a
`let` or an `=` is a finite lazy collection that reads a variable, the
statement stores the list of its elements, computed with the values the
variables have at that statement:

```epsil
let xs = [1, 2, 3]
let ys = filter(xs, c => c > 1)
xs = filter(xs, c => c > 2)
(xs, ys)
// ➔ ([3], [2, 3])
```

Two lazy collections stay lazy when they are assigned: one with no last
element (`filter(1..oo, p)`), which cannot be listed, and one that reads no
variable (`map(f, 1..1000000)`), which nothing can change. A `filter` over a
dictionary also stays lazy. Such a collection is made as a call is: a
variable that is one of its operands (`xs` in `filter(xs, p)`, `f` in
`map(f, xs)`) gives the value that it holds at that statement, and its inline
function is a closure. The closure reads a local of the block or the
function that made the collection, and a global, when an element is
computed, so a later assignment of the variable is seen:

```epsil
let k = 3
let big = filter(1..oo, c => c > k)
k = 10
first(big)
// ➔ 11
```

To keep the elements that the collection has at a statement, list them
there: a finite part of it is listed by `listFrom`.

```epsil
let k = 3
let big = filter(1..oo, c => c > k)
let firsts = listFrom(take(big, 3))
k = 10
firsts
// ➔ [4, 5, 6]
```

A lazy collection that is not assigned (an argument, an operand) still reads
program state **at materialization time**, like a generator in Python.

```mermaid
flowchart TD
  rhs["let xs = … or xs = …"] --> lit{"right-hand side<br/>is a literal?"}
  lit -- yes --> snap["stored as its elements: a snapshot"]
  lit -- "no: a lazy collection" --> reads{"reads a variable, as written?<br/>(an inline function counts;<br/>a named function is not inspected)"}
  reads -- "no, as map(f, 1..1000000)" --> lazy["stays lazy: enumerated when materialized"]
  reads -- yes --> fin{"has a last element?"}
  fin -- "no, as filter(1..oo, c => c > k)" --> bound["stays lazy: its variable operands<br/>are read now, its function<br/>when an element is computed"]
  fin -- yes --> snap2["stored as the list of its elements,<br/>computed with the values at this statement"]
```

The test "reads a variable" looks at the expression as written, and does not
look inside a named user function. An inline function that reads a variable
makes the `map` read it, so the assignment stores the elements. A named
function that reads the same variable does not: the `map` stays lazy, and
its elements are computed when they are read, with the value the variable
has then.

```epsil
let n = 1
let v = map((k) => k * n, 1..3)
n = 10
v
// ➔ [1, 2, 3]
```

```epsil
let n = 1
function scale(k) { k * n }
let v = map(scale, 1..3)
n = 10
v
// ➔ [10, 20, 30]
```

To get the elements with the value of `n` at the `let`, write the function
inline, or make a list literal of the elements:
`let v = [...map(scale, 1..3)]` gives `[1, 2, 3]` after `n = 10`.

## Errors are values

Per [Principles](/epsil/principles/), "errors are values": a *runtime*
problem — a type error, an out-of-domain argument, reassigning a `const` —
becomes an `Error` value that propagates outward through the enclosing
expressions and becomes their result, not a thrown exception. A program never
throws to its host for an ordinary runtime problem. Each top-level statement
fails on its own, so an invalid statement or a thrown runtime error does not
prevent later siblings from running:

```epsil
let z = "a" + 1
5
// ➔ 5, with diagnostics for the invalid statement
```

A nested block or function body stops at its error instead of continuing its
remaining statements. Cancellation stops the program; it is not an ordinary
statement failure.

*Parse*-time problems are different: a malformed program surfaces as a
**diagnostic**, not as a value. So do the few execution-time problems that are
really about the source, not the computation — a gated host pragma, or an
`#error` directive (see below).

Because only the **last** statement's value is the program's result, an error
value produced by an earlier statement would otherwise vanish silently. Each
*non-final* statement that evaluates to an error value therefore also emits
a `runtime-error` diagnostic — for example an assignment to an element past
the end of a list (`xs[5] = 9` when `xs` has three elements), or reassigning
a library constant such as
`Pi`. A same-program `const` write rejected during preparation is already
reported by the static check and is not reported a second time at runtime.

The same applies inside a block: a statement of a loop body, a function body
or an `if` branch whose value is discarded and holds an error is reported, once
for each place in the source. So is the list of a `for` loop or comprehension
header, which no statement holds: in `for x in [1, 1 / "a", 3] { n = n + 1 }`
the loop runs three turns, and the list `[1, 1 / "a", 3]` is reported, also
when the body does not use `x`. A header that is a variable (`for x in xs`) is
not reported again: the statement that gave `xs` its value is. A comprehension
is evaluated when its elements are read, so its header is reported only when
the program reads the list. A `map` or `filter` also reads its list later, but
a statement such as `let ys = map((u) => u, [1, 1 / "a", 3])` is reported at
once, because each read of `ys` gives the error.

A program constructs an error value of its own with `RuntimeError`:

```epsil-live
function reciprocal(x) {
  if x == 0 { RuntimeError("zero-has-no-reciprocal") } else { 1 / x }
}
[reciprocal(4), reciprocal(0)]
// ➔ [1/4, Error("zero-has-no-reciprocal")]
```

The call evaluates to `Error("zero-has-no-reciprocal")`, which a caller takes
apart with [`if let`](/epsil/control-flow/#if-let) or
[`match`](/epsil/control-flow/#match) like any other error value. The
argument is a code string, or an `ErrorCode("code", details…)` when the
error carries data.

Do not write `Error("…")` for this. A written `Error(…)` is a *static*
diagnostic — the node the engine itself inserts where a program is wrong,
such as a type mismatch — and it marks the whole expression around it as
invalid: a function whose body spells `Error("neg")` never gets defined. The
two spellings make the distinction explicit: `Error` is a problem *with the
program*, `RuntimeError` is a failure *produced by running it*.

## Console input and output

`print` writes its operands to the host console — the terminal for the
command-line tools, the developer console in a browser — separated by
spaces and followed by a newline. Strings print their content, without the
quotes; every other value prints its ordinary textual form. It evaluates to
`nothing`:

```epsil
let x = 6
print("x is", x * 7)
// prints: x is 42
```

`input` reads one line of text and evaluates to it as a string, without the
trailing newline. An optional operand is a prompt, displayed before
reading. In a terminal it reads from the terminal (piped standard input
works too); in a browser it opens the `prompt()` dialog. At end-of-input —
or when the dialog is canceled — it evaluates to `nothing`; on a host with
no interactive input at all, the call stays symbolic.

```text
> let name = input("Who? ")
Who? Arno
> print("Hello,", name)
Hello, Arno
```

`print` and `input` are the lowercase spellings of the `Print` and `Input`
operators, like `sin` for `Sin` — not keywords — so a local declaration of
`print` shadows the command like any other library name. See
[Naming](/epsil/naming/).

## Pragma security

`#env(...)` and `#navigator(...)` read state from the host process (or the
browser) at parse time. Because a notebook document can be shared or opened
in an unfamiliar environment, both are **gated off by default**:

<!-- epsil-test: expect-diagnostics -->

```epsil
#env("HOME")
```

by default produces a `host-pragma-disabled` diagnostic and no host read — the
pragma evaluates to `nothing`. A host can opt back in and let `#env`/
`#navigator` read as documented in [Pragmas](/epsil/pragmas/).

The benign pragmas — `#line`, `#column`, `#url`, `#filename`, `#date`,
`#time` — always work; they don't read anything sensitive from the host.

`#error(...)` never crashes the host embedding the program: it becomes an
`error-directive` diagnostic, so a single bad cell is contained.

## Interruptibility

A host can give an evaluation an explicit time budget, and independent
count-based bounds on iteration and recursion depth. A breached limit becomes
an error value (or an `evaluation-canceled` diagnostic when it happens in a
non-final statement) — see
[Execution](/epsil/implementation/#execution) for how a host sets one.

The two kinds of limit end differently:

- An expired **time budget ends the program**. The budget is one deadline for
  the whole run, so once it has passed no later statement could run either:
  the statement that hit it becomes the last one executed, the program's
  value is its `Error("Timeout exceeded", "timeout")`, and the statements
  after it are not evaluated. Statements that completed before the expiry keep
  their effects. The deadline is checked before every statement (and before
  every statement of the static pass), so a program of many cheap statements
  is bounded too, not only one whose single statement runs long.
- A breached **count-based cap** (`iterationLimit`, `recursionLimit`) is
  per-construct: the next statement gets a fresh allowance, so the program
  continues past it. The statement that breached evaluates to the error value,
  and — because a loop is imperative — whatever it assigned before the breach
  stays assigned. A program that reads such a variable afterwards therefore
  sees a *partial* result alongside the `evaluation-canceled` diagnostic.

An Epsil program has **no iteration limit** by default: a loop runs until it
ends, and a program that does not end is a valid program. The time budget is
the bound a host should use. The engine's own default iteration limit (1024
turns of a loop or of a lazy walk) is removed on an engine the first time it
runs an Epsil program, and it stays removed for everything that engine
evaluates afterwards, so that a lazy collection the program returns can be
read in full.

```epsil
let total = 0
for i in 1..5000 { total = total + i * 2 }
total
// ➔ 25005000
```

A host that wants a count-based bound assigns `ce.iterationLimit` before it
runs a program. An assigned limit is kept and applies to Epsil programs: a
loop that exceeds it stops with `iteration-limit-exceeded`, and the host must
then surface `diagnostics` with `value`, because the variables the loop
assigned hold a partial result. The recursion limit (256 nested calls of user
functions by default) always applies.

These limits are cooperative. A browser that evaluates untrusted or potentially
unbounded programs should run Epsil in a Web Worker it can terminate from the
outside. See
[Execution Constraints](/compute-engine/guides/execution-constraints/) for the
complete cancellation model.
