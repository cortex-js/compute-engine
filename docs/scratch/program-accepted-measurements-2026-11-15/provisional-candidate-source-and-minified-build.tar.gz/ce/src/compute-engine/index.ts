import { Complex } from 'complex.js';
import type { AsyncEvaluation } from './boxed-expression/evaluation-epoch.js';
import { BigDecimal } from '../big-decimal/index.js';

import {
  Type,
  TypeParamsOption,
  TypeReference,
  TypeResolver,
  TypeString,
} from '../common/type/types.js';
import { BoxedType } from '../common/type/boxed-type.js';
import { isMacroDef } from './boxed-expression/macro.js';
import { staticViewDiverges } from './static-typing-view.js';
import { dropSpacingOperands } from './latex-syntax/drop-spacing-operands.js';
import { isValidPrimitiveType } from '../common/type/primitive.js';

import type { OneOf } from '../common/one-of.js';
import type { DeadlineFrame } from '../common/interruptible.js';
import { hidePrivateProperties } from '../common/utils.js';

import type { ConfigurationChangeListener } from '../common/configuration-change.js';
import type { KernelPool } from './kernel-pool-types.js';

import type {
  MathJsonExpression,
  MathJsonSymbol,
  MathJsonNumberObject,
} from '../math-json/types.js';

import {
  canonicalInteger,
  MACHINE_PRECISION,
  SMALL_INTEGER,
} from './numerics/numeric.js';

import type {
  ValueDefinition,
  OperatorDefinition,
  AngularUnit,
  RoundingTies,
  AssignValue,
  AssumeResult,
  InferResult,
  Expression,
  BoxedRule,
  BoxedRuleSet,
  BoxedSubstitution,
  CanonicalOptions,
  Metadata,
  Rule,
  RulePurpose,
  Scope,
  InspectableScope,
  NarrowingSink,
  EvalContext,
  ExpressionInput,
  IComputeEngine,
  IntegrationProvider,
  ILatexSyntax,
  BoxedDefinition,
  SymbolDefinitionInput,
  DeclareOptions,
  OperatorDefinitionPatch,
  SequenceDefinition,
  SequenceStatus,
  SequenceInfo,
  OEISSequenceInfo,
  OEISOptions,
  InterpretResult,
  LibraryDefinition,
  OperatorInfo,
  SymbolInfo,
  DefinitionSearchResult,
  ParseDiagnostic,
  BoxedValueDefinition,
  ProtocolRecord,
  ProtocolMembersInput,
  ProtocolImplementationInput,
  InferenceWriteEvent,
  InferenceCauseContext,
  EvaluateOptions,
  ParameterRecord,
} from './global-types.js';

import type {
  LibraryCategory,
  ParseLatexOptions,
  SymbolResolution,
  SerializeLatexOptions,
} from './latex-syntax/types.js';
import { validateStyleOptions } from './latex-syntax/style-options.js';
import { validateDisplayDigits } from './numerics/strings.js';
import { isOperatorDef, isValueDef } from './boxed-expression/utils.js';
import { isLibraryDefinition } from './boxed-expression/implicit-variable-rule.js';
import {
  markEngineSubscriptHandler,
  withStandardLibraryInstall,
} from './boxed-expression/host-handler-changes.js';
import { isInferredDefinition } from './boxed-expression/definition-guards.js';
import { markExternalFact } from './boxed-expression/forward-call-reference.js';
import { recordTypeProvenance } from './boxed-expression/type-provenance.js';
import {
  adoptsForeignEngineObject,
  isFunction,
  isSymbol,
} from './boxed-expression/type-guards.js';
import {
  functionLiteralParameterName,
  markFunctionLiteralParameter,
} from './boxed-expression/function-literal.js';
import { debugBindingsDefault } from './boxed-expression/binding-tombstone.js';
import {
  jsProfileSwitchDefault,
  jsProfileShadowDefault,
  type JsProfileSwitch,
} from './js-profile-switch.js';
import {
  _mapAutoCompileStats,
  type MapAutoCompileStats,
} from './map-auto-compile-stats.js';
import {
  cacheStatsControl,
  type CacheStatsControl,
} from '../common/cache-stats.js';

import { getStandardLibrary } from './library/library.js';
import { pipeStageAsCall } from './library/core.js';

import { DEFAULT_COST_FUNCTION } from './cost-function.js';

import type { BigNum, Rational } from './numerics/types.js';
import {
  isMachineRational,
  isRational,
  mul,
  rationalAsFloat,
} from './numerics/rationals.js';
import {
  ExactNumericValueData,
  NumericValue,
  NumericValueData,
} from './numeric-value/types.js';
import { ExactNumericValue } from './numeric-value/exact-numeric-value.js';
import { BigNumericValue } from './numeric-value/big-numeric-value.js';
import { MachineNumericValue } from './numeric-value/machine-numeric-value.js';

import {
  beginInferenceTransaction,
  endInferenceTransaction,
  box,
  boxFunction,
  optionsToInternal,
  rebind,
} from './boxed-expression/box.js';
import type { FormOption } from './types-serialization.js';
import { boxRules } from './boxed-expression/rules.js';
import { aggregateHotHeadDispatch } from './boxed-expression/rule-index.js';
import { validatePattern } from './boxed-expression/boxed-patterns.js';
import { BoxedString } from './boxed-expression/boxed-string.js';
import {
  BoxedCharacter,
  isSingleGraphemeCluster,
} from './boxed-expression/boxed-character.js';
import { BoxedFunction } from './boxed-expression/boxed-function.js';
import { makeObject } from './boxed-expression/boxed-object.js';
import { _BoxedExpression } from './boxed-expression/abstract-boxed-expression.js';
import './boxed-expression/init-lazy-refs.js';
import { _BoxedOperatorDefinition } from './boxed-expression/boxed-operator-definition.js';
import {
  HARMONIZATION_RULES,
  UNIVARIATE_ROOTS,
} from './boxed-expression/solve.js';
import {
  factorPerfectSquare,
  factorDifferenceOfSquares,
  factorQuadratic,
  factorPolynomial,
} from './boxed-expression/factor.js';

// To avoid circular dependencies, serializeToJson is forward declared. Type
// to import it.
import './boxed-expression/serialize.js';
import { SIMPLIFY_RULES } from './symbolic/simplify-rules.js';

import {
  deriveSubstream,
  nextFrameDraw,
  type RandomSeedFrame,
  type RandomSubstream,
} from './numerics/random.js';
import {
  CapabilityDeniedError,
  DEFAULT_EFFECT_HANDLERS,
  deriveEffectHandlers,
  runWithEvaluationEffects,
} from './effects-registry.js';
import type {
  EffectHandlerOverrides,
  EffectHandlers,
} from './types-effects.js';
import { isValidSymbol } from '../math-json/symbols.js';
import { temporaryName as temporaryNameImpl } from './temporary-name.js';

import { getFunctionProperties } from './function-properties/index.js';
import { contourIntegrate as contourIntegrateImpl } from './symbolic/contour-integrate.js';
import type { ContourInput, ContourIntegralResult } from './types-contour.js';
import type { FunctionProperties } from './function-properties/index.js';
import { whileDefining } from './boxed-expression/declared-parameter-result.js';

import {
  lookupDefinition as lookupDefinitionImpl,
  searchDefinitions as searchDefinitionsImpl,
  suggestOperatorName as suggestOperatorNameImpl,
  declareSymbolValue as declareSymbolValueImpl,
  declareSymbolOperator as declareSymbolOperatorImpl,
  getSymbolValue as getSymbolValueImpl,
  setSymbolValue as setSymbolValueImpl,
  declareType as declareTypeImpl,
  declareFn as declareFnImpl,
  assignFn as assignFnImpl,
  withValuesFn as withValuesFnImpl,
  undeclare as undeclareImpl,
} from './engine-declarations.js';
import type { KindRegistryState } from './types-definitions.js';
import { createKindRegistry } from './boxed-expression/value-kinds.js';
import { canonicalFunctionLiteralOperands } from './function-utils.js';
import { markLibraryCall } from './library-shadowing.js';
import {
  declareProtocolImpl,
  declareProtocolImplementationImpl,
} from './engine-protocols.js';

import {
  pushScope as pushScopeImpl,
  popScope as popScopeImpl,
  pushEvalContext as pushEvalContextImpl,
  popEvalContext as popEvalContextImpl,
  removeEvalContext as removeEvalContextImpl,
  countHolders,
  uncountHolders,
  inScope as inScopeImpl,
  printStack as printStackImpl,
} from './engine-scope.js';

import {
  createScope as createScopeImpl,
  inHarvestScope,
} from './engine-inspectable-scope.js';

import {
  ask as askImpl,
  verify as verifyImpl,
  assumeFn as assumeFnImpl,
  forget as forgetImpl,
} from './engine-assumptions.js';
import { inferFn } from './engine-infer.js';

import {
  declareSequence as declareSequenceImpl,
  getSequenceStatus as getSequenceStatusImpl,
  getSequence as getSequenceImpl,
  listSequences as listSequencesImpl,
  isSequence as isSequenceImpl,
  clearSequenceCache as clearSequenceCacheImpl,
  getSequenceCache as getSequenceCacheImpl,
  getSequenceTerms as getSequenceTermsImpl,
  lookupOEIS as lookupOEISImpl,
  checkSequenceOEIS as checkSequenceOEISImpl,
} from './engine-sequences.js';
import { interpret as interpretImpl } from './interpret-oeis.js';
import { EngineCacheStore } from './engine-cache.js';
import {
  type CommonSymbolTable,
  resetCommonSymbols,
} from './engine-common-symbols.js';
import { CompilationTargetRegistry } from './engine-compilation-targets.js';
import {
  EngineConfigurationLifecycle,
  type StateEvent,
} from './engine-configuration-lifecycle.js';
import {
  type CommonNumberTable,
  createBindingSymbolExpression,
  createLibrarySymbolExpression,
  createNumberExpression,
  createSymbolExpression,
} from './engine-expression-entrypoints.js';
import { SimplificationRuleStore } from './engine-simplification-rules.js';
import { EngineNumericConfiguration } from './engine-numeric-configuration.js';
import { EngineRuntimeState } from './engine-runtime-state.js';
import { EngineBoxingState } from './engine-boxing-state.js';
import { UnitEnvironment } from './binding-unit.js';
import { objectDepCollectorDepth } from './boxed-expression/object-deps.js';
import { sharedEvaluationStarts } from './boxed-expression/shared-evaluation-memo.js';
import { EngineStartupCoordinator } from './engine-startup-coordinator.js';
import { loadLibraryLate } from './engine-library-bootstrap.js';
import { createTypeResolver } from './engine-type-resolver.js';
import {
  createErrorExpression,
  createTypeErrorExpression,
} from './engine-validation-entrypoints.js';

export type * from './global-types.js';

// Free functions backed by a lazily-instantiated global engine
export {
  parse,
  expr,
  simplify,
  evaluate,
  N,
  declare,
  assign,
  expand,
  expandAll,
  factor,
  solve,
  compile,
  getDefaultEngine,
} from './free-functions.js';
export type { FreeFunctionOptions } from './free-functions.js';
import { _setDefaultEngineFactory } from './free-functions.js';

export { validatePattern };

// Export specialized polynomial factoring functions for advanced users
export {
  factorPerfectSquare,
  factorDifferenceOfSquares,
  factorQuadratic,
  factorPolynomial,
};

// Export compilation types and classes for advanced users
export type {
  CompileTarget,
  CompiledOperators,
  CompiledFunctions,
  CompilationOptions,
  CompilationResult,
  CompileMode,
  CompileDiagnostic,
  CompileDiagnosticKind,
  StorageHint,
  StorageKind,
  LanguageTarget,
  TargetSource,
  CompiledFunction,
} from './compilation/types.js';
export {
  CompileDeclineError,
  LaneMismatchError,
  isCompileDeclineError,
  isLaneMismatchError,
} from './compilation/diagnostics.js';

// Export BigDecimal for arbitrary-precision arithmetic
export { BigDecimal } from '../big-decimal/index.js';

// Only the two targets that every engine registers are exported from the
// engine module. The GPU targets are exported by the full entry
// (`src/compute-engine.ts`) and by `src/compile.ts`, so that the `./core`
// entry does not bundle them (`engine-compilation-targets.ts` says why).
export { JavaScriptTarget } from './compilation/javascript-target.js';
export { IntervalJavaScriptTarget } from './compilation/interval-javascript-target.js';
export { BaseCompiler } from './compilation/base-compiler.js';

// Import for internal use
import type {
  LanguageTarget,
  IntervalJsCompilationTarget,
  JavaScriptCompilationTarget,
  CompilationResult,
} from './compilation/types.js';
import { compile as _compile } from './compilation/compile-expression.js';
import { fu as _fu } from './symbolic/fu.js';

/** True if `x`, a part of a complex value given as a double or a big
 * decimal, is zero. `undefined` (a part that is not given) is zero. */
/**
 * The names that the canonical form binds as the implicit variable of an
 * integral that names no variable: the parameters of the function literal in
 * `Integrate(Function(x^2, x), Limits(Nothing, 0, 1))`, the canonical form of
 * `\int_0^1 x^2` (see `implicitLiteralParameters()` in
 * `library/calculus.ts`). In the source these names are free, so their
 * `undeclared-symbol` diagnostics are correct, and the bound-only check of
 * `parse()` skips them.
 */
function implicitIntegralVariables(expr: Expression): Set<string> {
  const result = new Set<string>();
  const visit = (e: Expression): void => {
    if (!isFunction(e)) return;
    const integrand = e.op1;
    if (
      e.operator === 'Integrate' &&
      isFunction(integrand, 'Function') &&
      e.ops
        .slice(1)
        .some(
          (limit) =>
            isFunction(limit, 'Limits') &&
            isSymbol(limit.op1) &&
            limit.op1.symbol === 'Nothing'
        )
    )
      for (const param of integrand.ops.slice(1))
        result.add(functionLiteralParameterName(param));
    for (const op of e.ops) visit(op);
  };
  visit(expr);
  return result;
}

function isZeroLike(x: number | BigDecimal | undefined): boolean {
  if (x === undefined) return true;
  if (typeof x === 'number') return x === 0;
  return x.isZero();
}

/** The value of `x`, a part of a complex value from the host, as an exact
 * integer, or `undefined` when it is not one. A double is an exact integer
 * when it is a safe integer (a larger double is a rounded value). A big
 * decimal is an exact integer when it is integer-valued and its exponent is
 * small enough to write out as digits: `canonicalNumber()` reads a big
 * decimal given alone the same way. */
function exactIntegerPart(x: number | BigDecimal): bigint | undefined {
  if (typeof x === 'number')
    return Number.isSafeInteger(x) ? BigInt(x) : undefined;
  if (x.isInteger() && x.exponent <= 1_000_000) return x.toBigInt();
  return undefined;
}

/**
 *
 * To use the Compute Engine, create a `ComputeEngine` instance:
 *
 * ```js
 * ce = new ComputeEngine();
 * ```
 *
 * If using a mathfield, use the default Compute Engine instance from the
 * `MathfieldElement` class:
 *
 * ```js
 * ce = MathfieldElement.computeEngine
 * ```
 *
 * Use the instance to create boxed expressions with `ce.expr()`.
 *
 * ```js
 * const ce = new ComputeEngine();
 *
 * let expr = ce.expr(["Power", "ExponentialE", ["Multiply", "ImaginaryUnit", "Pi"]]);
 * console.log(expr.N().toString());
 * // ➔ "-1"
 *
 * expr = ce.expr(["Expand", ["Power", ["Add", "a", "b"], 2]]);
 * console.log(expr.evaluate().toString());
 * // ➔ "a^2 + 2ab + b^2"
 * ```
 *
 * @category Compute Engine
 *
 */
/**
 * Walk a raw (pre-canonicalization) MathJSON expression and collect the
 * symbols that appear in function-application syntax `f(…)` — encoded as an
 * `InvisibleOperator` with a symbol immediately followed by a `Delimiter`.
 * In a scope-aware parse, a symbol known to be a function is parsed as an
 * application instead, so only non-functions surface here.
 */
function collectAppliedNonFunctions(node: unknown, result: Set<string>): void {
  if (Array.isArray(node)) {
    if (node[0] === 'InvisibleOperator') {
      for (let i = 1; i + 1 < node.length; i++) {
        const head = node[i];
        const next = node[i + 1];
        if (
          typeof head === 'string' &&
          Array.isArray(next) &&
          next[0] === 'Delimiter'
        )
          result.add(head);
      }
    }
    for (const child of node) collectAppliedNonFunctions(child, result);
    return;
  }
  if (
    node !== null &&
    typeof node === 'object' &&
    'fn' in node &&
    Array.isArray((node as { fn: unknown }).fn)
  )
    collectAppliedNonFunctions((node as { fn: unknown }).fn, result);
}

/** The type that the parse oracle answers for a macro (`_scopeResolution()`). */
const MACRO_RESOLUTION_TYPE = new BoxedType('any');

export class ComputeEngine implements IComputeEngine {
  /** @internal Factory for creating LatexSyntax instances. Registered by the
   *  full entry point (compute-engine.ts). When set, `new ComputeEngine()`
   *  lazily creates a LatexSyntax if none was provided in options. */
  static _latexSyntaxFactory: (() => ILatexSyntax) | null = null;

  // Common symbols
  readonly True: Expression;
  readonly False: Expression;
  readonly Pi: Expression;
  readonly E: Expression;
  readonly Nothing: Expression;
  readonly Missing: Expression;

  // Common numbers
  readonly Zero: Expression;
  readonly One: Expression;
  readonly Half: Expression;
  readonly NegativeOne: Expression;
  readonly Two: Expression;
  readonly I: Expression;
  readonly NaN: Expression;
  readonly PositiveInfinity: Expression;
  readonly NegativeInfinity: Expression;
  readonly ComplexInfinity: Expression;

  /** @internal */
  private _numericConfiguration: EngineNumericConfiguration;

  /** @internal The factory of the inexact (float) numeric values of this
   * engine. Every exact numeric value that this engine makes keeps this
   * function (`ExactNumericValue.factory`) and calls it for its float
   * value (`.N()`) and for its float arithmetic. The function reads the
   * precision of the engine at each call, not when the exact value is
   * made: a literal made at machine precision gets a big decimal value
   * with all the digits of a precision that is raised later (with the
   * `precision` setter or with `_withTransientPrecision`), and a machine
   * value again when the precision is lowered back to machine. */
  readonly _inexactNumericValue = (
    x: number | BigDecimal | NumericValueData
  ): NumericValue =>
    this._numericConfiguration.precision > MACHINE_PRECISION
      ? new BigNumericValue(x)
      : new MachineNumericValue(x);

  /** @internal */
  private _cacheStore = new EngineCacheStore();

  /** @internal Runtime execution limits and verification mode state */
  private _runtimeState = new EngineRuntimeState();

  /** @internal Construction-local boxing repair state */
  readonly _boxingState = new EngineBoxingState<Scope>();

  /** @internal Configuration change generation/tracking lifecycle */
  private _configurationLifecycle = new EngineConfigurationLifecycle();

  /** @internal */
  private _cost?: (expr: Expression) => number;

  /** @internal Optional symbolic-integration provider consulted by the
   * `Integrate` evaluator before the built-in antiderivative. Registered by
   * the opt-in `loadIntegrationRules()` (Rubi rule driver). */
  _integrationProvider?: IntegrationProvider;

  /** @internal Backing state for simplificationRules */
  private _simplificationRules = new SimplificationRuleStore([
    ...SIMPLIFY_RULES,
  ]);

  /** @internal Backing state for solveRules */
  private _solveRules = new SimplificationRuleStore([...UNIVARIATE_ROOTS]);

  /** @internal Backing state for harmonizationRules */
  private _harmonizationRules = new SimplificationRuleStore([
    ...HARMONIZATION_RULES,
  ]);

  /** @internal Registry of compilation targets */
  private _compilationTargets = new CompilationTargetRegistry();

  /** @internal Fu trigonometric simplification algorithm */
  _fuAlgorithm = _fu;

  /** @internal Names installed by a CALLER-supplied library (see
   * `engine-library-bootstrap.ts`). Fixed once the constructor returns:
   * `loadLibrary()` installs into the global scope and does not add to it. */
  readonly _customLibraryOperators = new Set<string>();

  /** @internal See `IComputeEngine._libraryProvenance`. */
  readonly _libraryProvenance = new Map<
    string,
    { library: string; binding: BoxedDefinition }
  >();

  /** @internal See `IComputeEngine._loadedLibraries`. */
  readonly _loadedLibraries = new Map<string, LibraryDefinition>();

  /** @internal */
  private _commonSymbols: CommonSymbolTable = {
    Pi: null,

    True: null,
    False: null,

    All: null,
    Nothing: null,
    Missing: null,
    None: null,

    // Note: `ImaginaryUnit` is deliberately NOT interned here. Its definition
    // has `holdUntil: 'never'`, so canonicalizing the symbol must substitute
    // its value, the complex literal `i` (`ce.I`). Interning it would
    // short-circuit that substitution and leave a second canonical spelling of
    // the imaginary unit (the symbol) alongside `["Complex", 0, 1]`.
    ExponentialE: null,
  };

  /** @internal */
  private _commonNumbers: CommonNumberTable = {
    '-5': null,
    '-4': null,
    '-3': null,
    '-2': null,
    2: null,
    3: null,
    4: null,
    5: null,
    6: null,
    7: null,
    8: null,
    9: null,
    10: null,
    11: null,
    12: null,
    36: null,
  };

  /** @internal Interned `BoxedType`s for primitive type names (P-BOX).
   * Primitive names can never be shadowed by a user-declared type, so a
   * per-engine singleton is safe — and identity-stable, which keeps caches
   * keyed on `BoxedType` identity (e.g. the R-D5 display projection) from
   * missing on every `engine.type('number')`. */
  private _commonTypes = new Map<string, BoxedType>();

  /**
   * The stack of evaluation contexts.
   *
   * An **evaluation context** tracks the current lexical scope and
   * assumptions. Symbol values are stored in their definitions, not here.
   */
  _evalContextStack: EvalContext[] = [];

  /** The current evaluation context */
  get context(): EvalContext {
    return this._evalContextStack[this._evalContextStack.length - 1];
  }

  get contextStack(): ReadonlyArray<EvalContext> {
    return [...this._evalContextStack];
  }

  set contextStack(stack: ReadonlyArray<EvalContext>) {
    // A frame that the new stack does not keep is dropped without a pop.
    // A frame that the new stack adds holds the definitions of its scope,
    // unless it was discarded (`countHolders`). A dropped frame no longer
    // holds them, so the pop of another frame that holds one of them
    // disposes it. A definition that an earlier pop kept only for the
    // dropped frames is disposed now (`uncountHolders`); the other
    // definitions of a dropped frame are not. The new frames are counted
    // first, so a frame both dropped and added keeps its count.
    const kept = new Set(stack);
    for (const frame of stack) countHolders(frame);
    for (const frame of this._evalContextStack)
      if (!kept.has(frame)) uncountHolders(this, frame);
    this._evalContextStack = [...stack];
  }

  /** The engine-level type registry: one namespace of declared types per
   * engine, world state alongside symbol assignment. Types are NOT lexically
   * scoped (`docs/TYPE-SYSTEM.md`).
   * @internal */
  readonly _typeRegistry: Record<string, TypeReference> = Object.create(null);

  /** The engine-level PROTOCOL registry — the second kind of registry entry
   * (`docs/TYPE-SYSTEM.md`), engine-global for the
   * same reason types are: a conformance is a fact about a TYPE, not about a
   * position in a scope chain. Protocol names are NOT types (P8).
   * @internal */
  readonly _protocolRegistry: Record<string, ProtocolRecord> =
    Object.create(null);

  /** See `IComputeEngine._protocolExtendsConflicts`.
   * @internal */
  readonly _protocolExtendsConflicts: Set<string> = new Set();

  /** The engine-level KIND registry: the value kinds declared by the
   * `arithmetic` field of operator definitions. Read and written through
   * `boxed-expression/value-kinds.ts` only.
   * @internal */
  readonly _kindRegistry: KindRegistryState = createKindRegistry();

  /** Backing store for {@link _conformanceVersion}. */
  private _conformanceVersionCounter = 0;

  /** See `IComputeEngine._conformanceVersion`. @internal */
  get _conformanceVersion(): number {
    return this._conformanceVersionCounter;
  }

  /** See `IComputeEngine._noteConformanceRegistryChange`. @internal */
  _noteConformanceRegistryChange(): void {
    this._conformanceVersionCounter += 1;
  }

  /** See `IComputeEngine._staticTypeCheckDepth`. @internal */
  _staticTypeCheckDepth = 0;

  /** See `IComputeEngine._epsilBatchId`. @internal */
  _epsilBatchId: number | undefined = undefined;





  /** See `IComputeEngine._epsilDeclarationRoute`. @internal */
  _epsilDeclarationRoute = false;

  /** See `IComputeEngine._epsilStatementResultHook`. @internal */
  _epsilStatementTimeLimitMs: number | undefined = undefined;
  _epsilStatementResultHook:
    ((statement: Expression, result: Expression, programIndex?: number, error?: unknown) => void) | undefined =
    undefined;

  /** Capture the registry's state and return a rollback thunk restoring it.
   *
   * For the Epsil STATIC PRE-PASS, which canonicalizes every top-level
   * statement for diagnostics only: a `DeclareType` registers at
   * canonicalization time (so later statements of the same program check
   * against the new definition), and the rollback discards those
   * registrations so the program's real evaluation performs them in
   * statement order, on the real state. Records are REPLACED IN PLACE
   * elsewhere (captures hold the record object), so the snapshot is
   * per-record FIELDS, not just the name table.
   * @internal */
  _typeRegistryRollbackPoint(): () => void {
    const registry = this._typeRegistry;
    const names = new Set(Object.keys(registry));
    const fields = [...names].map((name) => {
      const r = registry[name] as TypeReference & {
        _declaredByStatement?: boolean;
        _forwardArity?: Set<number>;
      };
      return {
        r,
        def: r.def,
        alias: r.alias,
        typeParams: r.typeParams,
        varianceState: r._varianceState,
        varianceBlockedOn: r._varianceBlockedOn,
        declaredByStatement: r._declaredByStatement,
        forwardArity:
          r._forwardArity === undefined ? undefined : new Set(r._forwardArity),
        sumOf: r._sumOf,
        sumVariants: r._sumVariants,
        // REDEFINITION DISCIPLINE — the origin stamp must go back too. The
        // pre-pass registers a `type` statement and this thunk undoes it; a
        // LEAKED stamp would make the evaluation loop's registration of that
        // very statement look like a second declaration of the same unit (its
        // fresh boxing carries a different statement identity), turning every
        // checked-then-run `type` statement into a false
        // `type-redefinition`. See
        // `docs/TYPE-SYSTEM.md`.
        declOrigin: r._declOrigin,
        // Whether the declaration minted a constructor: read by the kind
        // registration (`boxed-expression/value-kinds.ts`), so a rolled-back
        // declaration must not leave it behind.
        minted: r._minted,
      };
    });
    return () => {
      // Track whether the restore actually changed anything: the rollback
      // runs on EVERY static pre-pass (i.e. every `executeEpsil` call), and
      // the overwhelming majority of programs declare no types at all.
      // Bumping the version axes unconditionally would cold every
      // mutation-keyed cache on every run — the exact anti-pattern the
      // conditional `_assumptionsDirty` bump in `engine-scope.ts` exists to
      // avoid (Tycho item 38).
      let changed = false;
      for (const k of Object.keys(registry))
        if (!names.has(k)) {
          delete registry[k];
          changed = true;
        }
      for (const s of fields) {
        const r = s.r;
        if (r.def !== s.def) changed = true;
        r.def = s.def;
        if (r.alias !== s.alias) changed = true;
        r.alias = s.alias;
        if (r.typeParams !== s.typeParams) changed = true;
        if (s.typeParams === undefined) delete r.typeParams;
        else r.typeParams = s.typeParams;
        if (r._varianceState !== s.varianceState) changed = true;
        if (s.varianceState === undefined) delete r._varianceState;
        else r._varianceState = s.varianceState;
        if (r._varianceBlockedOn !== s.varianceBlockedOn) changed = true;
        if (s.varianceBlockedOn === undefined) delete r._varianceBlockedOn;
        else r._varianceBlockedOn = s.varianceBlockedOn;
        const holder = r as { _declaredByStatement?: boolean };
        if (holder._declaredByStatement !== s.declaredByStatement)
          changed = true;
        if (s.declaredByStatement === undefined)
          delete holder._declaredByStatement;
        else holder._declaredByStatement = s.declaredByStatement;
        const arities = r as { _forwardArity?: Set<number> };
        // Snapshot took a COPY of the arity set (it is mutated in place), so
        // compare contents, not identity.
        const before = arities._forwardArity;
        const after = s.forwardArity;
        if (
          (before === undefined) !== (after === undefined) ||
          (before !== undefined &&
            after !== undefined &&
            (before.size !== after.size ||
              [...after].some((n) => !before.has(n))))
        )
          changed = true;
        if (after === undefined) delete arities._forwardArity;
        else arities._forwardArity = after;
        // Sum-sugar bookkeeping (A6): declaration metadata, restored with the
        // rest of the record so a rolled-back pre-pass declaration cannot
        // leave a stale `sumOf`/variant list behind for the compile tier.
        if (r._sumOf !== s.sumOf) changed = true;
        if (s.sumOf === undefined) delete r._sumOf;
        else r._sumOf = s.sumOf;
        if (r._sumVariants !== s.sumVariants) changed = true;
        if (s.sumVariants === undefined) delete r._sumVariants;
        else r._sumVariants = s.sumVariants;
        // The redefinition stamp (see the snapshot above). Deliberately NOT
        // counted as a `changed` field: it selects nothing a boxed expression
        // could have read, so restoring it alone must not cold every
        // mutation-keyed cache — the same reasoning that makes the whole
        // bump conditional. (The P47 `_implOrigin` restore below is silent for
        // the same reason.)
        if (s.declOrigin === undefined) delete r._declOrigin;
        else r._declOrigin = s.declOrigin;
        if (r._minted !== s.minted) changed = true;
        if (s.minted === undefined) delete r._minted;
        else r._minted = s.minted;
        // A record that vanished from the table but is still captured by a
        // pre-pass-built type keeps its restored fields — same contract as a
        // statement replacement rollback.
        if (!(r.name in registry)) {
          registry[r.name] = r;
          changed = true;
        }
      }
      // A rollback that restored something is a type redefinition for
      // anything boxed against the pre-pass state: bump all three axes,
      // mirroring the declaration path's replacement bump. A no-op rollback
      // (no `type` statements in the program) bumps nothing.
      if (changed) {
        // Classified `config` for the state-event dispatch: a type-statement
        // rollback is a global type-redefinition event (G+M+E, selected by
        // every axis). Recorded in the design's §2 table (2b addenda).
        this._noteStateEvent({ kind: 'config' });
      }
    };
  }

  /** Capture the PROTOCOL registry's state and return a rollback thunk — the
   * protocol mirror of {@link _typeRegistryRollbackPoint}, and invoked
   * alongside it by the Epsil static pre-pass. Same contract in every respect:
   * records are replaced IN PLACE elsewhere, so the snapshot is per-record
   * FIELDS (with the conformance ARRAY copied, since it is pushed to in
   * place), and the thunk bumps the invalidation axes only when it actually
   * restored something.
   * @internal */
  _protocolRegistryRollbackPoint(): () => void {
    const registry = this._protocolRegistry;
    const names = new Set(Object.keys(registry));
    const fields = [...names].map((name) => {
      const r = registry[name];
      return {
        r,
        members: r.members,
        // The parent list is replaced (never mutated in place) by a
        // replacement of the protocol, so the array reference is enough.
        extends: r.extends,
        conformances: [...r.conformances],
        // Conformance records are mutated in place too (an implementation
        // block fulfils a pending edge), so their fields are snapshotted with
        // the list.
        edges: r.conformances.map((c) => ({
          c,
          impl: c.impl,
          // The author's block rides with the merged map it was merged into:
          // it is what tells an author's EMPTY block from no block at all,
          // and restoring one without the other would leave the edge claiming
          // an implementation nobody wrote (or disowning one somebody did).
          authored: c._authored,
          // The batch stamp rides with the implementation it describes (P47):
          // the pre-pass installs a block, this thunk removes it again, and
          // the evaluation loop's install must not then see the pre-pass's
          // own stamp as a duplicate.
          origin: c._implOrigin,
          pending: c.pending,
          // The pending REASON rides with the flag it explains: a re-settled
          // edge (a protocol replacement, a redefinition of the target type)
          // records why it went pending, and restoring the flag without the
          // reason would leave the end-of-batch warning quoting a layout
          // change this rollback just undid.
          pendingReason: c._pendingReason,
          // The statement protocol that installed the edge's part rides with
          // the part: a later conformance with a block reads it to decide
          // which authored edges it replaces.
          via: c._via,
          // The flag that lets a wider conditional conformance replace a
          // derived edge rides with the edge, like the stamp above.
          derived: c._derived,
        })),
        declaredByStatement: r.declaredByStatement,
        // The whole-SUM conformances, copied because the list is pushed to in
        // place: the pre-pass registers `type <sum> is P` and this thunk undoes
        // its edges, so the remembered statement must go with them — left
        // behind, it would hand its block to a variant a later declaration of
        // that sum adds, on the strength of a statement that was rolled back.
        sumConformances:
          r._sumConformances === undefined
            ? undefined
            : [...r._sumConformances],
        // REDEFINITION DISCIPLINE — the protocol mirror of the type registry's
        // `declOrigin` snapshot: the pre-pass registers a `protocol` statement
        // and this thunk undoes it, so a leaked stamp would make the
        // evaluation loop's registration of that same statement a false
        // `protocol-redefinition`
        // (`docs/TYPE-SYSTEM.md`).
        declOrigin: r._declOrigin,
      };
    });
    return () => {
      let changed = false;
      for (const k of Object.keys(registry))
        if (!names.has(k)) {
          delete registry[k];
          changed = true;
        }
      for (const s of fields) {
        const r = s.r;
        if (r.members !== s.members) changed = true;
        r.members = s.members;
        // A different parent list changes which edges a conformance
        // registers, so restoring it is a change.
        if (r.extends !== s.extends) changed = true;
        r.extends = s.extends;
        if (r.declaredByStatement !== s.declaredByStatement) changed = true;
        r.declaredByStatement = s.declaredByStatement;
        // The redefinition stamp (see the snapshot above); silent, like the
        // `_implOrigin` restore further down — it selects nothing a boxed
        // expression could have read.
        if (s.declOrigin === undefined) delete r._declOrigin;
        else r._declOrigin = s.declOrigin;
        // The conformance list is MUTATED in place (pushed to), so the
        // snapshot took a copy and the comparison is on contents.
        if (
          r.conformances.length !== s.conformances.length ||
          s.conformances.some((c, i) => r.conformances[i] !== c)
        )
          changed = true;
        r.conformances = s.conformances;
        for (const e of s.edges) {
          if (e.c.impl !== e.impl) changed = true;
          if (e.impl === undefined) delete e.c.impl;
          else e.c.impl = e.impl;
          // Silent, like the `_implOrigin` restore below: the authored block
          // selects nothing a boxed expression could have read, so restoring
          // it does not on its own make the registry look changed.
          if (e.authored === undefined) delete e.c._authored;
          else e.c._authored = e.authored;
          if (e.origin === undefined) delete e.c._implOrigin;
          else e.c._implOrigin = e.origin;
          if (e.c.pending !== e.pending) changed = true;
          e.c.pending = e.pending;
          // Silent, like the `_implOrigin` restore above: the reason is
          // diagnostic text, so restoring it alone cannot have changed any
          // answer a boxed expression read.
          if (e.pendingReason === undefined) delete e.c._pendingReason;
          else e.c._pendingReason = e.pendingReason;
          // Silent, like the `_implOrigin` restore: the stamp selects nothing
          // a boxed expression could have read.
          if (e.via === undefined) delete e.c._via;
          else e.c._via = e.via;
          if (e.derived === undefined) delete e.c._derived;
          else e.c._derived = e.derived;
        }
        // The remembered whole-sum statements (see the snapshot above).
        // Silent, like the `_implOrigin` restore: they select nothing a boxed
        // expression could have read — they are consulted only when a sum is
        // re-declared with a new variant.
        if (s.sumConformances === undefined) delete r._sumConformances;
        else r._sumConformances = s.sumConformances;
        // A record that vanished from the table but is still captured keeps
        // its restored fields — the type-registry contract.
        if (!(r.name in registry)) {
          registry[r.name] = r;
          changed = true;
        }
      }
      if (changed) {
        this._noteStateEvent({ kind: 'config' });
        // A rollback is itself a change to the conformance registry: a derived
        // dispatcher effect union computed while the pre-pass registrations
        // were in place must not be served to the real evaluation, which sees
        // the restored world.
        this._noteConformanceRegistryChange();
      }
    };
  }

  /** See `IComputeEngine._resultMayBeDiscarded`.
   * @internal */
  _resultMayBeDiscarded(): boolean {
    return (
      this._staticTypeCheckDepth > 0 ||
      this._boxingState.trialEnvironment() !== undefined
    );
  }

  /** See `IComputeEngine._withBoxingPassWindow`.
   * @internal */
  _withBoxingPassWindow<T>(fn: () => T): T {
    beginInferenceTransaction(this);
    try {
      return fn();
    } finally {
      endInferenceTransaction(this);
    }
  }

  /** See `IComputeEngine.declareProtocol`. Throws on error, including on
   * re-declaration (P5) — the Epsil statement route replaces instead. */
  declareProtocol(
    name: string,
    members: ProtocolMembersInput,
    options?: { extends?: readonly string[] }
  ): void {
    declareProtocolImpl(
      this,
      name,
      members,
      options?.extends === undefined ? undefined : { extends: options.extends }
    );
  }

  /** See `IComputeEngine.declareProtocolImplementation`. Throws on error —
   * including on a second implementation of the same (type, protocol) pair
   * (P5) — where the Epsil statement route returns an error value. */
  declareProtocolImplementation(
    type: string,
    protocol: string,
    impl: ProtocolImplementationInput,
    options?: { where?: string }
  ): void {
    declareProtocolImplementationImpl(this, type, protocol, impl, options);
  }

  /** See `IComputeEngine.conformsTo`. */
  conformsTo(type: Type | TypeString, protocol: string): boolean {
    return (
      this._typeResolver.conformsTo?.(this.type(type).type, protocol) ?? false
    );
  }

  /** @internal */
  private __typeResolver: TypeResolver | undefined;

  /** @internal */
  get _typeResolver(): TypeResolver {
    // The resolver reads `this.context` dynamically, so a single instance
    // remains valid across scope changes — create it once and reuse it
    // (this getter is hit on essentially every `.type` computation).
    this.__typeResolver ??= createTypeResolver(this);
    return this.__typeResolver;
  }

  /**
   * Declare a new type in the current scope.
   *
   * By default, types are nominal. To declare a structural type, set
   * `alias` to `true`.
   *
   * `fromStatement` marks the declaration as coming from a `DeclareType`
   * statement: such a declaration may be replaced by a later `DeclareType`
   * statement for the same name in the same scope (a re-run of the program).
   *
   * A declaration also mints a value-level **constructor** operator of the
   * same name in the same scope (nominal-types design §4.1): `point(1, 2)` is
   * how a nominal type is inhabited. Minting is unconditional per the design;
   * `mint: false` is an internal escape hatch for a declaration that must not
   * claim the value name (no caller uses it today).
   */
  declareType(
    name: string,
    type: BoxedType | Type | TypeString,
    options?: {
      alias?: boolean;
      fromStatement?: boolean;
      /** Whether the declaration also declares a value-level constructor
       * of the same name (`point(1, 2)` for `type point = tuple<…>`). Default
       * `true`. A VALUE KIND uses `false`: its type is a nominal type defined
       * as exactly `value` (`ce.declareType('gf8', 'value', { mint: false })`),
       * and its values are made by the head that declares its arithmetic
       * (`GF8(3)`), so a second constructor with no arithmetic must not
       * exist. See the `arithmetic` field of `OperatorDefinition`. */
      mint?: boolean;
      /** A generic type ALIAS's parameter clause
       * (`{ alias: true, typeParams: ['T'] }`): the body is then parsed with
       * those names in scope as type VARIABLES, and every use must apply them
       * (`Pair<integer>`), which expands eagerly into the substituted body. */
      typeParams?: TypeParamsOption;
    }
  ): void {
    declareTypeImpl(this, name, type, options);
  }

  /**
   * A list of the function calls to the current evaluation context,
   * most recent first.
   */
  get trace(): ReadonlyArray<string> {
    return this._evalContextStack
      .map((ctx) => ctx.name)
      .filter((x) => x !== undefined)
      .reverse();
  }

  /**
   * The `any` invalidation axis — advanced by every state event whose mask
   * selects it. READ-ONLY since the step-2b cutover: all advancement goes
   * through `_noteStateEvent` and the dispatch table
   * (`engine-configuration-lifecycle.ts`, `axisMaskOf` — the per-kind masks
   * are documented there and in the design's §2/§5).
   * @internal
   */
  get _anyVersion(): number {
    return this._configurationLifecycle.anyVersion;
  }

  /** See `IComputeEngine._typeVersion`.
   * @internal */
  get _typeVersion(): number {
    return this._configurationLifecycle.typeVersion;
  }

  /**
   * The `semantic` invalidation axis — semantic mutations only; excludes
   * ephemeral loop-index writes and clean scope pops, so caches keyed on it
   * (the `Comprehension` element memo) survive unrelated scoped
   * evaluations. READ-ONLY since the step-2b cutover — see `_anyVersion`.
   * @internal
   */
  get _semanticVersion(): number {
    return this._configurationLifecycle.semanticVersion;
  }

  /**
   * The `world` invalidation axis — rare global-semantics events only
   * (assumptions, redefinition, inference, configuration). A cache whose
   * dependency tracking already covers value writes (the collection element
   * memo) keys on THIS axis, so an unrelated `assign()` does not cold it.
   * READ-ONLY since the step-2b cutover — see `_anyVersion`.
   * @internal
   */
  get _worldVersion(): number {
    return this._configurationLifecycle.worldVersion;
  }

  /**
   * Advanced when an existing definition changes: a retype, a declaration
   * that shadows a callable, or any other change of a callable except a
   * declaration. Keys the memo of a declared function's derived result
   * (`declaredResultMemoKey`); see
   * `EngineConfigurationLifecycle.definitionVersion`. READ-ONLY.
   * @internal
   */
  get _definitionVersion(): number {
    return this._configurationLifecycle.definitionVersion;
  }

  /**
   * Advanced by every state event that can change the value a node
   * evaluates to in an evaluation frame that is still on the stack. Keys the
   * memo of the evaluations of shared nodes (`shared-evaluation-memo.ts`);
   * see `EngineConfigurationLifecycle.evaluationVersion`. READ-ONLY.
   * @internal
   */
  get _evaluationVersion(): number {
    return this._configurationLifecycle.evaluationVersion;
  }

  /**
   * `_evaluationVersion` less the ephemeral value writes (a loop index); see
   * `EngineConfigurationLifecycle.persistentEvaluationVersion`. READ-ONLY.
   * @internal
   */
  get _persistentEvaluationVersion(): number {
    return this._configurationLifecycle.persistentEvaluationVersion;
  }

  /**
   * The `callable` invalidation axis (design §5, step 3) — events that can
   * change what the effects projection reads: world-class events, callable
   * writes/declares/retypes/swaps, and assumption-dirty pops. Keys
   * `BoxedFunction._effects` (with a scope-identity stamp). READ-ONLY —
   * see `_anyVersion`.
   * @internal
   */
  get _callableVersion(): number {
    return this._configurationLifecycle.callableVersion;
  }

  /**
   * When > 0, value writes are ephemeral loop-index writes: they bump
   * `_anyVersion` and the definition's `_writeVersion` but not
   * `_semanticVersion`. Incremented/decremented (try/finally) around the
   * index assigns of `reduceBigOp` and `ComprehensionIndexFrame`.
   * @internal
   */
  get _ephemeralWriteDepth(): number {
    return this._configurationLifecycle.ephemeralWriteDepth;
  }

  set _ephemeralWriteDepth(value: number) {
    this._configurationLifecycle.ephemeralWriteDepth = value;
  }

  /**
   * When > 0, the assumptions store answers as EMPTY to every consumer that
   * queries it through `contextAssumptions()`, so a computation bracketed by
   * this depth behaves as if no assumption were in force. Sites that COPY or
   * SNAPSHOT the store (a scope push) are exempt.
   * @internal
   */
  get _factSuppressionDepth(): number {
    return this._configurationLifecycle.factSuppressionDepth;
  }

  set _factSuppressionDepth(value: number) {
    this._configurationLifecycle.factSuppressionDepth = value;
  }

  /** See `IComputeEngine._withoutFacts()`.
   * @internal */
  _withoutFacts<T>(thunk: () => T): T {
    // An `async` thunk is refused BEFORE it is invoked: calling it would
    // start its body immediately, and every continuation after its first
    // `await` would run once the bracket below has closed — with the
    // assumptions visible again, the opposite of what the bracket promises.
    if (thunk.constructor.name === 'AsyncFunction')
      throw new Error(
        'A fact-blind bracket must be synchronous: an async thunk is refused before it runs, because everything after its first await would see the assumptions again'
      );
    const lifecycle = this._configurationLifecycle;
    lifecycle.factSuppressionDepth += 1;
    let result: T;
    try {
      result = thunk();
    } finally {
      lifecycle.factSuppressionDepth -= 1;
    }
    // A plain (non-async) thunk can still hand back a promise, and by now
    // its work has already escaped the bracket. Refuse the result rather
    // than hand back a value derived under conditions the caller did not
    // ask for — after detaching the orphaned promise's rejection, so the
    // refusal does not also surface an unhandled-rejection warning later.
    if (
      typeof (result as { then?: unknown } | undefined)?.then === 'function'
    ) {
      void Promise.resolve(result as PromiseLike<unknown>).then(
        undefined,
        () => {}
      );
      throw new Error(
        'A fact-blind bracket must be synchronous: its thunk returned a promise, whose work would run after the bracket closed and would see the assumptions again'
      );
    }
    return result;
  }

  /** See `IComputeEngine._factsHidden()`.
   * @internal */
  _factsHidden(): boolean {
    if (this._factSuppressionDepth === 0) return false;
    const context = this.context;
    if (context === undefined) return false;
    return (
      (context.assumptions?.size ?? 0) !== 0 ||
      (context.assumedValues?.size ?? 0) !== 0
    );
  }

  /** See `IComputeEngine._recursionKnots`.
   * @internal */
  readonly _recursionKnots: Map<string, { depth: number; binding: object }> =
    new Map();

  /** See `IComputeEngine._cacheGeneration()`.
   * @internal */
  _cacheGeneration(): number {
    return this._viewKeyedGeneration(staticViewDiverges(this));
  }

  /** `_baseCacheGeneration()`, or inside the static view of a type
   * computation when `diverges`, a key of its own. */
  private _viewKeyedGeneration(diverges: boolean): number {
    const generation = this._baseCacheGeneration();
    if (!diverges) return generation;
    // Inside a type computation, the bindings are read in the static view
    // (`static-typing-view.ts`): a variable has no value. A sign, a value or
    // an evaluation computed in the view is not the one a read outside it
    // gets, so it is kept under a key of its own: one key for each
    // value of the key outside the view, minted as a shield key is, so that
    // it never equals another key. The facts bit is kept. The key outside the
    // view comes back when a value shield ends, and the same key comes back
    // with it: a new key would retire every sign that the type computation
    // cached before the shield, and a derivation through a deep body then
    // computes them again, once for each shield.
    const axis = Math.floor(generation / 2);
    let key = this._staticViewKeys.get(axis);
    if (key === undefined) {
      // A key of an older `any` version is not used again. The limit only
      // bounds the map: a key minted again costs cache hits.
      if (this._staticViewKeys.size >= 64) this._staticViewKeys.clear();
      key = this._nextValueShieldKey();
      this._staticViewKeys.set(axis, key);
    }
    return key * 2 + (generation & 1);
  }

  /** The key of `_cacheGeneration()` inside the static view of a type
   * computation, for each key outside it. */
  private readonly _staticViewKeys = new Map<number, number>();

  /** `_cacheGeneration()` outside the static view of a type computation. */
  private _baseCacheGeneration(): number {
    const facts = this._factsHidden() ? 1 : 0;
    const shields = this._valueShieldKeys;
    if (shields.length === 0) return this._anyVersion * 2 + facts;
    const top = shields[shields.length - 1];
    // A write inside the shield (a value write, a retype, a configuration
    // change, the index write of each step of a `Sum` under `Integrate`)
    // advances the `any` axis; the shield key must move with it, or an
    // answer cached earlier in the same shield would be served after the
    // write. The key is minted again whenever the axis has moved since it
    // was last read. This also covers an outer shield after an inner one
    // popped: its recorded axis is then outdated too.
    if (top.any !== this._anyVersion) {
      top.key = this._nextValueShieldKey();
      top.any = this._anyVersion;
    }
    return top.key * 2 + facts;
  }

  /** See `IComputeEngine._typeCacheGeneration()`.
   * @internal */
  _typeCacheGeneration(): number {
    if (this._valueShieldKeys.length > 0) return this._baseCacheGeneration();
    const facts = this._factsHidden() ? 1 : 0;
    // The key is the type version, times four: a key of
    // `_typeCacheFallbackGeneration()` is two more. A type does not depend
    // on the scope of its reader, so a call frame has no key of its own.
    return this._configurationLifecycle.typeVersion * 4 + facts;
  }

  /** See `IComputeEngine._typeCacheFallbackGeneration()`.
   * @internal */
  _typeCacheFallbackGeneration(): number {
    // A type does not depend on a value, and a free name is read from its
    // home chain, on which the static view maps the frame of an application
    // to the body scope of its literal (`staticBindingIn()`,
    // `staticParentOf()`) and skips the parameter activations: a type
    // computed inside an application is the one computed outside it, so the
    // view has no key of its own here.
    const generation = this._baseCacheGeneration();
    // A minted key (negative) is unique. A key of the `any` axis is moved
    // out of the values of `_typeCacheGeneration()`: four times the axis,
    // plus two, plus the facts bit.
    if (generation < 0) return generation;
    return Math.floor(generation / 2) * 4 + 2 + (generation & 1);
  }

  /** The value shields on the stack, innermost last: the key in force inside
   * each one and the `any` axis that key was minted for. See
   * `_withValueShieldKey()`. */
  private readonly _valueShieldKeys: { key: number; any: number }[] = [];

  /** The number of shield keys minted so far. Monotone for the lifetime of
   * the engine, so no two shield extents share a key. */
  private _valueShieldCount = 0;

  /** A shield key that no earlier read can have stamped. The keys are the
   * NEGATIVE integers from −2 down, so a shield key can never equal a value
   * of the `any` axis (a non-negative integer), whatever the length of the
   * session. The doubled key with the facts bit (`_cacheGeneration()`) is
   * then −4 or −3, −6 or −5, …: `& 1` gives the facts bit and `>> 1` the
   * same axis half for both cells of a key, as for a non-negative key, and
   * no key is −1, the "no generation" sentinel of the per-node caches
   * (`_type.generation`, `_typeGeneration`, `boxed-function.ts`). */
  private _nextValueShieldKey(): number {
    this._valueShieldCount += 1;
    return -(this._valueShieldCount + 1);
  }

  /** See `IComputeEngine._withValueShieldKey()`.
   * @internal */
  _withValueShieldKey<T>(f: () => T): T {
    this._valueShieldKeys.push({
      key: this._nextValueShieldKey(),
      any: this._anyVersion,
    });
    try {
      return f();
    } finally {
      this._valueShieldKeys.pop();
    }
  }

  /** The source of the `id` of an assumption record. Monotone for the
   * lifetime of the engine, so two assertions of the same normalized fact
   * never share an id.
   * @internal */
  _nextFactId(): number {
    this._factIdCounter += 1;
    return this._factIdCounter;
  }

  private _factIdCounter = 0;

  get _scratchDeclarationScopes(): object[] {
    return this._configurationLifecycle.scratchDeclarationScopes;
  }

  /** See `IComputeEngine._scratchAnyAdvances`.
   * @internal */
  get _scratchAnyAdvances(): number {
    return this._configurationLifecycle.scratchAnyAdvances;
  }

  /** See `IComputeEngine._scratchCallableAdvances`.
   * @internal */
  get _scratchCallableAdvances(): number {
    return this._configurationLifecycle.scratchCallableAdvances;
  }

  /** See `IComputeEngine._inFlightAsyncEvaluations`.
   * @internal */
  _inFlightAsyncEvaluations = 0;

  /** See `IComputeEngine._evaluationDepth`.
   * @internal */
  _evaluationDepth = 0;

  /** See `IComputeEngine._delegatedEvaluations`.
   * @internal */
  _delegatedEvaluations = 0;

  /** See `IComputeEngine._evaluationEffects`.
   * @internal */
  _evaluationEffects: EffectHandlers | undefined = undefined;

  /** See `IComputeEngine._requestedPrecision`.
   * @internal */
  _requestedPrecision: number | undefined = undefined;

  /** See `IComputeEngine._numericRequest`.
   * @internal */
  _numericRequest = false;

  /** The registry assigned to `ce.effects`, before any `withEffects` change.
   * @internal */
  private _baseEffects: EffectHandlers = DEFAULT_EFFECT_HANDLERS;

  /** The `withEffects` calls that are open now, oldest first. A synchronous
   * call is removed when its callback returns; an asynchronous one when its
   * promise settles. It is a list and not a saved-and-restored value because
   * two asynchronous calls can overlap without nesting: if each one put back
   * the value it saw when it started, the one that settles LAST would
   * reinstall the overrides of the one that settled first, permanently.
   * @internal */
  private _effectOverrides: EffectHandlerOverrides[] = [];

  /** The installed registry: `_baseEffects` with every open `withEffects`
   * change applied, oldest first. Recomputed only when one of them changes.
   * @internal */
  private _effects: EffectHandlers = DEFAULT_EFFECT_HANDLERS;

  /** See `IComputeEngine._objectStoreEpoch`.
   * @internal */
  _objectStoreEpoch = 0;

  /** See `IComputeEngine._applicationMemo`.
   * @internal */
  _applicationMemo:
    | WeakMap<
        Expression,
        {
          worldVersion: number;
          objectStoreEpoch: number;
          deps: unknown;
          results: Map<string, Expression>;
        }
      >
    | undefined = undefined;

  /** The state-event choke point — see `IComputeEngine._noteStateEvent`.
   * @internal */
  _noteStateEvent(event: StateEvent): void {
    this._configurationLifecycle.noteStateEvent(event);
  }

  /** Depth of nested top-level boxing operations (see
   * `beginInferenceTransaction` in `box.ts`).
   * @internal
   */
  _inferenceTxDepth = 0;
  _hasAsyncOnlyOperator = false;

  /** See `IComputeEngine._jsProfile`.
   * @internal
   */
  _jsProfile: JsProfileSwitch | undefined = jsProfileSwitchDefault();

  /** See `IComputeEngine._jsProfileShadow`.
   * @internal
   */
  _jsProfileShadow: false | 'ir' = jsProfileShadowDefault();

  /** When true, a scope being discarded tombstones its value definitions and
   * the symbol resolution sites report a use of a dead binding with both
   * stacks (`boxed-expression/binding-tombstone.ts`). Debugging aid, not a
   * semantic mode — defaults from the `CE_DEBUG_BINDINGS` environment
   * variable and can be set programmatically.
   * @internal
   */
  _debugBindings = debugBindingsDefault();

  /** See `IComputeEngine._opensOperation()`.
   * @internal
   */
  _opensOperation(evaluation: boolean): boolean {
    const state = this._boxingState;
    const current = state.currentOperation();
    if (current === undefined) return true;
    // An operation nested in an operation that is not a program runs in the
    // environment of the enclosing operation: the method that opened the
    // operation, called again in it, and every operation of library code.
    if (!current.isProgram) return false;
    // In the environment of a program, an evaluation in the evaluation of a
    // statement by the run driver runs in it.
    return !(evaluation && state.inProgramStatement);
  }

  /** See `IComputeEngine._withOperation()`.
   * @internal
   */
  _withOperation<T>(input: unknown, fn: () => T): T {
    const state = this._boxingState;
    const current = state.currentOperation();
    // A nested operation writes in the environment of the operation that
    // encloses it (see `_opensOperation()`).
    if (current !== undefined && !current.isProgram) return fn();
    return state.withOperation(
      UnitEnvironment.forOperation(input, this.context?.lexicalScope),
      fn
    );
  }

  /** See `IComputeEngine._captureAsyncOperation()`.
   * @internal
   */
  _captureAsyncOperation(evaluation: AsyncEvaluation, input: unknown): void {
    if (evaluation.operation !== undefined) return;
    const state = this._boxingState;
    if (this._opensOperation(true)) {
      evaluation.operation = UnitEnvironment.forOperation(
        input,
        this.context?.lexicalScope
      );
      return;
    }
    evaluation.operation = state.currentOperation();
    if (evaluation.operation?.isProgram && state.inProgramStatement)
      evaluation.programStatement = true;
  }

  /** See `IComputeEngine._withProgramEnvironment()`.
   * @internal
   */
  _withProgramEnvironment<T>(fn: () => T): T {
    return this._boxingState.withOperation(
      UnitEnvironment.forOperation(undefined, this.context?.lexicalScope),
      fn
    );
  }

  /** Value definitions whose type was first inferred (unknown → concrete)
   * during the current top-level boxing operation — forward-computed
   * provenance for the fresh-matrix-inference repair. Lazily allocated by
   * `_noteInferenceWrite()`; reset when the outermost boxing ends.
   * @internal
   */
  _freshlyInferred: Set<BoxedValueDefinition> | null = null;

  /** The operator expression being canonicalized, recorded as the `cause` of
   * provenance entries — see `IComputeEngine._inferenceCause`. Installed
   * with save/restore around `makeCanonicalFunction` (`box.ts`), so nested
   * canonicalizations resolve to the innermost enclosing operator.
   * @internal
   */
  _inferenceCause: InferenceCauseContext | null = null;

  /** The head of the library call that `_libraryCall()` is boxing — see
   * `IComputeEngine._qualifiedHead`. Set and cleared by
   * `boxFunctionInternal()` (`box.ts`).
   * @internal
   */
  _qualifiedHead: { name: string; definition: BoxedDefinition } | undefined =
    undefined;

  /** See `IComputeEngine._macroCount`.
   * @internal */
  _macroCount = 0;

  /** See `IComputeEngine.macroNames`. */
  get macroNames(): ReadonlySet<string> {
    return this._macroNames;
  }

  /** See `IComputeEngine._macroNames`.
   * @internal */
  readonly _macroNames = new Set<string>();

  /** See `IComputeEngine._macroSuspects`.
   * @internal */
  _macroSuspects = 0;

  /** The inference-write choke point — see
   * `IComputeEngine._noteInferenceWrite`. Subscribers, in order: the
   * provenance history on the written definition, the fresh-inference set
   * (unknown → concrete transitions during a boxing, consumed by the
   * fresh-matrix-inference repair in `box.ts`), and the narrowing sink
   * (writes onto definitions outside a contained scope, reported back to
   * `InspectableScope.narrowings()`).
   * @internal */
  _noteInferenceWrite(event: InferenceWriteEvent): void {
    // The cause is materialized lazily: canonicalization is hot and stores
    // only {operator, ops}; the non-canonical wrapper expression is built on
    // the first write that records it. Raw-form boxing binds nothing and
    // canonicalizes nothing, so this cannot recurse into inference.
    const ctx = this._inferenceCause;
    if (ctx && ctx.expr === undefined)
      ctx.expr = this._fn(
        ctx.operator,
        ctx.ops.map((o) => this.expr(o, { form: 'raw' })),
        { canonical: false }
      );
    recordTypeProvenance(event.target, {
      type: event.to,
      kind: event.kind,
      axis: 'type',
      cause: ctx?.expr,
    });

    if (
      event.valueDef !== undefined &&
      event.from.isUnknown &&
      this._inferenceTxDepth > 0
    ) {
      (this._freshlyInferred ??= new Set()).add(event.valueDef);
    }

    this._narrowingSink?._recordNarrowing(
      event.name,
      event.binding,
      event.from,
      event.to
    );
  }

  /** In strict mode (the default) the Compute Engine performs
   * validation of domains and signature and may report errors.
   *
   * These checks may impact performance
   *
   * When strict mode is off, results may be incorrect or generate JavaScript
   * errors if the input is not valid.
   *
   */
  strict: boolean;

  /**
   * Whether the engine may **implicitly** generate and execute compiled code
   * (the `Function` constructor) as a performance optimization — the
   * auto-compilation of lazy-`Map` element lambdas on numeric drains, and the
   * compiled numeric kernels behind `NIntegrate`/`ND`/`NLimit` and the
   * `Integrate`/`Limit` numeric fallbacks.
   *
   * - `'auto'` (default): implicit compilation attempts run. On the first
   *   environment-level failure to *construct* a function (a CSP `EvalError` —
   *   distinct from an ordinary compile failure), the engine latches to
   *   `'off'` engine-wide, so a strict-CSP host generates at most one
   *   violation report.
   * - `'off'`: no implicit code generation is ever attempted; every implicit
   *   path uses the interpreter. Set this up front on strict-CSP pages
   *   (no `'unsafe-eval'`), MV3 extensions, or hardened runtimes — or as a
   *   diagnostic kill switch to bisect interpreter-vs-compiled behavior.
   *
   * Explicit `compile()` calls are exempt: a direct user request keeps
   * failing loudly with the environment's own error, regardless of this flag.
   *
   * Toggling it is an engine-configuration change, like `tolerance`: it
   * bumps the invalidation counters so caches whose entries were produced
   * on the other route (compiled vs interpreted values can differ by the
   * documented ~1 ulp on unit-scaled arguments) are not served across the
   * flip — and so `jit = 'off'` as a diagnostic actually re-runs the
   * interpreter instead of serving compiled-era cached results.
   */
  get jit(): 'auto' | 'off' {
    return this._jit;
  }

  set jit(value: 'auto' | 'off') {
    if (value === this._jit) return;
    this._jit = value;
    this._noteStateEvent({ kind: 'config' });
  }

  private _jit: 'auto' | 'off' = 'auto';

  /**
   * The worker pool that `broadcastAsync()` of a compiled result uses
   * (`createKernelPool`, `kernel-pool.ts`). The engine creates no worker on
   * its own: with no pool every batch runs on the calling thread. One pool
   * can serve several engines; the pool is read at each call, so it can be
   * given or replaced at any time.
   */
  workers: KernelPool | undefined = undefined;

  /**
   * Return symbol tables suitable for the specified categories, or `"all"`
   * for all categories (`"arithmetic"`, `"algebra"`, etc...).
   *
   * Each requested library comes with the libraries it requires, directly or
   * indirectly, in load order: `getStandardLibrary('physics')` gives `core`,
   * `arithmetic`, `units` and `physics`.
   *
   * A symbol table defines how to evaluate and manipulate symbols.
   *
   */

  static getStandardLibrary(
    categories?: LibraryCategory[] | LibraryCategory | 'all'
  ): readonly LibraryDefinition[] {
    return getStandardLibrary(categories);
  }

  /**
   * Construct a new `ComputeEngine` instance.
   *
   * Symbols tables define functions, constants and variables (in `options.ids`).
   * If no table is provided the MathJSON Standard Library is used (`ComputeEngine.getStandardLibrary()`)
   *
   * @param options.precision Specific how many digits of precision
   * for the numeric calculations. Default is 300.
   *
   * @param options.tolerance If the absolute value of the difference of two
   * numbers is less than `tolerance`, they are considered equal. Used by
   * `chop()` as well. The default is `1e-10`, whatever the precision.
   * `'auto'` makes the tolerance follow the precision: `10^(-precision + 2)`,
   * recomputed when the precision changes.
   *
   * @param options.libraries Optional standard/custom library list.
   * Custom library entries are validated during startup (name, dependencies
   * and definitions). The libraries load in dependency order: each library
   * loads after the libraries in its `requires` list and, where that order
   * allows it, in the order of this list.
   */
  constructor(options?: {
    libraries?: readonly (string | LibraryDefinition)[];
    precision?: number | 'machine';
    tolerance?: number | 'auto';
    latexSyntax?: ILatexSyntax;
    latexOptions?: Partial<ParseLatexOptions & SerializeLatexOptions>;
    /** The worker pool for `broadcastAsync()` (`createKernelPool`); the
     * same as setting `ce.workers` after construction. */
    workers?: KernelPool;
  }) {
    if (options !== undefined && typeof options !== 'object')
      throw Error('Unexpected argument');

    this.strict = true;
    this.jit = 'auto';
    this.workers = options?.workers;

    this._numericConfiguration = new EngineNumericConfiguration({
      precision: options?.precision,
      tolerance: options?.tolerance,
      angularUnit: 'rad',
    });

    const startup = new EngineStartupCoordinator(this);
    const commonNumbers = startup.initializeCommonNumbers();

    this.Zero = commonNumbers.Zero;
    this.One = commonNumbers.One;
    this.Half = commonNumbers.Half;
    this.NegativeOne = commonNumbers.NegativeOne;
    this.Two = commonNumbers.Two;
    this.NaN = commonNumbers.NaN;
    this.PositiveInfinity = commonNumbers.PositiveInfinity;
    this.NegativeInfinity = commonNumbers.NegativeInfinity;
    this.I = commonNumbers.I;
    this.ComplexInfinity = commonNumbers.ComplexInfinity;

    // Reset the caches/create (precision-dependent) numeric constants
    this._reset();

    // Create the system scope (top-level scope)
    this.pushScope(undefined, 'system');

    // Declare the standard types. A definition that a declaration makes is a
    // definition of the standard library, not host code
    // (`host-handler-changes.ts`).
    withStandardLibraryInstall(() => {
      this.declareType('limits', 'expression<Limits>');
      // `alias: true` makes `distribution` a *structural* type: a value whose
      // type is `expression<NormalDistribution>` (etc.) is a subtype of the
      // union. A nominal reference (the default) would not match, so `PDF`/
      // `CDF`/`Mean`(distribution)… would reject their distribution argument.
      this.declareType(
        'distribution',
        'expression<NormalDistribution> | expression<BinomialDistribution> | expression<PoissonDistribution> | expression<UniformDistribution> | expression<ExponentialDistribution>',
        { alias: true }
      );
    });

    startup.bootstrapLibraries(options?.libraries);

    const commonSymbols = startup.initializeCommonSymbolBindings(
      this._commonSymbols
    );
    this.True = commonSymbols.True;
    this.False = commonSymbols.False;
    this.Pi = commonSymbols.Pi;
    this.E = commonSymbols.E;
    this.Nothing = commonSymbols.Nothing;
    this.Missing = commonSymbols.Missing;

    // Push a fresh scope to protect system definitions:
    // this will be the "global" scope
    this.pushScope(undefined, 'global');

    // Register default compilation targets
    this._compilationTargets.registerDefaults();

    // Store the injected LatexSyntax instance (if any)
    if (options?.latexSyntax) this._latexSyntax = options.latexSyntax;

    // Store engine-wide LaTeX options (merged into every parse/serialize call)
    if (options?.latexOptions) {
      validateStyleOptions(options.latexOptions);
      validateDisplayDigits(options.latexOptions.digits);
      this._latexOptions = { ...options.latexOptions };
    }

    hidePrivateProperties(this);
  }

  toJSON() {
    return '[ComputeEngine]';
  }

  [Symbol.toStringTag]: string = 'ComputeEngine';

  /** After the configuration of the engine has changed, clear the caches
   * so that new values can be recalculated.
   *
   * This needs to happen for example when the numeric precision changes.
   *
   * @internal
   */
  _reset(): void {
    this._configurationLifecycle.reset({
      refreshNumericConstants: () => {
        // BigDecimal constants are static/frozen — nothing to refresh
      },
      resetCommonSymbols: () => resetCommonSymbols(this._commonSymbols),
      purgeCaches: () => this._cacheStore.purgeValues(),
    });
  }

  /** @internal */
  _listenToConfigurationChange(
    tracker: ConfigurationChangeListener
  ): () => void {
    return this._configurationLifecycle.listen(tracker);
  }

  /** @internal Compile a boxed expression. */
  _compile(
    expr: Expression,
    options?: Parameters<typeof _compile>[1]
  ): CompilationResult {
    // Spelled out rather than `ReturnType<typeof _compile>`: that instantiates
    // the generic at its CONSTRAINT, so the result's `R` collapses to
    // `unknown` instead of taking the `CompiledValue` default and stops
    // matching the `IComputeEngine` declaration. The same trap is documented
    // at the `compile` wrapper in `free-functions.ts`, where it cost the
    // target parameter instead of the result one.
    return _compile(expr, options);
  }

  /** @internal Get a registered compilation target by name. */
  _getCompilationTarget(
    name: 'interval-js'
  ): IntervalJsCompilationTarget<Expression> | undefined;
  _getCompilationTarget(
    name: 'javascript'
  ): JavaScriptCompilationTarget<Expression> | undefined;
  _getCompilationTarget(name: string): LanguageTarget<Expression> | undefined;
  _getCompilationTarget(name: string): LanguageTarget<Expression> | undefined {
    return this._compilationTargets.get(name);
  }

  /** @internal Return the names of all registered compilation targets. */
  _listCompilationTargets(): string[] {
    return this._compilationTargets.list();
  }

  /**
   * Register a compilation target under `name`, so that
   * `compile(expr, { to: name })` resolves it. A later registration under the
   * same name replaces the earlier target. The name must be a non-empty
   * string and the target must implement `getOperators()`, `getFunctions()`,
   * `createTarget()` and `compile()`; otherwise this throws.
   *
   * Every engine has `javascript` and `interval-js`. Every engine also has
   * `glsl` once the full package entry,
   * `@cortex-js/compute-engine/epsil` or the CLI has been loaded anywhere in
   * the program, whichever entry made the engine and in whichever order. A
   * program that loads only `@cortex-js/compute-engine/core` has the two
   * built-in targets: import `GLSLTarget`
   * from `@cortex-js/compute-engine/compile` and register it here.
   */
  registerCompilationTarget(
    name: string,
    target: LanguageTarget<Expression>
  ): void {
    this._compilationTargets.register(name, target);
  }

  /** @internal The pre-2026-10-26 spelling of `registerCompilationTarget`. */
  _registerCompilationTarget(
    name: string,
    target: LanguageTarget<Expression>
  ): void {
    this.registerCompilationTarget(name, target);
  }

  /** Remove the compilation target registered under `name`. A name that is
   * not registered is ignored. */
  unregisterCompilationTarget(name: string): void {
    this._compilationTargets.unregister(name);
  }

  /** @internal The pre-2026-10-26 spelling of `unregisterCompilationTarget`. */
  _unregisterCompilationTarget(name: string): void {
    this.unregisterCompilationTarget(name);
  }

  get precision(): number {
    return this._numericConfiguration.precision;
  }

  /** The precision, or number of significant digits, of numeric
   * calculations.
   *
   * To make calculations using more digits, at the cost of expanded memory
   * usage and slower computations, set the `precision` higher.
   *
   * Trigonometric operations are accurate for precision up to 1,000.
   *
   * If the precision is set to `machine`, floating point numbers
   * are represented internally as a 64-bit floating point number (as
   * per IEEE 754-2008), with a 52-bit mantissa, which gives about 15
   * digits of precision.
   *
   * If the precision is set to `auto`, the precision is set to a default value.
   *
   * The precision of the arbitrary-precision arithmetic is shared by every
   * engine in the program: creating an engine, or setting the precision of
   * any engine, sets it for all of them. A program that sets different
   * precisions on two engines computes in both at the precision set last,
   * so use one engine per program.
   *
   */
  set precision(p: number | 'machine' | 'auto') {
    if (!this._numericConfiguration.setPrecision(p)) return;
    this._reset();
  }

  /** Run `fn` at the precision `digits` (of the engine and of the big
   * decimals) without a reset of the engine: see
   * `EngineNumericConfiguration.withTransientPrecision`.
   * @internal */
  _withTransientPrecision<T>(digits: number, fn: () => T): T {
    return this._numericConfiguration.withTransientPrecision(digits, fn);
  }

  /** True while `_withTransientPrecision` runs a function.
   * @internal */
  get _atTransientPrecision(): boolean {
    return this._numericConfiguration.isTransientPrecision;
  }

  /** Run `fn` with the angular unit `unit` without a reset of the engine:
   * see `EngineNumericConfiguration.withTransientAngularUnit`.
   * @internal */
  _withTransientAngularUnit<T>(unit: AngularUnit, fn: () => T): T {
    return this._numericConfiguration.withTransientAngularUnit(unit, fn);
  }

  /** True while `_withTransientPrecision` or `_withTransientAngularUnit`
   * runs a function: a value computed now must not be stored where a reader
   * at the working precision, or in the working angular unit, can find it.
   * @internal */
  get _atTransientConfiguration(): boolean {
    return (
      this._numericConfiguration.isTransientPrecision ||
      this._numericConfiguration.isTransientAngularUnit
    );
  }

  /**
   * The unit used for unitless angles in trigonometric functions.
   *
   * - `rad`: radian, $2\pi$ radians is a full circle
   * - `deg`: degree, 360 degrees is a full circle
   * - `grad`: gradians, 400 gradians is a full circle
   * - `turn`: turn, 1 turn is a full circle
   *
   * Default is `"rad"` (radians).
   */
  get angularUnit(): AngularUnit {
    return this._numericConfiguration.angularUnit;
  }

  set angularUnit(u: AngularUnit) {
    if (!this._numericConfiguration.setAngularUnit(u)) return;
    this._reset();
  }

  /**
   * The rule that `Round` uses for a value that is exactly halfway between
   * two integers (a tie). See {@link RoundingTies}.
   *
   * - `away-from-zero`: `Round(2.5)` is `3`, `Round(-2.5)` is `-3`
   * - `to-even`: `Round(2.5)` is `2`, `Round(3.5)` is `4` (IEEE 754, Python)
   * - `toward-zero`: `Round(2.5)` is `2`, `Round(-2.5)` is `-2`
   * - `toward-positive-infinity`: `Round(-2.5)` is `-2` (JavaScript
   *   `Math.round`)
   * - `toward-negative-infinity`: `Round(2.5)` is `2`
   *
   * The rule applies to the evaluation of `Round` at every precision and to
   * the code that `compile()` makes. A function compiled before a change
   * keeps the rule that was in effect when it was compiled.
   *
   * Default is `"away-from-zero"`.
   */
  get roundingTies(): RoundingTies {
    return this._numericConfiguration.roundingTies;
  }

  set roundingTies(r: RoundingTies) {
    if (!this._numericConfiguration.setRoundingTies(r)) return;
    this._reset();
  }

  /**
   * Run `fn` with **at most** `ms` milliseconds (the `limit`, or `limit.ms`
   * for the object form).
   *
   * A tighter deadline may already be in effect from an enclosing span, in
   * which case that one preempts this limit — nesting can only shorten the
   * effective deadline, never extend it. Any evaluation performed inside `fn`
   * throws a `CancellationError` (with `cause: 'timeout'`) once the effective
   * deadline is exceeded. Use the `label` and the `attribution`/`spans` fields
   * on `CancellationError` to determine which limit fired.
   *
   * The object form is preferred for new code because the label reads before
   * the callback:
   *
   * ```ts
   * ce.withTimeLimit({ ms: 500, label: 'plot:sample' }, () => {
   *   for (const el of collection.each()) process(el);
   * });
   * ```
   *
   * The numeric form `ce.withTimeLimit(500, fn)` stays valid and produces an
   * unlabelled span (`attribution: undefined` on any error it owns).
   *
   * **⚠️ `fn` MUST be synchronous.** The span is armed and restored around a
   * single synchronous call: the frame is torn down in a synchronous `finally`
   * as soon as `fn` returns. A `fn` that returns a `Promise` (an `async`
   * callback, or one that returns un-awaited async work) hands control back at
   * its first `await` while the span is still nominally open, so any work that
   * resumes after that point runs **outside** the deadline and is never
   * cancelled — the span is silently ineffective (see
   * `docs/TIMEOUT-MODEL.md` §6.4). An `expr.evaluateAsync()` call that `fn`
   * makes before its first `await` is the exception: the evaluation keeps
   * the span's deadline until it ends. For cancellation that is not a time
   * limit, use `expr.evaluateAsync({ signal })` with an `AbortSignal`.
   */
  withTimeLimit<T>(
    limit: number | { ms: number; label?: string },
    fn: () => T extends Promise<unknown> ? never : T
  ): T {
    const ms = typeof limit === 'number' ? limit : limit.ms;
    const label = typeof limit === 'number' ? undefined : limit.label;
    return this._withBudget({ ms, label }, fn);
  }

  /**
   * Run `fn` with **at most** `limit.steps` steps of engine work — a hang
   * guard that fires at the same point on every machine, whatever its speed
   * or load, unlike a wall-clock limit.
   *
   * A step is one of the engine's cooperative cancellation checks. The
   * checks are amortized in hot loops and sit at fixed points of the
   * evaluator, the numeric integrators, the series and limit code and the
   * integration rules, so the count for one computation on one engine state
   * is the same on every run, but it is an **opaque unit**: it is not a
   * measure of the computation's cost or complexity, it is not comparable
   * across engine versions, and code that does not reach a check (a single
   * large numeric operation) spends no steps while it runs. Tune the budget
   * empirically against the computations it must admit, and keep a
   * `withTimeLimit` span outside it as the guard of last resort.
   *
   * A spent budget throws a `CancellationError` with `cause: 'step-budget'`
   * (a time expiry has `cause: 'timeout'`), the span's `label` as its
   * `attribution`, and the active span labels in `spans`. Spans nest: a step
   * counts against every active budget, and the deadline of an enclosing
   * `withTimeLimit` span still applies inside. `steps` must be a
   * non-negative integer no larger than `Number.MAX_SAFE_INTEGER` (2^53 − 1):
   * a larger number does not change when 1 is subtracted from it, so the
   * budget would never be spent. `Infinity` and `NaN` are contract errors,
   * not budgets. `steps: 0` lets `fn` start and throws at its first check.
   *
   * ```ts
   * try {
   *   ce.withStepBudget({ steps: 20_000, label: 'classify' }, () =>
   *     expr.evaluate()
   *   );
   * } catch (e) {
   *   if (e.name === 'CancellationError' && e.cause === 'step-budget')
   *     report('too complex');
   * }
   * ```
   *
   * **⚠️ `fn` MUST be synchronous**, for the reason given at
   * `withTimeLimit`: the span ends when `fn` returns, so work that resumes
   * after an `await` runs outside it.
   */
  withStepBudget<T>(
    limit: { steps: number; label?: string },
    fn: () => T extends Promise<unknown> ? never : T
  ): T {
    const { steps, label } = limit;
    if (!Number.isSafeInteger(steps) || steps < 0)
      throw new Error(
        `withStepBudget: \`steps\` must be a non-negative integer no larger than Number.MAX_SAFE_INTEGER, got ${String(steps)}`
      );
    return this._withBudget({ steps, label, host: true }, fn);
  }

  /** See `IComputeEngine.timeRemaining`. Unlike the internal
   * `_timeRemaining`, a spent step budget does not make it `0`: the two
   * conditions are read separately (`stepBudgetSpent`). */
  get timeRemaining(): number {
    const frame = this._runtimeState.deadlineFrame;
    return frame === undefined
      ? Number.POSITIVE_INFINITY
      : frame.at - Date.now();
  }

  /** See `IComputeEngine.stepBudgetSpent`. The frame lists the budget of
   * each enclosing step-budget span, outermost first; any spent one cancels
   * the work of the span. */
  get stepBudgetSpent(): boolean {
    return (
      this._runtimeState.deadlineFrame?.budgets?.some((b) => b.left < 0) ??
      false
    );
  }

  /** See `IComputeEngine.stepsLeft`. The frame lists the budget of each
   * enclosing step-budget span, outermost first. The engine opens step
   * budgets of its own (integration, Rubi, contour integrals), and host code
   * can run inside one (an `evaluate` handler): those budgets are skipped,
   * and the last budget that `withStepBudget` created (`host`) is read. */
  get stepsLeft(): number | undefined {
    const budgets = this._runtimeState.deadlineFrame?.budgets ?? [];
    for (let i = budgets.length - 1; i >= 0; i--)
      if (budgets[i].host) return budgets[i].left;
    return undefined;
  }

  /**
   * Run `fn` in a span with a wall-clock limit (`ms`), a step budget
   * (`steps`, see `StepBudget` in `common/interruptible.ts`), or both. With
   * neither, the span only adds its label. `withTimeLimit` is this with
   * `ms` alone.
   *
   * A step budget makes the point where an internal search gives up
   * independent of the machine, so its result is too: use it, not `ms`, to
   * bound a search whose result changes when it gives up. Keep a large `ms`
   * beside it only as a guard against a hang in code that does not count
   * steps.
   *
   * Spans nest: the effective deadline is the earliest one, and a step
   * counts against every active budget. With `ruleSteps`, each rule that
   * `replace()` tries is also a step of this budget, and only of the
   * budgets that set it (see `StepBudget`).
   *
   * @internal
   */
  _withBudget<T>(
    limit: {
      ms?: number;
      steps?: number;
      label?: string;
      ruleSteps?: boolean;
      host?: true;
    },
    fn: () => T
  ): T {
    const { ms, steps, label, ruleSteps, host } = limit;
    const prevFrame = this._runtimeState.deadlineFrame;
    const own = ms === undefined ? Infinity : Date.now() + ms;
    const spans = [
      ...(prevFrame?.spans ?? []),
      ...(label !== undefined ? [label] : []),
    ];
    const budgets =
      steps === undefined
        ? prevFrame?.budgets
        : [
            ...(prevFrame?.budgets ?? []),
            {
              left: steps,
              owner: label,
              spans,
              ...(ruleSteps === true ? { ruleSteps } : {}),
              ...(host === true ? { host } : {}),
            },
          ];

    // Nesting stays `min()`: if an enclosing span's deadline is already at or
    // before our own, it remains the effective one (and keeps its owner);
    // otherwise this span's deadline wins.
    const frame: DeadlineFrame =
      prevFrame !== undefined && prevFrame.at <= own
        ? { at: prevFrame.at, owner: prevFrame.owner, spans }
        : { at: own, owner: label, spans };
    if (budgets !== undefined) frame.budgets = budgets;

    this._runtimeState.deadlineFrame = frame;
    try {
      return fn();
    } finally {
      this._runtimeState.deadlineFrame = prevFrame;
    }
  }

  get effects(): EffectHandlers {
    return this._effects;
  }

  set effects(handlers: EffectHandlerOverrides) {
    // A complete description: derive from the DEFAULTS, not from the current
    // registry, so a handler that is not mentioned returns to its default.
    this._baseEffects = deriveEffectHandlers(DEFAULT_EFFECT_HANDLERS, handlers);
    this._recomputeEffects();
  }

  /** @internal */
  private _recomputeEffects(): void {
    let effects = this._baseEffects;
    for (const overrides of this._effectOverrides)
      effects = deriveEffectHandlers(effects, overrides);
    this._effects = effects;
  }

  withEffects<T>(overrides: EffectHandlerOverrides, fn: () => T): T {
    // Validate before anything is installed: a bad override must not leave an
    // entry in the list.
    deriveEffectHandlers(this._effects, overrides);

    // A private copy is the identity of THIS call in the list, so the same
    // `overrides` object passed to two calls gives two distinct entries.
    const entry = { ...overrides };
    this._effectOverrides.push(entry);
    this._recomputeEffects();

    const close = () => {
      const i = this._effectOverrides.indexOf(entry);
      if (i >= 0) this._effectOverrides.splice(i, 1);
      this._recomputeEffects();
    };

    // When `withEffects` is called by an operator handler, an evaluation is
    // already running and has captured its registry. The evaluations `fn`
    // starts are nested in it and would inherit that captured registry, so
    // replace it for the synchronous part of `fn`. It is restored as soon as
    // `fn` returns — not when a promise settles — because by then the
    // enclosing evaluation continues, or has ended.
    const enclosing = this._evaluationEffects;
    if (enclosing !== undefined) this._evaluationEffects = this._effects;

    // Everything that can throw synchronously — the callback, and the read
    // of `then` that detects a promise (a getter can throw) — is inside the
    // `try`, so a throw always removes this call from the list.
    let result: T;
    let settled: Promise<T> | undefined;
    try {
      result = fn();
      if (
        result !== null &&
        (typeof result === 'object' || typeof result === 'function') &&
        typeof (result as { then?: unknown }).then === 'function'
      )
        settled = Promise.resolve(result).finally(close);
    } catch (e) {
      close();
      throw e;
    } finally {
      this._evaluationEffects = enclosing;
    }

    if (settled !== undefined) return settled as T;
    close();
    return result;
  }

  withEvaluationContext<T>(
    options: Partial<EvaluateOptions> | undefined,
    fn: () => T
  ): T {
    // When `options` carry no registry, the registry slot keeps the one of
    // the evaluation that is running now, or gets the installed one.
    return runWithEvaluationEffects(
      this,
      options?._effects ?? this._evaluationEffects ?? this._effects,
      fn,
      options?._contextStack,
      options?._precisionWindow
    );
  }

  /** Absolute time (`Date.now()` epoch ms) beyond which evaluation should
   * not proceed, or `undefined` when no time limit is active. (An un-prefixed
   * `deadline` alias existed from the 2026-02 service refactor until
   * 2026-08-17; `_deadline` is the one spelling.)
   * @internal
   */
  get _deadline(): number | undefined {
    return this._runtimeState.deadline;
  }

  /** @internal */
  set _deadline(value: number | undefined) {
    this._runtimeState.deadline = value;
  }

  /** The full deadline frame (effective deadline plus attribution).
   * @internal
   */
  get _deadlineFrame(): DeadlineFrame | undefined {
    return this._runtimeState.deadlineFrame;
  }

  /** @internal */
  set _deadlineFrame(value: DeadlineFrame | undefined) {
    this._runtimeState.deadlineFrame = value;
  }

  /** @internal */
  get _timeRemaining(): number {
    return this._runtimeState.timeRemaining;
  }

  /** Instrumentation counters for the auto-compilation of lazy-`Map` element
   * lambdas on numeric drains — compile attempts, elements served by a
   * compiled function, dependency re-validations, recompiles, per-element
   * interpreter fallbacks and NaN double-checks. This is the only surface that
   * says whether a given `Map` drain compiled, re-validated or fell back, and
   * it is exposed here because that question is asked from a consumer install,
   * where a module-level export of `library/map-auto-compile.ts` is not
   * reachable (no subpath export, and the symbol does not survive
   * minification).
   *
   * The counters are process-global and cumulative, not per-engine — the
   * compile cache they instrument is a module-level `WeakMap` shared by every
   * engine in the process — so every engine returns the same object, and a
   * caller measures a single drain by reading the counters before and after it
   * and taking the difference.
   * @internal
   */
  get _mapAutoCompileStats(): MapAutoCompileStats {
    return _mapAutoCompileStats;
  }

  /** The statistics of the memoization caches, for a host that uses the
   * published package: a module export of `common/cache-stats.ts` is not
   * reachable there, and a browser has no `CE_CACHE_STATS` environment
   * variable. The counters are process-global, so every engine returns the
   * same object.
   * @internal
   */
  get _cacheStats(): CacheStatsControl {
    return cacheStatsControl;
  }

  /** Throw `CancellationError` `iteration-limit-exceeded` when the iteration limit
   * in a loop or a lazy walk is exceeded. Default: 1024. A value of 0 or less
   * means no limit.
   *
   * An engine that runs an Epsil program (`executeEpsil`, the `epsil`
   * command) has no iteration limit from then on, unless this property was
   * assigned: an assigned limit is kept and applies to Epsil programs too.
   *
   * @experimental
   */
  get iterationLimit(): number {
    return this._runtimeState.iterationLimit;
  }
  set iterationLimit(t: number) {
    // Recorded before the equality test: assigning the default value is still
    // a host decision that Epsil programs must honor.
    this._runtimeState.iterationLimitIsExplicit = true;
    this._setIterationLimit(t);
  }

  /** Change the iteration limit without recording a host assignment. */
  private _setIterationLimit(t: number): void {
    // Compared after normalization: a limit of 0 or less means no limit and
    // is stored as `Infinity`, so removing a limit that is already removed
    // must be a no-op and must not signal a configuration change.
    const limit = t <= 0 ? Number.POSITIVE_INFINITY : t;
    if (limit === this._runtimeState.iterationLimit) return;
    this._runtimeState.iterationLimit = limit;
    // The iteration limit is a global evaluation input: a collection count
    // or element walk that gave up under the old limit
    // (`iteration-limit-exceeded` → "unknown") can answer differently under
    // the new one, and the facet/element memos key such answers on the
    // world epoch. Same event, same reason as the `tolerance` setter.
    this._noteStateEvent({ kind: 'config' });
  }

  /** See `IComputeEngine._liftDefaultIterationLimit`. @internal */
  _liftDefaultIterationLimit(): void {
    if (this._runtimeState.iterationLimitIsExplicit) return;
    this._setIterationLimit(0);
  }

  /** Signal `recursion-depth-exceeded` when the recursion depth for this
   * scope is exceeded.
   *
   * The same error is thrown when the JavaScript stack is nearly full
   * before the depth reaches the limit: a level of a recursion can use
   * several kilobytes of stack, and the size of the stack depends on the
   * host.
   *
   * @experimental
   */
  get recursionLimit(): number {
    return this._runtimeState.recursionLimit;
  }
  set recursionLimit(t: number) {
    this._runtimeState.recursionLimit = t;
  }

  /** @internal Enter a user-function application; throws a `CancellationError`
   *  (`cause: 'recursion-depth-exceeded'`) when `recursionLimit` is exceeded
   *  or the JavaScript stack is nearly full. Returns the depth before the
   *  entry. Balanced with `_exitRecursion`. */
  _enterRecursion(): number {
    return this._runtimeState.enterRecursion();
  }
  /** @internal Leave a user-function application: `depth` is the value that
   *  the balancing `_enterRecursion()` returned. */
  _exitRecursion(depth: number): void {
    this._runtimeState.exitRecursion(depth);
  }

  /** Maximum number of elements a collection may have when materialized
   * (converted from a lazy form to a `List`). Default: 10,000.
   *
   * When a materialization would exceed this size, the operation leaves
   * the expression in its lazy form. Consumers can detect oversize
   * collections via the symbolic form's `count`.
   *
   * Set to `Infinity` (or `0` / a negative number) to disable the cap.
   *
   * @experimental
   */
  get maxCollectionSize(): number {
    return this._runtimeState.maxCollectionSize;
  }
  set maxCollectionSize(t: number) {
    const before = this._runtimeState.maxCollectionSize;
    this._runtimeState.maxCollectionSize = t;
    // A handler that declines a collection above the cap answers a symbolic
    // call, and the evaluate memo keeps such a result
    // (`_isMemoizableInertEvaluation`, `boxed-expression/boxed-function.ts`).
    // The cap is engine configuration, so a change advances the versions a
    // configuration change advances, and the declined result is computed
    // again under the new cap.
    if (this._runtimeState.maxCollectionSize !== before)
      this._noteStateEvent({ kind: 'config' });
  }

  /**
   * Flag to prevent infinite recursion in the verify/ask/equality checking cycle.
   *
   * **The Problem:**
   * When verifying equality predicates, a recursion loop can occur:
   * 1. `verify(Equal(x, 0))` evaluates the expression
   * 2. `Equal.evaluate()` calls `eq(x, 0)` to check equality
   * 3. `eq()` calls `ask(['NotEqual', x, 0])` to check assumptions
   * 4. `ask()` calls `verify(NotEqual(x, 0))` as a fallback
   * 5. `verify()` evaluates, calling `eq()` again → infinite loop
   *
   * **The Solution:**
   * - Set `_isVerifying = true` when entering `verify()`
   * - `ask()` skips the `verify()` fallback when `_isVerifying` is true
   * - `Equal/NotEqual` evaluate handlers check this flag to preserve 3-valued
   *   logic in verification mode while still returning False/True in normal mode
   *
   * @see verify() in index.ts
   * @see ask() in index.ts
   * @see eq() in compare.ts
   * @see Equal/NotEqual operators in relational-operator.ts
   */
  /** @internal */
  get _isVerifying(): boolean {
    return this._runtimeState.isVerifying;
  }

  set _isVerifying(value: boolean) {
    this._runtimeState.isVerifying = value;
  }

  /**
   * @internal
   * Indicates whether we're currently inside a verify() call.
   * Used to prevent recursion and to enable 3-valued logic in verification mode.
   */
  get isVerifying(): boolean {
    return this._runtimeState.isVerifying;
  }

  get tolerance(): number {
    return this._numericConfiguration.tolerance;
  }

  /** @internal */
  get _bignumTolerance(): BigDecimal {
    return this._numericConfiguration.bignumTolerance;
  }
  /**
   * Values smaller than the tolerance are considered to be zero for the
   * purpose of comparison, i.e. if `|b - a| <= tolerance`, `b` is considered
   * equal to `a`. The tolerance applies only when a float is involved; two
   * exact numbers are compared exactly.
   *
   * A number is kept as set, also when the precision changes later. The
   * default is `1e-10` at every precision. `'auto'` makes the tolerance
   * follow the precision: `10^(-precision + 2)`, so 1e-19 at the default
   * 21 digits and 1e-38 at 40 digits, recomputed at each precision change.
   * It is meant for big-decimal work: a value computed in machine floats
   * (about 16 digits) then compares as different from its exact value.
   * Above 325 digits the float returned by the getter is clamped to the
   * smallest positive float; the big-decimal comparisons and `chop()` use
   * the exact value.
   */
  set tolerance(val: number | 'auto') {
    if (this._numericConfiguration.setTolerance(val)) {
      // The tolerance is a global evaluation input (equality and comparisons
      // are within tolerance), so a change is a semantic mutation AND an
      // epoch event. Deliberately not a full `_reset()`: unlike precision, no
      // stored value needs to be recomputed.
      this._noteStateEvent({ kind: 'config' });
    }
  }

  /** The innermost active `WithRandomSeed` frame, or `undefined` when draws
   * are live. Swapped by `withRandomSeedFrame`, exactly like `_deadlineFrame`.
   * @internal
   */
  get _randomFrame(): RandomSeedFrame | undefined {
    return this._runtimeState.randomFrame;
  }

  set _randomFrame(value: RandomSeedFrame | undefined) {
    this._runtimeState.randomFrame = value;
  }

  /** @internal Draw the next uniform in [0, 1).
   *
   * Inside a `WithRandomSeed` frame the draw is the counter-based
   * `hash(seed, n)` of the innermost frame, and the frame's counter advances
   * (u32, wrapping). Outside any frame the draw is LIVE: there is no ambient
   * seed to set, so an unframed draw is non-deterministic by construction. It
   * comes from the `entropy` handler of the host capability registry — the
   * registry of the running evaluation, or the installed one when no
   * evaluation is running. This is the one place where an operator that
   * declares `random` (not `entropy`) reaches the `entropy` handler: the
   * stated exception to the coupling rule of `docs/EFFECTS-MODEL.md`, ruled
   * 2026-09-18. A denied handler (`null`) throws `CapabilityDeniedError`,
   * which the evaluation driver turns into the operator's
   * `Error("capability-denied", "entropy")` value.
   */
  _random(): number {
    const frame = this._runtimeState.randomFrame;
    if (frame !== undefined) return nextFrameDraw(frame);
    return this._liveRandom();
  }

  /** @internal A live uniform in [0, 1) from the `entropy` handler of the
   * host capability registry — the registry of the running evaluation, or the
   * installed one when no evaluation is running — with no regard to any
   * `WithRandomSeed` frame. `_random()` uses it outside a frame; compiled
   * integrals use it inside a frame too, because a compiled integral samples
   * live by ruling (`docs/RANDOMNESS-MODEL.md`, "Compiled integrals are a
   * ruled exception"). A denied handler throws `CapabilityDeniedError`.
   */
  _liveRandom(): number {
    const entropy = (this._evaluationEffects ?? this._effects).entropy;
    if (entropy === null) throw new CapabilityDeniedError('entropy');
    return entropy.random();
  }

  /** @internal A private stream derived from the ambient `WithRandomSeed`
   * frame, for the stochastic ESTIMATORS (Monte-Carlo integration, the
   * sampled equality probe).
   *
   * Unlike `_random()`, this consumes NO indices from the frame: an estimator
   * that samples 1e7 points must not shift a sibling `Random()` draw, and its
   * sample count is deadline-dependent, so charging it to the frame would make
   * replay depend on wall-clock time. See
   * `docs/RANDOMNESS-MODEL.md`.
   *
   * `tag` selects which sub-stream — pass a structural hash (`expr.hash`) so
   * the same expression samples the same points wherever it appears in the
   * frame. Outside a frame the result is live: each draw comes from the
   * `entropy` handler, through `_random()`, so a mocked or denied handler
   * applies to the estimators too.
   */
  _substream(tag: number): RandomSubstream {
    const frame = this._runtimeState.randomFrame;
    if (frame === undefined) return () => this._random();
    return deriveSubstream(frame, tag);
  }

  /** Replace a number that is close to 0 with the exact integer 0.
   *
   * How close to 0 the number has to be to be considered 0 is determined by {@linkcode tolerance}.
   */
  chop(n: number): number;
  chop(n: BigDecimal): BigDecimal | 0;
  chop(n: Complex): Complex | 0;
  chop(n: number | BigDecimal | Complex): number | BigDecimal | Complex {
    const tolerance = this._numericConfiguration.tolerance;
    if (typeof n === 'number') {
      if (Math.abs(n) <= tolerance) return 0;
      return n;
    }

    if (n instanceof BigDecimal) {
      if (n.isPositive() && n.lte(this._numericConfiguration.bignumTolerance))
        return 0;
      if (
        n.isNegative() &&
        n.gte(this._numericConfiguration.negBignumTolerance)
      )
        return 0;
      if (n.isZero()) return 0;
      return n;
    }

    if (
      n instanceof Complex &&
      Math.abs(n.re) <= tolerance &&
      Math.abs(n.im) <= tolerance
    )
      return 0;

    return n;
  }

  /** Create an arbitrary precision number. 
   * 
   * The return value is an object with methods to perform arithmetic
   * operations:
   * - `toNumber()`: convert to a JavaScript `number` with potential loss of precision
   * - `add()`
   * - `sub()`
   * - `neg()` (unary minus)
   * - `mul()`
   * - `div()`
   * - `pow()`
   * - `sqrt()` (square root)
   * - `cbrt()` (cube root)
   * - `exp()`  (e^x)
   * - `log()` 
   * - `ln()` (natural logarithm)
   * - `mod()`

   * - `abs()`
   * - `ceil()`
   * - `floor()`
   * - `round()`

   * - `equals()`
   * - `gt()`
   * - `gte()`
   * - `lt()`
   * - `lte()`
   * 
   * - `cos()`
   * - `sin()`
   * - `tanh()`
   * - `acos()`
   * - `asin()`
   * - `atan()`
   * - `cosh()`
   * - `sinh()`
   * - `acosh()`
   * - `asinh()`
   * - `atanh()`
   * 
   * - `isFinite()`
   * - `isInteger()`
   * - `isNaN()`
   * - `isNegative()`
   * - `isPositive()`
   * - `isZero()`
  * - `sign()` (1, 0 or -1)
  * 
  */
  bignum(a: string | number | bigint | BigDecimal): BigDecimal {
    return this._numericConfiguration.bignum(a);
  }

  /** Create a complex number whose parts are machine doubles.
   *
   * The result is a `Complex` object: its real part and its imaginary part
   * are always JavaScript `number` values. A `BigDecimal` argument is
   * converted to the nearest double, so its digits beyond 16 are lost, a
   * part too small for a double (`1e-800`) becomes `0` and a part too large
   * (`1e800`) becomes `Infinity`.
   *
   * To create a complex number without that loss, use one of these:
   * - `ce.number({ re, im })`, whose parts can be `BigDecimal` values;
   * - the MathJSON `Complex` expression, for example
   *   `ce.box(["Complex", {num: "1e-800"}, {num: "2"}])`;
   * - LaTeX, for example `ce.parse("10^{-800} + 2i")`.
   *
   * A `Complex` holds two doubles, so `ce.number()` and `ce.box()` read it
   * as a float, also when both its parts are integers:
   * `ce.number(ce.complex(2, 3))` is the float `2.0 + 3.0i`. For the exact
   * Gaussian integer `2+3i`, use `ce.number({ re: 2, im: 3 })` or
   * `ce.box(["Complex", 2, 3])`.
   *
   * The return value is an object with methods to perform arithmetic
   * operations:
   * - `re` (real part, as a JavaScript `number`)
   * - `im` (imaginary part, as a JavaScript `number`)
   * - `add()`
   * - `sub()`
   * - `neg()` (unary minus)
   * - `mul()`
   * - `div()`
   * - `pow()`
   * - `sqrt()` (square root)
   * - `exp()`  (e^x)
   * - `log()` 
   * - `ln()` (natural logarithm)
   * - `mod()`

   * - `abs()`
   * - `ceil()`
   * - `floor()`
   * - `round()`

   * - `arg()` the angle of the complex number
   * - `inverse()` the inverse of the complex number 1/z
   * - `conjugate()` the conjugate of the complex number

   * - `equals()`
   * 
   * - `cos()`
   * - `sin()`
   * - `tanh()`
   * - `acos()`
   * - `asin()`
   * - `atan()`
   * - `cosh()`
   * - `sinh()`
   * - `acosh()`
   * - `asinh()`
   * - `atanh()`
   * 
   * - `isFinite()`
   * - `isNaN()`
   * - `isZero()`
   * - `sign()` (1, 0 or -1)
   */
  complex(a: number | BigDecimal | Complex, b?: number | BigDecimal): Complex {
    if (a instanceof BigDecimal) a = a.toNumber();
    if (b instanceof BigDecimal) b = b.toNumber();
    return new Complex(a, b);
  }

  /**
   *
   * Create a Numeric Value.
   *
   * @internal
   */
  _numericValue(
    value:
      | number
      | bigint
      | Complex
      | OneOf<[BigNum | NumericValueData | ExactNumericValueData]>
  ): NumericValue {
    // Convert to an ExactNumericValue if possible.
    //
    // Only a machine double that is a SAFE integer becomes an exact integer.
    // A double past the safe integers (`1e200`) is a rounded value, and a
    // big decimal is a value at the working precision whose integer-valuedness
    // depends on that precision: both stay floats. An exact integer beyond the
    // safe range comes from a bigint or a string of digits.
    if (value instanceof NumericValue) {
      const exact = value.asExact;
      if (exact === undefined) return value;
      // An exact value made by another numeric value (the exact results of
      // the kernels of a machine float, such as `floor()`) or by another
      // engine has a factory that does not follow the precision of this
      // engine: the factory of a machine float always makes a machine float.
      // A finite value of this kind gets the factory of this engine.
      if (
        exact instanceof ExactNumericValue &&
        exact.factory !== this._inexactNumericValue &&
        !exact.isNaN &&
        !exact.isPositiveInfinity &&
        !exact.isNegativeInfinity &&
        !exact.isComplexInfinity
      ) {
        return new ExactNumericValue(
          !exact.isComplex
            ? { rational: exact.rational, radical: exact.radical }
            : {
                rational: exact.rational,
                radical: exact.radical,
                imRational: exact.imRational,
                imRadical: exact.imRadical,
              },
          this._inexactNumericValue
        );
      }
      return exact;
    }

    const makeNumericValue = this._inexactNumericValue;

    if (typeof value === 'number') {
      if (Number.isSafeInteger(value))
        return new ExactNumericValue(value, makeNumericValue);
      return makeNumericValue(value);
    }

    if (typeof value === 'bigint')
      return new ExactNumericValue(value, makeNumericValue);

    if (isRational(value))
      return new ExactNumericValue({ rational: value }, makeNumericValue);

    if (value instanceof BigDecimal) return makeNumericValue(value);

    // A `Complex` object holds two doubles, so its value is a float, also
    // when both parts are integers: `new Complex(2, 3)` is the float
    // `2.0 + 3.0i` and `new Complex(2, 0)` is the float `2.0`. The exact
    // Gaussian integer `2 + 3i` is `ce.number({ re: 2, im: 3 })` or the
    // MathJSON `["Complex", 2, 3]`.
    if (value instanceof Complex) {
      if (value.im === 0) return makeNumericValue(value.re);
      return makeNumericValue({ re: value.re, im: value.im });
    }

    //
    // We have a NumericValueData
    //

    if ('im' in value || 're' in value) {
      // The imaginary part is a double or a big decimal. A big decimal is an
      // object, so `im !== 0` is not a zero test for it.
      if (!isZeroLike(value.im)) return makeNumericValue(value);

      // A real part that is a safe-integer double is an exact integer (a big
      // decimal real part stays a float, see above)
      if (typeof value.re === 'number' && Number.isSafeInteger(value.re))
        return new ExactNumericValue(
          {
            rational: [value.re, 1],
            // radical: value.radical
          },
          makeNumericValue
        );
      // A zero imaginary part held as a big decimal is passed on as the
      // double `0`, so the value is built as a real value.
      return makeNumericValue(
        value.im === undefined || typeof value.im === 'number'
          ? value
          : { ...value, im: 0 }
      );
    }

    if ('radical' in value || 'rational' in value) {
      let data: ExactNumericValueData = value;

      // Normalize the radical part. An exact radical must be a positive
      // integer whose square-free part is below SMALL_INTEGER (a larger
      // radical would lose precision under subsequent exact arithmetic).
      // Rather than throwing when a numeric evaluation path lands on such a
      // value, extract any perfect-square factor (√(k²·r) = k·√r); if the
      // remaining square-free radicand is still too large — or the radical is
      // not a positive integer at all — fall back to the (inexact) float lane.
      if (data.radical !== undefined && data.radical !== 1) {
        // √(−c) = i·√c: a negative integer radical is a pure-imaginary
        // exact value. `(1/3)·√(−13)` is `(√13/3)·i`; the float lane below
        // would take `Math.sqrt(−13)` and give `NaN`.
        if (
          Number.isInteger(data.radical) &&
          data.radical < 0 &&
          data.imRational === undefined &&
          data.imRadical === undefined
        )
          return this._numericValue({
            rational: [0, 1],
            imRational: data.rational ?? [1, 1],
            imRadical: -data.radical,
          });
        if (!Number.isInteger(data.radical) || data.radical < 1) {
          return makeNumericValue({
            re:
              rationalAsFloat(data.rational ?? [1, 1]) *
              Math.sqrt(data.radical),
          });
        }
        if (data.radical >= SMALL_INTEGER) {
          const [factor, root] = canonicalInteger(data.radical, 2);
          if (root >= SMALL_INTEGER)
            return makeNumericValue({
              re:
                rationalAsFloat(data.rational ?? [1, 1]) *
                Math.sqrt(data.radical),
            });
          data = {
            ...data,
            radical: root,
            rational: mul(data.rational ?? [1, 1], [factor, 1]),
          };
        }
      }

      // The imaginary radical gets the same treatment as the real one: take
      // out the square factors, and go to the float lane past SMALL_INTEGER.
      if (data.imRadical !== undefined && data.imRadical >= SMALL_INTEGER) {
        const [factor, root] = canonicalInteger(data.imRadical, 2);
        if (root >= SMALL_INTEGER)
          return makeNumericValue({
            re: 0,
            im:
              rationalAsFloat(data.imRational ?? [1, 1]) *
              Math.sqrt(data.imRadical),
          });
        data = {
          ...data,
          imRadical: root,
          imRational: mul(data.imRational ?? [1, 1], [factor, 1]),
        };
      }

      // Validate rational part

      if (data.rational) {
        if (isMachineRational(data.rational)) {
          if (
            !Number.isInteger(data.rational[0]) ||
            !Number.isInteger(data.rational[1])
          )
            // @fixme: this may never happen
            return makeNumericValue(data as unknown as NumericValueData);
        }
      }

      return new ExactNumericValue(data, makeNumericValue);
    }
    throw Error(
      `Unexpected value: ${typeof value === 'object' ? JSON.stringify(value) : String(value)}`
    );
  }

  /**
   * The cost function is used to determine the "cost" of an expression. For example, when simplifying an expression, the simplification that results in the lowest cost is chosen.
   */
  get costFunction(): (expr: Expression) => number {
    return this._cost ?? DEFAULT_COST_FUNCTION;
  }

  set costFunction(fn: ((expr: Expression) => number) | undefined) {
    // A non-function value (including `undefined`) resets to the default
    // cost function (the getter falls back to DEFAULT_COST_FUNCTION).
    this._cost = typeof fn === 'function' ? fn : undefined;
  }

  /**
   * The rules used by `.simplify()` when no explicit `rules` option is passed.
   * Initialized to a copy of the built-in simplification rules.
   *
   * Add custom rules with `push()`:
   * ```ts
   * ce.simplificationRules.push({
   *   match: ['Power', ['Sin', '_x'], 2],
   *   replace: ['Subtract', 1, ['Power', ['Cos', '_x'], 2]],
   * });
   * ```
   *
   * Or replace entirely:
   * ```ts
   * ce.simplificationRules = myCustomRules;
   * ```
   */
  get simplificationRules(): Rule[] {
    return this._simplificationRules.rules;
  }

  set simplificationRules(rules: Rule[]) {
    this._simplificationRules.rules = rules;
    // Invalidate the cached boxed rule set
    this._cacheStore.invalidate('standard-simplification-rules');
  }

  /**
   * The rules used by `solve()` to find roots of univariate expressions.
   *
   * Each rule matches a normalized equation `f(_x) = 0` — the unknown is
   * the wildcard `_x` — and `replace` produces a root expression.
   * Conditions should reject matches where other wildcards capture `_x`.
   *
   * Candidate roots are validated against the original equation, so an
   * over-eager template degrades to a no-op rather than a wrong answer.
   *
   * Initialized to a copy of the built-in root-finding rules.
   *
   * Add custom rules with `push()`:
   * ```ts
   * ce.solveRules.push({
   *   match: ['Add', ['Tan', '_x'], '__b'],
   *   replace: ['Arctan', ['Negate', '__b']],
   *   condition: ({ __b }) => !__b.has('_x'),
   * });
   * ```
   *
   * Or replace entirely:
   * ```ts
   * ce.solveRules = myCustomRules;
   * ```
   */
  get solveRules(): Rule[] {
    return this._solveRules.rules;
  }

  set solveRules(rules: Rule[]) {
    this._solveRules.rules = rules;
    // Invalidate the cached boxed rule set
    this._cacheStore.invalidate('univariate-roots-rules');
  }

  /**
   * The rules used by `solve()` to transform an equation into equivalent,
   * easier-to-solve forms before root-finding (e.g. `ln f(x) → f(x) - 1`).
   *
   * Same conventions and extension pattern as `solveRules`: the unknown is
   * the wildcard `_x`; `push()` to extend, assign to replace.
   */
  get harmonizationRules(): Rule[] {
    return this._harmonizationRules.rules;
  }

  set harmonizationRules(rules: Rule[]) {
    this._harmonizationRules.rules = rules;
    // Invalidate the cached boxed rule set
    this._cacheStore.invalidate('harmonization-rules');
  }

  /**
   * Return definition matching the symbol, starting with the current
   * lexical scope and going up the scope chain.
   */
  lookupDefinition(id: MathJsonSymbol): undefined | BoxedDefinition {
    return lookupDefinitionImpl(this, id);
  }

  normalizeIdentifier(latex: string): string {
    if (!latex) return '';
    // Fast path: already a valid canonical MathJSON identifier.
    if (isValidSymbol(latex)) return latex;
    // Slow path: parse LaTeX in a temporary scope so any auto-declared
    // symbol doesn't leak into the engine scope chain.
    this.pushScope();
    try {
      const expr = this.parse(latex);
      if (isSymbol(expr)) return expr.symbol;
    } finally {
      this.popScope();
    }
    return '';
  }

  operatorInfo(head: string): OperatorInfo | undefined {
    const def = this.lookupDefinition(head);
    if (!def || !isOperatorDef(def)) return undefined;
    const op = def.operator;
    const canEvaluate = !!(op.evaluate || op.collection);
    return {
      kind: canEvaluate ? 'function' : 'opaque',
      signature: op.signature,
      canEvaluate,
    };
  }

  symbolInfo(name: string): SymbolInfo | undefined {
    const def = this.lookupDefinition(name);
    if (!def || !isValueDef(def)) return undefined;
    const v = def.value;
    return {
      kind: v.isConstant ? 'constant' : 'variable',
      type: v.type,
    };
  }

  /**
   * Reverse library search: map a plain-text concept `query` to a ranked,
   * deterministic list of matching identifiers drawn from the current scope
   * chain (the standard library plus any user declarations).
   *
   * The query is a string (tokenized on whitespace) or an array of strings
   * (each element tokenized the same way); a definition matches when **any**
   * token is a case-insensitive substring of at least one of its searchable
   * strings, drawn from four axes:
   * - its **identifier** (e.g. `GCD`, `Floor`),
   * - its **description** text,
   * - its curated **keywords** (synonyms and alternate names, e.g. `average`
   *   → `Mean`, `antiderivative` → `Integrate`, `nCr` → `Binomial`), and
   * - its **LaTeX triggers** (e.g. `\gcd` → `GCD`, `\lfloor` → `Floor`,
   *   `\binom` → `Binomial`) — available only when a LaTeX syntax is present.
   *
   * Results are `{ id, kind }`, where `kind` matches `operatorInfo()` /
   * `symbolInfo()` semantics (`'function'`, `'opaque'`, `'constant'`,
   * `'variable'`). Every returned `id` resolves via `ce.lookupDefinition(id)`;
   * chain that call for full detail.
   *
   * Ranking, best first: definitions matching **more** query tokens rank
   * above those matching fewer; among equals, by match quality — exact
   * identifier match, identifier prefix, exact trigger or exact keyword,
   * identifier substring, trigger substring, then keyword-substring and
   * description-only matches. Multi-word phrases (the whole query string, or
   * each array element) also count toward match quality, so
   * `'inverse cosine'` ranks `Arccos` (exact keyword) above token-level
   * matches. Ties break by shorter id, then alphabetically. An empty or
   * whitespace-only query returns `[]`.
   *
   * ```ts
   * ce.searchDefinitions('gcd');           // → [{ id: 'GCD', kind: 'function' }, …]
   * ce.searchDefinitions('\\lfloor');      // → includes { id: 'Floor', … }
   * ce.searchDefinitions('golden');        // → includes { id: 'GoldenRatio', kind: 'constant' }
   * ce.searchDefinitions('floor quotient integer division');
   *                                        // → includes Floor, Mod, Remainder, …
   * ce.searchDefinitions(['gcd', 'least common multiple']);
   *                                        // → includes GCD and LCM
   * ```
   *
   * @param options.limit Maximum number of results (default 10, clamped to
   * `[1, 100]`).
   */
  searchDefinitions(
    query: string | string[],
    options?: { limit?: number }
  ): DefinitionSearchResult[] {
    return searchDefinitionsImpl(this, query, options);
  }

  /**
   * Given a `name` that is **not** a known operator, return the closest known
   * operator name — a "did you mean" suggestion — or `undefined` when nothing
   * is close enough. Powers the Epsil `unknown-function` diagnostic.
   *
   * Matching is conservative and applied in priority order (first match wins):
   * case-insensitive exact match, singular/plural, Damerau–Levenshtein
   * distance (≤ 2 for names of length ≥ 6, ≤ 1 for length 5, never for
   * shorter names), then a prefix match against exactly one operator. Ties
   * prefer the candidate sharing the longest prefix with the query.
   *
   * ```ts
   * ce.suggestOperatorName('Quartile'); // → 'Quartiles'
   * ce.suggestOperatorName('foo');      // → undefined
   * ```
   */
  suggestOperatorName(name: string): string | undefined {
    return suggestOperatorNameImpl(this, name);
  }

  /**
   * Return a name for a temporary symbol: `<hint>_tmp<n>`, with `n` the
   * smallest integer from 1 for which the name has no definition from the
   * current scope and does not occur in `avoid` (boxed expressions, single
   * names, sets of names). Keeps no state and declares nothing. See
   * `IComputeEngine.temporaryName()` for the rules.
   *
   * ```ts
   * ce.temporaryName('t'); // → 't_tmp1'
   * ```
   */
  temporaryName(
    hint: string,
    ...avoid: (Expression | string | ReadonlySet<string>)[]
  ): string {
    return temporaryNameImpl(this, hint, avoid);
  }

  /**
   * Return the known analytic properties of an operator — poles, zeros, branch
   * points/cuts, residues, holomorphic/meromorphic domains — drawn from the
   * Fungrim-derived metadata store, or `undefined` if none are recorded.
   *
   * ```ts
   * ce.functionProperties('Gamma')?.poles?.toString(); // 'NonPositiveIntegers'
   * ```
   *
   * The set-valued accessors (`poles`, `zeros`, ...) return a boxed set for the
   * unconditional record of that kind; parametric / conditional records (e.g.
   * residues that depend on parameters) are available via `entries`.
   */
  functionProperties(name: string): FunctionProperties | undefined {
    return getFunctionProperties(this, name);
  }

  /** Integrate over a supported contour or the full real line and report
   * residue-theorem intermediate results. Boundary poles require explicit
   * principal-value interpretation on the real line; undecidable cases have
   * no value. */
  contourIntegrate(
    integrand: ExpressionInput,
    variable: string,
    contour: ContourInput
  ): ContourIntegralResult {
    return contourIntegrateImpl(this, integrand, variable, contour);
  }

  /**
   * Associate a new definition to a symbol in the current context.
   *
   * For internal use. Use `ce.declare()` instead.
   *
   * @internal
   */
  _declareSymbolValue(
    name: MathJsonSymbol,
    def: Partial<ValueDefinition>,
    scope?: Scope
  ): BoxedDefinition {
    // A declaration with a value: a call of `name` in the body of a function
    // literal value is a recursive call while the declaration types the
    // value (`whileDefining()`).
    if (def.value === undefined)
      return declareSymbolValueImpl(this, name, def, scope);
    return whileDefining(this, name, () =>
      declareSymbolValueImpl(this, name, def, scope)
    );
  }

  /**
   * Associate a new OperatorDefinition to a function in the current context.
   *
   * For internal use. Use `ce.declare()` instead.
   *
   * @internal
   */
  _declareSymbolOperator(
    name: string,
    def: OperatorDefinition,
    scope?: Scope
  ): BoxedDefinition {
    // A call of `name` in the body of a function literal of the definition
    // is a recursive call while the declaration types the body
    // (`whileDefining()`).
    return whileDefining(this, name, () =>
      declareSymbolOperatorImpl(this, name, def, scope)
    );
  }

  /**
   * Push a new lexical scope (and its evaluation context) onto the stack.
   */
  pushScope(scope?: Scope, name?: string): void {
    pushScopeImpl(this, scope, name);
  }

  /**
   * Remove the most recent scope from the scope stack.
   */
  popScope(): void {
    popScopeImpl(this);
  }

  /**
   * Create a caller-owned lexical scope, for use as the `scope` option of
   * `ce.parse()` / `ce.expr()`.
   *
   * The parse/box then runs with this scope current: lookups walk
   * `scope → parents`, and **every auto-declare and inference lands rooted
   * here**. Discarding the scope discards the writes; keeping it lets the
   * caller read back what the parse declared and inferred.
   *
   * ```js
   * const scope = ce.createScope({ h: 'function', p: 'tuple<3>' });
   * const expr = ce.parse('h(u) = u^2', { scope });
   * scope.declarations();  // -> [{ name: 'h', … }, { name: 'u', … }]
   * ```
   *
   * @param bindings Declarations to pre-populate the scope with. A `Type` or
   * type string is declared through the normal declare path. A
   * `BoxedDefinition` — typically one harvested from an earlier scope's
   * `declarations()` — is re-installed as the SAME object, preserving binding
   * identity and write-version continuity; it is then shared mutable state
   * between the two scopes.
   *
   * @param parent The enclosing scope. Defaults to the engine's current
   * lexical scope **at call time** — callers with their own ordering
   * discipline should pass their document scope explicitly rather than rely on
   * whatever is current.
   */
  createScope(
    bindings?: Record<string, Type | TypeString | BoxedDefinition>,
    parent?: Scope
  ): InspectableScope {
    return createScopeImpl(this, bindings, parent);
  }

  /** @internal */
  _narrowingSink: NarrowingSink | undefined = undefined;

  /** @internal */
  _pushEvalContext(scope: Scope, name?: string): void {
    pushEvalContextImpl(this, scope, name);
  }

  /** @internal */
  _popEvalContext(): void {
    popEvalContextImpl(this);
  }

  /**
   * Remove one specific evaluation context, wherever it sits on the stack.
   * @internal
   */
  _removeEvalContext(context: EvalContext): void {
    removeEvalContextImpl(this, context);
  }

  /** @internal */
  _inScope<T>(scope: Scope | undefined, f: () => T): T {
    return inScopeImpl(this, scope, f);
  }

  /** See `IComputeEngine._pipeStageAsCall`. @internal */
  _pipeStageAsCall(
    topic: Expression,
    stage: Expression
  ): { call: Expression; topicAt?: number; written?: Expression } | undefined {
    return pipeStageAsCall(this, topic, stage);
  }

  /** @internal Depth of the enclosing resolve-only regions. */
  _resolveOnlyDepth = 0;

  /** @internal */
  _resolveOnly<T>(f: () => T): T {
    this._resolveOnlyDepth += 1;
    try {
      return f();
    } finally {
      this._resolveOnlyDepth -= 1;
    }
  }

  /** @internal */
  _printStack(options?: { details?: boolean; maxDepth?: number }): void {
    printStackImpl(this, options);
  }

  /** @internal */
  _bindingSymbol(name: MathJsonSymbol, scope: Scope): Expression | undefined {
    return createBindingSymbolExpression(this, name, scope);
  }

  /** @internal */
  _librarySymbol(name: MathJsonSymbol): Expression | undefined {
    return createLibrarySymbolExpression(this, this._commonSymbols, name);
  }

  /** @internal */
  _libraryCall(
    name: MathJsonSymbol,
    ops: ReadonlyArray<ExpressionInput>,
    options?: { metadata?: Metadata; scope?: Scope }
  ): Expression | undefined {
    const library = this._evalContextStack[0]?.lexicalScope.bindings.get(name);
    if (library === undefined || !('operator' in library)) return undefined;
    const call = boxFunction(this, name, ops, {
      metadata: options?.metadata,
      scope: options?.scope,
      libraryHead: library,
    });
    // The canonical form of the call, and of its structural form, is this
    // library call again (`isLibraryCall()`). A fold of the library operator
    // can give another expression, which is not marked.
    if (call.operatorDefinition === library.operator) markLibraryCall(call);
    return call;
  }

  /** See `IComputeEngine._callBoundTo()`. @internal */
  _callBoundTo(
    name: MathJsonSymbol,
    ops: ReadonlyArray<ExpressionInput>,
    def: BoxedDefinition
  ): Expression {
    return boxFunction(this, name, ops, { libraryHead: def });
  }

  /** The `resolveSymbol` handler of the `parse()` call in progress; see the
   * interface. Saved and restored around each parse, so a parse made from
   * inside a handler sees its own. @internal */
  _activeSymbolOracle:
    ((symbol: MathJsonSymbol) => SymbolResolution | undefined) | undefined =
    undefined;

  /** Stack of parameter-name sets active while canonicalizing function bodies.
   * Each frame optionally carries declared types for annotated parameters so
   * the auto-declaration of a parameter during body canonicalization can
   * create the binding with the declared (non-inferred) type directly.
   * @internal */
  private _shadowedParameterStack: {
    names: Set<string>;
    types?: ReadonlyMap<string, Type>;
    /** The types a caller INFERRED for bare parameters before the body is
     * canonicalized (a fold's accumulator, typed to the fixpoint of its seed
     * and its combiner's result): the auto-declaration binds such a
     * parameter with the type as an INFERRED type, so a use may still widen
     * it and nothing is enforced at apply time, unlike an annotation. */
    inferredTypes?: ReadonlyMap<string, Type>;
    /** The binding auto-declared for an annotated parameter on its first
     * reference during this body's canonicalization, cached so later
     * references (including those in nested Block scopes) reuse the SAME
     * binding instead of spawning a stray per-block copy. */
    defs: Map<string, BoxedDefinition>;
    /** The lexical scope that was current when the frame was pushed — i.e. the
     * scope ENCLOSING the construct that introduces these names (the scope a
     * function literal is written in, the scope enclosing a `Block`). A
     * shadowed name must never resolve to a binding in that scope or above it:
     * such a binding belongs to the enclosing context, and the parameter (or
     * block local) shadows it. */
    boundary: Scope;
    /** True when the names are the parameters of a function literal, false
     * when they are the locals of a `Block`. The binding of a parameter is
     * recorded as a parameter binding when it is cached
     * (`markFunctionLiteralParameter()`). */
    functionLiteral: boolean;
    /** True when the function literal stands for a body with bound
     * variables, not for a literal the user wrote: the integrand of
     * `Integrate`, the body of a `Limit`. Its parameters are bound variables,
     * as the index of a `Sum` is, and keep the product reading of `x(2)`
     * (`headHasNoTypeInformation()`, `boxed-expression/invisible-operator.ts`).
     */
    liftedBody: boolean;
    /** For a function literal: what the uses of its parameters require,
     * recorded while the literal is boxed (`ParameterRecord`). */
    record: ParameterRecord | undefined;
  }[] = [];

  /** @internal */
  _pushShadowedParameters(
    names: ReadonlyArray<string>,
    types?: ReadonlyMap<string, Type>,
    inferredTypes?: ReadonlyMap<string, Type>,
    boundary?: Scope,
    functionLiteral = false,
    liftedBody = false
  ): void {
    this._shadowedParameterStack.push({
      names: new Set(names),
      types,
      inferredTypes,
      defs: new Map(),
      boundary: boundary ?? this.context.lexicalScope,
      functionLiteral,
      liftedBody,
      record: functionLiteral
        ? {
            requirements: new Map(),
            env: new UnitEnvironment(),
            collectorDepth: objectDepCollectorDepth(),
            memoStarts: sharedEvaluationStarts(),
            created: new Set(),
          }
        : undefined,
    });
  }

  /** The innermost frame that shadows `name` in the current lexical scope.
   *
   * A frame applies only where its boundary is on the current scope chain:
   * every scope of the construct that pushed it (the function literal, the
   * `Block`) is a descendant of the boundary. A boxing that runs in an
   * unrelated scope while the construct is canonicalized, such as the typed
   * copy of a callee that a signature read boxes under the callee's home
   * scope (`resultUnderDeclaredParameters()`), is outside the construct, and
   * the frame's names do not shadow there. Reading the frame there made a
   * `Block` local `b` claim the free `b` of the callee's body, and the
   * resolution then walked from a scope that the boundary does not enclose
   * up past the root scope.
   */
  private _shadowFrame(
    name: string
  ): (typeof this._shadowedParameterStack)[number] | undefined {
    const stack = this._shadowedParameterStack;
    for (let i = stack.length - 1; i >= 0; i--) {
      const frame = stack[i];
      if (!frame.names.has(name)) continue;
      for (
        let s: Scope | null | undefined = this.context?.lexicalScope;
        s;
        s = s.parent
      )
        if (s === frame.boundary) return frame;
    }
    return undefined;
  }

  /** The INFERRED type a caller supplied for an active bare shadowed
   * parameter (`_pushShadowedParameters`' third argument), if any.
   * @internal */
  _shadowedParameterInferredType(name: string): Type | undefined {
    return this._shadowFrame(name)?.inferredTypes?.get(name);
  }

  /** @internal */
  _popShadowedParameters(): void {
    this._shadowedParameterStack.pop();
  }

  /** See `IComputeEngine._withoutShadowedParameters`. @internal */
  _withoutShadowedParameters<T>(f: () => T): T {
    const saved = this._shadowedParameterStack;
    this._shadowedParameterStack = [];
    try {
      return f();
    } finally {
      this._shadowedParameterStack = saved;
    }
  }

  /** See `IComputeEngine._canonicalFunctionLiteralOperands`. @internal */
  _canonicalFunctionLiteralOperands(
    ops: ReadonlyArray<Expression>,
    options?: { inferredParamTypes?: ReadonlyMap<string, Type> }
  ): Expression | undefined {
    return canonicalFunctionLiteralOperands(this, ops, options);
  }

  /** @internal */
  _isShadowedParameter(name: string): boolean {
    return this._shadowFrame(name) !== undefined;
  }

  /** See `IComputeEngine._isFunctionLiteralParameter`. @internal */
  _isFunctionLiteralParameter(name: string): boolean {
    return this._shadowFrame(name)?.functionLiteral === true;
  }

  /** See `IComputeEngine._isLiftedBodyParameter`. @internal */
  _isLiftedBodyParameter(name: string): boolean {
    return this._shadowFrame(name)?.liftedBody === true;
  }

  /** See `IComputeEngine._hasShadowedParameterFrame`. @internal */
  _hasShadowedParameterFrame(): boolean {
    return this._shadowedParameterStack.length > 0;
  }

  /** The declared type of an active shadowed parameter, if any. @internal */
  _shadowedParameterType(name: string): Type | undefined {
    return this._shadowFrame(name)?.types?.get(name);
  }

  /** The scope enclosing the construct that shadows `name` — the scope a
   * function literal whose parameter is `name` is written in, or the scope
   * enclosing a `Block` that declares `name`. A resolution of `name` must stop
   * before reaching this scope: anything found at or above it is the enclosing
   * context's binding, which the parameter (or block local) shadows.
   * `undefined` when `name` is not an active shadowed parameter. @internal */
  _shadowedParameterBoundary(name: string): Scope | undefined {
    return this._shadowFrame(name)?.boundary;
  }

  /** The binding already auto-declared for an active shadowed parameter during
   * this body's canonicalization, if any. @internal */
  _shadowedParameterDef(name: string): BoxedDefinition | undefined {
    return this._shadowFrame(name)?.defs.get(name);
  }

  /** Cache the binding auto-declared for an active shadowed parameter, so later
   * references reuse it. `created` is true when the caller declared the
   * binding now, false when it reuses a binding that existed before.
   * @internal */
  _setShadowedParameterDef(
    name: string,
    def: BoxedDefinition,
    created = false
  ): void {
    const frame = this._shadowFrame(name);
    if (frame === undefined) return;
    frame.defs.set(name, def);
    if (created && 'value' in def) frame.record?.created.add(def.value);
    // Marked now, not only when the literal is complete: a nested literal in
    // the body can compute its type before that, and the type is then cached.
    if (frame.functionLiteral && 'value' in def)
      markFunctionLiteralParameter(this, def.value);
  }

  /** The bindings cached on the TOP shadowed-parameter frame — read by
   * `canonicalFunctionLiteralArguments` just before popping the frame, so the
   * literal's parameter declarations can adopt the binding the body's
   * references accumulated type evidence on. @internal */
  _currentShadowedParameterDefs(): ReadonlyMap<string, BoxedDefinition> {
    const stack = this._shadowedParameterStack;
    return stack.length > 0 ? stack[stack.length - 1].defs : new Map();
  }

  /** The function literals whose shadowed-parameter frame is popped, while
   * their boxing ends: the parameter definitions of each, with its record
   * (`_withClosingLiteral()`). @internal */
  private _closingLiterals: {
    params: ReadonlySet<BoxedValueDefinition>;
    record: ParameterRecord;
  }[] = [];

  /** See `IComputeEngine._parameterRecord`. @internal */
  _parameterRecord(def: BoxedValueDefinition): ParameterRecord | undefined {
    const stack = this._shadowedParameterStack;
    for (let i = stack.length - 1; i >= 0; i--) {
      const frame = stack[i];
      if (frame.record === undefined) continue;
      for (const d of frame.defs.values())
        if ('value' in d && d.value === def) return frame.record;
    }
    const closing = this._closingLiterals;
    for (let i = closing.length - 1; i >= 0; i--)
      if (closing[i].params.has(def)) return closing[i].record;
    return undefined;
  }

  /** See `IComputeEngine._saveParameterRequirements`. A boxing of a body
   * that is discarded leaves no requirement on the parameters of an
   * enclosing literal. @internal */
  _saveParameterRequirements(): () => void {
    const saved = this._shadowedParameterStack.flatMap((frame) =>
      frame.record === undefined
        ? []
        : [[frame.record.requirements, new Map(frame.record.requirements)]]
    ) as [Map<object, unknown>, Map<object, unknown>][];
    return () => {
      for (const [requirements, before] of saved) {
        requirements.clear();
        for (const [k, v] of before) requirements.set(k, v);
      }
    };
  }

  /** See `IComputeEngine._currentParameterRecord`. @internal */
  _currentParameterRecord(): ParameterRecord | undefined {
    const stack = this._shadowedParameterStack;
    return stack[stack.length - 1]?.record;
  }

  /** See `IComputeEngine._withClosingLiteral`. @internal */
  _withClosingLiteral<T>(
    params: ReadonlySet<BoxedValueDefinition>,
    record: ParameterRecord,
    f: () => T
  ): T {
    this._closingLiterals.push({ params, record });
    try {
      return f();
    } finally {
      this._closingLiterals.pop();
    }
  }

  /**
   * Use `ce.expr(name)` instead
   * @internal */
  _getSymbolValue(id: MathJsonSymbol): Expression | undefined {
    return getSymbolValueImpl(this, id);
  }

  /**
   * For internal use. Use `ce.assign(name, value)` instead.
   * @internal
   */
  _setSymbolValue(
    id: MathJsonSymbol,
    value: Expression | boolean | number | undefined
  ): void {
    setSymbolValueImpl(this, id, value);
  }

  /**
   * Declare a symbol in the current lexical scope: specify their type and
   * other attributes, including optionally a value.
   *
   * Once the type of a symbol has been declared, it cannot be changed.
   * The type information is used to calculate the canonical form of
   * expressions and ensure they are valid. If the type could be changed
   * after the fact, previously valid expressions could become invalid.
   *
   * Set the type to `unknown` if the type is not known yet: it will be
   * inferred based on usage. Use `any` for a very generic type.
   *
   * A declaration in the global scope cannot shadow a constant of the
   * library whose name results carry in MathJSON (`Pi`, `ExponentialE`,
   * `GoldenRatio`, `True`, ...): `ce.declare('Pi', { value: 3 })` throws, as
   * `ce.assign('Pi', 3)` does. A result built with the library π serializes
   * as the name `"Pi"`, and a global user binding of `Pi` would read that
   * name with the user value. A declaration in a nested scope
   * (`ce.pushScope()`, a function parameter, a `Block` local) is allowed, and
   * so are the input spellings `e` and `i`, which no result carries by name.
   *
   * A function value that writes outside itself must state the `scope` effect,
   * in every scope: `ce.declare('f', { value: writer })` throws, also after
   * `ce.pushScope()`, and `{ type: '() scope -> number', value: writer }` is
   * accepted.
   *
   * The third argument is the scope to declare in, or an options object
   * `{ scope?, extend? }` (see {@link DeclareOptions}).
   *
   * **Extend mode.** With `{ extend: true }`, the definition is a PATCH
   * applied to the operator definition that is currently visible for `id`
   * (see {@link OperatorDefinitionPatch}):
   *
   * - The engine builds a new definition from the visible one and the patch,
   *   and installs it in the target scope. A field that the patch does not
   *   name keeps its value (handlers, flags, collection handlers,
   *   description...). A field that the patch names replaces the old value:
   *   when two extensions give the same handler, the later one wins.
   * - `signature` replaces the signature. `addSignature` adds an overload: the
   *   new signature is `old & addSignature`. The new signature must be a
   *   subtype of the old one, so that every call that was valid stays valid.
   *   Otherwise the call throws and nothing is installed.
   * - Extending a name that is already declared in the target scope replaces
   *   that binding. Without `extend`, this throws as before.
   * - It is an error to extend a name that has no visible operator
   *   definition, a name declared as a value, or a function defined by
   *   clauses.
   * - The visible definition is not changed. An expression boxed before the
   *   extension keeps using the old definition.
   *
   * ```ts
   * // Accept any value as the first operand of `SetMinus`, and keep its
   * // `evaluate` and collection handlers
   * ce.declare(
   *   'SetMinus',
   *   { signature: '(value, value*) -> set' },
   *   { extend: true }
   * );
   * ce.box(['SetMinus', 5, 2]).isValid; // ➔ true
   * ```
   */
  // Two `(id, …)` overloads: a `Type`/type string in the same union as the
  // definition shapes would stop TypeScript from typing the parameters of an
  // inline `type: (ops) => …` handler (see `IComputeEngine.declare`).
  declare(
    id: string,
    type: Type | TypeString,
    scope?: Scope | (DeclareOptions & { extend?: false })
  ): IComputeEngine;
  declare(
    id: string,
    patch: OperatorDefinitionPatch,
    options: DeclareOptions & { extend: true }
  ): IComputeEngine;
  declare(
    id: string,
    def: SymbolDefinitionInput,
    scope?: Scope | (DeclareOptions & { extend?: false })
  ): IComputeEngine;
  declare(symbols: {
    [id: string]: Type | TypeString | SymbolDefinitionInput;
  }): IComputeEngine;
  declare(
    arg1:
      | string
      | {
          [id: string]: Type | TypeString | SymbolDefinitionInput;
        },
    arg2?: Type | TypeString | SymbolDefinitionInput | OperatorDefinitionPatch,
    scope?: Scope | DeclareOptions
  ): IComputeEngine {
    return declareFnImpl(this, arg1, arg2, scope);
  }

  /**
   * Load a library on an engine that is already constructed.
   *
   * The library has the same shape as a custom entry of the `libraries`
   * constructor option: a `name`, an optional `requires` list and the
   * `definitions`. Its definitions are declared in the GLOBAL scope, as with
   * `ce.declare()`: an expression boxed before the call with a head that the
   * library defines uses the new definition. With
   * `ce.box(['Sq', 3]).evaluate()` giving `Sq(3)`, loading a library that
   * defines `Sq` as `x ↦ x²` makes the same expression evaluate to `9`.
   *
   * The library name is recorded: `ce.libraryOf('Sq')` returns it.
   *
   * The library carries no LaTeX notation. To parse and serialize a notation
   * for its operators, add the entries with `ce.latexSyntax.addEntries()`.
   *
   * @throws if the library is malformed; if it is one of the standard
   * libraries (select those with the `libraries` constructor option); if a
   * library with the same name is already loaded; if a library in its
   * `requires` list is not loaded yet; if a definition name is invalid,
   * repeated, defined by a library loaded earlier, or already explicitly
   * declared in the global scope. A standard name such as `Sin` can be
   * defined: as with `ce.declare()`, the new definition shadows it. In these
   * cases nothing is declared. Also throws if `ce.declare()` rejects a
   * definition (for example for an unknown key): the definitions declared
   * before it are removed, so nothing is declared and the library is not
   * recorded as loaded. The exception is a call made while an evaluation or
   * a declaration batch is in progress: then the definitions before the rejected one stay declared.
   * If a library in `requires` is a standard library, select it with the
   * `libraries` constructor option: a standard library cannot be loaded
   * after construction.
   *
   * ```ts
   * const ce = new ComputeEngine();
   * ce.loadLibrary({
   *   name: 'residues',
   *   requires: ['arithmetic'],
   *   definitions: {
   *     Sq: { evaluate: ['Function', ['Multiply', 'x', 'x'], 'x'] },
   *   },
   * });
   * ce.box(['Sq', 3]).evaluate();  // 9
   * ce.libraryOf('Sq');            // 'residues'
   * ```
   */
  loadLibrary(library: LibraryDefinition): IComputeEngine {
    loadLibraryLate(this, library);
    return this;
  }

  /**
   * The name of the library that defines `name`, or `undefined`.
   *
   * The answer is the library whose definition `name` resolves to in the
   * current scope: a standard library name for a standard operator or
   * constant (`ce.libraryOf('Sin')` is `'trigonometry'`), the `name` of a
   * caller library given to the constructor or to `ce.loadLibrary()`, and
   * `undefined` for a name declared with `ce.declare()`, a name that is not
   * defined, or a library name that a declaration in the current scope
   * shadows.
   */
  libraryOf(name: string): string | undefined {
    const key = name.normalize();
    const entry = this._libraryProvenance.get(key);
    if (entry === undefined) return undefined;
    return this.lookupDefinition(key) === entry.binding
      ? entry.library
      : undefined;
  }

  /**
   * Declare a sequence with a recurrence relation.
   *
   * @example
   * ```typescript
   * // Fibonacci sequence
   * ce.declareSequence('F', {
   *   base: { 0: 0, 1: 1 },
   *   recurrence: 'F_{n-1} + F_{n-2}',
   * });
   * ce.parse('F_{10}').evaluate();  // → 55
   * ```
   */
  declareSequence(name: string, def: SequenceDefinition): IComputeEngine {
    return declareSequenceImpl(this, name, def);
  }

  /**
   * Get the status of a sequence definition.
   *
   * @example
   * ```typescript
   * ce.parse('F_0 := 0').evaluate();
   * ce.getSequenceStatus('F');
   * // → { status: 'pending', hasBase: true, hasRecurrence: false, baseIndices: [0] }
   * ```
   */
  getSequenceStatus(name: string): SequenceStatus {
    return getSequenceStatusImpl(this, name);
  }

  /**
   * Get information about a defined sequence.
   * Returns `undefined` if the symbol is not a sequence.
   */
  getSequence(name: string): SequenceInfo | undefined {
    return getSequenceImpl(this, name);
  }

  /**
   * List all defined sequences.
   */
  listSequences(): string[] {
    return listSequencesImpl(this);
  }

  /**
   * Check if a symbol is a defined sequence.
   */
  isSequence(name: string): boolean {
    return isSequenceImpl(this, name);
  }

  /**
   * Clear the memoization cache for a sequence.
   * If no name is provided, clears caches for all sequences.
   */
  clearSequenceCache(name?: string): void {
    clearSequenceCacheImpl(this, name);
  }

  /**
   * Get the memoization cache for a sequence.
   * Returns a Map of index → value, or `undefined` if not a sequence or memoization is disabled.
   *
   * For single-index sequences, keys are numbers.
   * For multi-index sequences, keys are comma-separated strings (e.g., '5,2').
   */
  getSequenceCache(name: string): Map<number | string, Expression> | undefined {
    return getSequenceCacheImpl(this, name);
  }

  /**
   * Generate a list of sequence terms from start to end (inclusive).
   *
   * @param name - The sequence name
   * @param start - Starting index (inclusive)
   * @param end - Ending index (inclusive)
   * @param step - Step size (default: 1)
   * @returns Array of BoxedExpressions, or undefined if not a sequence
   *
   * @example
   * ```typescript
   * ce.declareSequence('F', { base: { 0: 0, 1: 1 }, recurrence: 'F_{n-1} + F_{n-2}' });
   * ce.getSequenceTerms('F', 0, 10);
   * // → [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
   * ```
   */
  getSequenceTerms(
    name: string,
    start: number,
    end: number,
    step?: number
  ): Expression[] | undefined {
    return getSequenceTermsImpl(this, name, start, end, step);
  }

  /**
   * Look up sequences in OEIS by their terms.
   *
   * @param terms - Array of sequence terms to search for
   * @param options - Optional configuration (timeout, maxResults)
   * @returns Promise resolving to array of matching sequences
   *
   * @example
   * ```typescript
   * const results = await ce.lookupOEIS([0, 1, 1, 2, 3, 5, 8, 13]);
   * // → [{ id: 'A000045', name: 'Fibonacci numbers', ... }]
   * ```
   */
  lookupOEIS(
    terms: (number | Expression)[],
    options?: OEISOptions
  ): Promise<OEISSequenceInfo[]> {
    return lookupOEISImpl(this, terms, options);
  }

  /**
   * Check if a defined sequence matches an OEIS sequence.
   *
   * @param name - Name of the defined sequence
   * @param count - Number of terms to check (default: 10)
   * @param options - Optional configuration
   * @returns Promise with match results including OEIS matches and generated terms
   *
   * @example
   * ```typescript
   * ce.declareSequence('F', { base: { 0: 0, 1: 1 }, recurrence: 'F_{n-1} + F_{n-2}' });
   * const result = await ce.checkSequenceOEIS('F', 10);
   * // → { matches: [{ id: 'A000045', name: 'Fibonacci numbers', ... }], terms: [0, 1, 1, ...] }
   * ```
   */
  checkSequenceOEIS(
    name: string,
    count?: number,
    options?: OEISOptions
  ): Promise<{ matches: OEISSequenceInfo[]; terms: number[] }> {
    return checkSequenceOEISImpl(this, name, count, options);
  }

  /**
   * Interpret a notational expression, then propose OEIS-attributed closed
   * forms for it (the async v4 of the `Interpret` ladder).
   *
   * The synchronous `Interpret` head (and `evaluate()`) never touch the
   * network; this method is the sole path that does. It runs the same offline
   * recognizer — so `result.expression` is exactly what `Interpret` returns
   * (a `Sum`/`Product`, or the input unchanged) — and *additionally* looks the
   * extracted numeric samples up in OEIS, parsing and verifying each hit's
   * free-text formula into an attributed candidate closed form.
   *
   * Every candidate is verified to reproduce all samples exactly before being
   * returned, and always carries attribution (`id`/`name`/`url` — OEIS data is
   * CC BY-NC and is never bundled). Too few samples, being offline, a timeout,
   * or an empty OEIS result all yield an empty `candidates` list rather than a
   * rejection.
   *
   * @param expr - The (typically inert, continuation-bearing) expression
   * @param options - OEIS request options (timeout, maxResults)
   *
   * @example
   * ```typescript
   * const expr = ce.parse('1 + 3 + 6 + 10 + \\cdots + n');
   * const { expression, candidates } = await ce.interpret(expr);
   * // expression → Sum(...)   (offline recognizer)
   * // candidates → [{ id: 'A000217', url: 'https://oeis.org/A000217', ... }]
   * ```
   */
  interpret(expr: Expression, options?: OEISOptions): Promise<InterpretResult> {
    return interpretImpl(this, expr, options);
  }

  /**
   * Assign a value to a symbol in the current scope.
   * Use `undefined` to reset the symbol to no value: the declaration and its
   * type stay. A name with no definition stays undeclared. A constant, and a
   * name defined as a function, throw an error.
   *
   * The symbol should be a valid MathJSON symbol not a LaTeX string.
   *
   * If the symbol was not previously declared, it will be declared as a
   * symbol of a type inferred from its value.
   *
   * To more precisely define the type of the symbol, use `ce.declare()`
   * instead, which allows you to specify the type, value and other
   * attributes of the symbol.
   */
  assign(id: string, value: AssignValue): IComputeEngine;
  assign(ids: { [id: string]: AssignValue }): IComputeEngine;
  assign(
    arg1: string | { [id: string]: AssignValue },
    arg2?: AssignValue
  ): IComputeEngine {
    return assignFnImpl(this, arg1, arg2);
  }

  /**
   * Run `fn` with each symbol of `values` bound to the given value, and put
   * back the earlier value and type of each symbol when `fn` returns or
   * throws.
   *
   * Every expression reads the values while `fn` runs: an expression created
   * before the call, an expression created inside `fn`, and the body of a
   * function or the value of another symbol that reads the symbol.
   *
   * ```js
   * ce.declare('a', 'real');
   * const expr = ce.parse('a + 1');
   * ce.withValues({ a: 3 }, () => expr.evaluate()); // -> 4
   * expr.evaluate(); // -> a + 1
   *
   * ce.parse('f(x) := x + a').evaluate();
   * ce.withValues({ a: 1 }, () => ce.parse('f(2)').evaluate()); // -> 3
   * ```
   *
   * A value is checked as `ce.assign()` checks it: a value that the declared
   * type of the symbol does not admit throws. The value `undefined` gives the
   * symbol no value while `fn` runs, but a value that an assumption gives
   * (`ce.assume(ce.parse('a = 3'))`) still applies. A symbol that is not
   * declared is declared when the method is called, and has no value after
   * the call.
   *
   * These throw before any symbol gets a value: a constant, a symbol bound to
   * a function definition, a value that is a function, and a value that
   * `ce.assign()` refuses for the symbol.
   *
   * When putting back a value fails, the error is thrown after every other
   * value is put back. If `fn` threw too, the method throws an
   * `AggregateError` whose `errors` are the error of `fn` and the error of
   * the restore, in this order, and whose `cause` is the error of `fn`.
   *
   * `fn` must be synchronous. The earlier values are put back when `fn`
   * returns, before a promise that it returns settles.
   */
  withValues<T>(
    values: { readonly [id: string]: AssignValue },
    fn: () => T
  ): T {
    return withValuesFnImpl(this, values, fn);
  }

  /**
   * Return false if the execution should stop.
   *
   * This can occur if:
   * - an error has been signaled
   * - the time limit or memory limit has been exceeded
   *
   * @internal
   */
  _shouldContinueExecution(): boolean {
    return this._runtimeState.shouldContinueExecution();
  }

  /** @internal */
  _checkContinueExecution(): void {
    if (!this._shouldContinueExecution()) {
      // @todo: should capture stack
      throw new Error('timeout');
    }
  }

  // assert(
  //   condition: boolean,
  //   expr: Expression,
  //   msg: string,
  //   code?: SignalMessage
  // ) {
  //   if (!condition) this.signal(expr, msg, code);
  // }

  /** @internal */
  _cache<T>(
    cacheName: string,
    build: () => T,
    purge?: (t: T) => T | undefined
  ): T {
    return this._cacheStore.getOrBuild(
      cacheName,
      () => {
        // A one-time cache build is engine warm-up, not part of the user's
        // evaluation: it runs outside any deadline (an explicit "no deadline"
        // span). A partial cache is useless, so a build in progress is never
        // interrupted by an enclosing span's expiry, and the enclosing frame
        // is restored unchanged when it completes (see TIMEOUT-MODEL.md §7.3).
        const frame = this._runtimeState.deadlineFrame;
        if (frame === undefined) return build();
        this._runtimeState.deadlineFrame = undefined;
        try {
          return build();
        } finally {
          this._runtimeState.deadlineFrame = frame;
        }
      },
      purge
    );
  }

  /** Return a boxed expression from a number, string or expression input.
   * Calls `ce.function()`, `ce.number()` or `ce.symbol()` as appropriate.
   *
   * `options.scope` RECEIVES the boxing's writes: the box runs with that scope
   * as the current lexical scope, so lookups walk `scope → parents` and every
   * auto-declare and inference lands rooted there. (Before 0.101.0 the option
   * steered lookup only, and auto-declares still landed in the engine's
   * current scope.) Use `ce.createScope()` to make one that can be read back.
   */
  expr(
    expr: NumericValue | ExpressionInput,
    options?: {
      form?: FormOption;
      canonical?: CanonicalOptions;
      structural?: boolean;
      scope?: Scope | undefined;
    }
  ): Expression {
    const { canonical, structural } = optionsToInternal(options);
    return inHarvestScope(this, options?.scope, () =>
      box(this, expr, { canonical, structural, scope: options?.scope })
    );
  }

  /** @deprecated Use `expr()` instead. */
  box(
    expr: NumericValue | ExpressionInput,
    options?: {
      form?: FormOption;
      canonical?: CanonicalOptions;
      structural?: boolean;
      scope?: Scope | undefined;
    }
  ): Expression {
    return this.expr(expr, options);
  }

  rebind(
    expr: Expression,
    options?: { form?: FormOption; scope?: Scope | undefined }
  ): Expression {
    return inHarvestScope(this, options?.scope, () =>
      rebind(this, expr, options)
    );
  }

  /** @internal LatexSyntax instance for parse/serialize. */
  private _latexSyntax?: ILatexSyntax;

  /** The LatexSyntax instance, lazily created if a factory is registered.
   *  `undefined` only when no LatexSyntax was provided and no factory exists
   *  (the core-only entry point).
   *
   *  A lazily created instance belongs to this engine only, so
   *  `ce.latexSyntax.addEntries([...])` changes the notation of this engine
   *  and of no other. An instance passed with the `latexSyntax` constructor
   *  option is the caller's: if it was passed to several engines, entries
   *  added to it apply to all of them. */
  get latexSyntax(): ILatexSyntax | undefined {
    if (!this._latexSyntax && ComputeEngine._latexSyntaxFactory)
      this._latexSyntax = ComputeEngine._latexSyntaxFactory();
    return this._latexSyntax;
  }

  /** @internal Returns the LatexSyntax instance, lazily creating one
   *  if a factory is registered. Throws if no LatexSyntax is available. */
  _requireLatexSyntax(): ILatexSyntax {
    if (!this._latexSyntax && ComputeEngine._latexSyntaxFactory)
      this._latexSyntax = ComputeEngine._latexSyntaxFactory();
    if (!this._latexSyntax)
      throw new Error(
        'LatexSyntax not available. Pass a LatexSyntax instance to the ComputeEngine constructor.'
      );
    return this._latexSyntax;
  }

  /** @internal Engine-wide LaTeX parse/serialize options (e.g. decimalSeparator).
   *  Merged into every `parse()` and `toLatex()` call between the LatexSyntax
   *  instance defaults and any per-call overrides. */
  private _latexOptions: Partial<ParseLatexOptions & SerializeLatexOptions> =
    {};

  /** Engine-wide LaTeX parse/serialize options.
   *
   * These options are merged into every `parse()` and `toLatex()` call.
   * Precedence (most-specific wins):
   *   1. LatexSyntax instance defaults (set at its construction)
   *   2. `ce.latexOptions` (this property)
   *   3. Per-call options passed to `ce.parse()` / `expr.toLatex()`
   *
   * Assigning replaces the whole bag. Use spread to merge:
   * ```ts
   * ce.latexOptions = { ...ce.latexOptions, decimalSeparator: '{,}' };
   * ```
   */
  get latexOptions(): Partial<ParseLatexOptions & SerializeLatexOptions> {
    return this._latexOptions;
  }

  set latexOptions(
    options: Partial<ParseLatexOptions & SerializeLatexOptions>
  ) {
    // A style option specified as an invalid constant (e.g.
    // `rootStyle: 'sold'`) is reported here, rather than resulting in an
    // empty serialization later on.
    validateStyleOptions(options);
    // An invalid `digits` is reported here too, rather than at the next
    // `.latex` read of any expression.
    validateDisplayDigits(options.digits);
    this._latexOptions = { ...options };
  }

  /**
   * Parse a LaTeX string and return a boxed expression.
   *
   * Uses the engine's symbol definitions for accurate parsing
   * (e.g., recognizing `f` as a function).
   *
   * Malformed or incomplete LaTeX does **not** throw: it returns a boxed
   * expression containing `["Error", ...]` nodes (check `expr.isValid`).
   * Parsing `null` returns `null`.
   *
   * `options.scope` RECEIVES the parse's writes: the whole parse runs with
   * that scope as the current lexical scope, so name resolution (including the
   * parser's symbol oracle) walks `scope → parents`, and every declaration
   * and inference made while it runs lands rooted there. Boxing itself
   * declares no name. Discarding the scope discards the writes. Use `ce.createScope()` to make one that can be read back.
   *
   * `options.speculative` leaves NO trace in the engine's type state: the
   * parse runs inside a transient scope (declarations and inferences land
   * there and are discarded with it), and every ambient symbol whose type is currently
   * inferred is shadowed in that scope with its current type — so a narrowing
   * use in `latex` refines the discarded shadow instead of persistently
   * narrowing the ambient symbol. Use it for derive-style parses that only
   * READ the result (its type, structure, or serialization): the result's
   * bindings refer to the discarded scope, so do not retain, evaluate, or
   * compare it against later expressions. Mutually exclusive with `scope`.
   *
   * With `form: 'structural'`, a spacing command between the operands of a
   * juxtaposition (`\,`, `\;`, `\quad`, …) is left out, as the canonical form
   * leaves it out: `\,d=2` is `["Equal", "d", 2]`, the same as `d=2`. The
   * raw form keeps it (`["InvisibleOperator", ["HorizontalSpacing", 3],
   * "d"]`), and so does the `structural` property of a raw expression.
   *
   * @throws Only in edge cases:
   * - the argument is neither a string nor `null`/`undefined`;
   * - both `speculative` and `scope` are passed;
   * - no LaTeX syntax is available (minimal entry point without a
   *   `LatexSyntax` instance passed to the `ComputeEngine` constructor);
   * - an internal parser safety guard trips (e.g. the infinite-loop
   *   detector), which indicates a bug rather than bad input.
   */
  parse(
    latex: string,
    options?: Partial<ParseLatexOptions> & {
      form?: FormOption;
      canonical?: CanonicalOptions;
      structural?: boolean;
      scope?: Scope | undefined;
      speculative?: boolean;
    }
  ): Expression;
  parse(
    latex: string | null,
    options?: Partial<ParseLatexOptions> & {
      form?: FormOption;
      canonical?: CanonicalOptions;
      structural?: boolean;
      scope?: Scope | undefined;
      speculative?: boolean;
    }
  ): Expression | null;
  parse(
    latex: string | null,
    options?: Partial<ParseLatexOptions> & {
      form?: FormOption;
      canonical?: CanonicalOptions;
      structural?: boolean;
      scope?: Scope | undefined;
      speculative?: boolean;
    }
  ): Expression | null {
    if (latex === null || latex === undefined) return null;
    if (typeof latex !== 'string')
      throw Error('ce.parse(): expected a LaTeX string');

    // A SPECULATIVE parse leaves no trace in the engine's type state. Two
    // leaks are closed, and they need different mechanisms:
    // - auto-declares: confined by running the whole parse in a transient
    //   scope, discarded on the way out;
    // - narrowing writes: a use in `latex` can NARROW an ambient symbol whose
    //   type is inferred (e.g. `Fibonacci(u)` moves an inferred `u: number`
    //   to `integer`), and that write lands on the resolved definition
    //   wherever it lives — a child scope alone does not confine it. So every
    //   symbol the string mentions whose ambient definition is
    //   inferred-typed is SHADOWED in the transient scope, seeded with its
    //   current type: the narrowing refines the shadow, and the shadow is
    //   discarded. Symbols with a declared (non-inferred) type are not
    //   shadowed — uses cannot narrow them, and shadowing a constant (`Pi`)
    //   or an operator would change how the string parses.
    // The returned expression is for INSPECTION (its type, structure,
    // serialization): its bindings refer to the discarded scope. This is the
    // engine-side isolation for consumer derive-style parses (Tycho item
    // 179: a type-deriving parse must not side-effect-declare into, or
    // narrow, the parent scope).
    if (options?.speculative) {
      if (options.scope !== undefined)
        throw Error(
          'ce.parse(): the `speculative` and `scope` options are mutually ' +
            "exclusive — `speculative` discards the parse's writes, `scope` " +
            'harvests them'
        );
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { speculative, ...rest } = options;
      // The raw pre-parse (no binding, so no declarations and no inference
      // writes) supplies the symbols the string mentions, so the shadows can
      // be declared before the real parse runs.
      const raw = this.parse(latex, { ...rest, form: 'raw' });
      this.pushScope(undefined, 'speculative-parse');
      try {
        const scope = this.context.lexicalScope!;
        if (raw !== null)
          for (const name of new Set(raw.symbols)) {
            const incumbent = this.lookupDefinition(name);
            if (
              incumbent !== undefined &&
              'value' in incumbent &&
              !incumbent.value.isConstant &&
              // A DECLARED `unknown` is narrowable too, so it needs the shadow
              // just as much as an inferred type does. `unknown` is a
              // placeholder that refines per use, not a contract (unlike `any`
              // and unlike a concrete declared type, which a use cannot move),
              // so `ce.declare('u', 'unknown')` followed by a SPECULATIVE
              // parse of `u+1` persistently narrowed `u` to `number` — a
              // trace, which is the one thing `speculative` promises not to
              // leave. The same pairing spells "not a binding contract"
              // wherever else it is needed (see `assignValue` in
              // `engine-declarations.ts`).
              (incumbent.value.inferredType || incumbent.value.type.isUnknown)
            )
              this.declare(
                name,
                {
                  // The shadow carries the incumbent's own flag: a host's
                  // explicit `unknown` declaration and the engine's inferred
                  // placeholder read differently before a parenthesized
                  // argument (`k(2)` is a product for the first, an
                  // application for the second — `invisible-operator.ts`),
                  // and a shadow marked inferred for a declared `unknown`
                  // made the speculative parse diverge from the normal one.
                  // Narrowing refines a declared `unknown` as it refines an
                  // inferred type, so the flag is not what makes the shadow
                  // narrowable.
                  inferred: incumbent.value.inferredType,
                  type: incumbent.value.type.type,
                  // Parse-affecting metadata must survive onto the shadow, or
                  // the speculative parse diverges from a normal one: the
                  // parser's symbol oracle reads `subscriptEvaluate` through
                  // the RESOLVED definition to keep `S_5` parsing as
                  // `Subscript(S, 5)` (see `parse-symbol.ts`), and during a
                  // speculative parse the shadow is what resolves.
                  ...(incumbent.value.subscriptEvaluate
                    ? { subscriptEvaluate: incumbent.value.subscriptEvaluate }
                    : {}),
                },
                scope
              );
          }
        return this.parse(latex, rest);
      } finally {
        this.popScope();
      }
    }

    // The supplied scope RECEIVES the call's writes, so the WHOLE parse runs
    // with it as the current lexical scope: the LaTeX pass (whose symbol
    // oracle falls back to a scope lookup, so a binding there steers
    // application-vs-multiplication and the subscript fold) and the boxing
    // (whose auto-declares and inference then land rooted there). `inScope`
    // pops without the disposal loop, so a harvested definition outlives the
    // call. Re-entered with the option cleared, so this runs exactly once.
    if (options?.scope)
      return inHarvestScope(this, options.scope, () =>
        this.parse(latex, { ...options, scope: undefined })
      );

    const syntax = this._requireLatexSyntax();

    // `form` / `canonical` / `structural` control how the parsed MathJSON is
    // boxed, and `scope` / `speculative` were consumed by the re-entries
    // above; none of them are LaTeX-parser options, so keep them out of
    // `parseOpts` (which is forwarded to the LaTeX parser).
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { form, canonical, structural, scope, speculative, ...parseOpts } =
      options ?? {};

    // Opt-in parse diagnostics: the parser reports each diagnostic through an
    // internal sink; collect them here and attach the (possibly empty) array
    // to the top-level result below. The effective flag is resolved after
    // merging the engine-wide `_latexOptions` with the per-call options: an
    // explicit per-call value (including `false`) wins over an engine-wide
    // `diagnostics: true`.
    const wantDiagnostics =
      parseOpts.diagnostics ?? this._latexOptions?.diagnostics ?? false;
    let diagnostics: ParseDiagnostic[] | undefined;
    let onDiagnostic: ((d: ParseDiagnostic) => void) | undefined;
    let onBoundVariable: ((name: string) => void) | undefined;
    // Bound names a binder parselet deliberately processed (_pruneUndeclared):
    // exempt from the bound-only post-check assertion below.
    const processedBoundNames = new Set<string>();
    if (wantDiagnostics) {
      diagnostics = [];
      onBoundVariable = (name) => processedBoundNames.add(name);
      const seen = new Set<string>();
      onDiagnostic = (d) => {
        // Belt-and-braces dedupe: identical-span re-emissions (same
        // code+start+end+detail) are always spurious duplicates left by a
        // speculative reparse of the same tokens.
        const key = `${d.code} ${d.start} ${d.end} ${d.detail ? JSON.stringify(d.detail) : ''}`;
        if (seen.has(key)) return;
        seen.add(key);
        diagnostics!.push(d);
      };
    }

    // Explicit lexical bindings shadow external facts. Only an inferred,
    // unassigned binding yields to the resolver. Cache answers by name for
    // this parse: symbol facts do not depend on speculative parser retries.
    const userResolve =
      parseOpts.resolveSymbol ?? this._latexOptions?.resolveSymbol;
    const facts = new Map<MathJsonSymbol, SymbolResolution>();
    const unresolved = new Set<MathJsonSymbol>();
    const resolveSymbol = userResolve
      ? (id: MathJsonSymbol) => {
          const def = this.lookupDefinition(id);
          const scoped = this._scopeResolution(def);
          if (scoped !== undefined && !isInferredDefinition(def)) return scoped;
          let resolved = facts.get(id);
          if (resolved === undefined && !unresolved.has(id)) {
            resolved = userResolve(id) ?? undefined;
            if (resolved !== undefined) facts.set(id, resolved);
            else unresolved.add(id);
          }
          return resolved ?? scoped;
        }
      : (id: MathJsonSymbol) => this._resolveSymbolFromScope(id);

    const userResolveApplication =
      parseOpts.resolveApplication ?? this._latexOptions?.resolveApplication;
    const supersededGuesses = new Set<MathJsonSymbol>();
    const resolveApplication: ParseLatexOptions['resolveApplication'] =
      userResolveApplication
        ? (context) => {
            const decision = userResolveApplication(context);
            if (
              decision !== undefined &&
              !facts.has(context.head) &&
              isInferredDefinition(this.lookupDefinition(context.head))
            )
              supersededGuesses.add(context.head);
            return decision;
          }
        : undefined;

    const outerOracle = this._activeSymbolOracle;
    this._activeSymbolOracle = userResolve;
    beginInferenceTransaction(this);
    try {
      const result = syntax.parse(latex, {
        tolerance: this.tolerance,
        ...this._latexOptions,
        ...parseOpts,
        resolveSymbol,
        resolveApplication,
        // Resolved diagnostics wiring wins over both spreads.
        diagnostics: wantDiagnostics,
        onDiagnostic,
        onBoundVariable,
        isLibraryFunction: (id) => this._isLibraryFunction(id),
      });

      if (result === null) return null;

      // External facts live in an expression-owned scope. Declaring them in
      // the caller's scope would make a raw parse mutate its environment and
      // would let one parse's resolver affect unrelated later expressions.
      const parseScope: Scope | undefined =
        facts.size || supersededGuesses.size
          ? {
              parent: this.context.lexicalScope,
              bindings: new Map(),
              // Only the explicitly installed facts belong to this overlay.
              // Ordinary free variables keep the caller's inference scope.
              noAutoDeclare: true,
            }
          : undefined;
      let boxed = this._inScope(parseScope, () => {
        // An occurrence decision may contradict an earlier inferred use.
        // Give that occurrence a fresh unknown binding and let its explicit
        // tree constrain it, without rewriting the ambient guess.
        for (const id of supersededGuesses)
          if (!facts.has(id))
            this.declare(id, { type: 'unknown', inferred: true });
        for (const [id, fact] of facts)
          this.declare(id, {
            type: fact.type,
            inferred: false,
            // The resolver reports handler presence, not its implementation.
            // Rebuild in the captured scope so evaluation keeps the external
            // subscript symbolic instead of folding it to a compound name.
            ...(fact.subscriptEvaluate
              ? {
                  subscriptEvaluate: markEngineSubscriptHandler(
                    (subscript: Expression) =>
                      this._inScope(parseScope, () =>
                        this._fn('Subscript', [this.symbol(id), subscript])
                      )
                  ),
                }
              : {}),
          });
        // A call of a fact reads the definition that the scope of this
        // `parse()` call holds (`markExternalFact`). An occurrence binding of
        // a superseded guess (above) is not a fact.
        for (const id of facts.keys()) {
          const def = parseScope!.bindings.get(id);
          if (def !== undefined) markExternalFact(def, parseScope!);
        }
        const internal = optionsToInternal({ form, canonical, structural });
        // The structural form leaves out the spacing commands between the
        // operands of a juxtaposition (`dropSpacingOperands()`).
        return box(
          this,
          internal.structural ? dropSpacingOperands(result) : result,
          internal
        );
      });

      if (parseScope) {
        (boxed as _BoxedExpression)._retainParseScope(parseScope);
      }

      if (diagnostics !== undefined) {
        // Attach to a fresh top-level instance: `_unshared()` clones interned
        // leaf literals (small integers, cached constants) and returns
        // always-fresh function expressions as-is, so tagging never pollutes a
        // shared/cached instance (e.g. `ce.parse('4', { diagnostics: true })`).
        boxed = (boxed as unknown as _BoxedExpression)._unshared();

        // Defense-in-depth bound-variable post-check (DETECT-ONLY — it never
        // drops diagnostics). On a canonical result, a name that appears among
        // the result's symbols but NOT among its free variables occurs only
        // bound. That has two causes, and only one is a defect:
        //   1. a binder parselet forgot its `_pruneUndeclared` wiring — a real
        //      false fire that should have been pruned at parse time; or
        //   2. canonicalization synthesized a same-named binder from a
        //      genuinely-free source reference (e.g. `\mathbb{R}_{>0}` builds a
        //      set-builder reusing the membership variable's name). Here the
        //      diagnostic is CORRECT — the consumer needs to see the free
        //      source reference — so dropping it would be a false negative.
        // We cannot tell the two apart from the boxed result, so we keep the
        // diagnostic either way and only `console.assert` (stripped in
        // production) to surface case 1 to test runs / the corpus gate. Skipped
        // for non-canonical parses (free-variable analysis is unreliable there),
        // and wrapped so a throw never breaks the parse.
        //
        // Names in `processedBoundNames` are exempt: a binder parselet DID run
        // its `_pruneUndeclared` wiring for them, so a surviving diagnostic is a
        // deliberately-kept free occurrence whose name collides with the dummy
        // (`\int_x^1 x\,dx` — the canonical result then reports the shared
        // name as bound-only, hiding the free lower bound from this check).
        // The implicit variable of an integral that names none
        // (`\int_0^1 x^2`) is exempt too: the canonical form binds that free
        // source name (see `implicitIntegralVariables()`).
        if (boxed.isCanonical) {
          try {
            const symbols = new Set(boxed.symbols);
            const free = new Set(boxed.freeVariables);
            const implicit = implicitIntegralVariables(boxed);
            for (const d of diagnostics) {
              if (d.code !== 'undeclared-symbol') continue;
              const name = d.detail?.name;
              if (typeof name !== 'string') continue;
              if (processedBoundNames.has(name) || implicit.has(name)) continue;
              if (symbols.has(name) && !free.has(name))
                console.assert(
                  false,
                  `parse-diagnostics: bound-only "${name}" in canonical result — either missing _pruneUndeclared wiring in a binder parselet, or a canonicalization-synthesized binder reusing a free source name (diagnostic retained either way)`
                );
            }
          } catch {
            // Never let diagnostic post-processing break a successful parse.
          }
        }

        // Deep-freeze: each diagnostic and its `detail` are frozen too, so the
        // exposed array is immutable all the way down (matches the JSDoc).
        for (const d of diagnostics) {
          if (d.detail) Object.freeze(d.detail);
          Object.freeze(d);
        }
        boxed.parseDiagnostics = Object.freeze(diagnostics);
      }

      return boxed;
    } finally {
      this._activeSymbolOracle = outerOracle;
      endInferenceTransaction(this);
    }
  }

  /**
   * What the current scope knows about `id`, in the shape of the parser's
   * `resolveSymbol` oracle: `undefined` if undeclared, otherwise the
   * definition's type (and whether it has a `subscriptEvaluate` handler).
   * Declaration *presence* is the record's presence — a declared symbol with
   * an `unknown` type still resolves.
   */
  private _resolveSymbolFromScope(
    id: MathJsonSymbol
  ):
    | { type: BoxedType; subscriptEvaluate?: boolean; inferred?: boolean }
    | undefined {
    return this._scopeResolution(this.lookupDefinition(id));
  }

  private _scopeResolution(
    def: BoxedDefinition | undefined
  ):
    | { type: BoxedType; subscriptEvaluate?: boolean; inferred?: boolean }
    | undefined {
    if (!def) return undefined;
    if (isOperatorDef(def)) return { type: def.operator.signature };
    // A macro is not a function for the parser (`macro.ts`): its body has a
    // type only where it is boxed, and the answer `any`, which is neither
    // `unknown` nor a function, makes `A(x+1)` a product.
    if (isMacroDef(def)) return { type: MACRO_RESOLUTION_TYPE };
    if (isValueDef(def))
      return {
        type: def.value.type,
        subscriptEvaluate: !!def.value.subscriptEvaluate,
        inferred: isInferredDefinition(def),
      };
    // A definition of neither kind is still a declaration.
    return { type: BoxedType.unknown };
  }

  /**
   * Whether a LaTeX assignment to `id`, or an Epsil definition `id(x) := …`,
   * would replace a function of a library: `a + b := 5` would change the value
   * of every later `1 + 2`.
   *
   * A definition that the host made in place of the library function
   * (`ce.declare('D', 'function')`, `ce.declare('N', 'unknown')`, or
   * `ce.declare('Sin', { … })`) is not the library function, so a LaTeX
   * assignment can define it. So is a function that an earlier Epsil program
   * defined with `function Sin(x) { … }`.
   *
   * A value whose type is not a function does not make the name the host's own.
   * After `N := 5` or `N := y`, a later `N(x) := x + 1` would replace the library
   * `N`, which `N(1/3)` calls after `N := 5`. Reading `[N, 1]` binds `N` to a
   * shadow with no value and no type, and calls of `N` still reach the library:
   * a parse must not change what a later assignment can do.
   *
   * @internal
   */
  _isLibraryFunction(id: MathJsonSymbol): boolean {
    const def = this.lookupDefinition(id);
    if (def === undefined) return false;
    if (isOperatorDef(def)) return isLibraryDefinition(this, id, def);
    const library = this.contextStack[0]?.lexicalScope.bindings.get(id);
    if (library === undefined || !isOperatorDef(library)) return false;
    if (!isValueDef(def)) return true;
    const { value } = def;
    if (value.type.matches('function')) return false;
    const hostDeclaration = value.value === undefined && !value.inferredType;
    return !hostDeclaration;
  }

  /**
   * The symbols that appear in function-application syntax — `f(…)` — in
   * `latex` but are **not** defined as functions in the current scope, and so
   * are interpreted as implicit multiplication (`f·x`) or left unresolved.
   *
   * Resolution is scope-aware: a name declared as a function (e.g. by a
   * notebook's "declare every defined function first" pass) is not reported.
   * This is a parse-time signal — the application-vs-multiplication
   * distinction is erased by canonicalization — and the call has no side
   * effects (it does not declare symbols). Intended to be intersected with
   * {@link Expression.freeVariables} / unresolved symbols to warn that,
   * say, `f(x)` looks like a call to an undefined function.
   *
   * ```js
   * ce.declare('f', 'function');
   * ce.appliedNonFunctions('f(x) + g(x)');  // -> ['g']  (f is a function)
   * ```
   */
  appliedNonFunctions(latex: string): string[] {
    const syntax = this.latexSyntax;
    if (!syntax) return [];
    // Same handler-supplements-scope composition as `parse()`, except that a
    // function declaration the engine INFERRED from an earlier application
    // of the name, with nothing behind it, does not count as a function
    // here: the question this call answers is whether the host has defined
    // the name, and such a declaration is the engine's guess, not the
    // host's definition. Without this, the first parse of `g(x)` made every
    // later call answer `[]` for `g`.
    const scope = (id: MathJsonSymbol) => {
      const def = this.lookupDefinition(id);
      if (
        def !== undefined &&
        isValueDef(def) &&
        def.value.inferredType &&
        def.value.storedValue === undefined &&
        def.value.type.matches('function')
      )
        return undefined;
      return this._resolveSymbolFromScope(id);
    };
    const userResolve = this._latexOptions?.resolveSymbol;
    const raw = syntax.parse(latex, {
      ...this._latexOptions,
      resolveSymbol: userResolve
        ? (id) => {
            const scoped = scope(id);
            if (scoped !== undefined && !scoped.inferred) return scoped;
            return userResolve(id) ?? scoped;
          }
        : scope,
    });
    const result = new Set<string>();
    if (raw !== null) collectAppliedNonFunctions(raw, result);
    return Array.from(result).sort();
  }

  function(
    name: string,
    ops: ReadonlyArray<Expression> | ReadonlyArray<MathJsonExpression>,
    options?: {
      metadata?: Metadata;
      form?: FormOption;
      canonical?: CanonicalOptions;
      structural?: boolean;
      scope?: Scope | undefined;
    }
  ): Expression {
    const { canonical, structural } = optionsToInternal(options);
    return boxFunction(this, name, ops, {
      metadata: options?.metadata,
      canonical,
      structural,
      scope: options?.scope,
    });
  }

  /**
   *
   * Shortcut for `this.expr(["Error",...])`.
   *
   * The result is canonical.
   */
  error(message: string | string[], where?: string): Expression {
    return createErrorExpression(this, message, where);
  }

  typeError(
    expected: Type,
    actual: undefined | Type | BoxedType,
    where?: string | Expression
  ): Expression {
    return createTypeErrorExpression(this, expected, actual, where);
  }

  /**
   * Add a `["Hold"]` wrapper to `expr`.
   */
  hold(expr: ExpressionInput): Expression {
    return this._fn('Hold', [this.expr(expr, { form: 'raw' })]);
  }

  /** Shortcut for `this.expr(["Tuple", ...])`
   *
   * The result is canonical.
   *
   * Every element keeps its position, including `Nothing` and missing data.
   */
  tuple(...elements: ReadonlyArray<number>): Expression;
  tuple(...elements: ReadonlyArray<Expression>): Expression;
  tuple(...elements: ReadonlyArray<number | Expression>): Expression {
    return new BoxedFunction(
      this,
      'Tuple',
      elements.map((x) =>
        typeof x === 'number' ? this.number(x) : x.canonical
      ),
      { canonical: true }
    );
  }

  list(values: ArrayLike<number>): Expression {
    return this._list(values, false);
  }

  /** @internal A `List` of numbers held in a numeric store, as `list()`
   * builds it. When `floats` is `true`, the elements with an integer value
   * are floats (`_numericStoreFloats`): a float computation produced them,
   * and `2·0.5` is the float `1`, not the exact `1`. */
  _list(values: ArrayLike<number>, floats: boolean): Expression {
    const n = values.length;
    if (typeof n !== 'number' || !Number.isSafeInteger(n) || n < 0)
      throw new TypeError(
        `list(): the length must be a non-negative safe integer, not ${String(n)}`
      );
    // The empty list keeps its ordinary construction, type and identity.
    if (n === 0) return this.function('List', []);
    const store = new Array<number>(n);
    for (let i = 0; i < n; i++) {
      const v = values[i];
      if (typeof v !== 'number')
        throw new TypeError(
          `list(): element ${i} is ${v === undefined ? 'undefined' : typeof v}, not a number`
        );
      // `-0 === 0`, so this stores `+0` for both, which is what
      // `ce.number(-0)` boxes to.
      store[i] = v === 0 ? 0 : v;
    }
    return new BoxedFunction(this, 'List', undefined, {
      canonical: true,
      numericStore: Object.freeze(store),
      numericStoreFloats: floats,
    });
  }

  type(type: Type | TypeString | BoxedType): BoxedType {
    if (type instanceof BoxedType) return type;
    if (typeof type === 'string' && isValidPrimitiveType(type)) {
      let boxed = this._commonTypes.get(type);
      if (boxed === undefined) {
        boxed = new BoxedType(type, this._typeResolver);
        this._commonTypes.set(type, boxed);
      }
      return boxed;
    }
    return new BoxedType(type, this._typeResolver);
  }

  string(s: string, metadata?: Metadata): Expression {
    return new BoxedString(this, s, metadata);
  }

  character(s: string, metadata?: Metadata): Expression {
    // The caller is responsible for having checked the one-cluster criterion
    // (`isSingleGraphemeCluster`); a caller that cannot, goes through
    // `CharacterFrom`, which reports a diagnostic instead. Throwing here
    // rather than silently truncating keeps "a character is exactly one
    // grapheme cluster" a class invariant. This must be a real throw, not
    // `console.assert`: all `console.*` calls are stripped from the minified
    // production build, so an assert would enforce the invariant only in
    // development.
    if (!isSingleGraphemeCluster(s))
      throw new Error(
        `ce.character(): "${s}" is not exactly one grapheme cluster. ` +
          `A character is exactly one user-perceived character (one UAX #29 ` +
          `extended grapheme cluster); use ce.string() for arbitrary text, ` +
          `or CharacterFrom() to get a diagnostic instead of a throw.`
      );
    return new BoxedCharacter(this, s, metadata);
  }

  /** Create a boxed symbol */
  symbol(
    name: string,
    options?: {
      canonical?: CanonicalOptions;
      metadata?: Metadata;
      autoDeclare?: boolean;
    }
  ): Expression {
    return createSymbolExpression(this, this._commonSymbols, name, options);
  }

  /**
   * This function tries to avoid creating a boxed number if `num` corresponds
   * to a common value for which we have a shared instance (-1, 0, NaN, etc...)
   *
   * A `{ re, im }` object is a complex number whose parts are each a
   * `number` or a `BigDecimal`: see `IComputeEngine.number()`.
   */
  number(
    value:
      | number
      | bigint
      | string
      | NumericValue
      | MathJsonNumberObject
      | BigDecimal
      | Complex
      | Rational
      | { re: number | BigDecimal; im: number | BigDecimal },
    options?: { metadata: Metadata; canonical: CanonicalOptions }
  ): Expression {
    // A `{ re, im }` object (not a `Complex`, whose parts are doubles and
    // which `canonicalNumber()` reads itself) keeps a big-decimal part
    // without rounding it to a double.
    if (
      typeof value === 'object' &&
      value !== null &&
      !Array.isArray(value) &&
      !(value instanceof NumericValue) &&
      !(value instanceof Complex) &&
      !(value instanceof BigDecimal) &&
      're' in value &&
      'im' in value
    ) {
      // A complex value from the host whose two parts are integers is the
      // exact Gaussian integer, as an integer `number` or an integer-valued
      // `BigDecimal` given alone is an exact integer (`canonicalNumber()`).
      // A part with a fraction makes the value a float.
      const re = exactIntegerPart(value.re);
      const im = exactIntegerPart(value.im);
      if (re !== undefined && im !== undefined)
        return createNumberExpression(
          this,
          this._commonNumbers,
          im === 0n
            ? re
            : new ExactNumericValue(
                { rational: [re, 1n], imRational: [im, 1n] },
                this._inexactNumericValue
              ),
          options
        );
      return createNumberExpression(
        this,
        this._commonNumbers,
        this._numericValue({ re: value.re, im: value.im }),
        options
      );
    }
    return createNumberExpression(
      this,
      this._commonNumbers,
      value as Parameters<typeof createNumberExpression>[2],
      options
    );
  }

  rules(
    rules:
      Rule | ReadonlyArray<Rule | BoxedRule> | BoxedRuleSet | undefined | null,
    options?: {
      canonical?: boolean;
      /** Default purpose applied to any rule in the set that doesn't carry
       *  its own `purpose` tag (a per-rule tag takes precedence). */
      purpose?: RulePurpose;
    }
  ): BoxedRuleSet {
    return boxRules(this, rules, options);
  }

  /**
   * Return a set of built-in rules.
   */
  getRuleSet(id?: string): BoxedRuleSet | undefined {
    id ??= 'standard-simplification';

    if (id === 'standard-simplification') {
      // Invalidate cache if rules array was mutated (e.g. via push/splice)
      if (this._simplificationRules.hasMutatedSinceLastCache()) {
        this._cacheStore.invalidate('standard-simplification-rules');
      }

      const result = this._cache('standard-simplification-rules', () => {
        // Rules tagged `purpose: 'expand'` grow expressions by design
        // (series, argument expansion): they are excluded from simplify()'s
        // scan, but remain reachable via `expr.replace()`.
        const boxed = boxRules(this, this._simplificationRules.rules, {
          canonical: true,
        });
        const simplifyRules = boxed.rules.filter((r) => r.purpose !== 'expand');
        // Collapse each hot head's loader-registered functional dispatch rules
        // into one per-head dispatcher (ROADMAP item 5). No-op when no such
        // rules are present (e.g. the Fungrim identities are not loaded). The
        // public `ce.simplificationRules` array is untouched — only this
        // internal cached set is aggregated.
        return { rules: aggregateHotHeadDispatch(simplifyRules) };
      });
      this._simplificationRules.markCached();
      return result;
    }

    if (id === 'solve-univariate') {
      // Invalidate cache if rules array was mutated (e.g. via push/splice)
      if (this._solveRules.hasMutatedSinceLastCache()) {
        this._cacheStore.invalidate('univariate-roots-rules');
      }

      const result = this._cache('univariate-roots-rules', () =>
        boxRules(this, this._solveRules.rules)
      );
      this._solveRules.markCached();
      return result;
    }

    if (id === 'harmonization') {
      // Invalidate cache if rules array was mutated (e.g. via push/splice)
      if (this._harmonizationRules.hasMutatedSinceLastCache()) {
        this._cacheStore.invalidate('harmonization-rules');
      }

      const result = this._cache('harmonization-rules', () =>
        boxRules(this, this._harmonizationRules.rules)
      );
      this._harmonizationRules.markCached();
      return result;
    }

    return undefined;
  }

  /**
   * Return a function expression, but the caller is responsible for making
   * sure that the arguments are canonical.
   *
   * Unlike `ce.function()`, the operator of the result is the name argument.
   * Calling this function directly is potentially unsafe, as it bypasses
   * the canonicalization of the arguments.
   *
   * For example:
   *
   * - `ce._fn('Multiply', [1, 'x'])` returns `['Multiply', 1, 'x']` as a
   *   canonical expression, even though it doesn't follow the canonical form
   * - `ce.function('Multiply', [1, 'x']` returns `'x'` which is the correct
   *    canonical form
   *
   * @internal */
  _fn(
    name: MathJsonSymbol,
    ops: ReadonlyArray<Expression>,
    options?: { metadata?: Metadata; canonical?: boolean; scope?: Scope }
  ): Expression {
    const canonical = options?.canonical ?? true;

    // `_fn` constructs a `BoxedFunction` directly, so it does not pass through
    // `boxFunctionInternal` and would otherwise be an unguarded cross-engine
    // ingress: an operand that is, or transitively contains, an object from
    // another engine would be adopted into this engine's expression with its
    // typing and invalidation still wired to the other one. (Invariant 8 of
    // `docs/TYPE-SYSTEM.md`,
    // "Cross-engine ingress".) The check is one boolean read until an object
    // has been constructed somewhere in the process.
    if (adoptsForeignEngineObject(ops, this))
      return this.error('object-foreign-engine');

    return new BoxedFunction(this, name, ops, { ...options, canonical });
  }

  /**
   * Construct an object of the nominal type `typeName`. See
   * {@link IComputeEngine._object} — this is the only path that mints one.
   * @internal
   */
  _object(
    typeName: string,
    slots: Iterable<readonly [string, Expression]> | Record<string, Expression>,
    metadata?: Metadata,
    pinnedType?: BoxedType
  ): Expression {
    return makeObject(this, typeName, slots, metadata, pinnedType);
  }

  /**
   * Return the assumption bindings that match a pattern.
   *
   * The `pattern` typically contains wildcards (symbols starting with `_`).
   * Each returned substitution maps every wildcard to the value it captured
   * from a matching assumption. A wildcard bound query (`Greater(x, _k)`)
   * resolves against the derived bounds for the subject:
   *
   * ```js
   *  ce.assume(['Greater', 'x', 4]);
   *  ce.ask(['Greater', 'x', '_val']);
   *  //  -> [{ _val: 4 }]
   * ```
   *
   * A **closed** (wildcard-free) pattern degrades to an existence check: the
   * result is a single empty substitution `[{}]` when the predicate is known
   * to hold, or `[]` otherwise — so `ce.ask(P).length > 0` answers "is `P`
   * known?". For a definite `true`/`false`/`undefined` answer use
   * {@link verify} instead.
   *
   * @see verify
   */
  ask(pattern: Expression): BoxedSubstitution[] {
    return askImpl(this, pattern);
  }

  /**
   * Check whether a predicate is entailed by the current assumptions.
   *
   * Three-valued (Kleene): returns `true` when the predicate is provable,
   * `false` when its negation is provable, and `undefined` when neither can be
   * decided. `And`/`Or`/`Not` are combined three-valued.
   *
   * The `query` may be an `Expression`, a MathJSON expression, or a
   * **string** parsed as LaTeX (`'x > 0'`, `'$x > 0$'`, or `'\\pi > 0'`); an
   * unparseable string throws.
   *
   * ```js
   *  ce.assume(['Greater', 'x', 0]);
   *  ce.verify('x > 0');   // -> true
   *  ce.verify('x < 0');   // -> false
   *  ce.verify('x > 5');   // -> undefined
   * ```
   *
   * @see ask
   */
  verify(query: Expression | string): boolean | undefined {
    return verifyImpl(this, query);
  }

  /**
   * Add an assumption.
   *
   * Note that the assumption is put into canonical form before being added.
   *
   * Returns:
   * - `contradiction` if the new assumption is incompatible with previous
   * ones.
   * - `tautology` if the new assumption is redundant with previous ones.
   * - `ok` if the assumption was successfully added to the assumption set.
   *
   *
   */
  assume(predicate: Expression | string): AssumeResult {
    return assumeFnImpl(this, predicate);
  }

  /**
   * Declare the names that `exprs` use, in their home scopes, with the types
   * that their uses require. See `IComputeEngine.infer()` for the contract.
   *
   * @experimental
   */
  infer(exprs: ReadonlyArray<Expression>): InferResult {
    return inferFn(this, exprs);
  }

  /**
   * Remove all assumptions about one or more symbols.
   *
   * `ce.forget()` will remove all assumptions.
   *
   * Note that assumptions are scoped, so when exiting the current lexical
   * scope, the previous assumptions will be restored.
   *
   * */
  forget(symbol: undefined | MathJsonSymbol | MathJsonSymbol[]): void {
    forgetImpl(this, symbol);
  }

  /**
   * Remove the binding of one or more names from the current scope: a value,
   * or a function defined by assignment or by clauses. An enclosing scope
   * is not changed, and a declaration of the name there applies again.
   *
   * Throws if a name is not declared in the current scope, is defined by a
   * library, or is the variable of an operator such as `Sum`.
   *
   * See `IComputeEngine.undeclare()` for the full contract.
   */
  undeclare(names: MathJsonSymbol | ReadonlyArray<MathJsonSymbol>): void {
    undeclareImpl(this, names);
  }
}

// The `ce.randomSeed` accessor tombstone (a throwing getter/setter installed
// on the prototype, off the TS surface) lived here for the one release
// promised by the Random redesign's §9 (0.95.0) and was deleted afterwards.
// A plain-JS assignment to `ce.randomSeed` is now an ordinary silent expando,
// like any other unknown property.

// Register a factory with the free-functions module so it can lazily
// instantiate a default engine without importing back from this file.
// Note: this factory does NOT inject LatexSyntax. The full entry point
// (compute-engine.ts) registers a factory that includes LatexSyntax.
_setDefaultEngineFactory(() => new ComputeEngine());
