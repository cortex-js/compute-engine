import type {
  BoxedValueDefinition,
  Expression,
  FunctionInterface,
  Scope,
} from '../global-types.js';
import type {
  EffectSet,
  FunctionSignature,
  NamedElement,
  ParameterDefault,
  Type,
  TypeReference,
} from '../../common/type/types.js';
import { parseType } from '../../common/type/parse.js';
import { freeTypeVariables } from '../../common/type/instantiate.js';
import {
  isGroupedTypeText,
  signatureEffects,
} from '../../common/type/utils.js';
import { isSubtype } from '../../common/type/subtype.js';
import type { BoxedType } from '../../common/type/boxed-type.js';
import { isFunction, isString, isSymbol, sym } from './type-guards.js';
import { tuplePatternNames } from './tuple-pattern.js';
import { literalParameterDefault } from './parameter-defaults.js';
import { registerDefinitionSideTable } from './definition-restore-point.js';

/**
 * Shared accessors for the shape of a `Function` literal so that no call site
 * has to pattern-match the `["Typed", …]` parameter/return annotations by hand.
 *
 * A `Function` literal has the canonical shape
 * `["Function", body, param₁, …, paramₙ]` where:
 * - each `paramᵢ` is a bare symbol (inferred type) or `["Typed", symbol, type]`
 *   (annotated parameter), possibly wrapped as `["Optional", param, default]`
 *   (a parameter with a default value, see `isOptionalParameter()`); a rest
 *   parameter `["Spread", symbol]` or a destructuring pattern `["Tuple", …]`;
 * - `body` is a scoped `Block`; a return-type ascription lives INSIDE that
 *   Block, wrapping the last statement as `["Typed", statement, type]`.
 *
 * These helpers are the single source of truth for reading that shape.
 */

/**
 * The resolution of a `Typed` type operand, keyed by the operand NODE.
 *
 * A type operand is stored as TEXT (`["Typed", "x", "'pt'"]`), and every read
 * of the parameter types of a literal parses that text again. Type names are
 * not lexically scoped: `ce._typeResolver` reads the type registry of the
 * engine (`ce._typeRegistry`), and the end of the scope that declared a type
 * does not remove its name. A name leaves the registry only when a rollback
 * of the registry (`ce._typeRegistryRollbackPoint()`) undoes its
 * registration: the Epsil static pre-pass (`static-diagnostics.ts`), which
 * registers the `type` statements of a program and then discards them; a
 * sum-type declaration that fails after some of its variants registered
 * (`engine-declarations.ts`). A literal that
 * was boxed while the name was registered can be read after such a rollback.
 * The parse then throws `Unknown type`, the annotation reads as absent with no
 * message, and the check of the argument types stops.
 *
 * Same hazard, same fix as the operator-definition signature
 * (`boxed-operator-definition.ts`, "assembled as a Type OBJECT, never as a
 * string that is re-parsed"): `typeToString` discards the resolution, so carry
 * the resolved `Type` — a `TypeReference` carries its own `def` and stays
 * usable wherever it escapes to. Here the text is what the expression stores,
 * so the resolution is remembered against the operand node instead, recorded
 * the first time the name resolves. `canonicalFunctionLiteralArguments` forces
 * that first resolution (`resolveFunctionLiteralTypes`) when the literal is
 * boxed, while the name is registered, rather than leaving it to whichever
 * consumer reads the literal first.
 */
const RESOLVED_TYPE_OPERANDS = new WeakMap<Expression, Type>();

/** Parse a `Typed` type operand (a string literal or a type-name symbol) into
 * a {@link Type}, returning `undefined` if it cannot be parsed. */
function parseTypeOperand(t: Expression | undefined): Type | undefined {
  if (!t) return undefined;
  const s = isString(t) ? t.string : sym(t);
  if (s === undefined) return undefined;
  try {
    return parseType(s);
  } catch {
    // The annotation may name a user-declared type (`ce.declareType()`),
    // which only the engine's resolver can read. Tried second, so the
    // resolver-less (memo-cached) parse still carries the common case.
    try {
      const resolved = parseType(s, t.engine._typeResolver);
      RESOLVED_TYPE_OPERANDS.set(t, resolved);
      return resolved;
    } catch {
      // A rollback of the type registry removed the name: use the
      // resolution recorded while the name was registered (see
      // `RESOLVED_TYPE_OPERANDS`).
      return RESOLVED_TYPE_OPERANDS.get(t);
    }
  }
}

/**
 * Force the resolution of a canonical `Function` literal's type operands while
 * the scope that declares those type names is still current.
 *
 * Called once, at the end of `canonicalFunctionLiteralArguments`: the literal
 * may escape that scope, and after it does the operand text no longer resolves
 * (see {@link RESOLVED_TYPE_OPERANDS}). The reads are pure; they are made for
 * the resolution they record.
 */
export function resolveFunctionLiteralTypes(expr: Expression): void {
  functionLiteralParameters(expr);
  functionLiteralReturnType(expr);
}

/**
 * True when a `Function` parameter operand is a REST parameter — the
 * `["Spread", symbol]` node spelled `...rest` in Epsil.
 *
 * A rest parameter may only be the LAST operand of the parameter list. It
 * consumes every argument from its own position onwards and binds ONE name to
 * a `Tuple` of them, empty when the call supplies no trailing argument.
 * `canonicalFunctionLiteralArguments` rejects any other placement, a
 * `["Spread", …]` holding something other than a single symbol, and a `Typed`
 * annotation wrapped around one.
 */
export function isRestParameter(param: Expression): boolean {
  return isFunction(param, 'Spread');
}

/**
 * True when a `Function` parameter operand is a parameter with a DEFAULT
 * VALUE: `["Optional", param, default]`, spelled `(x, k = 2) => …` in Epsil.
 * `param` is a symbol or `["Typed", symbol, type]`; `default` is a number, a
 * string, `True`, `False`, a symbol, `["List"]` or `["Dictionary"]`.
 *
 * A call that supplies every parameter before the first such parameter is a
 * full call: each parameter with a default that the call leaves out receives
 * its default. The parameters with a default come after the required ones,
 * and a rest or destructuring parameter cannot have one
 * (`canonicalFunctionLiteralArguments()` checks both).
 */
export function isOptionalParameter(param: Expression): boolean {
  return isFunction(param, 'Optional');
}

/** The parameter inside an `Optional` wrapper (a symbol or a `Typed`
 * annotation), or `param` itself when it has no default. Every reader of a
 * parameter's name, type or binding site reads this operand. */
export function optionalParameterTarget(param: Expression): Expression {
  return isFunction(param, 'Optional') && param.op1 !== undefined
    ? param.op1
    : param;
}

/** The default operand of a parameter `["Optional", param, default]`, or
 * `undefined` for a parameter without a default. In a canonical literal the
 * operand is canonical. */
export function optionalParameterDefault(
  param: Expression
): Expression | undefined {
  return isFunction(param, 'Optional') ? param.op2 : undefined;
}

/** The number of parameters that a call of a literal with the parameters
 * `params` must supply: the parameters before the first parameter with a
 * default, or before the rest parameter. A call with at least this many
 * arguments is a full call; a call with fewer is a partial application. */
export function requiredParameterCount(
  params: ReadonlyArray<Expression>
): number {
  const i = params.findIndex(
    (p) => isOptionalParameter(p) || isRestParameter(p)
  );
  return i < 0 ? params.length : i;
}

/**
 * The index of the REST parameter within a `Function` literal's parameter
 * list, or `-1` when the list has none.
 *
 * Canonicalization admits at most one rest parameter and only in the last
 * position, so this index is also the number of FIXED parameters an
 * application must supply before the rest parameter takes over.
 */
export function restParameterIndex(params: ReadonlyArray<Expression>): number {
  return params.findIndex((p) => isRestParameter(p));
}

/**
 * The variadic tail a rest parameter contributes to a `Function` literal's
 * arrow, ready to be spread into a signature object. An empty object when the
 * parameter list has no rest parameter.
 *
 * The element type is `any` — the widest contract, absence markers included —
 * because a rest parameter carries no annotation of its own (a `Typed` wrapper
 * around one is rejected at canonicalization), so the call may pass anything.
 * `variadicMin` is `0` because the tail may be empty: the application then
 * binds the empty tuple.
 *
 * EVERY derivation of a literal's arrow must spread this in. A derivation that
 * does not counts the rest parameter as one ordinary positional slot, and the
 * arrow then claims a fixed arity the function does not have — which is what
 * made an assigned `(a, ...rest) => …` report `(unknown, unknown) -> integer`.
 */
export function restParameterSignatureTail(params: ReadonlyArray<Expression>): {
  variadicArg?: NamedElement;
  variadicMin?: 0;
} {
  return restParameterIndex(params) < 0
    ? {}
    : { variadicArg: { type: 'any' }, variadicMin: 0 };
}

/**
 * The call arities a `Function` literal accepts: the number of FIXED
 * parameters it requires, and whether a rest parameter leaves the tail
 * unbounded.
 *
 * `(a, b) => …` is `{ fixed: 2, variadic: false }` — it accepts exactly two
 * arguments. `(a, ...rest) => …` is `{ fixed: 1, variadic: true }` — one
 * argument or more. This is the reading every arity check owes a literal;
 * counting the parameter OPERANDS answers `2` for both.
 */
export function functionLiteralArity(expr: Expression): {
  fixed: number;
  variadic: boolean;
  required: number;
} {
  const params = isFunction(expr, 'Function') ? expr.ops.slice(1) : [];
  const rest = restParameterIndex(params);
  // `required` is less than `fixed` when parameters have a default value:
  // `(x, k = 2) => …` accepts one or two arguments.
  const required = requiredParameterCount(params);
  return rest < 0
    ? { fixed: params.length, variadic: false, required }
    : { fixed: rest, variadic: true, required };
}

/** The symbol NODE a rest parameter binds — the operand inside its `Spread`
 * wrapper — or `undefined` when `param` is not a rest parameter. Consumers
 * that must reach the parameter's own binding (the site a call frame
 * activates, the path a binding-site selector reports) read this node, never
 * the `Spread` wrapper. */
export function restParameterSymbol(param: Expression): Expression | undefined {
  return isFunction(param, 'Spread') ? param.op1 : undefined;
}

/** The name of a single `Function` parameter operand, unwrapping a `Typed`
 * annotation or a rest parameter's `Spread` wrapper. Returns `''` when the
 * operand is not a symbol (matching the historical
 * `isSymbol(p) ? p.symbol : ''` idiom). */
export function functionLiteralParameterName(param: Expression): string {
  param = optionalParameterTarget(param);
  if (isFunction(param, 'Typed')) return sym(param.op1) ?? '';
  if (isFunction(param, 'Spread')) return sym(param.op1) ?? '';
  return sym(param) ?? '';
}

/** The name that an INFERRED signature gives to the slot of a parameter with
 * no annotation, or `undefined` when the slot has no name.
 *
 * An inferred signature keeps the parameter names of the literal, so a named
 * call can find each slot: with `f := (a, b) => a - b`, the call
 * `f(b: 2, a: 10)` gives 8, and the arrow prints `(a: unknown, b: unknown) ->
 * number`. A slot has no name when the operand is not a symbol (a
 * destructuring pattern), and when the name is a wildcard (`_`, `_1`, `_2`):
 * a wildcard parameter is positional, and its name is not one that a caller
 * writes. The names do not change how two signatures compare: matching and
 * subtyping read only the slot types. */
export function inferredSignatureParameterName(
  param: Expression
): string | undefined {
  const name = sym(optionalParameterTarget(param));
  if (name === undefined || name === '' || /^_\d*$/.test(name))
    return undefined;
  return name;
}

/**
 * True when a `Function` parameter operand is a DESTRUCTURING PATTERN — a raw
 * `["Tuple", …]` node — rather than a plain (possibly annotated) name.
 *
 * Such a parameter still counts as ONE parameter: it consumes one argument,
 * which must be a tuple of the pattern's arity, and binds the pattern's leaf
 * names to that tuple's components. Epsil spells it with a second pair of
 * parentheses — `((p, q)) => p && q` is unary, `(p, q) => p && q` is binary.
 *
 * The pattern operand is kept RAW (never canonicalized), for the same reason
 * the `Declare`/`Assign` destructuring targets are: canonicalizing a
 * single-letter leaf would fold it into the library constant of that name
 * (`i` → `ImaginaryUnit`).
 */
export function isDestructuringParameter(param: Expression): boolean {
  return isFunction(param, 'Tuple');
}

/**
 * Every name a single `Function` parameter operand BINDS, in pattern order.
 *
 * One name for a plain or `Typed` parameter (empty when the operand is not a
 * symbol at all); for a destructuring pattern, the pattern's leaf names with
 * `_` positions — which bind nothing — dropped, nested patterns included.
 *
 * This is what every walker that asks "which names does this lambda bind?"
 * must use; {@link functionLiteralParameterName} answers only for the
 * single-name shapes and returns `''` for a pattern.
 */
export function functionLiteralParameterNames(param: Expression): string[] {
  if (isDestructuringParameter(param)) return tuplePatternNames(param);
  const name = functionLiteralParameterName(param);
  return name ? [name] : [];
}

/**
 * The mark of a value definition of a parameter of a canonical function
 * literal, a field of the definition. A parameter binding is marked when it
 * is created while the body is canonicalized (`_setShadowedParameterDef()`
 * in `index.ts`), so that a nested literal whose type is computed before the
 * enclosing literal is complete sees it. `canonicalFunctionLiteralArguments()`
 * (`function-utils.ts`) marks the other parameter bindings when it declares
 * the parameters.
 *
 * A reader uses it to know that a call is a call of a parameter, also when
 * the parameter has no type and no value yet, and also from a nested
 * literal that captures the parameter. The scope of the body cannot answer
 * this: an inferred binding with no value there may be an auto-declared
 * local. The reader that needs
 * it is the reading of a call named `Return`: a call of a parameter named
 * `Return` is not the `Return` statement (`hasEscapingReturn()` in
 * `library/utils.ts`, `earlyReturnTypes()` in `effects-inference.ts`).
 *
 * A binding that existed before the literal can become a parameter binding
 * (the body was canonical before the literal was made, and its scope already
 * held the name).
 */
type FunctionLiteralParameter = { _functionLiteralParameter?: true };

/** Record `def` as the value definition of a function-literal parameter
 * (`FunctionLiteralParameter`). `ce` is the engine of the literal. */
export function markFunctionLiteralParameter(
  ce: Expression['engine'],
  def: object
): void {
  (def as FunctionLiteralParameter)._functionLiteralParameter = true;
}

/** True when `def` is the value definition of a parameter of a canonical
 * function literal (`FunctionLiteralParameter`). */
export function isFunctionLiteralParameter(def: object | undefined): boolean {
  return (
    (def as FunctionLiteralParameter | undefined)?._functionLiteralParameter ===
    true
  );
}

/**
 * The symbol occurrences of the bodies of canonical function literals that
 * read a symbol from outside the literal (`y` in `t ↦ g(y)`): the symbol is
 * not a parameter of the literal or of a nested literal, not the variable of
 * a binder of the body (a `Sum` index), and not a local of a block of the
 * body (a `let` local). The definition of the symbol
 * can be in any scope: a binding that the canonicalization of the body
 * declared in a scope of the body, or the binding of an outer scope that
 * existed before the literal. When the body is evaluated, the occurrence
 * reads the value that the symbol has at that time.
 *
 * So, when the signature of the literal is inferred, the type of such a
 * symbol is not the type of the value that a later call reads. A call of a
 * function literal over such an occurrence of type `unknown` may get a
 * list, a tuple or a nested list, and its type must admit the result
 * (`isUnknownCapturedSymbol()` in `boxed-function.ts`).
 *
 * The record is for the occurrence (each occurrence of a symbol is its own
 * expression), not for the definition: the same symbol outside every
 * literal (`g(y)` at the top level) is typed again when the symbol gets a
 * value, and it keeps the scalar reading.
 */
const FUNCTION_LITERAL_CAPTURES = new WeakSet<Expression>();

/**
 * Record the occurrences of `body`, the body of a canonical function
 * literal, that read a symbol from outside the literal
 * (`FUNCTION_LITERAL_CAPTURES`). The walk goes into every nested
 * expression, nested blocks included (a branch of an `If`). The bindings of
 * a scoped expression that is not a block (the variable of a `Sum`, the
 * parameters of a nested literal) and the locals of each block are not
 * recorded.
 */
export function markFunctionLiteralCaptures(body: Expression): void {
  const bound = new Set<object>();
  const seen = new Set<Expression>();
  const occurrences: Expression[] = [];
  const visit = (e: Expression): void => {
    if (seen.has(e)) return;
    seen.add(e);
    if (isSymbol(e)) {
      occurrences.push(e);
      return;
    }
    if (!isFunction(e) || e._numericStore !== undefined) return;
    const scope = e.isScoped ? e.localScope : undefined;
    // The bindings of a block are not bound here: a local of a block is
    // read in the activation of its run.
    if (scope !== undefined && e.operator !== 'Block')
      for (const b of scope.bindings.values())
        if ('value' in b) bound.add(b.value);
    for (const op of e.ops) visit(op);
  };
  visit(body);
  for (const op of occurrences) {
    const def = op.valueDefinition;
    if (def !== undefined) {
      if (def.isConstant || (def._blockLocal === true && !def._programVariable)) continue;
      if (isFunctionLiteralParameter(def) || bound.has(def)) continue;
    } else if (op.operatorDefinition !== undefined) continue;
    FUNCTION_LITERAL_CAPTURES.add(op);
  }
}

/** True when `op` is an occurrence of the body of a canonical function
 * literal that reads a symbol from outside the literal
 * (`FUNCTION_LITERAL_CAPTURES`). */
export function isFunctionLiteralCapture(op: Expression): boolean {
  return FUNCTION_LITERAL_CAPTURES.has(op);
}

/**
 * The type a destructuring parameter's argument must have: a tuple whose
 * arity is the pattern's, with a nested tuple type at each nested pattern
 * position and `unknown` everywhere else.
 *
 * Surfacing this on the literal's arrow (rather than the `unknown` a bare
 * parameter gets) is what states the arity the application will enforce, and
 * what keeps the parameter from reading as a SCALAR slot — a scalar slot
 * invites the collection-argument broadcast, which would map the lambda over
 * the tuple's components instead of binding the tuple whole.
 *
 * The COMPONENT types stay `unknown`: a pattern position carries no
 * annotation of its own (per-element annotations are rejected at parse), and
 * the per-application element-type inference declines to stamp a pattern
 * parameter (`annotateFunctionLiteralParams` rewrites bare SYMBOL parameters
 * only).
 */
export function destructuringParameterType(param: Expression): Type {
  if (!isFunction(param, 'Tuple')) return 'unknown';
  const elements = param.ops.map((el) =>
    isFunction(el, 'Tuple')
      ? { type: destructuringParameterType(el) }
      : { type: 'unknown' as Type }
  );
  return { kind: 'tuple', elements };
}

/** Every name the parameter list of a `Function` literal binds, in order. */
export function functionLiteralBoundNames(
  params: ReadonlyArray<Expression>
): string[] {
  const names: string[] = [];
  for (const p of params) names.push(...functionLiteralParameterNames(p));
  return names;
}

/** The declared type of a single `Function` parameter operand, or `undefined`
 * for a bare (unannotated) parameter. */
export function functionLiteralParameterType(
  param: Expression
): Type | undefined {
  param = optionalParameterTarget(param);
  if (isFunction(param, 'Typed')) return parseTypeOperand(param.op2);
  return undefined;
}

/**
 * The DECLARED type carried by the function-literal parameter operand `p`
 * (`Typed(x, "complex")`, the MathJSON form of a type annotation on a
 * parameter), or `undefined` when `p` carries no annotation or the
 * annotation does not parse. An unannotated or unparseable parameter
 * therefore reads as undeclared, the safe direction.
 *
 * It reads one parameter, so that the callers that read the parameters by
 * position (the value-position coercion of an inline literal, in
 * `compilation/compile-callbacks.ts`) and `literalDeclaredParamTypes()` in
 * the same module, which reads them by name, agree on the declared type of
 * a parameter.
 *
 * This is the reading the compiler uses to put a parameter of a literal in
 * the `{ re, im }` complex lane (`compilation/compile-function-literals.ts`),
 * so a caller that must agree with that decision reads the parameter with
 * this function (`complexLaneParameters()` in `library/map-auto-compile.ts`).
 * Unlike {@link functionLiteralParameterType}, it keeps no memo of a
 * resolved type operand.
 */
export function declaredParamType(p: Expression): Type | undefined {
  // A parameter with a default value, `["Optional", param, default]`, has
  // the declared type of the parameter it wraps.
  p = optionalParameterTarget(p);
  if (!isFunction(p, 'Typed') || !isSymbol(p.ops[0])) return undefined;
  const src = p.ops[1];
  const text = isString(src)
    ? src.string
    : isSymbol(src)
      ? src.symbol
      : undefined;
  if (text === undefined) return undefined;
  try {
    return parseType(text, p.engine._typeResolver);
  } catch {
    // Unparseable annotation: read as undeclared.
    return undefined;
  }
}

/** True for the wide types `any`, `expression` and `value`. Each of them
 * admits a collection, and a parameter DECLARED with one of them receives
 * a collection argument whole (see {@link isScalarType}). `unknown` is not
 * one of them: it is the type of a parameter with no declaration.
 *
 * A transparent alias is unfolded first, as {@link isScalarType} unfolds it:
 * with `type alias A = expression`, `A` is a wide type. A nominal reference
 * stays opaque, and is not a wide type.
 * @internal
 */
export function isWideParameterType(
  t: Type,
  seen?: Set<TypeReference>
): boolean {
  if (typeof t === 'string')
    return t === 'any' || t === 'expression' || t === 'value';
  if (t.kind !== 'reference' || t.alias !== true || t.def === undefined)
    return false;
  // Cycle guard, as in `isScalarType`: a pure reference cycle is not a wide
  // type.
  if (seen === undefined) seen = new Set();
  else if (seen.has(t)) return false;
  seen.add(t);
  try {
    return isWideParameterType(t.def, seen);
  } finally {
    seen.delete(t);
  }
}

/** True for `unknown`, the type of a parameter with no declaration, and for
 * a transparent alias of it (`type alias U = unknown`). The alias is unfolded
 * as {@link isWideParameterType} unfolds it; a nominal reference stays
 * opaque.
 * @internal
 */
export function isUnknownParameterType(
  t: Type,
  seen?: Set<TypeReference>
): boolean {
  if (typeof t === 'string') return t === 'unknown';
  if (t.kind !== 'reference' || t.alias !== true || t.def === undefined)
    return false;
  // Cycle guard, as in `isWideParameterType`.
  if (seen === undefined) seen = new Set();
  else if (seen.has(t)) return false;
  seen.add(t);
  try {
    return isUnknownParameterType(t.def, seen);
  } finally {
    seen.delete(t);
  }
}

/** True for a function-literal parameter `["Typed", symbol, T]` where `T` is
 * `unknown` or a transparent alias of it ({@link isUnknownParameterType}).
 * Such a parameter is the same as the bare `symbol` (user decision
 * 2026-10-30, recorded with GitHub issue #488): each step that reads the
 * parameters of a literal, raw or canonical, reads it as the bare symbol.
 * @internal
 */
export function isUnknownTypedParameter(
  param: Expression
): param is Expression & FunctionInterface {
  if (!isFunction(param, 'Typed') || !isSymbol(param.op1)) return false;
  const t = parseTypeOperand(param.op2);
  return t !== undefined && isUnknownParameterType(t);
}

/** A type is "scalar" for broadcasting purposes if a function whose
 * parameter has this type is mapped over the elements of a collection
 * argument at that parameter, instead of receiving the collection whole.
 *
 * A known collection-like type is not scalar. The wide types `any`,
 * `expression` and `value` are not scalar either: a parameter declared with
 * one of them accepts a collection, so it receives the collection whole
 * (user decision 2026-10-30, GitHub issue #488). With
 * `f := (t: any) ↦ (0 if t ∈ ℤ else 1)`, `f([[0, 0], 5])` is `1`, not
 * `[[0, 0], 0]`.
 *
 * `unknown`, the type of a parameter with no declaration, stays scalar, so
 * an untyped parameter is mapped: with `g := t ↦ (0 if t ∈ ℤ else 1)`,
 * `g([[0, 0], 5])` is `[[0, 0], 0]` (user decision 2026-10-15,
 * `docs/BROADCAST-MODEL.md`). An explicit `unknown` declaration is read as
 * no declaration, and other types that are not collection-like (`number`,
 * `integer`, `boolean`, …) are scalar.
 * @internal
 */
export function isScalarType(t: Type, seen?: Set<TypeReference>): boolean {
  if (typeof t === 'string') {
    if (isWideParameterType(t)) return false;
    // String types like 'collection', 'list', 'tuple', 'set' are non-scalar.
    if (
      t === 'collection' ||
      t === 'indexed_collection' ||
      t === 'list' ||
      t === 'tuple' ||
      t === 'set' ||
      t === 'dictionary' ||
      t === 'record' ||
      t === 'function'
    )
      return false;
    return true;
  }
  if (
    t.kind === 'collection' ||
    t.kind === 'indexed_collection' ||
    t.kind === 'list' ||
    t.kind === 'tuple' ||
    t.kind === 'set' ||
    t.kind === 'dictionary' ||
    t.kind === 'record' ||
    t.kind === 'signature' ||
    // A `broadcastable<T>` parameter accepts a collection whole (it handles
    // collections natively), so it is NOT a scalar — a lambda with such a
    // parameter must not be mapped/broadcast over a collection argument.
    t.kind === 'broadcastable'
  )
    return false;
  if (t.kind === 'union' || t.kind === 'intersection')
    return t.types.every((x) => isScalarType(x, seen));
  if (t.kind === 'negation') return isScalarType(t.type, seen);
  // A STRUCTURAL alias IS its definition, so an alias of a collection type is
  // NOT scalar — the same unfold rule `isSubtype` applies. Without it,
  // `type alias u = list<number>` read as scalar and a `(u) -> …` function
  // BROADCAST over its list argument instead of binding it whole (each element
  // then failing the parameter check), while the inline `(list<number>) -> …`
  // spelling bound correctly.
  //
  // A NOMINAL reference stays opaque, and opaque means scalar: its values are
  // tagged applications, never collections, so a list of them is a genuine
  // broadcast (`norm([p1, p2])` maps a `(point) -> …` over the list).
  if (t.kind === 'reference') {
    if (t.alias !== true || t.def === undefined) return true;
    // Cycle guard (mirrors `beginUnfold` in `common/type/subtype.ts`). A pure
    // reference cycle passes through no collection constructor, so cutting the
    // back edge as "scalar" agrees with the conservative default below.
    if (seen === undefined) seen = new Set();
    else if (seen.has(t)) return true;
    seen.add(t);
    try {
      return isScalarType(t.def, seen);
    } finally {
      seen.delete(t);
    }
  }
  return true;
}

/** The parameters of a `Function` literal, as `{ name, type }` records. Bare
 * parameters have `type: undefined`. A parameter with a default value
 * (`["Optional", k, 2]`) also has `optional: true` and its `default`. */
export function functionLiteralParameters(expr: Expression): {
  name: string;
  type: Type | undefined;
  optional?: boolean;
  default?: ParameterDefault;
}[] {
  if (!isFunction(expr, 'Function')) return [];
  return expr.ops.slice(1).map((p) => {
    const entry = {
      name: functionLiteralParameterName(p),
      type: functionLiteralParameterType(p),
    };
    const op = optionalParameterDefault(p);
    if (op === undefined) return entry;
    const d = literalParameterDefault(op);
    return d === undefined
      ? { ...entry, optional: true }
      : { ...entry, optional: true, default: d };
  });
}

/**
 * The argument lists of the signature of a `Function` literal whose
 * parameter operands are `params`, given `slots`, the signature slots of its
 * FIXED parameters (the parameters before a rest parameter), in order.
 *
 * A required parameter's slot goes into `args`. The slot of a parameter with
 * a default value (`["Optional", k, 2]`) goes into `optArgs`, with that
 * default: `(x, k = 2) => x * k` has the signature
 * `(x: unknown, k: unknown = 2) -> number`. The default does not change the
 * slot type, which is the annotation or the type that the body's uses infer,
 * as for a parameter without a default. Canonicalization puts the parameters
 * with a default after the required ones and checks that each default is a
 * value that a signature can hold (`literalParameterDefault()`).
 */
export function signatureArgumentsOfSlots(
  params: ReadonlyArray<Expression>,
  slots: ReadonlyArray<NamedElement> | undefined
): { args?: NamedElement[]; optArgs?: NamedElement[] } {
  if (slots === undefined || slots.length === 0) return {};
  const required = requiredParameterCount(params);
  if (required >= slots.length) return { args: [...slots] };
  const optArgs = slots.slice(required).map((slot, i) => {
    const op = optionalParameterDefault(params[required + i]);
    const d = op === undefined ? undefined : literalParameterDefault(op);
    return d === undefined ? slot : { ...slot, default: d };
  });
  return {
    ...(required > 0 ? { args: slots.slice(0, required) } : {}),
    optArgs,
  };
}

/** The return-ascription MARKER node of a `Function` literal — the §4.2
 * `Typed` wrapping the body Block's last statement, or, in the not-yet
 * normalized authoring form `["Typed", body, type]`, the body slot itself.
 * `undefined` when the literal carries no ascription. */
export function functionLiteralReturnMarker(
  expr: Expression
): (Expression & FunctionInterface) | undefined {
  if (!isFunction(expr, 'Function')) return undefined;
  const body = expr.ops[0];
  if (!body) return undefined;
  // Canonical body is a scoped Block; the marker wraps its last statement.
  if (isFunction(body, 'Block')) {
    const last = body.ops[body.nops - 1];
    return isFunction(last, 'Typed') ? last : undefined;
  }
  // Authoring form (not yet normalized): `["Typed", body, type]`.
  return isFunction(body, 'Typed') ? body : undefined;
}

/**
 * The FULL SIGNATURE a return marker declares (`docs/EFFECTS-MODEL.md`,
 * "Epsil surface"), or `undefined` when the marker is an ordinary
 * return-type ascription.
 *
 * **Decomposition predicate**: the marker's type operand decomposes as a full
 * signature iff its TEXT is ungrouped and parses to a signature — effects and
 * `where` clause optional. An author who spells an arrow in the return slot
 * plainly means the literal's contract; the GROUPED spelling (below) is the
 * explicit opt-out for the "returns a function" reading, so a ground arrow
 * needs no second discriminator (ruled 2026-08-04). Before that ruling only an
 * effect-bearing or quantified signature decomposed, and `["Typed", body,
 * "(x: number) -> number"]` typed as `(unknown) -> (x: number) -> number` —
 * the marker author's contract read as a returned function.
 *
 * The literal's parameter operands remain the parameters of record. The marker
 * signature's argument list is a MIRROR built by the Epsil lowering (and by
 * `desugarSignatureString`) and is never read for parameter types.
 */
export function functionLiteralDeclaredSignature(
  expr: Expression
): FunctionSignature | undefined {
  const marker = functionLiteralReturnMarker(expr);
  if (marker === undefined) return undefined;
  // A fully parenthesized spelling is a GROUPED type (ruled 2026-08-01): the
  // author's disambiguation that this is a RETURN type — possibly an
  // effect-bearing arrow — never the literal's own contract. Grouping does
  // not survive parsing, so the test is on the marker's text.
  const op = marker.op2;
  const text =
    op === undefined ? undefined : isString(op) ? op.string : sym(op);
  if (text !== undefined && isGroupedTypeText(text)) return undefined;
  const t = parseTypeOperand(marker.op2);
  if (t === undefined || typeof t === 'string' || t.kind !== 'signature')
    return undefined;
  return t;
}

/**
 * True when `t` — a component of `sig` (an argument type or the result) —
 * mentions one of the variables `sig`'s `where` clause quantifies.
 *
 * Read on the COMPONENT, not on the whole signature: the clause-carrying
 * signature is CLOSED, so `freeTypeVariables` of it is empty by construction.
 * A component looked at on its own has those same occurrences FREE, so the
 * question is whether any of them is a name the clause declares.
 */
export function mentionsQuantifiedVariable(
  t: Type,
  sig: FunctionSignature
): boolean {
  const params = sig.typeParams;
  if (params === undefined || params.length === 0) return false;
  const free = freeTypeVariables(t);
  if (free.size === 0) return false;
  return params.some((p) => free.has(p.name));
}

/** The arrow-level effects declared by a full-signature return marker, or
 * `undefined` when the literal has no declared signature. A STATED empty set
 * (`pure`) is preserved as `[]`: discriminate with `!== undefined`, never by
 * truthiness or length. */
export function functionLiteralDeclaredEffects(
  expr: Expression
): EffectSet | undefined {
  return signatureEffects(functionLiteralDeclaredSignature(expr));
}

/** The ascribed return type of a `Function` literal (the §4.2 marker: a
 * `Typed` wrapping the body Block's last statement), or `undefined` when the
 * return type is left to inference.
 *
 * When the marker holds a full signature, the declared return type is that
 * signature's RESULT — except under the wide-result convention (mirroring
 * `desugarSignatureString`'s `isWide`): a result of `unknown`/`any` declares
 * no return type at all, so the return stays inferred from the body and only
 * the effects are declared (`function tick() scope { … }`).
 *
 * A result that mentions a QUANTIFIED variable (`(T) -> T where T`) joins
 * that same wide-result convention and declares no return type: under erasure
 * there is nothing ground to ascribe, and call-site result types come from the
 * INSTANTIATED signature instead. An open type must never leave this accessor
 * — it would reach the §4.2 ground-invariant tripwires. */
export function functionLiteralReturnType(expr: Expression): Type | undefined {
  const declared = functionLiteralDeclaredSignature(expr);
  if (declared !== undefined) {
    const result = declared.result;
    if (mentionsQuantifiedVariable(result, declared)) return undefined;
    return result === 'unknown' || result === 'any' ? undefined : result;
  }
  const marker = functionLiteralReturnMarker(expr);
  return marker === undefined ? undefined : parseTypeOperand(marker.op2);
}

/** The body of a `Function` literal (the scoped `Block`, return-type marker
 * included). */
export function functionLiteralBody(expr: Expression): Expression | undefined {
  if (!isFunction(expr, 'Function')) return undefined;
  return expr.ops[0];
}

/** The anonymous-slot symbols of a shorthand function body: the bare `_`
 * and the positional `_1`…`_9`. */
export const ANONYMOUS_SLOT_NAMES: ReadonlySet<string> = new Set([
  '_',
  '_1',
  '_2',
  '_3',
  '_4',
  '_5',
  '_6',
  '_7',
  '_8',
  '_9',
]);

/**
 * The anonymous-slot names (`_`, `_1`…`_9`) that `expr` mentions as a
 * symbol or as an operator name and that no `Function` literal inside
 * `expr` binds. These are the slots that are FREE in `expr`.
 *
 * A `Function` node, including `expr` itself, is read as follows:
 * - A literal with NO parameter list (a single operand) is a shorthand
 *   literal. It takes its parameters from every slot its own body uses, so
 *   none of its slots is free outside it, and the walk does not enter it.
 *   For example, the body
 *   `["Add", "_1", [["Function", ["Multiply", "_1", "_2"]], 2, 3]]` mentions
 *   only `_1`, and the enclosing literal has one parameter, not two.
 * - A literal WITH a parameter list binds only the names it declares. The
 *   walk enters its body and ignores those names there. Any other slot in
 *   that body is free and refers to the enclosing literal: in
 *   `["Function", ["Apply", ["Function", ["Multiply", "_1", "x"], "x"], 2]]`
 *   the `_1` is the parameter of the outer literal.
 *
 * A `Pipe(value, stage)` node also binds slots: its stage takes its slots
 * from the piped value, so only `value` is walked. In
 * `["Add", "y", ["Pipe", "ys", ["Multiply", "_", 2]]]` the `_` is not free.
 *
 * Every reader that decides "which slots are the parameters of this
 * shorthand body" must use this walk, so that the reading when boxing
 * (`anonymousParameters`, `function-utils.ts`) agrees with the reading when
 * serializing (`serializePrettyJsonFunction`, `serialize.ts`), which drops a
 * parameter list only when boxing gives it back.
 */
export function freeAnonymousSlots(expr: Expression): Set<string> {
  const result = new Set<string>();
  // A node contributes the same slots each time it is reached with the same
  // bound names, so it is walked once for each set of bound names. A shared
  // subtree inside an explicit-parameter literal (a body that is a DAG,
  // `Add(d, d)` at each level) is then walked once, not once per path,
  // which was exponential in its depth. Each set of bound names is one
  // object, found by its key (the sorted names, as JSON), so that
  // `visited` can compare the sets by identity. `undefined` is the empty
  // set outside every literal.
  const visited = new Map<Expression, Set<ReadonlySet<string> | undefined>>();
  const boundSets = new Map<string, ReadonlySet<string>>();
  const pending: [Expression, ReadonlySet<string> | undefined][] = [
    [expr, undefined],
  ];
  while (pending.length > 0) {
    const [e, bound] = pending.pop()!;
    const s = sym(e);
    if (s !== undefined) {
      if (ANONYMOUS_SLOT_NAMES.has(s) && !bound?.has(s)) result.add(s);
      continue;
    }
    if (!isFunction(e)) continue;
    let contexts = visited.get(e);
    if (contexts === undefined) visited.set(e, (contexts = new Set()));
    if (contexts.has(bound)) continue;
    contexts.add(bound);
    const op = e.operator;
    if (op === 'Function') {
      if (e.nops < 2) continue;
      const names = new Set(bound);
      for (const n of functionLiteralBoundNames(e.ops.slice(1))) names.add(n);
      const key = JSON.stringify([...names].sort());
      let shared = boundSets.get(key);
      if (shared === undefined) boundSets.set(key, (shared = names));
      pending.push([e.ops[0], shared]);
      continue;
    }
    if (ANONYMOUS_SLOT_NAMES.has(op) && !bound?.has(op)) result.add(op);
    // The stage of a `Pipe` (its second operand) takes its slots from the
    // pipe: the `_` in `Pipe(ys, Multiply(_, 2))` is the piped value `ys`,
    // as in the Epsil parser, which makes such a stage a `Function` literal.
    // So only the value operand is walked.
    if (op === 'Pipe' && e.nops === 2) {
      pending.push([e.ops[0], bound]);
      continue;
    }
    // A store-backed list holds only numbers, which are never a slot, so it
    // is not walked (walking it would box every element).
    if ((e as { _numericStore?: unknown })._numericStore !== undefined)
      continue;
    for (const x of e.ops) pending.push([x, bound]);
  }
  return result;
}

/**
 * A captured symbol of a function literal: a name that the body reads from
 * the scope that the literal is defined in, with one occurrence of it in the
 * body. The type of the occurrence is the type that the body, and so the
 * type of the literal, was derived with.
 */
export type CapturedSymbol = { name: string; occurrence: Expression };

/** The captured symbols of each canonical function literal, see
 * `capturedSymbols()`. A canonical literal does not change, so its body is
 * walked one time. */
const CAPTURED_SYMBOLS = new WeakMap<object, readonly CapturedSymbol[]>();

/**
 * The symbols of the body of the canonical function literal `literal` that
 * a call reads from the scope the literal is defined in, one entry for each
 * name. An occurrence is captured when it is bound to a binding outside the
 * literal, or when it is a free name (the call reads the binding that the
 * name has then in the scope that the literal is written in). These are not
 * captured: a constant, a parameter of a function literal, a binding of a
 * nested scope of the body (the index of a `Sum`, a local of a nested
 * block), and a local of the body scope (a `let` local).
 *
 * The walk reads each node of the body one time, so a body that shares its
 * operands is not unfolded.
 */
export function capturedSymbols(
  literal: Expression
): readonly CapturedSymbol[] {
  const cached = CAPTURED_SYMBOLS.get(literal);
  if (cached !== undefined) return cached;
  const result: CapturedSymbol[] = [];
  if (!isFunction(literal, 'Function')) return result;
  const body = literal.ops[0];
  const bodyScope = body.isScoped ? body.localScope : undefined;
  const occurrences = new Map<string, Expression>();
  const nested = new Set<object>();
  const seen = new Set<Expression>();
  const visit = (e: Expression): void => {
    if (seen.has(e)) return;
    seen.add(e);
    if (isSymbol(e)) {
      if (!occurrences.has(e.symbol)) occurrences.set(e.symbol, e);
      return;
    }
    if (!isFunction(e) || e._numericStore !== undefined) return;
    if (e !== body && e.isScoped && e.localScope !== undefined)
      for (const b of e.localScope.bindings.values())
        if ('value' in b) nested.add(b.value);
    for (const op of e.ops) visit(op);
  };
  visit(body);
  for (const [name, occurrence] of occurrences) {
    const def = occurrence.valueDefinition;
    // A free name of the body: a call reads it in the scope that the
    // literal is written in.
    if (def === undefined) {
      if ((occurrence as { _isFreeName?: boolean })._isFreeName === true)
        result.push({ name, occurrence });
      continue;
    }
    if (def.isConstant || (def._blockLocal === true && !def._programVariable)) continue;
    if (isFunctionLiteralParameter(def) || nested.has(def)) continue;
    const own = bodyScope?.bindings.get(name);
    if (own !== undefined && 'value' in own && own.value === def) {
      // A binding of the body scope is captured only when it is the
      // valueless binding that the body scope declared for a call head with
      // no definition (`makeCanonicalFunctionCore()`).
      if (!def.inferredType || def.value !== undefined) continue;
    }
    result.push({ name, occurrence });
  }
  CAPTURED_SYMBOLS.set(literal, result);
  return result;
}

/** The binding that a call of `literal` reads for the captured symbol
 * `name`: the binding of the name in the scope that encloses the body of
 * the literal, or `undefined` when there is none. */
function outerBindingOf(
  literal: Expression,
  name: string
): BoxedValueDefinition | undefined {
  const body = isFunction(literal, 'Function') ? literal.ops[0] : undefined;
  const bodyScope = body?.isScoped ? body.localScope : undefined;
  for (let s: Scope | null | undefined = bodyScope?.parent; s; s = s.parent) {
    const b = s.bindings.get(name);
    if (b === undefined) continue;
    return 'value' in b ? b.value : undefined;
  }
  return undefined;
}

/** A binding that a call of a function literal reads for a captured symbol,
 * with its type when the type of the definition was inferred. A free name
 * of the body has no definition: the entry then has no `binding`, and the binding is found by name from `literal` when the entry
 * is read (`capturedTypeWidenings()`). */
type CapturedTypeEntry = readonly [
  binding: BoxedValueDefinition | undefined,
  type: BoxedType,
  name: string,
  literal?: Expression,
];

/** For each definition made from a function literal, the type of each
 * binding that a call of the literal reads for a captured symbol, when the
 * type of the definition was inferred (`noteDefinitionCapturedTypes()`). */
const DEFINITION_CAPTURED_TYPES = new WeakMap<
  object,
  ReadonlyArray<CapturedTypeEntry>
>();
registerDefinitionSideTable(DEFINITION_CAPTURED_TYPES);

/**
 * Record, for the definition `def` whose type the engine infers from the
 * function literal `literal` now, the type of each binding that a call of
 * the literal reads for a captured symbol (`capturedSymbols()`): the
 * binding of the occurrence, or, for a copy that the body scope declared,
 * the outer binding of the name. A later change of one of these types is
 * what makes the inferred type of `def` outdated (`capturedTypesWidened()`).
 */
export function noteDefinitionCapturedTypes(
  def: object,
  literal: Expression
): void {
  if (!isFunction(literal, 'Function')) return;
  const bindings: Array<CapturedTypeEntry> = [];
  // Computed once for this record, from the types of now.
  let cells: Set<object | string> | undefined;
  for (const entry of capturedSymbols(literal)) {
    const own = entry.occurrence.valueDefinition;
    // A free name of the body: its type is the type of the occurrence, read
    // in the environment of the unit, and the binding is found by name when
    // the record is read.
    if (own === undefined) {
      let type = entry.occurrence.type;
      if (type.isUnknown) {
        cells ??= numberCellBindings(literal);
        if (cells.has(entry.name)) type = literal.engine.type('number');
      }
      bindings.push([undefined, type, entry.name, literal] as const);
      continue;
    }
    const copy = own.inferredType && own.value === undefined;
    const outer = copy ? outerBindingOf(literal, entry.name) : undefined;
    if (copy && outer === undefined) {
      // A call head of the body that has no outer binding yet: the type
      // is the type of the occurrence (rule 4 of the binding units), and
      // the binding is the one that a later declaration or assignment of
      // the name makes, found by name when the record is read.
      let type = entry.occurrence.type;
      if (type.isUnknown) {
        cells ??= numberCellBindings(literal);
        if (cells.has(own)) type = literal.engine.type('number');
      }
      bindings.push([undefined, type, entry.name, literal] as const);
      continue;
    }
    const binding = copy ? (outer ?? own) : own;
    if (binding === undefined) continue;
    // The type of a list literal reads an element that is a free symbol of
    // type `unknown` as a number cell (`[-x, y]` is typed `vector<2>`), but
    // it does not infer the symbol (`narrowFreeSymbolCells()`,
    // `canonical-utils.ts`). So the type of the definition relied on a
    // number there, and `number` is recorded: a later string value of `y`
    // makes the type outdated. A recorded `unknown` would admit it.
    let type = binding.type;
    if (type.isUnknown) {
      cells ??= numberCellBindings(literal);
      if (cells.has(own) || cells.has(binding))
        type = literal.engine.type('number');
    }
    bindings.push([binding, type, entry.name] as const);
  }
  if (bindings.length === 0 && !DEFINITION_CAPTURED_TYPES.has(def)) return;
  if (bindings.length === 0) DEFINITION_CAPTURED_TYPES.delete(def);
  else DEFINITION_CAPTURED_TYPES.set(def, bindings);
}

/**
 * The bindings of the symbols that the type of a `List` literal in the body
 * of the function literal `literal` reads as number cells: the symbols of
 * type `unknown` that are elements of a list whose element type is known
 * (`[-x, y]`, typed `vector<2>`). A list whose element type is `unknown`
 * (`[y, x]` with a parameter `x`, typed `list<unknown>`) relies on no type of
 * its elements. A list in a nested function literal counts: the type of the
 * outer literal contains the type of the nested one. A symbol is matched by
 * its binding, so a parameter of a nested literal with the same name as a
 * captured symbol does not count. The walk reads each node one time, so a
 * body that shares its operands is not unfolded, as in `capturedSymbols()`.
 */
function numberCellBindings(literal: Expression): Set<object | string> {
  const out = new Set<object | string>();
  if (!isFunction(literal, 'Function')) return out;
  const seen = new Set<Expression>();
  const visit = (e: Expression): void => {
    if (seen.has(e) || !isFunction(e) || e._numericStore !== undefined) return;
    seen.add(e);
    if (e.operator === 'List' && listReadsNumberCells(e))
      for (const op of e.ops) {
        const def = isSymbol(op) ? op.valueDefinition : undefined;
        if (def !== undefined && op.type.isUnknown) out.add(def);
        // A free name is matched by its name.
        else if (
          isSymbol(op) &&
          (op as { _isFreeName?: boolean })._isFreeName === true &&
          op.type.isUnknown
        )
          out.add(op.symbol);
      }
    for (const op of e.ops) visit(op);
  };
  visit(literal);
  return out;
}

/** True when the type of the list literal `list` gives its elements a known
 * type, the test that `narrowFreeSymbolCells()` (`canonical-utils.ts`) makes
 * before it reads the cells. */
function listReadsNumberCells(list: Expression): boolean {
  const t = list.type.type;
  if (typeof t === 'string' || t.kind !== 'list') return false;
  const e = t.elements;
  return !(
    e === 'unknown' ||
    (typeof e !== 'string' &&
      e.kind === 'union' &&
      e.types.some((x) => x === 'unknown'))
  );
}

/**
 * True when a binding that a call of the literal of the definition `def`
 * reads for a captured symbol has a type now that is not a subtype of its
 * type when the type of `def` was inferred (`noteDefinitionCapturedTypes()`).
 *
 * The type that a definition inferred from its literal (the signature of
 * `g(x) := [-x, y]`, or the type of `let g = (x) => [-x, y]`) is not
 * inferred again when such a type changes, so a call can then give a value
 * outside the type that the call is typed with. A change to `unknown` gives
 * no evidence of that.
 * (User decision 2026-10-25, option (c) of CE-473 in `ROADMAP.md`.)
 */
export function capturedTypesWidened(def: object): boolean {
  return capturedTypeWidening(def) !== undefined;
}

/**
 * The first captured symbol of the literal of the definition `def` whose
 * binding has a type now that is not a subtype of its type when the type of
 * `def` was inferred: its name, that earlier type, and its type now. This
 * is the test of `capturedTypesWidened()`, with the evidence that a message
 * can name. `undefined` when there is no such symbol.
 */
export function capturedTypeWidening(
  def: object
): { name: string; before: BoxedType; now: BoxedType } | undefined {
  return capturedTypeWidenings(def)[0];
}

/**
 * Every captured symbol of the literal of the definition `def` whose binding
 * has a type now that is not a subtype of its type when the type of `def`
 * was inferred, in the order of the record. `capturedTypeWidening()` gives
 * the first one.
 */
export function capturedTypeWidenings(
  def: object
): Array<{ name: string; before: BoxedType; now: BoxedType }> {
  const snapshot = DEFINITION_CAPTURED_TYPES.get(def);
  if (snapshot === undefined) return [];
  const out: Array<{ name: string; before: BoxedType; now: BoxedType }> = [];
  for (const [recorded, before, name, literal] of snapshot) {
    const binding =
      recorded ??
      (literal !== undefined ? outerBindingOf(literal, name) : undefined);
    if (binding === undefined) continue;
    const now = binding.type;
    if (now === before) continue;
    if (now.isUnknown) {
      // A binding that stays `unknown` can still hold a value, written on
      // the definition without the type setter. The value is compared with
      // the recorded type: for `y` in `x ↦ [-x, y]` the record is `number`
      // (the list reads `y` as a number cell), and a string value makes the
      // type of the definition outdated.
      const value = binding.value?.type;
      if (
        value !== undefined &&
        !value.isUnknown &&
        !isSubtype(value.type, before.type)
      )
        out.push({ name, before, now: value });
      continue;
    }
    if (!isSubtype(now.type, before.type)) out.push({ name, before, now });
  }
  return out;
}

/**
 * The value of a call of a definition made from a function literal, when
 * `checked` is true (a captured symbol of the literal changed type since the
 * type of the definition was inferred, or holds a value of another type than
 * the body was typed with) and `result`, the value of the call, is not of
 * `callType`, the static type of the call: an `incompatible-type` error, as
 * a library operator gives for an operand of the wrong type. `undefined`
 * otherwise.
 *
 * The comparison is with the type of the call node, not with the result of
 * the signature: a call that maps the function over a list
 * (`g([1, 2])`), or a partial application (`g(1)` for a function of two
 * parameters), is typed by its node, which describes that value.
 * (User decision 2026-10-25, option (c) of CE-473 in `ROADMAP.md`.)
 */
export function resultOutsideCallType(
  ce: Expression['engine'],
  callType: BoxedType,
  checked: boolean,
  result: Expression | undefined
): Expression | undefined {
  if (!checked || result === undefined || !result.isValid) return undefined;
  if (
    callType.isUnknown ||
    result.type.isUnknown ||
    result.type.matches(callType)
  )
    return undefined;
  return ce.typeError(callType.type, result.type, result);
}
