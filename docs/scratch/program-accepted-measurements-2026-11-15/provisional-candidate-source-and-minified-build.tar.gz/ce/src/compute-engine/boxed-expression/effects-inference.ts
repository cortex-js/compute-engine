import type {
  EffectLabel,
  EffectSet,
  FunctionSignature,
  Type,
} from '../../common/type/types.js';
import type { BoxedType } from '../../common/type/boxed-type.js';
import { withStaticTypingView } from '../static-typing-view.js';
import {
  broadcastableBaseMatches,
  collectionElementType,
  hasFunctionSignature,
  signatureArms,
  signatureEffects,
  signatureSlotType,
  stripMissingFromType,
  stripNumericRanges,
  typeContainsMissing,
} from '../../common/type/utils.js';
import {
  defaultedSlotsAsRequired,
  isSubtype,
  provablyAdmits,
  objectLayoutOfType,
  provablyDisjoint,
  widenAll,
} from '../../common/type/subtype.js';
import {
  COLLECTION_SHAPE_TYPE,
  INDEXED_COLLECTION_SHAPE_TYPE,
} from '../../common/type/primitive.js';
import {
  isRecordOrRecordUnionShapedType,
  isRecordShapedType,
  isTupleOrTupleUnionShapedType,
  isTupleShapedType,
} from '../collection-utils.js';
import { isInferredTypedParameter } from './inferred-annotations.js';
import { declaredBinders } from './binding-sites.js';
import { callableBindingInContext, readsActivationHalf } from './binders.js';
import { scopeActivationTemplate } from './ambient-chain.js';
import { reduceType, typesOverlap } from '../../common/type/reduce.js';
import { parseType } from '../../common/type/parse.js';
import {
  effectSetToString,
  isCoFiniteEffects,
  normalizeEffectSet,
  subtractEffects,
  unionEffectSets,
} from '../../common/type/effects.js';

import type {
  BoxedOperatorDefinition,
  Expression,
  FunctionInterface,
  IComputeEngine as ComputeEngine,
  Scope,
} from '../global-types.js';

import {
  isAbsentSymbol,
  isDictionary,
  isFunction,
  isNumber,
  isString,
  isSymbol,
  sym,
} from './type-guards.js';
import { restrictionParts } from './conditional-value.js';
import {
  effectiveDischarge,
  blockStatementsOf,
  homeBinding,
  homeDefinition,
  mayStoreIntoReceiverOfType,
  protocolAccessorEffects,
} from './effects-of.js';
import { typeAcceptsValue } from './value-membership.js';
import {
  declaredTypeError,
  failedElementRefusedBy,
  genericOverloadLiteralError,
} from './type-compatibility-error.js';
import { substituteDeclaredBounds } from './generic-instantiation.js';
import { isPolymorphicType } from '../../common/type/instantiate.js';
import {
  functionLiteralParameterNames,
  destructuringParameterType,
  functionLiteralBody,
  functionLiteralBoundNames,
  functionLiteralDeclaredEffects,
  functionLiteralDeclaredSignature,
  functionLiteralParameters,
  functionLiteralReturnMarker,
  functionLiteralReturnType,
  inferredSignatureParameterName,
  isDestructuringParameter,
  isFunctionLiteralParameter,
  isScalarType,
  isWideParameterType,
  mentionsQuantifiedVariable,
  optionalParameterTarget,
  restParameterIndex,
  restParameterSignatureTail,
  signatureArgumentsOfSlots,
} from './function-literal.js';
import { signatureResultType } from './callee-type-derivation.js';
import { matchPatternReferences } from './pattern-utils.js';

/**
 * # The `Function`-literal construction seam (`docs/EFFECTS-MODEL.md`, "Inference")
 *
 * Stage 2 requires ONE choke point: "The effect walk runs where a `Function`
 * literal's signature type is constructed. […] Stage 2 **must route them
 * through a single shared construction seam** that performs the walk, plus a
 * guard test that fails if a construction site bypasses it — a missed site
 * silently reintroduces the inline-callback gap."
 *
 * This module is that seam. Two exported entry points, and nothing else in the
 * engine may build a `Function` literal's arrow or re-implement the walk:
 *
 * - {@link functionLiteralSignatureType} — the literal's OWN arrow type,
 *   parameters + result + effect specifier. Every route (`ce.parse`, `ce.box`,
 *   `ce.function`, `ce._fn`, internal construction in `calculus.ts`,
 *   `collections.ts`, `match-dispatch.ts`, …) reaches it through the single
 *   `type()` computation in `boxed-function.ts`, because a construction site
 *   builds an *expression*: the arrow only ever materializes here.
 * - {@link inferFunctionLiteralEffects} — the walk itself, used by
 *   `boxed-operator-definition.ts` to stamp a user function's definition.
 *
 * The guard test is `test/compute-engine/effects-seam.test.ts`.
 */

/** The outcome of the static effect walk over a `Function` literal's body. */
export interface InferredLiteralEffects {
  /** The latent effect set of the literal's arrow. */
  effects: EffectSet | undefined;
  /** The peer runtime field (NOT an effect — the noise-floor convention). */
  readsRandomFrame: boolean;
  /** Frame participation the walk POSITIVELY observed, retained across the
   * `any` collapse. See `_inferredDraws` in `boxed-operator-definition.ts`. */
  draws: boolean;
  /** True when the walk applied a named head with no resolvable definition.
   * Such a walk contributed `{any}` and, per the v5 dependency-order ruling,
   * DISABLES the definition-annotation check: the annotation installs as a
   * trusted contract instead (no dependency tracking, no revalidation). */
  unresolvedHead: boolean;
  /** True when the walk POSITIVELY proved a world mutation: an unconfined
   * write or `Assume` in the body, or an application of a resolved callee /
   * annotated callback parameter whose effect set concretely contains
   * `scope`. Unlike the `scope` label in {@link effects}, this bit survives
   * the `any` collapse AND is never set by conservatism (an unresolved head's
   * `{any}` does not set it) — it is the trigger of the default-`!scope`
   * ceiling on bare-slot definitions (`docs/EFFECTS-MODEL.md`, "Scope is
   * opt-in"; ruled 2026-08-15). */
  escapingWrite: boolean;
  /** True when the walk consulted an effect set that is itself LAZILY DERIVED
   * from the conformance registry — see `WalkState.consultsRegistry`. A
   * definition stamped from such a walk installs a deriver of its own
   * (`_deriveEffects` in `boxed-operator-definition.ts`) instead of freezing
   * the value it saw. */
  consultsRegistry: boolean;
}

/**
 * Raised when a definition's EXPLICIT effect annotation is violated by the
 * inference over its body (`inferred ⊄ declared`). The definition is not
 * installed; the `Assign` / `Declare` operator routes turn this into an
 * `incompatible-type` error value, the same channel as the call-boundary
 * check.
 */
export class EffectContractError extends Error {
  /** Identifies the class by STRING, not `instanceof`: a plugin bundle
   * re-bundles the engine, so a cross-bundle `instanceof` check fails (see the
   * cross-bundle identity hazard in ARCHITECTURE.md). */
  readonly name = 'EffectContractError';

  constructor(
    readonly symbol: string,
    readonly declared: EffectSet | undefined,
    readonly inferred: EffectSet | undefined,
    /** Where the violated contract was STATED, when the effects-axis
     * provenance history recorded it (a post-construction declaration —
     * `docs/EFFECTS-MODEL.md`). `undefined` for
     * a construction-stated contract, which records no entry. Used for
     * RENDERING only (the escape rule of the rollback-frame design): the
     * message and the Epsil diagnostic show its `toString()`, and no
     * consumer resolves bindings through it. */
    readonly declaredAt?: Expression,
    /** True when the violated bound is the IMPLICIT default rather than an
     * author-stated contract: a bare-slot definition whose body proved a
     * world mutation. Escaping writes are opt-in — the `scope` effect must
     * be declared (`docs/EFFECTS-MODEL.md`, "Scope is opt-in"; ruled
     * 2026-08-15). Changes only the rendering, not the channel. */
    readonly scopeDefault?: boolean
  ) {
    super(
      scopeDefault
        ? `Operator Definition "${symbol}": the body writes outside the function (an assignment to an outer variable, or an assumption), which requires declaring the \`scope\` effect — e.g. \`function ${symbol}(…) scope { … }\` or a \`(…) scope -> …\` signature. Inferred effects: \`${describeEffects(inferred)}\``
        : `Operator Definition "${symbol}": the body infers the effects \`${describeEffects(inferred)}\`, which the declared effects \`${describeEffects(declared)}\`` +
            (declaredAt === undefined
              ? ''
              : ` (declared at \`${declaredAt.toString()}\`)`) +
            ` do not cover`
    );
  }
}

/** True when `e` is an {@link EffectContractError}, checked by name so the
 * test survives a host/plugin bundle boundary. */
export function isEffectContractError(e: unknown): e is EffectContractError {
  return (
    e instanceof Error &&
    (e as Error).name === 'EffectContractError' &&
    'declared' in e
  );
}

/**
 * The `incompatible-type` error VALUE a violated definition-annotation
 * contract yields on the `Assign` / `Declare` operator routes — the same shape
 * and channel as the call-boundary type check
 * (`createTypeErrorExpression`). The JS `ce.assign` / `ce.declare` API keeps
 * the throw, matching every other registration-time conflict.
 */
export function effectContractErrorValue(
  ce: ComputeEngine,
  e: EffectContractError
): Expression {
  // The declaring site travels as the error's `where` STRING — the legacy
  // string-context slot of the sited-error shape, rendered by
  // `describeError` on the Epsil static route. Deliberately a string, not
  // an expression operand: the effects note only ever renders the site
  // (never resolves bindings through it), and the public `ce.error` `where`
  // parameter is string-typed. The diagnostic dedup key is site-less by the
  // phase-1 design, so deduplication is unchanged.
  return ce.error(
    [
      'incompatible-type',
      e.scopeDefault
        ? 'non-scope effects (writes outside a function require a declared `scope` effect)'
        : `${describeEffects(e.declared)} effects`,
      `${describeEffects(e.inferred)} effects`,
    ],
    e.declaredAt?.toString()
  );
}

/** The effect set spelled for a diagnostic; the empty set has no spelling. */
export function describeEffects(effects: EffectSet | undefined): string {
  return effects === undefined ? 'pure' : effectSetToString(effects);
}

/**
 * The effects attached to a signature type's arrow, if any — the compute-engine
 * layer's entry point for the question. ONE implementation lives in
 * `common/type/utils.ts` (the reader behind `BoxedType.effects`); this module
 * re-exports it so the two layers cannot drift. See that function for the
 * union / intersection / stated-empty rules.
 */
export { signatureEffects };

/**
 * `t` with the TOP-LEVEL arrow's effect specifier removed.
 *
 * Used where an INFERRED literal type is fed back as a definition's
 * `signature:` (`assignValueAsOperatorDef`, for a literal carrying a
 * return-type ascription or an annotated parameter). Such a signature is
 * inference-produced, not author-stated: leaving the specifier on it would set
 * the `effectsDeclared` provenance bit and turn the engine's own inference into
 * a contract it then checks against itself. A return-type-only `Typed(body, T)`
 * ascription carries NO effect contract (`docs/EFFECTS-MODEL.md`, "Annotation
 * provenance"); the walk re-derives the effects and stamps them back.
 *
 * Nested arrows keep their effects — an annotated parameter's declared
 * `(real) random -> real` is the author's, and only the outer specifier is
 * inferred.
 */
export function stripArrowEffects(t: Type): Type {
  if (typeof t === 'string') return t;
  if (t.kind !== 'signature' || t.effects === undefined) return t;
  const next = { ...t };
  delete next.effects;
  return next;
}

/**
 * `t` with `effects` set on its TOP-LEVEL arrow — the counterpart of
 * {@link stripArrowEffects}, a no-op when `t` is not a signature.
 *
 * Used where an AUTHOR-STATED effect set (a `Function` literal's
 * full-signature return marker) must ride onto a signature otherwise derived
 * from the inference-produced literal type, so that the operator definition
 * records it as a contract rather than as its own inference.
 */
export function withArrowEffects(t: Type, effects: EffectSet): Type {
  if (typeof t === 'string' || t.kind !== 'signature') return t;
  return { ...t, effects };
}

/**
 * The declared-type compatibility check, judged **per axis**
 * (`docs/EFFECTS-MODEL.md`, "Annotation provenance").
 *
 * A declaration written as a full signature declares its **type axes** —
 * parameters and result — unconditionally. Its **effects axis** is judged by
 * its own provenance, exactly as `inferredType` gates the type axes:
 *
 * - `effectsDeclared === false` (a bare specifier slot): effects are on the
 *   INFERRED track. Every `Function` literal's arrow carries the effects its
 *   body walk inferred, so a `{scope}` closure assigned to a declaration
 *   written `(number) -> number` must still fit — the check retries with the
 *   value's inferred top-level specifier removed. (Those closures are shipped,
 *   pinned idioms: `scope.test.ts`'s recursive-with-outer-variable function,
 *   `lambda-capture.test.ts`'s mutable closure.)
 * - `effectsDeclared === true`, or ANY effect set on the declared arrow
 *   (including the stated-empty `[]` a `pure` keyword builds): the effect set
 *   is a CONTRACT and is checked covariantly here too, `inferred ⊆ declared`.
 *
 * Only the TOP-LEVEL specifier is inferred; a nested arrow (an annotated
 * parameter's `(real) random -> real`) is the author's and is never stripped.
 */
/**
 * Refine `unknown` placeholder slots in a DECLARED ground signature with the
 * corresponding slots of the value's inferred signature, before the two are
 * compared.
 *
 * A declared `unknown` is a placeholder, not a contract: the following
 * definition supplies the information used to refine it. Comparing a body
 * directly against `(unknown) -> unknown` would fail contravariantly because
 * `unknown` is not a subtype of the inferred parameter type.
 *
 * `any` slots are not refined: `any` is a contract. The
 * identity function is `(any) -> any`, a promise to accept every value — so a
 * body must honor it.
 *
 * Only top-level parameter and result slots of a plain fixed-arity ground
 * signature are refined; polymorphic declarations, optional/variadic
 * signatures, and non-signature types pass through untouched.
 *
 * Exported for the install routes in `engine-declarations.ts`, which refine
 * BEFORE their reconciliation pipeline (so parameter ascription, the
 * compatibility check, and the `paramsAreScalar` broadcast decision all see
 * the concrete signature) and persist the refined type onto the definition —
 * a check-time-only refinement here would accept the definition but leave the
 * stored `(unknown) -> …` signature driving call-site broadcasting, so
 * `l_P([3,4])` broadcast elementwise instead of passing the list whole.
 */
export function refineDeclaredPlaceholders(declared: Type, value: Type): Type {
  if (typeof declared !== 'object' || declared.kind !== 'signature')
    return declared;
  // A polymorphic declaration's slots are quantified variables with their own
  // machinery (§2.4 generic literals) — never placeholder-refined.
  if (isPolymorphicType(declared)) return declared;
  if (typeof value !== 'object' || value.kind !== 'signature') return declared;
  if ((declared.optArgs?.length ?? 0) > 0) return declared;
  if (declared.variadicArg !== undefined) return declared;
  const dArgs = declared.args ?? [];
  const vArgs = value.args ?? [];
  if (dArgs.length !== vArgs.length) return declared;

  let argsChanged = false;
  const args = dArgs.map((a, i) => {
    if (a.type !== 'unknown') return a;
    const v = vArgs[i]?.type;
    if (v === undefined || v === 'unknown') return a;
    argsChanged = true;
    return { ...a, type: v };
  });
  let resultChanged = false;
  let result = declared.result;
  if (result === 'unknown' && value.result !== 'unknown') {
    resultChanged = true;
    result = value.result;
  }
  if (!argsChanged && !resultChanged) return declared;
  // Replace only the slots that moved: a zero-arg signature spells its
  // parameter list as ABSENT (`args: undefined`), and fabricating an explicit
  // empty array changes the object shape the rest of the type machinery
  // canonicalized on.
  const refined = { ...declared, result };
  if (argsChanged) refined.args = args;
  return refined;
}

/**
 * True when {@link refineDeclaredPlaceholders} can move a slot of `t`: `t` is
 * a plain fixed-arity ground signature and at least one of its top-level
 * parameter slots or its result slot is `unknown`.
 *
 * A declaration of this shape is a SIGNATURE SKELETON. The value definition
 * keeps it as written and derives the refined signature from the current
 * function value on every read, so the refinement follows the body instead
 * of recording the body's type at the moment of the first assignment.
 */
export function hasSignaturePlaceholder(t: Type): boolean {
  if (typeof t !== 'object' || t.kind !== 'signature') return false;
  if (isPolymorphicType(t)) return false;
  if ((t.optArgs?.length ?? 0) > 0) return false;
  if (t.variadicArg !== undefined) return false;
  if (t.result === 'unknown') return true;
  return (t.args ?? []).some((a) => a.type === 'unknown');
}

/**
 * The MIRROR of {@link refineDeclaredPlaceholders}, deliberately NARROWER: a
 * VALUE's placeholder `unknown` slot adopts the expected signature's slot
 * only when that slot is a TOP type (`any` — adopting `unknown` is a no-op).
 * This is exactly the acceptance the `any`/`unknown` lattice repair
 * (2026-08-17) orphaned: `(x) => x`, inferred `(unknown) -> unknown`, must
 * still satisfy a parameter declared `(any) -> any`, which previously worked
 * only via the erroneous `any <: unknown` edge. It must go NO wider: adopting
 * a CONCRETE expected slot (`(number) -> number`) would silently ascribe a
 * result type nothing proved — a `(unknown) -> unknown` value was refused at
 * such a parameter before the repair, and still is.
 *
 * One more case is accepted, for a PARAMETER slot only: an expected slot that
 * admits the absence marker (`string | missing`). A bare parameter of a
 * function literal accepts an absent argument (the body runs with
 * `Missing`, user decision of 2026-09-30, pinned by
 * `test/compute-engine/absent-argument-annotated-parameter.test.ts`), but its
 * placeholder type `unknown` excludes `missing`, so the contravariant check
 * `string | missing <: unknown` refused `s ↦ IsMissing(s)` under the
 * declaration `(string | missing) -> unknown`, which is the declaration a
 * host writes to accept an absent argument. The slot is read as
 * `unknown | missing`, which states what the bare parameter accepts and
 * ascribes nothing to the body.
 */
export function adoptTopPlaceholderSlots(value: Type, expected: Type): Type {
  if (typeof value !== 'object' || value.kind !== 'signature') return value;
  if (isPolymorphicType(value)) return value;
  if (typeof expected !== 'object' || expected.kind !== 'signature')
    return value;
  if ((value.optArgs?.length ?? 0) > 0) return value;
  if (value.variadicArg !== undefined) return value;
  const vArgs = value.args ?? [];
  const eArgs = expected.args ?? [];
  if (vArgs.length !== eArgs.length) return value;

  let argsChanged = false;
  const args = vArgs.map((a, i) => {
    if (a.type !== 'unknown') return a;
    const e = eArgs[i]?.type;
    if (e === 'any') {
      argsChanged = true;
      return { ...a, type: 'any' as Type };
    }
    // A TOP-LEVEL `missing` arm only: `list<integer | missing>` is already a
    // subtype of `unknown`, and its absent cells say nothing about an absent
    // argument.
    if (e !== undefined && provablyAdmits('missing', e)) {
      argsChanged = true;
      return {
        ...a,
        type: reduceType({ kind: 'union', types: ['unknown', 'missing'] }),
      };
    }
    return a;
  });
  let resultChanged = false;
  let result = value.result;
  if (result === 'unknown' && expected.result === 'any') {
    resultChanged = true;
    result = 'any';
  }
  if (!argsChanged && !resultChanged) return value;
  const refined = { ...value, result };
  if (argsChanged) refined.args = args;
  return refined;
}

/**
 * The type a RESTRICTION presents when its condition holds, as a union with
 * the `missing` arm it keeps — or `undefined` when the value is not one of
 * the narrow shape this refinement covers.
 *
 * A restriction such as `5 {a > 0}` holds the number 5 when its condition is
 * true and the absence marker when it is false. Its own type cannot say which
 * number: a type-handler result is widened back to ordinary types, because a
 * handler must not store an over-specific contract nobody wrote, so the
 * literal type `5` becomes the tier `integer` and the restriction types
 * `integer | missing`. A declared RANGE then refuses the restriction —
 * `integer` inhabits no range — although the value it holds does inhabit it,
 * and the identical ungated `5` is accepted. Reading the literal back off the
 * held operand restores that precision at the one place it is needed: the
 * check that admits a value into a declared type. (2026-09-22)
 *
 * The shape is deliberately narrow:
 * - the value's own type must be a union with a `missing` arm, which is the
 *   SCALAR restriction. A list-broadcast restriction types
 *   `list<T | missing>`, and there the held operand describes one cell rather
 *   than the whole value, so it keeps its own type.
 * - the held operand must be a number literal, the only operand whose type
 *   carries a value the widening erased.
 * - that literal type must be a subtype of what the restriction's own type
 *   already says, so this can narrow the check but never contradict it.
 */
function restrictionValueType(
  value: BoxedType,
  valueExpr: Expression | undefined
): Type | undefined {
  if (valueExpr === undefined) return undefined;
  const t = value.type;
  // Stacked restrictions canonicalize into one restriction, but a value that was
  // not canonicalized can still nest, so walk to the innermost held operand.
  let held: Expression = valueExpr;
  for (let r = restrictionParts(held); r; r = restrictionParts(held))
    held = r.value;
  if (held === valueExpr) return undefined;
  // A NUMERIC restriction is typed with a `nan` arm and no `missing` arm,
  // because it masks to `NaN` (user decision 2026-09-25): the type it
  // PRESENTS is the value it holds, `integer` for `5 {a > 0}`, which is what
  // an assumption (`v > 3`) or a declared range (`integer<3<..>`) is asked
  // about. This extends the 2026-09-22 rule (absence is a state every type
  // can take, so a `missing` arm is not held against the declared type) to
  // the `NaN` a masked number answers: a declared `integer<3<..>` symbol
  // holding `5 {a > 0}` evaluates to `NaN` once `a` fails, exactly as it
  // evaluated to `Missing` before. A list
  // MASK over numbers (`[10,20,30] {[1,2,3] > 2}`, `5 {[a > 0, b > 0]}`) is
  // typed `list<number>` for the same reason and presents the held list, or
  // a list of the held number's tier.
  if (isNumber(held) && isSubtype(t, 'number')) return held.type.type;
  if (
    typeof t === 'object' &&
    t.kind === 'list' &&
    isSubtype(t.elements, 'number')
  ) {
    if (isNumber(held)) return { kind: 'list', elements: held.type.type };
    if (isFunction(held, 'List') && isSubtype(held.type.type, 'list<number>'))
      return held.type.type;
    return undefined;
  }
  if (!isNumber(held)) return undefined;
  const literal = held.type.type;
  if (typeof t !== 'object' || t.kind !== 'union') return undefined;
  if (!t.types.includes('missing')) return undefined;
  if (!isSubtype(literal, stripMissingFromType(t))) return undefined;
  return reduceType({ kind: 'union', types: [literal, 'missing'] });
}

/**
 * The type a value PRESENTS to a constraint: the type it has when it is
 * there, with the `missing` arm removed and a literal held through a
 * restriction read back (see {@link restrictionValueType}).
 *
 * Absence is a state every type can take (ruled 2026-09-09), so a check that
 * asks what a value IS must ask it of the present arm. This is the same
 * reading {@link matchesDeclaredTypeAxes} applies to a declared type, shared
 * here for the assumption check in `assertAssignableValueDef`, which asks the
 * identical question of the type the facts in force prove. (2026-09-22)
 */
export function presentedValueType(
  ce: ComputeEngine,
  value: Expression
): BoxedType {
  const refined = restrictionValueType(value.type, value);
  const t = refined ?? value.type.type;
  if (!typeContainsMissing(t)) return refined ? ce.type(refined) : value.type;
  return ce.type(stripMissingFromType(t));
}

/**
 * The declared-type check of a STORE into a declared symbol (`ce.assign`, the
 * `Assign` operator, a `Declare` with a value, a typed Epsil `let` or
 * assignment): true when `value` fits `declared`, or when it is the marker
 * `Missing`, or when each of its parts fits `declared` except the parts that
 * are `Missing`.
 *
 * `Missing` is a result only: it cannot be declared, and a read out of range
 * or a selection with no match produces it whatever type the collection has
 * (`At(["a"], 5)` is `Missing`, and `(1, Missing) + (1, 1)` is
 * `(2, Missing)`). A declared type cannot say "or absent", so a declared
 * variable that may receive such a read must accept the marker where it
 * accepts a present value: `s: string` takes `At(["a"], 5)`, and
 * `t: tuple<integer, integer>` takes `(2, Missing)`. The `missing` arms of the
 * value's type, at the top and in every element or component, are removed
 * before the ordinary check (`matchesDeclaredTypeAxes`), so a value that is
 * wrong where it is present (`5` for `string`, `[5, Missing]` for
 * `list<string>`) is still refused.
 *
 * `BoxedType.matches` stays strict: `missing` is not a subtype of `string`.
 * This tolerance belongs only to the store routes above. A numeric position
 * holds `NaN`, not `Missing`, when it is absent, and `NaN` is not removed:
 * `x: real` refuses `At([1, 2], 5)`, which is `NaN`, as it refuses `0/0`.
 *
 * Source: `docs/ERROR-MODEL.md`, "`Missing` is a result only — user
 * decision of 2026-11-02", rule 5.
 */
export function matchesOrAbsent(
  ce: ComputeEngine,
  value: BoxedType,
  declared: BoxedType,
  effectsDeclared: boolean,
  valueExpr?: Expression,
  /** The symbol being declared/assigned, for the diagnostic. */
  symbol?: string
): boolean {
  if (valueExpr !== undefined && isAbsentSymbol(valueExpr)) return true;
  if (typeContainsMissing(value.type)) {
    const present = stripMissingFromType(value.type);
    // A value typed `missing` alone is absent wherever it is read.
    if (present === 'never') return true;
    value = ce.type(present);
  }
  return matchesDeclaredTypeAxes(
    ce,
    value,
    declared,
    effectsDeclared,
    valueExpr,
    symbol
  );
}

/**
 * The verdict of a STORE of `value` into a symbol whose type `declared` was
 * declared (`ce.assign`, the `Assign` operator, a `Declare` with a value):
 *
 * - `'match'`: the value fits the declared type (`matchesOrAbsent()`). A
 *   read of the symbol does not test its value.
 * - `'overlap'`: the value does not fit, but its type overlaps the declared
 *   type, so it can evaluate to a value of the declared type. The store
 *   accepts it, and each evaluation of the symbol tests the evaluated value
 *   (`overlapReadError()` in `store-admission.ts`). This is the rule of an argument of a user
 *   function, which is admitted when its type overlaps the parameter type
 *   (`typesOverlap()`, read by `liftedOperandCannotFit()` in `validate.ts`)
 *   and tested when it is bound. The type compared is the type the value
 *   presents (`presentedValueType()`). Example: with `a` declared `real`
 *   and `P` declared `tuple<real | signed_infinity | nan, real |
 *   signed_infinity | nan>`, the value `(-sqrt(1 - a^2), a)` is typed
 *   `tuple<complex, real>`.
 *   The store accepts it; a read with `a = 0.5` gives `(-0.866…, 0.5)`, and
 *   a read with `a = 5` gives an `incompatible-type` error, because the first
 *   component is then imaginary.
 * - `'refuse'`: the store throws.
 *
 * Only a value that holds a symbol which is not a constant is admitted on
 * overlap: such a value can change when that symbol changes. A value made of
 * literals and constants is its own final value, so its type decides, and a
 * value that does not fit is refused at the store (`(1, 2.5)` for
 * `tuple<integer, integer>`). These are also refused at the store, whatever
 * their type: the symbol `Missing` at a type that excludes absence, an error
 * value, a collection that holds a failed element, a number literal held
 * through a restriction (`2 {a > 0}`), a value at a declared function
 * signature and a value at a polymorphic declared type. Each of these is
 * refused by its own rule, which an overlap must not replace.
 *
 * Source: ROADMAP CE-800, option 1 (user decision 2026-11-04).
 */
export function storeAdmission(
  ce: ComputeEngine,
  value: Expression,
  declared: BoxedType,
  effectsDeclared: boolean,
  /** The symbol being declared/assigned, for the diagnostic. */
  symbol?: string
): 'match' | 'overlap' | 'refuse' {
  if (matchesOrAbsent(ce, value.type, declared, effectsDeclared, value, symbol))
    return 'match';
  return mayEvaluateIntoDeclaredType(ce, value, declared)
    ? 'overlap'
    : 'refuse';
}

/**
 * Whether `value`, which does not fit the declared type `declared`, is
 * admitted on overlap: see the `'overlap'` verdict of `storeAdmission()`.
 */
function mayEvaluateIntoDeclaredType(
  ce: ComputeEngine,
  value: Expression,
  declared: BoxedType
): boolean {
  if (declared.isPolymorphic || hasFunctionSignature(declared.type))
    return false;
  if (isAbsentSymbol(value) || !value.isValid) return false;
  if (failedElementRefusedBy(value, declared.type) !== undefined) return false;
  // A number literal held through a restriction (`2 {a > 0}`) is that number
  // or `Missing`, whatever value `a` takes: the literal decides, as for the
  // ungated literal (`restrictionValueType()`).
  if (restrictionValueType(value.type, value) !== undefined) return false;
  const variable = value.symbols.some((id) => {
    const def = ce.lookupDefinition(id);
    return def === undefined || !('value' in def) || !def.value.isConstant;
  });
  if (!variable) return false;
  return typesOverlap(presentedValueType(ce, value).type, declared.type);
}

export function matchesDeclaredTypeAxes(
  ce: ComputeEngine,
  value: BoxedType,
  declared: BoxedType,
  effectsDeclared: boolean,
  valueExpr?: Expression,
  /** The symbol being declared/assigned, for the D7 diagnostic. */
  symbol?: string
): boolean {
  // A parameter of the declared signature with a default value is always
  // supplied when the symbol is called (the default is inserted), so the
  // value may require it: `(x, k) => x * k` is a value of
  // `(number, number = 2) -> number`.
  const required = defaultedSlotsAsRequired(declared.type);
  if (required !== declared.type) declared = ce.type(required);

  // A declared type is a contract on EVERY value the symbol takes (user
  // decision P1 of `docs/plans/2026-10-21-presence-contracts-and-assertion.md`,
  // 2026-10-21): the absence symbol `Missing` is refused
  // by a declaration that excludes absence, exactly as `5` is refused by
  // `string`. The value itself is tested first. A declaration
  // that admits absence (`string | missing`, `any`, a placeholder `unknown`)
  // takes the symbol.
  if (
    valueExpr !== undefined &&
    isAbsentSymbol(valueExpr) &&
    !isSubtype('missing', declared.type)
  )
    return false;

  // The same contract for a failed element of a collection literal. The
  // type of `[1, Error(…)]` leaves the failed element out (a type describes
  // the successful values), so it is `vector<integer^2>`, which a
  // `list<number>` admits. The value itself is read: a collection that holds
  // a failed element is refused unless the declared type admits `error` at
  // the position of that element (`failedElementRefusedBy`). The declared
  // type is read before its placeholders are refined from the value below,
  // so a declared `list<unknown>` still admits the value. A parameter
  // binding suspends this part of the check (`withoutFailedElementCheck`):
  // only a declared variable refuses the value.
  if (
    valueExpr !== undefined &&
    failedElementRefusedBy(valueExpr, declared.type) !== undefined
  )
    return false;

  // The mirror of the placeholder rule below, at whole-type granularity: a
  // value whose type is `unknown` states nothing about itself ("some value,
  // not stated which"), so a declaration has nothing to refute and admits it
  // UNCHECKED — no later verification happens, here or on dereference, which
  // is the same bargain the argument-position path in `validate.ts` already
  // strikes (an `unknown`-typed argument is admitted at a typed parameter and
  // never re-examined). Without this, a declared type was unwritable from any
  // expression the engine cannot type statically: `xs = f(0)` for an
  // undeclared `f` raised `incompatible-type list unknown` while the identical
  // value passed to a `list` PARAMETER was accepted. `any` is the opposite
  // case: it is a stated contract, is not `unknown`, and is still checked.
  //
  // A declared FUNCTION SIGNATURE is excluded, because admitting an unchecked
  // value there gives up more than one axis at once: the branches below judge
  // arity, the effects contract (`pure`) and polymorphic instantiation
  // separately, and a shapeless `unknown` would satisfy all of them at once
  // and install a definition that is CALLABLE under a contract nothing
  // proved. Those declarations keep refusing an `unknown` value, as they did
  // before this rule existed.
  if (value.isUnknown && !hasFunctionSignature(declared.type)) return true;

  // A restriction over a number literal presents that literal, not the tier
  // its own type shows — see `restrictionValueType` for why the two differ.
  // (2026-09-22)
  const restricted = restrictionValueType(value, valueExpr);
  if (restricted !== undefined) value = ce.type(restricted);

  // The value's `missing` member is NOT removed before the comparison (user
  // decision P1, 2026-10-21, which reverses the rule of 2026-09-09 that
  // read a declared type as the successes only): a value typed
  // `missing | tuple<integer, integer>` (a restricted point `(1, 2) {a > 0}`
  // while `a` is unbound) does not bind to a symbol declared
  // `tuple<number, number>`; the author declares `tuple<number, number> |
  // missing`, or discharges the absent case with `Coalesce`. A NUMERIC
  // restriction is unaffected: it masks to `NaN` and types `integer | nan`,
  // which `number` admits. The reader of a declared symbol can then trust
  // the declaration: a symbol declared `string` holds a string.
  //
  // A declared `unknown` slot is a placeholder the value refines, never a
  // constraint (see `refineDeclaredPlaceholders` above). Skipped for a
  // polymorphic declaration, whose slots are quantified variables with their
  // own machinery.
  if (!declared.isPolymorphic) {
    const refined = refineDeclaredPlaceholders(declared.type, value.type);
    if (refined !== declared.type) declared = ce.type(refined);
  }
  // The MIRROR reconciliation: the VALUE's own inferred signature can carry
  // placeholder `unknown` slots too (a lambda whose body did not constrain a
  // parameter types `(unknown) -> …`), and such a slot adopts a TOP-typed
  // declared slot before compatibility is judged — this is what lets
  // `vf: (any) -> any` accept `(y) => …`. Deliberately top-only (see
  // `adoptTopPlaceholderSlots`): adopting a concrete declared slot would
  // silently ascribe behavior nothing proved.
  if (!declared.isPolymorphic) {
    const refinedValue = adoptTopPlaceholderSlots(value.type, declared.type);
    if (refinedValue !== value.type) value = ce.type(refinedValue);
  }
  // Declaration compatibility uses SUBTYPE semantics. `BoxedType.matches` on
  // a polymorphic pattern is the D12 existential QUERY ("does SOME
  // instantiation fit?"), which would accept an instance-shaped ground value
  // against a generic declaration — but a declaration promises EVERY
  // instantiation (`Ground <: Poly` is false, D3), so a polymorphic declared
  // type is held to `isSubtype` here, never the existential probe.
  if (
    declared.isPolymorphic
      ? isSubtype(value.type, declared.type)
      : value.matches(declared)
  )
    return true;

  // A value typed `broadcastable<R>` is the scalar `R` or an indexed
  // collection of `R`, and which one it is is known only when it is
  // evaluated: `Sin(P)`, with `P` declared `collection<number>` and no value,
  // is a number when `P` holds a set and a list when `P` holds a list. Where
  // `R` is admitted, such a value is admitted too, because its scalar arm may
  // be the value. This is the admission a typed PARAMETER gives the same
  // value (`broadcastableBaseMatches`, applied by `validateArguments` and
  // `checkType` in `validate.ts`), so a declared symbol and a parameter of
  // the same type accept the same expressions.
  if (
    !declared.isPolymorphic &&
    broadcastableBaseMatches(value.type, declared.type)
  )
    return true;

  // A `Function` LITERAL under a GENERIC declaration is judged by the
  // generic-literals acceptance rule (§2.4 of
  // `docs/TYPE-SYSTEM.md`), NOT by
  // `Ground <: Poly` — which is false (D3) and would reject every generic
  // literal, as the retired D7 gate did. Under erasure (G1) the literal is an
  // untyped lambda with the polytype as its call-site contract, so the axes
  // that CAN be checked at the boundary are checked here and the rest is a
  // trusted ascription (G10).
  //
  // Gated on an actual `Function` LITERAL, as the routes in
  // `engine-declarations.ts` are: any other callable value (a symbol bound to
  // a ground function, say) has no body to speak of and falls through to the
  // ordinary `matches` path below, whose honest verdict is
  // `Ground <: Poly = false` — a plain `incompatible-type`.
  if (
    declared.isPolymorphic &&
    isFunction(valueExpr, 'Function') &&
    isCallableType(value.type)
  )
    return acceptsGenericFunctionLiteral(symbol ?? '', valueExpr, declared);

  // A concrete value inhabiting a value-component declared type (`z: 0` with
  // `z := 0`): the synthesized type (`integer`) cannot witness
  // membership in the value type. See `value-membership.ts`.
  if (valueExpr !== undefined && typeAcceptsValue(valueExpr, declared.type))
    return true;
  if (effectsDeclared || signatureEffects(declared.type) !== undefined)
    return false;
  const stripped = ce.type(stripArrowEffects(value.type));
  return declared.isPolymorphic
    ? isSubtype(stripped.type, declared.type)
    : stripped.matches(declared);
}

/**
 * G11 (§2.4) — a function literal may implement a polymorphic declared type
 * only when that type is a SINGLE-ARM signature.
 *
 * Runs FIRST at every declaration-boundary site, ahead of the arity and
 * effects assertions: an overload set with a generic arm is not a shape one
 * erased body can implement at all, so a "wrong arity" diagnostic for it would
 * name the wrong problem.
 *
 * A no-op for a ground declared type and for a single generic signature.
 */
export function assertSingleArmPolytype(
  symbol: string,
  literal: Expression,
  declared: BoxedType
): void {
  if (!declared.isPolymorphic) return;
  const t = declared.type;
  if (typeof t === 'object' && t.kind === 'signature') return;
  throw genericOverloadLiteralError(symbol, literal.type, declared);
}

/**
 * `sig` reduced to its TYPE AXES — `typeParams`, argument types and result —
 * for the G9 α-equivalence comparison.
 *
 * Two axes are dropped. **Effects**, because they are governed solely by the
 * `inferred ⊆ declared` subset rule (§2.4 rule 2) and whole-signature
 * α-equality would penalize a literal for honestly stating a NARROWER set.
 * **Argument names**, because a marker's argument names are cosmetic — the
 * literal's operand names are the names of record (§2.3, the
 * `docs/EFFECTS-MODEL.md` mirror rule) — and the α-equivalence relation
 * compares dedup KEYS, which do spell names out (`(x: T) -> T`). Without this
 * a declaration written `(T) -> T where T` would refuse the E1 spelling of
 * its own implementation, whose sugar REQUIRES named arguments.
 *
 * `typeParams` is carried through (the rebuild invariant): the comparison is
 * α-equivalence, which needs the clause.
 */
function typeAxesOf(sig: FunctionSignature): Type {
  const t = stripArrowEffects(sig) as FunctionSignature;
  const anonymize = (a: { name?: string; type: Type }) => ({ type: a.type });
  return {
    ...t,
    ...(t.args !== undefined ? { args: t.args.map(anonymize) } : {}),
    ...(t.optArgs !== undefined ? { optArgs: t.optArgs.map(anonymize) } : {}),
    ...(t.variadicArg !== undefined
      ? { variadicArg: anonymize(t.variadicArg) }
      : {}),
  };
}

/**
 * The generic-literal ACCEPTANCE RULE (§2.4 of
 * `docs/TYPE-SYSTEM.md`), shared by every
 * declaration-boundary route.
 *
 * Rules 1 (arity, `assertFunctionLiteralArity`) and 2 (effects,
 * `assertDeclaredEffects`) are the SAME assertions a ground declared signature
 * runs — `signatureArms` and `signatureEffects` both read a clause-carrying
 * arrow — so the boundary sites in `engine-declarations.ts` already apply
 * them, unchanged, before the value definition is built and this check runs.
 * What is generic-specific is rule 0 (G11, {@link assertSingleArmPolytype}),
 * rule 3 and rule 4 below.
 *
 * Everything the erased body itself does — in particular whether it really
 * returns its argument's type — is a TRUSTED ascription (G10, ruled): under
 * erasure there is nothing to check it against.
 */
function acceptsGenericFunctionLiteral(
  symbol: string,
  literal: Expression,
  declared: BoxedType
): boolean {
  // Rule 0 — G11.
  assertSingleArmPolytype(symbol, literal, declared);
  const declaredSig = declared.type as FunctionSignature;

  // Rule 3 — own-contract agreement (G9). A literal that states its OWN
  // full-signature polytype (E1/E2/E4) must agree with the declaration on the
  // TYPE axes: `typeParams` modulo renaming, argument types, result. That is
  // exactly `isSubtype` between two polytypes (§5 rule 3 — α-equivalence).
  //
  // The EFFECTS axis is excluded — stripped from BOTH arrows first — and is
  // governed solely by the `inferred ⊆ declared` subset rule: a literal that
  // honestly states a NARROWER effect set (`pure` marker under a `random`
  // declaration) must not be penalized for being explicit where silence
  // passes. A plain (E3) literal carries no marker and always passes.
  const marker = functionLiteralDeclaredSignature(literal);
  if (marker !== undefined && (marker.typeParams?.length ?? 0) > 0) {
    if (!isSubtype(typeAxesOf(marker), typeAxesOf(declaredSig)))
      throw declaredTypeError(symbol, literal, declared);
  }

  // Rule 4 — ground annotations cover the domain (CONTRAVARIANT). A ground
  // implementation annotation sitting at a QUANTIFIED parameter position must
  // accept every instantiation the declaration admits, i.e.
  // `declaredBound <: annotation`. An unbounded variable is bounded by `any`,
  // so in practice only a wide `unknown`/`any` annotation passes — don't
  // annotate a quantified position. Ground annotations at GROUND positions
  // reconcile exactly as they do under a ground declaration.
  const args = declaredSig.args ?? [];
  const typeParams = declaredSig.typeParams;
  if (typeParams !== undefined && typeParams.length > 0) {
    // `substituteDeclaredBounds` leaves an UNBOUNDED variable alone; the
    // kind-level reading of one is `any`, so supply that bound explicitly.
    const bounded = typeParams.map((p) =>
      p.bound === undefined ? { ...p, bound: 'any' as Type } : p
    );
    const params = functionLiteralParameters(literal);
    for (let i = 0; i < params.length && i < args.length; i++) {
      const annotation = params[i].type;
      if (annotation === undefined) continue;
      const pattern = args[i].type;
      if (!mentionsQuantifiedVariable(pattern, declaredSig)) continue;
      if (!isSubtype(substituteDeclaredBounds(bounded, pattern), annotation))
        throw declaredTypeError(symbol, literal, declared);
    }
  }

  return true;
}

//
// ── The literal's own arrow ──────────────────────────────────────────────────
//

/**
 * Build the signature type of a `Function` literal — THE seam.
 *
 * Parameters + result type + the effect specifier produced by
 * {@link inferFunctionLiteralEffects} over the body. Called from exactly one
 * place, the `Function` case of `type()` in `boxed-function.ts`; every
 * construction route funnels through it because a construction site produces an
 * expression and the arrow is only ever materialized on `.type`.
 *
 * The literal's effects go on ITS OWN arrow — that is the Stage 2 boundary
 * rule: `makeCallback() := (() ↦ Random())` is itself pure, with result type
 * `() random -> …`.
 */
/**
 * The COLLECTION type inference gave a bare (unannotated) parameter, or
 * `undefined` to leave its arrow slot `unknown` as before.
 *
 * A parameter operand denotes the one binding the literal's body Block
 * declares for it (`bindParameterOperands`), so its `.type` is whatever the
 * body's uses inferred — `At(v, 1)` narrows `v` to `indexed_collection |
 * dictionary` through `At`'s signature. Surfacing that on the arrow is what
 * makes `paramsAreScalar` false, so a list argument is APPLIED to the lambda
 * instead of being broadcast element-wise over it (`h([3,4])` → `7`, not
 * `[h(3), h(4)]`).
 *
 * Deliberately narrow: the inferred type must EXCLUDE every scalar, so only a
 * parameter that cannot be a scalar is lifted. A parameter inferred `number`
 * (the overwhelmingly common case, `x ↦ 2x`) keeps an `unknown` slot so the
 * `broadcastable<T>` lift still fires; so does a function-typed one (a
 * higher-order callback slot), and — the trap — so does an INDEX parameter:
 * `At`'s index slot is
 * `boolean | character | indexed_collection | number | string` (a gather
 * index may itself be a collection), so `(t) ↦ L[t] + 1` must keep
 * `t` unlifted even though one arm of that union is a collection.
 */
export function inferredCollectionParameterType(
  param: Expression | undefined
): Type | undefined {
  if (param === undefined || !isSymbol(param)) return undefined;
  const t = param.type.type;
  if (t === 'unknown' || t === 'any' || t === 'value' || t === 'nothing')
    return undefined;
  if (!excludesEveryScalar(t) || isSubtype(t, 'function')) return undefined;
  return t;
}

/** True when NO value of `t` is a scalar — every arm of a union has to be
 * collection-like. (`isScalarType` of a union is the dual "every arm is a
 * scalar", which is not the question here.) A wide type (`any`,
 * `expression`, `value`) admits scalars, so it does not exclude them, even
 * though `isScalarType` reads it as "not scalar" (a parameter declared with
 * it receives a collection whole). */
function excludesEveryScalar(t: Type): boolean {
  if (isWideParameterType(t)) return false;
  if (typeof t === 'object' && t.kind === 'union')
    return t.types.every((m) => excludesEveryScalar(m));
  return !isScalarType(t);
}

/**
 * The signature type of a bare parameter that the body CONSUMES WHOLE, or
 * `undefined` when no use of the parameter does.
 *
 * A user function whose parameter slot reads as a scalar is applied to each
 * element of a list argument (auto-broadcast). That is only right when every
 * use of the parameter is element-wise. The body of
 * `function h(xs) { mean(xs) }` reads a list argument as one data set, so
 * `h([1, 2, 3])` must be `2`, not `[1, 2, 3]` (user decision 2026-09-29).
 * The reference is the body with the argument substituted: the function
 * applied to a list gives the same value as its body with that list in
 * place of the parameter. So a parameter that is used both whole and
 * element-wise (`mean(xs) + xs`) is consumed whole too: the element-wise
 * use then broadcasts inside the body, as it does in the substituted body.
 *
 * A use is WHOLE only when all of these hold:
 * - The operand REACHES the parameter: it is the parameter itself, or an
 *   application of an element-wise (`broadcastable`) operator with such an
 *   operand (`mean(xs^2)`, `variance(xs - c)`): with the list bound whole,
 *   the element-wise operator maps over it and the reducer reads the
 *   result, the mean of the squares. The compiled form of such a function
 *   follows: a call with a list argument at the lifted slot compiles a
 *   helper specialized to the argument's list type, whose body maps the
 *   element-wise operators over the array
 *   (`ensureSpecializedUserCallEmitted`, `compilation/base-compiler.ts`),
 *   so the two routes agree.
 * - The operand is the ONLY operand of that application: `mean(xs)`
 *   counts, `mean(x, 1)`, `max(x, 0)` and `hypot(x, 1)` do not. With several
 *   operands the operator reads each operand as one datum, and a function
 *   such as `g(x) = mean(x, 1)` called with a list of sample values must give
 *   one value per sample (`[1, 1.5, 2]` for `[1, 2, 3]`).
 * - The operator is not element-wise (`broadcastable`), and its declared
 *   slot type has a collection arm. A tuple, record or function arm does not
 *   count: a tuple is a point or a color read as one atomic value, which the
 *   broadcast never descends into. A slot typed only by a top type (`value`,
 *   `any`) does not count either: those are containers and structural
 *   operators such as `List`, `Tuple` or `Equal`, and `(t) ↦ (cos(t),
 *   sin(t))` must keep mapping over a list of parameters. The exceptions are
 *   the operators in {@link TOP_SLOT_WHOLE_COLLECTION_OPERATORS}.
 * - The operator is not `Norm`. Its slot (`number | tensor | tuple |
 *   list<tuple>`) has collection arms, but a graphing application calls
 *   `d(p) = norm(p)` with a LIST OF POINTS and expects one norm per point,
 *   and the compiled form reduces a whole array to one scalar
 *   (`_SYS.norm`). A list of vectors given to `len(v) = norm(v)` is also
 *   applied element by element on both routes, and must not become one
 *   norm of the whole matrix.
 *
 * So the operators covered are `Mean`, `Median`, `Variance`,
 * `StandardDeviation`, `Mode`, `Quartiles`, `Max`, `Min`, `GCD`, `LCM`,
 * `Sum`, `Product`, `Flatten`, `ListFrom`, `SetFrom` and `TupleFrom`. `String` is
 * element-wise: `label(p) = String(p)` over a list gives one string per
 * element.
 *
 * The returned slot is the unreduced union `collection<any> | value`. The
 * collection arm makes `paramsAreScalar` read the slot as one that admits a
 * collection, so a list argument is bound whole. The `value` arm admits
 * every argument the unlifted `unknown` slot admitted: the type the body's
 * uses infer for the parameter (often `real`) is not an argument contract,
 * so a point, a complex number or a string is still accepted and reaches
 * the body as before. Reducing the union would give `value`, which reads as
 * a scalar slot.
 *
 * A parameter with a declared type is never lifted: it is not a bare symbol
 * (it is a `Typed` operand of the `Function` literal), so this function
 * returns `undefined` for it and the declaration is the slot.
 *
 * Limitations:
 * - A copy of the parameter into a local is not a use of the parameter:
 *   `function h(xs) { let ys = xs; mean(ys) }` is applied to each element of
 *   a list (user decision 2026-11-14); `h(xs: list)` takes it whole. A
 *   call to another user function is a
 *   use like any other: `k(xs) = h(xs)` is lifted when the slot of `h` is lifted, because
 *   that slot then has a collection arm. It is the only way the lift reaches
 *   through a function, and it reads the signature of `h` as it is when the
 *   signature of `k` is derived. With `ce.assign()`, both definition orders
 *   give the same result: the definition of `h` derives the signature of
 *   `k` again (`repairProvisionalDependents()`, `function-utils.ts`). In a
 *   `Block`, `h` is read through the definition that the call dispatches to
 *   when the signature of `k` is derived ({@link calledOperatorDefinition}),
 *   and the `Assign` of `h` derives the signature of `k` again when an
 *   earlier statement of the same run of the block assigned `k`
 *   (`afterFunctionAssignment()`, `function-utils.ts`), so both orders give
 *   the same result there too. Two cases still depend on the order: a `k`
 *   with an annotated parameter, whose signature is derived from the type
 *   of its literal when it is assigned, and an `Assign` of `h` that is not
 *   a statement of the same list (inside an `If` or a nested `Block`). The
 *   tests in `test/compute-engine/whole-collection-parameter.test.ts` pin
 *   both orders.
 * - A local of the body assigned a function literal before the call
 *   (`let h = (t) => count(t)` or `h = (t) => count(t)`, then `h(xs)`) is
 *   read through the record of that literal, made when the walk meets the
 *   assignment ({@link literalFirstSlotCollectionArm}): the call has no
 *   definition to read, because the signature of the enclosing function is
 *   derived before its body runs. The record is the last literal assigned
 *   to the name before the call in the order of the body. A record made
 *   inside a nested function literal or block ends with it. A plain
 *   assignment there (`h = …` in a branch of an `If`) also removes the
 *   record that the name had before, so a call after the `If` gives no
 *   evidence through it.
 *   `localFunctions` holds the records of an enclosing
 *   body, read when the body of one of its literals is walked (the chain
 *   `h = …; q = (a) => h(a)`).
 * - An operator whose signature is an overload set (an intersection of
 *   arms, such as `Take` and `Drop`) is not read. Those two check their
 *   operands with their own validation.
 * - Once one parameter is bound whole, NO parameter of the function is
 *   applied element by element: a list given to another parameter is bound
 *   whole too.
 */
export function wholeCollectionParameterType(
  param: Expression | undefined,
  body: Expression | undefined,
  localFunctions?: ReadonlyMap<string, Type>
): Type | undefined {
  if (param === undefined || body === undefined || !isSymbol(param))
    return undefined;
  const binding = param.valueDefinition;
  if (binding === undefined) return undefined;

  // The locals of the body assigned a function literal whose first slot
  // has a collection arm, with that arm. When the body is boxed, the call
  // `h(xs)` is bound to the body-local placeholder of `h`, which has no
  // definition yet, so the call gives no evidence through a definition.
  // The record is copied from `localFunctions`: the locals of an enclosing
  // body that are visible here (the chain `let q = (a) => h(a)`).
  const localFunctionArms = new Map<string, Type>(localFunctions);
  // The local function names that an enclosing inner function literal binds
  // as its own parameters: inside it, that name is the inner parameter, not
  // the local function.
  let shadowed = new Set<string>();
  // Whether `e` reaches the parameter: it is the parameter, or an
  // element-wise (`broadcastable`) application with an operand that does
  // (`xs^2`, `xs - c`). A bound symbol is matched by its binding. A RAW
  // symbol (one with no binding: the operands of a canonical `Declare` are
  // held raw) is matched by name.
  const reaches = (e: Expression): boolean => {
    if (isSymbol(e))
      return e.valueDefinition === undefined
        ? e.symbol === param.symbol
        : e.valueDefinition === binding;
    if (!isFunction(e)) return false;
    const def = e.operatorDefinition;
    if (def === undefined || !def.broadcastable) return false;
    return e.ops.some(reaches);
  };

  // A shared subexpression is walked once.
  const seen = new Set<Expression>();
  const arms: Type[] = [];
  // A nested function literal or block is a scope: a helper that it
  // declares with `let` (`if c { let h = (t) => count(t) }`) is not the
  // local `h` of the body after it, so the records are put back as they
  // were when the walk leaves it. A plain assignment (`h = …`) in it can
  // write the local of the body, but only when the branch runs or the
  // literal is called, so after the scope the name has no record, and a
  // call of it gives no evidence. `scopeWrites` holds the names that a
  // plain assignment wrote in each scope that the walk is in.
  const scopeWrites: Set<string>[] = [];
  const visit = (expr: Expression): void => {
    if (!isFunction(expr, 'Function') && !isFunction(expr, 'Block')) {
      visitNode(expr);
      return;
    }
    const outer = [...localFunctionArms];
    const writes = new Set<string>();
    scopeWrites.push(writes);
    visitNode(expr);
    scopeWrites.pop();
    localFunctionArms.clear();
    for (const [name, arm] of outer) localFunctionArms.set(name, arm);
    for (const name of writes) {
      localFunctionArms.delete(name);
      scopeWrites.at(-1)?.add(name);
    }
  };
  const visitNode = (expr: Expression): void => {
    if (!isFunction(expr) || seen.has(expr)) return;
    seen.add(expr);
    // `h := …` is an `Assign`; the canonical `let h = …` of a block is a
    // `Declare` whose second operand is a dictionary with the entry
    // `value: …`.
    if (
      (expr.operator === 'Assign' || expr.operator === 'Declare') &&
      expr.nops === 2 &&
      isSymbol(expr.op1)
    ) {
      const value =
        expr.operator === 'Assign' ? expr.op2 : declaredValueOf(expr.op2);
      const local = expr.op1;
      // A local assigned a function literal (`let h = (t) => count(t)` or
      // `h = (t) => count(t)`) records the collection arm of the first slot
      // of that literal, read now, so that a later `h(xs)` reads it. Any
      // other value assigned to the name removes the record.
      localFunctionArms.delete(local.symbol);
      if (expr.operator === 'Assign') scopeWrites.at(-1)?.add(local.symbol);
      if (isFunction(value, 'Function')) {
        const arm = literalFirstSlotCollectionArm(value, localFunctionArms);
        if (arm !== undefined) localFunctionArms.set(local.symbol, arm);
      }
    }
    if (expr.nops === 1 && reaches(expr.op1)) {
      // A call bound to an operator definition (a library operator, or a
      // function declared with `function h(t) { … }`) is not a call of a
      // local assigned a literal, so it reads that definition.
      const localArm =
        expr.operatorDefinition !== undefined || shadowed.has(expr.operator)
          ? undefined
          : localFunctionArms.get(expr.operator);
      if (localArm !== undefined) arms.push(localArm);
      else {
        const def = expr.operatorDefinition ?? calledOperatorDefinition(expr);
        const arm =
          def === undefined
            ? undefined
            : wholeCollectionSlotArm(expr.operator, def);
        if (arm !== undefined) arms.push(arm);
      }
    }
    if (expr.operator === 'Function') {
      const names = expr.ops
        .slice(1)
        .flatMap((p) => functionLiteralParameterNames(p))
        .filter((n) => localFunctionArms.has(n));
      if (names.length > 0) {
        const outer = shadowed;
        shadowed = new Set([...outer, ...names]);
        for (const op of expr.ops) visit(op);
        shadowed = outer;
        return;
      }
    }
    for (const op of expr.ops) visit(op);
  };
  visit(body);
  if (arms.length === 0) return undefined;
  return { kind: 'union', types: [widenAll(arms), 'value'] };
}

/**
 * The collection type of the slot that the bare parameter `param` fills
 * when the body `body` is one application of a function literal to which
 * `param` is passed as an argument, or `undefined`.
 *
 * The deferred residual of a partial application has this form: with
 * `F = (x, p) ↦ x + p[1] + p[2]`, `F(1)` is `(_1) ↦ Apply(F, 1, _1)`, where
 * `F` is the literal (`makeLambda` in `function-utils.ts`). The only use of
 * `_1` is an argument of `Apply`, so the other rules find no collection use
 * of it, and its slot was `unknown`. A list argument was then applied to the
 * residual element by element: `Apply(F(1), [2, 3])` was a list of two
 * `incompatible-type` errors, while the full call `F(1, [2, 3])` binds the
 * list whole to `p` and is `6`. Now the parameter takes the slot type that
 * the same rules give to the parameter of the called literal at its
 * position (`p` here), so a list argument is bound whole exactly when the
 * full call binds it whole. Like the other inferred slot types, it is not an
 * annotation, and an argument is not validated against it.
 *
 * The parameter must be one operand of the application, and must not occur
 * in another operand. An operand before it that is a `Spread`, or a slot of
 * the called literal that is a rest parameter or an annotated or a
 * destructuring parameter, gives `undefined`.
 */
function forwardedCollectionParameterType(
  param: Expression | undefined,
  body: Expression | undefined
): Type | undefined {
  if (param === undefined || body === undefined || !isSymbol(param))
    return undefined;
  // The application, inside the scoped `Block` of the body and the
  // return-type marker of the literal.
  let call = body;
  while (
    (isFunction(call, 'Block') && call.nops === 1) ||
    (isFunction(call, 'Typed') && call.nops === 2)
  )
    call = call.op1;
  if (!isFunction(call, 'Apply') || !isFunction(call.op1, 'Function'))
    return undefined;
  const callee = call.op1;
  const operands = call.ops.slice(1);
  const isParam = (op: Expression): boolean =>
    isSymbol(op) &&
    (op.valueDefinition !== undefined
      ? op.valueDefinition === param.valueDefinition
      : op.symbol === param.symbol);
  const at = operands.findIndex(isParam);
  if (at < 0) return undefined;
  if (operands.slice(0, at).some((op) => isFunction(op, 'Spread')))
    return undefined;
  if (
    operands.some(
      (op, i) => i !== at && !isParam(op) && op.symbols.includes(param.symbol)
    ) ||
    operands.filter(isParam).length !== 1
  )
    return undefined;
  const calleeParams = callee.ops.slice(1);
  const restAt = restParameterIndex(calleeParams);
  if (restAt >= 0 && at >= restAt) return undefined;
  const slot = calleeParams[at];
  if (slot === undefined || !isSymbol(slot)) return undefined;
  const calleeBody = functionLiteralBody(callee);
  return (
    inferredCollectionParameterType(slot) ??
    wholeCollectionParameterType(slot, calleeBody) ??
    forwardedCollectionParameterType(slot, calleeBody)
  );
}

/**
 * The `value` entry of the dictionary operand of a canonical `Declare`
 * (`Declare(ys, {value: xs})`, the form of `let ys = xs` in a block: the
 * operand is a dictionary VALUE, written `Dictionary(KeyValuePair("value",
 * xs))` in MathJSON), or `undefined` when there is none.
 */
function declaredValueOf(spec: Expression): Expression | undefined {
  if (isDictionary(spec)) return spec.get('value');
  if (!isFunction(spec, 'Dictionary')) return undefined;
  for (const entry of spec.ops) {
    if (!isFunction(entry, 'KeyValuePair') || entry.nops !== 2) continue;
    const key = entry.op1;
    if (isString(key) && key.string === 'value') return entry.op2;
  }
  return undefined;
}

/**
 * The operator definition that the application `expr` dispatches to now,
 * when its operator name is bound to a VALUE definition, or `undefined`.
 *
 * A function that a `Block` assigns (`Assign(h, t ↦ Count(t))`) has no
 * definition when the block is boxed: the call `h(a)` in the body of a
 * second function of the same block is bound to the block-local value
 * placeholder of `h`, which has no value and no type. When the `Assign`
 * runs, it gives `h` an OPERATOR definition, and the evaluation of `h(a)`
 * dispatches through that definition (`applyFunctionLiteralWith()`,
 * `boxed-function.ts`). The same lookup here lets the signature of the
 * second function read the slot of `h`: with
 * `Block(Assign(h, t ↦ Count(t)), Assign(q, a ↦ h(a)), q([1, 2]))`, the slot
 * of `a` takes the collection arm of the slot of `t`, and the list is bound
 * whole (`2`), as it is when `ce.assign()` defines both functions. Without
 * it, `q` is applied to each element, and each element gives an
 * `incompatible-type` error.
 *
 * The lookup reads the definitions in the current scope chain, so the
 * result depends on the time the signature is derived. When the callee has
 * no operator definition at that time (`h` is assigned AFTER `q` in the
 * block), the call gives no evidence, and the slot is element-wise until
 * the `Assign` of `h` derives the signature of `q` again
 * (`afterFunctionAssignment()`, `function-utils.ts`).
 */
function calledOperatorDefinition(
  expr: Expression
): BoxedOperatorDefinition | undefined {
  const own = expr.valueDefinition;
  if (own === undefined) return undefined;
  const binding = callableBindingInContext(expr.engine, expr.operator, {
    value: own,
  });
  return binding !== undefined && 'operator' in binding
    ? binding.operator
    : undefined;
}

/**
 * The collection arm of the first slot of the function literal `literal`,
 * or `undefined` when that slot has none.
 *
 * It is the evidence that a call `h(xs)` gives when a function body assigns
 * the literal to the local `h` (`let h = (t) => count(t)` or
 * `h = (t) => count(t)`) before the call. The signature of the enclosing
 * function is derived when that function is defined, before its body runs,
 * so the call is bound to the body-local placeholder of `h`, which has no
 * definition, and {@link calledOperatorDefinition} finds none. With this
 * evidence, `function f(xs) { let h = (t) => count(t); h(xs) }` binds the
 * list of `f([1, 2])` whole and gives `2`, as it does when `h` is declared
 * with `function h(t) { count(t) }`. Without it, `f` is applied to each
 * element, and each element gives an `incompatible-type` error.
 *
 * The slot is first read from the declared signature of the literal, or
 * from its parameter slots ({@link functionLiteralParameterSlots}), which
 * cover a declared parameter type and the rules of {@link
 * wholeCollectionParameterType} for a bare parameter. Neither reads the type
 * of the body of the literal, so the walk can run while an enclosing call
 * is being boxed. When the body of the
 * literal calls another local function of the same enclosing body (the chain
 * `let h = …; let q = (a) => h(a)`), the type of the literal does not know
 * the local, so a bare parameter is read again with `localFunctions`, the
 * records of the locals assigned before the literal. A record whose name is
 * a parameter of the literal is left out: inside the literal, that name is
 * the parameter.
 */
function literalFirstSlotCollectionArm(
  literal: Expression,
  localFunctions: ReadonlyMap<string, Type>
): Type | undefined {
  // A literal held raw (not canonical) has no type to read.
  if (!isFunction(literal, 'Function') || !literal.isCanonical)
    return undefined;
  const declared = functionLiteralDeclaredSignature(literal);
  if (declared !== undefined)
    return firstSlotCollectionArm(declared, undefined);
  const body = functionLiteralBody(literal);
  if (body === undefined) return undefined;
  const slot = functionLiteralParameterSlots(literal, body)?.[0];
  if (slot === undefined) return undefined;
  const arm = collectionArm(slot.type);
  if (arm !== undefined || localFunctions.size === 0) return arm;
  const params = literal.ops.slice(1);
  const target = optionalParameterTarget(params[0]);
  if (target === undefined || !isSymbol(target)) return undefined;
  const ownNames = new Set(
    params.flatMap((p) => functionLiteralParameterNames(p))
  );
  const visible = new Map(
    [...localFunctions].filter(([name]) => !ownNames.has(name))
  );
  if (visible.size === 0) return undefined;
  const t = wholeCollectionParameterType(target, body, visible);
  return t === undefined ? undefined : collectionArm(t);
}

/**
 * The operators whose slot type is a top type (`value` or `any`) but that
 * read a collection operand WHOLE: `Flatten`, `SetFrom` and `TupleFrom` take
 * the elements of the collection. Their signatures cannot say so: a slot
 * written `collection<any> | value` does mark the collection arm, but a FREE
 * symbol at that slot is then narrowed to that union, and an arithmetic use
 * of the symbol (`x + 1`) is then typed as a collection instead of `number`.
 * So the fact is recorded here, where only the signature of a user function
 * reads it.
 *
 * `Max`, `Min`, `GCD`, `LCM`, `Sum`, `Product` and `ListFrom` read a
 * collection operand whole too, and are listed. A compiled call with a list
 * argument at a lifted slot compiles a helper specialized to the argument's
 * list type, which reduces the array (`ensureSpecializedUserCallEmitted`,
 * `compilation/base-compiler.ts`); where no such helper can be emitted the
 * compilation declines and the interpreter answers, so the two routes
 * agree. `SetFrom` and `TupleFrom` have no JavaScript lowering, and
 * `Flatten` declines an operand that is not typed as an indexed collection.
 */
const TOP_SLOT_WHOLE_COLLECTION_OPERATORS: ReadonlySet<string> = new Set([
  'Flatten',
  'SetFrom',
  'TupleFrom',
  'Max',
  'Min',
  'GCD',
  'LCM',
  'ListFrom',
  // `Sum(L)` and `Product(L)` with one operand reduce the collection; their
  // slot is `any` because the operand is a body under `Limits` otherwise.
  'Sum',
  'Product',
]);

/**
 * The collection arm of the slot that the LONE operand of an application of
 * `operator` (whose definition is `def`) fills, when that operand is consumed
 * WHOLE; `undefined` when the operand is element-wise or the slot has no
 * collection arm. See {@link wholeCollectionParameterType} for the rule.
 */
function wholeCollectionSlotArm(
  operator: string,
  def: BoxedOperatorDefinition
): Type | undefined {
  if (def.broadcastable || operator === 'Norm') return undefined;
  return firstSlotCollectionArm(def.signature?.type, operator);
}

/**
 * The collection arm of the first slot of the signature `sig`, or
 * `undefined`. `operator` is the name of the operator that has this
 * signature, or `undefined` for a function literal: a slot typed `value` or
 * `any` counts as a collection arm only for the operators in
 * {@link TOP_SLOT_WHOLE_COLLECTION_OPERATORS}.
 */
function firstSlotCollectionArm(
  sig: Type | undefined,
  operator: string | undefined
): Type | undefined {
  if (sig === undefined || typeof sig === 'string' || sig.kind !== 'signature')
    return undefined;
  const slot = signatureSlotType(sig, 0);
  if (slot === undefined) return undefined;
  const t = substituteDeclaredBounds(sig.typeParams, slot);
  if (
    (t === 'value' || t === 'any') &&
    operator !== undefined &&
    TOP_SLOT_WHOLE_COLLECTION_OPERATORS.has(operator)
  )
    return { kind: 'collection', elements: 'any' };
  return collectionArm(t);
}

/**
 * The union of the members of `t` that are collection types, or
 * `undefined` when no member is one.
 */
function collectionArm(t: Type): Type | undefined {
  const members = typeof t === 'object' && t.kind === 'union' ? t.types : [t];
  // A wide arm (`any`, `expression`, `value`) is not a collection arm:
  // `isScalarType` reads it as "not scalar" only because a parameter
  // declared with it receives a collection whole. The listed operators
  // above are the only ones whose wide slot is read as a whole collection.
  const collections = members.filter(
    (m) =>
      !isWideParameterType(m) &&
      !isScalarType(m) &&
      !isSubtype(m, 'function') &&
      !isTupleOrTupleUnionShapedType(m) &&
      !isRecordOrRecordUnionShapedType(m)
  );
  return collections.length === 0 ? undefined : widenAll(collections);
}

/**
 * The collection type that the SELF-CALLS of a named user function give to
 * each of its parameters, by position. An entry is `undefined` when no
 * self-call gives evidence for that parameter. `params` is the whole
 * parameter list of the function literal, a rest parameter included.
 *
 * A call of the function to itself that passes a collection at the position
 * of a parameter is strong evidence that the parameter takes a whole
 * collection (user decision 2026-10-08). Without this evidence, the body of
 * `f(n, s) = s if n == 0 else f(n - 1, [1, 2])` never indexes, measures or
 * iterates `s`, so the slot of `s` reads as a scalar and `f(1, [0])` maps
 * over `[0]` and gives `[[1, 2]]`. With it, the slot of `s` is
 * `list<any>`, the list argument binds whole, and the result is `[1, 2]`.
 *
 * The evidence is read from the body SYNTACTICALLY: the static type of each
 * argument of each self-call, as the canonical body records it. The function
 * is not re-derived against its own signature, because that is the signature
 * this evidence helps to build. While a recursive body canonicalizes, a
 * self-call types `unknown`, so a self-call nested in an argument
 * (`f(n - 1, f(n - 1, s))`) gives no evidence.
 *
 * Rules:
 * - A self-call is an application whose operator is `selfName`, at any depth
 *   of the body (inside `If` branches, blocks and nested function literals).
 *   When `literal` is given, an application whose operator is another name
 *   that holds `literal` as its value now is a self-call too. The same
 *   function can be held by two names (`b = a`), and the evidence must not
 *   change with the name a call uses.
 * - An argument gives evidence only when its static type is a collection
 *   (`collection<any>` shape) and is not a string, a tuple or a record. Those
 *   three are read as one atomic value, and a broadcast never descends into
 *   them. The tuple and the record tests read the shape of the type, so a
 *   tuple or a record with an absent slot (`tuple<integer, missing>`) is
 *   excluded too.
 * - Only a parameter that is a bare symbol takes evidence (or one that
 *   carries an annotation written by inference, not by the author). An
 *   annotated parameter keeps the type its author wrote, a destructuring
 *   parameter keeps its tuple type, and a rest parameter has no position.
 * - An argument that is a parameter of the function, forwarded bare, gives no
 *   new information: `walk(xs, k - 1)` leaves `xs` as it is. A scalar
 *   argument (`n - 1`) gives no evidence either.
 * - A self-call that contains a spread argument is skipped, because its
 *   arguments do not map to positions.
 * - The walk does not enter a part of the body where `selfName` is bound to
 *   something else, because a call of that name there calls another function.
 *   Such a part is a nested function literal with a parameter of that name
 *   (bare, annotated, destructuring or rest), or an expression whose local
 *   scope binds the name: a block with a local declaration (`let f = 0`), a
 *   comprehension or a loop with an index of that name, a `Sum` or a
 *   `Product` with an index of that name. The self-calls in the other parts
 *   of the body are still evidence.
 * - There is no evidence at all when a parameter has the same name as the
 *   function, or when the body assigns or defines the name outside every
 *   local scope that binds it (`f = g`): after such an assignment, the name
 *   can refer to another function.
 *
 * The type of an entry is `list<any>` when every argument at that position
 * is a list, `indexed_collection<any>` when every argument is indexed, and
 * `collection<any>` otherwise. The type excludes every scalar, so the
 * parameter is not a scalar slot and a call does not broadcast over a
 * collection argument.
 *
 * The element type of the arguments is NOT kept. A self-call shows only
 * that the parameter takes a collection; the callers outside the function
 * can pass any elements. A caller that forwards its own parameter to this
 * slot is narrowed to the slot type, so `list<integer>` (from `[1, 2]`)
 * made `h(t) = f(0, t)[1]` claim an `integer` result while `h([0.25])`
 * gives `0.25`.
 */
export function selfCallCollectionParameterTypes(
  selfName: string,
  params: readonly Expression[],
  body: Expression | undefined,
  literal?: Expression
): (Type | undefined)[] {
  const sites = selfCallSites(selfName, params, body);
  if (sites === undefined) return [];
  return selfCallEvidence(sites, readSelfCalls(sites, selfName, literal));
}

/** The parts of the body of a function literal that the self-call evidence
 * reads, for one name of the function. They depend only on the structure of
 * the literal and on the name, so they are found once for each pair. See
 * {@link selfCallCollectionParameterTypes}. */
interface SelfCallSites {
  /** The names the parameter list binds. */
  paramNames: ReadonlySet<string>;
  /** For each parameter before the rest parameter: whether it takes
   * evidence. */
  takesEvidence: readonly boolean[];
  /** The applications with no spread argument, outside every part of the body
   * where the name is bound to something else, that are a self-call or can
   * become one: the operator is the name, or the operator is a name that is
   * held as a value (it can hold the function literal now or later). */
  calls: readonly (Expression & FunctionInterface)[];
}

/** The {@link SelfCallSites} of the function named `selfName`, or `undefined`
 * when its self-calls give no evidence at all. See
 * {@link selfCallCollectionParameterTypes} for the rules. */
function selfCallSites(
  selfName: string,
  params: readonly Expression[],
  body: Expression | undefined
): SelfCallSites | undefined {
  if (body === undefined || params.length === 0) return undefined;
  // Every name the parameter list binds: the names in a destructuring
  // pattern, the name of an annotated parameter and the rest parameter.
  const paramNames = new Set(functionLiteralBoundNames(params));
  if (paramNames.has(selfName)) return undefined;
  const restAt = restParameterIndex(params);
  const positional = restAt < 0 ? params : params.slice(0, restAt);
  const takesEvidence = positional.map(
    (p) => isSymbol(p) || isInferredTypedParameter(p)
  );

  const calls: (Expression & FunctionInterface)[] = [];
  let rebound = false;
  const seen = new Set<Expression>();
  const visit = (expr: Expression): void => {
    if (rebound || !isFunction(expr) || seen.has(expr)) return;
    seen.add(expr);
    if (bindsNameLocally(expr, selfName)) return;
    const head = expr.operator;
    if (
      (head === 'DefineFunction' || head === 'Declare' || head === 'Assign') &&
      sym(expr.op1) === selfName
    ) {
      rebound = true;
      return;
    }
    if (
      (head === selfName || expr.valueDefinition !== undefined) &&
      !expr.ops.some((x) => x.operator === 'Spread')
    )
      calls.push(expr);
    for (const op of expr.ops) visit(op);
  };
  visit(body);
  if (rebound) return undefined;
  return { paramNames, takesEvidence, calls };
}

/** True when the expression `expr` binds `name` for its own operands, so that
 * the name does not refer to the enclosing function inside it. See
 * {@link selfCallCollectionParameterTypes}. Three cases:
 *
 * - a function literal with a parameter of that name (bare, annotated,
 *   destructuring or rest);
 * - a binder with an index of that name (a comprehension, a loop, a `Sum`
 *   or a `Product`), as its binding sites declare it (`declaredBinders`);
 * - a block with a statement that declares or defines the name
 *   (`let f = 0` is `Declare(f, …)`).
 *
 * The local scope of a block is not read. A name that a body calls before
 * it is defined (`let r = (n, s) => … r(n - 1, [1, 2])`) is declared in the
 * local scope of the body's block when the body canonicalizes, although the
 * call reaches the outer function. A binding there is not a shadow. */
function bindsNameLocally(expr: Expression, name: string): boolean {
  if (isFunction(expr, 'Function'))
    return functionLiteralBoundNames(expr.ops.slice(1)).includes(name);
  if (isFunction(expr, 'Block'))
    return expr.ops.some(
      (x) =>
        (x.operator === 'Declare' || x.operator === 'DefineFunction') &&
        isFunction(x) &&
        sym(x.op1) === name
    );
  return declaredBinders(expr, 'post')?.visibleFrom.has(name) === true;
}

/** The kind of collection a self-call argument is, as evidence: a list, an
 * indexed collection that is not a list, or another collection. */
type SelfCallArgumentKind = 'list' | 'indexed' | 'collection';

/**
 * What the calls of `sites` give now: for each call, the kind of each
 * argument that is evidence (`undefined` for an argument that is not), or
 * `null` when the call is not a self-call now.
 *
 * A call is a self-call when its operator is `selfName`, or when its operator
 * is a name that holds `literal` as its value now. The same function can be
 * held by two names (`b = a`), and the evidence must not change with the
 * name a call uses.
 *
 * This reads the static types of the arguments and the values of the callee
 * names, which assignments can change. It does not walk the body.
 */
function readSelfCalls(
  sites: SelfCallSites,
  selfName: string,
  literal: Expression | undefined
): ((SelfCallArgumentKind | undefined)[] | null)[] {
  return sites.calls.map((call) => {
    if (
      call.operator !== selfName &&
      (literal === undefined || call.valueDefinition?.value !== literal)
    )
      return null;
    const n = Math.min(call.nops, sites.takesEvidence.length);
    const kinds: (SelfCallArgumentKind | undefined)[] = [];
    for (let i = 0; i < n; i++) {
      const arg = call.ops[i];
      kinds.push(
        !sites.takesEvidence[i] ||
          (isSymbol(arg) && sites.paramNames.has(arg.symbol))
          ? undefined
          : selfCallArgumentKind(arg.type.type)
      );
    }
    return kinds;
  });
}

/** The kind of a self-call argument of type `t` when it is evidence that the
 * parameter takes a whole collection, or `undefined`. See
 * {@link selfCallCollectionParameterTypes}. */
function selfCallArgumentKind(t: Type): SelfCallArgumentKind | undefined {
  if (
    t === 'unknown' ||
    t === 'any' ||
    t === 'nothing' ||
    !isSubtype(t, COLLECTION_SHAPE_TYPE) ||
    isSubtype(t, 'string') ||
    isTupleShapedType(t) ||
    isRecordShapedType(t)
  )
    return undefined;
  if (isSubtype(t, 'list<any>')) return 'list';
  if (isSubtype(t, INDEXED_COLLECTION_SHAPE_TYPE)) return 'indexed';
  return 'collection';
}

/** The parameter types that the self-calls read by {@link readSelfCalls}
 * give, by position: `list<any>` when every argument at that position is a
 * list, `indexed_collection<any>` when every argument is indexed, and
 * `collection<any>` otherwise. */
function selfCallEvidence(
  sites: SelfCallSites,
  reads: readonly ((SelfCallArgumentKind | undefined)[] | null)[]
): (Type | undefined)[] {
  return sites.takesEvidence.map((_, i) => {
    let found = false;
    let allLists = true;
    let allIndexed = true;
    for (const kinds of reads) {
      const kind = kinds?.[i];
      if (kind === undefined) continue;
      found = true;
      if (kind !== 'list') allLists = false;
      if (kind === 'collection') allIndexed = false;
    }
    if (!found) return undefined;
    if (allLists) return { kind: 'list', elements: 'any' };
    return allIndexed ? INDEXED_COLLECTION_SHAPE_TYPE : COLLECTION_SHAPE_TYPE;
  });
}

/** The memo of {@link namedLiteralSignatureType}. For each function literal,
 * there is one entry for each name the literal was read under. */
const NAMED_LITERAL_SIGNATURES = new WeakMap<
  Expression,
  Map<
    string,
    {
      /** The parts of the body the evidence reads, `undefined` when there is
       * no evidence. */
      sites: SelfCallSites | undefined;
      /** What the self-calls gave when `evidence` was computed, as a
       * string. */
      reads: string;
      evidence: (Type | undefined)[];
      /** The last signature the evidence was applied to, and the result. */
      base: Type;
      type: Type;
    }
  >
>();

/**
 * The signature type of the function literal `literal` when it is held as
 * the VALUE of the symbol `name`, with the self-call evidence of
 * {@link selfCallCollectionParameterTypes} applied to its parameter slots
 * that are `unknown`. A slot that takes evidence is a bare parameter, so a
 * slot the author annotated keeps its type, also when the annotation is
 * `unknown`.
 *
 * The literal's own type (`functionLiteralSignatureType`) cannot read the
 * self-calls, because a literal does not know the name it is stored under.
 * A function installed as an operator definition reads them when its
 * signature is derived. A function held as a value (a name that already had
 * a value binding, or a top-level `DefineFunction` on the MathJSON route)
 * has no derived signature, so the sites that apply or type a call of such
 * a value read the literal's type through this function instead. Without
 * it, the same program gives a different answer depending on the name of
 * the function.
 *
 * `base` is the signature to apply the evidence to. It is the literal's own
 * type by default. A value definition whose type was INFERRED from the
 * literal (`let r = (n, s) => …`) passes that inferred type, and an
 * operator definition whose signature was derived from an annotated literal
 * passes that signature.
 *
 * Returns `base` unchanged when it is not a signature, when it is generic,
 * or when no self-call gives evidence.
 *
 * The walk of the body runs once for each pair of literal and name. The
 * evidence depends on the static types of the self-call arguments and on
 * the names that hold the literal, which assignments can change (`v = [1, 2]`
 * for a variable `v` passed in a self-call, or `b = a`). So each use reads
 * the calls the walk found again (`readSelfCalls`), and computes the
 * evidence again only when that read differs. A key made of the engine's
 * version counters did not work: the evaluation of a call writes to the
 * engine, so each call in a loop of 1000 iterations walked the body again.
 */
export function namedLiteralSignatureType(
  name: string,
  literal: Expression,
  base: Type = literal.type.type
): Type {
  if (
    !isFunction(literal, 'Function') ||
    typeof base !== 'object' ||
    base.kind !== 'signature' ||
    base.args === undefined ||
    isPolymorphicType(base)
  )
    return base;
  let memos = NAMED_LITERAL_SIGNATURES.get(literal);
  if (memos === undefined) {
    memos = new Map();
    NAMED_LITERAL_SIGNATURES.set(literal, memos);
  }
  let memo = memos.get(name);
  const sites =
    memo !== undefined
      ? memo.sites
      : selfCallSites(name, literal.ops.slice(1), functionLiteralBody(literal));
  const read =
    sites === undefined ? undefined : readSelfCalls(sites, name, literal);
  const reads = JSON.stringify(read ?? null);
  if (memo !== undefined && memo.reads === reads && memo.base === base)
    return memo.type;
  const evidence =
    memo !== undefined && memo.reads === reads
      ? memo.evidence
      : sites === undefined
        ? []
        : selfCallEvidence(sites, read!);
  let type: Type = base;
  if (evidence.some((t) => t !== undefined)) {
    type = {
      ...base,
      args: base.args.map((arg, i) =>
        arg.type === 'unknown' && evidence[i] !== undefined
          ? { ...arg, type: evidence[i] }
          : arg
      ),
    };
  }
  memo = { sites, reads, evidence, base, type };
  memos.set(name, memo);
  return type;
}

/**
 * The signature of the function literal `expr` as a call site reads it
 * (`functionLiteralSignatureType()`). The type of an occurrence is read
 * through the definition that its name
 * resolves to in the current context, so the parameter and result types
 * are derived in the scope that the literal is written in, as its
 * evaluation reads that scope: with a global `P: list<real>` and
 * `angle := t ↦ P`, the result of `angle` read inside the body of a
 * function whose parameter is named `P` is still `list<real>`. The effects
 * are read from the scope the literal was boxed in, wherever they are
 * computed (`walkHome`).
 */
export function functionLiteralCallSignatureType(expr: Expression): Type {
  const ce = expr.engine;
  if (!isFunction(expr)) return functionLiteralSignatureType(expr);
  const body = expr.ops[0];
  const written = body?.isScoped ? body.localScope?.parent : undefined;
  if (!written || written === ce.context?.lexicalScope)
    return functionLiteralSignatureType(expr);
  // The scope of the literal first: the types that its derivation caches on
  // the body are those of that scope.
  const there = ce._inScope(written, () => functionLiteralSignatureType(expr));
  const here = functionLiteralSignatureType(expr);
  if (
    typeof here !== 'object' ||
    here.kind !== 'signature' ||
    typeof there !== 'object' ||
    there.kind !== 'signature'
  )
    return here;
  const { effects: _effects, ...shape } = there;
  return here.effects === undefined
    ? shape
    : { ...shape, effects: here.effects };
}

/**
 * The parameters of the signature that `functionLiteralCallSignatureType()`
 * gives for the `Function` literal `expr` (the argument slots, the optional
 * slots and the variadic tail, derived in the scope the literal is written
 * in), with the result `any` and no effects. It does not read the type of the
 * body, so a check of the arguments of a call does not type the body.
 *
 * `undefined` when `expr` is not a valid `Function` literal, or when it has a
 * full-signature marker (a generic literal states its parameters there): the
 * caller reads the type of the literal.
 */
export function functionLiteralParameterSignature(
  expr: Expression
): Type | undefined {
  if (!isFunction(expr, 'Function') || !expr.isValid) return undefined;
  if (functionLiteralDeclaredSignature(expr) !== undefined) return undefined;
  const body = functionLiteralBody(expr);
  if (body === undefined) return undefined;
  const ce = expr.engine;
  const paramOps = expr.ops.slice(1);
  const build = (): Type => ({
    kind: 'signature',
    ...signatureArgumentsOfSlots(
      paramOps,
      functionLiteralParameterSlots(expr, body)
    ),
    ...restParameterSignatureTail(paramOps),
    result: 'any',
  });
  const scoped = expr.ops[0];
  const written = scoped?.isScoped ? scoped.localScope?.parent : undefined;
  return withStaticTypingView(ce, () =>
    written && written !== ce.context?.lexicalScope
      ? ce._inScope(written, build)
      : build()
  );
}

/**
 * The positional parameter slots of the `Function` literal `expr` with the
 * body `body`, or `undefined` when it has none. A rest parameter is not a
 * slot: `restParameterSignatureTail()` gives its variadic tail.
 *
 * This reads the parameters and the structure of the body, never the body's
 * type, so it can run while an enclosing call is being boxed.
 */
export function functionLiteralParameterSlots(
  expr: Expression,
  body: Expression
): { name?: string; type: Type }[] | undefined {
  const params = functionLiteralParameters(expr);
  // Parameter slots: an annotated param carries its declared type, named
  // (`x: integer`); a bare param is `unknown` and keeps its name, so that a
  // named call can find the slot (`inferredSignatureParameterName`). The Type
  // OBJECT is carried through — never serialized and re-parsed: an annotation may name
  // a SCOPE-LOCAL type (resolved when the literal was canonicalized), and a
  // text round-trip here — possibly after that scope popped — either threw
  // `Unknown type` or silently dropped the annotation. Same hazard class as
  // the inferred-signature fix in `boxed-operator-definition.ts`.
  const paramOps = isFunction(expr, 'Function') ? expr.ops.slice(1) : [];
  // A REST parameter (`(a, ...rest) => …`) is not a positional slot: it
  // absorbs every argument from its position onwards, so it leaves the
  // signature's argument list and becomes the variadic tail.
  const restOp = restParameterIndex(paramOps);
  const fixedParams = restOp < 0 ? params : params.slice(0, restOp);
  if (fixedParams.length === 0) return undefined;
  return fixedParams.map((p, i) => {
    if (p.type !== undefined) return { name: p.name, type: p.type };
    // A DESTRUCTURING parameter (`((p, q)) => …`) states its own slot: the
    // tuple shape its pattern will match. See `destructuringParameterType`
    // for why the slot must not read as a bare `unknown` scalar.
    if (paramOps[i] !== undefined && isDestructuringParameter(paramOps[i]))
      return { type: destructuringParameterType(paramOps[i]) };
    // A parameter the body consumes whole is lifted too, even when its
    // inferred type admits a scalar (`wholeCollectionParameterType`).
    // A parameter that the body only passes to a slot of another literal
    // takes the collection type of that slot
    // (`forwardedCollectionParameterType`).
    // A parameter with a default value is read through its `Optional`
    // wrapper: the slot type does not depend on the default.
    const target =
      paramOps[i] === undefined
        ? undefined
        : optionalParameterTarget(paramOps[i]);
    const inferred =
      inferredCollectionParameterType(target) ??
      wholeCollectionParameterType(target, body) ??
      forwardedCollectionParameterType(target, body);
    const name =
      paramOps[i] !== undefined
        ? inferredSignatureParameterName(paramOps[i])
        : undefined;
    const type = inferred ?? ('unknown' as Type);
    return name !== undefined ? { name, type } : { type };
  });
}

export function functionLiteralSignatureType(expr: Expression): Type {
  const body = functionLiteralBody(expr);
  // A `Function` with no body (raw input held unbound by `Hold`) has no
  // signature to build: it is an error value, not a throw (CE-106).
  if (body === undefined) return 'error';

  // Result type: an explicit return-type ascription (the §4.2 marker) is
  // used verbatim, bypassing the widening rule. A Block's type is its last
  // statement's type, so `body.type` already surfaces the ascribed return.
  const ascribedReturn = functionLiteralReturnType(expr);
  // A FULL-SIGNATURE marker (`docs/EFFECTS-MODEL.md`, "Epsil surface") is the
  // trap here: `Typed`'s type handler surfaces the ascribed type verbatim, and
  // a Block's type is its last statement's, so `body.type` IS that whole
  // signature — meaningless as a body type. The last statement's OWN type
  // lives on the marker's first operand.
  const declaredSignature = functionLiteralDeclaredSignature(expr);
  const bodyTypeSource =
    declaredSignature === undefined
      ? body.type
      : functionLiteralReturnMarker(expr)!.op1.type;
  let bodyType: Type =
    declaredSignature !== undefined && ascribedReturn !== undefined
      ? ascribedReturn
      : bodyTypeSource.type;

  const paramOps = isFunction(expr, 'Function') ? expr.ops.slice(1) : [];
  const args = functionLiteralParameterSlots(expr, body);

  // A derived result reads a parameter of type `unknown` in a cell of a list
  // literal as a cell of unknown type, not as a number: `x ↦ [x]` has the
  // result `list`, not `vector<1>`, since `x` can receive any value
  // (`signatureResultType`). An ascribed result is the author's contract and
  // is kept.
  const sourceType = bodyType;
  if (ascribedReturn === undefined)
    bodyType = signatureResultType(
      declaredSignature === undefined
        ? body
        : functionLiteralReturnMarker(expr)!.op1,
      paramOps,
      bodyType
    );

  // The parameters of a bare function literal have unknown type, so a
  // finite-numeric body claim is unsound: the lambda may later be applied to
  // a non-finite argument — `(x ↦ x²)(∞) = +∞` — so widen a finite-numeric
  // result to the top numeric type `number`. (A nullary function has no such
  // parameter, so its exact body type is kept.)
  //
  // The widening fires only when at least ONE parameter slot could actually
  // inject a non-finite value into the body: a slot that stayed `unknown` (it
  // may bind anything), or one whose type overlaps `infinity` or `nan` (a
  // `number` slot, an `infinity` slot). Every other slot is provably unable to
  // bind a non-finite value and so gives the body no way to become non-finite:
  // since the finite-by-default flip the bare numeric names exclude the
  // infinities, so an `integer` parameter cannot bind `∞`; and a NON-numeric
  // slot — `collection`, `string`, `boolean` — is disjoint from the two
  // non-finite tiers as well, so a body such as `Length(r)` over
  // `r: collection` keeps its exact `integer` claim. The test reads the
  // ARROW's slots, computed above, so an inferred slot counts the same as an
  // annotated one.
  if (
    ascribedReturn === undefined &&
    args !== undefined &&
    (bodyType === sourceType
      ? bodyTypeSource.matches('complex')
      : isSubtype(bodyType, 'complex')) &&
    args.some(
      (a) =>
        !provablyDisjoint(a.type, 'infinity') ||
        !provablyDisjoint(a.type, 'nan')
    )
  )
    bodyType = 'number';

  // A DERIVED result type is a storage position: a NUMBER-LITERAL body's
  // type is literal cargo and projects to its tier (`() -> 21` types
  // `() -> integer`, not `() -> 21`; `() -> √2` types `() -> real`, not the
  // enclosure range — ruling O9's second half,
  // 2026-08-23). Any OTHER body keeps its type verbatim: a non-literal
  // body's type is already a stored/derived type (handler results are
  // widened where they are stored), and walking it here could rewrite a
  // NESTED authored contract (an inner ascribed `-> 0` in a returned
  // function literal). An ASCRIBED return is the author's contract and is
  // kept verbatim, literal or not (the same rule that keeps a declared
  // `(0) -> 0` signature).
  const derivedBodyExpr =
    declaredSignature === undefined
      ? body
      : functionLiteralReturnMarker(expr)!.op1;
  if (
    ascribedReturn === undefined &&
    derivedBodyExpr._literalType !== undefined
  )
    bodyType = stripNumericRanges(bodyType);

  if (ascribedReturn === undefined)
    bodyType = joinEarlyReturnTypes(derivedBodyExpr, args, bodyType);

  const effects = functionLiteralArrowEffects(expr);

  // A GENERIC marker (a `where` clause) is the literal's contract of record on
  // every TYPE axis: the clause, the argument types and the result are carried
  // VERBATIM. Under erasure the quantified parameter operands are bare symbols,
  // so the `args` assembled above would read `unknown` and the result would be
  // the body's ground type — both would silently drop the clause. Only the
  // EFFECTS axis is recomputed (`declared ∪ inferred`, above): the literal's own
  // arrow must stay a sound over-approximation even where the declared contract
  // is violated (`docs/EFFECTS-MODEL.md`). A closed polytype is a legal
  // `isPolymorphic` `BoxedType`.
  if (declaredSignature !== undefined && isGenericSignature(declaredSignature))
    return {
      ...declaredSignature,
      ...(effects !== undefined ? { effects } : {}),
    };

  return {
    kind: 'signature',
    // A parameter with a default value is an optional slot that carries the
    // default: `(x, k = 2) => x * k` types `(x: unknown, k: unknown = 2) ->
    // number`.
    ...signatureArgumentsOfSlots(paramOps, args),
    // The rest parameter's variadic tail, so `(a, ...rest) => …` types
    // `(unknown, any*) -> R`.
    ...restParameterSignatureTail(paramOps),
    ...(effects !== undefined ? { effects } : {}),
    result: bodyType,
  };
}

/**
 * The effects on the arrow of the function literal `expr`: the effect slot
 * of its signature type (`functionLiteralSignatureType()`, which calls this
 * function), computed without the types of the parameters and of the body.
 *
 * An inferred empty set is no slot (`undefined`): the author's `pure`
 * spelling is a statement, and inference states nothing
 * (`inferFunctionLiteralEffects()` collapses a `[]` accumulated from an
 * applied stated-pure callback).
 *
 * A full-signature marker states the effects of the arrow, so they join the
 * inferred set: the union keeps a stated `[]` (`[] ∪ undefined = []`,
 * spelled ` pure`) and, where the contract holds (`inferred ⊆ declared`),
 * equals the declared set. Where the contract is violated, the union is a
 * sound over-approximation, and the violation is reported at install time
 * by the definition-annotation check.
 *
 * A literal with no body has the type `error`, which has no effect slot:
 * the result is `undefined`.
 *
 * Call it in the static view of the bindings (`withStaticTypingView()`), as
 * the type computation does, so that both give the same set.
 */
export function functionLiteralArrowEffects(
  expr: Expression
): EffectSet | undefined {
  if (functionLiteralBody(expr) === undefined) return undefined;
  const declaredEffects = functionLiteralDeclaredEffects(expr);
  const inferredEffects = inferFunctionLiteralEffects(
    expr.engine,
    expr
  ).effects;
  return declaredEffects === undefined
    ? inferredEffects
    : unionEffectSets(declaredEffects, inferredEffects);
}

/**
 * The result type of a function whose body is `body`, whose positional
 * parameter slots are `args` and whose last value has the type `lastType`.
 *
 * A `Return` before the last statement gives the function its operand's
 * value, not the last statement's, so the result is the join of the two:
 * `x ↦ Block(If(x > 1, Return((x, x))), x^2)` gives a pair for `x = 1.5`,
 * and is typed `(unknown) -> number | tuple<number, number>`, not
 * `(unknown) -> number`. A returned value is widened by the rule for the
 * body of a function literal (`functionLiteralSignatureType()`): a finite
 * numeric type is `number` when a parameter can bind a non-finite value.
 * An `unknown` side stays `unknown`: the join would drop it. A `Return` with
 * no operand gives `Nothing`, and the join absorbs `nothing` too, so that
 * arm is added to the union after the join:
 * `x ↦ Block(If(x > 1, Return()), 2x)` is `(unknown) -> nothing | number`.
 *
 * Returns `lastType` when the body has no `Return`. Both the type of a
 * function literal and the signature that is derived when a literal becomes
 * an operator definition (`f(y) := …`, `boxed-operator-definition.ts`) read
 * this, so both include the types of the early `Return` values. The two
 * results can still differ in precision, not in soundness: each caller
 * widens the type of the last value and builds the parameter slots in its
 * own way (the literal widens a finite numeric last value to `number` when
 * a slot can bind a non-finite value; the derived signature does not), and
 * `args` decides the widening of the returned values here.
 */
export function joinEarlyReturnTypes(
  body: Expression,
  args: { type: Type }[] | undefined,
  lastType: Type
): Type {
  const returned = earlyReturnTypes(body).map((t) =>
    args !== undefined &&
    isSubtype(t, 'complex') &&
    args.some(
      (a) =>
        !provablyDisjoint(a.type, 'infinity') ||
        !provablyDisjoint(a.type, 'nan')
    )
      ? ('number' as Type)
      : stripNumericRanges(t)
  );
  if (returned.length === 0) return lastType;
  // The `nothing` arm is kept whether it comes from a `Return()` or from
  // the body itself, a fallthrough to an empty `Block()`:
  // `(c: boolean) ↦ Block(If(c, Return(1)), Block())` is
  // `-> integer | nothing`.
  const all = [lastType, ...returned];
  const values = all.filter((t) => t !== 'nothing');
  if (values.includes('unknown')) return 'unknown';
  const joined: Type = values.length === 0 ? 'nothing' : widenAll(values);
  return all.some((t) => provablyAdmits('nothing', t))
    ? reduceType({ kind: 'union', types: [joined, 'nothing'] })
    : joined;
}

/**
 * Whether the call `e` applies a function value: its head is bound to a
 * definition that holds a value or that declares a type. `Return` is not a
 * library operator: its head is bound, if at all, to the definition that
 * canonicalization infers for an unknown name, which holds no value and
 * whose type is inferred.
 */
function isCallOfFunctionValue(e: Expression): boolean {
  const own = e.valueDefinition;
  return own !== undefined && (own.value !== undefined || !own.inferredType);
}

/**
 * The types of the operands of the `Return` statements of a function body
 * (`nothing` for a `Return` with no operand), outside a nested function
 * literal (whose `Return` leaves that literal) and outside the operand of a
 * quoting operator (`holdClass: 'quote'`, such as `Hold`), which is never
 * run as part of the body.
 *
 * A call of a function-literal parameter named `Return` is not the
 * statement, also when the parameter has no type, and also when it is a
 * parameter of an enclosing literal: the parameter shadows `Return`, and
 * evaluation calls it (`isFunctionLiteralParameter()`). Without this,
 * `Return ↦ 1 + Return()` was typed
 * `(unknown) -> broadcastable<number> | nothing`.
 */
function earlyReturnTypes(body: Expression): Type[] {
  const types: Type[] = [];
  // A subexpression shared by several operands is visited once: a body can
  // be a DAG whose tree has exponentially many paths.
  const seen = new Set<Expression>();
  const visit = (e: Expression): void => {
    if (!isFunction(e) || e.operator === 'Function' || seen.has(e)) return;
    seen.add(e);
    if (e.operatorDefinition?.holdClass === 'quote') return;
    // A call of a function value named `Return` (a parameter declared
    // `() -> real`) is not the statement (`isCallOfFunctionValue`).
    if (
      e.operator === 'Return' &&
      !isCallOfFunctionValue(e) &&
      !isFunctionLiteralParameter(e.valueDefinition)
    )
      types.push(e.nops === 0 ? 'nothing' : e.op1.type.type);
    for (const op of e.ops) visit(op);
  };
  visit(body);
  return types;
}

/** True when a full-signature marker carries a non-empty `where` clause. */
function isGenericSignature(t: FunctionSignature): boolean {
  return (t.typeParams?.length ?? 0) > 0;
}

//
// ── The walk ─────────────────────────────────────────────────────────────────
//

/** Mutable accumulator of the walk. */
interface WalkState {
  effects: EffectSet | undefined;
  readsRandomFrame: boolean;
  draws: boolean;
  unresolvedHead: boolean;
  escapingWrite: boolean;
  /** True when the walk read an effect set that is lazily DERIVED from the
   * conformance registry — a protocol dispatcher's union over the registered
   * conforming implementations of a bare requirement, or a callee whose own
   * stamp is itself derived. A definition stamped by such a walk must
   * RE-DERIVE rather than freeze: the next conformance can widen the union
   * under it (`docs/TYPE_SYSTEM_ROADMAP.md`, Appendix B, "Changing a field is
   * an effect"). */
  consultsRegistry: boolean;
}

/** Per-branch context: the confinement frontier and the local literal bindings. */
interface WalkContext {
  /** Symbols provably `Declare`d on EVERY static path to this point, within
   * the literal. The dominance approximation — see {@link isConfinedTarget}. */
  declared: Set<string>;
}

/**
 * The context `ctx` with the index names of the scoped operator `expr` (a
 * `Loop`, a `Sum`, a comprehension: the `binderNames` of its scope) added to
 * its confinement frontier. Each such name is a binding of the scope of the
 * operator, so a write to it in an operand does not leave the operator:
 * `for k in [1, 2] { k = k * 10 }` writes the index, not a variable outside
 * the function.
 */
function withBinderIndices(expr: Expression, ctx: WalkContext): WalkContext {
  const names = expr.localScope?.binderNames;
  if (names === undefined || names.size === 0) return ctx;
  if ([...names].every((name) => ctx.declared.has(name))) return ctx;
  return { declared: new Set([...ctx.declared, ...names]) };
}

/**
 * Infer the effect set of a `Function` literal from its body.
 *
 * The normative rules (`docs/EFFECTS-MODEL.md`, "Inference" and "Scope writes"):
 *
 * - **Literals are inference boundaries.** A nested `Function` literal's
 *   effects go on its own arrow; the enclosing body adds them only where it
 *   APPLIES (or projects) the literal. Merely producing or storing a callback
 *   contributes ∅. Applications recognized statically: an immediately-applied
 *   literal (`Apply(Function(…), …)`) and a head that is a local symbol bound
 *   to a literal by a `Declare`/`Assign` earlier in the body. The literal of
 *   a `Declare` can be a positional operand or the `value` entry of its
 *   attributes dictionary (Epsil's `let f = …`). When the `Declare` has a
 *   type that states an effect set (`let f: () random -> number = …`),
 *   applying the local contributes the stated set, which is the contract,
 *   and the literal is not walked.
 * - **Applied parameters (ruling (c)).** An ANNOTATED function parameter
 *   contributes its declared arrow effects where the body applies it. An
 *   UNANNOTATED parameter (declared `unknown`) is treated pure — deliberate
 *   residual optimism, closable by annotation.
 * - **Dependency order (v5 ruling).** An UNRESOLVED named head contributes
 *   `{any}` and sets {@link InferredLiteralEffects.unresolvedHead}. A
 *   self-call is neutral: the definition under construction is the literal
 *   itself, not an unknown.
 * - **Confinement (dominance).** An `Assign` contributes no `scope` iff every
 *   static path from the literal's entry to it passes through a `Declare` of
 *   that symbol WITHIN the literal, and no nested `Function` literal WRITES
 *   the symbol. A nested literal that only READS the symbol does not change
 *   this: the body's own writes still die with the application, and the
 *   nested literal sees the value but cannot change it. A nested literal
 *   that writes the symbol (an `Assign`, `Declare` or `DefineFunction` of
 *   it, or a destructuring or `Field` target that has it as a component or
 *   base, at any depth of nesting) makes every write to the symbol in this
 *   body escaping, because the nested literal can outlive the application
 *   and keep the binding alive. The nested literal's own walk reports
 *   `scope` on its own arrow, and this body receives that `scope` where it
 *   applies the nested literal.
 *   `Assume` is never confined. Not provably confined ⇒ `scope`.
 *   Inference-only: the runtime `effectsOf` accounting stays conservative.
 * - **Parameters are confined at entry.** A write to the literal's own
 *   parameter is call-local — the binding lives in the call frame and dies
 *   with the application; the caller's variable never changes (verified
 *   empirically: `f(x) := (x := x + 1; x)` returns 6 for `f(5)` and leaves
 *   the caller's `a := 5` untouched). Parameters therefore seed the
 *   dominance frontier. The rule about nested literals applies to
 *   parameters too: a parameter that a nested literal only reads stays
 *   confined, and a parameter that a nested literal writes is not confined.
 *
 * `Hold` is NOT skipped: `Hold(Random())` marks the literal as drawing even
 * though nothing draws until `Release`. That is the conservative direction and
 * keeps the walk a plain structural scan.
 *
 * The literal may arrive in `'raw'` form, so its nodes can be UNBOUND and
 * `operatorDefinition` `undefined` throughout — the lookup by name is the
 * load-bearing path, not a fallback.
 */
export function inferFunctionLiteralEffects(
  ce: ComputeEngine,
  literal: Expression,
  options?: { selfName?: string }
): InferredLiteralEffects {
  const state: WalkState = {
    effects: undefined,
    readsRandomFrame: false,
    draws: false,
    unresolvedHead: false,
    escapingWrite: false,
    consultsRegistry: false,
  };
  walkLiteral(ce, literal, state, options?.selfName, 0, new Set());
  // Inference produces an UNSTATED set: an empty result is the bare arrow,
  // never the author's `pure`. The walk can accumulate a stated `[]` from an
  // applied `(…) pure -> …` callback, so collapse it here — the one place the
  // inference/stated split is decided (`normalizeEffectSet` vs
  // `normalizeStatedEffectSet`, `common/type/effects.ts`).
  state.effects = normalizeEffectSet(state.effects);
  return state;
}

/**
 * The stored function literals already walked into each accumulator by the
 * value-bound expansion of {@link Walker.applyNamed}, with the smallest depth
 * (the `depth` argument of {@link walkLiteral}) each was walked at.
 *
 * The `seen` map of a {@link Walker} skips a node reached again along another
 * path, but each expansion of a stored literal builds a new `Walker`, so a
 * body that calls the same stored function twice walked it twice, and a
 * chain of functions whose bodies each call the next one twice walked the
 * last one 2^depth times (89 794 reads of the declared signatures for a chain
 * of 12 functions declared `(unknown) -> unknown`, measured 2026-10-01; see
 * `tycho-item-336-nested-signature-derivation.test.ts`).
 *
 * Every contribution of a walk is a monotone union into the accumulator
 * (`WalkState`), and a walk of a literal at a smaller depth reaches every
 * literal a walk at a larger depth reaches, at smaller depths. So a repeat at
 * the same depth or a larger one adds nothing, and is skipped. A repeat at a
 * SMALLER depth is walked again: the earlier walk may have stopped at the
 * depth guard (`MAX_LITERAL_DEPTH`), which records `any` and sets none of the
 * other bits (`draws`, `unresolvedHead`, `consultsRegistry`,
 * `escapingWrite`), and the repeat sets them. A literal that is on the
 * expansion stack when it is reached again is walked to completion by the
 * walk that put it there, into the same accumulator.
 *
 * The one difference from walking every repeat: a skipped repeat that would
 * have reached the depth guard no longer collapses the effect set to `any`.
 * The result can then depend on the order of the calls (a direct call
 * before a deep chain to the same function keeps the precise set, the
 * reverse order still collapses), and is never less precise than before.
 * Keyed weakly on the accumulator, which a walk creates and drops.
 */
const expandedLiterals = new WeakMap<WalkState, Map<Expression, number>>();

/** Depth guard: a pathological self-referential literal must not recurse
 * forever through the applied-callback resolution. */
const MAX_LITERAL_DEPTH = 8;

function walkLiteral(
  ce: ComputeEngine,
  literal: Expression,
  state: WalkState,
  selfName: string | undefined,
  depth: number,
  /** Names of the VALUE bindings whose stored literal this walk is currently
   * inside — the cycle stack of {@link Walker.applyNamed}'s stored-literal
   * expansion. A head already on it is a recursive call back into a literal
   * being walked, which is neutral for the same reason a self-call is: the
   * rest of that body is what classifies it. Without the stack, a
   * self-recursive value binding (`R := (i) ↦ … R(i-1) …`) would expand into
   * itself until the depth guard collapsed it to `any`, reporting a pure
   * recursive body impure. */
  expanding: Set<string>,
  /** The scope that the names of `literal` are read from, when it is not
   * the scope of its body (`literalHome()`): the scope of the block that
   * declares a local with this literal (`blockLocalLiteral()`). */
  home?: Scope
): void {
  if (depth > MAX_LITERAL_DEPTH) {
    state.effects = 'any';
    return;
  }

  // A parameter shadows any same-named operator for the whole body, so
  // `f(Random) := Random` must not be read as a draw.
  const params = new Map<string, EffectSet | undefined | null>();
  // The parameters' DECLARED types, kept separately from their arrow effects
  // above so that a write through a parameter can be classified by what the
  // parameter is declared to be. A store into a mutable object's own field
  // (`x.id = …` where `x: M` and `M` is an `object{…}` layout declaring `id`)
  // is a heap mutation and must carry `state`; the declaration is the only
  // place that says so, since canonicalizing the receiver inside a literal
  // reports a parameter's type as `unknown`. Unannotated parameters get no
  // entry, which keeps them on the conservative `scope` path.
  const paramTypes = new Map<string, Type>();
  for (const p of functionLiteralParameters(literal)) {
    // `null` marks an UNANNOTATED parameter: optimistically pure, no
    // contribution. An annotated one contributes its declared arrow effects.
    params.set(p.name, p.type === undefined ? null : signatureEffects(p.type));
    if (p.type !== undefined) paramTypes.set(p.name, p.type);
  }
  // A DESTRUCTURING parameter (`((p, q)) => …`) has no single name, so the
  // loop above entered only an empty one for it. Its leaves are parameters
  // like any other, and carry no annotation of their own — `null` throughout.
  if (isFunction(literal, 'Function'))
    for (const name of functionLiteralBoundNames(literal.ops.slice(1)))
      if (!params.has(name)) params.set(name, null);

  const body = functionLiteralBody(literal);
  if (body === undefined) return;

  // The names of the literal are read from the scope it was boxed in: its
  // body scope and the chain above it (`walkHome`).
  const outerHome = walkHome;
  // A literal with no scope of its own (a literal of the text of a block,
  // `blockLocalLiteral()`, or one nested in it) reads its names from the
  // home of the walk that encloses it; its parameters shadow them
  // (`params`).
  walkHome = home ?? literalHome(literal) ?? outerHome;
  try {
    walkBody(ce, body, state, params, paramTypes, selfName, depth, expanding);
  } finally {
    walkHome = outerHome;
  }
}

/**
 * The scope that the names of the function literal `literal` are read from
 * by the walk (`definitionOf()`): the scope of its body, whose chain holds
 * the scope the literal was boxed in. `undefined` for a literal whose body
 * has no scope (a literal that is not canonical): its names are then read
 * from the current scope.
 */
function literalHome(literal: Expression): Scope | undefined {
  if (!isFunction(literal, 'Function')) return undefined;
  const body = literal.ops[0];
  return isFunction(body) ? body.localScope : undefined;
}

/**
 * The scope that the walk in progress reads names from (`literalHome()` of
 * the literal being walked), or `undefined` to read them from the current
 * scope.
 */
let walkHome: Scope | undefined = undefined;

/**
 * The definition that `name` denotes in the literal being walked: the
 * binding that the chain of `walkHome` gives (`homeDefinition()`), not the
 * binding of the current scope. The answer of the walk is then the same
 * whatever scope is current when the effects of a literal are read.
 */
function definitionOf(
  ce: ComputeEngine,
  name: string
): ReturnType<ComputeEngine['lookupDefinition']> {
  return walkHome === undefined
    ? ce.lookupDefinition(name)
    : homeDefinition(name, walkHome);
}

/** The walk of the body of a literal, with the names of the literal read
 * from `walkHome`: see {@link walkLiteral}. */
function walkBody(
  ce: ComputeEngine,
  body: Expression,
  state: WalkState,
  params: Map<string, EffectSet | undefined | null>,
  paramTypes: Map<string, Type>,
  selfName: string | undefined,
  depth: number,
  expanding: Set<string>
): void {
  // Closure capture: a symbol that a nested literal WRITES is shared between
  // this application and a closure that can outlive it, so a write to it is
  // never confined. A symbol that nested literals only READ is not in this
  // set: the closure observes the binding but cannot change it, so the
  // body's own writes to it still die with the application.
  const captured = new Set<string>();
  collectNestedLiteralWrites(body, captured);

  // Local symbols bound to a `Function` literal by a `Declare`/`Assign` in the
  // body: applying one of them projects the literal's latent effects, or the
  // effects its declaration states (see {@link LocalLiteral}).
  const localLiterals = new Map<string, LocalLiteral>();

  const walker = new Walker(
    ce,
    state,
    params,
    paramTypes,
    captured,
    localLiterals,
    selfName,
    depth,
    expanding
  );
  // Parameters seed the confinement frontier: a parameter is bound on every
  // static path at entry, and a write to it is call-local (see "Parameters
  // are confined at entry" above). A parameter that a nested literal writes
  // is still excluded by the `captured` check in `scopeWrite`.
  walker.sequence([body], { declared: new Set(params.keys()) });
}

/** The names of the symbols that some nested `Function` literal of `expr`
 * WRITES, at any depth of nesting inside that literal.
 *
 * A write is an `Assign`, `Declare` or `DefineFunction` node. Its target
 * symbols come from {@link assignTargets}, the same extraction
 * {@link Walker.scopeWrite} uses, so the two cannot disagree about what a
 * target names: a plain symbol, each component of a destructuring target,
 * and the base symbol of a `Field` target. A `Declare` inside a nested
 * literal binds a new local of that literal, and so does not write the outer
 * binding. It is counted anyway: this is the conservative direction, and it
 * keeps the scan a plain structural walk with no dominance reasoning of its
 * own.
 *
 * An expression that SHARES operands is a DAG: the same node object can be
 * reachable along exponentially many paths (`test/compute-engine/
 * dag-shared-walks.test.ts`). The scan only ADDS names to `out`, so visiting
 * a node a second time contributes nothing — the `seen` set makes the walk
 * linear in distinct nodes instead of in paths. */
function collectNestedLiteralWrites(
  expr: Expression,
  out: Set<string>,
  seen: Set<Expression> = new Set()
): void {
  if (isSymbol(expr)) return;
  const ops = walkedOperands(expr);
  if (ops === undefined) return;
  if (seen.has(expr)) return;
  seen.add(expr);
  if (isFunction(expr, 'Function')) {
    collectWritesMasked(expr, new Set(), out);
    return;
  }
  for (const op of ops) collectNestedLiteralWrites(op, out, seen);
}

/**
 * Collect the target symbols of every write inside `expr`, masking each
 * `Function` literal's OWN parameter names within its subtree, in the same
 * way as {@link collectSymbolsMasked}: a write to a parameter of a nested
 * literal changes that literal's call-local binding, not a binding of the
 * enclosing body with the same spelling.
 *
 * A target that {@link assignTargets} cannot resolve to a symbol (an `At` or
 * `Subscript` target, for example) records every symbol spelling of the
 * target expression instead. This over-approximates, which only makes more
 * of the enclosing body's writes escaping.
 */
function collectWritesMasked(
  expr: Expression,
  mask: ReadonlySet<string>,
  out: Set<string>,
  /** Nodes already scanned UNDER THE SAME MASK OBJECT — see the parameter of
   * the same name on {@link collectSymbolsMasked}. */
  seen: Map<ReadonlySet<string>, Set<Expression>> = new Map(),
  /** Where the operator names that {@link collectSymbolsMasked} records go.
   * The mask does not apply to them. */
  operators: Set<string> = out
): void {
  if (!isFunction(expr) && !isDictionary(expr)) return;
  // The memo covers dictionaries too: a dictionary can hold the same
  // dictionary under several keys, and the scan must stay linear in distinct
  // nodes.
  let seenForMask = seen.get(mask);
  if (seenForMask === undefined) {
    seenForMask = new Set();
    seen.set(mask, seenForMask);
  }
  if (seenForMask.has(expr)) return;
  seenForMask.add(expr);
  if (isDictionary(expr)) {
    for (const value of expr.values)
      collectWritesMasked(value, mask, out, seen, operators);
    return;
  }
  if (!isFunction(expr)) return;
  if (expr.operator === 'Function') {
    // The writes of a literal depend only on its own tree, and a mask only
    // removes names, so the writes of a literal under the mask `M` are its
    // writes under an empty mask minus `M`. Those are computed once per
    // literal and stored. Without the memo, each literal of a nested chain
    // (`Map((x) ↦ Map((y) ↦ …, ys), xs)`) scanned every literal below it
    // again when its own effects were inferred, which is quadratic in the
    // depth (CE-347).
    const writes = literalWrites(expr);
    for (const name of writes.masked) if (!mask.has(name)) out.add(name);
    for (const name of writes.unmasked) operators.add(name);
    return;
  }
  if (
    expr.operator === 'Assign' ||
    expr.operator === 'AddTo' ||
    expr.operator === 'Declare' ||
    expr.operator === 'DefineFunction'
  ) {
    const targets = assignTargets(expr);
    if (targets.some((name) => name === undefined)) {
      const target = expr.ops[0];
      if (target !== undefined)
        collectSymbolsMasked(target, mask, out, new Map(), operators);
    }
    for (const name of targets)
      if (name !== undefined && !mask.has(name)) out.add(name);
  }
  for (const op of expr.ops)
    collectWritesMasked(op, mask, out, seen, operators);
}

/** The writes of the `Function` literal `fn` as {@link collectWritesMasked}
 * collects them under an empty mask: `masked` holds the names the mask of an
 * enclosing scan still filters (its own parameters are already removed),
 * `unmasked` the operator names that no mask filters. Computed once per
 * literal object: the operands of a function expression never change after
 * it is built, and the scan reads nothing else. */
function literalWrites(fn: Expression): LiteralWrites {
  let result = LITERAL_WRITES.get(fn);
  if (result !== undefined) return result;
  const params = new Set<string>();
  if (isFunction(fn))
    for (const name of functionLiteralBoundNames(fn.ops.slice(1)))
      params.add(name);
  const masked = new Set<string>();
  const unmasked = new Set<string>();
  const seen = new Map<ReadonlySet<string>, Set<Expression>>();
  if (isFunction(fn))
    for (const op of fn.ops)
      collectWritesMasked(op, params, masked, seen, unmasked);
  result = { masked, unmasked };
  LITERAL_WRITES.set(fn, result);
  return result;
}

type LiteralWrites = {
  readonly masked: ReadonlySet<string>;
  readonly unmasked: ReadonlySet<string>;
};

const LITERAL_WRITES = new WeakMap<Expression, LiteralWrites>();

/**
 * Collect symbol spellings, masking each `Function` literal's OWN parameter
 * names within its subtree: `(x) ↦ x` nested in a body whose enclosing
 * function also has an `x` parameter SHADOWS that parameter rather than
 * capturing it, and recording the spelling as captured wrongly un-confines
 * the enclosing body's writes to its own `x`. Deeper literals extend the
 * mask with their own parameters, subtree by subtree. Operator names are
 * still collected — harmless over-approximation for the membership checks
 * the `captured` set feeds. {@link collectWritesMasked} uses this for a
 * write target it cannot resolve to a symbol.
 */
function collectSymbolsMasked(
  expr: Expression,
  mask: ReadonlySet<string>,
  out: Set<string>,
  /** Nodes already collected UNDER THE SAME MASK OBJECT. The mask only
   * changes at a nested `Function` (which builds a new, extended set), so
   * within one mask a shared node's second mention adds nothing — the memo
   * keeps the collection linear in distinct nodes on a DAG that would
   * otherwise unfold once per path. */
  seen: Map<ReadonlySet<string>, Set<Expression>> = new Map(),
  /** Where the operator names go; the mask does not apply to them. */
  operators: Set<string> = out
): void {
  const name = sym(expr);
  if (name !== undefined) {
    if (!mask.has(name)) out.add(name);
    return;
  }
  if (!isFunction(expr)) return;
  let seenForMask = seen.get(mask);
  if (seenForMask === undefined) {
    seenForMask = new Set();
    seen.set(mask, seenForMask);
  }
  if (seenForMask.has(expr)) return;
  seenForMask.add(expr);
  operators.add(expr.operator);
  if (expr.operator === 'Function') {
    // Every name the parameter list binds, destructuring leaves included.
    const extended = new Set(mask);
    for (const name of functionLiteralBoundNames(expr.ops.slice(1)))
      extended.add(name);
    for (const op of expr.ops)
      collectSymbolsMasked(op, extended, out, seen, operators);
    return;
  }
  for (const op of expr.ops)
    collectSymbolsMasked(op, mask, out, seen, operators);
}

class Walker {
  constructor(
    private ce: ComputeEngine,
    private state: WalkState,
    private params: Map<string, EffectSet | undefined | null>,
    /** The declared type of each ANNOTATED parameter; see the field-store
     * classification in {@link Walker.isFieldStore}. */
    private paramTypes: Map<string, Type>,
    private captured: Set<string>,
    private localLiterals: Map<string, LocalLiteral>,
    private selfName: string | undefined,
    private depth: number,
    /** See the parameter of the same name on {@link walkLiteral}. */
    private expanding: Set<string>
  ) {}

  /**
   * Function nodes already visited, with the context they were visited under.
   *
   * A body that SHARES operands is a DAG: the same node object is reachable
   * along exponentially many paths (a depth-30 tower of `Max(e, e)` holds 31
   * distinct nodes that unfold to 2^30 — `test/compute-engine/
   * dag-shared-walks.test.ts`). Every write this walk performs is a monotone
   * union into the current accumulator (`this.state`, `this.localLiterals`),
   * so re-walking an identical node under an identical context can add
   * nothing, and skipping the repeat is exact, not an approximation.
   *
   * "Identical context" is four-part, and each part is a key or snapshot in
   * the map below:
   *
   * - the accumulator OBJECT — a {@link visitDischarged} sub-walk uses a
   *   fresh one, and its contributions are filtered before merging, so a
   *   node's contribution must be recomputed per accumulator (the
   *   {@link dischargedSubwalks} cache keeps that recomputation linear);
   * - the confinement-frontier SET object and its SIZE — {@link sequence}
   *   grows its frontier in place between statements, and a `Declare` that
   *   lands between two mentions of a node changes what a write inside it
   *   contributes;
   * - the {@link localLiteralsGen} generation — an `Assign(f, (…) ↦ …)`
   *   between two mentions of a shared `f(…)` node rebinds what applying
   *   `f` projects, without touching the frontier or the accumulator.
   *
   * The inner value is a SNAPSHOT (frontier size + generation), overwritten
   * on re-visit: both counters only advance, so a superseded snapshot can
   * never be a future context and keeping one entry per (node, accumulator,
   * frontier) suffices — and keeps the lookup O(1) rather than a scan over
   * every context the node was ever seen under.
   */
  private seen = new Map<
    Expression,
    Map<WalkState, Map<Set<string>, { size: number; gen: number }>>
  >();

  /**
   * Generation counter for {@link localLiterals}: advanced whenever
   * {@link recordLocalLiteral} rebinds a name to a different literal. Memo
   * entries snapshot it so that a binding change invalidates every node
   * visited under the previous bindings.
   */
  private localLiteralsGen = 0;

  /**
   * Completed sub-walk results for operands visited under a DISCHARGING
   * position, keyed by operand and frontier, snapshot-checked like
   * {@link seen}. {@link visitDischarged} walks its operand into a fresh
   * accumulator every time, so the `seen` memo (keyed on the accumulator
   * object) can never collapse two discharged mentions of a shared operand —
   * a tower with two distinct `WithRandomSeed(…, shared)` wrappers per level
   * would still unfold once per path. The RAW inner result is cached here
   * (before any label subtraction, so one entry serves every discharge set)
   * and replayed instead of re-walked. A result is only stored when the walk
   * left the local-literal bindings unchanged — a walk that rebound a name
   * computed with a mix of generations and is not replayable.
   */
  private dischargedSubwalks = new Map<
    Expression,
    Map<Set<string>, { size: number; gen: number; result: WalkState }>
  >();

  /** Straight-line dominance: a `Declare(n, …)` statement dominates the
   * statements that FOLLOW it in the same sequence, and nothing else. The
   * frontier is copied per sequence, so a `Declare` inside a nested `Block`
   * (or inside an `If` arm) does not leak to the enclosing sequence — the
   * `Block(If(flag, Declare(n, 0)), Assign(n, 5))` case, which must NOT be
   * confined. */
  sequence(ops: readonly Expression[], ctx: WalkContext): void {
    const declared = new Set(ctx.declared);
    for (const op of ops) {
      this.visit(op, { declared });
      if (isFunction(op, 'Declare') || isFunction(op, 'DefineFunction')) {
        for (const name of assignTargets(op)) {
          if (name === undefined) continue;
          declared.add(name);
        }
        this.recordLocalLiteral(op, 1);
      } else if (isFunction(op, 'Assign')) this.recordLocalLiteral(op, 1);
    }
  }

  /** Remember `name := (…) ↦ …` so a later application of `name` inside the
   * same body projects the literal's latent effects. */
  private recordLocalLiteral(expr: Expression, valueIndex: number): void {
    if (!isFunction(expr)) return;
    const name = sym(expr.ops[0]);
    if (name === undefined) return;
    // `Declare(n, type, value)` puts the value third; `Assign(n, value)`
    // second. Scan the remaining operands for a literal. A `Declare` can
    // also carry its value in a trailing attributes dictionary,
    // `Declare(n, Dictionary(value: …))` or `Declare(n, type, Dictionary(
    // value: …))`, which is how Epsil lowers `let n = …` and
    // `let n: T = …`; the literal is then the dictionary's `value` entry.
    // Only the LAST operand of a `Declare` is an attributes dictionary: the
    // dictionary operand of an `Assign` is the value itself, a dictionary
    // and not a function.
    const isDeclare = isFunction(expr, 'Declare');
    const ops = expr.ops.slice(valueIndex);
    for (const [i, op] of ops.entries()) {
      const literal = isFunction(op, 'Function')
        ? op
        : isDeclare && i === ops.length - 1
          ? dictionaryEntry(op, 'value')
          : undefined;
      if (literal === undefined || !isFunction(literal, 'Function')) continue;
      const stated = isDeclare ? declaredEffects(this.ce, expr) : undefined;
      // A REBINDING invalidates the shared-node memos: a node visited under
      // the old binding may resolve this name differently now. Re-recording
      // the same literal changes nothing and keeps the memos.
      const prior = this.localLiterals.get(name);
      if (
        prior === undefined ||
        prior.literal !== literal ||
        !sameEffectSet(prior.stated, stated)
      )
        this.localLiteralsGen++;
      this.localLiterals.set(name, { literal, stated });
      return;
    }
  }

  visit(expr: Expression, ctx: WalkContext): void {
    // Saturated: nothing further can change the answer.
    if (
      this.state.effects === 'any' &&
      this.state.readsRandomFrame &&
      this.state.draws &&
      this.state.unresolvedHead
    )
      return;
    if (!isFunction(expr) && !isDictionary(expr)) return;

    // Shared-node cutoff — see the {@link seen} field for why the skip is
    // exact. It applies to a dictionary as well as to a function expression:
    // a dictionary can hold the same dictionary under several keys, and
    // without the cutoff a tower of such dictionaries unfolds once per path.
    // Recorded before descending: an expression is a DAG (no cycles),
    // so the entry cannot be consulted mid-visit of the same node. The
    // snapshot carries the ENTRY generation; a descent that rebinds a local
    // literal advances the generation, so the stale snapshot simply never
    // matches again and the next mention re-walks.
    let byState = this.seen.get(expr);
    let byFrontier = byState?.get(this.state);
    const prior = byFrontier?.get(ctx.declared);
    if (
      prior !== undefined &&
      prior.size === ctx.declared.size &&
      prior.gen === this.localLiteralsGen
    )
      return;
    if (byState === undefined) {
      byState = new Map();
      this.seen.set(expr, byState);
    }
    if (byFrontier === undefined) {
      byFrontier = new Map();
      byState.set(this.state, byFrontier);
    }
    byFrontier.set(ctx.declared, {
      size: ctx.declared.size,
      gen: this.localLiteralsGen,
    });

    // A canonical `Dictionary` is not a function expression, but its entry
    // values are evaluated like operands: the `value` entry of
    // `Declare(x, Dictionary(value: Random()))` (Epsil's `let x = Random()`)
    // draws. Building the dictionary itself has no effect.
    if (isDictionary(expr)) {
      for (const value of expr.values) this.visit(value, ctx);
      return;
    }
    if (!isFunction(expr)) return;

    const head = expr.operator;

    // ── Literals are inference boundaries ────────────────────────────────
    // Producing or storing a nested literal contributes ∅; its effects live on
    // its own arrow.
    if (head === 'Function') return;

    // The index of a loop, of a comprehension or of a big operator is a
    // binding of the scope of the operator (`binderNames`). An assignment to
    // it in the body writes that binding, which does not outlive the
    // operator, so the write is confined.
    ctx = withBinderIndices(expr, ctx);

    // A sequence: `Block` is the only straight-line construct the confinement
    // analysis reasons about.
    if (head === 'Block') {
      this.sequence(expr.ops, ctx);
      return;
    }

    // ── Applications ─────────────────────────────────────────────────────
    // `ApplyWhole` is `Apply` with its arguments bound whole (engine-internal,
    // `library/core.ts`): the same effects flow.
    if (head === 'Apply' || head === 'ApplyWhole') {
      const callee = expr.ops[0];
      if (callee !== undefined) {
        // An immediately-applied literal: its latent effects DO flow into the
        // enclosing body. A literal node already walked into this accumulator
        // at this depth or a smaller one adds nothing (`expandedLiterals`): a
        // held argument with its caller's local functions inlined is a DAG
        // that applies one literal node at many places.
        if (isFunction(callee, 'Function')) {
          let walked = expandedLiterals.get(this.state);
          if (walked === undefined) {
            walked = new Map();
            expandedLiterals.set(this.state, walked);
          }
          const prior = walked.get(callee);
          if (prior === undefined || prior > this.depth + 1) {
            walked.set(callee, this.depth + 1);
            walkLiteral(
              this.ce,
              callee,
              this.state,
              this.selfName,
              this.depth + 1,
              this.expanding
            );
          }
        } else this.applyNamed(sym(callee));
      }
      // The callee is handled above; the remaining operands are ordinary
      // invoking positions (`Apply(hof, callback)`).
      this.projectOperands(head, expr.ops, 1);
      for (const op of expr.ops.slice(1)) this.visit(op, ctx);
      return;
    }

    if (head === 'Assign') {
      // `Assign` spells two different operations. When the target is a `Field`
      // whose receiver is declared to be a mutable object, it is a HEAP STORE:
      // it overwrites a field of the object the caller handed in, so the
      // mutation is observable to the caller and the function is not pure
      // ("Changing a field is an effect", `docs/TYPE_SYSTEM_ROADMAP.md`
      // Appendix B). It gets no confinement exemption — the confinement
      // analysis proves that a write cannot outlive the call, which is never
      // true of a store into someone else's object ("Confinement does not
      // apply to `state`", `docs/EFFECTS-MODEL.md`). Everything else — a plain
      // name, a destructuring target, a receiver whose declared type does not
      // establish an object — stays on the `scope` path, where `assignTargets`
      // judges the write on the base symbol.
      const store = this.propertyStoreTarget(expr);
      if (store !== undefined) {
        this.state.effects = unionEffectSets(this.state.effects, ['state']);
        // …plus whatever the AUTHORED `set` accessor's body does, when the name
        // is answered by a computed property rather than a stored slot. The
        // unqualified `p.name = v` keeps its `Field` target through
        // canonicalization, so this arm — not the `ProtocolProperty` one — is
        // where a setter that draws, or writes an outer binding, has to be
        // accounted for. Union over every protocol declaring the name, since
        // which one answers is a runtime question; a field-backed accessor is a
        // host callback and adds nothing (`protocolAccessorEffects`,
        // `effects-of.ts`). Registry-derived, hence `consultsRegistry`: the set
        // widens as conformances register, and the definition being stamped
        // must re-derive rather than freeze what the registry said here.
        //
        // Skipped when the receiver's DECLARED layout owns the name: the slot
        // store wins that precedence and no accessor runs, so unioning one in
        // would attribute code that cannot execute. A QUALIFIED store never
        // skips — it goes through the protocol view, whose accessor runs even
        // for a field-backed property — and narrows the union to the protocol
        // it names.
        if (
          store.protocol !== undefined ||
          !this.layoutOwns(store.receiver, store.name)
        ) {
          this.state.consultsRegistry = true;
          this.state.effects = unionEffectSets(
            this.state.effects,
            protocolAccessorEffects(this.ce, store.name, 'set', store.protocol)
          );
        }
      } else this.scopeWrite(expr, ctx, /* confinable */ true);
      for (const op of expr.ops.slice(1)) this.visit(op, ctx);
      return;
    }

    if (head === 'AddTo') {
      // `AddTo(s, e)` and `AddTo(At(L, i), e)` rebind `s` or `L`, as the
      // `Assign` forms they stand for do (`evaluateAddTo()`,
      // `library/control-structures.ts`), so the write is judged on that
      // name: a write to a local of the literal is confined. The positions
      // of an `At` target and the value are evaluated.
      this.scopeWrite(expr, ctx, /* confinable */ true);
      const target = expr.ops[0];
      if (isFunction(target, 'At'))
        for (const op of target.ops.slice(1)) this.visit(op, ctx);
      for (const op of expr.ops.slice(1)) this.visit(op, ctx);
      return;
    }

    if (head === 'ProtocolProperty') {
      // `ProtocolProperty(P, "name", receiver, value)` — the FOUR-operand form
      // — invokes the protocol's `set` handler for the property; the
      // three-operand form is the qualified READ.
      //
      // A SET contributes `state`, unconditionally. Appendix B of
      // `docs/TYPE_SYSTEM_ROADMAP.md` (rule "Which types can conform", ruled
      // 2026-08-15) makes a WRITABLE property meaningful only on a mutable
      // object, so a property set is a heap store by definition: it overwrites
      // a cell that every other reference to the receiver sees. Like the field
      // store above it gets no confinement exemption, because a store into an
      // object the caller handed in outlives the call
      // ("Confinement does not apply to `state`", `docs/EFFECTS-MODEL.md`).
      //
      // The verdict deliberately does not consult the conformance registry to
      // ask what the selected setter actually does. A registry-derived answer
      // would report the set pure whenever the conformance was not registered
      // yet — an inference walk runs before, and independently of, conformance
      // registration — and would let a body annotated `pure` mutate its
      // caller's object.
      //
      // On top of that fixed contribution, BOTH halves union in what the
      // AUTHORED accessor bodies do (`protocolAccessorEffects`, `effects-of.ts`
      // — the property counterpart of the union `derivedDispatcherEffects`
      // performs for function members, which property members never reach
      // because they get no dispatcher). So a computed getter whose body draws
      // makes the enclosing function `random`, and a setter that writes an
      // outer binding makes it `scope`. That half IS registry-derived and
      // widens as conformances register, hence the `consultsRegistry` bit: it
      // makes the definition being stamped re-derive rather than freeze what
      // the registry happened to say when the body was walked.
      //
      // A field-backed accessor is a host callback and adds nothing — its store
      // is already described by the `state` above. A READ therefore contributes
      // nothing at all in the ordinary case.
      //
      // Returning here skips `projectOperands`, which the generic path would
      // otherwise run, and that is deliberate rather than an omission: neither
      // half of this operator INVOKES a function-valued operand (the operands
      // are the protocol name, the property name, the receiver and the value),
      // so there is no latent set to project. The definition spells the same
      // decision as `invokes: false` (`library/core.ts`), which is what stops
      // the runtime channel from consulting `invokesAt` here — the two channels
      // agree because both were told, not by coincidence.
      const isSet = expr.ops.length >= 4;
      if (isSet)
        this.state.effects = unionEffectSets(this.state.effects, ['state']);
      const property = expr.ops[1];
      if (isString(property)) {
        this.state.consultsRegistry = true;
        // The protocol operand restricts dispatch, so it restricts the union
        // too: an unrelated protocol declaring the same property name can never
        // be selected here.
        const protocol = expr.ops[0];
        this.state.effects = unionEffectSets(
          this.state.effects,
          protocolAccessorEffects(
            this.ce,
            property.string,
            isSet ? 'set' : 'get',
            isString(protocol) ? protocol.string : sym(protocol)
          )
        );
      }
      for (const op of expr.ops) this.visit(op, ctx);
      return;
    }

    if (head === 'MatchCase') {
      // The captures of the pattern of a case are bindings of the case: a
      // write to one in the guard or the body does not leave the case.
      const { captures } = matchPatternReferences(expr.ops[0]);
      const inner =
        captures.length === 0
          ? ctx
          : { declared: new Set([...ctx.declared, ...captures]) };
      this.visit(expr.ops[0], ctx);
      for (const op of expr.ops.slice(1)) this.visit(op, inner);
      return;
    }

    if (head === 'Declare') {
      // A `Declare` inside the literal introduces a binding in a scope the
      // literal itself owns — it cannot write through to an outer binding, so
      // it never contributes `scope`.
      for (const op of expr.ops.slice(1)) this.visit(op, ctx);
      return;
    }

    if (head === 'Assume') {
      // Never confined: an assumption targets the ambient assumption store.
      this.state.effects = unionEffectSets(this.state.effects, ['scope']);
      this.state.escapingWrite = true;
      for (const op of expr.ops) this.visit(op, ctx);
      return;
    }

    if (head === 'DefineFunction') {
      // A NESTED `DefineFunction` (Epsil's one-step inner definition,
      // `helper(x) = x + a` inside a body, lowers here) is BLOCK-LOCAL, so
      // it never contributes `scope` — categorically, exactly like the
      // `Declare` above. The definition binds in the block or call frame it
      // is written in and dies with it: after `function outer(n) { sq(m) =
      // m * m; sq(n) }` is defined and called, `sq` is still unresolved at
      // top level, and a same-named outer function is SHADOWED for the
      // duration of the frame rather than overwritten. The one-step and
      // two-step (`let sq; sq(m) = m * m`) forms are the same write.
      //
      // Not judged by a definition-visibility lookup: the verdict would flip
      // when the provisional-dependents cascade re-walks the body after a
      // runtime install has made a name visible. The generic operator path
      // is wrong too — it would union `DefineFunction`'s own declared
      // `{scope}`, which describes the TOP-LEVEL defining form.
      //
      // The literal operand is deliberately not visited: its body's effects
      // are latent until the helper is applied, and an application inside
      // this same body projects them through the `localLiterals` entry
      // `Walker.sequence` records for the statement.
      return;
    }

    this.applyNamed(head);
    this.projectOperands(head, expr.ops, 0);

    // DISCHARGE, mirroring the runtime channel (`effectsOf`, which applies
    // `subtractEffects(own, discharge)` at a held position of a `lazy`
    // definition). Without this the static walk stamps a literal's arrow with
    // labels the operator provably absorbs, so `(i) ↦ WithRandomSeed(42,
    // Random())` came out `random` — and every operator that reads a lambda's
    // LATENT set rather than the body directly inherited that: `Map` reported
    // impure for a body `Comprehension` reported pure.
    const def = operatorDefinitionOf(this.ce, head);
    const discharges = def?.lazy ? def.discharges : undefined;
    if (discharges === undefined) {
      for (const op of expr.ops) this.visit(op, ctx);
      return;
    }
    for (let i = 0; i < expr.ops.length; i++) {
      const op = expr.ops[i];
      // …and mirroring it on the ESCAPE carve-out too (Tycho item 142, ruled
      // 2026-08-02): a `random` discharge does not apply to a body that
      // provably escapes the frame as a lazy drawing view, because those draws
      // happen at materialization, outside the frame
      // (`docs/RANDOMNESS-MODEL.md` §6). Reading the shared
      // `effectiveDischarge` is what keeps the two channels in lockstep — the
      // item-132 disagreement was exactly this rule differing between them.
      const discharge = effectiveDischarge(discharges[i], op);
      if (discharge === undefined || discharge.length === 0) {
        this.visit(op, ctx);
        continue;
      }
      this.visitDischarged(op, ctx, discharge);
    }
  }

  /**
   * Walk a held operand whose position DISCHARGES some labels, and merge back
   * only what survives the discharge.
   *
   * The accumulator is shared and mutable, so "what did this subtree add" is
   * not otherwise recoverable: swap in a fresh state for the sub-walk, subtract
   * there, then union. Only the EFFECT SET is filtered — `draws` /
   * `readsRandomFrame` are the randomness bookkeeping the pending-draw walk and
   * `RANDOMNESS-MODEL.md` key on (a seeded frame still draws, it just draws
   * reproducibly), and `unresolvedHead` is a resolution fact, not an effect.
   */
  private visitDischarged(
    op: Expression,
    ctx: WalkContext,
    discharge: readonly EffectLabel[]
  ): void {
    const outer = this.state;
    // Replay a completed sub-walk of the same operand under the same context
    // instead of re-walking it — see {@link dischargedSubwalks} for why the
    // `seen` memo cannot do this job. The cached result is read-only from
    // here on: the merge below only reads `inner`.
    const cached = this.dischargedSubwalks.get(op)?.get(ctx.declared);
    let inner: WalkState;
    if (
      cached !== undefined &&
      cached.size === ctx.declared.size &&
      cached.gen === this.localLiteralsGen
    ) {
      inner = cached.result;
    } else {
      const entryGen = this.localLiteralsGen;
      inner = {
        effects: undefined,
        readsRandomFrame: false,
        draws: false,
        unresolvedHead: false,
        escapingWrite: false,
        consultsRegistry: false,
      };
      this.state = inner;
      try {
        this.visit(op, ctx);
      } finally {
        this.state = outer;
      }
      // Only a walk that left the local-literal bindings unchanged is
      // replayable — one that rebound a name computed under a mix of
      // generations, and the next mention must re-walk.
      if (this.localLiteralsGen === entryGen) {
        let byFrontier = this.dischargedSubwalks.get(op);
        if (byFrontier === undefined) {
          byFrontier = new Map();
          this.dischargedSubwalks.set(op, byFrontier);
        }
        byFrontier.set(ctx.declared, {
          size: ctx.declared.size,
          gen: entryGen,
          result: inner,
        });
      }
    }
    const kept = subtractEffects(inner.effects, discharge);
    // `subtractEffects` works on the runtime `ComputedEffects` lattice, whose
    // co-finite form has no spelling in the inference walk's plain
    // `EffectSet`. A held body is never `'any'` here (the walk only ever
    // accumulates finite sets), so this is a narrowing, not a loss.
    if (kept !== undefined && kept !== 'any' && !isCoFiniteEffects(kept))
      outer.effects = unionEffectSets(outer.effects, kept);
    outer.readsRandomFrame ||= inner.readsRandomFrame;
    outer.draws ||= inner.draws;
    outer.unresolvedHead ||= inner.unresolvedHead;
    // A proven mutation survives a discharge of OTHER labels; a position that
    // discharges `scope` itself (none does today) would contain the write.
    outer.escapingWrite ||= inner.escapingWrite && !discharge.includes('scope');
    // Registry-dependence is a provenance fact about WHERE the sub-walk read
    // its numbers, not an effect: a discharge removes labels, never the need
    // to re-derive.
    outer.consultsRegistry ||= inner.consultsRegistry;
  }

  /**
   * PROJECTION of a callback passed as an OPERAND of an applied head.
   *
   * Worked example 1, the headline case: "the literal `(xs) ↦ Map(f, xs)` has
   * type `(list) random -> list` — the application's effects, stamped onto the
   * enclosing literal's own arrow by the static walk". The body adds a
   * callback's effects where it "APPLIES (or **projects**)" it, and handing `f`
   * to `Map` is projection. `applyNamed` covers the direct application
   * (`f(x)`); this covers the operand position, for all three kinds of function
   * value:
   *
   * - an **inline literal** — its latent set, walked here. This does NOT
   *   reopen "literals are inference boundaries": producing or STORING a
   *   literal still contributes ∅ (the `Function`, `Assign` and `Declare`
   *   branches of {@link visit} never reach this method); only an invoking
   *   position projects.
   * - an **annotated parameter** — its declared arrow effects. An UNANNOTATED
   *   one contributes nothing (ruling (c) optimism, unchanged).
   * - a **named symbol** resolving to a function value — its binding's arrow,
   *   a construction-time SNAPSHOT: signatures are constants, so a later
   *   reassignment does not re-stamp this arrow (the runtime `effectsOf`
   *   channel is the honest party there). An UNRESOLVED name contributes
   *   `{any}` per the dependency-order ruling — but only under a head that
   *   DECLARES a callback parameter ({@link acceptsCallable}), so an ordinary
   *   free symbol (`(x) ↦ x + freeVar`) stays optimistic rather than
   *   collapsing every literal with a free variable to the top.
   *
   * Gated throughout on the head's `invokes` metadata, exactly as `effectsOf`
   * gates the latent half of a contribution: a non-invoking position only
   * STORES or SELECTS the value, so `(g) ↦ List(g)` and `List(x ↦ Random())`
   * stay pure. The operator-level `invokesNone` is a cheap pre-gate; the
   * per-position `invokesAt` is what the loop consults, so an operator that
   * invokes at some positions and stores at others is handled exactly. An
   * unresolved head keeps the conservative default (`invokes: true`) — and has
   * already contributed `{any}` through {@link applyNamed}.
   *
   * (The `acceptsCallable` gate below stays position-INSENSITIVE by design —
   * see its own note: it answers "could an operand of this operator be a
   * callback at all", which is a different question from "does THIS position
   * invoke".)
   *
   * @param start First operand index to consider — 1 for `Apply`, whose callee
   * is handled by {@link visit} itself.
   */
  private projectOperands(
    head: string,
    ops: readonly Expression[],
    start: number
  ): void {
    const def = operatorDefinitionOf(this.ce, head);
    if (def !== undefined && def.invokesNone) return;

    for (let i = start; i < ops.length; i++) {
      if (def !== undefined && !def.invokesAt(i)) continue;
      const op = ops[i];

      // An inline literal in an invoking position: project its latent set.
      if (isFunction(op, 'Function')) {
        walkLiteral(
          this.ce,
          op,
          this.state,
          this.selfName,
          this.depth + 1,
          this.expanding
        );
        continue;
      }

      const name = sym(op);
      if (name === undefined) continue;

      // `applyNamed` already encodes every resolution rule — parameter
      // shadowing, local literals, the neutral self-reference, operator
      // definitions (with the `draws` / `readsRandomFrame` bits), value
      // bindings, and the unresolved-`{any}` case. Reuse it rather than
      // reimplement it; the guard below is only about WHICH names may reach
      // its unresolved arm.
      if (
        this.params.has(name) ||
        this.localLiterals.has(name) ||
        name === this.selfName ||
        this.isFunctionValued(name) ||
        acceptsCallable(def)
      )
        this.applyNamed(name);
    }
  }

  /** Whether `name` currently resolves to something callable — an operator
   * definition, or a value binding whose type is an arrow. A binding that is
   * not callable (`k := 5`) contributes nothing from an operand position. */
  private isFunctionValued(name: string): boolean {
    const def = definitionOf(this.ce, name);
    if (def === undefined) return false;
    if ('operator' in def) return true;
    const t = def.value.type?.type as Type | undefined;
    return t !== undefined && isCallableType(t);
  }

  /** Contribution of applying the named head `name`. */
  private applyNamed(name: string | undefined): void {
    if (name === undefined) return;

    // A parameter shadows any same-named operator.
    if (this.params.has(name)) {
      const declared = this.params.get(name);
      // `null` = unannotated: optimistically pure (ruling (c)).
      if (declared !== null) this.noteContributorEffects(declared);
      return;
    }

    // A local symbol bound to a literal earlier in the body: project the
    // literal's latent effects.
    const local = this.localLiterals.get(name);
    if (local !== undefined) {
      // A declaration whose type STATES an effect set is the contract for the
      // local, as it is for an annotated parameter: `Declare` refuses a
      // literal whose effects are not in the stated set, so the stated set
      // covers every literal the local can hold.
      if (local.stated !== undefined) {
        this.noteContributorEffects(local.stated);
        return;
      }
      walkLiteral(
        this.ce,
        local.literal,
        this.state,
        this.selfName,
        this.depth + 1,
        this.expanding
      );
      return;
    }

    // A self-call is neutral: the definition under construction is this very
    // literal, and the rest of the body is what classifies it.
    if (name === this.selfName) return;

    const def = operatorDefinitionOf(this.ce, name);
    if (def === undefined) {
      const t = valueSignatureOf(this.ce, name);
      if (t === 'undeclared') {
        // Dependency order, ruled (v5): an unresolved named head infers
        // `{any}` — sound; the cost is caching for forward references. An
        // explicit annotation over such a walk installs as a TRUSTED contract.
        this.state.effects = 'any';
        this.state.unresolvedHead = true;
        return;
      }
      // A binding whose declared arrow STATES an effect set (including the
      // stated-pure empty one) is a trusted contract: union it and stop. When
      // the arrow is UNSTATED — which is what the `ce.declare(g, '(…) -> …')`
      // then `ce.assign(g, literal)` idiom leaves behind — the contract says
      // nothing about what `g` does, and the only account of it is the
      // `Function` literal the binding currently holds. Walking that literal
      // into this state propagates its effects, its `draws` /
      // `readsRandomFrame` bits and — the reason this branch exists — its
      // `consultsRegistry` bit, so a caller that reaches a protocol dispatcher
      // through a value-bound hop re-derives when a later conformance widens
      // the derived union, instead of freezing the (empty) set it first saw.
      // This mirrors the runtime channel's `valueBindingEffects`
      // (`effects-of.ts`), which likewise trusts a stated declared arrow and
      // otherwise consults the stored value; the two channels must not
      // disagree about the same head. (`docs/TYPE_SYSTEM_ROADMAP.md`,
      // Appendix B, "Changing a field is an effect".)
      //
      // A head already on the expansion stack is a recursive call back into a
      // literal this walk is inside; it is neutral, exactly as a self-call is,
      // and falls through to contribute nothing.
      if (t === undefined && !this.expanding.has(name)) {
        const found = storedFunctionLiteral(this.ce, name);
        const stored = found?.literal;
        const home = found?.home;
        if (stored !== undefined) {
          // A stored literal already walked into this accumulator at this
          // depth or a smaller one adds nothing (see `expandedLiterals`).
          let walked = expandedLiterals.get(this.state);
          if (walked === undefined) {
            walked = new Map();
            expandedLiterals.set(this.state, walked);
          }
          const prior = walked.get(stored);
          if (prior !== undefined && prior <= this.depth + 1) return;
          walked.set(stored, this.depth + 1);
          this.expanding.add(name);
          try {
            walkLiteral(
              this.ce,
              stored,
              this.state,
              this.selfName,
              this.depth + 1,
              this.expanding,
              home
            );
          } finally {
            this.expanding.delete(name);
          }
          return;
        }
      }
      this.noteContributorEffects(t);
      return;
    }

    // The callee's effect set may be LAZILY DERIVED rather than fixed — a
    // protocol dispatcher unions the inferred effects of the conformers
    // registered right now, and a later conformance can widen it. Reading
    // `def.effects` below goes through the refreshing accessor, so the number
    // this walk uses is current; recording that the walk depended on it is
    // what lets the definition being stamped re-derive instead of freezing
    // (`docs/TYPE_SYSTEM_ROADMAP.md`, Appendix B, "Changing a field is an
    // effect").
    if (def._deriveEffects !== undefined) this.state.consultsRegistry = true;

    if (def.readsRandomFrame === true) this.state.readsRandomFrame = true;
    // Read from the callee's DERIVED getter, so an explicit `random`, a
    // frame-protocol head, and a callee whose own inference saw a draw all
    // propagate — the same composition rule as the effect union. This is the
    // pending-draw obligation ("a surviving nested `WithRandomSeed` owes the
    // outer frame"), and it rides the `draws` BIT.
    if (def.drawsRandom === true) this.state.draws = true;
    // …and it rides ONLY that bit: "the runtime frame-protocol role is a
    // separate field, NOT THE ARROW" (`docs/EFFECTS-MODEL.md`, "Randomness
    // shapes"). Contributing `{random}` to the enclosing literal's arrow here
    // put the frame-protocol role on the arrow, which stamped
    // `(i) ↦ WithRandomSeed(42, Random())` as `random` while the runtime
    // channel called the same expression PURE — and every operator that reads
    // a lambda's LATENT set inherited the disagreement (`Map` impure where
    // `Comprehension`, which sees the body directly, was pure). The body's own
    // draw is removed by the position's DISCHARGE in `visit`, mirroring
    // `effectsOf`; nothing needs to be added in its place.
    this.noteContributorEffects(def.effects);
  }

  /**
   * The parts of this `Assign` if it is, or may be, a property STORE —
   * `undefined` when it is not one.
   *
   * Two target shapes spell the same write: `Field(receiver, "name")` is the
   * unqualified `p.name = v`, and `ProtocolProperty(P, "name", receiver)` is
   * the qualified `p.(P.name) = v`. Both keep their shape through
   * canonicalization, and neither writes a binding.
   *
   * For the unqualified shape the receiver's declared type decides: an object
   * type, or a declaration that establishes nothing about it.
   *
   * The UNDECIDED case is a `state` too, and that is the load-bearing half.
   * After the property rebinding sugar retired, assignment through a `Field`
   * target is a store and never a binding write, so a receiver nothing is known
   * about is either a heap store or a runtime error — `state` is the sound
   * over-approximation of both, and a `scope` label (or none at all) is a claim
   * about a receiver no one has looked at. Without it,
   * `function k(x) pure { x.id = "Z" }` was ACCEPTED and mutated its caller's
   * object behind the `pure` contract: an unannotated parameter yields no type,
   * the write fell to the `scope` path, and `assignTargets` attributed it to the
   * parameter `x`, which confinement then exempted.
   *
   * A receiver whose declared type IS decided and is not an object is not a
   * store: `p.name = v` on a record or a tuple is `immutable-value-assignment`,
   * which changes nothing and needs no label. (One over-approximation remains:
   * a decided non-object in the MIDDLE of a chain — `r.a.b = v` where `r.a` is
   * a record — is indistinguishable here from an undecided step, so it takes
   * the `state` branch. The program faults either way.)
   *
   * The FIELD NAME is not consulted, and does not need to be. Assignment
   * through a `Field` target is a store and never a binding write
   * (`docs/TYPE_SYSTEM_ROADMAP.md`, Appendix B, "Assigning to a property"), so
   * on an object receiver it either writes a slot, runs a protocol property's
   * `set` accessor — which exists only on objects, so it too is a heap write —
   * or faults on a name the object has neither way. `state` is the sound label
   * for all three; `scope` would be false for all three.
   *
   * The receiver need not be a bare symbol: a field chain (`p.child.age = 3`)
   * and an indexed element (`xs[i].age = v`) store through to the same heap
   * cell, and {@link Walker.receiverType} resolves both structurally from the
   * declared parameter types.
   *
   * Those declared types are the only usable evidence here: inside a `Function`
   * literal the body is not yet in a frame that binds the parameters, so
   * canonicalizing the receiver and reading its type reports `unknown` and
   * decides nothing. Everything the declaration does not positively establish —
   * a parameter with no annotation, a step of the chain whose type is not an
   * object — answers `false` and takes the conservative `scope` path.
   *
   * `isObjectFieldStore()` in `effects-of.ts` decides the same question for the
   * runtime channel, by the same rule on the evidence available there (a bare
   * symbol off its definition, anything else off its canonical type). The two
   * must not disagree about the same assignment.
   */
  private propertyStoreTarget(
    expr: Expression & FunctionInterface
  ): { receiver: Expression; name: string; protocol?: string } | undefined {
    const target = expr.ops[0];
    // The QUALIFIED spelling `p.(P.name) = v` keeps its
    // `ProtocolProperty(P, "name", p)` target through canonicalization. It is
    // unconditionally a store: a protocol that declares a settable property
    // admits object conformers only, and the write goes to an accessor either
    // way. No receiver evidence is needed, and none is available inside an
    // unentered literal anyway.
    if (isFunction(target, 'ProtocolProperty') && target.ops.length === 3) {
      const name = target.ops[1];
      const receiver = target.ops[2];
      if (!isString(name) || receiver === undefined) return undefined;
      const protocol = target.ops[0];
      return {
        receiver,
        name: name.string,
        protocol: isString(protocol) ? protocol.string : sym(protocol),
      };
    }
    if (!isFunction(target, 'Field')) return undefined;
    const name = target.ops[1];
    const receiver = target.ops[0];
    if (!isString(name) || receiver === undefined) return undefined;
    // One predicate for both channels — see `mayStoreIntoReceiverOfType` in
    // `effects-of.ts` for the rule and why an undecided type, and a union with
    // an object arm, both count.
    if (!mayStoreIntoReceiverOfType(this.receiverType(receiver)))
      return undefined;
    return { receiver, name: name.string };
  }

  /**
   * Does the receiver's DECLARED layout own `name` as a stored field?
   *
   * The static counterpart of `layoutDeclaresField()` in `effects-of.ts`: when
   * the layout declares the name, the assignment is a slot store and no
   * protocol accessor can run (`objectLayoutOwnsField()` in
   * `library/collections.ts` states that precedence). `false` whenever the
   * declaration does not settle it, which keeps the accessor union — the
   * conservative direction.
   */
  private layoutOwns(receiver: Expression | undefined, name: string): boolean {
    const declared = this.receiverType(receiver);
    if (declared === undefined) return false;
    return objectLayoutOfType(declared)?.elements[name] !== undefined;
  }

  /**
   * The static type of an assignment target's RECEIVER, resolved structurally
   * from the declared parameter types — no canonicalization and no evaluation,
   * because inside an unentered `Function` literal neither is available.
   *
   * Three shapes, so that a store reaches the same verdict however deep the
   * receiver is written: a bare symbol is a parameter (`p.age = 3`), a `Field`
   * is one step down a chain (`p.child.age = 3`), and an `At` is an element of
   * an indexed collection (`xs[i].age = 3`). All three store through to the
   * very same heap cell — the evaluator walks the chain and stores at the end
   * — so labelling only the bare-symbol case would let a nested store pass as
   * a `scope` write.
   *
   * `undefined` for everything else, and for any step whose type is not an
   * object layout: the caller then takes the conservative path.
   */
  private receiverType(receiver: Expression | undefined): Type | undefined {
    if (receiver === undefined) return undefined;
    const name = sym(receiver);
    if (name !== undefined) return this.paramTypes.get(name);
    if (isFunction(receiver, 'Field')) {
      const base = this.receiverType(receiver.ops[0]);
      const field = receiver.ops[1];
      if (base === undefined || !isString(field)) return undefined;
      return objectLayoutOfType(base)?.elements[field.string];
    }
    if (isFunction(receiver, 'At')) {
      const base = this.receiverType(receiver.ops[0]);
      return base === undefined ? undefined : collectionElementType(base);
    }
    return undefined;
  }

  /** An `Assign`: `{scope}` unless provably confined. */
  private scopeWrite(
    expr: Expression,
    ctx: WalkContext,
    confinable: boolean
  ): void {
    const targets = assignTargets(expr);
    // Destructuring / compound targets are judged per target symbol; any
    // target the analysis cannot resolve ⇒ `scope`.
    // NOTE (2026-08-15): an "implicit local declaration" exemption — treating
    // an `Assign` to a name with no visible outer binding as confined, since
    // evaluation creates a call-local binding — was tried here and REVERTED.
    // It is unsound for a literal that is walked standalone: a closure
    // writing a variable of its ENCLOSING literal (`makeCounter`'s
    // `count := count + 1`) sees the same "no visible binding" as a genuine
    // fresh temp, because the enclosing literal's lexical locals are not in
    // the definition registry — and the closure's arrow then claimed PURE
    // while every call returned a different value. Not provably confined ⇒
    // `scope` stays the rule; a fresh-temp body opts out with a `Declare`
    // (`let`) or a `scope` annotation.
    const confined =
      confinable &&
      targets.length > 0 &&
      targets.every(
        (name) =>
          name !== undefined &&
          ctx.declared.has(name) &&
          !this.captured.has(name)
      );
    if (!confined) {
      this.state.effects = unionEffectSets(this.state.effects, ['scope']);
      this.state.escapingWrite = true;
    }
  }

  /**
   * Union a RESOLVED contributor's effect set into the walk, marking the
   * proven-mutation bit when the set concretely contains `scope`. The `any`
   * set deliberately does NOT mark it: `any` is conservatism (an unresolved
   * or collapsed account), and the default-`!scope` ceiling must never fire
   * on conservatism — only on a positively established world mutation.
   */
  private noteContributorEffects(set: EffectSet | undefined): void {
    this.state.effects = unionEffectSets(this.state.effects, set);
    if (Array.isArray(set) && set.includes('scope'))
      this.state.escapingWrite = true;
  }
}

/**
 * Whether `t` denotes a callable value: the bare `function` primitive, an
 * arrow, or a union/intersection containing one.
 *
 * Deliberately NARROWER than the runtime channel's `couldBeCallable`: `unknown`
 * and `any` are excluded. This predicate arms the unresolved-operand `{any}`
 * rule, and most user-function parameters are typed `unknown` — admitting them
 * would collapse every literal that passes a free symbol to an ordinary head.
 * Only a position DECLARED callable (an arrow slot, the bare `function`
 * primitive, an explicit arrow parameter) says "this operand is a callback".
 *
 * An arrow slot counts — under compatibility admission (Design E §3) it is
 * primitive `function` for every admission and subtyping question, and this is
 * one of them.
 */
function isCallableType(t: Type): boolean {
  if (typeof t === 'string') return t === 'function';
  if (t.kind === 'signature') return true;
  if (t.kind === 'union' || t.kind === 'intersection')
    return (t.types as Type[]).some(isCallableType);
  return false;
}

/**
 * Whether `def` takes a callback in ANY parameter position — see
 * {@link isCallableType}; any arm of an overload set suffices.
 *
 * Deliberately position-INSENSITIVE, as a simplification rather than out of
 * necessity: no operand-order mismatch forces it, and a per-position variant —
 * testing the declared parameter an operand's index resolves to — is perfectly
 * feasible if a case ever calls for it. The question this gate answers is only "could an
 * operand of this operator be a callback at all" — enough to keep the
 * unresolved-operand `{any}` rule off `Add`, `Total` and every other
 * callback-free operator, which is what it exists for.
 */
function acceptsCallable(def: BoxedOperatorDefinition | undefined): boolean {
  if (def === undefined) return false;
  const t = def.signature.type;
  if (typeof t === 'string') return false;
  const arms =
    t.kind === 'signature'
      ? [t]
      : t.kind === 'intersection'
        ? (signatureArms(t) ?? [])
        : [];
  for (const arm of arms) {
    const params = [
      ...(arm.args ?? []),
      ...(arm.optArgs ?? []),
      ...(arm.variadicArg ? [arm.variadicArg] : []),
    ];
    if (params.some((p) => isCallableType(p.type))) return true;
  }
  return false;
}

/**
 * A local symbol bound to a `Function` literal by a statement of the body
 * being walked (`Declare`, `Assign` or `DefineFunction`).
 *
 * `stated` is the effect set that the TYPE of a `Declare` states, when it
 * states one (`let f: () random -> number = …`). Applying the local then
 * contributes that set instead of walking the literal. When the declaration
 * has no type, or a type that states no effects (`() -> number`,
 * `function`), `stated` is `undefined` and the literal is walked.
 */
interface LocalLiteral {
  literal: Expression;
  stated: EffectSet | undefined;
}

/**
 * The sub-expressions an effect walk descends into: the operands of a
 * function expression, and the entry values of a canonical `Dictionary`.
 * `undefined` for a leaf.
 *
 * A canonical `Dictionary` is a separate kind of expression, not a function
 * expression, so a walk that only follows `ops` stops at it. That hides the
 * value of every `Declare(x, Dictionary(value: …))`, which is how Epsil
 * lowers `let x = …`.
 */
function walkedOperands(expr: Expression): readonly Expression[] | undefined {
  if (isFunction(expr)) return expr.ops;
  if (isDictionary(expr)) return expr.values;
  return undefined;
}

/**
 * The value of the entry `key` of a `Dictionary` operand, in either of its
 * two forms: a canonical dictionary, or a RAW
 * `["Dictionary", ["KeyValuePair", key, value], …]` function expression,
 * whose key is a symbol or a string. `undefined` when `op` is not a
 * dictionary or has no such entry.
 */
function dictionaryEntry(
  op: Expression | undefined,
  key: string
): Expression | undefined {
  if (op === undefined) return undefined;
  if (isDictionary(op)) return op.get(key);
  if (!isFunction(op, 'Dictionary')) return undefined;
  for (const kv of op.ops) {
    if (!isFunction(kv, 'KeyValuePair') || kv.nops !== 2) continue;
    const k = kv.ops[0];
    if ((isString(k) ? k.string : sym(k)) === key) return kv.ops[1];
  }
  return undefined;
}

/**
 * The effect set that the type of a `Declare` states, or `undefined` when the
 * declaration has no type, the type cannot be parsed, or the type states no
 * effects.
 *
 * The operand layout follows the `Declare` evaluate handler
 * (`library/core.ts`): after the symbol come an optional positional type and
 * value, and an optional trailing attributes dictionary. A positional type
 * wins over the dictionary's `type` entry.
 */
function declaredEffects(
  ce: ComputeEngine,
  declare: Expression
): EffectSet | undefined {
  if (!isFunction(declare)) return undefined;
  const rest = declare.ops.slice(1);
  const last = rest[rest.length - 1];
  const attrs =
    last !== undefined && (isDictionary(last) || isFunction(last, 'Dictionary'))
      ? last
      : undefined;
  const typeOp =
    rest.length > (attrs === undefined ? 0 : 1)
      ? rest[0]
      : dictionaryEntry(attrs, 'type');
  if (typeOp === undefined) return undefined;
  const source = isString(typeOp) ? typeOp.string : sym(typeOp);
  if (source === undefined) return undefined;
  try {
    return signatureEffects(parseType(source, ce._typeResolver));
  } catch {
    return undefined;
  }
}

/** Whether two effect sets are the same set. */
function sameEffectSet(
  a: EffectSet | undefined,
  b: EffectSet | undefined
): boolean {
  if (a === b) return true;
  if (a === undefined || b === undefined) return false;
  if (a === 'any' || b === 'any') return false;
  return a.length === b.length && a.every((label) => b.includes(label));
}

/**
 * The target symbols of an `Assign`/`Declare` first operand. A destructuring
 * `Tuple`/`List` yields one entry per component; `undefined` marks a component
 * the analysis cannot resolve to a symbol (e.g. `Assign(At(v, 1), …)`), which
 * forces the conservative `scope`.
 */
function assignTargets(expr: Expression): (string | undefined)[] {
  if (!isFunction(expr)) return [undefined];
  const target = expr.ops[0];
  if (target === undefined) return [undefined];
  const name = sym(target);
  if (name !== undefined) return [name];
  if (
    isFunction(target, 'Tuple') ||
    isFunction(target, 'List') ||
    isFunction(target, 'Delimiter') ||
    isFunction(target, 'Sequence')
  )
    return target.ops.map((op) => sym(op));
  // A `Field`-target write — `Assign(Field(p, "name"), v)` — is judged on its
  // BASE symbol. This path is reached only for a receiver whose declared type
  // is DECIDED and is not an object: `Walker.propertyStoreTarget` claims every
  // other `Field` target as a `state` store before `scopeWrite` is called at
  // all, including the ones nothing is known about. What is left writes
  // nothing — `p.name = v` on a record or a tuple is
  // `immutable-value-assignment` — so attributing it to the base binding costs
  // nothing and keeps the ordinary confinement judgement. ONLY `Field` gets
  // this:
  // `Assign(Subscript(L, i), v)` is a SEQUENCE DEFINITION (`L_0 := 1`
  // registers a base case in the engine-wide pending-sequence state — see
  // the Subscript branch of `Assign`'s evaluate in `library/core.ts`),
  // never a local rebind, and an `At` target has no assignment semantics
  // at all today — both stay on the unresolvable-target fallback below.
  // A mutable-object STORE reuses the `Assign(Field(…))` spelling with heap
  // semantics, and it does not reach this branch: `Walker.isFieldStore`
  // recognizes it from the receiver's declared parameter type and contributes
  // `state` without consulting the confinement frontier at all, because heap
  // stores get no confinement exemption (`docs/EFFECTS-MODEL.md`,
  // "Confinement does not apply to `state`"). Any OTHER caller of
  // `assignTargets` on a `Field` target inherits the rebinding reading above,
  // so a new one must make the same distinction.
  if (isFunction(target, 'Field')) {
    const base = sym(target.ops[0]);
    if (base !== undefined) return [base];
  }
  // The `At` target of an `AddTo`, `AddTo(At(L, i), e)`, rebinds the list
  // `L` (`evaluateAddTo()`, `library/control-structures.ts`).
  if (expr.operator === 'AddTo' && isFunction(target, 'At')) {
    const base = sym(target.ops[0]);
    if (base !== undefined) return [base];
  }
  return [undefined];
}

/** The operator definition bound to `name`, or `undefined` when `name` is
 * undeclared or holds a value rather than an operator. */
function operatorDefinitionOf(
  ce: ComputeEngine,
  name: string
): BoxedOperatorDefinition | undefined {
  const def = definitionOf(ce, name);
  return def && 'operator' in def ? def.operator : undefined;
}

/**
 * A head bound to a VALUE rather than to an operator: a function literal stored
 * under a declared signature (`Declare(f, "(…) -> …", (x) ↦ …)`) is the common
 * shape. Returns its arrow effects, or the sentinel `'undeclared'` when the
 * name has no binding at all — the dependency-order case.
 */
function valueSignatureOf(
  ce: ComputeEngine,
  name: string
): EffectSet | undefined | 'undeclared' {
  const def = definitionOf(ce, name);
  if (def === undefined) return 'undeclared';
  if (!('value' in def)) return undefined;
  // The arrow of an INFERRED binding type that came from the `Function`
  // literal the binding holds (`let g = (x) => speak(x)`) states no
  // contract: its effects are what a walk of the literal gave when the type
  // was read. Answer `undefined`, so that the caller walks the stored
  // literal (`storedFunctionLiteral`). That walk also records when the
  // literal reaches a set derived from the conformance registry
  // (`consultsRegistry`), so a caller re-derives its effects when a later
  // conformance adds one. Without this, a caller of `g` whose literal
  // already had an effect (`random`) read the effects of the arrow as a
  // contract and did not see a `scope` effect that a later conformance of
  // `speak` gave to `g`.
  if (def.value.inferredType && storedFunctionLiteral(ce, name) !== undefined)
    return undefined;
  const t = def.value.type?.type;
  const stated = signatureEffects(t as Type | undefined);
  // The local of a block holds its value only in a run of the block, and
  // the walk does not read it. With no effects stated by its type, the
  // literal that the text of its block gives it is walked
  // (`blockLocalLiteral()`); with no such literal, nothing says what it
  // does: it is unresolved, as a name with no definition. A host
  // declaration with no value keeps the optimistic reading
  // (`docs/EFFECTS-MODEL.md`, "Inference").
  if (
    stated === undefined &&
    def.value._blockLocal === true && !def.value._programVariable &&
    storedFunctionLiteral(ce, name) === undefined
  )
    return 'undeclared';
  return stated;
}

/**
 * The `Function` literal a value binding currently HOLDS, when it holds one —
 * the body behind the `ce.declare(name, { type: '(…) -> …' })` +
 * `ce.assign(name, literal)` idiom, whose declared arrow states no effects.
 *
 * Reading the binding's value is gated on the declared type possibly denoting
 * something callable ({@link bindingCouldHoldFunction}): the value slot is a
 * lazy getter that materializes a dynamic value on first read, and an ordinary
 * `x: number` binding must never be materialized by an effect walk.
 */
function storedFunctionLiteral(
  ce: ComputeEngine,
  name: string
): { literal: Expression; home?: Scope } | undefined {
  // The local of a block holds a value only in a run of the block: the walk
  // reads the literal that the text of the block gives it, and never the
  // value of the activation that is current.
  const found = homeBinding(name, walkHome ?? ce.context.lexicalScope);
  if (
    found !== undefined &&
    'value' in found.def &&
    found.def.value._blockLocal === true && !found.def.value._programVariable
  ) {
    // A node boxed in a run reads the local in the activation of the
    // block: the text is the text of the block that it activates.
    const block = scopeActivationTemplate(found.scope) ?? found.scope;
    const literal = blockLocalLiteral(name, block);
    return literal === undefined ? undefined : { literal, home: block };
  }
  const def = definitionOf(ce, name);
  if (def === undefined || !('value' in def)) return undefined;
  // A parameter and the variable of a binder hold a value only in an
  // activation: the walk reads their type, not the value of the activation
  // that is current.
  if (readsActivationHalf(def.value)) return undefined;
  if (!bindingCouldHoldFunction(def.value.type?.type as Type | undefined))
    return undefined;
  const value = def.value.value;
  if (value === undefined || !isFunction(value, 'Function')) return undefined;
  return { literal: value };
}

/** The answers of `blockLocalLiteral()`, for each list of statements that
 * the registry holds (`blockStatementsOf()`) and each name (`null` for
 * none). An entry of the registry that changes is a new list, which starts
 * with no answers. */
const blockLocalLiterals = new WeakMap<
  readonly Expression[],
  Map<string, Expression | null>
>();

/**
 * The function literal that the text of the block whose scope is `scope`
 * gives its local `name`, or `undefined`. There is one when a statement of
 * the block declares the local with a literal as its value
 * (`Declare(h, Function(…))`, `Declare(h, Dictionary(value: Function(…)))`,
 * `DefineFunction(h, Function(…))`), and no other node of the block, at any
 * depth, writes the local (an `Assign`, an `AddTo`, a second declaration, a
 * store through it). The statements are those written
 * (`blockStatementsOf()`), recorded before the block is canonicalized, so
 * the answer does not depend on when it is read. The literal is a fact of
 * the text, not of a run: the answer is the same inside a run of the block
 * and after it. Its walk, and the walk of a literal nested in it, reads
 * names from the scope of the block (`walkLiteral()`).
 */
function blockLocalLiteral(name: string, scope: Scope): Expression | undefined {
  const statements = blockStatementsOf(scope);
  if (statements === undefined) return undefined;
  let memo = blockLocalLiterals.get(statements);
  if (memo === undefined) {
    memo = new Map();
    blockLocalLiterals.set(statements, memo);
  }
  const known = memo.get(name);
  if (known !== undefined) return known ?? undefined;
  let literal: Expression | undefined;
  for (const statement of statements) {
    if (
      !isFunction(statement, 'Declare') &&
      !isFunction(statement, 'DefineFunction')
    )
      continue;
    if (sym(statement.ops[0]) !== name) continue;
    const value = statement.ops[statement.ops.length - 1];
    literal = isFunction(value, 'Function')
      ? value
      : isFunction(statement, 'Declare')
        ? dictionaryEntry(value, 'value')
        : undefined;
  }
  if (literal !== undefined && !isFunction(literal, 'Function'))
    literal = undefined;
  if (literal !== undefined && writesOf(statements, name) !== 1)
    literal = undefined;
  memo.set(name, literal ?? null);
  return literal;
}

/** The number of nodes of `statements`, at any depth, that write `name`:
 * an `Assign`, `AddTo`, `Declare` or `DefineFunction` whose target is
 * `name`, or whose target mentions it (a store through it). */
function writesOf(statements: readonly Expression[], name: string): number {
  let count = 0;
  const seen = new Set<Expression>();
  const visit = (expr: Expression): void => {
    const ops = walkedOperands(expr);
    if (ops === undefined || seen.has(expr)) return;
    seen.add(expr);
    if (
      isFunction(expr) &&
      (expr.operator === 'Assign' ||
        expr.operator === 'AddTo' ||
        expr.operator === 'Declare' ||
        expr.operator === 'DefineFunction')
    ) {
      const targets = assignTargets(expr);
      if (
        targets.includes(name) ||
        (targets.includes(undefined) &&
          expr.ops[0] !== undefined &&
          expr.ops[0].symbols.includes(name))
      )
        count += 1;
    }
    for (const op of ops) visit(op);
  };
  for (const statement of statements) visit(statement);
  return count;
}

/**
 * Whether a value binding's DECLARED type leaves room for the binding to hold a
 * function — the gate on reading the (lazy) value slot in
 * {@link storedFunctionLiteral}.
 *
 * Deliberately GENEROUS, and deliberately different from {@link isCallableType}
 * next door: an absent, `unknown` or `any` declared type counts, because a
 * binding assigned a literal before any type was declared reads that way. It
 * mirrors `couldBeCallable` in `effects-of.ts`, which gates the runtime
 * channel's read of the very same slot — the two gates decide which bindings
 * are worth consulting, and must not disagree. Being generous here only ever
 * costs a value read that answers "not a literal"; being narrow would silently
 * drop a stored literal's effects.
 */
function bindingCouldHoldFunction(t: Type | undefined): boolean {
  if (t === undefined) return true;
  if (typeof t === 'string')
    return t === 'unknown' || t === 'any' || t === 'function' || t === 'symbol';
  return (
    t.kind === 'signature' ||
    t.kind === 'intersection' ||
    t.kind === 'union' ||
    t.kind === 'reference'
  );
}
