import { Complex } from 'complex.js';
import { isLibraryOperator, shadowsLibraryName } from '../library-shadowing.js';
import { canonicalBranch } from '../statement-position.js';
import { BigDecimal } from '../../big-decimal/index.js';
import type {
  ExpressionInput,
  Expression,
  CanonicalOptions,
  IComputeEngine as ComputeEngine,
  Metadata,
  Scope,
  BoxedDefinition,
  BoxedValueDefinition,
  BoxedOperatorDefinition,
} from '../global-types.js';
import type { FormOption } from '../types-serialization.js';

import type {
  MathJsonExpression,
  ExpressionObject,
  MathJsonSymbol,
} from '../../math-json/types.js';
import {
  hasMetaData,
  matchesNumber,
  matchesString,
  matchesSymbol,
  stringValue,
  symbol,
} from '../../math-json/utils.js';
import { isValidSymbol, validateSymbol } from '../../math-json/symbols.js';
import { checkDeadline } from '../../common/interruptible.js';

import { isOne } from '../numerics/rationals.js';
import { asBigint } from './numerics.js';

import { canonicalAdd } from './arithmetic-add.js';
import { canonicalMultiply } from './arithmetic-mul-div.js';

import { NumericValue } from '../numeric-value/types.js';
import { ExactNumericValue } from '../numeric-value/exact-numeric-value.js';
import {
  NUMERIC_CANONICAL_NAMES,
  canonicalNumericOperator,
  canonicalProductOperands,
} from './canonical-numeric.js';
import { numericCanonicalHandlerName } from './numeric-canonical-registry.js';

import {
  declaredNamesUnavailable,
  hasNamedArguments,
  inlineLiteralSignature,
  namesRequiredOperands,
  normalizeNamedArguments,
  protocolMemberParts,
  qualifiedFieldParts,
  moduleQualifiedName,
  splitNamedArguments,
  valueCalleeSignature,
  withoutParentheses,
  writtenArgumentSlots,
  type WrittenArgumentSlot,
} from './named-arguments.js';
import { qualifiedMemberRequirementShape } from '../engine-protocols.js';
import { resolveFieldCallee } from './field-callee.js';
import { constantFieldLiteral } from './constant-field.js';
import { recordCanonicalFailure } from './canonical-failure.js';
import { multiClauseState } from '../multi-clause.js';

import { _BoxedExpression } from './abstract-boxed-expression.js';
import { evidenceAdmissionOf } from './value-membership.js';
import {
  BoxedFunction,
  broadcastableParamSlots,
  paramsAreScalar,
  pointListParamSlots,
} from './boxed-function.js';
import type { CallbackSlot, Threadable } from './generic-instantiation.js';
import {
  contextualCallbackPlan,
  hasCallbackParam,
  instantiateCallbackSlots,
  dictionaryValueSolveTypeAt,
} from './generic-instantiation.js';
import { BoxedString } from './boxed-string.js';
import { BoxedDictionary } from './boxed-dictionary.js';
import { canonicalForm } from './canonical.js';
import { sortOperands } from './order.js';
import {
  validateArguments,
  devolveAtValuePositions,
  devolveValueElements,
  isAnnotatedValueParameter,
  inferCollectionSourceArgs,
  isCollectionSourceOperator,
  refusedCollectionSourceOperands,
  inferGenericBoundArgs,
  inferNumericArgs,
  pointComponentRefuted,
  refusesAbsentArgument,
  runtimeCheckExemptParam,
} from './validate.js';
import {
  overloadArms,
  paramAt,
  resolveContextualArm,
  type OverloadResolution,
} from './overload.js';
import {
  isSubtype,
  valueKindDeclaration,
  widen,
} from '../../common/type/subtype.js';
import { typesOverlap } from '../../common/type/reduce.js';
import {
  COLLECTION_SHAPE_TYPE,
  NUMERIC_TYPES,
} from '../../common/type/primitive.js';
import {
  isWildcardFunctionType,
  resolveTypeAlias,
  resolveTypeForCompilation as resolveType,
  placeholderSlotsAs,
  signatureArms,
  withoutKindArms,
} from '../../common/type/utils.js';
import { KIND_PRIMITIVES, kindTypeNames } from './value-kinds.js';
import { typeToString } from '../../common/type/serialize.js';
import {
  freeTypeVariables,
  groundSkeleton,
  parameterPositions,
  readTypeVariablesAsBounds,
} from '../../common/type/instantiate.js';
import type { FunctionSignature, Type } from '../../common/type/types.js';
import { flatten } from './flatten.js';
import {
  fillParameterDefaults,
  parameterDefaultOperands,
  signatureDefaultOperands,
} from './parameter-defaults.js';
import { isOperatorDef, isValueDef, withOwnHead } from './utils.js';
import {
  isCardinalityOperand,
  isPointParameterType,
} from '../collection-utils.js';
import {
  annotateFunctionLiteralParams,
  lookupApplicable,
  shadowsQualifiedName,
  writtenUntypedFunctionLiteral,
} from '../function-utils.js';
import {
  canonical,
  imaginaryNumber,
  exactComplexParts,
  exactComplexLiteral,
  narrowFreeSymbolCells,
} from './canonical-utils.js';
import {
  isNumber,
  isFunction,
  isString,
  isSymbol,
  isAbsentSymbol,
  adoptsForeignEngineObject,
  hasInferredType,
  resolvedValueDefinition,
} from './type-guards.js';
import {
  functionLiteralParameterType,
  requiredParameterCount,
} from './function-literal.js';
import { isInferredTypedParameter } from './inferred-annotations.js';
import {
  declaredBinderNamesOf,
  ownIndexClause,
  symbolAtSite,
  replaceAtSite,
  type BindingSiteSelector,
  type OwnIndexClause,
} from './binding-sites.js';
import {
  anyMacroDeclared,
  beginExpansion,
  endExpansion,
  expandMacro,
  isExpanding,
  isMacroDef,
  isNameOperand,
  withSourceOffsets as macroBodyWithSourceOffsets,
} from './macro.js';
import { beginDormantPop, endDormantPop } from './binding-tombstone.js';
import {
  markBinderVariable,
  rebindToBindings,
  rewriteWithBinders,
} from './binders.js';
import { namedLiteralSignatureType } from './effects-inference.js';
import { isIndexReadTuple } from './index-read-tuple.js';
import { isLibraryDefinition } from './implicit-variable-rule.js';
import {
  isProvisionalCaptureOpen,
  noteProvisionalCall,
} from './provisional-application.js';
import {
  freeNameHomeScope,
  unitEnvironmentOfOperands,
} from '../binding-unit.js';
// Dynamic import to avoid circular dependency

/**
 * ### THEORY OF OPERATIONS
 *
 *
 * 1/ The result of boxing is canonical by default.
 *
 *   This is the most common need (i.e. to evaluate an expression you need it
 *   in canonical form). Creating a boxed expression which is canonical from the
 *   start avoid going through an intermediary step with a non-canonical
 *   expression.
 *
 * 2/ When boxing (and canonicalizing), if the function is "scoped", a new
 *    scope is created before the canonicalization, so that any declaration
 *    are done within that scope. Example of scoped functions include `Block`
 *    and `Sum`.
 *
 * 3/ When implementing an `evaluate()`:
 * - if `bignumPreferred()` all operations should be done in bignum,
 *    otherwise, they should all be done in machine numbers.
 * - if a rational is encountered, preserve it
 * - if a `Sqrt` of a rational is encountered, preserve it
 * - if a `hold` constant is encountered, preserve it
 * - if `numericApproximation` is false and one of the arguments is not exact,
 *  return an approximation
 * - if `numericApproximation` is true, always return an approximation
 *
 * NUMERIC APPROXIMATION = FALSE
 * - 2 + 5 -> 7
 * - 2 + 5/7 -> 19/7
 * - 2 + √2 -> 2 + √2
 * - 2 + √(5/7) -> 2 + √(5/7)
 * - 5/7 + 9/11 -> 118/77
 * - 5/7 + √2 -> 5/7 + √2
 * - 10/14 + √(18/9) -> 5/7 + √2
 * - √2 + √5 -> √2 + √5
 * - √2 + √2 -> 2√2
 * - sin(2) -> sin(2)
 * - sin(pi/3) -> √3/2
 * - 2 + 2.1 -> 2 + 2.1
 *
 * NUMERIC APPROXIMATION = TRUE
 * - 2 + 2.1 -> 4.1
 * - 2 + √2.1 -> 3.44914
 * - 5/7 + √2.1 -> 2.16342
 * - sin(2) + √2.1 -> 2.35844
 */

/**
 * Translate a public `FormOption` to the internal
 * `{ canonical, structural }` representation.
 */
/**
 * Boxing options for an operand boxed raw (unbound, uncanonicalized) from
 * inside the boxer — what `ce.expr(x, { form: 'raw' })` resolves to. Sites on
 * the recursive boxing path use `box(ce, x, RAW_OPERAND)` directly rather than
 * the public `ce.expr()`, which re-enters through the scope plumbing (five
 * frames per operand) to install a scope that is already the current one.
 */
const RAW_OPERAND = { canonical: false, structural: false } as const;

/**
 * How many function nodes of the input tree are between the node being boxed
 * now and the root of the boxing pass. Boxing recurses once per level, so this
 * is also, up to a constant factor, how much of the JS stack the pass has
 * already spent.
 *
 * The counter is module-level rather than a field on the engine because what
 * it stands in for — the JS stack — is shared by every engine in the process.
 * A canonical handler may box on a DIFFERENT engine, and those frames sit on
 * the same stack as this pass's, so a per-engine counter would under-report
 * exactly the nesting that a combined pass runs out of stack on.
 *
 * It is set to 0 when a boxing pass starts at the root (`box()` and
 * `boxFunction()` outside an active root repair) and adjusted around the
 * recursive descent in `boxInternal()`. There is no `try`/`finally` around the
 * decrement: a `finally` would cost a frame per level on the very path whose
 * frames are being counted, and an exception thrown mid-descent leaves the
 * counter high only until the next root boxing pass resets it. A high counter
 * is not a correctness problem in any case — it only makes the next pass
 * devolve earlier than it needs to. Added 2026-09-22.
 */
let boxingDepth = 0;

/**
 * True between the moment `boxFunctionInternal()` sets or clears
 * `ce._qualifiedHead` for the node it boxes and the start of the inner call
 * that boxes the node: see there.
 */
let qualifiedHeadSet = false;

/**
 * The nesting depth at which boxing stops recursing and boxes the rest of the
 * subtree with an explicit work stack instead (see `preboxDeepOperands`).
 *
 * 200 levels is well below the depth at which the recursion runs out of stack.
 * Measured 2026-09-22 on Node 26 with the default stack: a left-nested
 * `Subtract` chain from `ce.parse('1-2-3-…')` reached 585 levels, a `Sin` nest
 * 1 171 levels, and the canonicalization of an already raw-boxed chain 702
 * levels. The work stack itself runs at the depth that triggered it, so the
 * threshold must leave room for the deepest single node build below it — a
 * canonical handler that boxes sub-expressions of its own. A third of the
 * smallest measured ceiling leaves that room and still devolves only trees
 * that no ordinary input produces.
 */
let boxingDevolveThreshold = 200;

/**
 * Set the depth at which boxing devolves to a work stack, and return the
 * previous value. Only for tests, which lower it so an ordinary-sized tree
 * takes the devolved route and can be compared against the recursive one.
 * @internal
 */
export function _setBoxingDevolveThreshold(depth: number): number {
  const previous = boxingDevolveThreshold;
  boxingDevolveThreshold = depth;
  return previous;
}

/**
 * Box the operands of a construction: the same result as
 * `ops.map((x) => box(ce, x, options))` (for the dense arrays MathJSON
 * operands are — a hole in a sparse array would be boxed as a missing
 * operand rather than kept as a hole), spelled to spend as few stack frames
 * per nesting level as possible. Boxing recurses once per level of the
 * MathJSON tree, and the frames per level bound how deep a tree can be boxed
 * before `RangeError: Maximum call stack size exceeded` (see `box()`).
 *
 * Two savings. (1) When this construction is already inside a root boxing
 * pass — the inference transaction is open (`_inferenceTxDepth > 0`) AND a
 * root repair is active — both brackets that `box()` puts around
 * `boxInternal()` are no-ops (a nested `beginInferenceTransaction` does not
 * clear `_freshlyInferred` at its end; `withDevolveRepair` with the root
 * active just calls its builder), so `boxInternal()` is called directly. When
 * either bracket is not open — a construction that started at `ce.function()`
 * boxes its first operand with no transaction open — the operand goes through
 * `box()` exactly as before, so the transaction's clearing semantics are
 * unchanged. (2) A `for` loop replaces `Array.prototype.map` and its
 * callback, two frames per level — which is why this is not written as
 * `ops.map(...)`. The choice between `boxInternal` and
 * `box` is made once, before the loop.
 *
 * The two hottest sites (`boxFunctionInternal`'s non-canonical tail and
 * `applyOperatorDefinition`'s canonical operands) inline this loop rather than
 * call it, saving this helper's own frame as well.
 */
function boxOperands(
  ce: ComputeEngine,
  ops: ReadonlyArray<ExpressionInput>,
  options?: {
    canonical?: CanonicalOptions;
    structural?: boolean;
    scope?: Scope;
  }
): Expression[] {
  const boxOne =
    ce._inferenceTxDepth > 0 && ce._boxingState.isRootActive
      ? boxInternal
      : box;
  const result: Expression[] = [];
  for (const x of ops) result.push(boxOne(ce, x, options));
  return result;
}

export function formToInternal(form?: FormOption): {
  canonical: CanonicalOptions;
  structural: boolean;
} {
  if (form === undefined || form === 'canonical')
    return { canonical: true, structural: false };
  if (form === 'raw') return { canonical: false, structural: false };
  if (form === 'structural') return { canonical: false, structural: true };
  // CanonicalForm or CanonicalForm[]
  return { canonical: form, structural: false };
}

/**
 * Resolve the internal `{ canonical, structural }` boxing form from the
 * options accepted by the public creation/parsing entry points
 * (`parse()`, `expr()`, `function()`).
 *
 * The canonical way to specify the form is the `form` option. As a
 * convenience — and to match the creation modes documented for these
 * methods — the `canonical` and `structural` boolean shortcuts are also
 * accepted. An explicit `form` takes precedence; otherwise `structural`
 * takes precedence over `canonical` (structural form is non-canonical but
 * bound).
 */
export function optionsToInternal(options?: {
  form?: FormOption;
  canonical?: CanonicalOptions;
  structural?: boolean;
}): { canonical: CanonicalOptions; structural: boolean } {
  if (!options) return { canonical: true, structural: false };
  const { form, canonical, structural } = options;
  if (form !== undefined) return formToInternal(form);
  if (structural === true) return { canonical: false, structural: true };
  if (canonical !== undefined) return { canonical, structural: false };
  return { canonical: true, structural: false };
}

function boxHold(
  ce: ComputeEngine,
  expr: ExpressionInput | null,
  options: { canonical?: CanonicalOptions }
): Expression {
  if (expr instanceof _BoxedExpression) return expr;

  // Only an ABSENT operand (`['Hold']`, or a `null` hole in the MathJSON) is
  // reported as missing. A held operand is kept as written: `Nothing` and an
  // empty `Sequence` are values of the held expression, not absent operands.
  // `ReleaseHold` canonicalizes them later, and only then is an empty
  // `Sequence` spliced out of a list or of the arguments of a function.
  if (expr === null || expr === undefined) return ce.error('missing');

  // A held macro name is raw, and keeps the name: `ReleaseHold` makes it
  // canonical during an evaluation, so it stays the name
  // (`BoxedSymbol.canonical`).
  const symbolName =
    typeof expr === 'string'
      ? expr
      : typeof expr === 'object' && !Array.isArray(expr) && 'sym' in expr
        ? expr.sym
        : undefined;
  if (symbolName !== undefined && resolvesToMacro(ce, symbolName))
    return box(ce, symbolName, { canonical: false });

  if (typeof expr === 'string') return box(ce, expr, options);

  if (Array.isArray(expr)) {
    const [fnName, ...ops] = expr;
    return new BoxedFunction(
      ce,
      fnName,
      ops.map((x) => boxHold(ce, x, options)),
      { canonical: false }
    );
  }
  if (typeof expr === 'object') {
    if ('fn' in expr) return boxHold(ce, expr.fn, options);
    if ('str' in expr) return new BoxedString(ce, expr.str);
    if ('sym' in expr) return box(ce, expr.sym, options);
    if ('num' in expr) return box(ce, expr.num, options);
  }

  return box(ce, expr, options);
}

/**
 * Given a name and a set of arguments, return a boxed function expression.
 *
 * If available, preserve LaTeX and wikidata metadata in the boxed expression.
 *
 * This is also used internally when `box()` encounters a function expression.
 * The root repair guard is idempotent, so those nested calls join the existing
 * construction while a direct `ce.function()` call establishes one here.
 */
export function boxFunction(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  ops: readonly ExpressionInput[],
  options?: BoxFunctionOptions
): Expression {
  // Nested constructions join the active root repair — `withDevolveRepair`
  // would only hand `build()` straight back through `withRootRepair`. Call
  // through directly instead of via the two wrappers and a closure: this is
  // on the recursive path of every operand boxed, and each frame spent here
  // is stack a deep MathJSON tree cannot use (see `box()`).
  if (ce._boxingState.isRootActive)
    return boxFunctionInternal(ce, name, ops, options);
  // A construction that starts here starts at the root of the JS stack too,
  // so the nesting counter starts over (see `boxingDepth`).
  boxingDepth = 0;
  // A call with a boxed operand is not
  // a new binding unit: the symbols that it makes take the environment of
  // its first boxed operand (`binding-unit.ts`). A call whose operands are
  // all raw is a unit, with an environment of its own.
  const env = unitEnvironmentOfOperands(ops);
  if (env !== undefined)
    return withDevolveRepair(ce, options?.scope, () => {
      ce._boxingState.setUnitEnvironment(env);
      return boxFunctionInternal(ce, name, ops, options);
    });
  return withDevolveRepair(ce, options?.scope, () =>
    boxFunctionInternal(ce, name, ops, options)
  );
}

type BoxFunctionOptions = {
  metadata?: Metadata;
  canonical?: CanonicalOptions;
  structural?: boolean;
  scope?: Scope;
  /** Structural form only: `true` when this node is an operand (at any
   * depth) of a BINDER, an operator whose definition is `scoped` (`Sum`,
   * `Function`, `D`, …). A symbol is then boxed unbound, as the raw form
   * boxes it. A structural binder creates no scope, so the variable it
   * binds would otherwise bind to the definition that the same name has in
   * the enclosing scope (with `k: list<integer>`, the index of
   * `Sum(k^2, Limits(k, 1, 3))` was typed `list<integer>`). Set by
   * `boxFunctionInternal` (`isStructuralBinder`). */
  unboundSymbols?: boolean;
  /** Structural form only: the structural binders around this node, whose
   * names hide a macro (`HiddenBinders`). Set with `unboundSymbols`. */
  hidden?: HiddenBinders;
  /** The definition of `name` in the system scope, given by
   * `ce._libraryCall()`: the call is bound to this definition, also where
   * a binding of the program shadows `name` (`ce._qualifiedHead`). */
  libraryHead?: BoxedDefinition;
};

/**
 * True when `name` is a BINDER: an operator that declares its own variables
 * in a scope of its own when it is canonicalized. That is an operator whose
 * definition is `scoped` (the index of a `Sum`, the variable of a `D`), and
 * `Function`, which is not `scoped` but whose `canonical` handler makes the
 * scope of its parameters. The structural form boxes the operands of a
 * binder with unbound symbols (`unboundSymbols`).
 */
function isStructuralBinder(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  scope: Scope | undefined
): boolean {
  if (name === 'Function') return true;
  const def = lookupApplicable(name, scope ?? ce.context.lexicalScope, ce);
  return def !== undefined && !isValueDef(def) && def.operator.scoped;
}

/**
 * Box the symbol `name` for the structural form. The symbol binds to the
 * definition its name resolves to, so that the type handler of the
 * enclosing function reads its declared type (with `t: tuple<integer,
 * integer>`, `["Add", "t", "t"]` is typed `tuple<integer, integer>`). The
 * structural form keeps the written name: when the canonical form of the
 * name is another expression (`i` and `ImaginaryUnit` box to the complex
 * literal `0 + 1i`, `e` to the symbol `ExponentialE`, `Half` to `1/2`),
 * the symbol is boxed unbound, as the raw form boxes it. A host that reads
 * the structural form of `M(i) = i^2` as the definition of `M` with the
 * parameter `i` then sees the name `i`. Nothing is declared: a name that
 * resolves to no definition is boxed unbound too.
 */
function boxStructuralSymbol(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  metadata?: Metadata
): Expression {
  const bound = ce.symbol(name, {
    canonical: true,
    autoDeclare: false,
    metadata,
  });
  // `ce.symbol()` normalizes the name to NFC: compare with that form, so that
  // a name such as `Å` (which normalizes to `Å`) is not taken for a
  // name that resolved to another expression.
  if (isSymbol(bound, name.normalize())) {
    // Marked for the structural form, so that `subs()` boxes a replacement
    // structurally (`BoxedSymbol._asStructural()`, which leaves a library
    // symbol and a symbol with no definition unchanged). `ce.symbol()`
    // returns a fresh instance for a user definition, so it is marked in
    // place.
    const symbol = bound as Expression & {
      _asStructural?: (inPlace: boolean) => Expression;
    };
    return symbol._asStructural?.(true) ?? bound;
  }
  return ce.symbol(name, { canonical: false, metadata });
}

/**
 * The structural binders and lazy calls around the node being boxed,
 * innermost first. A structural binder makes no scope, so a macro of a name
 * that one of them binds, or that a lazy call writes at an operand that takes
 * a name, is hidden by this record, not by the lookup (rule 6 of
 * `docs/plans/2026-11-12-macro-kind-spec.md`). A node pushes its head and its
 * operands as written; the names are found only when a name below it
 * resolves to a macro (`isHiddenByBinder()`). Made only on an engine with a
 * macro (`hidesNames()`).
 */
type HiddenBinders = {
  readonly head: MathJsonSymbol;
  readonly ops: ReadonlyArray<ExpressionInput>;
  readonly parent: HiddenBinders | undefined;
  names?: ReadonlySet<string>;
};

/** True when one of the binders `binders` binds `name`
 * (`structuralBinderNames()`, computed once per binder). */
function isHiddenByBinder(
  ce: ComputeEngine,
  binders: HiddenBinders | undefined,
  name: string
): boolean {
  for (let b = binders; b !== undefined; b = b.parent) {
    b.names ??= new Set(structuralBinderNames(ce, b.head, b.ops));
    if (b.names.has(name)) return true;
  }
  return false;
}

/**
 * The expansion of the macro that the name `name`, written in the input,
 * denotes at this place (`macro.ts`), or `undefined` when the name does not
 * resolve to a macro definition. `options` are the options the name is boxed
 * with, and the body is boxed with the same ones.
 *
 * The raw form never expands. A name resolves as `ce.symbol()` resolves it: a
 * parameter of the function literal being canonicalized
 * (`ce._isShadowedParameter()`) and every definition up the scope chain
 * (an index, a local, a declaration of a pushed scope) come before a macro
 * of an outer scope. Below a structural binder, a name that the binder binds
 * is not expanded (`HiddenBinders`).
 */
function macroAt(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  options: {
    canonical?: CanonicalOptions;
    structural?: boolean;
    scope?: Scope;
    unboundSymbols?: boolean;
    hidden?: HiddenBinders;
  },
  sourceOffsets?: [start: number, end: number]
): Expression | undefined {
  if (!anyMacroDeclared(ce)) return undefined;
  if (options.canonical === false && options.structural !== true)
    return undefined;
  const def = resolvesToMacro(ce, name);
  if (def === undefined) return undefined;
  if (isHiddenByBinder(ce, options.hidden, name)) return undefined;
  return expandMacro(ce, def, name, sourceOffsets, (body) =>
    box(ce, body, {
      canonical: options.canonical,
      structural: options.structural,
      scope: options.scope,
      unboundSymbols: options.unboundSymbols,
      hidden: options.hidden,
    })
  );
}

/** The macro definition that `name` resolves to here, as `ce.symbol()`
 * resolves it (a parameter of the function literal being canonicalized
 * first), or `undefined`. */
function resolvesToMacro(
  ce: ComputeEngine,
  name: MathJsonSymbol
): BoxedValueDefinition | undefined {
  if (
    !anyMacroDeclared(ce) ||
    !ce._macroNames.has(name) ||
    ce._isShadowedParameter(name)
  )
    return undefined;
  const def = ce.lookupDefinition(name);
  return isMacroDef(def) && isValueDef(def) ? def.value : undefined;
}

/**
 * The names that the structural binder `name(…ops)` binds in its operands:
 * the binding sites that its operator definition declares
 * (`declaredBinderNamesOf()`, the table that `binderSitesOf()` of Epsil
 * reads), and, for a `Block`, the names of its top-level `Declare` and
 * `DefineFunction` statements. Clause visibility is not read: a name bound by
 * a later clause is taken as bound in the whole node.
 */
function structuralBinderNames(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  ops: ReadonlyArray<ExpressionInput>
): readonly string[] {
  return binderNamesOf(
    ce,
    name,
    ops.map((op) => shallowRaw(ce, op, BINDING_SITE_DEPTH))
  );
}

/** How deep a binding site can be below an operand of a binder: the index
 * of `Element(Tuple(p, q), pairs)` is at depth 2. */
const BINDING_SITE_DEPTH = 3;

/** `x` boxed raw down to `depth` levels of function nodes, with `Nothing` in
 * place of a deeper node: enough for the binding-site selectors, without
 * boxing the body of a deep tree once for each binder that holds it. */
function shallowRaw(
  ce: ComputeEngine,
  x: ExpressionInput,
  depth: number
): Expression {
  if (x instanceof _BoxedExpression) return x;
  const fn: ReadonlyArray<unknown> | undefined = Array.isArray(x)
    ? x
    : typeof x === 'object' && x !== null && 'fn' in x
      ? (x as { fn: ReadonlyArray<unknown> }).fn
      : undefined;
  const head = fn?.[0];
  if (fn === undefined || typeof head !== 'string')
    return box(ce, x, { canonical: false });
  if (depth === 0) return ce.symbol('Nothing');
  return new BoxedFunction(
    ce,
    head,
    fn.slice(1).map((op) => shallowRaw(ce, op as ExpressionInput, depth - 1)),
    { canonical: false }
  );
}

/** True when the structural node `name(…)` hides names from a macro in its
 * operands (`HiddenBinders`): a binder, or a lazy operator, whose operands
 * can take a name. */
function hidesNames(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  scope: Scope | undefined
): boolean {
  if (name === 'Function') return true;
  const def = lookupApplicable(name, scope ?? ce.context.lexicalScope, ce);
  return (
    def !== undefined &&
    !isValueDef(def) &&
    (def.operator.scoped || def.operator.lazy)
  );
}

/**
 * The names written at the operands of `name(…raw)` that take a name
 * (`isNameOperand()`): the operand when it is a symbol, each symbol element
 * of a `List` there, and the first operand of a `Tuple`, a `Pair`, an
 * `Element` or a `To` there or in that list (`Solve(eq, [x, y])`,
 * `FindRoot(f, [(a, 1)])`, `Solve(eq, Element(x, Reals))`,
 * `Limit(f, To(x, a))`). The other fields of such a spec (a start value, a
 * domain, a point) are not names.
 */
function nameOperandNames(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  raw: ReadonlyArray<Expression>
): string[] {
  const def = lookupApplicable(name, ce.context.lexicalScope, ce);
  if (def === undefined || isValueDef(def)) return [];
  const names: string[] = [];
  const spec = (x: Expression, inList: boolean) => {
    if (isSymbol(x)) names.push(x.symbol);
    else if (
      isFunction(x, 'Tuple') ||
      isFunction(x, 'Pair') ||
      isFunction(x, 'Element') ||
      isFunction(x, 'To')
    ) {
      if (isSymbol(x.op1)) names.push(x.op1.symbol);
    } else if (!inList && isFunction(x, 'List'))
      for (const y of x.ops) spec(y, true);
  };
  for (let i = 0; i < raw.length; i++)
    if (isNameOperand(name, def.operator, i, raw)) spec(raw[i], false);
  return names;
}

/** `structuralBinderNames()` for operands boxed raw. */
function binderNamesOf(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  raw: ReadonlyArray<Expression>
): readonly string[] {
  const names = [
    ...declaredBinderNamesOf(ce, name, raw),
    ...nameOperandNames(ce, name, raw),
  ];
  if (name === 'Block')
    for (const op of raw)
      if (
        (isFunction(op, 'Declare') || isFunction(op, 'DefineFunction')) &&
        isSymbol(op.op1)
      )
        names.push(op.op1.symbol);
  return names;
}

/**
 * Stride for the canonicalization walk's deadline check (see
 * `boxFunctionInternal`), the idiom `common/interruptible.ts` documents.
 *
 * The walk is a plain recursion, not a generator, so `run()`/`runAsync()` —
 * which enforce a deadline BETWEEN yields — do not apply to it. Without an
 * in-walk check the deadline was honored only at the boundaries BETWEEN
 * canonicalization calls, so a single long walk ran to completion no matter
 * how small the budget: measured 2026-08-15, a 12 000-term sum parsed under
 * `ce.withTimeLimit({ ms: 1 })` ran 2 799 ms to completion — a 2 799×
 * overrun, and unbounded in the input size rather than the ~2× recorded when
 * the item was filed. A deadline is a correctness boundary, so an unbounded
 * overrun is a defect independent of how large today's workloads are.
 *
 * At the canonicalization cost measured above (~6.5 µs/node) 1024 nodes is
 * roughly 6 ms, so the residual overrun is bounded by one stride rather than
 * by the size of the input.
 */
const CANONICALIZE_DEADLINE_STRIDE = 0x3ff;

function boxFunctionInternal(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  ops: readonly ExpressionInput[],
  options?: BoxFunctionOptions
): Expression {
  // The boxing of a library call made by `ce._libraryCall()` (the option
  // `libraryHead`) binds each node of its name to the library definition
  // (`ce._qualifiedHead`). The boxing of every other node, an operand of
  // that call among them, clears the field until it ends, so that an operand
  // is boxed in the current scope. The field is set or cleared here, and the
  // function is entered again with `qualifiedHeadSet`, which this entry
  // resets at once, so a nested boxing sees `false`. In the usual case, with
  // no such call in progress, this costs two field reads and one write.
  const libraryHead = options?.libraryHead;
  if (
    !qualifiedHeadSet &&
    (libraryHead !== undefined || ce._qualifiedHead !== undefined)
  ) {
    const outer = ce._qualifiedHead;
    ce._qualifiedHead =
      libraryHead !== undefined ? { name, definition: libraryHead } : undefined;
    qualifiedHeadSet = true;
    try {
      return boxFunctionInternal(ce, name, ops, options);
    } finally {
      qualifiedHeadSet = false;
      ce._qualifiedHead = outer;
    }
  }
  qualifiedHeadSet = false;

  // A deadline frame is armed only by an enclosing `ce.withTimeLimit()` span,
  // so work outside a span pays one `undefined` comparison and nothing else.
  //
  // The stride counter lives ON THE FRAME, not in a module-level variable, so
  // it counts the nodes of the span that armed it and only those. A shared
  // counter would let a nested canonicalization on a DIFFERENT engine consume
  // stride boundaries — reachable, because a canonical handler runs arbitrary
  // caller code — at moments when the engine being checked has no frame armed;
  // the check is then a no-op and the engine that DOES have a budget waits up
  // to another full stride, so the one-stride bound above would not hold.
  const frame = ce._deadlineFrame;
  if (
    frame !== undefined &&
    ((frame.tick = (frame.tick ?? 0) + 1) & CANONICALIZE_DEADLINE_STRIDE) === 0
  )
    checkDeadline(frame);

  options = options ? { ...options } : {};
  if (!('canonical' in options)) options.canonical = true;
  // `ce._qualifiedHead` holds the library head now. Some routes below pass
  // `options` on to the boxing of an operand, which must not see it.
  if (libraryHead !== undefined) delete options.libraryHead;

  if (!isValidSymbol(name)) {
    throw new Error(
      `Unexpected operator: "${name}" is not a valid symbol: ${validateSymbol(
        name
      )}`
    );
  }

  const structural = options.structural ?? false;

  // The operands of a structural binder, at any depth, box their symbols
  // unbound (see `BoxFunctionOptions.unboundSymbols`).
  if (
    structural &&
    options.unboundSymbols !== true &&
    isStructuralBinder(ce, name, options.scope)
  )
    options.unboundSymbols = true;
  // The names it binds hide a macro in its operands (`macroAt()`).
  if (structural && anyMacroDeclared(ce) && hidesNames(ce, name, options.scope))
    options.hidden = { head: name, ops, parent: options.hidden };

  // Deep tree: box what is left of it with an explicit work stack instead of
  // recursing into it (see `preboxDeepOperands`). The operands come back
  // already boxed, so the construction below proceeds exactly as it would for
  // a caller that had handed over boxed operands, and the recursion stops
  // growing here.
  if (boxingDepth >= boxingDevolveThreshold) {
    const preboxed = preboxDeepOperands(ce, name, ops, options);
    if (preboxed !== null) ops = preboxed;
  }

  // An operand that IS, or that transitively CONTAINS, an object from another
  // engine cannot be adopted into this engine's expression (see the same check
  // in `boxInternal`). In a session that has never constructed an object this
  // is a single boolean read for the whole operand list; only once an object
  // exists anywhere does the per-operand walk run.
  if (adoptsForeignEngineObject(ops, ce))
    return ce.error('object-foreign-engine');

  //
  // Hold
  //

  if (name === 'Hold') {
    // `Hold` takes one operand. Each extra operand is reported as an
    // `unexpected-argument` error, as for any other operator (`Sin(1, 2)` is
    // `Sin(1, Error('unexpected-argument', '2'))`). They were dropped with no
    // error, so `Hold(x, 1)` was the valid `Hold(x)`. The node is built as
    // canonical, so no signature check runs after this one. The operands
    // are not flattened (`checkArity()` would flatten a `Sequence`): a held
    // operand is kept as written. An operand that is already this error
    // (the node is boxed again from its boxed operands) is kept as it is.
    const held = [boxHold(ce, ops[0] ?? null, options)];
    for (const op of ops.slice(1)) {
      const extra = boxHold(ce, op, options);
      held.push(
        isFunction(extra, 'Error') &&
          isString(extra.op1) &&
          extra.op1.string === 'unexpected-argument'
          ? extra
          : ce.error('unexpected-argument', extra.toString())
      );
    }
    return new BoxedFunction(ce, 'Hold', held, {
      ...options,
      canonical: true,
      structural,
    });
  }

  //
  // Error
  //
  if (name === 'Error' || name === 'ErrorCode') {
    return new BoxedFunction(ce, name, boxOperands(ce, ops, RAW_OPERAND), {
      metadata: options?.metadata,
      canonical: true,
    });
  }

  //
  // Number
  //
  if (name === 'Number' && ops.length === 1) return box(ce, ops[0], options);

  const canonicalNumber = structural === false && options.canonical === true;

  // If canonical, handle cases of various expression structures being able to
  // be cast as BoxedNumbers (some cases of Negate, Rational, Divide, Complex),
  // or 'de-number' some 'borderline invalid' boxed number-like expressions
  // (!@note: this procedure is similarly repeated within the 'number'
  //  CanonicalForm, but the numberForm variant more simply applies to fully
  // BoxedExprs., and during partial canonicalization only)
  //
  // Skipped when a user definition shadows the head (`function Divide(x, y)
  // { … }`): the fold would answer the library operator's value, not the
  // user's (see `shadowsLibraryName`, `library-shadowing.ts`).
  if (
    canonicalNumber &&
    !(
      (name === 'Divide' ||
        name === 'Rational' ||
        name === 'Complex' ||
        name === 'Negate') &&
      shadowsLibraryName(ce, name)
    )
  ) {
    //
    // Rational (as Divide)
    //
    if ((name === 'Divide' || name === 'Rational') && ops.length === 2) {
      // A float operand is not folded to a rational, also when its value is
      // an integer: `asBigint` reads the float `2.0` as the integer 2, and
      // `Divide(1, 2.0)` was the exact `1/2`. A float operand makes the
      // quotient a float, so such a quotient is left to `canonicalDivide()`,
      // as it is on the boxing route of a MathJSON `{num: "2.0"}`.
      const n = ops.some(
        (op) => op instanceof _BoxedExpression && isNumber(op) && !op.isExact
      )
        ? null
        : asBigint(ops[0]);
      if (n !== null) {
        const d = asBigint(ops[1]);
        if (d !== null) {
          // Handle division by zero: a/0 = ~∞ (a pole), and 0/0 is the
          // indeterminate form `NaN`. A float operand (`0.0`) does
          // not reach this fold (see above).
          if (d === 0n) return n === 0n ? ce.NaN : ce.ComplexInfinity;
          return ce.number([n, d], options);
        }
      }
      // The `Rational` spelling is an `(integer, integer)` constructor
      // (ruled 2026-08-24). Renaming to `Divide` erases that contract, so a
      // proven non-integer argument — a literal, or a symbol holding one —
      // used to become plain division (`Rational(3, 2.5)` evaluated to
      // `1.2`), which almost always indicates a caller error. Reject it
      // here; a valueless symbol may still turn out integral, so it stays
      // admitted and proceeds as division. (The `Divide` spelling carries
      // no integer contract and is renamed unconditionally.)
      if (name === 'Rational') {
        const pair = ops.map((op) =>
          op instanceof _BoxedExpression ? op.canonical : box(ce, op, options)
        );
        if (pair.some((op) => evidenceAdmissionOf(op, 'integer') === 'refute'))
          return new BoxedFunction(
            ce,
            'Rational',
            pair.map((op) =>
              evidenceAdmissionOf(op, 'integer') === 'refute'
                ? ce.typeError('integer', op.type, op)
                : op
            ),
            { canonical: true }
          );
        // Not refuted: flow the canonicalized operands forward — the
        // Divide path below would otherwise re-canonicalize the raw
        // operands from scratch.
        ops = pair;
      }
      name = 'Divide';
    }

    //
    // Complex
    //
    if (name === 'Complex') {
      if (ops.length === 1) {
        // If single argument, assume it's imaginary
        const imOp =
          ops[0] instanceof _BoxedExpression
            ? ops[0]
            : box(ce, ops[0], options);
        if (isNumber(imOp)) return imaginaryNumber(ce, imOp, options);
        return imOp.mul(ce.I);
      }
      if (ops.length === 2) {
        // Box the real operand so a high-precision bignum literal (e.g. a
        // 50-digit √2) is not truncated to a machine float. When the operand
        // arrives as raw MathJSON (`{ num: '1.414…' }`), reading `machineValue`
        // alone would silently discard the extra digits on re-boxing
        // (`ce.expr(z.json)`).
        const reOp =
          ops[0] instanceof _BoxedExpression
            ? ops[0]
            : box(ce, ops[0], options);
        const imOp =
          ops[1] instanceof _BoxedExpression
            ? ops[1]
            : box(ce, ops[1], options);

        // Exact components (integers, rationals, radicals) reconstruct an
        // EXACT complex value when the pair is representable
        // (`exactComplexLiteral`, `canonical-utils.ts`).
        const parts = exactComplexParts(reOp, imOp);
        if (parts !== null) {
          const exact = exactComplexLiteral(ce, parts, options);
          if (exact !== null) return exact;
          // Two exact components that one exact literal cannot hold
          // (two different radicals, as in `√2 + √3·i`): the symbolic
          // sum `re + im·i`, which keeps both parts exact. The float
          // below would lose the exactness.
          return ce.function('Add', [
            reOp,
            ce.function('Multiply', [imOp, ce.I]),
          ]);
        }

        const re = reOp.re;
        const imDouble = imOp.re;
        if (
          imDouble !== null &&
          re !== null &&
          !isNaN(imDouble) &&
          !isNaN(re)
        ) {
          // Read the imaginary part from its big decimal when it has one: the
          // double is `0` for `10^{-800}` and `Infinity` for `10^{800}`.
          const im = imOp.bignumRe ?? imDouble;
          const imIsZero = typeof im === 'number' ? im === 0 : im.isZero();
          const reIsZero = reOp.bignumRe?.isZero() ?? re === 0;
          if (imIsZero && reIsZero) return ce.Zero;
          if (!imIsZero) {
            const bignumRe = reOp.bignumRe;
            return ce.number(
              ce._numericValue(
                bignumRe !== undefined ? { re: bignumRe, im } : { re, im }
              ),
              options
            );
          }
          return box(ce, ops[0], options);
        }
        // A component that is not a number literal (a symbol, a string, a
        // boolean, a list): the sum `re + im·i` through the `Add` operator,
        // which checks the `number` contract of each operand. The `.add()`
        // method does not check it: `Complex("str", 2)` was the float `NaN`
        // where the symbol route gives an `incompatible-type` error. This
        // branch runs only under the full canonical form (`canonicalNumber`
        // above), so the canonical `Add` is the form the caller asked for.
        return ce.function('Add', [
          reOp,
          ce.function('Multiply', [imOp, ce.I]),
        ]);
      }
      // Another number of operands: the generic route below reports the
      // missing or unexpected operands against the signature, as for the
      // other operators.
    }

    //
    // Negate
    //
    // Distribute over literals
    //
    if (name === 'Negate' && ops.length === 1) {
      const op1 = ops[0];
      if (typeof op1 === 'number') return ce.number(-op1, options);
      if (op1 instanceof BigDecimal) return ce.number(op1.neg(), options);
      const boxedop1 = ce.expr(op1, options);
      if (isNumber(boxedop1)) {
        const num = boxedop1.numericValue;
        return ce.number(typeof num === 'number' ? -num : num.neg(), options);
      }
      ops = [boxedop1];
    }
  }

  if (options.canonical === true)
    return makeCanonicalFunction(
      ce,
      name,
      ops,
      options.metadata,
      options.scope
    );

  // Inlined `boxOperands()` (see there for why): this is the recursive path
  // of every non-canonical operand, and even the helper's own call frame is
  // stack space a deep tree cannot afford.
  const operandOptions = {
    canonical: options.canonical,
    structural,
    scope: options.scope,
    unboundSymbols: options.unboundSymbols,
    hidden: options.hidden,
  };
  const boxOne =
    ce._inferenceTxDepth > 0 && ce._boxingState.isRootActive
      ? boxInternal
      : box;
  const boxedOps: Expression[] = [];
  for (const x of ops) boxedOps.push(boxOne(ce, x, operandOptions));
  return canonicalForm(
    new BoxedFunction(ce, name, boxedOps, {
      metadata: options.metadata,
      canonical: false,
      structural,
      scope: options.scope,
    }),
    options.canonical ?? false,
    options.scope
  );
}

/**
 * The operator names whose operands are NOT boxed the way an ordinary operand
 * of the same construction is boxed, so an operand boxed ahead of the
 * construction would not be the expression the construction expects.
 *
 * `Hold` boxes its operand with `boxHold()`, which leaves every function node
 * below it non-canonical and unbound whatever form the construction is in.
 * `Error` and `ErrorCode` box their operands raw for the same reason. A node
 * with one of these heads is left to the recursion.
 *
 * The definitions of these operators give their operands the `opaque` role,
 * but this set is read by name: a construction that is not fully canonical
 * does not look up the definition of the operator.
 */
const PREBOX_OPAQUE_HEADS: ReadonlySet<string> = new Set([
  'Hold',
  'Error',
  'ErrorCode',
]);

/** The options the operands of a construction are boxed with: `undefined` for
 *  a fully canonical construction (which boxes its operands with no options at
 *  all), the construction's own form otherwise. */
type PreboxOperandOptions =
  | undefined
  | {
      canonical: CanonicalOptions;
      structural: boolean;
      scope: Scope | undefined;
      unboundSymbols: boolean | undefined;
      hidden: HiddenBinders | undefined;
    };

/**
 * May the operands of `name(…ops)` be boxed BEFORE the construction runs, the
 * construction then being handed the boxed operands?
 *
 * The answer is yes when the construction would box each operand on its own,
 * with the same options, and read nothing of the unboxed operand first. It is
 * no whenever the construction decides something about an operand before
 * boxing it — which of them it is, what type it carries, or which scope it
 * belongs to.
 */
function mayPreboxOperands(
  ce: ComputeEngine,
  name: string,
  ops: ReadonlyArray<ExpressionInput>,
  fullyCanonical: boolean,
  scope: Scope | undefined,
  declineBinders: boolean
): boolean {
  if (PREBOX_OPAQUE_HEADS.has(name)) return false;

  // A construction that canonicalizes nothing boxes every operand with one
  // and the same set of options (the tail of `boxFunctionInternal`), so
  // nothing below applies to it, except one case: a structural BINDER boxes
  // its operands with unbound symbols (`BoxFunctionOptions.unboundSymbols`),
  // which are not the options of the construction that contains it. With
  // `declineBinders`, such a node is left to the recursion, which sets that
  // option.
  if (!fullyCanonical)
    return !(declineBinders && isStructuralBinder(ce, name, scope));

  // A named call is permuted into declaration order before any operand is
  // read by position, and a `Spread` operand leaves the final positional
  // operands unknown until evaluation. Both decide WHICH operand sits at a
  // position, so neither can be settled after the operands are boxed.
  if (hasNamedArguments(ops)) return false;
  for (const op of ops)
    if (
      isSpreadOperand(op) ||
      // An inline `Function` literal is annotated from the callee's declared
      // parameter type before it is boxed, so that it canonicalizes once,
      // already annotated (`annotateCallbacksFromSignature`). Boxing it here
      // would canonicalize it unannotated instead.
      mayBeInlineFunctionLiteral(op)
    )
      return false;

  const def = lookupApplicable(name, scope ?? ce.context.lexicalScope, ce);
  // A LAZY operator receives its operands raw and unbound and decides itself
  // what to canonicalize; a SCOPED one canonicalizes its operands in a scope
  // that does not exist yet when this runs. Boxing an operand up front would
  // take that decision away from both.
  if (def !== undefined && !isValueDef(def))
    if (def.operator.lazy || def.operator.scoped) return false;

  return true;
}

/**
 * The head and operands of `x` when the work stack can build `x` itself from
 * its own boxed operands, `null` otherwise.
 *
 * Two node kinds qualify. A MathJSON function node written as an array is
 * built the way `boxInternal()` builds it. A boxed function node that is not
 * canonical yet qualifies only for a fully canonical construction, where the
 * construction would ask it for `.canonical` — a rebuild from its operands —
 * and only when that getter's answer IS that plain rebuild: it answers with
 * the node itself for an invalid node, and rebuilds inside the scope the node
 * was parsed in when it retained one.
 *
 * The MathJSON object form (`{ fn: […] }`) is deliberately not included: it
 * carries metadata that `boxInternal()` threads into the construction and
 * drops the scope option while doing so, so it is left to the recursion. A
 * tree built of those nodes is as deep as boxing can take, as before.
 */
function preboxableNodeOperands(
  x: ExpressionInput,
  fullyCanonical: boolean
): { name: MathJsonSymbol; ops: ReadonlyArray<ExpressionInput> } | null {
  if (Array.isArray(x)) {
    if (typeof x[0] !== 'string') return null;
    return { name: x[0], ops: x.slice(1) as ExpressionInput[] };
  }
  if (!fullyCanonical || !(x instanceof _BoxedExpression)) return null;
  const node = x as _BoxedExpression & Expression;
  if (!isFunction(node) || node.isCanonical || !node.isValid) return null;
  if (node._parseScope !== undefined) return null;
  return { name: node.operator, ops: node.ops };
}

/** Build one node of the work stack from its already-boxed operands: the same
 *  construction the recursion would have performed for that node. */
function buildPreboxedNode(
  ce: ComputeEngine,
  source: ExpressionInput,
  boxedOps: ReadonlyArray<ExpressionInput>,
  operandOptions: PreboxOperandOptions
): Expression {
  if (Array.isArray(source)) {
    // What `boxInternal()` does with a MathJSON function node, with the
    // operands boxed already.
    const forms = operandOptions?.canonical ?? true;
    const fn = (
      ce._boxingState.isRootActive ? boxFunctionInternal : boxFunction
    )(ce, source[0] as MathJsonSymbol, boxedOps, {
      canonical: forms === true,
      structural: operandOptions?.structural ?? false,
      scope: operandOptions?.scope,
      unboundSymbols: operandOptions?.unboundSymbols,
      hidden: operandOptions?.hidden,
    });
    return canonicalForm(fn, forms, operandOptions?.scope);
  }
  // What `BoxedFunction`'s `.canonical` getter does, with the operands
  // canonical already. A node that retained a parse scope never gets here
  // (`preboxableNodeOperands`), so the getter's scope bracket has nothing to
  // restore and is not reproduced.
  const node = source as _BoxedExpression & Expression;
  return ce.function(
    node.operator,
    boxedOps,
    node.sourceOffsets !== undefined
      ? { metadata: { sourceOffsets: node.sourceOffsets } }
      : undefined
  );
}

/**
 * Box the operands of a construction that is already `boxingDevolveThreshold`
 * levels deep, using an explicit work stack instead of the boxing recursion,
 * and return the boxed operand list. Returns `null` when this construction is
 * not one whose operands may be boxed ahead of it (`mayPreboxOperands`), or
 * when none of its operands is a node the work stack can build; the caller
 * then recurses as before.
 *
 * The walk is a post-order traversal of the operand trees: an operand that is
 * a buildable node is descended into, its own operands are boxed first, and
 * the node is then built from them (`buildPreboxedNode`). An operand that is
 * not — a leaf, or a node one of the guards declines — is boxed on the spot,
 * at its position in the walk, by the ordinary recursive route. So the JS
 * stack depth stays bounded whatever the depth of the input, while the ORDER
 * in which operands are boxed, and the construction each node goes through,
 * are the ones the recursion would have produced.
 *
 * For a canonical construction the inference cause is threaded the way
 * `makeCanonicalFunction()` threads it: while the operands of a node are
 * boxed, that node is the cause recorded for any type inferred from them.
 * Without this, every inference below the threshold would be attributed to
 * the one construction that triggered the devolve. A construction that
 * canonicalizes nothing infers nothing and sets no cause, which is what the
 * recursion it replaces does.
 *
 * Added 2026-09-22 for the deep-tree boxing limit ("Boxing a long `1-2-3-…`
 * chain overflows the stack").
 */
function preboxDeepOperands(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  ops: ReadonlyArray<ExpressionInput>,
  options: BoxFunctionOptions
): ExpressionInput[] | null {
  const fullyCanonical = options.canonical === true;

  // A fully canonical construction boxes its operands with NO options
  // (`applyOperatorDefinition`), which is only the same thing as boxing them
  // in this construction's form when that form carries nothing else.
  if (
    fullyCanonical &&
    (options.structural === true || options.scope !== undefined)
  )
    return null;

  // Is there anything here for the work stack to build? Checked before the
  // guards below, which cost a definition lookup: every node the walk builds
  // re-enters this function (it is still past the threshold) with operands
  // that are boxed already, and must leave again cheaply.
  let deep = false;
  for (const op of ops)
    if (preboxableNodeOperands(op, fullyCanonical) !== null) {
      deep = true;
      break;
    }
  if (!deep) return null;

  if (
    !mayPreboxOperands(
      ce,
      name,
      ops,
      fullyCanonical,
      options.scope,
      // The options of this construction already say whether its operands
      // box their symbols unbound.
      false
    )
  )
    return null;

  const operandOptions: PreboxOperandOptions = fullyCanonical
    ? undefined
    : {
        canonical: options.canonical!,
        structural: options.structural ?? false,
        scope: options.scope,
        unboundSymbols: options.unboundSymbols,
        hidden: options.hidden,
      };

  type Frame = {
    /** The node this frame builds, or `null` for the construction that
     *  triggered the devolve: only its operand list is wanted. */
    readonly source: ExpressionInput | null;
    readonly ops: ReadonlyArray<ExpressionInput>;
    readonly boxed: ExpressionInput[];
    /** The inference cause in force while this frame's operands are boxed,
     *  `null` for a construction that canonicalizes nothing. */
    readonly cause: {
      operator: string;
      ops: ReadonlyArray<ExpressionInput>;
    } | null;
    index: number;
    /** The options its operands are boxed with: those of the construction,
     *  with the structural binders around the node (`HiddenBinders`). */
    readonly options: PreboxOperandOptions;
  };

  const stack: Frame[] = [
    {
      source: null,
      ops,
      boxed: [],
      index: 0,
      cause: fullyCanonical ? { operator: name, ops } : null,
      options: operandOptions,
    },
  ];

  const previousCause = ce._inferenceCause;
  try {
    if (fullyCanonical) ce._inferenceCause = stack[0].cause;
    for (;;) {
      const frame = stack[stack.length - 1];
      if (frame.index < frame.ops.length) {
        const op = frame.ops[frame.index];
        const node = preboxableNodeOperands(op, fullyCanonical);
        if (
          node !== null &&
          mayPreboxOperands(
            ce,
            node.name,
            node.ops,
            fullyCanonical,
            operandOptions?.scope,
            operandOptions?.structural === true &&
              operandOptions.unboundSymbols !== true
          )
        ) {
          // Below a structural binder, a nested binder hides the names it
          // binds from a macro, as the recursion does (`boxFunctionInternal`).
          const childOptions =
            frame.options?.structural === true &&
            anyMacroDeclared(ce) &&
            hidesNames(ce, node.name, frame.options.scope)
              ? {
                  ...frame.options,
                  hidden: {
                    head: node.name,
                    ops: node.ops,
                    parent: frame.options.hidden,
                  },
                }
              : frame.options;
          const child: Frame = {
            source: op,
            ops: node.ops,
            boxed: [],
            index: 0,
            cause: fullyCanonical
              ? { operator: node.name, ops: node.ops }
              : null,
            options: childOptions,
          };
          stack.push(child);
          if (fullyCanonical) ce._inferenceCause = child.cause;
          continue;
        }
        // An operand the walk does not descend into — a leaf, or a node one
        // of the guards declines — is boxed HERE, at its position in the
        // walk, and NOT left raw for the construction to box afterwards.
        // Boxing has effects that depend on the order it happens in: a
        // canonical handler declares symbols and infers their types, so the
        // operand boxed first is the one that decides what a shared symbol's
        // type is. The recursion this walk stands in for boxes operands left
        // to right; leaving this one raw would box it AFTER every later
        // sibling that the walk builds on the spot. The skipped subtree
        // recurses from here exactly as it did before — its own depth is
        // what it is.
        //
        // The operand options are the ones the construction would use for
        // this position, and the inference cause in force is this frame's
        // (set when the frame was pushed, restored when a child frame pops),
        // so the boxing is the same in every respect but where it happens.
        // `boxInternal` rather than `box` when both brackets `box()` puts
        // around it are already open, the choice the two operand-boxing
        // loops this stands in for make (`boxFunctionInternal` and
        // `applyOperatorDefinition`).
        frame.boxed.push(
          (ce._inferenceTxDepth > 0 && ce._boxingState.isRootActive
            ? boxInternal
            : box)(ce, op, frame.options)
        );
        frame.index += 1;
        continue;
      }
      stack.pop();
      if (stack.length === 0) return frame.boxed;
      const parent = stack[stack.length - 1];
      if (fullyCanonical) ce._inferenceCause = parent.cause;
      parent.boxed.push(
        buildPreboxedNode(ce, frame.source!, frame.boxed, parent.options)
      );
      parent.index += 1;
    }
  } finally {
    ce._inferenceCause = previousCause;
  }
}

/**
 * Notes about the boxed form:
 *
 * [1] MathJsonExpression with an operator of `Number`, `String`, `Symbol` and `Dictionary`
 *      are converted to the corresponding atomic expression.
 *
 * [2] Expressions with an operator of `Complex` are converted to a (complex) number
 *     or a `Add`/`Multiply` expression.
 *
 *     The precedence of `Complex` (for serialization) is sometimes the
 *     precedence of `Add` (when re and im != 0), sometimes the precedence of
 *    `Multiply` (when im or re === 0). Using a number or an explicit
 *    `Add`/`Multiply` expression avoids this ambiguity.
 *
 * [3] An expression with a `Rational` operator is converted to a rational
 *    number if possible, to a `Divide` otherwise.
 *
 * [4] A `Negate` function applied to a number literal is converted to a number.
 *
 *     Note that `Negate` is only distributed over addition. In practice, having
 * `Negate` factored on multiply/divide is more useful to detect patterns.
 *
 * Note that this function should only be called from `ce.expr()`
 *
 */

/**
 * Mark the start of a (possibly nested) boxing operation. While at least one
 * is in progress, `BoxedSymbol._infer()` records every value definition whose
 * type transitions unknown → concrete into `ce._freshlyInferred` — the
 * forward-computed provenance for `repairFreshMatrixInference`'s "first
 * inferred while canonicalizing this argument" eligibility test. This
 * replaced an eager snapshot of all inferred symbols (a walk over every
 * binding in every scope, per outermost box) that dominated the per-call
 * cost of small operations engine-wide.
 */
export function beginInferenceTransaction(ce: ComputeEngine): void {
  ce._inferenceTxDepth += 1;
}

export function endInferenceTransaction(ce: ComputeEngine): void {
  ce._inferenceTxDepth -= 1;
  if (ce._inferenceTxDepth === 0) ce._freshlyInferred = null;
}

/**
 * True when the boxing validation seam can admit the call without running
 * `validateArguments`: nothing about these operands could be refused, and
 * nothing the check-only validation does besides refusing (a repair, a
 * substitution) applies to them.
 *
 * The signature is a single arm with no type variables, and the operand
 * count fits it. Every operand is either
 * - a SYMBOL that names a value (not an operator — an unapplied operator
 *   symbol is what the devolve repair rewrites), holds no value and has no
 *   static assignment evidence (a held value is exactly what the seam must
 *   check against a ranged parameter), and whose type is a subtype of its
 *   parameter or, at a parameter the runtime conformance check covers,
 *   OVERLAPS it — the rule the full validation applies to a symbolic
 *   operand there; or
 * - a NUMBER literal whose value type is a subtype of its parameter (a
 *   literal `2` at `real<0<..>`; a `NaN` literal is never a subtype of a
 *   numeric carrier and takes the full path, where the NaN policy decides).
 *
 * Everything else takes the full validation: a string (character
 * narrowing), a collection literal (the threadable admission), an
 * application (its type must be derived and tested), `Missing`, a spread;
 * a collection-typed symbol at a scalar parameter overlaps nothing and
 * fails the tests above; and a parameter the runtime conformance check
 * exempts — a callable, a collection kind, `any`, `unknown`, a type
 * variable — is tested by subtype only, never by overlap, because the
 * plain path's specialized admissions decide those. Measured on
 * the trivial heads the seam costs most on: `PoissonDistribution(lam)` and
 * `Element(x, S)` paid about 1.4 µs in `validateArguments` for a call that
 * could not be refused.
 */
function triviallyAdmittedCall(
  ce: ComputeEngine,
  signature: Type,
  ops: ReadonlyArray<Expression>
): boolean {
  if (typeof signature === 'string' || signature.kind !== 'signature')
    return false;
  const required = signature.args ?? [];
  const optional = signature.optArgs ?? [];
  const variadic = signature.variadicArg;
  // A mandatory variadic tail (`+`) needs one operand past every optional
  // position; an optional one (`*`) needs none.
  const minCount =
    variadic !== undefined && signature.variadicMin === 1
      ? required.length + optional.length + 1
      : required.length;
  if (ops.length < minCount) return false;
  if (variadic === undefined && ops.length > required.length + optional.length)
    return false;
  for (let i = 0; i < ops.length; i++) {
    const param =
      i < required.length
        ? required[i].type
        : i < required.length + optional.length
          ? optional[i - required.length].type
          : variadic!.type;
    if (freeTypeVariables(param).size > 0) return false;
    const op = ops[i];
    if (isSymbol(op)) {
      if (op.operatorDefinition !== undefined) return false;
      // A symbol not yet declared holds nothing (it is declared `unknown`
      // on first use); a declared one must hold no value and carry no
      // static assignment evidence. A free name (`binding-unit.ts`) is
      // tested on the definition that its name resolves to.
      const def = resolvedValueDefinition(op);
      if (
        def !== undefined &&
        def.value !== undefined
      )
        return false;
      // A symbol whose type fits the parameter is admitted outright (the
      // `any` parameters of the set family take this branch). Otherwise the
      // plain path's rule for a symbolic operand applies: admitted when its
      // type OVERLAPS the parameter, deferring the decision to the runtime
      // conformance check — so a symbol the numeric-context inference has
      // typed `number` still passes a ranged `real<0<..>` — except at a
      // parameter that check exempts (a callable, a collection kind, a type
      // variable), where the plain path's specialized admissions are the
      // authority and this call takes the full validation.
      const t = op.type.type;
      if (isSubtype(t, param)) continue;
      if (runtimeCheckExemptParam(param)) return false;
      if (typesOverlap(t, param)) continue;
      return false;
    }
    if (isNumber(op)) {
      // Every type is a subtype of `any`, so the type of the literal is not
      // read. Reading it computes the value type of the literal, which for a
      // big-number float costs about 2 µs: a third of the canonical form of
      // a `Tuple` of two floats (the `any*` parameters of `Tuple` and
      // `List`).
      if (param === 'any') continue;
      if (isSubtype(op.type.type, param)) continue;
      return false;
    }
    return false;
  }
  return true;
}

/** True when every declared parameter of `signature` is numeric.
 *
 * A parameter that is a type variable with a numeric bound is not numeric
 * here. When this function returns false, the caller in the boxing step
 * narrows a valueless operand of such a parameter to its bound with
 * `inferGenericBoundArgs()` instead.
 */
function allParamsNumeric(ce: ComputeEngine, signature: Type): boolean {
  if (typeof signature === 'string' || signature.kind !== 'signature')
    return false;
  const params = [
    ...(signature.args ?? []),
    ...(signature.optArgs ?? []),
    ...(signature.variadicArg ? [signature.variadicArg] : []),
  ];
  // A parameter that admits a kind value beside its numbers (the
  // arithmetic operators admit a residue class) is numeric here: a free
  // argument of `x / 2` is inferred a number, as before the `residue` arm.
  const kinds = kindTypeNames(ce);
  return (
    params.length > 0 &&
    params.every((p) => isSubtype(withoutKindArms(p.type, kinds), 'number'))
  );
}

const EMPTY_FRESHLY_INFERRED: ReadonlySet<BoxedValueDefinition> = new Set();

/** Stringify an offending input for an error's context, truncating if huge.
 *  Never throws (JSON.stringify can fail on bigint or circular values). */
function stringifyForError(value: unknown): string {
  let s: string;
  try {
    s = JSON.stringify(value);
  } catch {
    s = String(value);
  }
  if (typeof s !== 'string') s = String(value);
  return s.length > 200 ? s.slice(0, 200) + '…' : s;
}

/**
 * Run `build` as the root construction of the engine, or as a part of the
 * root construction that is active.
 *
 * The root construction records which scopes existed before it began
 * (`EngineBoxingState.isPersistentScope()`): a free name boxed in a scope
 * that the construction made has the scope that the construction is written
 * in as its home scope. `build` is called once; boxing declares no name, so
 * nothing is built again.
 */
function withDevolveRepair(
  ce: ComputeEngine,
  scope: Scope | undefined,
  build: () => Expression
): Expression {
  // Nested constructions join the active root (withRootRepair returns
  // build() directly), so the persistence classifier below would be built
  // and discarded — skip the allocation on this per-node hot path.
  if (ce._boxingState.isRootActive)
    return ce._boxingState.withRootRepair(build);

  // Persistence classifier of the root construction
  // (`EngineBoxingState.isPersistentScope()`): a scope outlives this
  // construction iff it is on a lexical chain that existed when the
  // construction began — the engine's current chain, or the caller-supplied
  // `scope` option's chain (a harvest scope from `ce.createScope()` is
  // persistent but not on the engine's chain). Scopes created DURING the
  // construction (a binder body's scope) are parented onto these chains but
  // never members of them. Walking at query time sees the same chains that
  // existed at capture time: the engine never changes the parent of a
  // scope.
  const bases: Scope[] = [ce.context.lexicalScope];
  if (scope !== undefined) bases.push(scope);
  return ce._boxingState.withRootRepair(
    build,
    (s) => {
      for (const base of bases) {
        // A chain may terminate with `parent: undefined` rather than `null`
        // (`pushScope` builds scopes with `ce.context?.lexicalScope`), so test
        // truthiness, not `!== null`.
        let cur: Scope | null | undefined = base;
        while (cur) {
          if (cur === s) return true;
          cur = cur.parent;
        }
      }
      return false;
    },
    // The scope of these chains
    // whose bindings hold the definition `def` under `name`
    // (`BoxedSymbol._unitWriteScope()`).
    (name, def) => {
      for (const base of bases) {
        let cur: Scope | null | undefined = base;
        while (cur) {
          if (cur.bindings.get(name) === def) return cur;
          cur = cur.parent;
        }
      }
      return undefined;
    }
  );
}

export function box(
  ce: ComputeEngine,
  expr: null | undefined | NumericValue | ExpressionInput,
  options?: {
    canonical?: CanonicalOptions;
    structural?: boolean;
    scope?: Scope;
    unboundSymbols?: boolean;
    hidden?: HiddenBinders;
  }
): Expression {
  beginInferenceTransaction(ce);
  try {
    // Once a root repair is active (i.e. this is an operand of an enclosing
    // construction), `withDevolveRepair` degenerates to calling `build()`.
    // Skip the wrappers: boxing recurses once per level of the MathJSON tree,
    // and the number of stack frames per level bounds how deep a tree can be
    // boxed at all (a left-nested `Subtract` chain from parsing `1-2-3-…`, or
    // `Sin(Sin(…))`, overflows the stack past a few hundred levels).
    if (ce._boxingState.isRootActive) return boxInternal(ce, expr, options);
    // A construction that starts here starts at the root of the JS stack too,
    // so the nesting counter starts over (see `boxingDepth`).
    boxingDepth = 0;
    return withDevolveRepair(ce, options?.scope, () =>
      boxInternal(ce, expr, options)
    );
  } finally {
    endInferenceTransaction(ce);
  }
}

/**
 * Rebuild `expr` as if `ce.expr(expr.json, { form, scope })` had been called,
 * without writing `expr` out as a MathJSON TREE: every symbol resolves afresh
 * in `scope` (or the current scope) and every node is constructed again.
 *
 * Why this exists: `box()` on an already-boxed expression keeps the
 * bindings the expression was boxed with (`canonicalForm` never re-resolves
 * a symbol), so a consumer that needs an expression read under different
 * declarations has had to serialize it and box the MathJSON. `.json` writes
 * a TREE — a sub-expression shared by many parents is written once per path
 * — and on a DAG-shared value that serialization alone can exhaust memory.
 *
 * Both routes below read a function node the way `get json()` does: the
 * operands come from the node's STRUCTURAL form (the parse vocabulary a
 * canonical node was built from), and a parameter annotation that inference
 * wrote on a `Function` literal is left out. A leaf contributes its own
 * MathJSON, a constant-size read, and is not shared (a dictionary's MathJSON
 * serializes its values).
 *
 * **Canonical and partial forms** build the MathJSON as a DAG — each
 * DISTINCT function node becomes ONE array, shared by every parent that
 * reads it, so the build is linear in the distinct nodes — and box it by the
 * ordinary route. The match with `ce.expr(expr.json, …)` therefore holds by
 * construction, including for a subtree that already holds an `Error` node.
 * A rebuild made of BOXED copies gets that case wrong: a boxed node that is
 * invalid answers `.canonical` with itself, so nothing below it would be
 * canonicalized again. Canonical boxing visits every path either way; what
 * is removed is the tree-sized serialization.
 *
 * **The raw and structural forms** canonicalize nothing, so that hazard does
 * not reach them, and for them the OUTPUT can stay shared too: each distinct
 * node is rebuilt once, bottom-up, from already-rebuilt operands, where
 * boxing the MathJSON would allocate a boxed node per path. A held operand
 * (`Hold`) is rebuilt the way `boxHold` boxes MathJSON: its function nodes
 * stay plain non-canonical nodes and its leaves are boxed with the `Hold`
 * node's own options. `boxHold` would not do this for us, because it
 * returns an already-boxed operand unchanged. Both routes read only the
 * MathJSON of leaves and the operator names of function nodes, so an
 * expression from another engine is rebuilt on this one either way.
 */
export function rebind(
  ce: ComputeEngine,
  expr: Expression,
  options?: { form?: FormOption; scope?: Scope }
): Expression {
  const { canonical, structural } = optionsToInternal(options);
  const scope = options?.scope;

  if (canonical !== false) {
    const shared = new Map<Expression, MathJsonExpression>();
    const toSharedJson = (node: Expression): MathJsonExpression => {
      if (!isFunction(node)) return node.json;
      let out = shared.get(node);
      if (out === undefined) {
        out = [node.operator, ...serializedOperands(node).map(toSharedJson)];
        shared.set(node, out);
      }
      return out;
    };
    return box(ce, toSharedJson(expr), { canonical, structural, scope });
  }
  return unboundRebuilder(ce, { structural, scope })(
    [expr],
    undefined,
    false,
    undefined
  )![0];
}

/**
 * The rebuild of `rebind()` for the raw and the structural forms, without
 * recursion (an explicit stack, as `preboxDeepOperands()`): a function that
 * rebuilds the operands `ops`, each distinct node once for each binder record
 * around it, and returns them.
 *
 * With `expand` (the raw operands of a lazy call, `expandMacroOperands()`),
 * it rebuilds in the raw form, keeps a node that nothing below it changed,
 * and returns `undefined` when no operand changed. A raw symbol whose name
 * resolves to a macro is replaced by the raw body of the macro, rebuilt the
 * same way while the macro is in the cycle set; when the name stays a name
 * (an operand that takes a name, or a name that a binder or a lazy call
 * around it binds, `HiddenBinders`), by a fresh raw symbol of the name that
 * `canonical` does not expand (`BoxedSymbol._keptName`). An operand whose
 * role is `opaque` or `held` is kept as it is, also below the call
 * (`operandPolicies()`). A rebuilt node keeps the metadata of the node, and
 * a node that holds no macro name is recorded (`macroFree`), so that a lazy
 * call boxed later from it does not walk it again.
 */
function unboundRebuilder(
  ce: ComputeEngine,
  {
    structural,
    scope,
    expand = false,
  }: { structural: boolean; scope?: Scope; expand?: boolean }
): (
  ops: ReadonlyArray<Expression>,
  policy: ReadonlyArray<OperandPolicy> | undefined,
  underBinder: boolean,
  hidden: HiddenBinders | undefined
) => Expression[] | undefined {
  const nodeOptions: BoxFunctionOptions = structural
    ? { canonical: false, structural: true, scope }
    : { canonical: false, structural: false };
  const rebuilt = new Map<Expression, Expression>();
  const held = new Map<Expression, Expression>();
  const rebuildHeld = (node: Expression): Expression => {
    let out = held.get(node);
    if (out === undefined) {
      out = isFunction(node)
        ? new BoxedFunction(
            ce,
            node.operator,
            serializedOperands(node).map(rebuildHeld),
            { canonical: false }
          )
        : boxHold(ce, node.json, nodeOptions);
      held.set(node, out);
    }
    return out;
  };
  // In the structural form, a node below a BINDER (a `scoped` operator such
  // as `Sum` or `Function`) boxes its symbols unbound, as `box()` does
  // (`BoxFunctionOptions.unboundSymbols`). The same node can be shared by a
  // part of the tree that is below a binder and a part that is not, so each
  // case has its own cache.
  const rebuiltUnderBinder = new Map<Expression, Expression>();
  // With a macro declared, a structural binder or a lazy call hides names
  // from a macro (`HiddenBinders`) while its operands are rebuilt, as when
  // `box()` boxes the MathJSON. The result of a node then depends on the binders
  // around it, so each binder record has its own cache; a record is made once
  // for each rebuild of a binder node.
  const macros = (structural || expand) && anyMacroDeclared(ce);
  const hiddenCaches = new Map<HiddenBinders, Map<Expression, Expression>>();
  const cacheOf = (
    underBinder: boolean,
    hidden: HiddenBinders | undefined
  ): Map<Expression, Expression> => {
    if (hidden === undefined) return underBinder ? rebuiltUnderBinder : rebuilt;
    let c = hiddenCaches.get(hidden);
    if (c === undefined) hiddenCaches.set(hidden, (c = new Map()));
    return c;
  };
  // The scope is the same for the whole rebuild, so a name resolves once.
  const macroOf = new Map<string, BoxedValueDefinition | undefined>();
  const operatorOf = new Map<
    string,
    { hides: boolean; lazy: BoxedOperatorDefinition | undefined }
  >();
  const infoOf = (op: MathJsonSymbol) => {
    let info = operatorOf.get(op);
    if (info === undefined) {
      const def = expand
        ? lookupApplicable(op, scope ?? ce.context.lexicalScope, ce)
        : undefined;
      info = {
        hides: macros && hidesNames(ce, op, scope),
        lazy:
          def !== undefined && !isValueDef(def) && def.operator.lazy
            ? def.operator
            : undefined,
      };
      operatorOf.set(op, info);
    }
    return info;
  };

  type Frame = {
    readonly node: Expression | undefined;
    readonly ops: ReadonlyArray<Expression>;
    readonly policy: ReadonlyArray<OperandPolicy> | undefined;
    readonly underBinder: boolean;
    readonly hidden: HiddenBinders | undefined;
    readonly cache: Map<Expression, Expression> | undefined;
    /** The macros whose body this node is the root of: they leave the cycle
     *  set when the node is done. */
    readonly defs: BoxedValueDefinition[] | undefined;
    i: number;
    /** The rebuilt operands; with `expand`, only once one changed. */
    out: Expression[] | undefined;
    /** No macro name below (`macroFree`). */
    clean: boolean;
  };

  return (ops, policy, underBinder, hidden) => {
    const stack: Frame[] = [];
    const entered: BoxedValueDefinition[] = [];
    const leave = (defs: BoxedValueDefinition[] | undefined): void => {
      if (defs !== undefined) for (const def of defs) endExpansion(def);
    };
    const settle = (
      f: Frame,
      defs: BoxedValueDefinition[] | undefined,
      x: Expression,
      clean: boolean
    ): void => {
      leave(defs);
      give(f, x, clean);
    };
    const give = (f: Frame, x: Expression, clean: boolean): void => {
      if (expand && x !== f.ops[f.i] && f.out === undefined)
        f.out = f.ops.slice(0, f.i);
      f.out?.push(x);
      f.clean &&= clean;
      f.i += 1;
    };
    // Give `f` the rebuild of `x`, its next operand, with whether it holds
    // no macro name; or push a frame for `x`, which gives it when done.
    const visit = (
      f: Frame,
      x: Expression,
      underBinder: boolean,
      hidden: HiddenBinders | undefined,
      asName: boolean
    ): void => {
      let node = x;
      let defs: BoxedValueDefinition[] | undefined;
      if (expand) {
        while (isSymbol(node) && !node.isCanonical) {
          const name = node.symbol;
          if (
            !ce._macroNames.has(name) ||
            (node as { _keptName?: true })._keptName === true
          )
            return settle(f, defs, node, true);
          let def = macroOf.get(name);
          if (def === undefined && !macroOf.has(name))
            macroOf.set(name, (def = resolvesToMacro(ce, name)));
          if (def === undefined) return settle(f, defs, node, false);
          if (asName || isHiddenByBinder(ce, hidden, name))
            return settle(f, defs, keptName(ce, node), true);
          if (isExpanding(def))
            return settle(f, defs, ce.error('macro-cycle', name), true);
          beginExpansion(def);
          entered.push(def);
          (defs ??= []).push(def);
          const offsets = node.sourceOffsets;
          node = box(
            ce,
            offsets === undefined
              ? def.macro!
              : macroBodyWithSourceOffsets(def.macro!, offsets),
            RAW_OPERAND
          );
          asName = false;
        }
        if (
          !isFunction(node) ||
          node.isCanonical ||
          (macroFree.get(node) === ce._macroCount && node.engine === ce)
        )
          return settle(f, defs, node, true);
      }
      const cache = cacheOf(underBinder, hidden);
      const hit = cache.get(node);
      if (hit !== undefined)
        return settle(f, defs, hit, macroFree.get(hit) === ce._macroCount);
      // With `expand`, a function node gets here, and the operand roles of
      // `Hold` keep its operand (`operandPolicies()`).
      if (!isFunction(node) || (!expand && node.operator === 'Hold')) {
        const out = isFunction(node)
          ? boxFunction(
              ce,
              node.operator,
              serializedOperands(node).map(rebuildHeld),
              nodeOptions
            )
          : box(
              ce,
              node.json,
              underBinder || hidden !== undefined
                ? { ...nodeOptions, unboundSymbols: underBinder, hidden }
                : nodeOptions
            );
        cache.set(node, out);
        return settle(f, defs, out, false);
      }
      const nodeOps = expand ? node.ops : serializedOperands(node);
      const info = infoOf(node.operator);
      const binder = structural && isStructuralBinder(ce, node.operator, scope);
      stack.push({
        node,
        ops: nodeOps,
        policy:
          info.lazy !== undefined
            ? operandPolicies(info.lazy.operandRoles(nodeOps), nodeOps)
            : undefined,
        underBinder: underBinder || binder,
        hidden: info.hides
          ? { head: node.operator, ops: nodeOps, parent: hidden }
          : hidden,
        cache,
        defs,
        i: 0,
        out: expand ? undefined : [],
        clean: true,
      });
      return undefined;
    };

    stack.push({
      node: undefined,
      ops,
      policy,
      underBinder,
      hidden,
      cache: undefined,
      defs: undefined,
      i: 0,
      out: expand ? undefined : [],
      clean: true,
    });
    try {
      for (;;) {
        const f = stack[stack.length - 1];
        if (f.i < f.ops.length) {
          const x = f.ops[f.i];
          const p = f.policy?.[f.i];
          if (p === 'skip') give(f, x, false);
          else visit(f, x, f.underBinder, f.hidden, p === 'name');
          continue;
        }
        stack.pop();
        const node = f.node;
        if (node === undefined) return f.out;
        const out =
          f.out === undefined
            ? node
            : boxFunction(
                ce,
                node.operator,
                f.out,
                expand
                  ? {
                      ...nodeOptions,
                      metadata: {
                        latex: node.verbatimLatex,
                        sourceOffsets: node.sourceOffsets,
                      },
                    }
                  : nodeOptions
              );
        f.cache!.set(node, out);
        if (expand && f.clean && out.engine === ce)
          macroFree.set(out, ce._macroCount);
        leave(f.defs);
        give(stack[stack.length - 1], out, f.clean);
      }
    } finally {
      leave(entered);
    }
  };
}

/** True when the raw node `x` of `ce` is known to hold no macro name: a
 * canonical node, a symbol whose name is not a macro name or that is kept as
 * a name, a node recorded by a walk or by `boxRawOperands()` (`macroFree`),
 * or a leaf that is not a symbol. */
function holdsNoMacroName(ce: ComputeEngine, x: Expression): boolean {
  if (x.isCanonical) return true;
  if (isSymbol(x))
    return (
      !ce._macroNames.has(x.symbol) ||
      (x as { _keptName?: true })._keptName === true
    );
  if (!isFunction(x)) return true;
  return macroFree.get(x) === ce._macroCount && x.engine === ce;
}

/**
 * The raw operands `ops` boxed, as `boxOperands(ce, ops, RAW_OPERAND)`. On
 * an engine with a macro, an operand whose boxing made no raw node that can
 * hold a macro name (`IComputeEngine._macroSuspects`) is recorded as holding
 * none (`macroFree`), so the walk of the raw operands of the call
 * (`expandMacroOperands()`) does not visit it.
 */
function boxRawOperands(
  ce: ComputeEngine,
  ops: ReadonlyArray<ExpressionInput>
): Expression[] {
  if (ce._macroCount === 0) return boxOperands(ce, ops, RAW_OPERAND);
  const boxOne =
    ce._inferenceTxDepth > 0 && ce._boxingState.isRootActive
      ? boxInternal
      : box;
  const result: Expression[] = [];
  for (const op of ops) {
    const before = ce._macroSuspects;
    const x = boxOne(ce, op, RAW_OPERAND);
    if (
      ce._macroSuspects === before &&
      isFunction(x) &&
      !x.isCanonical &&
      x.engine === ce
    )
      macroFree.set(x, ce._macroCount);
    result.push(x);
  }
  return result;
}

/** What the walk of the raw operands of a lazy call does with an operand:
 * keep it as it is (`skip`: the role `opaque` or `held`), keep a macro name
 * there as a name (`name`: a symbol with the role `bound` or `clause`), or
 * walk it (`undefined`). */
type OperandPolicy = 'skip' | 'name' | undefined;

/** The `OperandPolicy` of each operand `ops` of a lazy call whose operand
 * roles are `roles`, or `undefined` when every operand is walked. */
function operandPolicies(
  roles: ReadonlyArray<string> | undefined,
  ops: ReadonlyArray<Expression>
): ReadonlyArray<OperandPolicy> | undefined {
  if (roles === undefined) return undefined;
  let out: OperandPolicy[] | undefined;
  for (let i = 0; i < ops.length; i++) {
    const role = roles[i];
    const p: OperandPolicy =
      role === 'opaque' || role === 'held'
        ? 'skip'
        : (role === 'bound' || role === 'clause') && isSymbol(ops[i])
          ? 'name'
          : undefined;
    if (p !== undefined) (out ??= [])[i] = p;
  }
  return out;
}

/** The raw function nodes that hold no macro name of their engine: the
 * value is `ce._macroCount` when that was found, so a later macro
 * declaration voids it. Read and written by the walk of
 * `unboundRebuilder()`; a node is never changed. */
const macroFree = new WeakMap<Expression, number>();

/** A fresh raw symbol of the name of `node`, which `canonical` does not
 * expand (`BoxedSymbol._keptName`). */
function keptName(
  ce: ComputeEngine,
  node: Expression & { readonly symbol: string }
): Expression {
  const kept = ce.symbol(node.symbol, {
    canonical: false,
    metadata: {
      latex: node.verbatimLatex,
      sourceOffsets: node.sourceOffsets,
    },
  });
  if (!kept.isCanonical) (kept as { _keptName?: true })._keptName = true;
  return kept;
}

/** The operands `get json()` serializes for a function node: those of its
 *  structural form, minus a `Function` literal's inference-written parameter
 *  annotations (see `BoxedFunction.json`). The same rule is written again in
 *  `jsonWithSourceOffsets()` and `rawCopyWithSourceOffsets()`
 *  (`engine-declarations.ts`): a change here must be made there too. */
function serializedOperands(
  node: Expression & {
    readonly operator: string;
    readonly ops: ReadonlyArray<Expression>;
  }
): ReadonlyArray<Expression> {
  const s = node.structural;
  const ops = isFunction(s) ? s.ops : node.ops;
  if (node.operator !== 'Function') return ops;
  return ops.map((x, i) =>
    i > 0 && isInferredTypedParameter(x) && isFunction(x) ? x.op1 : x
  );
}

function boxInternal(
  ce: ComputeEngine,
  expr: null | undefined | NumericValue | ExpressionInput,
  options?: {
    canonical?: CanonicalOptions;
    structural?: boolean;
    scope?: Scope;
    unboundSymbols?: boolean;
    hidden?: HiddenBinders;
  }
): Expression {
  if (expr === null || expr === undefined) return ce.error('missing');

  if (expr instanceof NumericValue) return fromNumericValue(ce, expr);

  if (expr instanceof _BoxedExpression) {
    // An object belongs to the engine that constructed it — its pinned type,
    // its state events and its cache dependencies all speak to that engine —
    // so adopting a foreign one here would produce an expression whose
    // invalidation is wired to the wrong place. This route adopts the
    // pre-boxed expression WHOLE, so the check has to be transitive: a `List`
    // or dictionary holding a foreign object is not itself an object, yet
    // adopting it retains the object all the same. Refuse as a value, the
    // errors-as-values convention of every expression route.
    if (adoptsForeignEngineObject([expr], ce))
      return ce.error('object-foreign-engine');

    // The common case — full canonical form, no scope — is exactly the
    // `.canonical` getter; `canonicalForm()` would only add a frame on the
    // recursive path of canonicalizing an already-boxed tree.
    //
    // Canonicalizing an already-boxed tree descends one level per operand
    // too — the `.canonical` getter of a function node rebuilds it from its
    // operands, each of which comes back through here — so this descent is
    // counted like the MathJSON one below (see `boxingDepth`).
    //
    const forms = options?.canonical ?? true;
    // A raw node taken as it is can hold a macro name
    // (`IComputeEngine._macroSuspects`).
    if (forms === false && ce._macroCount > 0 && !holdsNoMacroName(ce, expr))
      ce._macroSuspects += 1;
    // A boxed symbol requested in the structural form is marked for it, as a
    // symbol boxed from MathJSON is (`boxStructuralSymbol()`), so that its
    // `subs()` boxes a replacement structurally. The getter marks a copy, so
    // the canonical symbol given here is not changed.
    if (options?.structural === true && forms === false && isSymbol(expr))
      return expr.structural;
    boxingDepth += 1;
    const canonicalized =
      forms === true && options?.scope === undefined
        ? expr.canonical
        : canonicalForm(expr, forms, options?.scope);
    boxingDepth -= 1;
    return canonicalized;
  }

  options = options ? { ...options } : {};
  if (!('canonical' in options)) options.canonical = true;

  // If canonical is true, we want to canonicalize the arguments
  // If it's false or a CanonicalForm, we don't want to canonicalize the
  // arguments during create, we'll call canonicalForm to take care of it
  const canonical = options.canonical === true;

  const structural = options.structural ?? false;

  //
  //  Box a function
  //
  if (Array.isArray(expr)) {
    if (typeof expr[0] !== 'string') {
      // A function-literal head (or any boxed/array expression head) is
      // treated as an application, e.g.
      //   [["Function", body, "x"], arg] ≡ ["Apply", ["Function", body, "x"], arg]
      // This matches the explicit `Apply` form, which already beta-reduces.
      if (Array.isArray(expr[0]) || expr[0] instanceof _BoxedExpression)
        return box(ce, ['Apply', ...expr] as ExpressionInput, options);

      // Malformed MathJSON: the head of a function array must be a string,
      // an array (function-literal head) or a boxed expression. Return an
      // Error expression rather than throwing so callers boxing untrusted
      // input never have to special-case a JS exception.
      return ce.error('unexpected-mathjson', stringifyForError(expr));
    }

    // `boxFunction()` is only a root-repair dispatcher; with the root
    // already active it would call `boxFunctionInternal()` straight back, so
    // skip its frame (boxing recurses once per level, see `box()`).
    boxingDepth += 1;
    const fn = (
      ce._boxingState.isRootActive ? boxFunctionInternal : boxFunction
    )(ce, expr[0], expr.slice(1) as ExpressionInput[], {
      canonical,
      structural,
      scope: options?.scope,
      unboundSymbols: options.unboundSymbols,
      hidden: options.hidden,
    });
    boxingDepth -= 1;
    return canonicalForm(fn, options?.canonical ?? true, options?.scope);
  }

  //
  // Box a number
  //
  // `bigint` is part of `ExpressionInput` and preserves exact integer-ness
  // regardless of magnitude or engine precision (a large integer literal
  // routed through a float would silently become inexact).
  if (
    typeof expr === 'number' ||
    typeof expr === 'bigint' ||
    expr instanceof BigDecimal ||
    expr instanceof Complex
  )
    return ce.number(expr);

  //
  // Box a boolean primitive as the True/False symbol.
  // Tensors with `dtype: 'bool'` store JS booleans directly, so `.each()`
  // and `.at()` over such a tensor need this case to yield usable
  // symbolic values. Mirrors the `boolean → True/False` mapping in
  // `jsValueToExpression`.
  //
  if (typeof expr === 'boolean') return ce.symbol(expr ? 'True' : 'False');

  //
  // Box a String, a Symbol or a number as a string shorthand
  //
  if (typeof expr === 'string') {
    // Is it a symbol?
    if (matchesSymbol(expr)) {
      const sym = symbol(expr);
      if (!sym || !isValidSymbol(sym)) return ce.error('invalid-symbol', expr);
      // Let 'partial' canonicalization fetch the canonical variant of symbols: in order that at
      // minimum, they may be substituted with associated definition values (when its def. 'holdUntil'
      // is 'never')
      // @note: alternatively, this could be signalled by a 'Symbol' CanonicalForm: but this way is
      // more predictable, & ensures substitution as per above
      // A partial form resolves symbols but never DECLARES them: its output is
      // not fully canonical, so it follows the structural symbol contract and
      // leaves the caller's scope untouched (`autoDeclare: false`). The
      // structural form binds a symbol to its definition but keeps the
      // written name (`boxStructuralSymbol`). A symbol below a structural
      // binder stays unbound (`BoxFunctionOptions.unboundSymbols`).
      if (
        structural &&
        !canonical &&
        options.canonical === false &&
        options.unboundSymbols !== true
      )
        return macroAt(ce, sym, options) ?? boxStructuralSymbol(ce, sym);
      const canonicalSymbol = canonical || options.canonical !== false;
      return (
        macroAt(ce, sym, options) ??
        ce.symbol(sym, {
          canonical: canonicalSymbol,
          autoDeclare: canonical,
        })
      );
    }

    if (matchesNumber(expr)) return ce.number(expr);

    // Must be a string...
    console.assert(matchesString(expr));
    return new BoxedString(ce, stringValue(expr)!);
  }

  //
  // Box a MathJSON object literal
  //
  if (typeof expr === 'object') {
    // Extract metadata (latex, wikidata) from the MathJSON object if present
    const metadata = hasMetaData(expr as ExpressionObject)
      ? {
          latex: (expr as ExpressionObject & { latex?: string }).latex,
          wikidata: (expr as ExpressionObject & { wikidata?: string }).wikidata,
          sourceOffsets: (
            expr as ExpressionObject & {
              sourceOffsets?: [start: number, end: number];
            }
          ).sourceOffsets,
        }
      : undefined;

    if ('fn' in expr) {
      const [fnName, ...ops] = expr.fn;
      boxingDepth += 1;
      const fn = (
        ce._boxingState.isRootActive ? boxFunctionInternal : boxFunction
      )(ce, fnName, ops, {
        canonical,
        structural,
        metadata,
        unboundSymbols: options.unboundSymbols,
        hidden: options.hidden,
      });
      boxingDepth -= 1;
      return canonicalForm(fn, options.canonical!, options.scope);
    }
    if ('str' in expr) return new BoxedString(ce, expr.str, metadata);
    if ('sym' in expr) {
      const macro = macroAt(ce, expr.sym, options, metadata?.sourceOffsets);
      if (macro !== undefined) return macro;
      if (
        structural &&
        !canonical &&
        options.canonical === false &&
        options.unboundSymbols !== true
      )
        return boxStructuralSymbol(ce, expr.sym, metadata);
      return ce.symbol(expr.sym, {
        canonical,
        autoDeclare: canonical,
        metadata,
      });
    }
    if ('num' in expr) return ce.number(expr, { canonical, metadata });
    if ('dict' in expr) {
      // A malformed entry yields a boxed error, not a raw throw — the same
      // contract as the `unexpected-mathjson` fallback below.
      const dict = new BoxedDictionary(ce, expr.dict, { canonical });
      return dict.constructionError ?? dict;
    }

    // Not a recognized MathJSON object (no 'fn'/'str'/'sym'/'num'/'dict'
    // key). Return an Error expression rather than throwing so callers
    // boxing untrusted input never have to special-case a JS exception.
    return ce.error('unexpected-mathjson', stringifyForError(expr));
  }

  return ce.Missing;
}

/**
 * The parameter types an operand at position `idx` could be bound to by a
 * value definition's declared signature — one entry per overload arm (a
 * single entry for a plain signature). Empty when the position is beyond
 * every arm's parameters (an arity error, diagnosed elsewhere).
 *
 * Each type is returned GROUND, because the only consumer asks
 * `provablyDisjoint` whether the operand refutes the parameter, and that
 * predicate requires ground inputs: a quantified signature (`(T) -> list<T>
 * where T: number`) stores its parameters with the variable still free, so
 * handing them over raw walked an open `T` into
 * `provablyDisjoint`/`typeCategory`, which the type-variable design forbids
 * (the dev-time `console.assert` in `assertGroundType`,
 * `common/type/subtype.ts`, is the tripwire for it).
 *
 * Grounding happens on the WHOLE arm, not on the extracted parameter, because
 * a variable's bound lives in the arm's `where` clause (`typeParams`) and is
 * out of reach once the parameter is detached. `readTypeVariablesAsBounds`
 * reads each variable as its declared bound — so `T: number` becomes `number`
 * and a `string` operand provably refutes it, which is the whole point of the
 * check — and an unbounded variable as `unknown`, which nothing refutes.
 * `groundSkeleton` then covers any variable the arm does not itself quantify
 * (one bound by a nested arrow, say), reading it as the widest type admissible
 * at its position so no refutation is ever claimed that the bound does not
 * support.
 */
function candidateParamsAt(valueType: Type, idx: number): Type[] {
  const arms: ReadonlyArray<FunctionSignature> =
    typeof valueType !== 'string' && valueType.kind === 'signature'
      ? [valueType]
      : (overloadArms(valueType) ?? []);

  const result: Type[] = [];
  for (const rawArm of arms) {
    const grounded = readTypeVariablesAsBounds(rawArm);
    const arm: FunctionSignature =
      typeof grounded !== 'string' && grounded.kind === 'signature'
        ? grounded
        : rawArm;
    const args = arm.args ?? [];
    const optArgs = arm.optArgs ?? [];
    if (idx < args.length) result.push(groundSkeleton(args[idx].type));
    else if (idx < args.length + optArgs.length)
      result.push(groundSkeleton(optArgs[idx - args.length].type));
    else if (arm.variadicArg) result.push(groundSkeleton(arm.variadicArg.type));
  }
  return result;
}

/**
 * The `threadable` gate `validateArguments` must see for `sig`.
 *
 * `whenUndeclared` is the pre-existing signature-wide answer (the
 * `opDef.broadcastable` flag, or `paramsAreScalar` on the value-definition
 * route); it is returned unchanged for every signature that declares no
 * `broadcastable<T>` parameter, which is every built-in and every inferred
 * lambda.
 *
 * A signature that DOES declare one answers PER POSITION (Option A,
 * `docs/plans/2026-08-08-broadcastable-param-semantics.md`): the slots the
 * declaration maps elementwise admit a collection operand — the contract is
 * checked per ELEMENT, where the elements exist — while a sibling slot that
 * binds its argument WHOLE (`list<…>`, `tuple<…>`, a callback) is validated
 * exactly as it would be without the declaration. A signature-wide `true`
 * there admitted a collection at every slot unchecked.
 */
export function threadableGate(sig: Type, whenUndeclared: boolean): Threadable {
  const plan = broadcastableParamSlots(sig);
  if (plan === undefined) {
    // A signature with a point parameter maps a list at a scalar sibling
    // slot (`pointListParamSlots`, ROADMAP CE-414), so such a slot is
    // threadable. A point slot is not: its list of points is admitted by
    // `mapsPointLists`, which checks that the elements are points.
    const points = whenUndeclared ? undefined : pointListParamSlots(sig);
    if (points === undefined) return whenUndeclared;
    return (i: number) => {
      const slot = points.at(i);
      return (
        slot.mappable &&
        slot.elements !== undefined &&
        !isPointParameterType(slot.elements)
      );
    };
  }
  // A `broadcastable: true` OPERATOR (an arithmetic builtin) threads
  // everywhere it always did; the plan only ever adds slots.
  return whenUndeclared ? true : (i: number) => plan.at(i).mappable;
}

/**
 * The types to annotate an inline callback literal's parameters with, given
 * the type DECLARED for the slot the literal occupies — or `undefined` when
 * the slot is not a concrete arrow type and carries no information.
 *
 * The bare `function` primitive is a string type, so it declines here — a
 * built-in callback slot spelled that way carries no parameter types. A GENERIC
 * arrow (`(T) -> boolean where T`) also declines: its quantified positions
 * are not types a literal can be annotated with, and instantiating them is the
 * contextual solve's job.
 *
 * Admission is untouched by the stamp either way: an arrow slot admits by
 * COMPATIBILITY (Design E §3,
 * `docs/TYPE-SYSTEM.md`), and what is
 * annotated here is the author's own declared contract.
 */
function declaredCallbackParamTypes(t: Type): DeclaredCallbackSlot | undefined {
  const sig = t;
  if (typeof sig === 'string' || sig.kind !== 'signature') return undefined;
  if (sig.typeParams !== undefined && sig.typeParams.length > 0)
    return undefined;
  const args = sig.args;
  if (args === undefined || args.length === 0) return undefined;
  // A plain arrow is an explicit author-written contract and keeps the wider
  // `concreteCallbackParamType` gate (the contextual-solve path applies its
  // own `admissibleElementType` gate to what it stamps).
  const types = args.map((arg) => concreteCallbackParamType(arg.type));
  if (!types.some((x) => x !== undefined)) return undefined;
  // The declared slot's CONSUMPTION arity: its required parameters, optionally
  // through its optional ones, and unbounded when it declares a variadic tail.
  // Only the required positions are stamped — an optional or variadic
  // parameter's type is not read here — but a literal that supplies them is
  // still correctly paired and must not be turned away.
  //
  // A `+` tail (`variadicMin === 1`) demands at least one occurrence, so it
  // raises the MINIMUM too — the spelling `validateArguments` and the
  // arity diagnostic both read (`sig.variadicMin ?? 0`). Without it a
  // `(integer, string+)` slot admitted a unary literal and stamped it.
  return {
    types,
    required: args.length + (sig.variadicMin ?? 0),
    max:
      sig.variadicArg !== undefined
        ? Infinity
        : args.length + (sig.optArgs?.length ?? 0),
  };
}

/** A declared callback slot the signature-driven trigger will stamp: the
 * parameter types to write, positionally, plus the literal arities that pair
 * with them ({@link declaredCallbackParamTypes}). */
type DeclaredCallbackSlot = {
  types: ReadonlyArray<Type | undefined>;
  required: number;
  max: number;
};

/** A declared callback-parameter type that is worth stamping on a literal, or
 * `undefined`. Only positive evidence qualifies: `unknown`/`any` say nothing,
 * and a `broadcastable<T>` slot is a callee-side APPLICATION contract
 * (2026-08-08 broadcastable-param ruling) — stamping it on a literal would
 * give it an elementwise contract its author never wrote. The containment test
 * is on the SPELLING so a nested occurrence declines too; a false positive
 * only means "no annotation", which is the safe direction. */
function concreteCallbackParamType(t: Type): Type | undefined {
  if (t === 'unknown' || t === 'any') return undefined;
  if (typeToString(t).includes('broadcastable')) return undefined;
  return t;
}

/**
 * The SIGNATURE-driven trigger of the per-application element-type inference
 * (`docs/TYPE-SYSTEM.md`, ruling 1): a
 * callee whose signature declares a concrete arrow-typed parameter annotates
 * an INLINE `Function` literal passed at that position with the declared
 * parameter types — a plain concrete arrow (see
 * {@link declaredCallbackParamTypes}). This is what the mechanism offers
 * USER-DEFINED functions; no library signature qualifies, every converted
 * library slot being a POLYTYPE that takes the contextual route below.
 *
 * Runs before any operand is boxed and before any operand type is read, so the
 * literal is canonicalized ONCE, already annotated — exactly as the
 * hand-annotated spelling would be.
 *
 * An OVERLOAD set is skipped: resolution happens after this hook and the
 * annotation would itself feed the resolution. The one exception is R-D4
 * resolve-then-stamp — an arm that declares a contextual arrow slot — since a
 * contextual stamp is decided by the DECLARED slot, never by the operand's own
 * type, so it cannot feed the resolution it follows.
 */
function annotateCallbacksFromSignature(
  ce: ComputeEngine,
  ops: ReadonlyArray<ExpressionInput>,
  sigType: Type | undefined,
  out?: { stamp?: ValueDerivedStamp }
): ReadonlyArray<ExpressionInput> {
  if (sigType === undefined || typeof sigType === 'string') return ops;
  const arms = overloadArms(sigType);
  if (arms !== undefined) {
    // R-D4 (§9, ruled 2026-08-09): resolve the arm FIRST, then stamp against
    // the resolved one alone. A set no arm of which declares a contextual slot
    // — every user-defined overload set — resolves to nothing and keeps the
    // ratified conservative skip.
    const arm = resolveContextualArm(arms, ops.length);
    if (arm === undefined) return ops;
    return annotateCallbacksFromContextualSolve(ce, ops, arm, out);
  }
  if (sigType.kind !== 'signature') return ops;
  // A POLYMORPHIC callee takes the CONTEXTUAL route instead (Design D): its
  // parameter types mention the variables its own `where` clause binds, so
  // stamping one verbatim would leave `T` unresolved outside that scope (or
  // capture an unrelated nominal type of the same name). Only a contextual
  // slot is contextually typed there, and only after `S` has been
  // instantiated from the sibling operands.
  if (sigType.typeParams !== undefined && sigType.typeParams.length > 0)
    return annotateCallbacksFromContextualSolve(ce, ops, sigType, out);

  return annotateFromDeclaredParams(ce, ops, sigType);
}

/**
 * The stamp read straight off a signature's DECLARED parameter slots, with no
 * solve: each supplied operand's parameter is read for callback parameter types
 * ({@link declaredCallbackParamTypes}) and an inline `Function` literal there is
 * annotated with them.
 *
 */
function annotateFromDeclaredParams(
  ce: ComputeEngine,
  ops: ReadonlyArray<ExpressionInput>,
  sig: FunctionSignature
): ReadonlyArray<ExpressionInput> {
  let result: ExpressionInput[] | undefined;
  for (let i = 0; i < ops.length; i++) {
    // The parameter each SUPPLIED operand binds to: required, then optional,
    // then variadic — `paramAt` mirrors `validateArguments`' consumption
    // order, so a concrete arrow type in an optional or variadic position
    // triggers exactly like a required one.
    const param = paramAt(sig, i);
    if (param === undefined) break;
    const slot = declaredCallbackParamTypes(param);
    if (slot === undefined) continue;
    // The raw box is taken here rather than left to
    // `annotateFunctionLiteralParams` (whose own discrimination is the same
    // three tests) so that the ARITY GUARD below has the literal to measure.
    const raw = inlineLiteral(ce, ops[i]);
    if (raw === undefined) continue;
    // ARITY GUARD, the contextual route's (§5 step 3) applied to this one: the
    // stamp pairs the literal's parameters with the declared ones
    // POSITIONALLY, so a literal of the wrong arity would take a PARTIAL stamp
    // — a declared `(integer) -> boolean` slot annotating the `a` of
    // `(a, b) => a > b` and leaving `b` bare. The whole stamp declines
    // instead. Evaluation is unchanged either way (the arity error dominates);
    // what this buys is that a declined application carries no half-written
    // contract.
    // A literal with parameters that have a default value accepts from its
    // required count to its parameter count: the stamp applies when that
    // range meets the range the slot supplies.
    const arity = isFunction(raw) ? raw.nops - 1 : 0;
    const literalRequired = isFunction(raw)
      ? requiredParameterCount(raw.ops.slice(1))
      : 0;
    if (arity < slot.required || literalRequired > slot.max) continue;
    const literal = annotateFunctionLiteralParams(ce, raw, slot.types);
    if (literal === undefined) continue;
    result ??= [...ops];
    result[i] = literal;
  }
  return result ?? ops;
}

/**
 * The CONTEXTUAL-CALLBACK trigger (`docs/TYPE-SYSTEM.md`): a POLYMORPHIC
 * callee with a
 * contextual arrow slot annotates an INLINE `Function` literal at that slot with
 * `S`'s parameter types, instantiated from the sibling operands.
 *
 * The five steps of §5, in the spec's numbering:
 *
 * 1. **canonicalize** ONLY the operands that contribute constraints — the
 *    non-callback positions mentioning a variable `S`'s parameters read
 *    ({@link contextualCallbackPlan}'s `sources`), to read their types: the
 *    operands arrive unboxed here, and on the lazy path they would otherwise
 *    never bind. The canonical form is substituted back so the operator's own
 *    handler reuses it;
 * 2. **solve** the callback-DOMAIN variables from those sources alone
 *    ({@link instantiateCallbackSlots});
 * 3. **rebuild** each inline literal with the instantiated parameter types,
 *    per parameter, through the {@link admissibleElementType} gate (inherited
 *    verbatim from the `callbackElementOf` metadata trigger this replaced);
 * 4. **result-side** variables are solved from the callback's own type — NOT
 *    this pass: they are left open here and fall to ordinary validation;
 * 5. **validate** proceeds normally — where an arrow slot admits by
 *    COMPATIBILITY (Design E §3), broad in exactly the way a bare slot
 *    exactly what the primitive `function` admits (§4 clause 1).
 *
 * The discrimination that precedes step 1 (does the arm declare a slot, does
 * any operand hold a stampable literal) is not one of the five steps: it is
 * the guard that keeps the shared-symbol and shorthand spellings free, as the
 * retired metadata trigger's own guard did.
 *
 * Runs before ANY operand is boxed, so the literal canonicalizes ONCE, already
 * annotated — the same contract as
 * {@link annotateCallbacksFromSignature}, the other surviving trigger.
 */
function annotateCallbacksFromContextualSolve(
  ce: ComputeEngine,
  ops: ReadonlyArray<ExpressionInput>,
  arm: FunctionSignature,
  out?: { stamp?: ValueDerivedStamp }
): ReadonlyArray<ExpressionInput> {
  // Discriminate FIRST, in strictly increasing cost, so an application with no
  // stampable literal at all — the overwhelmingly common case, including every
  // symbol/operator-name callback — pays only allocation-free checks:
  //
  //  a. does the arm even DECLARE a contextual slot (a field scan);
  //  b. does any operand LOOK like an inline literal (a syntactic scan of the
  //     unboxed inputs — no boxing, no type read);
  //  c. only then plan the slots and their sources (allocates), and only then
  //     raw-box the callback operands to answer (b) exactly.
  //
  // Ordering matters: `contextualCallbackPlan` allocates per parameter
  // position, and before this the shared-symbol spelling paid for a plan it
  // could never use.
  if (!hasCallbackParam(arm)) return ops;
  if (!ops.some(mayBeInlineFunctionLiteral)) return ops;

  // The `hasCallbackParam` answer is threaded in: the planning pass opens with
  // the same field scan, and on the overload route `resolveContextualArm` has
  // already run it a third time.
  const plan = contextualCallbackPlan(arm, ops.length, true);
  if (plan === undefined) {
    // No plan: the arm's arrow slots have no domain variables to solve. A
    // MONOMORPHIC arm — an overload-set arm reached through
    // `resolveContextualArm` — stamps its concrete arrow slots straight off
    // the declaration, exactly as the identical standalone signature does;
    // without this, an overload arm silently stamped nothing (the Design D
    // ground-`S` fallback, inherited by the arrow spelling). A POLYMORPHIC
    // arm's ground arrow slot deliberately declines: pre-Design-E plain
    // arrows in polytype arms never stamped on this route, and
    // `declaredCallbackParamTypes` cannot judge which of the arm's own
    // `where`-bound variables its sibling slots mention.
    if (arm.typeParams === undefined || arm.typeParams.length === 0)
      return annotateFromDeclaredParams(ce, ops, arm);
    return ops;
  }

  // The raw box is computed ONCE per slot here and threaded into the stamp
  // below. `annotateFunctionLiteralParams` still re-boxes what it is given —
  // but on an already-raw `Expression` that call is the identity, so what this
  // buys is the ARITY GUARD below, which needs this exact expression before the
  // stamp runs.
  const stampable: {
    slot: CallbackSlot;
    raw: Expression;
    /** For a literal boxed before the call, the lexical scope in which it
     * was boxed; `undefined` for an inline literal. */
    boxedIn: Scope | undefined;
  }[] = [];
  for (const slot of plan.callbacks) {
    const op = ops[slot.index];
    if (op === undefined) continue;
    // The syntactic scan again, per slot: `Map`'s variadic clause puts a
    // SOURCE at the slot position, and raw-boxing one only to discard it is
    // work every multi-collection `Map` would otherwise pay.
    if (!mayBeInlineFunctionLiteral(op)) continue;
    const raw = inlineLiteral(ce, op);
    if (raw !== undefined) stampable.push({ slot, raw, boxedIn: undefined });
    else {
      // A function literal boxed before the call, with no annotated
      // parameter, is stamped too, from its written form, but only with a
      // type that is not a number type (see below).
      const written =
        op instanceof _BoxedExpression
          ? writtenUntypedFunctionLiteral(op)
          : undefined;
      if (written !== undefined)
        stampable.push({
          slot,
          raw: written.literal,
          boxedIn: written.scope,
        });
    }
  }
  if (stampable.length === 0) return ops;

  let result: ExpressionInput[] | undefined;
  // The literals as written, at each index whose literal is stamped below.
  let literals: Map<number, Expression> | undefined;

  // §5 step 1: canonicalize only the operands the solve needs, and hand the
  // CANONICAL form onward (canonical-of-canonical is the identity, so the
  // operator's own operand check does not redo the work).
  const actuals: (Type | undefined)[] = new Array(ops.length).fill(undefined);
  const positions = parameterPositions(arm, ops.length);
  for (const i of plan.sources) {
    const src = ops[i];
    if (src === undefined) continue;
    const canonicalSrc =
      src instanceof _BoxedExpression ? src.canonical : ce.expr(src);
    if (canonicalSrc !== src) {
      result ??= [...ops];
      result[i] = canonicalSrc;
    }
    // A dictionary value is solved from the fields it has, not from its open
    // record type, at the parameters where the solve of a call reads it so
    // (`dictionaryValueSolveTypeAt()`): `Map(x ↦ At(x, 2), {a: 1, b: 2})`
    // stamps `x: tuple<string, integer>`. (CE-77)
    actuals[i] =
      dictionaryValueSolveTypeAt(canonicalSrc, positions[i]) ??
      resolveType(canonicalSrc.type.type);
  }

  // §5 step 2 + step 3.
  const instantiated = instantiateCallbackSlots(arm, plan, actuals);
  for (const { slot, raw, boxedIn } of stampable) {
    const s = instantiated.get(slot.index);
    if (s === undefined) continue;
    // A VARIADIC contextual arrow (`(T+) any -> U` as a SLOT) would pair one
    // parameter with N sources. No converted signature spells one — `Map`'s
    // variadic (zip) clause deliberately declares no contextual slot — and a
    // slot that did spell one declines outright rather than stamping a
    // guess.
    if (s.variadicArg !== undefined) continue;
    // ARITY GUARD: the stamp pairs the literal's parameters with `S`'s
    // POSITIONALLY, so a literal of the wrong arity would take a PARTIAL stamp
    // — `Filter(cs, (a, b) => a > b)` annotating `a` alone. The whole stamp
    // declines instead. Evaluation is unchanged either way (the arity error
    // dominates); what this buys is that a declined application carries no
    // half-written contract. The admissible range is `S`'s consumption arity:
    // required parameters, optionally through the optional ones.
    // A literal with parameters that have a default value accepts from its
    // required count to its parameter count: the stamp applies when that
    // range meets `S`'s.
    const required = s.args?.length ?? 0;
    const arity = isFunction(raw) ? raw.nops - 1 : 0;
    const literalRequired = isFunction(raw)
      ? requiredParameterCount(raw.ops.slice(1))
      : 0;
    if (
      arity < required ||
      literalRequired > required + (s.optArgs?.length ?? 0)
    )
      continue;
    const paramTypes = [...(s.args ?? []), ...(s.optArgs ?? [])].map((arg) =>
      stampableParamType(arg.type)
    );
    if (!paramTypes.some((x) => x !== undefined)) continue;
    // A literal boxed before the call already has a canonical body, which
    // reads each parameter as a possible number. It is canonicalized again
    // from its written form when a parameter takes a type that is not a
    // number type, as an inline literal is:
    // - a value kind: the canonical body may have folded `x/x` to `1`, which
    //   is wrong for a kind value (`Map(f, [ResidueClass(2, 4),
    //   ResidueClass(3, 4)])` gave `[1, 1]`;
    //   `docs/plans/2026-10-26-value-kinds.md`, section 4.2);
    // - any other type, such as a row: the canonical body types its result
    //   as a number. `Scan(m, f, 0)` with `f = (a, t) ↦ a + t` boxed before
    //   the call and `m = [[1, 2], [3, 4]]` was typed `vector<2>`, a list of
    //   numbers, although its values are rows, and the inline literal gives
    //   `matrix<2x2>`.
    // For a number type the boxed literal is kept as it is: its canonical
    // body already reads the parameter as a number.
    //
    // The boxed form cannot be kept for such a type, because the boxed body
    // can give a wrong value: with `f = row ↦ (q ≔ 1; q·row/row)` boxed
    // before the call, `Map(f, [[1, 2], [3, 4]])` gave `[1, 1]`, one number
    // per row, where the inline literal gives `[[1, 1], [1, 1]]`.
    //
    // Each name of the written form must bind as it did when the literal
    // was boxed, in the lexical scope `boxedIn`. When the call is in another
    // scope and a name can bind in another way (`bindsAsInCurrentScope()`
    // returns `false`), the literal is canonicalized here, in `boxedIn`:
    // `x ↦ k·x` boxed where `k = 1`, and mapped over rows or residue classes
    // in a scope that declares another `k = 2`, reads `k = 1`, as `Apply` of
    // the boxed literal does. The test also returns `false` for a body with
    // a `Block` local or a nested literal, because it cannot compare them;
    // canonicalization in `boxedIn` is then correct too. Otherwise the
    // literal is left raw, as an inline literal is, and the call
    // canonicalizes it in its own scope, because the canonical handler of a
    // fold re-canonicalizes a raw literal to refine the type of its
    // accumulator (`bareAccumulatorName()`, `library/collections.ts`). A
    // literal canonicalized here does not get that refinement: a fold that
    // builds a list of residue classes in another scope is typed
    // `collection<any>`, not `list<residue>`; its value is the same. A name
    // that `boxedIn` declares after the literal was boxed is read in
    // `boxedIn` as it is now.
    let canonicalIn: Scope | undefined = undefined;
    if (boxedIn !== undefined) {
      if (
        !paramTypes.some(
          (x) =>
            x !== undefined &&
            (isKindElementType(x) || !isSubtype(resolveType(x), 'number'))
        )
      )
        continue;
      if (
        boxedIn !== ce.context.lexicalScope &&
        !bindsAsInCurrentScope(ce, ops[slot.index] as Expression, raw)
      )
        canonicalIn = boxedIn;
    }
    const annotated = annotateFunctionLiteralParams(ce, raw, paramTypes);
    if (annotated === undefined) continue;
    const literal =
      canonicalIn === undefined
        ? annotated
        : ce._inScope(canonicalIn, () => annotated.canonical);
    result ??= [...ops];
    result[slot.index] = literal;
    // The record keeps the literal that the call received. For a literal
    // boxed before the call, that is the boxed literal, not its written
    // form: the call boxed again for a new source type then takes this
    // branch again, and `bindsAsInCurrentScope()` reads the scope as it is
    // at that time, which can declare a name of the body after this call.
    if (out !== undefined)
      (literals ??= new Map()).set(
        slot.index,
        boxedIn !== undefined ? (ops[slot.index] as Expression) : raw
      );
  }

  // A parameter type solved from the type of a source operand that holds a
  // variable can become wrong when a variable is assigned again: the type
  // of the operand changes. This is true for a variable with an inferred
  // type, for a variable declared with a bare constructor (`list`), whose
  // element type follows each assignment, and for a variable whose value
  // reads another variable. Record each such operand with its type now, so
  // that the caller can box the call again when the type of the operand
  // changes (`recordValueDerivedStamp()`). An operand that holds no
  // variable, or only constants, is not recorded.
  if (out !== undefined && literals !== undefined) {
    const sources: { expr: Expression; type: Type }[] = [];
    for (const i of plan.sources) {
      const src = result?.[i] ?? ops[i];
      if (!(src instanceof _BoxedExpression)) continue;
      const holdsVariable = src.symbols.some((name) => {
        const def = ce.lookupDefinition(name);
        return isValueDef(def) && !def.value.isConstant;
      });
      if (holdsVariable) sources.push({ expr: src, type: src.type.type });
    }
    if (sources.length > 0) out.stamp = { literals, sources, ops: [] };
  }

  return result ?? ops;
}

/** What the contextual callback solve read to stamp a callback literal from
 * the value of a variable. `literals` holds, for each operand index whose
 * literal was stamped, the literal as written (with no stamp). `sources`
 * holds each source operand that the solve read and that holds a variable,
 * with the type that the operand had when the solve read it. `ops` holds
 * the operands after the stamp. */
type ValueDerivedStamp = {
  literals: Map<number, Expression>;
  sources: { expr: Expression; type: Type }[];
  ops: ReadonlyArray<ExpressionInput>;
};

/**
 * Make the call `result` follow the variables that its callback stamp was
 * solved from.
 *
 * The contextual callback solve gives the parameter of an inline callback
 * the element type of the value that a variable holds when the call is
 * boxed. Example: with `L := [1, 2]`, `Map(x ↦ x + 1, L)` stamps
 * `x: integer`. After `L := [1.5, 2.5]`, the stamp refuses each element,
 * and the evaluation gave a list of `incompatible-type` errors, while the
 * same call boxed after the assignment gave `[2.5, 3.5]`.
 *
 * The call records, as its receiver (`BoxedFunction._stampCallee()`), the
 * source operands that the solve read, with their types then, and its
 * operands as written. The counter of the receiver moves each time the
 * type of a source operand is not the type that it had at the last read.
 * Then the type and the value of the call are those of the same call boxed
 * again (`BoxedFunction._reboxedForCallee()`), and the solve reads the type
 * that the operand has now. The types are compared, not the change
 * counters of the variables: the type of the operand `s`, when `s` holds
 * `Reverse(L)`, changes when `L` is assigned again, and the counter of `s`
 * does not move.
 *
 * The literal as written is not bound. It is boxed again in the lexical
 * scope of this call, so that a name in its body has the binding that it
 * had when the call was boxed, also after that scope was left.
 *
 * A canonical handler can give a call of another operator: `Fold(f, x, L)`
 * becomes `Reduce(L, f, x)`. The record is then put on that call, with the
 * operator and the operands of the call as written, and the call is boxed
 * again from them. (ROADMAP CE-464)
 */
function recordValueDerivedStamp(
  ce: ComputeEngine,
  result: Expression,
  name: MathJsonSymbol,
  record: ValueDerivedStamp
): void {
  const ops = record.ops;
  if (!(result instanceof BoxedFunction)) return;
  if (result.operator === name && result.nops !== ops.length) return;
  const written = ops.map(
    (op, i) =>
      record.literals.get(i) ??
      (op instanceof _BoxedExpression ? op : ce.expr(op, { form: 'raw' }))
  );
  const sources = record.sources;
  const seen = sources.map((x) => x.type);
  let version = 0;
  const receiver = {
    get _writeVersion(): number {
      for (let i = 0; i < sources.length; i++) {
        const t = sources[i].expr.type.type;
        const before = seen[i];
        if (t === before) continue;
        if (isSubtype(t, before) && isSubtype(before, t)) continue;
        seen[i] = t;
        version += 1;
      }
      return version;
    },
  };
  result._stampCallee(undefined, written, receiver, {
    operator: result.operator === name ? undefined : name,
    scope: ce.context.lexicalScope,
  });
}

/** Could `op` be an inline `Function` literal? A purely SYNTACTIC test on the
 * UNBOXED operand — no boxing, no type read — used to skip the whole
 * contextual pass before it allocates anything. Conservative by construction:
 * it may answer `true` for an operand {@link inlineLiteral} then declines (an
 * already-canonical literal, a `["Function", body]` shorthand), never `false`
 * for one it would accept. Nothing else in `ExpressionInput` — a number, a
 * string, a symbol/number/string/dictionary object literal — can raw-box to a
 * `Function`. */
function mayBeInlineFunctionLiteral(op: ExpressionInput): boolean {
  if (op instanceof _BoxedExpression) return op.operator === 'Function';
  if (Array.isArray(op)) return op[0] === 'Function';
  if (typeof op === 'object' && op !== null && 'fn' in op)
    return (op as { fn: ReadonlyArray<unknown> }).fn[0] === 'Function';
  return false;
}

/** `op` raw-boxed when it is an INLINE `Function` literal with an explicit
 * parameter list — the one operand shape a contextual stamp rewrites — and
 * `undefined` otherwise. Answered on the ORIGINAL operand, raw-boxed: an
 * already-canonical literal is never rewritten, a symbol callback is shared and
 * never rebuilt (`canonicalFunctionLiteral` would LIFT one into a literal,
 * which is why this must not use it), and a `["Function", body]` shorthand has
 * no parameter list to stamp. The box is RETURNED rather than discarded — the
 * stamp needs this exact expression. */
function inlineLiteral(
  ce: ComputeEngine,
  op: ExpressionInput
): Expression | undefined {
  const raw = ce.expr(op, { form: 'raw' });
  if (raw.isCanonical || !isFunction(raw, 'Function') || raw.nops < 2)
    return undefined;
  return raw;
}

/**
 * True when canonicalizing `written`, the written form of the canonical
 * function literal `fn`, in the current scope binds each name as `fn` binds
 * it.
 *
 * The written form of a literal boxed before a call is canonicalized again
 * in the scope of the call (`annotateCallbacksFromContextualSolve()`) when
 * that scope is the one where the literal was boxed, or when this function
 * returns `true`; otherwise it is canonicalized again in the scope where it
 * was boxed. Two tests, with the parameters of `fn` left out:
 * - each symbol of the body of `fn`, and the operator of each application,
 *   is bound in `fn` to the definition that a lookup of its name in the
 *   current scope returns;
 * - each name of `written` that the body of `fn` does not hold, because
 *   canonicalization removed it (`Subtract` becomes `Add`), is a name of
 *   the library in the current scope. A library name that the first scope
 *   declared again is not removed by canonicalization, so the first test
 *   reads it.
 *
 * A name bound inside the body (the parameter of a nested literal, a local
 * of a `Block`) is not visible in the current scope, and an application
 * whose operator has no operator definition (a function held by a variable)
 * cannot be compared: both give `false`, so the caller canonicalizes the
 * literal again in the scope where it was boxed.
 */
function bindsAsInCurrentScope(
  ce: ComputeEngine,
  fn: Expression,
  written: Expression
): boolean {
  if (!isFunction(fn, 'Function') || fn.nops < 2) return false;
  if (!isFunction(written, 'Function') || written.nops !== fn.nops)
    return false;
  const params = new Set<string>();
  for (const p of fn.ops.slice(1)) {
    if (!isSymbol(p)) return false;
    params.add(p.symbol);
  }
  const current = (name: string): object | undefined => {
    const def = ce.lookupDefinition(name);
    if (def === undefined) return undefined;
    return 'value' in def ? def.value : def.operator;
  };
  // The names of the canonical body whose binding is the current one.
  const checked = new Set<string>();
  for (const x of fn.ops[0].subexpressions) {
    if (isSymbol(x)) {
      if (params.has(x.symbol)) continue;
      const own = x.valueDefinition ?? x.operatorDefinition;
      if (own === undefined || own !== current(x.symbol)) return false;
      checked.add(x.symbol);
    } else if (isFunction(x)) {
      const own = x.operatorDefinition;
      if (own === undefined || own !== current(x.operator)) return false;
      checked.add(x.operator);
    }
  }
  for (const x of written.ops[0].subexpressions) {
    const name = isSymbol(x)
      ? x.symbol
      : isFunction(x)
        ? x.operator
        : undefined;
    if (name === undefined || params.has(name) || checked.has(name)) continue;
    if (!isLibraryDefinition(ce, name, current(name))) return false;
  }
  return true;
}

/** An instantiated contextual arrow parameter type this trigger will stamp, or
 * `undefined`. The gate is {@link admissibleElementType}'s — including the
 * PERMANENT union exclusion — plus the ground-type invariant: a parameter
 * still mentioning a variable the solve could not pin says nothing about an
 * element, so it stays bare. */
/** True when the stamped parameter type `t` is the type of a value kind:
 * a kind primitive (`residue`) or a nominal type defined as exactly `value`
 * (`valueKindDeclaration()`). */
function isKindElementType(t: Type): boolean {
  if (typeof t === 'string') return KIND_PRIMITIVES.includes(t);
  return valueKindDeclaration(t) !== undefined;
}

function stampableParamType(t: Type): Type | undefined {
  if (freeTypeVariables(t).size > 0) return undefined;
  // The type of a value kind declared by the host, a nominal type defined
  // as exactly `value` (`valueKindDeclaration()`), is a leaf like `residue`:
  // `Map(x ↦ x/x, [GF8(1), GF8(2)])` stamps `x: gf8` and keeps `x/x`, as it
  // does for a list of classes. It is read before `resolveType()`, which
  // unfolds a nominal reference to its definition (`value`, which is not
  // admitted), and from the definition alone, so it needs no kind registry.
  if (valueKindDeclaration(t) !== undefined) return t;
  const resolved = resolveType(t);
  return admissibleElementType(resolved) ? t : undefined;
}

/** The signature to read a callee's declared callback slots from, for a
 * function-typed VALUE definition. A bare-`function` wildcard declaration
 * carries no parameter types and deliberately stays that way through
 * assignment, so the assigned value's own signature is the only one there is
 * — the same source the narrowing sink below reads. A transparent alias of
 * a signature (`ce.declare('g', 'Fn')` with `Fn` an alias of
 * `(integer) -> list<real>`) is unfolded, so that the call is checked and
 * typed as under the written-out declaration. */
function calleeSignatureType(def: BoxedValueDefinition): Type | undefined {
  const declared = resolveTypeAlias(def.type.type);
  if (isWildcardFunctionType(declared)) return def._programVariable ? undefined : def.value?.type.type;
  return declared;
}


/** `x` when it is a function literal that annotates at least one of its
 * parameters (`(u: real) ↦ 7`), and `undefined` otherwise. */
function annotatedLiteral(x: Expression | undefined): Expression | undefined {
  if (!isFunction(x, 'Function')) return undefined;
  return x.ops
    .slice(1)
    .some((p) => functionLiteralParameterType(p) !== undefined)
    ? x
    : undefined;
}

/**
 * The operands of `Apply(literal, …ops)`, checked against the parameters
 * that the function literal annotates, in a strict engine, as the call of a
 * named function assigned the same literal is checked when it is boxed. An
 * operand that certainly does not match its parameter (`"abc"` at `u: real`)
 * is replaced by its `incompatible-type` error, so the application is
 * invalid and is typed `error`, as `h("abc")` is for `h := (u: real) ↦ 7`.
 * An operand that the application maps over (a list, or a tuple at a
 * parameter declared as a scalar) is not refused here. The answer is
 * `undefined` when there is nothing to check or nothing changed.
 *
 * A callee that reads a `Function` literal from a field of a constant
 * dictionary (`lib.T("abc")`) is checked against that literal, as the call
 * is the literal applied (`constantFieldLiteral`).
 */
export function validatedLiteralApplicationOperands(
  ce: ComputeEngine,
  literal: Expression,
  ops: ReadonlyArray<Expression>,
  diagnostic = false
): ReadonlyArray<Expression> | undefined {
  if (!ce.strict) return undefined;
  const annotated = annotatedLiteral(constantFieldLiteral(literal) ?? literal);
  if (annotated === undefined || !annotated.isCanonical) return undefined;
  if (!ops.every((x) => x.isCanonical)) return undefined;
  const checkedType = pinnedValidationSignature(
    annotated.type.type,
    ops.length,
    annotated
  );
  if (typeof checkedType === 'string' || checkedType.kind !== 'signature')
    return undefined;
  const invalid = validateArguments(
    ce,
    ops,
    checkedType,
    undefined,
    threadableGate(checkedType, paramsAreScalar(checkedType)),
    undefined,
    undefined,
    {
      operatorName: 'Apply',
      mapsPointLists: true,
      userFunction: true,
      enforcesParameterAnnotations: true,
      noInference: diagnostic,
      diagnostic,
    }
  );
  if (!invalid) return undefined;
  return keepProvisionalOperands(ce, ops, invalid, checkedType, true);
}

/**
 * The operands of a call after `validateArguments` gave `invalid` for the
 * operands `ops`. Only a CLOSED operand (a literal or a constant expression,
 * whose type is definite: `0.5`, `"a"`) stays rejected. An operand with free
 * variables (a bare symbol `x`, a pattern variable `_q`, or `x+1`) has a
 * provisional type and may satisfy the parameter at run time, so its
 * rejection is undone, unless its own type refutes the parameter.
 *
 * "Has free variables" is a proxy for "provisional type", and it is only a
 * valid proxy while the type could still turn out compatible: a symbol
 * declared `string` can never denote a `tuple<…>`, so the error is
 * definite, not provisional. Refute only on PROVABLE disjointness
 * (`isDisjointFrom`, conservative by construction), so union-declared,
 * `unknown`-typed and same-category-composite operands (`list<integer>` vs
 * `list<string>` — the empty list inhabits both) keep deferring. A symbol
 * the Epsil static pre-pass recorded ASSIGNMENT EVIDENCE for is not
 * provisional either: the pass established its type from an actual
 * assignment (`x = g()` ⇒ `x: number`), so a rejection against that type is
 * as definite as one against a held value. An argument refused because it
 * is absent is refused by its `missing` member, which the type states
 * whatever value the free variables take (`refusesAbsentArgument`,
 * `validate.ts`), when `enforcesAnnotations` is true.
 */
function keepProvisionalOperands(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  invalid: ReadonlyArray<Expression>,
  checkedType: Type,
  enforcesAnnotations: boolean
): Expression[] {
  return invalid.map((r, i) => {
    const orig = ops[i];
    if (
      orig &&
      orig.isValid &&
      !r.isValid &&
      orig.freeVariables.length > 0
    ) {
      const params = candidateParamsAt(checkedType, i);
      // `isDisjointFrom` is conservative: it does not read the dimensions of
      // a collection type, so `list<string>` is not disjoint from
      // `matrix<2x2>` for it, although no list of strings is a 2×2 matrix.
      // `typesOverlap` reads them, and still finds the value that two
      // collection types share through the empty list (`list<string>` and
      // `list<integer>`), so it refuses only an operand that cannot fit.
      // A point with a component that its position refutes cannot fit
      // either, whatever value the free variables of the other components
      // take: `(1.5, x)` at `tuple<integer, integer>` (`pointComponentRefuted`).
      if (
        params.length > 0 &&
        params.every(
          (p) =>
            orig.type.isDisjointFrom(p) ||
            !typesOverlap(orig.type.type, p) ||
            pointComponentRefuted(orig, p)
        )
      )
        return r;
      if (
        enforcesAnnotations &&
        params.length > 0 &&
        params.every((p) =>
          refusesAbsentArgument(ce, orig, p, {
            enforcesParameterAnnotations: true,
          })
        )
      )
        return r;
      return orig;
    }
    return r;
  });
}

/**
 * The signature a call to a statically pinned literal (`staticallyPinnedCallee`)
 * is validated against, so the static verdict is the one the literal's own
 * application gives (`applyFunctionLiteral`, `function-utils.ts`):
 *
 * - an UNSATURATED call is a partial application, not a call with missing
 *   arguments — `let k = (x: integer, y: integer) => x + y` then `k(1)` is
 *   the literal `(y) => 1 + y` — so only the supplied prefix of the
 *   parameters is checked, and nothing is reported missing;
 * - a BARE parameter imposes no constraint: its slot holds whatever
 *   inference left there (`unknown`, or a type inferred from a use in the
 *   body such as `indexed_collection<number>` from `p[1]`), which is not a
 *   contract the author wrote, and `nothing` is deliberately not a subtype
 *   of `unknown` — so the slot is relaxed to `any` for validation, as the
 *   application relaxes it. With `literal`, the bare parameters are read
 *   from the literal itself; without it, only an `unknown` slot is relaxed.
 *
 * A declared signature (`let k: (x: integer, y: integer) -> integer`) keeps
 * the full check: its application reports the missing argument, so the
 * static line is a true prediction there. Anything but a plain one-arm
 * signature is returned unchanged.
 */
function pinnedValidationSignature(
  signature: Type,
  argCount: number,
  literal?: Expression
): Type {
  if (typeof signature === 'string' || signature.kind !== 'signature')
    return signature;
  const args = signature.args ?? [];
  const kept = argCount < args.length ? args.slice(0, argCount) : args;
  // The parameter operands of the literal pair one to one with the
  // signature's required arguments, unless the literal has a rest parameter
  // (it is the signature's variadic argument); then only `unknown` slots are
  // relaxed.
  const params =
    literal !== undefined && isFunction(literal, 'Function')
      ? literal.ops.slice(1)
      : undefined;
  const paired = params !== undefined && params.length === args.length;
  const relaxed = kept.map((arg, i) =>
    arg.type === 'unknown' ||
    (paired && functionLiteralParameterType(params[i]) === undefined)
      ? { ...arg, type: 'any' as Type }
      : arg
  );
  // A signature rebuilt field-by-field must carry its adjuncts (`typeParams`,
  // `effects`, `optArgs`, `restArg`); the spread does that.
  return { ...signature, args: relaxed };
}

/** A `Spread` operand makes the final positional operands unknown until
 * evaluation, so a positional callback rewrite cannot be trusted. Answered on
 * the UNBOXED operand — the hook runs before anything is boxed. */
function isSpreadOperand(x: ExpressionInput): boolean {
  if (x instanceof _BoxedExpression) return x.operator === 'Spread';
  if (Array.isArray(x)) return x[0] === 'Spread';
  if (typeof x === 'object' && x !== null && 'fn' in x)
    return (x as { fn: ReadonlyArray<unknown> }).fn[0] === 'Spread';
  return false;
}

/** The CONCRETE scalar primitives {@link admissibleElementType} admits: the
 * numeric types plus `boolean`, `character`, `string` and `color`. Every other
 * primitive —
 * the abstract supertypes (`scalar`, `value`, `expression`, …), the bare
 * composite names (`'tuple'`, `'collection'`, …) and `unknown`/`any`/`never` —
 * declines.
 *
 * `color` is a leaf primitive with no subtypes of its own (it is not in
 * `SCALAR_TYPES`, but only because `scalar` does not cover it), so the
 * union-like exclusion rationale below does not apply to it.
 */
const ADMISSIBLE_ELEMENT_PRIMITIVES: ReadonlySet<string> = new Set<string>([
  ...NUMERIC_TYPES,
  'boolean',
  // `character` is a concrete leaf scalar (one grapheme cluster, no subtypes)
  // and is the ELEMENT type of every string, so it is the type a callback
  // parameter over a string source — or over `Characters(s)` — deserves.
  'character',
  'string',
  'color',
  // `regexp` for exactly the reason `color` is here: a leaf primitive with no
  // subtypes, outside `SCALAR_TYPES` only because `scalar` does not cover it.
  // A callback over a `list<regexp>` deserves the same contextual element
  // stamp a `list<color>` gets.
  'regexp',
  // `type` (a reified type expression) is another such leaf: a callback over
  // a `list<type>` deserves the same contextual element stamp.
  'type',
  // The kind primitives (`residue`, a residue class) are other such leaves:
  // a callback over the elements of `ℤ/nℤ`, a `set<residue>`, deserves the
  // stamp too. A nominal kind type (`gf8`) is admitted by
  // `stampableParamType()`.
  ...KIND_PRIMITIVES,
]);

/**
 * The admission gate of the contextual stamp (ruling 4, widened 2026-08-09;
 * inherited unchanged from the `callbackElementOf` metadata trigger it
 * outlived): an element type this mechanism will stamp on a callback
 * parameter.
 *
 * Admits a CONCRETE type — a concrete scalar primitive (a numeric type,
 * `boolean` or `string`) or a parameterized structured kind (a tuple or a
 * collection node). Rejects everything that is not evidence about a single
 * element:
 *
 * - a UNION (even of tuples) — PERMANENTLY (ruled 2026-08-09). One
 *   annotation cannot express "each element satisfies its own arm":
 *   stamping the union makes a body that is valid for SOME arms fail once,
 *   at canonicalization, for the whole application — where the
 *   un-annotated program errors per element, which is the published Epsil
 *   "errors are values" behavior. And that un-annotated behavior IS the
 *   ruled per-element semantics: interpretation is value-directed, so the
 *   arm an element "satisfies" is its value and evaluation under it is
 *   ordinary evaluation. A union derived from the source's own element
 *   type is vacuously unviolatable, so admission would buy only a
 *   displayed signature — at the price of the published output (strict
 *   stamping) or a second annotation kind that breaks hand-annotation
 *   equivalence and serialization round-trip (loose stamping). Unions are
 *   explicit-contract-only: the signature-driven trigger admits them
 *   because an author wrote them; this trigger never will because no one
 *   did. (Design record: the union section of
 *   docs/TYPE-SYSTEM.md.)
 * - an ABSTRACT supertype — `scalar`, `value`, `expression`, `symbol`,
 *   `missing`, … These are union-like (`scalar` covers number, boolean and
 *   string), so stamping one poisons the whole application at
 *   canonicalization exactly as a written-out union does, even when every
 *   element is fine.
 * - a BARE composite NAME (`'tuple'`, `'list'`, `'collection'`, …): positive
 *   structural evidence requires a parameterized node, not a name that says
 *   only "some tuple, of some arity, of some element types".
 * - `unknown`/`any` (already excluded upstream) and `never`: the top and the
 *   bottom say nothing about an element. `never` is the element type of an
 *   EMPTY literal collection, and stamping it would make `Filter([], …)` a
 *   type error.
 * - every other kind — a signature, a type variable, a negation: not a type a
 *   literal's parameter can be annotated with here.
 *
 * Scalar admission is safe since follow-up (1): the Map fusion / exact-compile
 * gate now accepts an annotated parameter whose annotation the source's
 * element type provably satisfies (`annotationSatisfiedBySource` in
 * `map-broadcast-shape.ts`), so the fast paths survive the annotation instead
 * of falling out of it.
 *
 * The signature-driven trigger is deliberately NOT gated this way — a
 * user-declared arrow parameter is an explicit contract, whatever its types.
 */
function admissibleElementType(t: Type): boolean {
  if (typeof t === 'string') return ADMISSIBLE_ELEMENT_PRIMITIVES.has(t);
  switch (t.kind) {
    case 'tuple':
    case 'list':
    case 'set':
    case 'dictionary':
    case 'record':
    case 'collection':
    case 'indexed_collection':
      return true;
    default:
      return false;
  }
}

/**
 * The smallest number of operands a call of `type` must supply: the fixed
 * parameters of its signature, and, when the variadic tail must not be empty,
 * every optional position (validation fills them before the tail) plus one;
 * the minimum over the arms of an overload set. `0` for the bare `function`
 * type and for a type that is not a signature, which require nothing. The
 * same count `triviallyAdmittedCall` makes for one signature.
 */
function requiredOperandCount(type: Type): number {
  const arms = signatureArms(type);
  if (arms === undefined) return 0;
  let count: number | undefined;
  for (const sig of arms) {
    const required = sig.args?.length ?? 0;
    const n =
      sig.variadicArg !== undefined && sig.variadicMin === 1
        ? required + (sig.optArgs?.length ?? 0) + 1
        : required;
    if (count === undefined || n < count) count = n;
  }
  return count ?? 0;
}

/**
 * The largest number of operands a call of `type` may supply: the fixed and
 * optional parameters of its signature, `Infinity` with a variadic tail; the
 * maximum over the arms of an overload set. `Infinity` for a type that is
 * not a signature.
 */
function maximumOperandCount(type: Type): number {
  const arms = signatureArms(type);
  if (arms === undefined) return Number.POSITIVE_INFINITY;
  let count = 0;
  for (const sig of arms) {
    if (sig.variadicArg !== undefined) return Number.POSITIVE_INFINITY;
    count = Math.max(
      count,
      (sig.args?.length ?? 0) + (sig.optArgs?.length ?? 0)
    );
  }
  return count;
}

/**
 * The operands of the canonical call that replaces a call of a lazy
 * operator `name` whose canonical handler gave up (returned `null`) although
 * the call supplies a number of operands that its signature admits. Each
 * operand is canonicalized and checked against the type of its parameter, as
 * the operands of an operator that is not lazy are, with the policies of the
 * signature validation of a lazy call (`_validationSignature`, the
 * threadable slots, the NaN and absence policies). An operand that the check
 * refuses is a typed error, so the call is invalid: `Interval("'bad'", 1)`
 * gives `Interval(Error(ErrorCode("incompatible-type", "number", "string"), 'bad'), 1)`.
 * When the check refuses no operand (`Series(1)`, which needs a variable, or
 * any call when `ce.strict` is false, which skips the type checks), the call
 * is canonical and inert over its canonical operands.
 *
 * A top-level `Sequence` operand supplies each of its elements, as
 * `suppliedOperandCount()` counts them: `Interval(Sequence(1, 2))` is checked
 * as `Interval(1, 2)`. `undefined` for an operand list with a `Spread`
 * operand, whose operand count is not known before evaluation: the caller
 * then builds the call with the validation of a lazy call, which defers such
 * a list.
 */
function declinedCallOperands(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  opDef: BoxedOperatorDefinition,
  xs: ReadonlyArray<Expression>,
  resolutionOut: { resolution?: OverloadResolution }
): ReadonlyArray<Expression> | undefined {
  if (xs.some((x) => x.operator === 'Spread')) return undefined;
  const ops = xs
    .flatMap((x) => (isFunction(x, 'Sequence') ? x.ops : [x]))
    .map((x) => x.canonical);
  return (
    validateArguments(
      ce,
      ops,
      opDef._validationSignature ?? opDef.signature.type,
      false,
      threadableGate(opDef.signature.type, opDef.broadcastable === true),
      undefined,
      undefined,
      {
        resolutionOut,
        operatorName: name,
        operatorDefinition: opDef,
        nanPolicyAt: (i) => opDef.resolvedNanBehaviorAt(i),
        refusesAbsentAt: (i) => opDef.refusesAbsentOperandAt(i),
      }
    ) ?? ops
  );
}

/**
 * The number of operands a RAW operand list supplies: a top-level `Sequence`
 * operand supplies each of its elements (the operands of a lazy operator are
 * not flattened before its canonical handler runs).
 */
function suppliedOperandCount(xs: ReadonlyArray<Expression>): number {
  let n = 0;
  for (const x of xs) n += isFunction(x, 'Sequence') ? x.nops : 1;
  return n;
}

/**
 * The operands of a call of an operator with a `canonical` handler, or of a
 * lazy operator, after the default values of the parameters that the call
 * leaves out are inserted (`fillParameterDefaults`). These operands are not
 * flattened, so a top-level `Sequence` operand supplies each of its elements
 * (`suppliedOperandCount`), and the defaults are appended after the written
 * operands. With `(x, k = 2)`, `F(Sequence(3, 5))` supplies two positions and
 * gets no default; `F(Sequence(3))` gets one.
 *
 * `defaults` is `undefined` for an operator whose signature has no default,
 * and the operands are then returned as they are. A written `Nothing`
 * operand occupies its position, as on the route of an operator without a
 * handler.
 */
function withHandlerDefaults(
  xs: ReadonlyArray<Expression>,
  signature: Type,
  defaults: ReadonlyArray<Expression | undefined> | undefined
): ReadonlyArray<Expression> {
  if (defaults === undefined) return xs;
  return fillParameterDefaults(
    xs,
    signature,
    defaults,
    suppliedOperandCount(xs)
  );
}

function makeCanonicalFunction(
  ce: ComputeEngine,
  name: string,
  ops: ReadonlyArray<ExpressionInput>,
  metadata: Metadata | undefined,
  scope: Scope | undefined
): Expression {
  // Ambient inference-cause context: while this operator canonicalizes, any
  // `_infer()` write onto a definition records THIS expression as the cause
  // of the write in the definition's provenance history (`_noteInferenceWrite`
  // in `index.ts`). Save/restore rather than set/clear so nested
  // canonicalizations (a canonical handler boxing sub-expressions) resolve
  // to the innermost enclosing operator. The context stores only
  // `{operator, ops}` — two field writes on this hot path; the expression is
  // materialized lazily by the (rare) write that records it.
  const previousCause = ce._inferenceCause;
  ce._inferenceCause = { operator: name, ops };
  try {
    return makeCanonicalFunctionCore(ce, name, ops, metadata, scope);
  } finally {
    ce._inferenceCause = previousCause;
  }
}

function makeCanonicalFunctionCore(
  ce: ComputeEngine,
  name: string,
  ops: ReadonlyArray<ExpressionInput>,
  metadata: Metadata | undefined,
  scope: Scope | undefined
): Expression {
  // A `NamedArgument` carrier among the operands (`f(rate: 0.05)`) makes the
  // written order NOT the declaration order, so the call must be permuted
  // before anything reads an operand by position. The scan is a head
  // comparison per operand and nothing else: when no carrier is present every
  // path below is exactly what it was before named arguments existed.
  //
  // The three short paths are skipped for a named call so that it routes
  // through definition lookup and its names can be checked against a
  // signature. (`Add` and `List` declare no parameter names, so a named call
  // to either correctly reports `argument-name-unknown` rather than silently
  // taking the fast path.) See
  // `docs/LANGUAGE-MODEL.md`
  const named = hasNamedArguments(ops);

  if (!named) {
    const result = makeNumericFunction(ce, name, ops, metadata, scope);
    if (result) return result;
  }

  //
  // A `List` is always a plain canonical `List` `BoxedFunction` — tensor-ness
  // is a lazy view over its ops (`tensor-view.ts`), never a distinct
  // representation (§D1). Metadata is forwarded so latex/... survives boxing.
  //
  // A `Spread` element (`[...xs, c]`) takes the NORMAL path below instead:
  // `List`'s canonical handler owns the splice-and-lower rewrite
  // (`canonicalList`, library/collections.ts), which this fast path would
  // bypass.
  //
  if (name === 'List' && !named && !ops.some(isSpreadOperand)) {
    const boxedOps = boxOperands(ce, ops, RAW_OPERAND);
    // `flatten` applies the operand-list rule a collection literal owes
    // its elements, and must stay in step with `canonicalList`
    // (library/collections.ts), which this fast path bypasses:
    // - `Sequence` is SPLICED — `[1, Sequence(2, 3), 4]` is the 4-element
    //   list `[1, 2, 3, 4]`. A `Sequence` is the engine-wide "these operands,
    //   inlined here" marker and must never be STORED as an element; leaving
    //   it in place produced a 3-element list whose middle element was a
    //   `tuple<…>`.
    // - `Nothing` is an element like any other: `[12, Nothing, 34]` is a
    //   3-element list.
    //
    // `canonicalize: false` (the third argument): the operands were just made
    // canonical in `scope`, and `flatten` would otherwise re-canonicalize the
    // whole list in the AMBIENT scope the moment any one of them came back
    // non-canonical (an error node, a declined handler). `flatten` is wanted
    // here only for the splice step.
    let canonicalOps = flatten(
      canonical(ce, boxedOps, scope),
      undefined,
      false
    );
    // An element is a value: a bare `N` or `D` there is a variable
    // (`devolveAtValuePositions`, which `canonicalList` gets through the
    // lazy route).
    canonicalOps = devolveValueElements(ce, canonicalOps);
    // The free symbols of an arithmetic cell of the literal are inferred as
    // numbers here too, as in `canonicalList` (`narrowFreeSymbolCells`,
    // `canonical-utils.ts`).
    return narrowFreeSymbolCells(
      new BoxedFunction(ce, 'List', canonicalOps, {
        metadata,
        canonical: true,
      })
    );
  }

  // A `Spread` entry (`{-> , ...d, "k" -> v}` merge) takes the normal path
  // below instead: the `Dictionary` definition's canonical handler owns the
  // merge lowering (library/collections.ts), which this structural
  // construction would bypass.
  if (name === 'Dictionary' && !named && !ops.some(isSpreadOperand)) {
    // A macro name in an entry is the raw body, as in the operands of any
    // other lazy operator (`expandMacroOperands()`).
    const boxedOps = expandMacroOperands(
      ce,
      name,
      boxRawOperands(ce, ops),
      undefined
    );
    const dict = new BoxedDictionary(ce, ce._fn('Dictionary', boxedOps), {
      canonical: true,
    });
    // A malformed entry (a non-pair element, a `Nothing` or non-string key, a
    // tuple that is not exactly key-and-value) is reported as a boxed error
    // rather than thrown or — worse — silently dropped, which is what the
    // multi-entry path used to do: it returned an EMPTY dictionary.
    return dict.constructionError ?? dict;
  }

  //
  // Didn't match a short path, look for a definition.
  //
  // Function-application position: an inner binding that provably cannot be
  // applied (a user symbol `N = 85` shadowing the built-in `N` operator)
  // defers to an outer applicable definition — see `lookupApplicable` — so
  // the operator path (with its canonical handler) runs. `_bind()` performs
  // the same resolution, keeping construction and binding consistent. A
  // library call made by `ce._libraryCall()` reads the library definition
  // (`ce._qualifiedHead`), as `_bind()` does.
  //
  const qualifiedHead = ce._qualifiedHead;
  let def =
    qualifiedHead?.name === name
      ? qualifiedHead.definition
      : lookupApplicable(name, scope ?? ce.context.lexicalScope, ce);
  // A parameter first used as a call head needs its annotation before the
  // value-callee path validates the arguments and records the binding.
  if (def === undefined && ce._shadowedParameterType(name) !== undefined) {
    ce.symbol(name);
    def = lookupApplicable(name, scope ?? ce.context.lexicalScope, ce);
  }
  if (!def) {
    // No applicable definition (`["f", 2]` with `f` not declared). A head
    // that is a parameter of the function literal being canonicalized is
    // declared, as the parameter's definition, in the first scope that is
    // not marked `noAutoDeclare`; the literal adopts that binding
    // (`_setShadowedParameterDef`). Every other head is a free head with a
    // home scope (`binding-unit.ts`), resolved when the call is evaluated.
    // Inside a resolve-only region (`ce._resolveOnly()`: partial forms,
    // serialization) nothing is declared or recorded.
    let freeHead: Scope | undefined = undefined;
    if (ce._resolveOnlyDepth === 0) {
      let autoScope = ce.context.lexicalScope;
      while (autoScope.noAutoDeclare && autoScope.parent)
        autoScope = autoScope.parent;
      // The `function` reading of a free head is a requirement on the free
      // name in the environment of the unit. In a scope that the boxing
      // created (the body of a function literal), the home scope of the
      // head is the one a free name of the body gets (`ce.symbol()`). The
      // home scope skips the scope of a binder also when the call is boxed
      // outside the canonicalization of the binder (`freeNameHomeScope()`).
      const homeScope = freeNameHomeScope(autoScope);
      if (!ce._isShadowedParameter(name)) {
        if (ce.lookupDefinition(name) === undefined) {
          const head = ce.symbol(name);
          head._infer(() => 'function');
          freeHead =
            ce._boxingState.isPersistentScope(homeScope) === false
              ? ((head as { _homeScope?: Scope })._homeScope ?? homeScope)
              : homeScope;
        } else freeHead = homeScope;
      } else {
        ce.declare(name, { type: 'function', inferred: true }, autoScope);
        const declared = autoScope.bindings.get(name);
        if (declared !== undefined) ce._setShadowedParameterDef(name, declared);
      }
    }
    // An argument of a function with no declared signature is a value: a
    // bare `N` or `D` there is a variable (`devolveAtValuePositions`).
    const boxedOps = devolveValueElements(ce, flatten(semiCanonical(ce, ops)));
    // Definition order must not change semantics. `name` has no definition
    // yet, so the collection evidence its parameters would have narrowed onto
    // an unknown symbol argument (`narrowArgsFromInferredSignature`) does not
    // exist, and the call has no result type: note the call so the
    // enclosing `Function` literal is re-derived once `name` is defined
    // (`provisional-application.ts`). Also a call with closed arguments: the
    // result type of the literal reads the result type of the call
    // (`R := M ↦ G(M − [0, 0, Y])` before `G := M ↦ [M[1], M[2], M[3]]` is
    // typed `-> vector<3>`, as with `G` defined first). `Return` is a
    // statement that its `Block` reads, with no definition, not a call that
    // waits for one.
    if (isProvisionalCaptureOpen() && name !== 'Return')
      noteProvisionalCall(name);
    return new BoxedFunction(ce, name, boxedOps, {
      metadata,
      canonical: true,
      freeHead,
    });
  }

  //
  // An operator that REQUIRES named arguments (an object-type constructor —
  // `docs/TYPE_SYSTEM_ROADMAP.md` Appendix B, ruling B11) rejects any argument
  // written positionally.
  //
  // Checked HERE, before the permutation below, because that is the last point
  // at which a named call and a positional one are still distinguishable:
  // normalization rewrites a named call into declaration order, and from then
  // on every consumer sees the same operand list either way. A MIXED call is
  // rejected too (`Person("Alan", lastName: "Turing")`): naming the arguments
  // is what makes the call order-free, and one positional argument puts a slot
  // back under the control of its position.
  //
  if (
    ops.length > 0 &&
    !isValueDef(def) &&
    def.operator.namedArgumentsRequired
  ) {
    const blamed = namesRequiredOperands(ce, ops, def.operator.signature.type);
    if (blamed !== undefined)
      return new BoxedFunction(ce, name, flatten(semiCanonical(ce, blamed)), {
        metadata,
        canonical: true,
      });
  }

  //
  // A named call is permuted into declaration order HERE — after the callee's
  // definition is known, and before every consumer that reads an operand by
  // position: `annotateCallbacksFromSignature` (whose contextual arm selection
  // keys on `ops.length`), `semiCanonical`/`flatten`, the binder pre-phase
  // (`canonicalizeBinder` picks binding sites by raw operand index), the lazy
  // split, and `validateArguments`. Placing the seam above all of them is what
  // makes per-position effects metadata and binder site selection correct with
  // no changes of their own.
  //
  // The no-definition branch above is deliberately NOT covered: a call ahead
  // of its definition has no names to check, so its carriers are left
  // untouched and each reports `argument-names-unavailable` when it
  // canonicalizes (design doc §6).
  //
  // `Apply` is EXCLUDED (sub-ruling R4), with three carve-outs below. Its own
  // parameters are `(name, arguments*)` — the first one IS the callee — so a
  // name written in an `Apply` argument list is meant for that callee, not
  // for `Apply`, and matching it against `Apply`'s signature would answer a
  // question nobody asked. `(⟨literal⟩)(x: 1)` canonicalizes to `Apply` too,
  // so this one exclusion covers the whole non-symbol-callee spelling.
  // Declining leaves the carriers to report `argument-names-unavailable`.
  // The carve-outs are the three `Apply` shapes whose callee's parameter names
  // ARE knowable here: a qualified protocol member (next comment), a field of
  // a constant or record-typed receiver (the comment after it) and an inline
  // function literal (below them).
  //
  // The first carve-out is the QUALIFIED protocol-member call, which reaches this
  // seam as `Apply(Field(Protocol, "member"), …)` — the shape its
  // `MemberCall` parse canonicalizes to — (and can be written directly as
  // `ProtocolMember(Protocol, "member", …)` on the box route). Unlike an
  // inline literal, its parameter names are STATICALLY known — the
  // requirement of the named protocol declares them — so the call is
  // permuted here, against that requirement, before the carriers would
  // canonicalize. Without this, qualification (the escape hatch the
  // `protocol-call-ambiguous` diagnostic steers to) forced a named call to
  // drop its names. The bare `member(self: x, …)` form needs none of this:
  // the dispatcher's synthesized signature carries the requirement's names
  // (`sharedParameterName`, engine-protocols.ts) and the ordinary seam
  // below permutes it.
  //
  // The second carve-out is a callee that is a FIELD of a record or a
  // dictionary, `Apply(Field(bob, "S"), …)` — the shape `bob.S(…)`
  // canonicalizes to (GitHub issue #390, decided 2026-10-01). It is checked
  // first, and for a call with or without names, because its first form
  // replaces the whole call: when `bob`
  // is a constant whose field `S` holds a symbol that names an operator, the
  // call becomes the direct call `bob_S(…)` before any argument is made
  // canonical, so the operator's named parameters, its `lazy` flag and its
  // argument checks apply exactly as when the author writes `bob_S(…)`. A
  // field that holds a `Function` literal replaces the callee with the
  // literal in a call with a named argument, and the inline-literal
  // carve-out below then matches the names (a call without names keeps its
  // `Field` callee).
  // When neither applies and the receiver's type is a record that gives the
  // field a signature, the names are matched against that signature, below
  // with the protocol requirement. `resolveFieldCallee` (field-callee.ts)
  // states the rules in full.
  let fieldSignature: Type | undefined = undefined;
  // The receiver of a `Field` callee whose type was inferred, when its
  // signature gives the names: the call is matched again after an
  // assignment to the receiver (see below).
  let fieldReceiver: BoxedValueDefinition | undefined = undefined;
  if (name === 'Apply') {
    // A qualified callee, `Apply(Module(Floor), …)` (the Epsil
    // `std::floor(…)`), whose name the system scope defines as an operator,
    // is the plain call `Floor(…)`, boxed before any argument is
    // canonicalized, so a lazy operator gets its operands raw and a binder
    // binds its variable. Where `Floor` is not shadowed
    // (`shadowsQualifiedName()`, `function-utils.ts`), the call is boxed by
    // the normal route. Where it is shadowed, it is boxed by
    // `ce._libraryCall()`, which binds the call to the library operator and
    // boxes the arguments in the current scope. A value definition of the
    // library (a constant) is left to the `Apply` canonical handler.
    //
    // A callee that is already boxed, a symbol bound to the library operator
    // of its name (the canonical form of `["Module", "Sum"]`), is read here
    // too, but only where the name is shadowed: the `Apply` canonical handler
    // would get the arguments canonicalized in the current scope, so a lazy
    // or binding library operator would not get its operands as written, and
    // the index `k` of `Sum(k, Limits(k, 1, 3))` would be declared in the
    // current scope. A callee in parentheses, `Delimiter(Module(Sum))`, is
    // read without them, when `Delimiter` is the library operator in the
    // scope of the boxing: the canonical handler of a `Delimiter` that the
    // program defines can return another callee.
    const callee = withoutParentheses(ops[0], (delimiter) => {
      if (delimiter instanceof _BoxedExpression && delimiter.isCanonical)
        return isLibraryOperator(delimiter, 'Delimiter');
      const library =
        ce._evalContextStack[0]?.lexicalScope.bindings.get('Delimiter');
      return (
        library !== undefined &&
        !shadowsQualifiedName(
          ce,
          'Delimiter',
          library,
          scope ?? ce.context.lexicalScope
        )
      );
    });
    let qualifiedName = moduleQualifiedName(callee);
    let boxedCallee = false;
    if (
      qualifiedName === undefined &&
      callee instanceof _BoxedExpression &&
      isSymbol(callee)
    ) {
      const library = ce._evalContextStack[0]?.lexicalScope.bindings.get(
        callee.symbol
      );
      if (
        library !== undefined &&
        'operator' in library &&
        callee.operatorDefinition === library.operator
      ) {
        qualifiedName = callee.symbol;
        boxedCallee = true;
      }
    }
    if (qualifiedName !== undefined) {
      const library =
        ce._evalContextStack[0]?.lexicalScope.bindings.get(qualifiedName);
      if (library !== undefined && 'operator' in library) {
        const args = ops.slice(1);
        if (
          !shadowsQualifiedName(
            ce,
            qualifiedName,
            library,
            scope ?? ce.context.lexicalScope
          )
        ) {
          if (!boxedCallee)
            return ce.function(qualifiedName, args, { metadata, scope });
        } else {
          const call = ce._libraryCall(qualifiedName, args, {
            metadata,
            scope,
          });
          if (call !== undefined) return call;
        }
      }
    }
    const field = resolveFieldCallee(
      ce,
      ops[0],
      scope ?? ce.context.lexicalScope,
      named
    );
    if (field?.kind === 'operator')
      return ce.function(field.name, ops.slice(1), { metadata, scope });
    if (field?.kind === 'literal') ops = [field.literal, ...ops.slice(1)];
    else if (field?.kind === 'signature') {
      fieldSignature = field.signature;
      fieldReceiver = field.receiver;
    }
  }

  // The name and the operand of each written argument of a named call
  // through a variable with an inferred type (see below), or through a
  // `Field` whose receiver has an inferred type.
  let writtenArguments: WrittenArgumentSlot[] | undefined;

  const qualified = !named
    ? undefined
    : name === 'Apply'
      ? qualifiedFieldParts(ops[0])
      : name === 'ProtocolMember'
        ? protocolMemberParts(ops)
        : undefined;
  if (qualified !== undefined) {
    // A protocol requirement first; else, for a `Field` callee whose
    // receiver's record type gives the field a signature, that signature.
    // A base that is an already-boxed symbol bound to a CONSTANT is read
    // through that binding, as the `Field` reads it when the call is
    // evaluated, not through its name in this scope. A symbol bound to a
    // variable or to a binding with no value (a protocol name has none)
    // reads the innermost binding of its name when it is evaluated, so the
    // name is looked up (`receiverDefinition`, field-callee.ts).
    const boundBase =
      'receiver' in qualified &&
      qualified.receiver instanceof _BoxedExpression &&
      isSymbol(qualified.receiver) &&
      qualified.receiver.valueDefinition?.isConstant === true
        ? qualified.receiver.valueDefinition
        : undefined;
    const protocolRequirement = qualifiedMemberRequirementShape(
      ce,
      qualified.base,
      qualified.member,
      // Only the `Field` route has a SYMBOL base a value binding could
      // shadow; the `ProtocolMember` operands name the protocol as data.
      name === 'Apply' ? (scope ?? ce.context.lexicalScope) : undefined,
      boundBase === undefined ? undefined : boundBase.value !== undefined
    );
    const requirement: Type | null =
      protocolRequirement ?? fieldSignature ?? null;
    if (requirement !== null) {
      // The operands before the argument list: the callee for `Apply`, the
      // protocol and member names for `ProtocolMember`.
      const prefix = name === 'Apply' ? 1 : 2;
      const split = splitNamedArguments(ops.slice(prefix));
      const normalized = normalizeNamedArguments(ce, split, requirement);
      // `kind: 'apply'` cannot occur: no clauses are passed, and only a
      // clause list can pin a call to one arm of an overload set.
      if (normalized.kind === 'error')
        return new BoxedFunction(
          ce,
          name,
          flatten(
            semiCanonical(ce, [...ops.slice(0, prefix), ...normalized.ops])
          ),
          { metadata, canonical: true }
        );
      if (normalized.kind === 'ok') {
        ops = [...ops.slice(0, prefix), ...normalized.ops];
        // The names were matched against the INFERRED type of the receiver
        // of a `Field` callee, which an assignment can change. Keep the
        // names, as for a named call through a variable with an inferred
        // type (below), so that the call is matched again against the
        // record that the receiver holds when the call is evaluated. The
        // callee is the first operand, kept in place without a name.
        if (
          protocolRequirement === null &&
          fieldReceiver !== undefined &&
          normalized.permutation !== undefined
        )
          writtenArguments = [
            { name: undefined, slot: 0 },
            ...writtenArgumentSlots(split, normalized.permutation).map(
              ({ name, slot }) => ({ name, slot: slot < 0 ? slot : slot + 1 })
            ),
          ];
      }
      // `unavailable` leaves `ops` alone: the carriers decline as before.
    }
  } else if (named && name === 'Apply') {
    // Third carve-out: an INLINE function-literal callee,
    // `((x: number) => x + 1)(x: 5)`. Its parameter names sit in the very
    // expression being applied — read syntactically by
    // `inlineLiteralSignature`, so an UNANNOTATED literal's names work too,
    // even though its inferred signature type drops them (that drop is why a
    // literal bound to a NAME is still not name-addressable; ROADMAP
    // "Named-argument calls — v1 residuals"). The callee operand itself is
    // left untouched: only the argument list is permuted, and the literal
    // canonicalizes downstream exactly as a positional call's would.
    const literalSignature = inlineLiteralSignature(ce, ops[0]);
    if (literalSignature !== undefined) {
      const split = splitNamedArguments(ops.slice(1));
      const normalized = normalizeNamedArguments(ce, split, literalSignature);
      // `kind: 'apply'` cannot occur: the synthesized signature is a single
      // arm, never an overload set, and no clauses are passed.
      if (normalized.kind === 'error')
        return new BoxedFunction(
          ce,
          name,
          flatten(semiCanonical(ce, [ops[0], ...normalized.ops])),
          { metadata, canonical: true }
        );
      if (normalized.kind === 'ok') ops = [ops[0], ...normalized.ops];
      // `unavailable` leaves `ops` alone: the carriers decline as before.
    }
  } else if (named && name !== 'Apply' && name !== 'MemberCall') {
    // `MemberCall` is excluded for the same reason `Apply` is: its own
    // parameters are `(receiver, member, arguments*)`, and a name written in
    // `c.scale(k: 2)` is meant for the callee the node resolves to, not for
    // `MemberCall`. The operator holds its operands, so the carriers reach
    // its canonical handler intact, and the call it builds — the dispatcher
    // call `scale(c, k: 2)`, or the qualified `Apply(Field(P, m), …)` — comes
    // back through this seam under the head that does carry the names.
    if (isValueDef(def) && def.value._programVariable &&
        (isWildcardFunctionType(def.value.type.type) || def.value.type.isUnknown) && def.value.value === undefined) {
      const written = ops.map((op) => ce.box(op, { form: 'raw' }));
      const held = written.map((op) => isFunction(op, 'NamedArgument')
        ? ce._fn('NamedArgument', semiCanonical(ce, op.ops), { metadata: { sourceOffsets: op.sourceOffsets } })
        : semiCanonical(ce, [op])[0]);
      const call = new BoxedFunction(ce, name, held, { metadata, canonical: true });
      call._refusedOps = written;
      call._stampCallee(undefined, written);
      return call;
    }
    const split = splitNamedArguments(ops);
    if (split) {
      // A variable callee: the names are matched against its DECLARED type
      // only, never against the value it holds now, and are rejected when
      // that type gives no parameter names (`valueCalleeSignature`).
      const signature = isValueDef(def)
        ? valueCalleeSignature(def.value)
        : def.operator.signature.type;
      const normalized =
        signature === null
          ? declaredNamesUnavailable(ce, split)
          : normalizeNamedArguments(
              ce,
              split,
              signature,
              multiClauseState(def)?.clauses,
              // The default values that fill an optional parameter the
              // names skip, boxed once for the definition.
              signature === undefined
                ? undefined
                : signatureDefaultOperands(
                    ce,
                    isValueDef(def) ? def.value : def.operator,
                    signature
                  )
            );
      // Sub-ruling R5 enforcement: the names determined ONE clause of a
      // multi-clause callee and the ordinary call would dispatch elsewhere, so
      // the emitted expression applies that clause's literal directly instead
      // of re-entering the callee (which has no names left to filter its
      // clauses with). The printed form changes — `Apply(⟨literal⟩, …)` rather
      // than `f(…)` — and only for a call whose value would otherwise diverge
      // from what the names asked for.
      if (normalized.kind === 'apply')
        return ce.function('Apply', [normalized.literal, ...normalized.ops], {
          metadata,
          scope,
        });
      if (normalized.kind === 'error') {
        const result = new BoxedFunction(
          ce,
          name,
          flatten(semiCanonical(ce, normalized.ops)),
          { metadata, canonical: true }
        );
        // A named refusal is checked again after the same callee is
        // replaced, just as a successful named call is below.
        if (isValueDef(def)
          ? def.value.inferredType || (def.value._programVariable && isWildcardFunctionType(def.value.type.type))
          : def.operator.isUserFunctionDefinition)
        {
          const written = ops.map((op) => ce.box(op, { form: 'raw' }));
          result._refusedOps = written;
          result._stampCallee(undefined, written);
        }
        return result;
      }
      // `unavailable` leaves `ops` alone: the carriers survive to their own
      // canonicalization, which is where `argument-names-unavailable` is
      // minted.
      if (normalized.kind === 'ok') {
        ops = normalized.ops;
        // A variable with an INFERRED type, or a user function (an operator
        // definition made by the assignment of a function literal): the
        // names were matched against the function the name holds now, and a
        // later assignment can give it a function with other parameter
        // names. Keep the names, so that the call is matched again against
        // the function the name holds when the call is evaluated
        // (`BoxedFunction._reboxedForCallee()`). A DECLARED type of a
        // variable is a contract that every assigned value satisfies, so its
        // names do not change. An operator declared with
        // `inferredSignature: true` whose signature has a default is
        // recorded too (see the record below): the assignment of a function
        // literal replaces its names and its defaults, and a default that a
        // hole of the call received (`f(3, factor: 5)` boxed to
        // `f(3, 1, 5)`) is inserted again from the new definition only when
        // the call is boxed again with its names.
        if (
          normalized.permutation !== undefined &&
          (isValueDef(def)
            ? def.value.inferredType || (def.value._programVariable && isWildcardFunctionType(def.value.type.type))
            : def.operator.isUserFunctionDefinition ||
              (def.operator.inferredSignature &&
                parameterDefaultOperands(ce, def.operator) !== undefined))
        )
          writtenArguments = writtenArgumentSlots(
            split,
            normalized.permutation
          );
      }
    }
  }

  if (isValueDef(def)) {
    // The symbol is declared, but as a value.
    // We construct the function expression and will check its value
    // is a function literal when evaluating it.
    //
    // Before ANY operand is boxed: a declared arrow-typed parameter annotates
    // an inline `Function` literal passed at that position (the
    // signature-driven trigger), so the literal canonicalizes once, already
    // annotated. Runs ahead of the wildcard narrowing sink below, preserving
    // the documented sink-before-noting order.
    const calleeType = calleeSignatureType(def.value);
    // The declared type with a transparent alias unfolded, as
    // `calleeSignatureType` reads it.
    const declaredCalleeType = resolveTypeAlias(def.value.type.type);
    const calleeOps = ops.some(isSpreadOperand)
      ? ops
      : annotateCallbacksFromSignature(ce, ops, calleeType);

    // A bare `N` or `D` at an argument whose parameter takes any value is a
    // variable (`devolveAtValuePositions`). A callee with no parameter types
    // (declared `function`, holding no literal) takes values at every
    // argument.
    const flatOps = flatten(semiCanonical(ce, calleeOps));
    // The operands as written, before a default value is inserted. A call
    // whose callee can change is boxed again from these (see `_stampCallee`
    // below), so that the defaults of the function the name holds then are
    // inserted.
    const writtenOps =
      calleeType === undefined || isWildcardFunctionType(calleeType)
        ? devolveValueElements(ce, flatOps)
        : (devolveAtValuePositions(
            ce,
            name,
            calleeType,
            flatOps,
            isAnnotatedValueParameter
          ) ?? flatOps);
    // The written arguments index the operands in declaration order, so they
    // are kept only when no operand was spliced or removed.
    const written =
      writtenOps.length === calleeOps.length ? writtenArguments : undefined;
    // A parameter with a default value that the call leaves out receives its
    // default operand. The defaults are read from the type of the variable:
    // its declared type (`g: (number, number = 2) -> number`), or the type
    // inferred from the function it holds now, whose call is boxed again
    // when the variable is assigned another function. A variable DECLARED
    // with the bare `function` type has no defaults here: the function it
    // holds fills them when it is applied. A variable whose `function` type
    // was inferred is filled from the type of the function it holds
    // (`calleeType`), as a named call of it is. A `Spread` operand leaves
    // the number of positions unknown until evaluation, when the call is
    // boxed again after the splice.
    const valueDefaults =
      calleeType === undefined ||
      (!def.value.inferredType && isWildcardFunctionType(declaredCalleeType)) ||
      writtenOps.some((x) => x.operator === 'Spread')
        ? undefined
        : signatureDefaultOperands(ce, def.value, calleeType);
    const boxedOps =
      valueDefaults === undefined
        ? writtenOps
        : fillParameterDefaults(writtenOps, calleeType!, valueDefaults);

    // A function-typed value definition that was INFERRED is not a user
    // constraint but a placeholder — typically the auto-declaration the
    // no-def branch above made for an earlier occurrence of `name` in this
    // very body. It carries no parameter types, so the same evidence loss
    // applies: note the call (idempotent per literal).
    //
    // The bare `function` WILDCARD (`ce.declare('clean', 'function')`, the
    // documented forward-declaration form) is the same situation reached by a
    // different provenance: the author stated only "this is callable", so
    // there are no parameter types to narrow from either — until something is
    // assigned, at which point `setSymbolValue`/`updateDef` fire the repair
    // and the re-canonicalization reads the signature below.
    const wildcardCallee = isWildcardFunctionType(declaredCalleeType);

    // The narrowing sink for a wildcard-declared callee. The declared type is
    // a widening that carries no parameter types, and it deliberately STAYS
    // that way through assignment (narrowing it would turn a permissive
    // forward declaration into an arity/parameter contract that a later
    // re-assignment would have to satisfy). The assigned value's own type is
    // the only signature there is, so read it here — the same collection-only
    // evidence the operator path takes from `opDef.signature`.
    //
    // Runs BEFORE the noting below so the "assignment first, then caller"
    // order resolves synchronously: the sink writes the evidence, the
    // arguments stop being narrowable, and the caller does not register as a
    // permanent dependent that every later re-assignment would re-derive. A
    // SCALAR assignment writes nothing (scalar parameter types are not
    // evidence), so those callers stay narrowable and do still park.
    // The literal is read under the name it is held by, so that a collection
    // passed in a self-call is evidence here as on the operator path
    // (`namedLiteralSignatureType`).
    //
    // A variable whose function type was INFERRED from the literal it holds
    // (the Epsil `let k = p => p[1] + p[2]`) is read the same way. Its type
    // is a guess, like the signature of a user function, so the call takes
    // the same evidence as on the operator path: `k(ws)` types `ws` as it
    // does for `function k(p) { … }` and for `ce.assign('k', …)`. The
    // literal's own type is read, not the variable's type, because the
    // parameter slots of the literal's type carry the origin of an inferred
    // tuple (`isIndexReadTuple()`).
    const inferredFunctionValue =
      def.value.inferredType && def.value.type.matches('function');
    if (wildcardCallee || inferredFunctionValue) {
      const assigned = def.value.value;
      const assignedType =
        assigned === undefined
          ? undefined
          : namedLiteralSignatureType(name, assigned);
      if (assignedType !== undefined)
        narrowArgsFromInferredSignature(assignedType, boxedOps);
    }

    if (wildcardCallee || inferredFunctionValue) {
      if (isProvisionalCaptureOpen() && hasNarrowableArg(boxedOps))
        noteProvisionalCall(name);
    }

    // If the symbol was declared with an explicit *function* signature (e.g.
    // `ce.declare('f', '(integer) -> integer')`), enforce the parameter types
    // on application in strict mode: `f(0.5)` and `f("a")` are ill-typed. The
    // value-def application path historically honored the *result* type but
    // never validated the operands. An *inferred* signature carries no user
    // constraint (and an assigned function literal validates its own params
    // when applied), so skip those — except for the Epsil static pre-pass,
    // which asks for a function LITERAL's signature to be enforced here
    // (`staticallyPinnedCallee`).
    //
    // A callee declared `function` and assigned a literal that annotates a
    // parameter (`(u: real) ↦ 7`) is checked against those annotations, as
    // the literal is pinned. The same literal assigned with no declaration
    // is an operator definition, whose call is checked against them, so
    // `f("abc")` is invalid on both routes, typed `error` on both.
    const wildcardLiteral = wildcardCallee && !def.value._programVariable
      ? annotatedLiteral(def.value.value)
      : undefined;
    const pinned = def.value.inferredType || wildcardLiteral !== undefined;
    const valueType = wildcardLiteral?.type.type ?? declaredCalleeType;
    if (
      ce.strict &&
      (!def.value.inferredType ||
        wildcardLiteral !== undefined) &&
      typeof valueType !== 'string' &&
      // A plain signature, OR an overload set (an intersection of signatures).
      // Gating on `kind === 'signature'` alone let an overload-typed value
      // definition skip validation entirely — `h(true)` and `h(1,2,3)` against
      // `((integer) -> integer) & ((string) -> string)` were both reported
      // valid. `validateArguments` resolves the overload itself.
      (valueType.kind === 'signature' || overloadArms(valueType) !== undefined)
      // Complex-family parameters (`(complex) -> complex`, …) are enforced
      // like any other: under D10 (2026-07-02) `real ⊂ complex`, so
      // real/integer/rational arguments satisfy them through the normal
      // subtype path, and the arithmetic type handlers (Multiply, Divide,
      // Power, Ln) are complex-aware for real × pure-imaginary operands (a
      // pure-imaginary product such as `√2·i` types as `imaginary` ⊂
      // `complex`), which retired the last `signatureHasComplexParam` skip.
    ) {
      // Scalar-param signatures are THREADABLE at the application site: the
      // lambda-broadcast machinery maps the body element-wise over a
      // collection operand at runtime (`h(L+1)` evaluates to a List), so
      // validation must admit collection-typed operands against the scalar
      // parameter instead of baking `incompatible-type` (Tycho item 73).
      //
      // `valueResolutionOut` receives the overload resolution when
      // `valueType` is an overload set: it is attached to the constructed
      // call so result typing reads the arm the call was VALIDATED against
      // (`_resolvedOverload`, phase 2c).
      const valueResolutionOut: { resolution?: OverloadResolution } = {};
      const heldLiteral = def.value.value;
      const pinnedLiteral = !pinned
        ? undefined
        : (wildcardLiteral ??
          (isFunction(heldLiteral, 'Function') ? heldLiteral : undefined));
      const checkedType = pinned
        ? pinnedValidationSignature(valueType, boxedOps.length, pinnedLiteral)
        : placeholderSlotsAs(valueType, def.value._signatureSkeleton, 'any');
      const enforcesAnnotations =
        pinnedLiteral !== undefined &&
        isFunction(pinnedLiteral, 'Function') &&
        pinnedLiteral.ops
          .slice(1)
          .some((p) => functionLiteralParameterType(p) !== undefined);
      const invalid = validateArguments(
        ce,
        boxedOps,
        checkedType,
        undefined,
        // A DECLARED `broadcastable<T>` slot is threadable BY DECLARATION
        // (Option A, 2026-08-08): the application MAPS a collection argument
        // there, so the whole-argument check against `broadcastable<T>` is the
        // wrong one — the contract is per ELEMENT, and it is checked where the
        // elements exist (`declaredBroadcastElement`). Without this the
        // declared spelling rejected a mixed-element list that the plain
        // `(T)` spelling admits and diagnoses element by element.
        //
        // PER POSITION, not signature-wide: a sibling slot the declaration
        // binds WHOLE (`list<…>`, `tuple<…>`, a callback) is validated as
        // usual, or `(broadcastable<number>, list<string>)` would admit a
        // `list<number>` at the second slot unchecked.
        // The gate reads the signature as reported: a placeholder slot read
        // as `any` for validation is still a scalar slot for threading when
        // its refined type is one.
        threadableGate(
          pinned ? checkedType : valueType,
          paramsAreScalar(pinned ? checkedType : valueType)
        ),
        undefined,
        undefined,
        {
          resolutionOut: valueResolutionOut,
          operatorName: name,
          // A list of points at a parameter declared as a point is mapped
          // over at evaluation (`isPointListArgumentType`).
          mapsPointLists: true,
          // A function held as a value is a user function: `NaN` is
          // accepted at its numeric parameters (`acceptsNaNArgument`,
          // `validate.ts`).
          userFunction: true,
          // An absent argument at an annotated parameter of a pinned
          // literal is refused, as at the call of a `function` definition
          // (`refusesAbsentArgument`, `validate.ts`).
          enforcesParameterAnnotations: enforcesAnnotations,
        }
      );
      if (invalid) {
        // Only a closed operand stays rejected, or one whose type refutes
        // the parameter (`keepProvisionalOperands`).
        const cleaned = keepProvisionalOperands(
          ce,
          boxedOps,
          invalid,
          checkedType,
          enforcesAnnotations
        );
        // `validateArguments` returns a non-null list not only when an
        // operand was REJECTED but also when one was SUBSTITUTED and every
        // entry is valid — a one-cluster string literal narrowed to the
        // `character` a declared parameter expects, or an operand repaired
        // by matrix inference. Building the call from `boxedOps` here would
        // discard that substitution (the operator-definition route keeps it),
        // so the cleaned list is used whether or not it carries an error.
        const fn = new BoxedFunction(ce, name, cleaned, {
          metadata,
          canonical: true,
        });
        fn._resolvedOverload = valueResolutionOut.resolution;
        // The operands were checked against the literal that the name holds
        // now, and a later assignment can replace it. Keep the operands, so
        // that the call is checked again against the new literal
        // (`BoxedFunction._recheckedCall()`).
        if (pinned && cleaned.some((x) => !x.isValid))
          fn._refusedOps = writtenOps;
        // The call is boxed again from the operands as written, not from the
        // operands that this check replaced.
        if (pinned)
          fn._stampCallee(written, writtenOps, undefined, {
            filled: boxedOps,
          });
        return fn;
      }
      const fn = new BoxedFunction(ce, name, boxedOps, {
        metadata,
        canonical: true,
      });
      fn._resolvedOverload = valueResolutionOut.resolution;
      // The operands were checked against the literal that the name holds
      // now. A later assignment can replace it with a literal that refuses
      // them, so the call records the definition it was checked against
      // (`BoxedFunction._reboxedForCallee()`).
      if (pinned)
        fn._stampCallee(written, writtenOps, undefined, { filled: boxedOps });
      return fn;
    }

    // A symbol whose DECLARED type is provably INAPPLICABLE — a scalar
    // constant (`Pi`), an absence marker (`Nothing`), a `number`-declared
    // variable — applied as a function is a definite mistake: nothing can
    // make the application meaningful, and it used to stay inert typed
    // `unknown` (`Pi(2)` and `Nothing()` alike), silently absorbing what is
    // almost always a syntax slip. The error code starts with `expected-`,
    // so the Epsil static pre-pass reports it before anything runs.
    //
    // Narrow by construction — every one of these stays inert/applicable:
    // - INFERRED types (a guess; the devolve/repair machinery owns those);
    // - `any`/`unknown` (could still be a function);
    // - anything that COULD be a function, including a mixed callable
    //   union (`((integer) -> integer) | number` keeps its latent set);
    // - collection-SHAPED types: a collection-typed head applied is a
    //   legal APPLICATION (Tycho item 173 — `S(B)` with `S: set<number>`
    //   keeps operator `S`; field adjunction applies a set constant,
    //   `Q(\sqrt{2})`).
    //
    // A head declared exactly `value` is NOT exempted, even though `value`
    // overlaps `collection<any>`: `value` excludes functions from the
    // lattice, so the application can never become meaningful as a CALL,
    // and the vacuous could-be-a-collection overlap of the widest value
    // type is no positive evidence for the indexing/adjunction reading the
    // collection exemption exists for. Declaring `a: value` and writing
    // `a(x)` is diagnosed as applying a non-function; the LaTeX route reads
    // the same juxtaposition as multiplication instead (see the wide-type
    // arms in `invisible-operator.ts`).
    if (
      // Non-strict engines skip application-time type validation, matching
      // the declared-signature parameter checks above.
      ce.strict &&
      !def.value.inferredType &&
      !def.value.type.isUnknown &&
      def.value.type.type !== 'any' &&
      !def.value.type.couldMatch('function') &&
      // `couldMatch`, not `matches`: a MIXED union (`set<number> | number`)
      // or a `broadcastable<T>` head could still hold an applicable
      // collection at run time — only a type that could not possibly be
      // collection-shaped is provably inapplicable.
      (def.value.type.type === 'value' ||
        !def.value.type.couldMatch('collection<any>'))
    ) {
      return ce.error(
        ['expected-function', name, def.value.type.toString()],
        name
      );
    }

    const fn = new BoxedFunction(ce, name, boxedOps, {
      metadata,
      canonical: true,
    });
    // A variable declared `function`, or with no declaration, can later hold
    // a function that refuses the operands (an assignment can also make the
    // name an operator definition), and a named call matches its names
    // against the function the variable holds now. The call records the
    // definition, so that it is boxed again after an assignment
    // (`BoxedFunction._reboxedForCallee()`). A variable declared with a
    // signature is not recorded: the signature is a contract that every
    // assigned function satisfies.
    if (
      written !== undefined ||
      wildcardCallee ||
      (def.value.inferredType && def.value.type.matches('function'))
    )
      fn._stampCallee(written, writtenOps, undefined, { filled: boxedOps });
    return fn;
  }

  const opDef = def.operator;

  // If the operator has a local scope, create it now (unless we were given one,
  // for example one might have been create to record the arguments of a
  // function, but not for a Block expression)
  scope ??= opDef.scoped
    ? {
        parent: ce.context.lexicalScope,
        bindings: new Map(),
      }
    : undefined;

  // A *binder* declares which of its operands are its bound variables, with
  // the `bound` and `clause` roles of its `operands` handler, which give
  // its definition the binding sites `opDef.bindingSites`. The
  // framework then owns the two things every binder used to improvise: the
  // declaration of the variable in the operator's own scope (before the
  // canonical handler canonicalizes the body against it), and the rebinding of
  // the site afterwards, so the parse, `ce.box()` and `ce.function()` routes
  // agree about which binding the variable denotes.
  // See `docs/SCOPING-MODEL.md`
  const sites = opDef.bindingSites;
  if (sites !== undefined && scope !== undefined)
    return canonicalizeBinder(ce, name, ops, metadata, scope, opDef, sites);

  if (opDef.scoped && scope !== undefined)
    return applyOperatorDefinition(ce, name, ops, metadata, scope, opDef);

  // Receives the operands as boxed before the check against `opDef`, and
  // what a callback stamp read from the value of a variable.
  const checked: {
    ops?: ReadonlyArray<Expression>;
    filled?: ReadonlyArray<Expression>;
    stamp?: ValueDerivedStamp;
  } = {};
  const result = applyOperatorDefinition(
    ce,
    name,
    ops,
    metadata,
    scope,
    opDef,
    undefined,
    checked
  );
  // An assignment can replace a user function (`h := (u: real) ↦ 7`) after
  // the call was checked against it. The call records the definition, so
  // that its type and its value are those of the same call boxed against
  // the new definition (`BoxedFunction._reboxedForCallee()`). The call is
  // boxed again from the operands as written, not from the operands that
  // the check against the old definition replaced. The names of a named
  // call are kept with the record. They index the operands in declaration
  // order, so they are kept only when no operand was spliced or removed.
  // An operator declared with `inferredSignature: true` is not yet a user
  // function, but the assignment of a function literal replaces it, and its
  // defaults with it. When its signature has a default, every call of it is
  // recorded too: after the assignment, the call is checked again against
  // the new literal (`f(3, 4)` is an error when the literal takes one
  // argument), and its written operands are filled from the new definition,
  // not from the old defaults. This includes a named call that received a
  // default at a hole (`f(3, factor: 5)` boxed to `f(3, 1, 5)`). The route
  // of a `canonical` handler or of a lazy operator does not give the written
  // operands, so a call of such an operator on that route is not recorded:
  // it would be boxed again from the operands with the old defaults.
  if (
    (opDef.isUserFunctionDefinition ||
      (opDef.inferredSignature &&
        checked.ops !== undefined &&
        parameterDefaultOperands(ce, opDef) !== undefined)) &&
    result instanceof BoxedFunction &&
    result.operator === name
  )
    result._stampCallee(
      checked.ops?.length === ops.length ? writtenArguments : undefined,
      checked.ops,
      undefined,
      { filled: checked.filled }
    );
  // A named call through a `Field` whose receiver has an inferred type
  // records the receiver's definition, with the names as written: after an
  // assignment to the receiver, the call is boxed again, and the names are
  // matched against the signature of the record that it holds then
  // (`BoxedFunction._reboxedForCallee()`). `Apply` has a canonical
  // handler, so the call is boxed again from its own operands: the names
  // index them, so they are kept only when no operand was removed.
  if (
    fieldReceiver !== undefined &&
    writtenArguments !== undefined &&
    result instanceof BoxedFunction &&
    result.operator === name &&
    result.nops === ops.length
  )
    result._stampCallee(writtenArguments, undefined, fieldReceiver);
  // A callback literal stamped from the value of a variable: the call is
  // boxed again after an assignment to the variable.
  if (checked.stamp !== undefined)
    recordValueDerivedStamp(ce, result, name, checked.stamp);
  return result;
}

/** Every value of `t` is a collection — a union qualifies only when all its
 * arms do. Scalar-admitting types (including `unknown`/`any`) do not. */
function isCollectionOnlyType(t: Type): boolean {
  if (typeof t === 'object' && t.kind === 'union')
    return t.types.every(isCollectionOnlyType);
  // Shape question — asked against the absence-admitting family top (the
  // bare-synonym ruling, 2026-08-17): `dictionary<any>` — At's base param —
  // is collection-only evidence just as bare `dictionary` was.
  return isSubtype(t, COLLECTION_SHAPE_TYPE);
}

/**
 * True when at least one operand is a symbol `narrowArgsFromInferredSignature`
 * could still write evidence onto: its type is INFERRED and still `unknown`.
 * That is the only case a re-derivation of the enclosing `Function` literal
 * could learn something from, so it gates the noting of a call through a
 * variable that holds an inferred function (`noteProvisionalCall`): such a
 * call with closed or already-typed arguments waits on nothing.
 */
function hasNarrowableArg(args: ReadonlyArray<Expression>): boolean {
  return args.some(
    (arg) =>
      isSymbol(arg) && hasInferredType(arg) && arg.type.type === 'unknown'
  );
}

/**
 * A call to a user function whose signature was INFERRED skips argument
 * validation (currying and partial application are resolved by the lambda at
 * evaluation time). That skip also silenced the one inference side-channel the
 * validators provide: narrowing an unknown-typed symbol argument to the
 * parameter's type. Without it, a function that merely FORWARDS its parameter
 * (`g(xs) = f(xs)` where `f`'s body indexes its parameter) accumulates no
 * collection evidence on `xs`, its inferred signature stays `(unknown)`, and
 * the lambda auto-broadcast then maps `g` over a collection argument that `f`
 * consumes whole.
 *
 * Propagate just that side-channel here: an argument that is a symbol whose
 * type is inferred and still `unknown` narrows to the callee's inferred
 * parameter type, when that type is collection-only (the evidence is
 * unambiguous — no scalar value could occupy the slot). Scalar parameter
 * types are NOT propagated: an inferred scalar is a broadcast-friendly guess,
 * not evidence the caller's argument is scalar.
 */
function narrowArgsFromInferredSignature(
  sig: Type,
  args: ReadonlyArray<Expression>,
  validation?: Type
): void {
  if (typeof sig === 'string' || sig.kind !== 'signature' || !sig.args) return;
  const sigArgs = sig.args;
  // A slot of a partly annotated literal is bare when its validation
  // signature types it `any` (`OperatorDefinition._validationSignature`).
  // Every slot of an inferred signature is bare.
  const validationArgs =
    typeof validation === 'object' && validation.kind === 'signature'
      ? validation.args
      : undefined;
  const isBare = (i: number): boolean =>
    validationArgs === undefined || validationArgs[i]?.type === 'any';
  const n = Math.min(args.length, sigArgs.length);
  if (n === 0) return;
  // The eligibility test reads each argument's EFFECTIVE type, so it runs
  // fact-blind with the write it gates: an assumption that gives the argument
  // a tier would otherwise suppress a narrowing that outlives the assumption.
  args[0].engine._withoutFacts(() => {
    for (let i = 0; i < n; i++) {
      const arg = args[i];
      if (!isSymbol(arg)) continue;
      if (!hasInferredType(arg)) continue;
      if (arg.type.type !== 'unknown') continue;
      const paramType = sigArgs[i].type;
      if (!isCollectionOnlyType(paramType)) continue;
      const argType =
        !isBare(i) || arg.engine._isShadowedParameter(arg.symbol)
          ? paramType
          : oneElementTypeOf(paramType);
      arg._infer(() => argType, 'narrow');
    }
  });
}

/**
 * The type that a FREE symbol (a symbol that is not a parameter of the
 * function literal being canonicalized) learns from the collection type
 * `t` of an inferred parameter slot.
 *
 * The bare parameter of a function literal is typed as a tuple with one
 * component per index that its body reads (`p[1] + n` gives `p` the type
 * `tuple<number>`, `parameterIndexReadType()` in `library/collections.ts`).
 * A free symbol keeps one element type for every index, as a free symbol
 * that is read by index directly does (`docs/INFERENCE_ROADMAP.md` §5): a
 * parameter is local to one body, but a symbol at the top level lives across
 * statements, and a tuple type that grows with each use is surprising. So a
 * tuple slot with unnamed components gives the indexed collection whose
 * element type is the union of the known components: `k(zs, 1)` types `zs`
 * as `indexed_collection<number>`. Another type is returned as it is. A
 * slot that the author annotated is a contract, and is not read here.
 *
 * Only a tuple that index reads made is changed (`isIndexReadTuple()`). A
 * tuple that a call in the body requires is a contract: with
 * `h := p ↦ g(p)` and `g: (tuple<number, number>) -> number`, `h(zs)` types
 * `zs` as `tuple<number, number>`. When the body has both a call and index
 * reads (`p ↦ g(p) + p[1]`), the call decides, whatever the order of the
 * uses: an argument that is not that tuple is refused by `g` anyway. This
 * includes a call that requires a longer tuple than the earlier reads made
 * (`p ↦ {p[1] + 1; g(p)}`): index reads do not prove a length, so the
 * parameter takes the tuple of the call (`indexReadTupleExtension()`).
 */
function oneElementTypeOf(t: Type): Type {
  if (typeof t !== 'object' || t.kind !== 'tuple' || !isIndexReadTuple(t))
    return t;
  if (t.elements.some((x) => x.name !== undefined)) return t;
  const known = t.elements.map((x) => x.type).filter((x) => x !== 'unknown');
  return {
    kind: 'indexed_collection',
    elements: known.length === 0 ? 'unknown' : widen(...known),
  };
}

/**
 * The operator-definition half of `makeCanonicalFunction`: apply the `lazy`
 * flag, the `canonical` handler, signature validation, `flatten`,
 * `idempotent`/`involution` and operand sorting.
 *
 * Split out so the binder hook (`canonicalizeBinder`) can wrap it as a whole:
 * every one of its exits is a canonicalization result the post-phase must see.
 * `rawOps` lets the caller pass operands it has already boxed raw (the
 * pre-phase needs them to locate the binding sites), so a binder does not box
 * its operands twice.
 */
/**
 * Re-attach the source position carried by `metadata` to a canonically
 * constructed result that lost it: a custom `canonical` handler (and the
 * numeric fast-path constructors in `makeNumericFunction`) build their result
 * without the caller's metadata. Statement-level positions (`Block` operands,
 * loop bodies, `Declare`/`Assign`) must survive canonicalization so a
 * debugger can map canonical statements back to source
 * (`vscode-epsil/VSCODE_EPSIL_ROADMAP.md`, Tier 2).
 *
 * Only a FUNCTION expression lacking its own offsets is stamped:
 *  - a number/symbol/string result may be an interned singleton (`ce.One`,
 *    a library symbol) shared across unrelated expressions — writing a
 *    position on one would smear it engine-wide;
 *  - a result already carrying offsets (a pass-through operand with its own,
 *    more precise, sub-span) keeps them.
 *
 * The write cannot reach an unrelated statement: a handler's function result
 * is either constructed fresh or is an operand of the very node being
 * canonicalized. (A handler serving a cached function expression would be
 * stamped once with its first consumer's span — positions are advisory
 * metadata, so a stale span is acceptable; structural semantics never read
 * them.) Free when the input carries no offsets (LaTeX and programmatic
 * construction).
 */
function withSourceOffsets(
  result: Expression,
  metadata: Metadata | undefined
): Expression {
  const sourceOffsets = metadata?.sourceOffsets;
  if (sourceOffsets === undefined) return result;
  if (!(result instanceof BoxedFunction)) return result;
  if (result.sourceOffsets !== undefined) return result;
  (result as { sourceOffsets?: [number, number] }).sourceOffsets =
    sourceOffsets;
  return result;
}

/**
 * The log payload for a canonical-handler throw: the error message, plus —
 * for a deadline cancellation — the owner and span chain of the budget that
 * fired (`CancellationError.attribution`/`spans`). Without them the console
 * line reads bare `Timeout exceeded`, which is indistinguishable from an
 * engine-imposed deadline; no such deadline exists — a deadline frame is
 * armed only by an enclosing `withTimeLimit` span, so naming its owner tells
 * the reader whose clock expired (Tycho item 163). Identified by NAME, never
 * `instanceof`: plugin bundles re-bundle engine code.
 */
/**
 * Is `e` a cancellation — an expired deadline, an abort signal, an iteration
 * or recursion-depth breach?
 *
 * The two `catch` blocks around a `canonical` handler log the error and fall
 * back to a NON-canonical `BoxedFunction`, which is right for a handler that
 * genuinely failed on its operands but wrong for a cancellation: a caller who
 * armed `ce.withTimeLimit()` would get their span back NORMALLY, holding a
 * silently degraded expression, with the breach visible only as a line on the
 * console. That is a worse outcome than the unbounded overrun the strided
 * check in `boxFunctionInternal` was added to fix, because it looks like
 * success. Verified before the fix by a canonical handler that builds nodes
 * (which re-enters the strided check from inside the `try`): the span returned
 * normally with `isCanonical === false`.
 *
 * Every other catch site in the engine already makes this exception —
 * `abstract-boxed-expression.ts`, `rules.ts`, `stochastic-equal.ts`,
 * `boxed-function.ts` — so this only brings `box.ts` into line with them.
 *
 * Identified by NAME, never `instanceof`: plugin bundles re-bundle engine
 * code, so a `CancellationError` crossing a bundle boundary is not an instance
 * of the host's class. `isTimeoutCancellation` is deliberately NOT reused —
 * it admits only an expired budget (`cause: 'timeout'` or `'step-budget'`),
 * and an abort or an iteration-limit breach must propagate here for the same
 * reason a timeout must.
 */
function isCancellation(e: unknown): boolean {
  return e instanceof Error && e.name === 'CancellationError';
}

/**
 * Must `e` propagate past the `canonical`-handler catches below? A
 * cancellation must (see `isCancellation`), and so must the control-flow
 * signal a recursive user function raises when it is re-entered with a
 * symbolic argument: it is caught by the outermost application of that
 * function, which then declines (`SymbolicRecursion`, `function-utils.ts`).
 * Swallowed here, the application would not decline and a spurious
 * canonicalization error would be logged instead. Not an `Error`, and
 * identified by `name` for the same bundle-boundary reason as a cancellation.
 */
function mustPropagate(e: unknown): boolean {
  return (
    isCancellation(e) ||
    (typeof e === 'object' &&
      e !== null &&
      (e as { name?: unknown }).name === 'SymbolicRecursion')
  );
}

function canonicalErrorDetail(e: unknown): unknown {
  if (!(e instanceof Error)) return e;
  if (e.name === 'CancellationError') {
    const { attribution, spans } = e as {
      attribution?: string;
      spans?: string[];
    };
    if (attribution !== undefined || (spans?.length ?? 0) > 0) {
      const chain = spans?.length ? `, spans: ${spans.join(' → ')}` : '';
      return `${e.message} (budget owner: ${attribution ?? 'unlabeled'}${chain})`;
    }
  }
  return e.message;
}

/** `xs`, the operands of a lazy operator as written, where each operand
 * whose role in `roles` is `value` and that is a bare `N` or `D` naming the
 * library operator is a variable (`devolveValueElements()`). The lazy
 * operators that declare `value` operands (the comparisons, `List`, `Set`,
 * the conditions of `If` and `Which`) open no scope, so an operand resolves
 * here as it would in the handler. The statements of a `Block` and the
 * branches of an `If` are repaired by the handler of the operator, once its
 * scope and its locals exist. */
function devolveValueOperands(
  ce: ComputeEngine,
  xs: ReadonlyArray<Expression>,
  roles: ReadonlyArray<string>
): ReadonlyArray<Expression> {
  if (roles.every((role) => role === 'value'))
    return devolveValueElements(ce, xs);
  let result: Expression[] | undefined;
  xs.forEach((x, i) => {
    if (roles[i] !== 'value') return;
    const [y] = devolveValueElements(ce, [x]);
    if (y === x) return;
    result ??= [...xs];
    result[i] = y;
  });
  return result ?? xs;
}

/**
 * `xs`, the operands of the lazy operator `name` as written, where each name
 * that resolves to a macro, at any depth, is replaced by the raw body of the
 * macro (rule 2 of `docs/plans/2026-11-12-macro-kind-spec.md`), itself
 * expanded the same way: the handler then reads what it reads for the program
 * with the body written in place of the name. The operands stay raw.
 *
 * Not an occurrence: a name that the call or a binder or lazy call inside it
 * binds or takes as a name (`HiddenBinders`: a binding site, a parameter of
 * `Function`, a local of `Block`, an operand that takes a name,
 * `nameOperandNames()`), an operand held on purpose (the `opaque` and `held`
 * roles, and the operand of a nested `Hold`), and an operand whose role is
 * `bound` or `clause` when it is a symbol.
 */
function expandMacroOperands(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  xs: ReadonlyArray<Expression>,
  roles: ReadonlyArray<string> | undefined
): ReadonlyArray<Expression> {
  if (!anyMacroDeclared(ce)) return xs;
  return (
    unboundRebuilder(ce, { structural: false, expand: true })(
      xs,
      operandPolicies(roles, xs),
      false,
      { head: name, ops: xs, parent: undefined }
    ) ?? xs
  );
}

/** `xs`, the operands of an operator without a `canonical` handler, where
 * each operand whose role in `roles` is `statement` is canonicalized as a
 * branch (`canonicalBranch()`): a `Declare` is the error
 * `declaration-below-statement`, and a bare `Break` or
 * `Continue` symbol is an error. */
function canonicalStatementOperands(
  ce: ComputeEngine,
  xs: ReadonlyArray<Expression>,
  roles: ReadonlyArray<string>
): ReadonlyArray<Expression> {
  if (!roles.includes('statement')) return xs;
  return xs.map((x, i) =>
    roles[i] === 'statement' ? canonicalBranch(ce, x) : x
  );
}

function applyOperatorDefinition(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  ops: ReadonlyArray<ExpressionInput>,
  metadata: Metadata | undefined,
  scope: Scope | undefined,
  opDef: BoxedOperatorDefinition,
  rawOps?: ReadonlyArray<Expression>,
  checkedOut?: {
    ops?: ReadonlyArray<Expression>;
    filled?: ReadonlyArray<Expression>;
    stamp?: ValueDerivedStamp;
  }
): Expression {
  let result: Expression | null;

  // Before ANY operand is boxed and before any operand type is read: a
  // declared arrow-typed parameter annotates an inline `Function` literal
  // passed at that position (the signature-driven trigger of
  // `docs/TYPE-SYSTEM.md`). Skipped when
  // the caller supplied already-boxed operands (a binder's pre-phase) and when
  // a `Spread` makes the positions uncertain.
  //
  // The `rawOps === undefined` half is a DELIBERATE narrowing (Design D §9b):
  // the deleted `callbackElementOf` trigger ran on both routes, and the
  // contextual trigger runs only on the unboxed one — where its whole contract
  // (the literal canonicalizes ONCE, already annotated) is achievable. No
  // converted operator declares binding sites, so nothing reaches the other
  // route today. TRIPWIRE: a converted operator that also BINDS variables must
  // re-visit this gate — it would silently stamp nothing.
  if (rawOps === undefined && !ops.some(isSpreadOperand)) {
    ops = annotateCallbacksFromSignature(
      ce,
      ops,
      opDef.signature.type,
      checkedOut
    );
    if (checkedOut?.stamp !== undefined) checkedOut.stamp.ops = ops;
  }

  if (opDef.lazy) {
    // If we have a lazy function, we don't canonicalize the arguments
    let xs = rawOps ?? boxRawOperands(ce, ops);
    // A bare `N` or `D` held at an operand whose role is `value` (the
    // `operands` handler of the definition) is a variable
    // (`devolveAtValuePositions`). The other operands of a lazy operator are
    // `raw` by default: they hold a name, a pattern, a type or an
    // unevaluated form (`Assign`, `Hold`, `Head`, `Match`), and keep the
    // operand as written. The role, not the signature, says which operand is
    // a value: a comparison is a chain of any length (`Equal(2, 2, N)`),
    // although its signature lists two parameters.
    const roles = opDef.operandRoles(xs);
    // A macro name in an operand, where it is not a name, is the raw body.
    xs = expandMacroOperands(ce, name, xs, roles);
    if (roles !== undefined && !opDef.inferredSignature)
      xs = devolveValueOperands(ce, xs, roles);
    // A parameter with a default value that the call leaves out receives its
    // default operand, here, before the `canonical` handler and the
    // signature check see the operands. The inserted operand is the
    // canonical default boxed when the operator was declared, held like the
    // written operands. A `Spread` operand leaves the number of positions
    // unknown until evaluation; the call is boxed again then, after the
    // splice, and filled at that time. A handler that returns `null`
    // continues below with the operands already filled.
    if (!xs.some((x) => x.operator === 'Spread'))
      xs = withHandlerDefaults(
        xs,
        opDef.signature.type,
        parameterDefaultOperands(ce, opDef)
      );
    // An operator without a `canonical` handler keeps its operands as
    // written, except a `statement` operand, which is canonicalized here as
    // a branch (`canonicalBranch()`). For a binder (an operator with a
    // `bound` or a `clause` operand), `canonicalizeBinder()` calls this function
    // after it has declared the bound variables in the scope of the
    // operator, so a statement operand sees them. A `canonical` handler
    // receives the statement operands as written and canonicalizes them
    // itself.
    if (!opDef.canonical && roles !== undefined) {
      const filledRoles =
        roles.length === xs.length ? roles : opDef.operandRoles(xs)!;
      xs = canonicalStatementOperands(ce, xs, filledRoles);
    }
    if (opDef.canonical) {
      let failure: { error: unknown } | undefined;
      try {
        result = opDef.canonical(xs, { engine: ce, scope });
        if (result) {
          result = withOwnHead(
            ce,
            name,
            'canonical',
            opDef.canonical,
            result,
            () => xs
          );
          // The handler canonicalized the operands it consumes, but no
          // signature validation ran on them, so a valueless symbol passed as
          // a collection operand (`Filter(xs, p)`) got no type from its use.
          // Narrow it from the declared parameter of the RESULT's operator,
          // which is this operator unless the handler rewrote the head
          // (`Fold(f, x, xs)` becomes `Reduce(xs, f, x)`). See
          // `inferCollectionSourceArgs`.
          if (
            isFunction(result) &&
            result.isValid &&
            isCollectionSourceOperator(name) &&
            isCollectionSourceOperator(result.operator)
          ) {
            const resultDef = result.operatorDefinition;
            if (resultDef && !resultDef.inferredSignature)
              inferCollectionSourceArgs(
                ce,
                resultDef.signature.type,
                result.ops
              );
          }
          return withSourceOffsets(result, metadata);
        }
      } catch (e) {
        if (mustPropagate(e)) throw e;
        // Multi-arg form: a non-Error thrown value keeps its structure in the
        // console (and a Symbol or null-prototype object, whose implicit
        // string conversion throws, cannot break the recovery path).
        console.error(
          `ComputeEngine: error canonicalizing \`${name}\`:`,
          canonicalErrorDetail(e)
        );
        failure = { error: e };
      }
      // The canonical handler gave up. A handler that threw, or the handler
      // of an operator with an inferred signature, keeps the call as
      // written, not canonical.
      if (failure !== undefined || opDef.inferredSignature) {
        result = new BoxedFunction(ce, name, xs, {
          metadata,
          canonical: false,
        });
        // Keep the exception with the expression, for a caller that cannot
        // continue without the canonical form (`canonical-failure.ts`).
        if (failure !== undefined)
          recordCanonicalFailure(result, failure.error);
        return result;
      }
      const supplied = suppliedOperandCount(xs);
      // A call with fewer operands than the signature requires, or with
      // more than it admits, is not something the handler can decide. It
      // falls through to the signature validation below, as the call of a
      // head without a handler does: the validation marks an absent operand
      // `Error("missing")` (`Filter(xs)`, `Filter(IsEven)` with no
      // collection) and an operand left over `Error("unexpected-argument")`
      // (`Tail(xs, 2)`), and the call is canonical and invalid. Kept as
      // written, the call was non-canonical and reported valid. As the
      // callee of `Apply` it read as a constant function, and the applied
      // argument was dropped (GitHub issue #426). As an operand of a
      // canonical `Add` (`1 + Tail(xs, 2)`) it reached `toNumericValue()`,
      // whose `console.assert` requires a canonical expression.
      if (
        supplied >= requiredOperandCount(opDef.signature.type) &&
        supplied <= maximumOperandCount(opDef.signature.type)
      ) {
        // A collection operator whose handler refused a SOURCE operand
        // (`Map(x => x, 5)`, `Dedup(5)`) is the operator over the error, as
        // `Sort(5)` is: invalid and typed `error`. See
        // `refusedCollectionSourceOperands`.
        const refused = isCollectionSourceOperator(name)
          ? refusedCollectionSourceOperands(ce, opDef.signature.type, xs)
          : undefined;
        // Any other call is the operator over its canonical operands checked
        // against the signature, always canonical: a refused operand is a
        // typed error (`Interval("'bad'", 1)`), and a call whose operands
        // pass the check is inert (`Series(1)`). See `declinedCallOperands`.
        // A list with a `Spread` operand continues below.
        const resolutionOut: { resolution?: OverloadResolution } = {};
        const declined =
          refused ?? declinedCallOperands(ce, name, opDef, xs, resolutionOut);
        if (declined !== undefined) {
          const call = new BoxedFunction(ce, name, declined, {
            metadata,
            canonical: true,
            scope,
          });
          call._resolvedOverload = resolutionOut.resolution;
          // See `BoxedFunction._declinedByHandler`: no count, and the call
          // is inert.
          if (refused === undefined) call._declinedByHandler = true;
          return withSourceOffsets(call, metadata);
        }
      }
    }

    if (opDef.inferredSignature) {
      // No forward-reference noting on this LAZY path, unlike the non-lazy one
      // below: `xs` are raw, unbound operands, so they carry no binding a
      // re-derivation could narrow (`hasNarrowableArg` reads
      // `valueDefinition`) and there is nothing to wait on.
      narrowArgsFromInferredSignature(opDef.signature.type, xs);
    }
    // See the value-definition site above: the resolution of an overload-set
    // signature is attached to the constructed call for result typing.
    const lazyResolutionOut: { resolution?: OverloadResolution } = {};
    const lazyFn = new BoxedFunction(
      ce,
      name,
      opDef.inferredSignature
        ? xs
        : (validateArguments(
            ce,
            xs,
            // A partly annotated literal validates its bare slots as `any`
            // (`OperatorDefinition._validationSignature`).
            opDef._validationSignature ?? opDef.signature.type,
            opDef.lazy,
            // Declared-`broadcastable<T>` slots are threadable by declaration,
            // per position — see the value-definition site above.
            threadableGate(opDef.signature.type, opDef.broadcastable === true),
            undefined,
            undefined,
            {
              resolutionOut: lazyResolutionOut,
              operatorName: name,
              operatorDefinition: opDef,
              // Contract B NaN admission — same as the strict site above.
              nanPolicyAt: (i) => opDef.resolvedNanBehaviorAt(i),
              refusesAbsentAt: (i) => opDef.refusesAbsentOperandAt(i),
            }
          ) ?? xs),
      { metadata, canonical: true, scope }
    );
    lazyFn._resolvedOverload = lazyResolutionOut.resolution;
    result = lazyFn;
    return result;
  }

  // Keep a boundary around inference performed while canonicalizing these
  // operands. Signature validation may use this to retract only fresh,
  // provisional guesses; inferences from earlier expressions are never
  // eligible for repair.
  // Inlined `boxOperands()` (see there for why): this is the recursive path
  // of every canonical operand — the innermost boxing frames of a deep tree
  // are here — so it neither goes through the public `ce.expr()` (five
  // frames of scope re-installation) nor through `Array.prototype.map` and
  // a callback, nor through the helper itself.
  const boxOne =
    ce._inferenceTxDepth > 0 && ce._boxingState.isRootActive
      ? boxInternal
      : box;
  const xs: Expression[] = [];
  if (opDef.operands === undefined) for (const x of ops) xs.push(boxOne(ce, x));
  else {
    // An operand whose role is `statement` is canonicalized as a branch
    // (`canonicalBranch()`), before the `canonical` handler, if any, runs:
    // the handler of an operator that is not lazy receives canonical
    // operands. The roles are read from the operands as written.
    const written = boxOperands(ce, ops, RAW_OPERAND);
    const roles = opDef.operandRoles(written)!;
    ops.forEach((x, i) =>
      xs.push(
        roles[i] === 'statement'
          ? canonicalBranch(ce, written[i])
          : boxOne(ce, x)
      )
    );
  }

  // A symbolic `Spread` operand (`f(...p)` where `p` is not a literal tuple
  // — a literal one already spliced to a `Sequence` when the operand
  // canonicalized above) makes the final positional operands unknown until
  // evaluation, and every canonical handler assumes them (arity checks,
  // sorting, folding). Skip the handler and validation: the evaluate path
  // (step 0 of `_computeValue`) splices the tuple and rebuilds through
  // `ce.function`, which re-runs both on the real arguments.
  if (xs.some((x) => x.operator === 'Spread'))
    return new BoxedFunction(ce, name, xs, {
      metadata,
      canonical: true,
      scope,
    });

  // In set theory `|S|` is the number of elements of the set `S`, and `|w|`
  // is the length of the string `w`. The LaTeX parser reads every `|…|` as
  // `Abs`, so the library `Abs` of an operand whose type is a set or a string
  // is `Count` of it: `Abs(Set(1, 2))` is `Count(Set(1, 2))`, which evaluates
  // to 2. The rewrite is done here, when the expression is boxed, so the
  // LaTeX, MathJSON and `ce.function()` routes give the same expression. An
  // operand that is a list or a tuple keeps `Abs` (the absolute value of
  // each element, or the norm of a point). A definition of `Abs` that
  // replaces the library one is not affected.
  if (
    name === 'Abs' &&
    xs.length === 1 &&
    isCardinalityOperand(xs[0]) &&
    !shadowsLibraryName(ce, name)
  )
    return ce.function('Count', xs, { metadata, scope });

  //
  // 3/ Apply `canonical` handler
  //
  // If present, the canonical handler is responsible for
  //  - validating the signature (domain and number of arguments)
  //  - sorting them
  //  - applying involution and idempotent to the expression
  //  - flatenning sequences
  //
  // The arguments have been put in canonical form
  //
  // A bare `N` or `D` at an operand whose parameter takes any value is a
  // variable (`devolveAtValuePositions`): `(N, 1)`, `Max(N, 2)`. A parameter
  // of a user function counts only when it is annotated
  // (`isAnnotatedValueParameter`): `g(N)` with `g = (f) ↦ f(2)` keeps the
  // library `N`, as `Apply((f) ↦ f(2), N)` does.
  {
    const userFunction =
      opDef.isUserFunctionDefinition || opDef.inferredSignature;
    const devolved = devolveAtValuePositions(
      ce,
      name,
      opDef.signature.type,
      xs,
      userFunction ? isAnnotatedValueParameter : undefined
    );
    if (devolved !== undefined) xs.splice(0, xs.length, ...devolved);
  }

  // The boxed default operands of the parameters of the operator, or
  // `undefined` when its signature has no default value.
  const defaults = parameterDefaultOperands(ce, opDef);

  if (opDef.canonical) {
    // A parameter with a default value that the call leaves out receives its
    // default operand before the handler runs, so the handler sees every
    // operand (see `withHandlerDefaults`). A `Spread` operand returned
    // above, so the number of positions is known here.
    if (defaults !== undefined) {
      const filled = withHandlerDefaults(xs, opDef.signature.type, defaults);
      if (filled !== xs) xs.splice(0, xs.length, ...filled);
    }
    let failure: { error: unknown } | undefined;
    try {
      const handlerResult = opDef.canonical(xs, { engine: ce, scope });
      if (handlerResult) {
        const result = withOwnHead(
          ce,
          name,
          'canonical',
          opDef.canonical,
          handlerResult,
          () => xs
        );
        // In strict mode, validate the operands against the operator's
        // declared signature *after* the canonical handler runs — the
        // boxing validation seam of a canonical-handler head. A custom
        // canonical handler used to be the sole gate on argument validity,
        // and most only check arity, so an ill-typed call (`Sin("hello")`,
        // `Factorial("x")`, `PoissonDistribution("a")`) slipped through as
        // `isValid`, a fresh symbol handed to such a head inferred nothing
        // from the declared parameter, and a symbol whose held value lies
        // outside a ranged parameter (`PoissonDistribution(s)` with
        // `s := -3` against `real<0<..>`) was admitted where the same
        // argument to a head WITHOUT a canonical handler is refused.
        //
        // The seam is gated on all of:
        //  - the handler returned an expression with the *same* operator (a
        //    handler that rewrote the head — `Rational`→`Divide`,
        //    `Sqrt`→`Power` — or folded to a number made its own decision);
        //  - that result is still valid (don't second-guess a handler that
        //    already flagged an argument — its own error, such as a
        //    distribution constructor's `out-of-range`, stands);
        //  - the signature is not inferred (an inferred signature carries no
        //    constraints; inference narrows it later).
        //
        // It is the same `validateArguments` call the non-handler path
        // below makes, with the same options — threadable slots, absence
        // stripping, the NaN policy, the overload resolution attached to the
        // call — so a canonical-handler head admits exactly what a plain
        // head with the same signature admits. A handler that accepts more
        // than its declared signature therefore needs the signature widened
        // to say so, which is the seam's purpose: the declaration is the
        // contract the caller can read.
        const sameHeadValid =
          ce.strict &&
          !opDef.inferredSignature &&
          isFunction(result, name) &&
          result.isValid;
        const numericParams =
          sameHeadValid && allParamsNumeric(ce, opDef.signature.type);
        if (
          sameHeadValid &&
          !triviallyAdmittedCall(ce, opDef.signature.type, result.ops)
        ) {
          // The validation runs in CHECK-ONLY mode: every verdict, repair
          // and substitution of the plain path — an unapplied operator
          // symbol devolved to a variable, a fresh matrix inference, a
          // string literal narrowed to a character — but none of its
          // inference on a valueless symbol. The head's own handler has
          // typed what it types (`Sin(x)` gives `x` the `number` of its
          // numeric check, never the declared `complex`), and the seam is a
          // gate on the declaration, not a second source of types.
          const seamResolution: { resolution?: OverloadResolution } = {};
          const checked = validateArguments(
            ce,
            result.ops,
            opDef.signature.type,
            opDef.lazy,
            threadableGate(opDef.signature.type, opDef.broadcastable === true),
            ce._inferenceTxDepth > 0
              ? (ce._freshlyInferred ?? EMPTY_FRESHLY_INFERRED)
              : undefined,
            (i) => opDef.stripsMissingAt(i),
            {
              resolutionOut: seamResolution,
              operatorName: name,
              operatorDefinition: opDef,
              nanPolicyAt: (i) => opDef.resolvedNanBehaviorAt(i),
              refusesAbsentAt: (i) => opDef.refusesAbsentOperandAt(i),
              noInference: true,
              // A `broadcastable: true` library operator refuses a provably
              // non-numeric collection at boxing (see the plain route below
              // for the user-function exception).
              checkNumericCollections:
                opDef.broadcastable === true && !opDef.isUserFunctionDefinition,
            }
          );
          if (checked && checked.some((x) => !x.isValid)) {
            const fn = new BoxedFunction(ce, name, checked, {
              metadata,
              canonical: true,
              scope,
            });
            fn._resolvedOverload = seamResolution.resolution;
            return fn;
          }
          // A substituted operand (a devolved symbol, a narrowed literal)
          // replaces the handler's, position for position, as on the plain
          // path; an unchanged operand list keeps the handler's node. The
          // overload resolution is not attached either way: the call's
          // typing stays exactly what the handler built.
          if (checked && checked.some((x, i) => x !== result.ops[i]))
            return new BoxedFunction(ce, name, checked, {
              metadata,
              canonical: true,
              scope,
            });
        }
        // Preserve the numeric context the former `checkNumericArgs()`
        // fallback inferred onto fresh operands, without repeating its type
        // validation. Collection element validation now belongs to the
        // threadable admission inside `validateArguments()` itself.
        if (numericParams) inferNumericArgs(ce, result.ops);
        // A parameter that is a type variable with a numeric bound is not
        // "numeric" to `allParamsNumeric`, yet the handler-less path narrows
        // a valueless operand to that bound: do the same here.
        else if (sameHeadValid)
          inferGenericBoundArgs(ce, opDef.signature.type, result.ops);
        return withSourceOffsets(result, metadata);
      }
    } catch (e) {
      if (mustPropagate(e)) throw e;
      // Multi-arg form — see the lazy-path catch above.
      console.error(
        `ComputeEngine: error canonicalizing \`${name}\`:`,
        canonicalErrorDetail(e)
      );
      failure = { error: e };
    }

    // The canonical handler gave up, return a non-canonical expression
    const result = new BoxedFunction(ce, name, xs, {
      metadata,
      canonical: false,
    });
    // See the lazy-path catch above.
    if (failure !== undefined) recordCanonicalFailure(result, failure.error);

    return result;
  }

  //
  // Flatten any sequence
  // f(a, Sequence(b, c), Sequence(), d) -> f(a, b, c, d)
  //
  // For an associative operator, also splice an operand that is a call of
  // the same definition: f(a, f(b, c)) -> f(a, b, c). A call of another
  // definition with the same name (a user function `f` made in a scope that
  // is now popped) is a value, and is kept.
  let args: ReadonlyArray<Expression> = flatten(
    xs,
    opDef.associative
      ? {
          operator: name,
          operatorDefinition: opDef,
          valueDefinition: undefined,
        }
      : undefined
  );
  // The operands as written, before a default value is inserted. A call of a
  // user function is boxed again from these when the function is assigned
  // again (`BoxedFunction._reboxedForCallee()`), so that the written
  // arguments are matched against the new function, and its defaults are
  // inserted, not the defaults of the old one.
  const writtenArgs = args;
  // A parameter with a default value that the call leaves out receives its
  // default operand, after `flatten` (which splices a `Sequence`) and before
  // the signature check.
  if (defaults !== undefined)
    args = fillParameterDefaults(args, opDef.signature.type, defaults);

  // Skip validation for function literals with inferred signatures.
  // These will be validated during evaluation by the lambda function,
  // which handles currying and partial application. Collection evidence on
  // the callee's parameters still narrows unknown symbol arguments (see
  // `narrowArgsFromInferredSignature`).
  if (opDef.inferredSignature) {
    // As in the lazy path above: an inferred signature is a guess, so wait on
    // a redefinition of `name` that could supersede it with real evidence.
    if (isProvisionalCaptureOpen() && hasNarrowableArg(args))
      noteProvisionalCall(name);
    narrowArgsFromInferredSignature(opDef.signature.type, args);
  }
  // See the value-definition site above: the resolution of an overload-set
  // signature is attached to the constructed call for result typing
  // (`_resolvedOverload`, phase 2c).
  const resolutionOut: { resolution?: OverloadResolution } = {};
  // The operands before the check, which can replace an operand.
  if (checkedOut !== undefined) {
    checkedOut.ops = writtenArgs;
    // The operands after the defaults were inserted, when the call received
    // a default.
    if (args !== writtenArgs) checkedOut.filled = args;
  }
  // A partly annotated literal validates its bare slots as `any`
  // (`OperatorDefinition._validationSignature`). The inferred types of those
  // slots still narrow an untyped symbol argument, as they do for a literal
  // with no annotation above.
  if (opDef._validationSignature !== undefined)
    narrowArgsFromInferredSignature(
      opDef.signature.type,
      args,
      opDef._validationSignature
    );
  const adjustedArgs = opDef.inferredSignature
    ? null
    : validateArguments(
        ce,
        args,
        opDef._validationSignature ?? opDef.signature.type,
        opDef.lazy,
        // Declared-`broadcastable<T>` slots are threadable by declaration, per
        // position — see the value-definition site above.
        threadableGate(opDef.signature.type, opDef.broadcastable === true),
        // The repair is enabled whenever a boxing operation is in progress
        // (matching the old always-present snapshot); an empty log means "no
        // fresh inference happened", not "repair disabled".
        ce._inferenceTxDepth > 0
          ? (ce._freshlyInferred ?? EMPTY_FRESHLY_INFERRED)
          : undefined,
        // Strip-before-validate (§3.B): a `propagate`/`handle` operator admits
        // an absent (`Missing`) or possibly-absent (`T | missing`) operand in a
        // stripped position; the runtime gate carries the absence. A function
        // literal with annotated parameters admits it too: its application
        // checks the VALUE against the annotation when the call runs
        // (`enforcesParameterAnnotations`).
        (i) => opDef.stripsMissingAt(i) || opDef.enforcesParameterAnnotations,
        {
          resolutionOut,
          operatorName: name,
          operatorDefinition: opDef,
          // An absent argument at an annotated parameter of a function
          // literal is refused (`refusesAbsentArgument`, `validate.ts`).
          enforcesParameterAnnotations: opDef.enforcesParameterAnnotations,
          // Contract B NaN admission (`docs/ERROR-MODEL.md` §4): the policy
          // is tested ahead of carrier disjointness — see
          // `nanPolicyAdmitsParam` in `validate.ts`.
          nanPolicyAt: (i) => opDef.resolvedNanBehaviorAt(i),
          refusesAbsentAt: (i) => opDef.refusesAbsentOperandAt(i),
          // A `broadcastable: true` LIBRARY operator — an elementwise head
          // such as `Abs`, `Sin`, `Ln` — refuses a provably non-numeric
          // collection at a threadable numeric slot at boxing
          // (`Abs(["a", "b"])`), as the numeric fast path and the
          // canonical-handler seam do. A user function promoted to an
          // operator definition (an assigned lambda, a multi-clause
          // function) is `broadcastable` too — the vectorization default
          // sets the flag — but its broadcast runs per element at
          // evaluation, and each failing cell reports its own error with a
          // broadcast frame, so it stays fail-open here
          // (`isUserFunctionDefinition`).
          checkNumericCollections:
            opDef.broadcastable === true && !opDef.isUserFunctionDefinition,
          // A user function maps over a list of points at a parameter
          // declared as a point (`isPointListArgumentType`).
          mapsPointLists: opDef.isUserFunctionDefinition,
          // A user function accepts `NaN` at its numeric parameters
          // (`acceptsNaNArgument`, `validate.ts`).
          userFunction: opDef.isUserFunctionDefinition,
        }
      );

  if (adjustedArgs) {
    // If any adjusted argument is invalid, the arguments did not match the
    // parameters of the signature. We're done.
    if (adjustedArgs.some((x) => !x.isValid)) {
      const fn = new BoxedFunction(ce, name, adjustedArgs, {
        metadata,
        canonical: true,
        scope,
      });
      fn._resolvedOverload = resolutionOut.resolution;
      // A later assignment can replace a user function. Keep the operands,
      // so that the call is checked again against the new definition
      // (`BoxedFunction._recheckedCall()`).
      if (opDef.isUserFunctionDefinition) fn._refusedOps = writtenArgs;
      return fn;
    }
    // All valid: an operand was substituted (devolved to an unknown symbol,
    // or repaired by matrix inference). Continue canonicalization with the
    // substituted operands.
    args = adjustedArgs;
  }

  //
  // 4/ Apply `idempotent` and `involution`
  //
  // The inner call must be bound to the same definition, not only have the
  // same name: the qualified call `std::Not(…)` is evaluated by building the
  // library `Not` from the values of its arguments, and a value can still be
  // a call of a user function named `Not`. `Not_library(Not_user(p))` is not
  // `p`.
  if (
    args.length === 1 &&
    args[0].operator === name &&
    args[0].operatorDefinition === opDef
  ) {
    // f(f(x)) -> x
    //
    // `Not` reads an absent operand as `False`, so `Not(Not(Missing))` is
    // `Not(True)`, which is `False`, not `Missing`. Do not fold `Not(Not(x))`
    // when `x` is an absent symbol or when its type admits `missing`; a
    // present boolean still folds (`docs/ERROR-MODEL.md`, "A comparison is
    // two-valued").
    if (
      opDef.involution &&
      isFunction(args[0]) &&
      !(
        name === 'Not' &&
        (isAbsentSymbol(args[0].op1) ||
          !args[0].op1.type.isDisjointFrom('missing'))
      )
    )
      return args[0].op1;

    // f(f(x)) -> f(x)
    if (opDef.idempotent && isFunction(xs[0])) {
      const fn = new BoxedFunction(ce, name, xs[0].ops, {
        metadata,
        canonical: true,
        scope,
      });
      // The rewrite RETAINS the inner call (same operator, same operands),
      // so the inner call's validated overload resolution is this
      // expression's too — without the transfer, `.type` falls to the
      // prefilter-only cold path and can rank a different arm than the one
      // the inner call validated against.
      if (xs[0] instanceof BoxedFunction)
        fn._resolvedOverload = xs[0]._resolvedOverload;
      return fn;
    }
  }

  //
  // 4b/ Remove the factors 1 of a `Multiply` that has no canonical handler
  //
  // The library `Multiply` has a canonical handler, which removes the
  // factors 1 among its other steps. A host that changes a flag of
  // `Multiply` (`ce.declare('Multiply', { commutative: false },
  // { extend: true })`) loses that handler, and its products are
  // canonicalized here, as a user operator is. The number 1 is the identity
  // of a product whether or not the product commutes, so it is removed here
  // too: `a·1·b` is `a·b`. Removing it does not move any other operand. An
  // inexact 1 (`1.0`) is kept, because it makes the product numeric.
  // User decision 2026-10-20.
  //
  // Only a definition that still multiplies, with the `evaluate` handler of
  // the library `Multiply`, is changed. A host that declares its own
  // `Multiply` with another `evaluate` handler defines another operation,
  // and its operands are kept as written.
  let removedOperands = false;
  if (name === 'Multiply' && keepsLibraryProduct(ce, opDef)) {
    const isExactOne = (x: Expression) =>
      isNumber(x) && x.isExact && x.isSame(1);
    if (args.some(isExactOne)) {
      args = args.filter((x) => !isExactOne(x));
      removedOperands = true;
      if (args.length === 0) return ce.One;
      if (args.length === 1) return args[0];
    }
  }

  //
  // 5/ Sort the operands
  //
  // The attached resolution is index-INSENSITIVE for its consumer: result
  // typing reads `selected`, `selectedInstance` and `undecidedResults` only,
  // none of which is indexed by operand position, so a commutative sort of
  // the operands does not invalidate it. Removing operands (step 4b) can: the
  // overload was chosen for the original number of operands. Then no
  // resolution is attached, and the type is derived from the operands that
  // remain.
  const fn = new BoxedFunction(ce, name, sortOperands(name, args), {
    metadata,
    canonical: true,
    scope,
  });
  if (!removedOperands) fn._resolvedOverload = resolutionOut.resolution;
  return fn;
}

/**
 * True when `opDef`, a definition of `Multiply`, has the `evaluate` handler
 * of the library `Multiply` (the same function object), so it computes a
 * product. The library definition is the one in the system scope, the first
 * scope of the context stack. A `Multiply` from a caller-supplied library
 * (the constructor's `libraries` option) is never the library product.
 */
function keepsLibraryProduct(
  ce: ComputeEngine,
  opDef: { readonly evaluate?: unknown }
): boolean {
  if (ce._customLibraryOperators.has('Multiply')) return false;
  const library = ce.contextStack[0]?.lexicalScope.bindings.get('Multiply');
  const libraryOperator = (library as { operator?: { evaluate?: unknown } })
    ?.operator;
  return (
    libraryOperator?.evaluate !== undefined &&
    opDef.evaluate === libraryOperator.evaluate
  );
}

/**
 * Canonicalize a **binder**: an operator whose `operands` handler gives a
 * `bound` or a `clause` role, read as the binding sites `sites`
 * (`docs/SCOPING-MODEL.md` §1.3). Two phases, because a canonical handler
 * both *needs* the bound variable declared before it canonicalizes the body
 * and *may reshape* the operands.
 *
 * Pre-phase: declare each site's symbol in the operator's own scope, with
 * `noAutoDeclare` set so the free variables of the body and the bounds are
 * promoted to the ENCLOSING scope instead (the prologue `canonicalBigop` and
 * `canonicalLoopLike` each hand-rolled).
 *
 * Post-phase: `bindBindingSites`, below.
 *
 * Two things the pre-phase deliberately does NOT do:
 *
 * - It does not push a scope when there is no site to declare. A bare
 *   `Loop(body)` and a `Series(f)` whose expansion variable the handler
 *   supplies have nothing to bind before the handler runs, and a scope pushed
 *   for them is popped and discarded — swallowing a `Declare` in the body. The
 *   post-phase still runs, and declares a site the handler revealed.
 *
 * - It does not declare a *later* clause's index (see
 *   `BindingSite.clauseLocal`). The whole node is canonicalized by ONE
 *   handler call, so the framework cannot interleave a declaration between two
 *   clauses; the clause walk inside the handler (`canonicalIndexingSet`,
 *   `canonicalLoopLike`) declares each index in this scope just before its own
 *   clause, and the post-phase is the backstop. Only the FIRST clause's index
 *   can be declared up front — nothing is canonicalized ahead of it.
 */
function canonicalizeBinder(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  ops: ReadonlyArray<ExpressionInput>,
  metadata: Metadata | undefined,
  scope: Scope,
  opDef: BoxedOperatorDefinition,
  sites: BindingSiteSelector
): Expression {
  // The selector reads the operands, so they must be boxed before the handler
  // runs. Raw (unbound) boxing is what a lazy operator does anyway, and the
  // result is handed on so it is done once.
  const xs = boxRawOperands(ce, ops);

  const preSites = sites(xs, 'pre');

  let result: Expression;
  if (preSites.length === 0) {
    // Nothing to declare: canonicalize in the ambient scope rather than in a
    // frame that is pushed, never populated, and discarded.
    result = applyOperatorDefinition(ce, name, ops, metadata, scope, opDef, xs);
  } else {
    const wasNoAutoDeclare = scope.noAutoDeclare;
    scope.noAutoDeclare = true;
    ce.pushScope(scope);
    try {
      // A clause-local site is visible only from its own operand onward, and
      // the handler canonicalizes the operands in one call: all the pre-phase
      // can declare is the first clause's index.
      //
      // A lazy operator without a `canonical` handler canonicalizes none of
      // its clauses: the engine canonicalizes only its `statement` operands
      // (`applyOperatorDefinition()`), and a statement before the first
      // clause is the body, which sees every index. When every statement
      // operand is before the first clause, every index is declared here:
      // an assignment of the index of a later clause in the body
      // (`MyLoop(Assign(y, 5), Limits(k, 1, 3), Limits(y, 1, 3))`) writes
      // that index, and is not an assignment to an undeclared name. A statement
      // after a clause must not see the index of a later clause, so then
      // only the first clause's index is declared, as for a handler.
      let everyClause = false;
      if (opDef.lazy && opDef.canonical === undefined) {
        const clauseAt = Math.min(
          ...preSites.filter((s) => s.clauseLocal).map((s) => s.path[0])
        );
        const roles = opDef.operandRoles(xs);
        everyClause =
          roles !== undefined &&
          roles.every((role, i) => role !== 'statement' || i < clauseAt);
      }
      let firstClause: number | undefined;
      for (const site of preSites) {
        if (site.clauseLocal && !everyClause) {
          firstClause ??= site.path[0];
          if (site.path[0] !== firstClause) continue;
        }
        const sym = symbolAtSite(xs, site.path);
        if (sym === undefined) continue;
        // An explicit `ce.declare()` is not affected by `noAutoDeclare`: it
        // always lands in the target (this operator's) scope.
        // A site WITHOUT a declared type gets an INFERRED `unknown` binding,
        // not a declared one. A binder's canonical handler then narrows the
        // index to whatever the iterated collection's element type claims
        // (`canonicalLoopLike` in `library/control-structures.ts` does this
        // for `Loop`/`Comprehension`) — a GUESS, which an element whose
        // actual value falls outside the claimed element type must be able to
        // widen at the per-iteration `ce.assign(index, value)` rather than be
        // rejected by it as `incompatible-type` (`assignFn`,
        // `engine-declarations.ts`, which widens on the inferred track and
        // enforces on the declared one). `BoxedSymbol._infer()` also marks the
        // types it writes inferred, so this is belt-and-braces; declaring the
        // provenance HERE keeps the binding honest even before any inference
        // runs, for the readers of `inferredType` that ask whether a type was
        // declared. A site that DOES declare a type states a real contract
        // and stays on the declared track.
        if (!scope.bindings.has(sym.symbol))
          ce.declare(sym.symbol, {
            type: site.type ?? 'unknown',
            inferred: site.type === undefined,
          });
      }
      // Record every name this binder declares — the later clauses' too,
      // whichever phase declares them — so a `Declare` statement in the
      // binder's direct body that re-declares one of them is refused
      // (`canonicalBlock`, `library/control-structures.ts`).
      const binderNames = new Set(scope.binderNames ?? []);
      for (const site of preSites) {
        const sym = symbolAtSite(xs, site.path);
        if (sym !== undefined) binderNames.add(sym.symbol);
      }
      if (binderNames.size > 0) scope.binderNames = binderNames;
      result = applyOperatorDefinition(
        ce,
        name,
        ops,
        metadata,
        scope,
        opDef,
        xs
      );
    } finally {
      // A DORMANT pop: the canonical expression keeps this scope as its
      // `localScope` and pushes it again on every evaluation, so it is not
      // dying and must not be tombstoned by the debug invariant.
      beginDormantPop();
      try {
        ce.popScope();
      } finally {
        endDormantPop();
      }
      scope.noAutoDeclare = wasNoAutoDeclare;
    }
  }

  return bindBindingSites(ce, name, result, metadata, scope, sites);
}

/**
 * The post-phase of the binder hook: make every occurrence of a bound variable
 * denote THIS node's binding.
 *
 * Step 5 — the binding site itself. What arrives there differs by route: the
 * parse route leaves it RAW (a symbol with no definition — `box.ts` boxes a
 * lazy operator's operands with `form: 'raw'`), while `ce.function('Series',
 * [f, ce.symbol('x')])` hands over a symbol carrying the CALLER's binding.
 * Both are discarded, and only at the binding site.
 *
 * Step 6 — the same names elsewhere in the node, through the shared
 * `rebindToBindings` walk (`binders.ts`), which a `Function` literal's
 * parameter repair also runs: canonicalizing an already-canonical body is a
 * no-op, so a body canonicalized before this node's scope existed keeps the
 * earlier bindings. See that function for the raw-occurrence rule and the
 * rest of the contract.
 *
 * Step 6 is CLAUSE-ORDERED: a `BindingSite.clauseLocal` site's name is
 * rewritten only in its own clause and the ones after it (and in the operands
 * before the first clause — the body, which is inside every clause). An
 * earlier clause's collection referencing the name legitimately denotes the
 * ENCLOSING binding — `Comprehension(…, Element(i, [j, j+1]), Element(j, …))`
 * draws `i` from the ambient `j`.
 */
function bindBindingSites(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  result: Expression,
  metadata: Metadata | undefined,
  scope: Scope,
  sites: BindingSiteSelector
): Expression {
  // A handler that rewrote the head (`canonicalBigop` returns a `Reduce` for a
  // collection body) or gave up made its own decision: the paths no longer
  // describe this expression.
  if (!isFunction(result, name) || !result.isCanonical) return result;

  const found = sites(result.ops, 'post');
  if (found.length === 0) return result;

  // Step 5: the site denotes this node's binding.
  let ops: ReadonlyArray<Expression> = result.ops;
  const bound = new Map<string, Expression>();
  // The operand index a bound name becomes visible at (0 = the whole node),
  // and the index of the first clause — every operand before it (the body)
  // sees all the bindings.
  const visibleFrom = new Map<string, number>();
  let firstClause = Number.POSITIVE_INFINITY;
  for (const site of found) {
    const sym = symbolAtSite(ops, site.path);
    if (sym === undefined) continue;
    const id = sym.symbol;
    const from = site.clauseLocal ? site.path[0] : 0;
    if (site.clauseLocal) firstClause = Math.min(firstClause, site.path[0]);
    visibleFrom.set(id, Math.min(visibleFrom.get(id) ?? from, from));
    let binding = bound.get(id);
    if (binding === undefined) {
      // The 'post' phase is the authoritative one: a handler that reshapes
      // its operands (or supplies a default variable) can reveal a site the
      // 'pre' phase could not see, and that site still gets its binding here.
      // As in the 'pre' phase above: a site without a declared type gets an
      // INFERRED binding, so the narrowing a binder's canonical handler
      // applies (from the iterated collection's claimed element type) stays a
      // revisable guess rather than a contract the per-iteration assignment
      // must satisfy.
      if (!scope.bindings.has(id))
        ce._inScope(scope, () =>
          ce.declare(id, {
            type: site.type ?? 'unknown',
            inferred: site.type === undefined,
          })
        );
      // From the scope's OWN binding, not by name: `ce.symbol()` resolves a
      // constant-named variable (`D(f, Pi)`) to the interned constant rather
      // than to the binding this node just declared for it.
      binding = ce._bindingSymbol(id, scope);
      if (binding === undefined) continue;
      // The binding is this node's VARIABLE, not an ordinary declaration.
      // Symbol-value resolution walks past a binder's variable when the
      // occurrence it is reading denotes something else — a global a stored
      // value refers to (ruled 2026-09-21) — and the mark is how it
      // recognizes one without holding the scope (`markBinderVariable`,
      // `binders.ts`).
      markBinderVariable(scope, id);
      bound.set(id, binding);
    }
    if (sym.valueDefinition === binding.valueDefinition) continue;
    ops = replaceAtSite(ops, site.path, binding);
  }
  if (bound.size === 0) return result;

  // Step 6: same-named occurrences in the node's other operands.
  //
  // The node must also END UP carrying the scope: `boundVariableNames` reads
  // `localScope.bindings`, and that is the only channel `same()`,
  // `rebindEscaping` and the rewrite walks have for learning what a node binds.
  // A handler that builds its result with a bare `ce._fn(…)` does not attach
  // it, so a rebuild is needed even when no operand moved.
  let changed = ops !== result.ops || result.localScope !== scope;
  const next = ops.map((op, m) => {
    // An operand before the first clause is the body: it is inside every
    // clause, so it sees every binding.
    const limit = m < firstClause ? Number.POSITIVE_INFINITY : m;
    const accept = (name: string) => (visibleFrom.get(name) ?? 0) <= limit;
    const own =
      m >= firstClause ? ownIndexClause(name, op, m, visibleFrom) : undefined;
    const rewritten =
      own === undefined
        ? rebindToBindings(op, scope, bound, { accept })
        : withOwnBoundsUnbound(ce, op, own, scope, bound, accept);
    if (rewritten !== op) changed = true;
    return rewritten;
  });
  if (!changed) return result;

  return ce._fn(name, next, { metadata, scope });
}

/**
 * The indexing clause `op` (`Limits` or `Element`) with its index bound to
 * this binder's binding, and its operands outside the scope of the index
 * read in the scope that encloses the binder (`ownIndexClause()`).
 *
 * The bounds of a `Limits` clause and the collection of an `Element` clause
 * are outside the scope of their own index: in `∫₀ᵏ k dk`, `∏_{k=1}^{k} k`
 * and `∑_{k ∈ 1..k} k`, the `k` of the bound or of the collection is the
 * `k` of the enclosing scope (a global, or the index of an enclosing
 * `Sum`), not the integration variable or the index. The clause is
 * canonicalized in the scope of the binder, where the index is already
 * declared, so an occurrence of the index's name in such an operand is bound
 * to the index there. Such an occurrence, and one that is not bound yet, is
 * bound here to the symbol of the enclosing scope. Before, with `k := 2`,
 * `∫₀ᵏ k dk` was `k²/2` and `∏_{k=1}^{k} k` was `k!`, where `∫₀ᵏ t dt` is
 * `2`. An occurrence with another binding (a `Function` parameter of the
 * bound) keeps it. The indexes of the earlier clauses stay visible in these
 * operands, as `accept` states, and the condition of an `Element` clause
 * reads the index.
 */
function withOwnBoundsUnbound(
  ce: ComputeEngine,
  op: Expression,
  own: OwnIndexClause,
  scope: Scope,
  bound: ReadonlyMap<string, Expression>,
  accept: (name: string) => boolean
): Expression {
  if (!isFunction(op)) return op;
  const name = own.name;
  const binding = bound.get(name)?.valueDefinition;
  let enclosing: Expression | undefined;
  const enclosingSymbol = (): Expression => {
    if (enclosing !== undefined) return enclosing;
    // A chain of scopes can end with `undefined` rather than `null`.
    for (let s = scope.parent; s !== null && s !== undefined; s = s.parent) {
      if (!s.bindings.has(name)) continue;
      enclosing = ce._bindingSymbol(name, s);
      if (enclosing !== undefined) return enclosing;
      break;
    }
    enclosing = ce._inScope(scope.parent ?? undefined, () => ce.symbol(name));
    return enclosing;
  };
  let changed = false;
  const ops = op.ops.map((b, j) => {
    if (!own.outside(j)) {
      const rebound = rebindToBindings(b, scope, bound, { accept });
      if (rebound !== b) changed = true;
      return rebound;
    }
    const rebound = rebindToBindings(b, scope, bound, {
      accept: (n) => n !== name && accept(n),
    });
    const result = rewriteWithBinders(rebound, (s, shadowed) => {
      if (s.symbol !== name || shadowed?.has(name)) return s;
      const def = s.valueDefinition;
      if (def !== undefined && def !== binding) return s;
      return enclosingSymbol();
    });
    if (result !== b) changed = true;
    return result;
  });
  if (!changed) return op;
  return ce._fn(op.operator, ops);
}

function makeNumericFunction(
  ce: ComputeEngine,
  name: MathJsonSymbol,
  semiOps: ReadonlyArray<ExpressionInput>,
  metadata?: Metadata,
  scope?: Scope
): Expression | null {
  // The canonical form of these operators is computed by name, without a
  // lookup of their definition (`canonicalNumericOperator`).
  if (!NUMERIC_CANONICAL_NAMES.has(name)) return null;
  // A user definition of one of these names shadows the library operator,
  // so the call must reach the generic route, which looks the definition up.
  // The by-name route folds (`Square(3)` → `9`), and it silently ignored
  // `function Square(x) { x + 100 }` (user decision 2026-09-27: a
  // capitalized library name is shadowed like any other). A consequence:
  // shadowing `Add` also changes `+`, which builds an `Add`.
  //
  // Exception: a definition that holds the library `canonical` handler of
  // this operator is the library definition or a copy of it (`ce.declare(
  // 'Sqrt', { ...ce.lookupDefinition('Sqrt').operator, evaluate })`). Its
  // canonical form is the library one, so the by-name route applies. This
  // gives a copy that changes no field the same results as the library
  // operator (user decision 2026-10-01).
  if (shadowsLibraryName(ce, name) && !keepsNumericCanonicalForm(ce, name))
    return null;
  // The factors of a nested product are spliced before they are sorted, so
  // that the outer product orders all its factors at once (see
  // `canonicalProductOperands()`).
  const productOps =
    name === 'Multiply'
      ? canonicalProductOperands(ce, semiOps, scope)
      : undefined;
  const result = canonicalNumericOperator(
    ce,
    name,
    productOps ?? semiCanonical(ce, semiOps, scope),
    metadata
  );
  return result === null ? null : withSourceOffsets(result, metadata);
}

/**
 * True when the definition `name` resolves to holds the library `canonical`
 * handler of `name` (`numeric-canonical-registry.ts`), that is, when it is a
 * copy of the library definition of an arithmetic operator.
 *
 * A function parameter named like the operator is not such a copy, even
 * though the lookup can still find the library definition while the body is
 * boxed (see `shadowsLibraryName`).
 */
function keepsNumericCanonicalForm(ce: ComputeEngine, name: string): boolean {
  if (ce._isShadowedParameter(name)) return false;
  const def = ce.lookupDefinition(name);
  return (
    def !== undefined &&
    isOperatorDef(def) &&
    numericCanonicalHandlerName(def.operator.canonical) === name
  );
}

function fromNumericValue(ce: ComputeEngine, value: NumericValue): Expression {
  // Only an exact value can be one of the shared exact constants or be
  // converted to an exact value: a float `1.0` or `2.0` stays a float, as
  // `ce.number()` keeps it.
  if (value.isExact) {
    if (value.isZero) return ce.Zero;
    if (value.isOne) return ce.One;
    if (value.isNegativeOne) return ce.NegativeOne;
  }
  if (value.isNaN) return ce.NaN;
  if (value.isNegativeInfinity) return ce.NegativeInfinity;
  if (value.isPositiveInfinity) return ce.PositiveInfinity;

  if (value.isExact) value = value.asExact ?? value;

  // An exact complex value is best represented as a number literal directly:
  // decomposing it into `re + im·i` terms would only re-fold to the same
  // literal (via canonicalAdd), and the machine-complex imaginary emission
  // below would degrade it to an inexact float.
  if (value.isComplex && value instanceof ExactNumericValue)
    return ce.number(value);

  // An inexact value is boxed as it is. A float with an integer value (`2.0`)
  // stays a float, and a complex value keeps both parts at the precision it
  // holds them (a big-decimal imaginary part such as `10^{-800}` is not
  // rebuilt through the double constructor `ce.complex()`, which would round
  // it to `0`).
  if (!value.isExact) return ce.number(value);

  const terms: Expression[] = [];

  //
  // Real Part
  //
  const exactValue = value as ExactNumericValue;
  if (exactValue.sign !== 0) {
    // The real part is the product of a rational and radical

    if (exactValue.radical === 1) {
      // No radical, just a rational part
      terms.push(ce.number(exactValue.rational));
    } else {
      const rational = exactValue.rational;
      // At least a radical, maybe a rational as well.
      const radical = ce.function('Sqrt', [ce.number(exactValue.radical)]);
      if (isOne(rational)) terms.push(radical);
      else {
        const [n, d] = rational;
        if (d === 1) {
          if (n === 1) terms.push(radical);
          else terms.push(ce.function('Multiply', [ce.number(n), radical]));
        } else {
          if (n === 1)
            terms.push(ce.function('Divide', [radical, ce.number(d)]));
          else
            terms.push(
              ce.function('Divide', [
                ce.function('Multiply', [ce.number(n), radical]),
                ce.number(d),
              ])
            );
        }
      }
    }
  }

  let result: Expression;

  if (!value.isComplex) {
    if (terms.length === 0) return ce.Zero;
    result = terms.length === 1 ? terms[0] : canonicalMultiply(ce, terms);
    return result;
  }

  //
  // Imaginary Part
  //
  const imaginary = ce.number(
    ce._numericValue({ re: 0, im: value.bignumIm ?? value.im })
  );
  if (terms.length === 0) return imaginary;

  result = terms.length === 1 ? terms[0] : canonicalMultiply(ce, terms);
  return canonicalAdd(ce, [result, imaginary]);
}

export function semiCanonical(
  ce: ComputeEngine,
  xs: ReadonlyArray<ExpressionInput>,
  scope?: Scope
): ReadonlyArray<Expression> {
  // Avoid memory allocation if possible
  if (xs.every((x) => x instanceof _BoxedExpression && x.isCanonical))
    return xs as ReadonlyArray<Expression>;

  return xs.map((x) => ce.expr(x, { scope }));
}
