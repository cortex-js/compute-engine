import { isRestriction, mayHoldRestriction } from './conditional-value.js';
import {
  broadcastCellTypeOf,
  couldBeUnkeyedCollectionOperand,
  isFiniteIndexedCollection,
  isPointListArgumentType,
  isPointTensorArgumentType,
  isEmptyListArgumentType,
  listMixesPointsAndLists,
  pointArgumentMayMixDepths,
  isPointParameterType,
  isTupleWithListCoordinate,
  typeCouldBeCollection,
  typeCouldBeNumericCollection,
  typeCouldBeNumericTuple,
  typeIsProvablyNonNumericCollection,
  pointArity,
} from '../collection-utils.js';

import {
  COLLECTION_SHAPE_TYPE,
  INDEXED_COLLECTION_SHAPE_TYPE,
} from '../../common/type/primitive.js';
import { flatten, flattenHoldingBarriers } from './flatten.js';
import {
  functionLiteralBody,
  functionLiteralDeclaredSignature,
  functionLiteralParameterType,
  isFunctionLiteralParameter,
  optionalParameterTarget,
  restParameterSignatureTail,
  signatureArgumentsOfSlots,
} from './function-literal.js';
import {
  couldMatchNonEmpty,
  isSubtype,
  nonEmptyQuestionArms,
  provablyAdmits,
  provablyDisjoint,
  resolveTypeReference,
  widenAll,
} from '../../common/type/subtype.js';
import { callbackArityError } from './callback-arity.js';
import { callbackIncompatibility } from '../../common/type/compatibility.js';
import { broadcastAdmitsCollectionElement } from './callback-broadcast-admission.js';
import {
  admissionOf,
  concreteValueOf,
  hasValueComponent,
} from './value-membership.js';
import {
  broadcastableBaseMatches,
  collectionElementType,
  narrowingPreservesEffects,
  overlapsForDeferredValidation,
  resolveTypeAlias,
  stripMissingFromType,
  stripMissingFromElements,
  typeContainsMissing,
  hasKindArm,
  kindArmNames,
  withoutKindArms,
  withoutKindArmsDeep,
  type KindTypeNames,
  unfoldAliasOnDescent,
  type AliasDescent,
  signatureSlotType,
  staticCollectionDims,
  functionResult,
} from '../../common/type/utils.js';
import { kindTypeNames } from './value-kinds.js';
import {
  admitsThroughCarrier,
  groupOneCallbackType,
  isLibraryKindOperator,
  carrierKindTypeNames,
  groupOneHookOf,
  kindTypeNamesWithHook,
  type GroupOneHook,
} from './kind-admission.js';
import {
  diagnoseNoMatch,
  arityBounds,
  armArityCapable,
  isRepairableOperatorSymbol,
  joinParamAt,
  overloadArms,
  resolveOverload,
  type ArmTrialFn,
  type OverloadResolution,
} from './overload.js';
import {
  isErrorTypedOperand,
  isErrorTypedWithoutErrorValue,
} from './error-typed-operand.js';
import { withErrorFrames } from './error-value.js';
import { parseType } from '../../common/type/parse.js';
import { withoutNothing } from '../../common/type/omission.js';
import { typeToString } from '../../common/type/serialize.js';
import { reduceType, typesOverlap } from '../../common/type/reduce.js';
import {
  absentCellsArePoints,
  cellsArePoints,
  threadedPresentType,
} from './broadcast-lift-type.js';
import {
  freeTypeVariables,
  parameterPositions,
  readTypeVariablesAsBounds,
  substituteTypeVariables,
  type TypeInferenceResult,
} from '../../common/type/instantiate.js';
import {
  instantiatedParam,
  isThreadableAt,
  polytypeArm,
  solveArm,
  type Threadable,
} from './generic-instantiation.js';
import {
  FunctionSignature,
  NamedElement,
  Type,
} from '../../common/type/types.js';
import {
  adoptTopPlaceholderSlots,
  functionLiteralParameterSlots,
} from './effects-inference.js';
import { BoxedType } from '../../common/type/boxed-type.js';
import type {
  Expression,
  IComputeEngine as ComputeEngine,
  Scope,
  BoxedOperatorDefinition,
  BoxedValueDefinition,
  TypeProvenanceEntry,
  ParameterRequirement,
  ParameterRecord,
} from '../global-types.js';
import { recordTypeProvenance } from './type-provenance.js';
import { fuzzyStringMatch } from '../../common/fuzzy-string-match.js';
import { isOperatorDef, isValueDef } from './utils.js';
import { isWildcard } from './pattern-utils.js';
import { isScratchBinding } from '../scratch-scopes.js';
import { isTensorValue } from './tensor-view.js';
import { _BoxedOperatorDefinition } from './boxed-operator-definition.js';
import {
  isSymbol,
  isFunction,
  isNumber,
  isString,
  isAbsentSymbol,
  isNaNPointValue,
  isContinuationOperand,
  containsContinuationOperand,
  hasInferredType,
  isFreeName,
  freeBinding,
  resolvedValueDefinition,
} from './type-guards.js';
import type { UnitEnvironment } from '../binding-unit.js';
import { narrowStringLiteralToCharacter } from './boxed-character.js';
import { smallCount } from './collection-count.js';
import {
  indexReadTupleAtCollectionSlot,
  indexReadTupleExtension,
} from './index-read-tuple.js';

// Parsed once: the type of an indexed collection whose every element is a
// number. Used in `checkNumericArgs` to accept collections for broadcasting on
// the strength of their static element type.
const INDEXED_COLLECTION_OF_NUMBER = parseType('indexed_collection<number>');

// `typeCouldBeNumericCollection` / `typeCouldBeNumericTuple` — the COULD-
// semantics predicates `checkNumericArgs` uses to admit collection/tuple
// operands — are imported from `collection-utils.ts`, where the
// `Add`/`Multiply` type handlers and the invisible-operator gate share the
// SAME predicates. Keeping a private copy here let the two layers diverge:
// an operand admitted by validation but missed by the type handlers
// collapsed to `number` and baked `incompatible-type` (Tycho item 30).

// `couldBeUnkeyedCollectionOperand` moved to `collection-utils.ts` alongside
// the sibling COULD-semantics predicates, so validation, overload resolution
// and result typing share ONE definition — a private copy here would let the
// resolution used for validation admit different arms from the one used for
// result typing.

/**
 * The trial `trial` of an arm of an overloaded operator, run in a trial
 * environment
 * (`EngineBoxingState.withTrial()`), which is thrown away when the trial
 * ends: a requirement that the trial writes on an operand is not kept, and
 * does not refuse the trial of the next arm (rule 13 of
 * `docs/plans/2026-11-09-binding-units-slice-1-spec.md`).
 */
function inTrialEnvironment(ce: ComputeEngine, trial: ArmTrialFn): ArmTrialFn {
  return (declared, instance, solution, ops) =>
    ce._boxingState.withTrial(() => trial(declared, instance, solution, ops));
}

/** True while the trial of an overload arm is in progress: the
 * construction-level repairs assert that they do not run then. */
function inTrial(ce: ComputeEngine): boolean {
  return ce._boxingState.trialEnvironment() !== undefined;
}

/**
 * Exclusion gate for scalar numeric INFERENCE — deliberately WIDER than
 * broadcast admission (`couldBeUnkeyedCollectionOperand`). The hazard the
 * gate prevents is keyedness-independent: `x._infer('real')` on an operand
 * whose inferred result signature is collection-shaped WIDENS the shared
 * definition (Tycho item 121), and a `dictionary<…>`-shaped signature is
 * corrupted by that write exactly as a `vector<2>` one is. So ANY operand
 * that is, or could be, a collection of any kind is excluded from the
 * scalar inference — even though only the unkeyed ones are ever consumed
 * by broadcast.
 */
function excludedFromScalarInference(op: Expression): boolean {
  // A number literal takes no inferred type: its `_infer()` is the one of
  // the base class, which writes nothing and returns `false`. Every caller
  // uses this test only to decide whether to call `_infer()`, so excluding
  // the literal has the same effect as the tests below (which return
  // `false` for it), and does not compute the type of the literal (an
  // enclosure for `√6`). The `couldBeNonReal` scan of the callers still
  // reads its type.
  if (isNumber(op)) return true;
  // A kind value (a residue class) is admitted in a numeric position
  // (`hasKindArm`) but it is not a number: no numeric type is inferred onto
  // it.
  return (
    op.isCollection ||
    typeCouldBeCollection(op.type.type) ||
    hasKindArm(op.type.type, kindTypeNames(op.engine))
  );
}

/**
 * True when the NON-ABSENT cells of a collection type are provably
 * non-numeric: `list<string>` and `list<string | missing>` qualify,
 * `list<number | missing>` and `list<unknown>` do not, and neither does a
 * collection of nothing but absences (`list<missing>`), whose cells are all
 * owned by the operator's propagation policy. The absence arm is stripped
 * first so that it cannot mask a non-numeric carrier: the absence admission
 * (`typeContainsMissing`) is decided on what is left.
 */
export function collectionCellsProvablyNonNumeric(
  t: Type,
  admittedKinds?: KindTypeNames
): boolean {
  let carrier = stripMissingFromType(t);
  // For an operator with the arithmetic of the value kinds (`admittedKinds`,
  // the kind types of the engine) a kind value is a cell like a number
  // (`[c, d] + 1` is a list of classes): the kind arm of the cells does not
  // make them non-numeric.
  if (admittedKinds !== undefined)
    carrier = withoutKindCells(carrier, admittedKinds);
  if (
    typeof carrier !== 'string' &&
    'elements' in carrier &&
    carrier.elements === 'never'
  )
    return false;
  return typeIsProvablyNonNumericCollection(carrier);
}

/**
 * Whether an operand of an operator with the arithmetic of the value kinds
 * is admitted as a kind value: its type is a kind type of `kinds` (an absent
 * arm aside), or a union of kind types with numeric arms only
 * (`integer | residue`), or a collection or a tuple whose cells are such
 * types (`list<residue>`, `list<integer | gf8>`, `tuple<residue, residue>`):
 * a collection operand is broadcast, and each cell is an operand of the
 * operation. A union with an arm that is not a number (`string | residue`)
 * is not: the operand may be a string, and the operator refuses it as it
 * refuses a string.
 */
function admitsResidueClassOperand(t: Type, kinds: KindTypeNames): boolean {
  const carrier = stripMissingFromType(t);
  if (!hasKindArm(carrier, kinds)) return false;
  return isNumericWithoutKinds(withoutKindArmsDeep(carrier, kinds), 0);
}

/** Whether `t`, a type whose kind arms were removed, holds numbers only:
 * `never`, a number type, or a union, a collection or a tuple of such
 * types, an absence arm aside. */
function isNumericWithoutKinds(t: Type, depth: number): boolean {
  const x = stripMissingFromType(t);
  if (x === 'never' || isSubtype(x, 'number')) return true;
  if (typeof x === 'string' || depth > 8) return false;
  if (x.kind === 'union')
    return x.types.every((arm) => isNumericWithoutKinds(arm, depth + 1));
  if (x.kind === 'tuple')
    return x.elements.every((e) => isNumericWithoutKinds(e.type, depth + 1));
  const element = collectionElementType(x);
  return element !== undefined && isNumericWithoutKinds(element, depth + 1);
}

/**
 * True when `checkNumericArgs` refuses every operand of type `t`, read from
 * the type alone: a type derivation from operand descriptors
 * (`deriveApplicationType()`) then types the application `error`, as the
 * boxed application is typed. The branches follow those of
 * `checkNumericArgs` that a type can decide:
 *
 * - `error`, `unknown`, `any` and a number type are admitted;
 * - with `admittedKinds`, a kind value (with numbers only beside it);
 * - a collection whose cells are provably not numbers is refused
 *   (`list<string>`);
 * - a type with an absence arm is refused only when the rest of it is
 *   provably not a number, a numeric collection or a numeric tuple
 *   (`string | missing`);
 * - a type that could be a numeric collection or a numeric tuple is
 *   admitted, and so is a type that overlaps `number`
 *   (`integer | string`, `value`);
 * - every other type is refused (`string`, `boolean`, a function type).
 *
 * The refusals of `checkNumericArgs` that read the operand expression (the
 * elements of a list literal of unknown element type) are not decided here,
 * so this answer is `false` for them.
 */
export function numericOperandTypeRefused(
  t: Type,
  admittedKinds: KindTypeNames | undefined
): boolean {
  if (t === 'error' || t === 'unknown' || t === 'any' || t === 'never')
    return false;
  if (isSubtype(t, 'number')) return false;
  if (
    admittedKinds !== undefined &&
    admitsResidueClassOperand(t, admittedKinds)
  )
    return false;
  if (collectionCellsProvablyNonNumeric(t, admittedKinds)) return true;
  if (typeContainsMissing(t)) {
    const carrier = stripMissingFromType(t);
    return (
      carrier !== 'never' &&
      provablyDisjoint(carrier, 'number') &&
      !typeCouldBeNumericCollection(carrier) &&
      !typeCouldBeNumericTuple(carrier)
    );
  }
  if (typeCouldBeNumericCollection(t) || typeCouldBeNumericTuple(t))
    return false;
  return provablyDisjoint(t, 'number');
}

/**
 * `t` with the kind arms of `kinds` removed from the cells of a collection
 * type (`list<integer | residue>` is `list<integer>`, `list<residue>` is
 * `list<never>`), at the first level of cells; any other type is itself.
 */
function withoutKindCells(t: Type, kinds: KindTypeNames): Type {
  if (typeof t === 'string') return t;
  if (
    t.kind === 'list' ||
    t.kind === 'set' ||
    t.kind === 'collection' ||
    t.kind === 'indexed_collection'
  ) {
    const elements = withoutKindArms(t.elements, kinds);
    return elements === t.elements ? t : { ...t, elements };
  }
  return t;
}

/**
 * Validate the element carrier of an operand admitted through a threadable
 * numeric parameter.
 *
 * Threadability admits a collection where the declared parameter describes
 * one scalar cell. That admission must still reject a collection whose static
 * element type is provably non-numeric (`list<string>` at a `complex` slot):
 * `Ln(["a", "b"])` is an invalid call at boxing, the same as `Ln("a")`, not a
 * valid call that fails in every cell at evaluation. The check runs for a
 * `broadcastable: true` LIBRARY OPERATOR, on the plain boxing path and on the
 * boxing seam of a `canonical`-handler head alike, so every operator route
 * agrees with the numeric fast path (`checkNumericArgs`). A USER FUNCTION
 * does not opt in (`checkNumericCollections`), whether it is a value
 * definition or a lambda promoted to an operator definition
 * (`isUserFunctionDefinition`): its broadcast is performed per element by
 * the lambda machinery at evaluation, and each failing cell reports its own
 * `incompatible-type` with a broadcast frame
 * (`broadcast-error-context.test.ts`), which a whole-collection refusal at
 * boxing would take away.
 *
 * An unknown/weak element type remains fail-open, as elsewhere in argument
 * validation: the evaluate-time numeric gate decides once values are known,
 * and reports a mismatch per cell with its broadcast context.
 *
 * The check tests NUMERICITY, not the declared parameter, by ruling
 * (2026-09-08): a collection whose numeric cells are provably outside the
 * parameter's carrier is admitted here and fails per cell at evaluation.
 * `Sin(zs)` with `zs: list<+oo | -oo>` boxes as valid where the scalar
 * `Sin(+oo)` is refused, and evaluates to `[Error(incompatible-type)]` once
 * `zs` holds `[+oo]`; a tuple of strings passes too, because tuples thread
 * as points and are skipped on purpose. Comparing the element carrier
 * against the parameter would have to re-apply the scalar path's admission
 * rules — the exceptional-point policy (`nanPolicyAt`), ranged parameters,
 * the tuple lift — on the element side, a change to the admission contract
 * that no consumer has asked for while the evaluation-time failure is loud.
 */
function validateThreadableOperand(
  ce: ComputeEngine,
  op: Expression,
  param: Type,
  displayParam?: Type
): Expression {
  // The non-absent cells decide: `list<string | missing>` is refused like
  // `list<string>`. Missing cells themselves are owned by the operator's
  // propagation policy and remain valid broadcast input
  // (`Sin(list<missing>) -> list<number>`, `Sin(list<number | missing>)`).
  // A parameter that names a kind type beside its numbers (`complex |
  // quantity`, the trigonometric heads) is a numeric parameter for this
  // check, and the kinds it names are cells like numbers (`Sin(list<quantity>)`
  // is admitted as `Sin(quantity)` is), so `Sin(list<string>)` is refused
  // as `Sin("a")` is.
  const kinds = kindTypeNames(ce);
  if (
    isSubtype(withoutKindArms(param, kinds), 'number') &&
    collectionCellsProvablyNonNumeric(
      op.type.type,
      new Set(kindArmNames(param, kinds))
    )
  )
    return ce.typeError(displayParam ?? param, op.type, op);
  return op;
}

/**
 * Check an operand admitted through a threadable parameter.
 *
 * An operator that opts in (`checkNumericCollections`) refuses a collection
 * whose cells are provably not numbers (`validateThreadableOperand`). A user
 * function refuses an operand whose type shares no value with the
 * parameter, whole or by its elements (`liftedOperandCannotFit`). Any other
 * operand is admitted as it is.
 */
function checkThreadableOperand(
  ce: ComputeEngine,
  op: Expression,
  param: Type,
  displayParam: Type | undefined,
  internals: ValidateArgumentsInternals | undefined
): Expression {
  if (internals?.checkNumericCollections)
    return validateThreadableOperand(ce, op, param, displayParam);
  if (internals?.userFunction && liftedOperandCannotFit(op, param))
    return ce.typeError(displayParam ?? param, op.type, op);
  return op;
}

/**
 * True when no value of the type of `op` can be an argument of a user
 * function at the threadable parameter `param`: the type shares no value with
 * the parameter, its elements share none, and its cells share none. Each of
 * these is a way for the call to apply: to the whole operand, or mapped over
 * the elements (to each cell for a nested collection).
 *
 * With `g: (integer) -> integer` and `S: list<string>` (no value), `g(S)` is
 * refused when it is boxed, as `g("a")` is. A collection that holds its
 * elements (a literal list, or a symbol that holds one) is not refused here:
 * the application maps over its elements and reports an error for each
 * element that does not fit, with the position of that element.
 */
function liftedOperandCannotFit(op: Expression, param: Type): boolean {
  if (isFiniteIndexedCollection(op)) return false;
  const t = op.type.type;
  if (typesOverlap(t, param)) return false;
  const element = collectionElementType(t);
  if (element === undefined || typesOverlap(element, param)) return false;
  return !typesOverlap(broadcastCellTypeOf(t), param);
}

/**
 * Apply the numeric-context inference performed by `checkNumericArgs()` after
 * validation has already succeeded. This is intentionally validation-free:
 * the canonical-handler seam uses it to preserve the historical `number`
 * inference of a fresh operand without paying for a second type-checking pass.
 */
export function inferNumericArgs(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>
): void {
  ce._withoutFacts(() => {
    // The tier written onto a valueless operand, and onto each cell of an
    // eager collection operand. The requirement is kept in the unit of the
    // expression, and it outlives the types that the operands have now: with
    // `x := 2`, a `real` of `x + 1` would still be read after `x := 1 + i`.
    // The use requires a number, whatever the operands are when it is boxed.
    const inferredType: Type = 'number';
    for (const x of ops)
      if (isFiniteIndexedCollection(x)) {
        // `.each()` on a lazy collection materializes every element, so never
        // walk one merely to perform inference. Eager literals already store
        // their cells and still need the walk: a contained inferred function
        // call may have a result signature to narrow.
        if (x.isLazyCollection) continue;
        // A nested collection is consumed by nested broadcast rather than as
        // a scalar cell; do not push scalar numeric inference into it.
        for (const y of x.each())
          if (!excludedFromScalarInference(y)) y._infer(() => inferredType);
      } else if (!excludedFromScalarInference(x)) {
        // A possibly-collection operand likewise must not have its shared
        // result signature widened with a scalar numeric arm.
        x._infer(() => inferredType);
      }
  });
}

/**
 * Check that the number of arguments is as expected.
 *
 * Converts the arguments to canonical, and flattens the sequence.
 */
/**
 * Post-handler inference for a GENERIC numeric parameter.
 *
 * The boxing seam re-validates the same-head result of a canonical handler
 * with inference switched off, and then runs `inferNumericArgs` only when
 * every parameter is a concrete numeric type (`allParamsNumeric`, `box.ts`).
 * A parameter that is a type VARIABLE with a numeric bound — `(T) -> T where
 * T: number` — is not concrete, so a canonical-handler head with such a
 * signature inferred nothing for a valueless operand: `Conjugate(z)` left
 * `z` `unknown` the moment `Conjugate` gained a handler, where the
 * handler-less path had narrowed `z` to the bound. This is that narrowing:
 * each operand at a slot whose parameter is a type variable bounded by a
 * subtype of `number` is narrowed to the bound, exactly as the handler-less
 * path narrows it (`inferenceTypeAt` in `validateArguments` grounds the
 * variable to its bound). Collection operands narrow their elements, as
 * `inferNumericArgs` does. Fact-blind, since the written type outlives the
 * assumptions in force.
 */
export function inferGenericBoundArgs(
  ce: ComputeEngine,
  signature: Type,
  ops: ReadonlyArray<Expression>
): void {
  if (typeof signature === 'string' || signature.kind !== 'signature') return;
  const bounds = new Map<string, Type>();
  for (const v of signature.typeParams ?? [])
    if (v.bound !== undefined && isSubtype(v.bound, 'number'))
      bounds.set(v.name, v.bound);
  if (bounds.size === 0) return;
  const boundAt = (i: number): Type | undefined => {
    const t = signatureSlotType(signature, i);
    if (t === undefined || typeof t === 'string' || t.kind !== 'variable')
      return undefined;
    return bounds.get(t.name);
  };
  ce._withoutFacts(() => {
    ops.forEach((x, i) => {
      const bound = boundAt(i);
      if (bound === undefined) return;
      if (isFiniteIndexedCollection(x)) {
        if (x.isLazyCollection) return;
        for (const y of x.each())
          if (!excludedFromScalarInference(y)) y._infer(() => bound);
      } else if (!excludedFromScalarInference(x)) {
        x._infer(() => bound);
      }
    });
  });
}

/**
 * Post-handler inference for the COLLECTION operand of a `lazy` operator.
 *
 * A `lazy` operator receives its operands unbound, and its canonical handler
 * builds the result itself (usually with `ce._fn`), so the signature
 * validation that narrows a valueless symbol from the parameter it fills
 * never runs on this route: `validateArguments` skips inference for a lazy
 * operator, and the lazy branch of the boxing does not re-validate the
 * handler's result. A symbol passed as the source of `Filter(xs, p)`,
 * `Map(f, xs)`, `Reduce(xs, f, 0)`, `Any(xs, p)`, … therefore kept the type
 * `unknown`. When that symbol is the parameter of a user function, an
 * `unknown` parameter makes the function map over a list argument element by
 * element, so `h(xs) = Filter(xs, p)` applied to `[1, 2, 3]` gave
 * `[Filter(1, p), Filter(2, p), Filter(3, p)]` instead of the filtered list.
 * The non-lazy siblings (`Find`, `Sort`, `Count`, …) validate in their
 * handler and were typed correctly.
 *
 * This narrows each operand of the handler's result that is a symbol with no
 * value and an `unknown` type, at a slot whose declared parameter type is a
 * collection type, to that parameter type. The type variables of the
 * signature read as their bounds (`unknown` when unbounded), which is the
 * type the non-lazy validation writes for the same slot: `collection<T>`
 * gives `collection<unknown>`, `collection<any>` stays `collection<any>`.
 * Only the operands the handler already canonicalized are read: a callback
 * operand is at a function-typed slot and is never touched, so its own
 * parameters are not bound or evaluated here. A slot that also admits a
 * scalar (`value`, `number | collection<any>`) is not a collection slot and
 * writes nothing. Fact-blind, since the written type outlives the
 * assumptions in force.
 *
 * The inference applies ONLY to the operators of `COLLECTION_SOURCE_OPERATORS`
 * (`isCollectionSourceOperator`), and the caller checks both the operator
 * being boxed and the head of the handler's result. It must not run for every
 * lazy operator: many lazy operators have a collection-typed slot that is not
 * a source. `Subscript` is `(collection<any>, any) -> any`, and its handler
 * keeps `a_{n+1}` as a `Subscript` with an untyped base precisely so that `a`
 * can still be a number; typing `a` a collection from that use made a second
 * parse of `a_{n+1}` an element read (`At(a, n + 1)`). `Matrix`, `Dictionary`
 * and the string-typed slots of `Delimiter` or `ErrorCode` are other such
 * slots (a string is a collection of characters in the type lattice). An
 * operator with an overloaded signature (an intersection of arms) is not
 * narrowed either: another arm may fit the operand.
 */
export function inferCollectionSourceArgs(
  ce: ComputeEngine,
  signature: Type,
  ops: ReadonlyArray<Expression>
): void {
  if (typeof signature === 'string' || signature.kind !== 'signature') return;
  // Most applications hold no candidate: test the operands before the
  // signature is grounded, which allocates.
  if (
    !ops.some(
      (x) =>
        isSymbol(x) && x.value === undefined && isUntypedAtCollectionSlot(x)
    )
  )
    return;
  const grounded = readTypeVariablesAsBounds(signature);
  if (typeof grounded === 'string' || grounded.kind !== 'signature') return;
  ce._withoutFacts(() => {
    ops.forEach((x, i) => {
      if (!isSymbol(x) || x.value !== undefined) return;
      const slot = signatureSlotType(grounded, i);
      // A variable left after grounding is one the signature does not
      // declare: a malformed signature, which writes nothing.
      if (slot === undefined || freeTypeVariables(slot).size > 0) return;
      if (!isSubtype(slot, COLLECTION_SHAPE_TYPE)) return;
      if (!isUntypedAtCollectionSlot(x, slot)) return;
      x._infer(() => slot);
    });
  });
}

/**
 * The lazy operators whose collection operand is a SOURCE: the operator reads
 * the elements of that operand, so an untyped symbol there is a collection.
 * See `inferCollectionSourceArgs` for why the list is explicit.
 */
const COLLECTION_SOURCE_OPERATORS: ReadonlySet<string> = new Set([
  'Map',
  'Filter',
  'Reduce',
  'Fold',
  'Scan',
  'Any',
  'All',
  'TakeWhile',
  'DropWhile',
  'FlatMap',
  'MaxBy',
  'MinBy',
  'ArgMax',
  'ArgMin',
  'Dedup',
  'Differences',
]);

export function isCollectionSourceOperator(name: string): boolean {
  return COLLECTION_SOURCE_OPERATORS.has(name);
}

/**
 * The collection type that operand `i` of an operator with the signature
 * `signature` must have when that operand is a SOURCE collection, or
 * `undefined` when the operand is not at a source slot.
 *
 * The slot is read as `inferCollectionSourceArgs` reads it: the type
 * variables of the signature read as their bounds, and a slot is a source
 * slot when its type is a collection type. The answer is
 * `'indexed_collection'` for a slot that requires positions (`ArgMax`), and
 * `'collection'` otherwise. The caller decides that the operator is one of
 * `COLLECTION_SOURCE_OPERATORS` (`isCollectionSourceOperator`).
 */
export function collectionSourceSlot(
  signature: Type,
  i: number
): 'collection' | 'indexed_collection' | undefined {
  if (typeof signature === 'string' || signature.kind !== 'signature')
    return undefined;
  const grounded = readTypeVariablesAsBounds(signature);
  if (typeof grounded === 'string' || grounded.kind !== 'signature')
    return undefined;
  const slot = signatureSlotType(grounded, i);
  if (slot === undefined || freeTypeVariables(slot).size > 0) return undefined;
  if (!isSubtype(slot, COLLECTION_SHAPE_TYPE)) return undefined;
  return isSubtype(slot, INDEXED_COLLECTION_SHAPE_TYPE)
    ? 'indexed_collection'
    : 'collection';
}

/**
 * True when `expr` is a parameter of a function literal being boxed whose
 * type so far is a number type that only uses of operators that map over a
 * collection gave it (`x + x`). A use that requires a collection
 * (`Length(x)`) then gives it a collection type (`narrowInferredType()`,
 * `boxed-symbol.ts`).
 */
export function isMappedNumberParameter(expr: Expression): boolean {
  if (!isSymbol(expr)) return false;
  const v = expr.valueDefinition;
  if (v === undefined) return false;
  const record = expr.engine._parameterRecord(v);
  const t = expr.type.type;
  return (
    record !== undefined &&
    t !== 'never' &&
    isSubtype(t, 'number') &&
    record.env.scalarUsesMap(v, expr.symbol) === true
  );
}

/**
 * True when `expr` has no type yet where a slot of type `slot` requires a
 * collection: its type is `unknown`, or it is a mapped number parameter
 * (`isMappedNumberParameter()`) and `slot` can hold numbers. The
 * collection operators that narrow an untyped operand themselves use this
 * test, and so does argument validation, before the matrix repair. The
 * narrowing then gives `expr` the requirement of the slot
 * (`narrowInferredType()`): the order of the uses does not decide whether
 * the parameter is a collection (CE-1270).
 */
export function isUntypedAtCollectionSlot(
  expr: Expression,
  slot: Type = 'collection'
): boolean {
  if (expr.type.isUnknown) return true;
  return typeCouldBeNumericCollection(slot) && isMappedNumberParameter(expr);
}

/**
 * Validate the collection operand of a LAZY collection operator's canonical
 * handler. This is like `checkType(engine, op, type)`, but fail-open: an
 * operand whose type is not PROVABLY incompatible (`unknown`/`any`/`value`,
 * or a `broadcastable<T>`) is admitted as it is. The lazy-broadcast
 * machinery needs this: `mod(L, N)` over a declared-`unknown` symbol `L`
 * holding a >100-element `List` builds `Map(…, L)` over the SYMBOL, whose
 * static type is `unknown` even though its value is a collection. Mirrors the
 * free-variable leniency of the signature-validation path in `box.ts` (an
 * operand whose type is provisional may satisfy the parameter at runtime).
 *
 * A refused operand is returned as an error expression. The canonical
 * handler then returns `null`, and the boxing builds the operator over the
 * error (`refusedCollectionSourceOperands`), as for an eager operator:
 * `Dedup(5)` is `Dedup(Error(incompatible-type, collection, 5))`.
 */
export function checkCollectionOperand(
  engine: ComputeEngine,
  arg: Expression | undefined | null,
  type: 'collection' | 'indexed_collection' = 'collection'
): Expression {
  if (arg === undefined || arg === null) return engine.error('missing');
  const x = arg.canonical;
  if (!x.isValid) return x;
  // An ABSENT operand (`Missing`) is admitted: every collection
  // operator propagates absence (`signatureParamsPropagateAbsence`,
  // `boxed-operator-definition.ts`, user decision 2026-09-25), so the
  // evaluation driver answers the marker of the codomain for it (`Missing`
  // for a collection result). Refused here, `Map(f, Missing)` stayed a raw
  // node that no gate could reach, and `Filter(Missing, p)` was an
  // `incompatible-type` error.
  if (isAbsentScalarSymbol(x)) return x;
  const t = x.type.type;
  // An operand typed `unknown`, `any` or `value` is admitted, even when it is
  // a symbol whose current value is not a collection (a declared-`unknown`
  // symbol assigned `5`). A canonical form must not depend on the value
  // assigned to a symbol: the symbol can be reassigned to a collection
  // before the call is evaluated. The evaluation reads the value: a value
  // that cannot be a collection is an `incompatible-type` error there
  // (`heldEagerSources()` in `boxed-function.ts`), so `Any(x)` does not
  // quantify over an empty element stream and answer `False`.
  if (t === 'unknown' || t === 'any' || t === 'value') return x;
  // For the same reason, a symbol whose type was inferred (from its assigned
  // value: a declared-`unknown` symbol assigned `5` is typed `integer`, or
  // from an earlier use) is admitted. The refusal reads declared types only,
  // as the refusal of the boxing does (`refusedCollectionSourceOperands`).
  if (isSymbol(x) && hasInferredType(x)) return x;
  if (typeof t !== 'string' && t.kind === 'broadcastable') return x;
  if (absentTupleSlotsMatchSource(x, type)) return x;
  // An operand that can be absent as a whole is admitted when its other arms
  // are: every collection operator answers `Missing` for an absent source.
  // `missing | list<integer>` is admitted by the overlap deferral in
  // `checkType` (it reads the arms of a union one by one), but that deferral
  // reads no `string` arm, so before, `Dedup(s)`, `Filter(s, p)` and
  // `Map(f, s)` with `s: missing | string` were `incompatible-type` errors.
  if (presentArmsMatch(t, type)) return x;
  // A structural alias, at the top or as an arm of a union, is read as its
  // definition, so that `a: L`, with `L` an alias of
  // `list<integer | missing>`, is admitted as `list<integer | missing>` is.
  // The overlap deferral in `checkType` (`overlapsForDeferredValidation`)
  // reads a reference node as no collection at all, so before, `Dedup(a)`,
  // `ArgMax(a)` and `Map(x ↦ x + 1, a)` were `incompatible-type` errors, and
  // so were they for `b: missing | L`.
  const unfolded = aliasArmsUnfolded(t);
  if (unfolded !== t && overlapsForDeferredValidation(unfolded, type)) return x;
  return checkType(engine, x, type);
}

/**
 * True when `t` is a union with a top-level `missing` arm, and each of its
 * other arms is a subtype of the source slot `type`. A structural alias, at
 * the top or as an arm, is read as its definition.
 */
function presentArmsMatch(t: Type, type: Type): boolean {
  const r = resolveTypeAlias(t);
  if (typeof r === 'string' || r.kind !== 'union') return false;
  const arms = r.types.map((a) => resolveTypeAlias(a));
  const present = arms.filter((a) => a !== 'missing');
  if (present.length === arms.length || present.length === 0) return false;
  // A top-type arm is admitted, as an operand typed `unknown`, `any` or
  // `value` is (above): `missing | unknown` is the type of an index into a
  // `list<unknown>`, and its present value may be a collection.
  return present.every(
    (a) => a === 'unknown' || a === 'any' || a === 'value' || isSubtype(a, type)
  );
}

/**
 * `t` with a structural alias replaced by its definition, at the top and in
 * each arm of a union; `t` itself when there is none. One level only, with
 * no further descent, so a self-referential alias cannot make it loop
 * (`resolveTypeAlias` guards one chain of references).
 */
function aliasArmsUnfolded(t: Type): Type {
  const r = resolveTypeAlias(t);
  if (typeof r === 'string' || r.kind !== 'union') return r;
  const arms = r.types.map((a) => resolveTypeAlias(a));
  return arms.every((a, i) => a === r.types[i])
    ? r
    : { kind: 'union', types: arms };
}

/**
 * True when `op` is a tuple with a slot that may be absent, or may itself be
 * absent, and the same tuple without its absent cases fits the source slot
 * `type` of a lazy collection operator.
 *
 * A lazy collection operator (`Map`, `Filter`, `Any`, `Reduce`, `ArgMax`, …)
 * reads the slots of a tuple source as its elements, as it reads the elements
 * of a list, and an absent element is an ordinary element for it:
 * `list<integer | missing>` is admitted at the `collection` source slot.
 * Without this function, `checkType` read the tuple slot by slot and refused
 * it, because a `missing` slot is not a value: `Map(x ↦ x + 10, t)` with
 * `t: tuple<integer, missing>` was an `incompatible-type` error, while the
 * same call with `l: list<integer | missing>` was typed `list<number>`. The
 * eager operators with the same parameter (`CountIf`, `Find`, `Sort`) already
 * admitted the tuple, because their signature solve binds the element type
 * variable to the widening of the slot types.
 *
 * The test is the one the same tuple with no absent case gets: a slot that
 * holds nothing but `missing` is removed, the `missing` arms of the other
 * slots are removed (`stripMissingFromElements`), and the result is admitted
 * only when it is a SUBTYPE of `type`. So `tuple<integer, missing>` is
 * admitted because `tuple<integer>` is, and `tuple<integer, nothing, missing>`
 * is refused because `tuple<integer, nothing>` is. The overlap deferral
 * (`overlapsForDeferredValidation`) is not applied: it never admits a tuple
 * at a collection parameter (it pairs a tuple only with a tuple), so applying
 * it here would admit, only because a slot can be absent, a type that the
 * same tuple without that slot is refused (`tuple<integer, missing> |
 * boolean` while `tuple<integer, integer> | boolean` is refused).
 *
 * A `missing` arm of the operand itself (`missing | tuple<integer, integer>`)
 * is set aside: every collection operator answers `Missing` for an absent
 * source, and `missing | list<integer>` is admitted at the same slot. The
 * other arms of a union are tested as they are.
 *
 * A tuple whose slots can hold nothing but absent values
 * (`tuple<missing, missing>`) is refused: no slot is left once its absent
 * slots are removed. A `list<missing>` IS admitted at this source today, by
 * the overlap deferral in `checkType`, so `Map(x ↦ x + 10, m)` with
 * `m: list<missing>` is typed `list<number>`. The difference is recorded in
 * ROADMAP.md ("A tuple with an absent slot is refused as the source of a
 * lazy collection operator").
 */
function absentTupleSlotsMatchSource(op: Expression, type: Type): boolean {
  if (!op.type.facts.containsMissing) return false;
  const t = resolveTypeAlias(op.type.type);
  const arms =
    typeof t !== 'string' && t.kind === 'union'
      ? t.types.map((a) => resolveTypeAlias(a))
      : [t];
  const present = arms.filter((a) => a !== 'missing');
  if (!present.some((a) => typeof a !== 'string' && a.kind === 'tuple'))
    return false;
  const read: Type[] = [];
  for (const a of present) {
    if (typeof a === 'string' || a.kind !== 'tuple') {
      read.push(a);
      continue;
    }
    // A slot that can hold `any` is not read here. Whether a tuple with an
    // `any` slot is admitted at a collection parameter is an open user
    // decision (`docs/plans/2026-10-20-bare-tuple-record-any.md`); this
    // function does not change it, so `tuple<any, integer>` stays refused
    // at this slot, and `tuple<any, missing>` is refused with it. The test
    // is `isSubtype`, not equality with `any`, so that a union slot with an
    // `any` arm (`tuple<integer, any | missing>`) is refused too.
    if (a.elements.some((e) => isSubtype('any', e.type))) return false;
    const elements = a.elements.filter(
      (e) => resolveTypeAlias(e.type) !== 'missing'
    );
    if (elements.length === 0) return false;
    read.push({ ...a, elements });
  }
  const view: Type =
    read.length === 1 ? read[0] : { kind: 'union', types: read };
  const stripped = typeContainsMissing(view)
    ? stripMissingFromElements(view)
    : view;
  if (stripped === undefined) return false;
  return isSubtype(stripped, type);
}

/**
 * True when `op`, the first operand of a call to `ArgMax` or `ArgMin`, is
 * a function, so that the call is the optimization form `ArgMax(f, domain)`
 * and not the collection form `ArgMax(xs, key)`. The canonical handler
 * (`canonicalOptimumForm()` in `library/collections.ts`) and the
 * evaluation (`heldEagerSources()` in `boxed-function.ts`) use this same
 * test, so they choose the same form.
 *
 * - A function literal is a function.
 * - A symbol is a function when the current scope defines it as an operator,
 *   or as a value whose DECLARED type is a function type. A type inferred
 *   from an assigned value is not read: `h` declared `unknown` and then
 *   assigned `Sin` can be assigned a list later, and a canonical form must
 *   not depend on the current value. An undeclared symbol or a wildcard is
 *   not a function, and the symbol is not declared by this test.
 * - Any other call is a function when its canonical type is a function type
 *   (`Derivative(Sin)`, a composition). The raw operand of a lazy operator
 *   is typed `unknown`, so the call is canonicalized first. A call has no
 *   name to declare, so this has no side effect.
 */
export function isOptimumFunctionOperand(op: Expression): boolean {
  if (isFunction(op, 'Function')) return true;
  if (isSymbol(op)) {
    if (isWildcard(op)) return false;
    const def = op.engine.lookupDefinition(op.symbol);
    if (def === undefined) return false;
    if (isOperatorDef(def)) return true;
    return (
      isValueDef(def) &&
      def.value.inferredType !== true &&
      def.value.type.matches('function')
    );
  }
  if (!isFunction(op)) return false;
  return op.canonical.type.matches('function');
}

/**
 * Narrow the canonical domain operand `domain` of the optimization form
 * `ArgMax(f, domain)` / `ArgMin(f, domain)` to `collection` when it is a
 * symbol with a definition, no value and an `unknown` type (the parameter
 * `xs` of `xs ↦ 1 + ArgMax(f, xs)`).
 *
 * The domain of the form is a set, and the collection form `ArgMax(xs, key)`
 * reads a list there: either way the operand is a collection, never a
 * scalar. Left `unknown`, the parameter made the function literal map over a
 * list argument element by element (an `unknown` parameter is scalar for
 * that rule, `literalParamsMap()` in `library/core.ts`), so
 * `Apply(xs ↦ 1 + ArgMax(f, xs), [1, 4])` gave one error per element where
 * `1 + ArgMax(f, [1, 4])` gives one error.
 *
 * The narrowing is fact-blind, as the one `inferCollectionSourceArgs` writes
 * for a source slot. The caller (`canonicalOptimumForm()` in
 * `library/collections.ts`) calls it only for a parameter of the function
 * literal whose body is being canonicalized: a global symbol keeps its type
 * (`S` boxed alone, then `ArgMax(f, S)`), and an undeclared domain
 * (`ArgMax(x ↦ x², T)` at the top level) is not declared.
 */
export function inferOptimumDomain(domain: Expression): void {
  if (!isSymbol(domain) || isWildcard(domain)) return;
  if (domain.value !== undefined || !isUntypedAtCollectionSlot(domain)) return;
  domain.engine._withoutFacts(() => domain._infer(() => 'collection'));
}

/**
 * The operands of a call to the lazy collection operator with the signature
 * `signature`, canonicalized, when an operand at a source slot
 * (`collectionSourceSlot`) is refused by `checkCollectionOperand`; or
 * `undefined` when every source operand is admitted.
 *
 * The canonical handler of such an operator returns `null` when it refuses
 * its source, and the boxing kept the call as a non-canonical node: valid,
 * typed `unknown`, and evaluated to itself, so the error was lost
 * (`Map(x => x, 5)`, `Dedup(5)`). The boxing builds the operator over these
 * operands instead: the refused operand is the error, so the call is invalid
 * and typed `error`, as `Sort(5)` is. A call with a spread operand is not
 * checked: the positions of its operands are not known.
 */
export function refusedCollectionSourceOperands(
  ce: ComputeEngine,
  signature: Type,
  xs: ReadonlyArray<Expression>
): Expression[] | undefined {
  if (xs.some((x) => isFunction(x, 'Sequence') || isFunction(x, 'Spread')))
    return undefined;
  let refused = false;
  const ops = xs.map((x, i) => {
    // A symbol with no definition stays undeclared: canonicalizing it, or
    // reading its type, would declare it, and a held `Map(R, f)` must leave
    // `R` as it was.
    if (isSymbol(x) && !ce.lookupDefinition(x.symbol)) return x;
    const operand = x.canonical;
    const kind = collectionSourceSlot(signature, i);
    // A function at a source slot is refused like any other operand that is
    // not a collection, as the eager `Sort(x ↦ x, xs)` is. This covers a
    // collection-first operator with its operands in the wrong order
    // (`Filter(x ↦ x > 0, xs)`) and a callback-first operator with its
    // operands in the wrong order (`Fold(xs, 0, (a, x) ↦ a + x)`). Kept as
    // written, the call was not canonical:
    // as an operand of a canonical `Add` it reached `toNumericValue()`,
    // which requires a canonical expression, and in the body of a function
    // it was broadcast over the elements of the list bound to `xs`.
    //
    // A function is never a collection, so the refusal does not depend on
    // the operand at the callback slot: `Map(Sin, Cos)` refuses `Cos`
    // too, whatever `Sin` is and whenever a symbol there is declared. When
    // the first operand of `Map` is a collection (`Map([1, 4], f)`), the
    // handler of `Map` reports the wrong order at the callback slot itself,
    // and the boxing does not reach this check.
    if (kind === undefined) return operand;
    // A canonical form must not depend on the value assigned to a symbol:
    // the symbol can be reassigned to a collection before the call is
    // evaluated. Thus the refusal reads a type that is not derived from a
    // value. An operand typed `unknown`, `any` or `value` is not refused
    // here, even when its current value is not a collection, and neither
    // is a symbol whose type was inferred: from its assigned value (a
    // declared-`unknown` symbol assigned `5` is typed `integer`), or from an
    // earlier use (the wildcard `_` is typed `number` after `Add(_, 1)`). The
    // evaluation step reports a non-collection value as `incompatible-type`.
    const t = operand.type.type;
    if (t === 'unknown' || t === 'any' || t === 'value') return operand;
    if (isSymbol(operand) && hasInferredType(operand)) return operand;
    const checked = checkCollectionOperand(ce, operand, kind);
    if (!checked.isValid) refused = true;
    return checked;
  });
  return refused ? ops : undefined;
}

export function checkArity(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  count: number
): ReadonlyArray<Expression> {
  ops = flatten(ops);

  // @fastpath
  if (!ce.strict) {
    // Skip the "unexpected-argument" bookkeeping below, but still pad a
    // missing *required* argument with an `Error("missing")` marker.
    // Leaving it out entirely stores a raw JS `undefined` in the operand
    // array once `count` operands are assumed downstream (e.g. `Sin()`
    // canonicalizes to a zero-operand `Sin`, and `.evaluate()` then
    // destructures `ops[0]` as `undefined`, producing the garbage
    // expression `Sin([undefined])` instead of degrading gracefully).
    if (ops.length >= count) return ops;
    const xs = [...ops];
    while (xs.length < count) xs.push(ce.error('missing'));
    return xs;
  }

  if (ops.length === count) return ops;

  const xs: Expression[] = [...ops.slice(0, count)];
  let i = Math.min(count, ops.length);
  while (i < count) {
    xs.push(ce.error('missing'));
    i += 1;
  }
  while (i < ops.length) {
    xs.push(ce.error('unexpected-argument', ops[i].toString()));
    i += 1;
  }
  return xs;
}

/**
 * Prose-style fallback for un-applied builtin operators: a single
 * uppercase-letter symbol bound to a **standard-library** operator (`N`, `D`)
 * that appears as a bare operand of a numeric function (`N + 1`, `M = N + 1`,
 * `S/D`) almost always means a variable, not the builtin. This occurrence
 * becomes a free name that its unit reads as a variable; its type is then
 * inferred like any other free variable. Nothing is declared.
 *
 * Only *root-scope* (standard library) bindings devolve — a user-declared
 * function used as an operand is a genuine error and is preserved. A later
 * application `N(...)` still calls the library operator.
 *
 * The repair applies only to an operand that is itself bound to an OPERATOR
 * definition — an un-applied operator. A symbol bound to a value definition
 * has a type of its own, and re-boxing it here would silently launder the
 * parameter check it just failed.
 *
 * Returns the free name, or `null` if the fallback does not apply.
 */
function devolveUnappliedOperator(
  ce: ComputeEngine,
  op: Expression
): Expression | null {
  if (!isSymbol(op)) return null;
  // Must never execute in the trial of an overload arm (phase 2c), which
  // admits a repairable operand by `isRepairableOperatorSymbol` without
  // running the repair. The Epsil static checking pass legitimately
  // reaches this: the repair declares nothing, so there is nothing to put
  // back.
  console.assert(
    !inTrial(ce),
    'devolveUnappliedOperator must not run in trial (repair-free) validation'
  );
  const name = op.symbol;
  if (!/^[A-Z]$/.test(name)) return null;
  // An un-applied OPERATOR is what devolves. A symbol already bound to a
  // value (a user declaration such as `V: tuple<number,number,number>`) is
  // not repairable: its declared type is the answer, and the failed check
  // must surface as `incompatible-type` like it does for any other name.
  if (!op.operatorDefinition) return null;

  // Find the scope where the name is currently bound
  let scope: Scope | null = ce.context.lexicalScope;
  while (scope && !scope.bindings.has(name)) scope = scope.parent;
  if (!scope) return null;

  const def = scope.bindings.get(name)!;
  if (!scope.parent) {
    // Bound to the standard library: read this occurrence as a variable
    if (!isOperatorDef(def)) return null;
    // A top-level `ce.assign('F', x ↦ x²)` hoists its definition into the
    // same parentless scope as the standard library, so scope position alone
    // cannot tell a builtin from a user function. Discriminate on the
    // definition's ORIGIN: a definition backed by a user-defined function
    // literal is a genuine user function — using it as a numeric operand must
    // surface `incompatible-type`, not silently shadow the function (which
    // would also turn a later `F(2)` into the product `2F`).
    if (
      def.operator instanceof _BoxedOperatorDefinition &&
      def.operator._isLambda
    )
      return null;
    // The home scope of the free name is the first scope that is not marked
    // `noAutoDeclare`. The scope of a binder (`Sum`, `Product`, `Integrate`,
    // `D`) is marked so: the letter is a free variable of the whole
    // expression, as `M` is in `Σ M·k`, not a local of the binder, so a
    // later `ce.assign('N', 2)` reaches `Sum(N·k, (k, 1, 3))`.
    let declareScope = ce.context.lexicalScope;
    while (declareScope.noAutoDeclare && declareScope.parent)
      declareScope = declareScope.parent;
    // Boxing declares no name: the occurrence becomes a free name that its
    // unit reads as a variable, and the resolution of the name in that unit
    // skips the library operator (`BoxedSymbol._asFreeVariable()`,
    // `binding-unit.ts`). In a scope that the boxing made (the body of a
    // function literal), its home scope is the scope that the literal is
    // written in, as for any free name of a body (`createSymbolExpression()`).
    while (
      ce._boxingState.isPersistentScope(declareScope) === false &&
      declareScope.parent
    ) {
      declareScope = declareScope.parent;
      while (declareScope.noAutoDeclare && declareScope.parent)
        declareScope = declareScope.parent;
    }
    return (
      op as unknown as { _asFreeVariable(home: Scope): Expression }
    )._asFreeVariable(declareScope);
  }
  return null;
}

/**
 * The canonical form of `op`, an operand that a lazy operator holds at a
 * position that takes a VALUE, with the repair of `devolveUnappliedOperator`
 * applied: a bare `N` or `D` bound to the library operator becomes a
 * variable.
 *
 * The repair otherwise runs only when an operand fails the type check of its
 * parameter (`N + 1`: `Add` requires a number). A lazy operator with a
 * `canonical` handler does not check its held operands against its
 * signature, and the value positions read here have a type that a function
 * matches (`any`, `value`). So in the integrand of `Integrate`, in the body
 * of `Sum` and `Product` and in the initial value of `Reduce`, `N` stayed
 * bound to the operator: `unknowns` left it out, and the body of `Sum` was a
 * type error. A position that takes a FUNCTION (the reducer of `Reduce`)
 * must not call this: there the operator binding is correct.
 *
 * Returns `op` unchanged when the repair does not apply, and in the trial of
 * an overload arm.
 */
export function canonicalValueOperand(
  ce: ComputeEngine,
  op: Expression
): Expression;
export function canonicalValueOperand(
  ce: ComputeEngine,
  op: Expression | undefined
): Expression | undefined;
export function canonicalValueOperand(
  ce: ComputeEngine,
  op: Expression | undefined
): Expression | undefined {
  if (op === undefined) return undefined;
  const canonical = op.canonical;
  if (!isSymbol(canonical) || !/^[A-Z]$/.test(canonical.symbol))
    return canonical;
  if (inTrial(ce)) return canonical;
  if (!isRepairableOperatorSymbol(ce, canonical)) return canonical;
  return devolveUnappliedOperator(ce, canonical) ?? canonical;
}

/** The parameter types that take any value: a library operator name passed
 * there is read as a variable, not as a function. A parameter that takes a
 * function has a function type (`function`, a signature). */
const VALUE_POSITION_TYPES: ReadonlySet<Type> = new Set([
  'any',
  'value',
  'expression',
  'unknown',
]);

/**
 * The operators whose operands are typed `any` but are not all values, so
 * none of their operands is repaired here (`ALL_OPERANDS`):
 * - `Apply(f, x…)` and `ApplyWhole(f, x…)` apply their first operand, and
 *   forward the others to `f`, whose own parameters say whether each one is
 *   a value or a function: `Apply(g, N)` with `g: (function) -> number` must
 *   keep the library `N`, as `g(N)` does. The repair of a forwarded argument
 *   is left to the call of `f` (its canonicalization, or its application).
 * - The operand of `__unit__` is the name of a unit (`\mathrm{N}` is
 *   `__unit__(N)`, the newton).
 */
const ALL_OPERANDS = 'all';
const FUNCTION_OPERAND_POSITIONS: ReadonlyMap<string, number | 'all'> = new Map<
  string,
  number | 'all'
>([
  ['Apply', ALL_OPERANDS],
  ['ApplyWhole', ALL_OPERANDS],
  ['__unit__', ALL_OPERANDS],
]);

/** A symbol whose name is one uppercase letter: the names the repair of
 * `devolveUnappliedOperator` can apply to (`N`, `D`). */
function isLibraryLetterCandidate(op: Expression): boolean {
  if (!isSymbol(op)) return false;
  const name = op.symbol;
  return name.length === 1 && /^[A-Z]$/.test(name);
}

/**
 * The one-uppercase-letter symbol that the operand `op` is, or that it holds
 * inside parentheses, or `undefined`. A raw (held) operand of a lazy operator
 * can still be written `Delimiter(N)` or `Delimiter(Delimiter(N))` (the parse
 * of `(N) = 2`): its canonical form is `N`, so it is read as `N` here. The
 * repaired operand replaces the whole `Delimiter`. A `Delimiter` with
 * another delimiter than parentheses (`[N]`, `|N|`) is not read through.
 */
function candidateOperand(
  op: Expression
): (Expression & { readonly symbol: string }) | undefined {
  let x: Expression = op;
  while (!x.isCanonical && isFunction(x, 'Delimiter')) {
    if (x.nops === 2) {
      const delim = isString(x.op2) ? x.op2.string : undefined;
      if (
        delim === undefined ||
        !(delim.startsWith('(') && delim.endsWith(')'))
      )
        return undefined;
    } else if (x.nops !== 1) return undefined;
    let inner = x.op1;
    if (isFunction(inner, 'Sequence')) {
      if (inner.nops !== 1) return undefined;
      inner = inner.op1;
    }
    x = inner;
  }
  if (!isSymbol(x) || !isLibraryLetterCandidate(x)) return undefined;
  return x;
}

/**
 * True when the name `name`, read in the current scope, resolves to a library
 * operator that `devolveUnappliedOperator` would repair, WITHOUT binding or
 * declaring anything. A
 * parameter of the function literal being canonicalized resolves to the
 * parameter, so it is not repaired.
 */
function resolvesToRepairableOperator(
  ce: ComputeEngine,
  name: string
): boolean {
  if (ce._isShadowedParameter(name)) return false;
  let scope: Scope | null = ce.context.lexicalScope;
  while (scope && !scope.bindings.has(name)) scope = scope.parent;
  if (!scope) return false;
  const def = scope.bindings.get(name)!;
  if (!scope.parent)
    return (
      isOperatorDef(def) &&
      !(
        def.operator instanceof _BoxedOperatorDefinition &&
        def.operator._isLambda
      )
    );
  return false;
}

const ANY_VALUES_SIGNATURE: FunctionSignature = {
  kind: 'signature',
  variadicArg: { type: 'any' },
  result: 'any',
};

/** `devolveAtValuePositions` for operands that are all values, the elements
 * of a collection literal (`[N, 1]`, `(N, 1)`) built without its operator
 * definition. */
export function devolveValueElements(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>
): ReadonlyArray<Expression> {
  return devolveAtValuePositions(ce, '', ANY_VALUES_SIGNATURE, ops) ?? ops;
}

/**
 * The rule for a parameter of a user function (a function literal, inline or
 * assigned to a name): whether the parameter `param` reads the operand `op`
 * as a value. A parameter with no annotation is typed `unknown` whether the
 * body applies it (`(f) ↦ f(2)`) or reads it as a value (`(x) ↦ x + 1`): the
 * literal does not infer from its body which of the two it is. So an
 * `unknown` parameter is not a value position, and the argument `N` stays
 * the library operator, as it did before the repair read value positions.
 * Only a parameter that says so is: an annotation `any`, `value` or
 * `expression`, or a type that the operator does not match
 * (`(x: number) ↦ x + 1`).
 */
export function isAnnotatedValueParameter(
  param: Type,
  op: Expression
): boolean {
  return (
    param !== 'unknown' &&
    (VALUE_POSITION_TYPES.has(param) || !op.type.matches(param))
  );
}

/** The type of the parameter that receives operand `index` of a call with
 * the signature `sig`, or `undefined` past the last parameter. */
function parameterTypeAt(
  sig: FunctionSignature,
  index: number
): Type | undefined {
  const args = sig.args ?? [];
  if (index < args.length) return args[index].type;
  const optArgs = sig.optArgs ?? [];
  if (index < args.length + optArgs.length)
    return optArgs[index - args.length].type;
  return sig.variadicArg?.type;
}

/**
 * The repair of `devolveUnappliedOperator` applied at each operand whose
 * parameter takes any value (`any`, `value`, `expression`, `unknown`): a bare
 * `N` or `D` bound to the library operator becomes a variable there, as it
 * does at a numeric parameter. `N = 2`, `[N, 1]`, `(N, 1)` and `f(N)` (with
 * `f` undeclared) did not count `N` as unknown, and `N = 2` evaluated to
 * `False` by comparing the operator with 2.
 *
 * Only a signature with one arm is read: in an overload set the parameter of
 * a position can differ between arms. A parameter typed as a function (the
 * reducer of `Reduce`, the function of `Map`) and the head operand of `Apply`
 * keep the operator binding.
 *
 * Returns the new operands, or `undefined` when no operand changed.
 */
export function devolveAtValuePositions(
  ce: ComputeEngine,
  name: string,
  signature: Type,
  ops: ReadonlyArray<Expression>,
  /** Whether the parameter `param` reads the operand `op` as a value. By
   * default, a parameter typed `any`, `value`, `expression` or `unknown`. */
  isValueParameter: (param: Type, op: Expression) => boolean = (param) =>
    VALUE_POSITION_TYPES.has(param)
): Expression[] | undefined {
  if (typeof signature === 'string' || signature.kind !== 'signature')
    return undefined;
  if (!ops.some((op) => candidateOperand(op) !== undefined)) return undefined;
  const skip = FUNCTION_OPERAND_POSITIONS.get(name);
  if (skip === ALL_OPERANDS) {
    // `Apply(f, x…)` with a function literal `f`: the literal is not called
    // again by name, so its forwarded arguments are read against ITS
    // parameters here. A named `f` is rebuilt as the call `f(x…)` by the
    // `Apply` handler, which reads them against the parameters of `f`.
    const callee = ops[0];
    if (
      (name === 'Apply' || name === 'ApplyWhole') &&
      isFunction(callee, 'Function') &&
      callee.isCanonical
    ) {
      // The parameter slots are read from the literal
      // (`functionLiteralParameterSlots`), not from `callee.type`. Deriving
      // the literal's full type here also derives its body's type while the
      // enclosing call is being boxed: with `Map(r, v)` in the body and `r` a
      // recursive user function, that types `r` for the first time inside a
      // type handler, which the type-handler purity check refuses. The slots
      // are the ones of the derived type (annotations, destructuring and
      // inferred collection types), and a rest parameter keeps its `any*`
      // tail.
      // A literal that declares its full signature (a generic one included:
      // `(x: T) -> T where T: number`, whose parameter annotation
      // canonicalization erases) is read from that declaration, each type
      // variable as its bound.
      const declared = functionLiteralDeclaredSignature(callee);
      const body = functionLiteralBody(callee);
      const slots =
        body === undefined
          ? undefined
          : functionLiteralParameterSlots(callee, body);
      const forwarded = devolveAtValuePositions(
        ce,
        '',
        declared !== undefined
          ? readTypeVariablesAsBounds(declared)
          : {
              kind: 'signature',
              ...signatureArgumentsOfSlots(callee.ops.slice(1), slots),
              ...restParameterSignatureTail(callee.ops.slice(1)),
              result: 'unknown',
            },
        ops.slice(1),
        isAnnotatedValueParameter
      );
      if (forwarded !== undefined) return [callee, ...forwarded];
    }
    return undefined;
  }
  let result: Expression[] | undefined;
  ops.forEach((written, i) => {
    if (i === skip) return;
    const op = candidateOperand(written);
    if (op === undefined) return;
    const param = parameterTypeAt(signature, i);
    if (param === undefined || !isValueParameter(param, op)) return;
    // A RAW operand (a lazy operator's held operand) is canonicalized only
    // when its name resolves to the library operator: canonicalizing it just
    // to test it would bind it, or declare it, in the current scope, before
    // the operator's handler opens its own (a parameter of a function
    // literal, a local of a block).
    if (!op.isCanonical && !resolvesToRepairableOperator(ce, op.symbol)) return;
    const devolved = canonicalValueOperand(ce, op);
    // Only a repaired operand replaces the operand: a raw operand that was
    // not repaired stays raw, for the operator to canonicalize itself.
    // The repaired operand can be a free name that its unit reads as a
    // variable (`BoxedSymbol._asFreeVariable()`).
    if (devolved === op || !isSymbol(devolved) || !isFreeName(devolved)) return;
    result ??= [...ops];
    result[i] = devolved;
  });
  return result;
}

/**
 * Validation of arguments is normally done by checking the signature of the
 * function vs the arguments of the expression. However, we have a fastpath
 * for some common operations (add, multiply, power, neg, etc...) that bypasses
 * the regular checks. This is its replacements.
 *
 * Since all those fastpath functions are numeric (i.e. have numeric arguments
 * and a numeric result), we do a simple numeric check of all arguments, and
 * verify we have the number of expected arguments.
 *
 * We also assume that the function is threadable.
 *
 * The arguments are made canonical.
 *
 * Flattens sequence expressions.
 */
export function checkNumericArgs(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  options?:
    | number
    | {
        count?: number;
        flatten?: string;
        kindHook?: GroupOneHook;
        carrier?: boolean | GroupOneHook;
      }
): ReadonlyArray<Expression> {
  let count = typeof options === 'number' ? options : options?.count;
  const flattenHead =
    typeof options === 'number' ? undefined : options?.flatten;
  // `kindHook`: the operator is one of the arithmetic operators of the value
  // kinds (`Add`, `Subtract`, `Multiply`, `Divide`, `Negate`, `Power`,
  // `Square`, `Sqrt`, `Root`), and a value of a kind whose head declares
  // this hook is admitted as an operand (a residue class, a `GF8` element).
  // `carrier`: the operator's parameters admit a real number (`Ln`, `Log`,
  // `Exp`), so a value of a kind admitted as a number (`admittedAs: 'real'`
  // or `'number'`) is admitted as an operand, as at `Sin`, and the
  // evaluation gives it to the kind's `apply` hook (to its `power` hook for
  // `Exp`, which is rewritten to `Power(e, x)`). A kind admitted as nothing
  // (a residue class) is refused. The registry is read now, when the
  // expression is boxed: an expression refused before the hook was
  // registered is not checked again. `PlusMinus` checks its operands here
  // with neither option and refuses a kind value.
  // When `carrier` names a hook, a kind admitted as a number is admitted
  // only when its heads also declare that hook. `Exp` and `Exp2` use
  // `'power'`: they are rewritten to `Power(e, x)` and `Power(2, x)`, and
  // `Power` refuses at evaluation a kind value whose kind has no `power`
  // hook, so such a value is refused here, at boxing, as at `Sqrt` and
  // `Square`.
  const carrierOption =
    typeof options === 'object' ? options?.carrier : undefined;
  const admittedKinds: KindTypeNames | undefined =
    typeof options === 'object' && options?.kindHook !== undefined
      ? kindTypeNamesWithHook(ce, options.kindHook)
      : carrierOption === true
        ? carrierKindTypeNames(ce)
        : typeof carrierOption === 'string'
          ? {
              has: (name: string) =>
                carrierKindTypeNames(ce).has(name) &&
                kindTypeNamesWithHook(ce, carrierOption).has(name),
            }
          : undefined;

  // Ellipsis fold barrier: when a direct `ContinuationPlaceholder` operand is
  // present (a notational sum/product like `2 · 4 · … · 2n`), do not lift
  // nested associative operands — that would tear a coefficient out of its
  // anchor (the `2n` in `Multiply(2, n)`). Still lift `Sequence`/`Nothing`.
  if (flattenHead && ops.some((x) => isContinuationOperand(x)))
    ops = flatten(ops);
  else if (flattenHead && ops.some((x) => containsContinuationOperand(x))) {
    // Depth-aware barrier (mirrors `canonicalMultiply`): a nested product may
    // carry its ellipsis at any depth — e.g. raw-boxed
    // `Multiply(Multiply(a, Multiply(b, ContinuationPlaceholder)), c)` — and,
    // since `flatten` descends `Sequence` too, it may also sit behind a
    // `Sequence` wrapper. Splicing either would smuggle the placeholder past
    // the direct-operand check above. Hold barrier-bearing products back
    // whole; everything else still flattens.
    ops = flattenHoldingBarriers(ops, flattenHead);
  } else ops = flatten(ops, flattenHead);

  // @fastpath
  if (!ce.strict) {
    // Skip the full per-argument type checking below, but still pad a
    // missing *required* argument (when a `count` is specified, e.g.
    // `Negate`/`Power`/`Root`) with an `Error("missing")` marker. Leaving
    // it out entirely stores a raw JS `undefined` in the operand array,
    // which crashes the first time a `canonical`/`evaluate` handler
    // destructures that fixed-arity operand (e.g. `Negate()`, `Power(2)`)
    // instead of degrading gracefully like strict mode does.
    let xs: ReadonlyArray<Expression> = ops;
    if (count !== undefined && ops.length < count) {
      const padded = [...ops];
      while (padded.length < count) padded.push(ce.error('missing'));
      xs = padded;
    }
    // The scan that CHOOSES the inferred type runs inside the same fact-blind
    // bracket as the writes it feeds: it reads each operand's effective type,
    // so an assumption that narrows one operand out of the complex tier would
    // otherwise flip the type stored on all the others.
    ce._withoutFacts(() => {
      let inferredType: Type = 'real';
      // If any of the arguments is a complex or imaginary number,
      // we'll infer the type as number
      for (const x of xs)
        if (x.type.facts.couldBeNonReal) {
          inferredType = 'number';
          break;
        }
      // Numeric operators are threadable: an operand that could be a collection
      // at runtime (a `vector<n>`-returning application, `number | list`, a
      // tuple) is consumed by BROADCAST, so the scalar numeric context must not
      // be inferred onto it — `x._infer('real')` on a call whose inferred result
      // signature is already `vector<2>` WIDENS the shared definition to
      // `real | vector<2>`, and every later use of that function then types as
      // `number` (Tycho item 121: the compiled Sum then emits scalar `+` over
      // arrays). The exclusion is wider than admission — see
      // `excludedFromScalarInference` — and mirrors the guard on the
      // signature-validation route (`validateSignature`).
      for (const x of xs)
        if (!excludedFromScalarInference(x)) x._infer(() => inferredType);
    });
    return xs;
  }

  let isValid = true;

  count ??= ops.length;

  const xs: Expression[] = [];
  const last = Math.max(count - 1, ops.length - 1);
  for (let i = 0; i <= last; i++) {
    const op = ops[i];
    if (i > count - 1) {
      isValid = false;
      xs.push(ce.error('unexpected-argument', op.toString()));
    } else if (op === undefined) {
      isValid = false;
      xs.push(ce.error('missing'));
    } else if (!op.isValid) {
      isValid = false;
      xs.push(op);
    } else if (op.type.type === 'error') {
      // A valid operand whose type is `error` always evaluates to an error of
      // its own, such as `Tuple(A, B) + (1, 1)` with `A`, `B` lists (see
      // `appliesToListCoordinateTuple`). It passes through unchanged, so that
      // evaluation reports that one error. Wrapping it in an
      // `incompatible-type` error ("expected `number`, got `error`") would
      // hide the real error, and would make every enclosing sum or product a
      // sum or product of such wrappers.
      xs.push(op);
    } else if (op.isNumber) {
      // The argument is a number literal or a function whose result is a number
      xs.push(op);
    } else if (
      isSymbol(op) &&
      !ce.lookupDefinition(op.symbol) &&
      !(isFreeName(op) && !op.type.isUnknown)
    ) {
      // We have an unknown symbol, we'll infer it's a number later. A free
      // name that its unit already requires to
      // be something is checked by the branches below, as a symbol with an
      // inferred definition is: in `o \cdot o(t)` the factor `o` is a
      // function, and an `incompatible-type` error.
      xs.push(op);
    } else if (op.type.isUnknown || op.type.type === 'any') {
      // Unknown or any type. Keep it that way, infer later
      xs.push(op);
    } else if (
      admittedKinds !== undefined &&
      admitsResidueClassOperand(op.type.type, admittedKinds)
    ) {
      // A residue class (`ResidueClass(2, 4)`, a symbol declared `residue`, a
      // call of a head whose signature returns `residue`), or a value that may
      // be one beside numbers (`integer | residue`). The operator has residue
      // arithmetic (`admittedKinds`), so the class is admitted. It is not a
      // number: it is admitted before the branches below, which read the
      // operand as a numeric collection, a tuple or a number, and it is not
      // given an inferred numeric type at the end of this function
      // (`excludedFromScalarInference`). A class beside an absent value
      // (`residue | missing`) is admitted the same way: the absence gives
      // `NaN`, as for a number. A value that may be a class beside something
      // that is not a number (`string | residue`) is not admitted here, and
      // the branches below refuse it as they refuse `string`.
      xs.push(op);
    } else if (collectionCellsProvablyNonNumeric(op.type.type, admittedKinds)) {
      // The static element type is concrete and provably non-numeric
      // (`list<string^2>`, `set<boolean>`, `list<string | missing>`). The
      // element type already disproves numericity, so reject WITHOUT
      // walking: `Ln(["a", "b"])` is an invalid call at boxing, the same as
      // `Ln("a")`, not a valid call that fails in every cell at evaluation.
      // This arm must come before every admission below — the absence arm,
      // which would otherwise admit `list<string | missing>` on the strength
      // of its `missing` cells, and the tensor arm, which admits any
      // dimensioned list, whatever its cells hold — and it agrees with
      // `validateThreadableOperand` on the definition route, so a head on
      // either route refuses the same collection. Derived from the shared
      // `typeIsProvablyNonNumericCollection` predicate so this stays in
      // lockstep with the `Add`/`Multiply` type handlers.
      isValid = false;
      xs.push(ce.typeError('number', op.type, op));
    } else if (op.type.facts.containsMissing) {
      // An absent (`Missing`) or possibly-absent (`T | missing`) operand in a
      // numeric position. Every numeric operator resolves to `propagate`
      // (§3.A), so the ABSENCE is admitted — the runtime gate produces `NaN`
      // in the result cell (strip-before-validate, §3.B). The carrier `T`
      // still has to satisfy the numeric position: a carrier that is
      // provably disjoint from `number` and cannot be a numeric collection
      // or tuple (`boolean | missing`, `string | missing`, an element read
      // out of a `list<boolean>`) is refused, the way the definition route
      // (`Sin(q)` with `q: boolean | missing`) already refuses it. Without
      // this the short path admitted `q + 1` while `Sin(q)` was an error,
      // and a boolean element read then numerically used wrote `never` onto
      // its collection instead of erroring. A carrier that could still be
      // numeric — `unknown`, `number | list`, a bare `missing` (carrier
      // `never`) — is admitted as before.
      const carrier = stripMissingFromType(op.type.type);
      if (
        carrier !== 'never' &&
        provablyDisjoint(carrier, 'number') &&
        !typeCouldBeNumericCollection(carrier) &&
        !typeCouldBeNumericTuple(carrier)
      ) {
        isValid = false;
        xs.push(ce.typeError('number', op.type, op));
      } else xs.push(op);
    } else if (typeCouldBeNumericCollection(op.type.type)) {
      // The argument's type could be a numeric collection at runtime
      // (e.g. `list`, `number | list`). Since numeric functions are
      // threadable, accept it.
      xs.push(op);
    } else if (typeCouldBeNumericTuple(op.type.type)) {
      // The argument is a numeric tuple (point/vector in ℝⁿ). Accept it for
      // vector arithmetic (Add/Multiply/Negate/Subtract/Divide). Pass through
      // without inferring its elements to `real` (like the tensor branch).
      xs.push(op);
    } else if (isTensorValue(op)) {
      // The argument is a tensor (matrix or vector). Accept it for tensor
      // operations like element-wise addition. Tensor-specific validation
      // (shape compatibility, etc.) happens in the evaluate function.
      xs.push(op);
    } else if (isFiniteIndexedCollection(op)) {
      if (op.type.matches(INDEXED_COLLECTION_OF_NUMBER)) {
        // (1) The static type already proves every element is a number (mirror
        // the indeterminate-size branch below). Accept without walking.
        xs.push(op);
      } else if (op.isLazyCollection) {
        // (2) The static element type is indeterminate (`any`/`unknown`), and
        // this is a lazy collection: `.each()` would materialize every element
        // just to type-check it. For a large lazy source (item 16:
        // `\frac{[1...1e8]}{2}` hung `ce.parse`) that is O(size) at
        // canonicalization time — and the cost does not depend on free
        // variables. Accept on the strength of laziness REGARDLESS of
        // `unknowns` and defer element validation to evaluate time — fail-open:
        // a lazy weak-typed collection of non-numbers now fails at evaluate
        // rather than erroring at canonicalization.
        xs.push(op);
      } else {
        // (2, eager) An eager, operand-backed collection (e.g. a literal
        // `List`) with an indeterminate element type: its elements are already
        // stored, so walking is cheap. Check that all elements are numbers and
        // infer the type of the elements. Use a local flag: `isValid` may
        // already be false from an earlier operand, which must not brand this
        // one with a type error.
        let allNumbers = true;
        for (const x of op.each()) {
          // A function-valued symbol element is accepted without inference,
          // mirroring the scalar gate's treatment of a bare function symbol
          // in numeric position (`2·N` stays symbolic and valid). An
          // `unknown`-typed element is infer-later, mirroring the
          // unknown-operand branch above. Both keep pathological values like
          // `[N, 2N]` (a list capturing an operator symbol) OUT of the
          // element-inference path — the operator-definition corruption
          // guard (type-inference.test.ts) pins this.
          const xt = x.type.type;
          if (isSymbol(x) && typeof xt !== 'string' && xt.kind === 'signature')
            continue;
          if (x.type.isUnknown) continue;
          if (!x.isNumber) {
            allNumbers = false;
            break;
          }
        }
        if (!allNumbers) {
          isValid = false;
          xs.push(ce.typeError('number', op.type, op));
        } else xs.push(op);
      }
    } else if (
      op.isIndexedCollection &&
      op.isFiniteCollection === undefined &&
      op.type.matches(INDEXED_COLLECTION_OF_NUMBER)
    ) {
      // An indexed collection of numbers whose size is indeterminate (e.g.
      // `Range(1, n)` with symbolic `n`). Accept it for broadcasting on the
      // strength of the element type: iterating to validate the elements —
      // what the finite branch above does — is not possible here.
      xs.push(op);
    } else if (hasInferredType(op) && isSubtype('number', op.type.type)) {
      // There was an inferred type, and it is a supertype of "number"
      // e.g. "any". We'll narrow it down to "number" when we infer later.
      xs.push(op);
    } else if (
      op.operatorDefinition?.inferredSignature &&
      isSubtype('number', op.type.type)
    ) {
      // There is an inferred signature, and it is a supertype of 'number
      // e.g. "any". We'll narrow it down to "number" when we infer later.
      xs.push(op);
    } else if (
      op.operator === 'Hold' ||
      op.valueDefinition?.value?.operator === 'Hold'
    ) {
      // We keep 'Hold' expressions as is
      xs.push(op);
    } else if (op.type.couldMatch('number')) {
      // The declared type overlaps `number` — a wide value type (`value`,
      // `scalar`) or a union with a numeric arm (`integer | string`). The
      // operand COULD be a number, so admit it: arithmetic operators are
      // permissive at boxing time and reject a non-numeric value at
      // evaluation time. (Types with their own admission story — collections,
      // tuples, tensors, `any`/`unknown` — are handled by the branches
      // above; disjoint types like `string` or `boolean` still error here.)
      // Note the post-validation `_infer` pass below is a no-op for these:
      // an explicitly declared type is never rewritten by a use.
      xs.push(op);
    } else {
      // Last chance: an un-applied single-letter builtin operator (`N + 1`)
      // devolves to an unknown symbol (see devolveUnappliedOperator)
      const devolved = op.operatorDefinition
        ? devolveUnappliedOperator(ce, op)
        : null;
      if (devolved) xs.push(devolved);
      else {
        isValid = false;
        xs.push(ce.typeError('number', op.type, op));
      }
    }
  }

  // Only if all arguments are valid, we infer the type of the arguments.
  // The whole pass — the scan that chooses the type and the writes that store
  // it — runs fact-blind, so an assumption narrowing one operand out of the
  // complex tier cannot decide what is inferred onto the others.
  if (isValid) inferNumericArgs(ce, xs);

  return xs;
}

/**
 * Evaluate-time complement of `checkNumericArgs`: numeric operators are
 * permissive at boxing time — a `value`-typed symbol is admitted because it
 * COULD be a number, even though it may legally hold a string — so the
 * numeric evaluate handlers must surface the mismatch once operand
 * evaluation substitutes a value that PROVES non-numeric. Without this the
 * mistake either lingers as an inert expression (`2 · "hello"`, `sin("a")`)
 * or is silently absorbed into a numeric result (`Negate` and `Sqrt` turned
 * a string into `NaN`).
 *
 * An operator whose operand type is checked against its declared signature
 * at canonicalization does not need this guard for a statically non-numeric
 * operand — but it does for one whose static type is a UNION that could
 * still be numeric, such as the element type of a heterogeneous list
 * (`Sin(At(["a", 2], 1))` types `integer | missing | number |
 * string`). Only evaluation can settle that operand, so only an
 * evaluate-time check can report it.
 *
 * Returns a type error for the first VALID operand whose type is disjoint
 * from every exempt reading: such an operand can neither be a number nor
 * broadcast over one. The exemptions, and why each stays silent:
 * - `broadcastable<number>`: could be a number, or a collection consumed by
 *   broadcast;
 * - `missing`: an absent value propagates (as `Missing`), never an error.
 *   The VALUE `Nothing` is not exempt: it is not a number, so `Add(2, y)`
 *   with `y := Nothing` is the same `incompatible-type` error as the boxed
 *   `Add(2, Nothing)`. The test reads the symbol, not the type, because the
 *   type `nothing` is the bottom type and so is below `number`;
 * - `function`: a function-valued symbol in a numeric position stays a
 *   symbolic term throughout the engine, in EVERY operator, not only as a
 *   product factor: at boxing time `checkNumericArgs` devolves an unapplied
 *   operator symbol to a plain symbol (`N + 1` via
 *   `devolveUnappliedOperator`) and accepts function-valued elements
 *   without inference, and the pinned cached-expression contracts keep
 *   `2·g` as `2g` after `g := x ↦ …` (pipeline-contracts,
 *   definition-order). Whether a function in a numeric position should
 *   instead be an error is a separate ruling; this guard only polices
 *   VALUES that arithmetic can never consume;
 * - `error`: the operand already carries its own problem — wrapping it
 *   would bury the original report.
 * A value of a kind (a quantity, a measurement) is not refused here: its
 * admission is decided at boxing (`kind-admission.ts`). Invalid operands are
 * skipped for the same reason as `error`-typed ones. Returns `undefined` when
 * every operand could still be numeric.
 *
 * A tuple operand is also an error when one of its components can be
 * neither a number nor a numeric collection or tuple, for example a string
 * or a boolean component: `("s", a)` types `tuple<string, unknown>`, which
 * is not disjoint from the exempt union, but it is not a point, so
 * arithmetic cannot consume it. This is the test that `checkNumericArgs`
 * makes at boxing (`typeCouldBeNumericTuple`), so `-("s", a)` is the same
 * error at boxing and at evaluation. Evaluation is where the test matters:
 * with `f(x) := (-x, x)`, the call `f(("s", a))` binds the tuple to `x`
 * when the body is evaluated, and without this test `-x` stayed the inert
 * `-("s", a)`, while `f("s")` gives the error. A tuple with a list
 * component is not refused here: that is the separate error of
 * `listCoordinateTupleOperandError`.
 */
// Parsed once: the guard runs for every operand of every numeric
// evaluation, so it must not re-resolve the type string per call.
// `residue` is exempt too: a residue class is admitted by the arithmetic
// operators that have residue arithmetic (`library/arithmetic.ts`), and their
// `evaluate` handlers route a class to the `residue*` functions
// (`residue-class.ts`) before this guard runs for the other operands.
const NON_NUMERIC_EXEMPT_TYPE: Type = parseType(
  'number | indexed_collection<number> | missing | nothing | function | error | residue'
);
export function nonNumericOperandError(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  operator?: string
): Expression | undefined {
  // A number literal, and any operand whose type is below `number`, share
  // values with `broadcastable<number>`: neither is disjoint, and the
  // subtype test answers that before the disjointness proof (five arms,
  // each a proof of its own) has to. The empty type `never` is below
  // `number` as well but shares no value with anything, so it keeps the
  // disjointness route and stays an error.
  // A value of a VALUE KIND registered in the engine (a nominal kind type
  // such as `gf8`) is exempt as a residue class is: the type string above
  // can only name the kind primitives. With `operator`, only the kinds that
  // the operator admits are exempt: at an arithmetic operator of group 1
  // (`Add`, `Divide`, …), a kind type whose heads declare the matching
  // hook; at any other operator, a kind type admitted through its carrier
  // (`admittedAs: 'real'` or `'number'`). A value of another kind is
  // an `incompatible-type` error, as a string is
  // (`docs/plans/2026-10-26-value-kinds.md`, section 4.2).
  const hook = groupOneHookOf(operator);
  const kinds =
    operator === undefined
      ? kindTypeNames(ce)
      : hook !== undefined
        ? kindTypeNamesWithHook(ce, hook)
        : carrierKindTypeNames(ce);
  const bad = ops.find(
    (x) =>
      x.isValid &&
      !isNumber(x) &&
      (isSymbol(x, 'Nothing') ||
        ((x.type.type === 'never' || !x.type.facts.belowNumber) &&
          x.type.isDisjointFrom(NON_NUMERIC_EXEMPT_TYPE) &&
          !hasKindArm(x.type.type, kinds)) ||
        isNonNumericTupleType(x.type.type))
  );
  if (bad === undefined) return undefined;
  return ce.typeError('number', bad.type, bad);
}

/**
 * Whether `t` is a tuple type with a component that can be neither a
 * number nor a numeric collection or tuple (a string, a boolean, a list of
 * strings). A union type answers false: one of its other arms can be a
 * number.
 */
function isNonNumericTupleType(t: Type): boolean {
  const resolved = resolveTypeAlias(t);
  return (
    typeof resolved === 'object' &&
    resolved.kind === 'tuple' &&
    !typeCouldBeNumericTuple(resolved)
  );
}

/**
 * The error for an arithmetic operand that is a `Tuple` with a LIST
 * coordinate, such as `Tuple(A, B)` with `A = [1, 2, 3]` and
 * `B = [10, 20, 30]` (see `isTupleWithListCoordinate`). Returns `undefined`
 * when no operand is such a tuple.
 *
 * Such a tuple is data, not a point. Before, `Tuple(1, 1) + Tuple(A, B)`
 * combined the lists coordinate by coordinate and gave the tuple of lists
 * `([2, 3, 4], [11, 21, 31])`, which is neither a point nor a list of points,
 * so no consumer (a plot, a compiled function) could use it. A list of points
 * is written `PointList(A, B)`, or `(A, B)` in LaTeX.
 *
 * The error is the operand-type error the arithmetic operators already use
 * (`incompatible-type`, see `nonNumericOperandError`), wrapping the offending
 * tuple. The expected type is a point with the same number of coordinates.
 * The actual type is the type of the EVALUATED tuple, so the message reads,
 * for example, "expected `tuple<number, number>`, got
 * `tuple<vector<integer^3>, vector<integer^3>>`" for `A = [1, 2, 3]` and
 * `B = [10, 20, 30]`.
 *
 * The arithmetic evaluate handlers (`Add`, `Multiply`, `Divide`, `Negate`,
 * `Power`) and the component-wise tuple broadcast of `Power`, `Sqrt` and
 * `Root` (`tupleBroadcastCells`) call this on their EVALUATED operands, so
 * the check happens at evaluation and the canonical form is unchanged.
 */
export function listCoordinateTupleOperandError(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>
): Expression | undefined {
  const bad = ops.find((x) => isTupleWithListCoordinate(x));
  if (bad === undefined || !isFunction(bad)) return undefined;
  const expected: Type = {
    kind: 'tuple',
    elements: bad.ops.map(() => ({ type: 'number' })),
  };
  return ce.typeError(expected, bad.type, bad);
}

/**
 * Whether the operands carry a SCALAR absence, the condition under which an
 * operator with `missingBehavior` `propagate` or `reject` answers instead of
 * running its handler: an operator over `Missing` gives `Missing`
 * (`docs/ERROR-MODEL.md`, "`Missing` is a result only — user decision of
 * 2026-11-02"), and a `reject` operator gives an error.
 *
 * The absence has to be an absence SYMBOL — `Missing`, the name
 * {@link isAbsentScalarSymbol} accepts. A `NaN` operand already
 * propagates through numeric evaluation natively, and some operators give a
 * literal `NaN` operand a bespoke meaning.
 *
 * "Scalar" means no operand is collection-SHAPED — read as the type, not only
 * as the `isCollection` capability, because an operand declared `list<number>`
 * with no value yet is destined to broadcast but cannot be enumerated now. A
 * collection operand makes the application a broadcast, which carries the
 * absence per cell through the operator's own kernel.
 *
 * The driver applies this gate to the operands it evaluated
 * (`_computeValue`/`_computeValueAsync`, the missing-value behavior gate). A
 * `lazy` operator gets its operands UNEVALUATED there, so the gate only sees a
 * `Missing` that was already written in the source; such an operator must run
 * this same test itself on the operands it evaluates, or an absence produced
 * BY that evaluation survives into the result (`Add(g(3), 1)` stayed
 * `Add(Missing, 1)` where `Add(Missing, 1)` gave `NaN`).
 */
export function hasAbsentScalarOperand(
  ops: ReadonlyArray<Expression>
): boolean {
  return (
    ops.some(isAbsentScalarSymbol) &&
    !ops.some((x) => x.isCollection || x.type.matches('collection<any>'))
  );
}

/**
 * Is this operand the `Missing` symbol, the absent scalar of a numeric slot?
 * `Missing` is the position-preserving absent datum of
 * `docs/ERROR-MODEL.md` §1. Arithmetic consumers use `isAbsentValue`;
 * explicit checks and fallbacks (`IsMissing`, `Coalesce`) use
 * `isMissingValue`, which also counts a `NaN` point.
 */
export function isAbsentScalarSymbol(x: Expression): boolean {
  return isAbsentSymbol(x);
}

/**
 * The boolean predicates of the collection and set libraries, each with the
 * value it answers when an operand is absent (`Missing`, or a
 * restriction whose condition is false). Such a predicate is two-valued, as a
 * comparison is: an absent operand makes it `False`, and its negated form
 * (`NotElement`, `NotSubset`, ...) is `True`, as `NotEqual` is `Not(Equal)`.
 * `IsEmpty(Missing)` is `False` (an absent value is not an empty collection),
 * `Element(2, Missing)` is `False` (nothing is a member of an absent value),
 * and `All(Missing, p)` is `False` (an absent value is not a collection in
 * which every element holds). User decision 2026-11-02, two-valued
 * comparisons (`docs/ERROR-MODEL.md`).
 *
 * The answer is for an absent COLLECTION (or set) operand only. The value
 * that `Element` and `NotElement` search for is not covered: an absent value
 * is an ordinary element to search for, a member where the same marker sits
 * (user decision 2026-09-26, `SEARCHED_VALUE_POLICY` in
 * `library/collections.ts`). So `Element(Missing, [1, Missing])` is `True`,
 * `Element(Missing, Integers)` is `False`, and a membership that the search
 * cannot decide stays held: `Element(Missing, Set(7))`.
 *
 * The other boolean operators that propagate absence (the number-theory
 * predicates `IsPrime`, `IsEven`, `Divides`, ..., and `Congruent`) still
 * answer `Missing`.
 */
const ABSENT_PREDICATE_ANSWERS: ReadonlyMap<string, boolean> = new Map([
  ['Any', false],
  ['All', false],
  ['Contains', false],
  ['ContainsSequence', false],
  ['StartsWith', false],
  ['EndsWith', false],
  ['IsEmpty', false],
  ['Element', false],
  ['NotElement', true],
  ['Subset', false],
  ['SubsetEqual', false],
  ['Superset', false],
  ['SupersetEqual', false],
  ['NotSubset', true],
  ['NotSuperset', true],
  ['NotSupersetEqual', true],
]);

/**
 * The boolean that the predicate `operator` answers when an operand is
 * absent (`true` or `false`), or `undefined` when `operator` is not such a
 * predicate (`ABSENT_PREDICATE_ANSWERS`): its absent marker is then the one
 * of its codomain, `NaN` or `Missing`.
 */
export function absentPredicateAnswer(operator: string): boolean | undefined {
  return ABSENT_PREDICATE_ANSWERS.get(operator);
}

/**
 * The value an operator with missing behavior `propagate` answers when
 * {@link hasAbsentScalarOperand} is true for its operands: `Missing`.
 *
 * `Missing` is a result only, and any operator other than a reader
 * (`IsMissing`, `Coalesce`, `AssertPresent`, a branch, a
 * position-preserving accessor) gives `Missing` for an absent operand:
 * `Missing + 2`, `Sin(Missing)` and `Sort(Missing)` are `Missing`. A
 * numeric operator does not turn the absent value into `NaN`: `NaN` is the
 * value of a read outside a list of numbers, not of an operator over an
 * absent value. When no application node is available the answer is
 * `Missing` too.
 *
 * A boolean predicate of the collection and set libraries
 * ({@link absentPredicateAnswer}) answers a boolean, not `Missing`: such a
 * predicate is two-valued, as a comparison is.
 *
 * A coordinate accessor (`PointX`, `PointY`, `PointZ`) whose application
 * is typed as a number answers `NaN`: a coordinate is a number, and a
 * coordinate of an absent point is `NaN`, as `First` and `At` give for a
 * read with no element. So `PointX(Missing)` and `PointX(If(c, (1, 2)))`
 * after `c := False` are `NaN`, the value that the held form `If(c, 1)`
 * gives there. The coordinates of an absent LIST of points (an application
 * typed as a list) are `Missing`, as the held form `If(c, [1, 3])` gives.
 *
 * Source: `docs/ERROR-MODEL.md`, "`Missing` is a result only — user
 * decision of 2026-11-02", which replaces the reading of 2026-07-24 and
 * 2026-09-25 that a numeric operator over `Missing` is `NaN`.
 */
export function absentScalarMarker(
  ce: ComputeEngine,
  expression: Expression | undefined
): Expression {
  if (expression === undefined) return ce.Missing;
  const answer = absentPredicateAnswer(expression.operator);
  if (answer !== undefined) return answer ? ce.True : ce.False;
  if (
    (expression.operator === 'PointX' ||
      expression.operator === 'PointY' ||
      expression.operator === 'PointZ') &&
    isSubtype(stripMissingFromType(expression.type.type), 'number')
  )
    return ce.NaN;
  return ce.Missing;
}

/**
 * Whether the value of a read at a position that does not exist is the
 * numeric `NaN` (true) or `Missing` (false), given `applicationType`, the
 * type of the read, and `signature`, the signature of its operator. The
 * accessors use it when the element type of the collection does not decide
 * (`absenceMarker()`, `library/collections.ts`). An operator over an
 * absent operand does not use it: its value is `Missing`
 * ({@link absentScalarMarker}).
 *
 * An application typed `missing` alone (`Sort(Missing)`), or `never` (a
 * numeric operator over a symbol assigned `Missing`, which types `never`),
 * strips to `never`, a subtype of everything, so the type says nothing
 * about the codomain: it is read off the operator's declared result
 * instead, `NaN` for a numeric one and `Missing` otherwise.
 */
export function absentMarkerIsNumeric(
  applicationType: Type,
  signature: Type | undefined
): boolean {
  const t = stripMissingFromType(applicationType);
  if (t === 'never') {
    const declared =
      signature === undefined
        ? undefined
        : functionResult(readTypeVariablesAsBounds(signature));
    return declared !== undefined && isSubtype(declared, 'number');
  }
  return isSubtype(t, 'number');
}

/**
 * Whether `op` is a collection operand that can be ABSENT AS A WHOLE, for an
 * operator that holds its operands: its type has a `missing` member of its
 * own beside a collection (`missing | list<…>`), and it is pure.
 *
 * Such an operand — a row read `At(x, 1)` of a list of lists whose length is
 * not known, a restricted list `xs{c}` — holds a collection or the absent
 * value `Missing`. Its type is not a collection type, so a lazy view over it
 * does not read it as a source, and an operator that holds its operands does
 * not see the absence. Such an operator evaluates the operand and continues
 * with the value that `settledAbsentableValue` reads off the result.
 *
 * A restriction `If(c, xs)` is admitted by its form: it is typed as its
 * value `xs`, with no `missing` member, but it is absent where `c` fails.
 *
 * An operand that is not pure is excluded: a value that is neither absent
 * nor a collection would be discarded by the caller, which would then
 * evaluate the operand a second time (a `Random` draw consumed twice).
 */
export function isAbsentableCollectionOperand(op: Expression): boolean {
  if (isAbsentScalarSymbol(op)) return false;
  // A restriction, and an expression that holds a read (`At(x, i)`,
  // `Sort(At(x, i))`), are typed as their present value: the absence marker
  // of a read is implicit in its type (`mayHoldRestriction()`), so the type
  // alone does not show that such an operand can be absent.
  // An operand typed `missing` alone (`Map(f, Missing)`) is always absent.
  if (op.type.type === 'missing') return op.isPure;
  const present = mayHoldRestriction(op)
    ? op.type.type
    : threadedPresentType(op.type.type);
  if (present === undefined || !typeCouldBeCollection(present)) return false;
  return op.isPure;
}

/**
 * The value of an operand admitted by `isAbsentableCollectionOperand`, once
 * evaluated, when that value settles the question: the absent value
 * (`Missing`, tested with `isAbsentScalarSymbol`), or a
 * collection that cannot be absent. `undefined` otherwise: an operand that
 * does not evaluate yet, and a restricted list whose condition is not
 * decided, which is still a restriction `If(c, xs)`; the caller then keeps
 * the operand as it is.
 */
export function settledAbsentableValue(
  value: Expression
): Expression | undefined {
  if (isAbsentScalarSymbol(value)) return value;
  if (!value.isCollection || isRestriction(value)) return undefined;
  return threadedPresentType(value.type.type) === undefined ? value : undefined;
}

/**
 * `settledAbsentableValue` of the evaluation of `op`, when `op` is admitted
 * by `isAbsentableCollectionOperand`; `undefined` otherwise. The synchronous
 * form; the asynchronous evaluation route evaluates the operand itself and
 * calls `settledAbsentableValue` on the result.
 */
export function absentableCollectionOperandValue(
  op: Expression,
  evaluate: (x: Expression) => Expression = (x) => x.evaluate()
): Expression | undefined {
  if (!isAbsentableCollectionOperand(op)) return undefined;
  return settledAbsentableValue(evaluate(op));
}

/**
 * `result`, a list computed by an element-wise application, with each `NaN`
 * cell replaced by `Missing` when the application's type says the cell is an
 * absent POINT: its cell type is `missing | tuple<…>` (every present arm a
 * tuple), or, when its cell type is a tuple, for each cell whose cell in
 * one of the evaluated operands `evaluatedOps` is absent. Otherwise `result`
 * itself.
 *
 * The kernel computes each cell from the cell's own operands. An absent
 * operand cell there is the `Missing` symbol, and the cell application
 * (`2 · Missing`) is numeric, so it answers `NaN`. But the absent cell stood
 * for a point — `2 · [P{c}, (2, 3)]` with the restricted point `P{c}` absent
 * — and an absent point is `Missing` (`docs/ERROR-MODEL.md`, the section on
 * `Missing` in a numeric slot). Only the application's type still knows that
 * (`absorbOperandAbsence`, `broadcast-lift-type.ts`), so the marker is
 * corrected here, from that type. A `NaN` cell cannot be a present point, so
 * the correction never replaces a value. `absentCellMarker()` in
 * `library/collections.ts` makes the same correction for a `Map` cell.
 */
export function markAbsentPointCells(
  ce: ComputeEngine,
  expression: Expression | undefined,
  result: Expression,
  evaluatedOps?: ReadonlyArray<Expression>
): Expression {
  if (expression === undefined || !isFunction(result, 'List')) return result;
  // The cells can be at any depth: a MATRIX of points (a list of lists of
  // points) has its absent points in the inner lists. A `NaN` is looked for
  // in nested `List`s only, never inside a `Tuple`, where it is a coordinate
  // of a present point.
  const isNaNCell = (x: Expression) => isNumber(x) && x.isNaN === true;
  // The walk is not bounded by the type: a list type without dimensions
  // (`list<missing | tuple<…>>`) describes the leaf cells at ANY depth, so a
  // matrix of points can carry it, and the value's own nesting is the only
  // bound. That nesting is the shape of a data list, a few levels at most.
  const hasNaNCell = (x: Expression): boolean =>
    isFunction(x, 'List') && x.ops.some((y) => isNaNCell(y) || hasNaNCell(y));
  if (!hasNaNCell(result)) return result;
  // The application's type says whether its absent cells are points: the
  // leaf cells, read through nested lists and through rows that can be
  // absent, are `missing | tuple<…>` (`absentCellsArePoints`). The static
  // typing of the absent cells reads the same predicate
  // (`absorbOperandAbsence`), so the value and its type agree.
  if (absentCellsArePoints(expression.type.type)) {
    const mark = (x: Expression): Expression =>
      isFunction(x, 'List') && hasNaNCell(x)
        ? ce._fn(
            'List',
            x.ops.map((y) => (isNaNCell(y) ? ce.Missing : mark(y)))
          )
        : x;
    return mark(result);
  }
  // A restricted point `If(c, P)` has the type of `P`, with no `missing`
  // arm, so `2 · [P{c}, (2, 3)]` is typed `list<tuple<…>>`. Its leaf cells
  // are points (`cellsArePoints`), but the type does not say which cell is
  // absent. So each `NaN` cell is decided from the operands that the caller
  // has already evaluated (`evaluatedOps`): the cell is an absent point only
  // when the evaluated cell at the same position in one of those lists, or a
  // row that holds it, is an absent symbol (a restriction whose condition is
  // false evaluates to `Missing`). Another `NaN` cell is a computed value and
  // is kept: `[(1, 2){c}, (3, 4)] / [1, NaN]` with `c` true is
  // `[(1, 2), NaN]`. Nothing is evaluated here: a second evaluation would
  // repeat the work of the caller and could run an effect again. A caller
  // that applies the operator to each cell separately does not pass the
  // operands: there, the application of a cell to an absent point answers
  // `Missing` itself.
  if (evaluatedOps === undefined || !cellsArePoints(expression.type.type))
    return result;
  // Whether the evaluated cell of `op` at `path` is absent. The walk follows
  // `List`s only. An absent symbol on the way decides for every cell it
  // holds: an absent row, or an absent operand that stood for a whole list
  // (`If(c, [P, Q]) / [1, 1]` with `c` false).
  const absentAt = (op: Expression, path: readonly number[]): boolean => {
    let node: Expression | undefined = op;
    for (let depth = 0; ; depth++) {
      if (isAbsentScalarSymbol(node!)) return true;
      if (depth === path.length || !isFunction(node, 'List')) return false;
      node = node.ops[path[depth]];
      if (node === undefined) return false;
    }
  };
  const markAt = (x: Expression, path: number[]): Expression =>
    isFunction(x, 'List')
      ? ce._fn(
          'List',
          x.ops.map((y, i) => {
            if (isNaNCell(y))
              return evaluatedOps.some((op) => absentAt(op, [...path, i]))
                ? ce.Missing
                : y;
            return isFunction(y, 'List') ? markAt(y, [...path, i]) : y;
          })
        )
      : x;
  return hasNaNCell(result) ? markAt(result, []) : result;
}

// ————————————————————————————————————————————————————————————————————————
// Generic runtime conformance (R1/R8 — §4.4 of
// `docs/plans/2026-08-22-type-handlers-on-types.md`)
//
// With overlap admission at boxing, a handler can receive a concrete
// wrong-kind value through a permissively-typed operand (an `any`-typed
// symbol, or a symbolic argument admitted because its type merely OVERLAPS
// the parameter). Handlers were written trusting the strict boxing gate to
// never hand them such a value — the `toBigint` family silently rounds
// (`FactorInteger(2.5)` → `[(3, 1)]`). This check runs at non-lazy dispatch,
// on the EVALUATED arguments, before the handler: a concrete value that does
// not conform produces the same `incompatible-type` error value the static
// gate produces for a literal, so the two routes agree; a still-symbolic
// argument is left alone (the application stays inert or the handler
// decides).
// ————————————————————————————————————————————————————————————————————————

/** Parameter positions the generic runtime conformance check does NOT
 * police:
 *
 * - **Function-kind** (bare `function`, a signature, or a union with such an
 *   arm): admission is Design E compatibility, and the application itself
 *   checks arity and argument types when the callback is applied.
 * - **Pure collection-kind** (`list`, `set`, `collection`,
 *   `indexed_collection`, `dictionary`, `tuple`, `record` — EVERY union arm
 *   one of these): runtime conformance is the operator's own evaluate-time
 *   gate (§D6.2 handler precedence — `expected-square-matrix` and friends),
 *   and several handlers deliberately accept lenient spellings (a `List`
 *   where a `tuple` shape is declared, a scalar as a 1×1 matrix). A MIXED
 *   union (`number | list<number>` — the Histogram/BinCounts bin-spec) is
 *   NOT exempt: its scalar arm is this check's to police (a string bin-spec
 *   used to be iterated character-by-character into NaN bin edges), and only
 *   a collection-SHAPED value at it is left to the handler — the per-value
 *   rule in `runtimeConformanceError`. `range` is not collection-kind here:
 *   no handler-owned gate polices a range parameter (D6.2 does not defer
 *   them), so a concrete wrong-kind value at one — a string at `Slice`'s
 *   span — is this check's to refuse.
 * - **Open generic parameters**: a free type variable cannot be judged
 *   without instantiation (the ground-type invariant — `admissionOf` asserts
 *   on an open type).
 * - `any`/`unknown` (including via a union arm): they admit every value, so
 *   exempting them is a pure fast path.
 *
 * The same classifier scopes the R1 STATIC overlap admission
 * (`overlapAdmission` below) and is exported so the conformance fuzz
 * (`runtime-conformance-fuzz.test.ts`) probes exactly the positions this
 * check polices — one implementation for all three, so they can never
 * disagree. */
const COLLECTION_PARAM_KINDS = new Set([
  'list',
  'set',
  'collection',
  'indexed_collection',
  'dictionary',
  'tuple',
  'record',
]);
function paramArms(t: Type): Type[] {
  const r = resolveTypeAlias(t);
  if (typeof r !== 'string' && r.kind === 'union')
    return (r.types as Type[]).map((a) => resolveTypeAlias(a));
  return [r];
}
function isCollectionKindArm(a: Type): boolean {
  return typeof a === 'string'
    ? COLLECTION_PARAM_KINDS.has(a)
    : COLLECTION_PARAM_KINDS.has(a.kind);
}

/**
 * Whether the overlap deferral (`overlapsForDeferredValidation`) admits the
 * operand `op` at the parameter `param`.
 *
 * The deferral admits a record type at a `dictionary<V>` parameter when
 * each required field can hold a `V`: `record{a: number, b: string?}` holds
 * `{a: 1}`, a `dictionary<integer>`. But the record type also holds values
 * that are not dictionaries of `V` (`{a: 1, b: "x"}`), and a dictionary
 * parameter is exempt from the runtime conformance check
 * (`runtimeCheckExemptParam`), so nothing checks the value later. A symbol
 * that HOLDS a dictionary value is therefore judged by the type of that
 * value, which lists its fields: with `r: record{a: number, b: string?}`
 * holding `{a: 1, b: "x"}`, `f(r)` for `f: (dictionary<integer>) -> integer`
 * is refused, and with `r` holding `{a: 1}` it is admitted. A symbol with no
 * value is admitted on the overlap of its type.
 */
function admittedByDeferredOverlap(op: Expression, param: Type): boolean {
  if (!overlapsForDeferredValidation(op.type.type, param)) return false;
  if (pointComponentRefuted(op, param)) return false;
  if (!isSymbol(op)) return true;
  const isRecordArm = (a: Type) =>
    a === 'record' || (typeof a !== 'string' && a.kind === 'record');
  const isDictionaryArm = (a: Type) =>
    a === 'dictionary' || (typeof a !== 'string' && a.kind === 'dictionary');
  if (!paramArms(param).some(isDictionaryArm)) return true;
  if (!paramArms(op.type.type).some(isRecordArm)) return true;
  const held = op.valueDefinition?.value;
  if (held === undefined || held === op) return true;
  const heldType = held.type.type;
  if (!paramArms(heldType).some(isRecordArm)) return true;
  return (
    isSubtype(heldType, param) || overlapsForDeferredValidation(heldType, param)
  );
}

/**
 * Whether `op` is a `Tuple` that every arm of the parameter type `param`
 * refuses, and at least one arm refuses it by a component: a tuple arm of
 * the arity of the point (`tuple<integer, integer>`) refuses the point when
 * the type of a position refutes the component there (`admissionOf()` in
 * `value-membership.ts`), and every other arm (`string`, a tuple of another
 * arity) refuses it when its type does not overlap the type of the point.
 * A concrete component is decided by its value:
 * `1.5` is refuted at `integer`. A symbolic component is refuted only when
 * its type is provably disjoint from the type of its position. A symbol
 * that holds a `Tuple` is judged by that tuple, as a symbol that holds a
 * number is judged by the number at a scalar parameter (`concreteValueOf()`
 * follows a symbol to a held number, but not to a held tuple).
 *
 * The type of the tuple `(1.5, 2)` is `tuple<real, integer>`, which overlaps
 * `tuple<integer, integer>`, so the overlap deferral alone admits it. A
 * tuple parameter is exempt from the runtime conformance check
 * (`runtimeCheckExemptParam`), and the evaluation of a call checks its
 * arguments with the same argument check, so nothing refused the point
 * later: with `U: (tuple<integer, integer>) -> integer` and the body
 * `p ↦ p.x`, `U((1.5, 2))` was valid, typed `integer`, and gave `1.5`. With
 * this test, the call is an `incompatible-type` error when it is boxed, for
 * the literal `(1.5, 2)` and for a symbol that holds it, and when it is
 * evaluated, for an argument that evaluates to such a tuple.
 *
 * A union parameter refuses the point only when each of its arms refuses
 * it: with `F: (tuple<integer, integer> | string) -> unknown`,
 * `F((1.5, 2))` is refused, because the tuple arm refutes the first
 * component and a string is not a tuple. A union with an arm that the point
 * can fit (`tuple<integer, integer> | tuple<real, real>`, or `collection`)
 * admits it. Before, only one tuple type was checked, and a function with
 * such a union parameter and the body `p ↦ p` returned `(1.5, 2)` unchanged.
 *
 * A call that maps over a list of points uses the same test for each point
 * it binds (`fitsPointSlot()` in `boxed-function.ts`), so a point gets the
 * same answer as the whole argument and as an element of a list.
 */
export function pointComponentRefuted(op: Expression, param: Type): boolean {
  const held = isSymbol(op) ? op.valueDefinition?.value : undefined;
  const point = held !== undefined && held !== op ? held : op;
  if (!isFunction(point, 'Tuple')) return false;
  let refutedByTupleArm = false;
  for (const arm of paramArms(resolveTypeReference(param) ?? param)) {
    const slot = resolveTypeReference(arm) ?? arm;
    if (
      typeof slot !== 'string' &&
      slot.kind === 'tuple' &&
      slot.elements.length === point.nops
    ) {
      if (
        !point.ops.some(
          (c, k) => admissionOf(c, slot.elements[k].type) === 'refute'
        )
      )
        return false;
      refutedByTupleArm = true;
    } else if (typesOverlap(point.type.type, slot)) return false;
  }
  return refutedByTupleArm;
}

const MATRIX_OF_INTEGERS = parseType('matrix<integer>');
const LIST_OF_NUMBERS = parseType('list<number>');

/**
 * Whether the parameter type `param` has an arm that is a matrix type, or a
 * tensor type that accepts a matrix of integers: `matrix`, `matrix | vector`,
 * `number | tensor`.
 *
 * A type that accepts a matrix only because it accepts every value, or every
 * list, has no matrix arm: `any`, `unknown`, `value`, `expression`, `list`,
 * `collection` and `list<any>` give `false`. A list of `Range` rows is read
 * as a matrix only at a parameter that asks for a matrix. At a parameter of
 * the other kinds, the list is an ordinary value and stays as it is.
 */
export function hasMatrixArm(param: Type): boolean {
  return paramArms(param).some(
    (arm) =>
      typeof arm !== 'string' &&
      arm.kind === 'list' &&
      arm.dimensions !== undefined &&
      isSubtype(MATRIX_OF_INTEGERS, arm)
  );
}

/**
 * Whether the operand `op` is a list of `Range` rows (`[1..2, 3..4]`, typed
 * `list<range>`) at a parameter `param` of a library operator that has a
 * matrix arm (`matrix`, `matrix | vector`, `number | tensor`; see
 * `hasMatrixArm()`).
 *
 * A `Range` element of a `List` stays a range, so the type of such a list is
 * `list<range>`. This type has no dimensions, so it does not match a matrix
 * type. But a list of finite ranges of the same length is a matrix of
 * integers: each range is a row (user decision 2026-10-26). The operand is
 * admitted, and the list keeps its value and its type. The evaluate handler
 * of the operator lists the rows (`rangeRowsAsMatrix()`,
 * `library/linear-algebra.ts`) and refuses a value that is not a matrix: rows
 * of different lengths, an infinite range, or too many cells.
 *
 * The elements must all be ranges or lists of numbers, and at least one
 * must be a range: `list<range | vector<integer^2>>` is admitted. A
 * parameter of a user function is not included: its declared type is the
 * type of the value that the body receives, and a list of ranges is not a
 * value of a matrix type.
 */
function admitsRangeRowsAsMatrix(
  op: Expression,
  param: Type,
  internals: ValidateArgumentsInternals | undefined
): boolean {
  if (internals?.userFunction === true) return false;
  if (!hasMatrixArm(param)) return false;
  const t = resolveTypeAlias(op.type.type);
  if (typeof t === 'string' || t.kind !== 'list' || t.dimensions !== undefined)
    return false;
  const element = t.elements;
  return (
    isSubtype(element, LIST_OF_NUMBERS) &&
    paramArms(element).some((arm) => arm === 'range')
  );
}

/**
 * True when a parameter is a UNION that mixes CALLABLE arms with VALUE arms
 * and every value arm is numeric — the shape of a "size or predicate"
 * parameter, such as `Partition`'s `integer | ((T) any -> boolean)`.
 *
 * Such a parameter is exempt from the static overlap admission below because
 * of its callable arm, and the exemption is right for a CALLABLE operand: the
 * arrow-slot rules (Design E) are the authority there. It was wrong for
 * everything else. A slot declared with a plain numeric type admits an
 * operand typed `integer | missing` — the type of a default-less piecewise —
 * because the two overlap, and defers the verdict to the runtime conformance
 * check; the union spelling refused the identical operand at canonicalization,
 * so `Partition(xs, k)` errored where its `Take`/`Chunk`/`Drop` siblings, whose
 * size parameter is a plain `integer`, admitted it. Letting such a parameter
 * reach the overlap admission restores the parity: an operand that overlaps
 * the numeric arms is admitted and re-checked when its value settles, and one
 * that overlaps nothing (a string, a proven `Missing`) is still refused here.
 *
 * A single non-numeric value arm disqualifies the parameter: the admission
 * must not loosen a slot whose other arms police a shape — a collection, a
 * string — that the numeric reasoning above says nothing about.
 */
function unionOfCallableAndNumericArms(t: Type): boolean {
  const r = resolveTypeAlias(t);
  if (typeof r === 'string' || r.kind !== 'union') return false;
  let callable = false;
  let numeric = false;
  for (const arm of paramArms(r)) {
    if (
      arm === 'function' ||
      (typeof arm !== 'string' && arm.kind === 'signature')
    ) {
      callable = true;
      continue;
    }
    if (!isSubtype(arm, 'number')) return false;
    numeric = true;
  }
  return callable && numeric;
}

export function runtimeCheckExemptParam(t: Type): boolean {
  if (freeTypeVariables(t).size > 0) return true;
  const arms = paramArms(t);
  if (
    arms.some(
      (a) =>
        a === 'function' ||
        a === 'any' ||
        a === 'unknown' ||
        (typeof a !== 'string' && a.kind === 'signature')
    )
  )
    return true;
  return arms.every(isCollectionKindArm);
}

/** One checkable parameter position: its (instantiated, ground) type, plus
 * whether the type has a collection-kind arm — a collection-SHAPED value at
 * such a position belongs to the handler's own gate, not to this check. */
type RuntimeCheckParam = { t: Type; collectionArm: boolean };

/** One overload arm of a signature, with each exempt parameter position
 * blanked to `null` so the per-dispatch walk tests nothing there, and the
 * arm's arity bounds so an arm that cannot take the call's operand count is
 * never consulted (a shorter arm's prefix must not mask the correctly-sized
 * arm's remaining positions). */
type RuntimeConformanceArm = {
  req: (RuntimeCheckParam | null)[];
  opt: (RuntimeCheckParam | null)[];
  varParam: RuntimeCheckParam | null;
  /** Required operand count. */
  minArity: number;
  /** Maximum operand count; `Infinity` for a variadic arm. */
  maxArity: number;
};

type RuntimeConformancePlan = {
  /** Identity guard: a definition whose signature was replaced gets a fresh
   * plan (the cache key is the definition object, which outlives it). */
  signature: BoxedType;
  /** `null` when no position of any arm is checkable — dispatch then skips
   * the walk entirely (the common case for `(any*)`-style signatures). */
  arms: RuntimeConformanceArm[] | null;
};

const runtimeConformancePlans = new WeakMap<object, RuntimeConformancePlan>();

function runtimeConformanceArms(
  cacheKey: object,
  signature: BoxedType
): RuntimeConformanceArm[] | null {
  const cached = runtimeConformancePlans.get(cacheKey);
  if (cached !== undefined && cached.signature === signature)
    return cached.arms;

  const sig = signature.type;
  let sigArms: readonly FunctionSignature[] | null = null;
  if (typeof sig !== 'string') {
    if (sig.kind === 'signature') sigArms = [sig];
    else sigArms = overloadArms(sig) ?? null;
  }

  const blank = (t: Type): RuntimeCheckParam | null =>
    runtimeCheckExemptParam(t)
      ? null
      : { t, collectionArm: paramArms(t).some(isCollectionKindArm) };
  let arms: RuntimeConformanceArm[] | null = null;
  if (sigArms !== null && sigArms.length > 0) {
    arms = sigArms.map((a) => {
      const req = (a.args ?? []).map((x) => blank(x.type));
      const opt = (a.optArgs ?? []).map((x) => blank(x.type));
      return {
        req,
        opt,
        varParam:
          a.variadicArg === undefined ? null : blank(a.variadicArg.type),
        minArity: a.args?.length ?? 0,
        maxArity:
          a.variadicArg !== undefined
            ? Infinity
            : (a.args?.length ?? 0) + (a.optArgs?.length ?? 0),
      };
    });
    if (
      !arms.some(
        (p) =>
          p.varParam !== null ||
          p.req.some((x) => x !== null) ||
          p.opt.some((x) => x !== null)
      )
    )
      arms = null;
  }
  runtimeConformancePlans.set(cacheKey, { signature, arms });
  return arms;
}

/** The parameter governing operand position `i` of `arm`, or `null` when
 * that position is exempt or beyond the declared arity (excess operands are
 * boxing's business — see `checkArity`). */
function armParamAt(
  arm: RuntimeConformanceArm,
  i: number
): RuntimeCheckParam | null {
  if (i < arm.req.length) return arm.req[i];
  const j = i - arm.req.length;
  if (j < arm.opt.length) return arm.opt[j];
  return arm.varParam;
}

/**
 * The generic runtime conformance check (§4.4): test each EVALUATED operand
 * against the declared signature and return the `incompatible-type` error
 * value for the first refuted position — or `undefined` when the call
 * conforms (which includes every undecidable case).
 *
 * Verdict per operand, mirroring the static gate's admission on a literal:
 * - an error value is never re-blamed (it is already the diagnosis);
 * - a collection-shaped value at a broadcastable operator belongs to the
 *   broadcast machinery, not to this check — and at a MIXED parameter with
 *   a collection arm (`number | list<number>`), to the handler's own gate;
 * - a still-symbolic value is left alone. "Still symbolic" means no
 *   `concreteValueOf` AND not the ground `Nothing` symbol: `Nothing` is a
 *   fully-evaluated unit value that `admissionOf` refutes by provable
 *   disjointness, exactly as the static gate refuses the literal
 *   (`Missing`, by contrast, stays the missing-behavior gate's business —
 *   step 4a of the dispatch runs before this check);
 * - a decidable value decides exactly through `admissionOf` (membership for
 *   value components, synthesized-type subtyping otherwise).
 *
 * For an overload set, the first ARITY-ELIGIBLE arm every decidable operand
 * satisfies wins (a symbolic operand satisfies any arm); an arm whose arity
 * bounds cannot take the call is never consulted, so a shorter arm's prefix
 * does not mask the correctly-sized arm's remaining positions. Only when NO
 * eligible arm accepts is the error minted, against the union of the arms'
 * parameters at the first universally-refuted position (§4.4:
 * "incompatible-type against the declared union"). No boxing-pass window:
 * nothing here writes.
 *
 * Arity is deliberately not re-checked as such: boxing normalizes it, and a
 * `Spread` call re-boxes after splicing (`_spliceSpreadOps`), which re-runs
 * the full static validation on the spliced operands. When no arm's bounds
 * fit the operand count, this check stands down rather than minting an
 * arity error of its own.
 *
 * When `operator` is given, the error carries the breadcrumb frame of that
 * operator at the 1-based position of the refused operand. A literal
 * argument of the wrong type (`Ln("s")`) makes the node invalid when it is
 * boxed, and the error of that node gets the frame `Ln` argument 1. An
 * argument whose VALUE has the wrong type (`Ln(w)` with `w = "s"`) is
 * refused only here, at evaluation. Without the frame, the error of
 * `3 - Ln(w)` would have only the frames of `Negate` and `Add`, and would
 * name no call of `Ln`.
 */
export function runtimeConformanceError(
  ce: ComputeEngine,
  cacheKey: object,
  signature: BoxedType,
  broadcastable: boolean,
  ops: ReadonlyArray<Expression>,
  /** Contract B per-slot NaN policy (`docs/ERROR-MODEL.md` §4): a
   * proven-`NaN` operand in a `propagate`/`handle` slot was ADMITTED past
   * the carrier at boxing, so re-testing it here must not refute what the
   * policy admitted — the policy gate (dispatch step 4a-0) and the handler
   * own it. Mirrors `nanPolicyAdmitsParam` on the static route. */
  nanPolicyAt?: (index: number) => 'reject' | 'propagate' | 'handle' | 'inert',
  /** The name of the operator whose call is checked, for the breadcrumb
   * frame of the error. */
  operator?: string
): Expression | undefined {
  if (ops.length === 0) return undefined;
  const allArms = runtimeConformanceArms(cacheKey, signature);
  if (allArms === null) return undefined;
  const arms = allArms.filter(
    (a) => ops.length >= a.minArity && ops.length <= a.maxArity
  );
  if (arms.length === 0) return undefined;

  // The verdict for one operand against one (non-null) parameter:
  // `true` = this operand refutes the parameter.
  const refutes = (
    op: Expression,
    param: RuntimeCheckParam,
    idx: number
  ): boolean => {
    if (!op.isValid) return false;
    // The concrete-value gate comes first: a symbolic operand (an
    // application that did not evaluate to a literal) is never refuted, and
    // the two gates below it read the operand's type — a derivation nothing
    // else needs for such an operand. Every gate here answers `false` on
    // its own, so their order does not change the answer.
    const v = concreteValueOf(op);
    if (v === undefined && !isSymbol(op, 'Nothing')) return false;
    if (broadcastable && couldBeUnkeyedCollectionOperand(op)) return false;
    // Contract B NaN admission — see the `nanPolicyAt` parameter above.
    if (op.isNaN === true && nanPolicyAt !== undefined) {
      const policy = nanPolicyAt(idx);
      if (policy === 'propagate' || policy === 'handle') return false;
    }
    // A collection-shaped value at a parameter with a collection arm is the
    // handler's to judge (lenient spellings, element-wise gates).
    if (
      param.collectionArm &&
      v !== undefined &&
      (isFunction(v, 'List') || isFunction(v, 'Tuple'))
    )
      return false;
    return admissionOf(op, param.t) === 'refute';
  };

  let anyRefuted = false;
  for (const arm of arms) {
    let accepted = true;
    for (let i = 0; i < ops.length; i++) {
      const param = armParamAt(arm, i);
      if (param === null) continue;
      if (refutes(ops[i], param, i)) {
        accepted = false;
        anyRefuted = true;
        break;
      }
    }
    if (accepted) return undefined;
  }
  if (!anyRefuted) return undefined;

  // No arm accepts. Blame the first position every arm refutes; the
  // expected type is the union of the arms' parameters there. (With mixed
  // refutations across arms — no universally-refuted position — fall back
  // to the first arm's first refuted position.)
  const refusal = (expected: Type, i: number): Expression => {
    const err = ce.typeError(expected, ops[i].type, ops[i]);
    if (operator === undefined) return err;
    return withErrorFrames(err, [{ operator, index: i + 1 }]);
  };
  for (let i = 0; i < ops.length; i++) {
    const params = arms.map((a) => armParamAt(a, i));
    if (params.some((p) => p === null || !refutes(ops[i], p, i))) continue;
    const expected: Type =
      params.length === 1
        ? params[0]!.t
        : reduceType({ kind: 'union', types: params.map((p) => p!.t) });
    return refusal(expected, i);
  }
  for (let i = 0; i < ops.length; i++) {
    const param = armParamAt(arms[0], i);
    if (param !== null && refutes(ops[i], param, i)) return refusal(param.t, i);
  }
  return undefined;
}

/**
 * Check that an argument is of the expected type.
 *
 * Converts the arguments to canonical
 */

/**
 * True when the element type of the declared parameter `param` is ground or
 * a bare type variable (`list<T>`, `indexed_collection<T>`), or `param` has
 * no element type (a bare `T`, whose bound is read as a whole). Then reading
 * the variable as its bound gives a requirement on the elements: the
 * variable is covariant there. A variable deeper in the element type (under
 * a function type, or in a named type that is not covariant) is not.
 *
 * A tuple parameter has one element type per slot, and each slot is
 * covariant, so each slot is tested by itself: `tuple<T, U>` and
 * `tuple<T, integer>` qualify. A slot that holds a variable under a
 * constructor (`tuple<list<T>, U>`, `tuple<tuple<T, U>, V>`) is not tested
 * further, so the whole parameter fails the test and distributes nothing,
 * not even to its bare slots: this writes less than it could, and is
 * sound. The element type of the tuple (`collectionElementType()`) is not
 * used: it is the union of the slots, which is never a bare variable when
 * two slots differ.
 */
function elementIsBareOrGround(param: Type | undefined): boolean {
  if (param === undefined || freeTypeVariables(param).size === 0) return true;
  if (typeof param === 'object' && param.kind === 'variable') return true;
  const isBareOrGround = (t: Type): boolean =>
    freeTypeVariables(t).size === 0 ||
    (typeof t === 'object' && t.kind === 'variable');
  if (typeof param === 'object' && param.kind === 'tuple')
    return param.elements.every((slot) => isBareOrGround(slot.type));
  const element = collectionElementType(param);
  if (element === undefined) return false;
  return isBareOrGround(element);
}

/**
 * PHASE 2 of `docs/INFERENCE_ROADMAP.md` (2026-08-18): distribute a
 * collection parameter's ELEMENT type onto the symbol elements of a
 * List/Tuple LITERAL operand, so `f([a, b])` against `(list<number>) -> …`
 * infers `a: number` and `b: number` — the same write `f(a)` would make,
 * which previously died at the literal's boundary. Conservative: only
 * literal List/Tuple operands, only SYMBOL elements, and only a usable
 * element type (`unknown`/`any` distribute nothing).
 *
 * An element that is itself a List/Tuple literal receives the element type
 * in the same way: a row of a `matrix` parameter must be a vector, so
 * `PseudoInverse([[x, y], [z, w]])` infers `x`, `y`, `z` and `w` as
 * numbers. Another application keeps its own inference. A literal list does
 * not infer its free symbols by itself (`narrowFreeSymbolCells()`,
 * `canonical-utils.ts`): only a parameter that requires a type of its
 * elements does.
 *
 * A union parameter (`collection<nothing | number> | number` at `Median`)
 * distributes the element type of its one arm that admits a list literal,
 * and nothing when several arms admit one. A tensor parameter of unknown rank
 * (`tensor`, `tensor<integer>`) distributes nothing: its element type
 * `T | tensor<T>` admits a list, so a cell of that type would remove the
 * shape of the literal. A valueless symbol cell gets the
 * element type without its `nothing` member, and a symbol cell that holds a
 * value gets no type (`symbolCellType()`).
 */
function distributeLiteralElementInference(op: Expression, param: Type): void {
  if (!isFunction(op, 'List') && !isFunction(op, 'Tuple')) return;
  if (typeof param === 'string') return;
  const resolved = resolveTypeAlias(param);
  if (typeof resolved === 'object' && resolved.kind === 'union') {
    // A union parameter (`collection<number> | distribution | number` at
    // `Mean`) has no element type of its own. When exactly one arm admits
    // a list of any contents, the call is admitted through that arm, and
    // that arm gives the element type: `Mean([p, q])` infers `p` and `q` as
    // numbers. The test does not read the type of the literal, which reads a
    // free symbol as a number cell: `p` and `q` can be lists, and then
    // `[p, q]` is a matrix, not a vector. So `matrix | vector`
    // (`MatrixMultiply`) has two arms that admit a list, and it distributes
    // nothing. A tuple literal is tested against `tuple` in the same way,
    // but a tuple of symbols without a type is not admitted by its type, so
    // this pass does not run on it (see the tuple branch below), and
    // `Mean((w1, w2))` leaves `w1` unknown.
    const literal = op.operator === 'Tuple' ? 'tuple' : 'list';
    const arms = resolved.types.filter((arm) => typesOverlap(literal, arm));
    if (arms.length === 1) distributeLiteralElementInference(op, arms[0]);
    return;
  }
  if (op.operator === 'Tuple' && param.kind === 'tuple') {
    // Per-slot for a tuple parameter of matching arity. NOTE: this fires
    // only when the tuple literal was GENUINELY admitted; a tuple of
    // unknown-typed symbols fails `matches` against a concrete tuple
    // parameter and is only provisionally re-admitted by the free-variable
    // un-rejection in `box.ts` — the final inference pass (this helper's
    // caller) deliberately does not run on that path, because writing slot
    // types from an unproven admission would be inference from a guess.
    if (param.elements.length !== op.nops) return;
    op.ops.forEach((el, i) => {
      const slot = param.elements[i].type;
      if (slot === 'unknown' || slot === 'any') return;
      if (isSymbol(el)) {
        const cell = symbolCellType(el, slot);
        if (cell !== undefined && cell !== 'never')
          el._infer(() => cell, 'narrow');
      } else distributeLiteralElementInference(el, slot);
    });
    return;
  }
  // A tensor of unknown rank (`tensor`, at `Trace`) has the element type
  // `number | tensor`: a cell can be a number or a tensor, as for the
  // parameter `matrix | vector` above. That type requires nothing that the
  // literal does not already show, and a cell typed `number | tensor` can
  // be a list, so the literal loses its shape: after `Trace([[a, b], [c,
  // d]])`, `[[a, b], [c, d]]` was typed `list<list<number | tensor>>`, not
  // `matrix<2x2>`, and `Trace`, `Determinant` and `Inverse` stayed
  // unevaluated for the rest of the session. So it distributes nothing.
  // (GitHub issue #505.)
  if (
    typeof resolved === 'object' &&
    resolved.kind === 'list' &&
    resolved.dimensions === null
  )
    return;
  const element = collectionElementType(param);
  if (element === undefined || element === 'unknown' || element === 'any')
    return;
  for (const el of op.ops)
    if (isSymbol(el)) {
      const cell = symbolCellType(el, element);
      if (cell !== undefined && cell !== 'never')
        el._infer(() => cell, 'narrow');
    } else distributeLiteralElementInference(el, element);
}

/**
 * The type that `distributeLiteralElementInference()` writes on the symbol
 * cell `el` for the element type `element`.
 *
 * A `nothing` member of the element type (`collection<nothing | number>` at
 * `Mean`) admits a cell that is omitted, but the use of a valueless symbol
 * there is no evidence that the symbol holds `Nothing`: `Mean([p, q])` gives
 * `p` the type `number`, not `nothing | number`.
 *
 * A symbol that holds a value gets no type (the result is `undefined`): the
 * type of its value is the evidence, not the parameter it fills. After
 * `p := Nothing`, `Mean([p, 1])` keeps the type `nothing` of `p`; the meet of
 * `nothing` and `number` is `never`, a type that does not hold its value.
 * The call is then checked against the value as usual.
 */
function symbolCellType(el: Expression, element: Type): Type | undefined {
  if (isSymbol(el) && el.valueDefinition?.value !== undefined) return undefined;
  return withoutNothing(element);
}

/**
 * The EVIDENCE-BEATS-REQUIREMENT decision at a narrow-eligible slot
 * (`docs/INFERENCE_ROADMAP.md`, Phase 0 guard, 2026-08-18). Called once the
 * caller has established the narrow preconditions (inferred type, `param`
 * strictly below the stored type, no value component, effects preserved):
 *
 * - `'narrowed'` — the symbol is VALUELESS (and carries no static
 *   assignment evidence): the CAS reading applies, the use declares, and
 *   the type was narrowed to `param`.
 * - `'admitted'` — the symbol has evidence (a held value, or the Epsil
 *   static pre-pass's assignment record) whose RAW type fits `param`:
 *   admit without an eager write (the post-validation pass may sharpen).
 * - `'fall-through'` — the evidence does not fit: the caller must fall
 *   through to its ordinary rejection path.
 *
 * Shared by the REQUIRED, OPTIONAL and VARIADIC parameter loops — the guard
 * lived only in the required loop at first, so an assigned symbol passed
 * through an optional or variadic slot could still be silently rewritten.
 */
function evidenceGuardedNarrow(
  ce: ComputeEngine,
  op: Expression,
  param: Type,
  noInference = false
): 'narrowed' | 'admitted' | 'fall-through' {
  // A free name (`isFreeName()`) reads the definition that it resolves to,
  // and with none it is valueless.
  const def = resolvedValueDefinition(op);
  const held = def?.value;
  if (held === undefined) {
    // A valueless symbol is admitted; in check-only mode it is admitted
    // without the narrowing write.
    if (!noInference) op._infer(() => param, 'narrow');
    return 'narrowed';
  }
  const evidenceType = held.type.type;
  return isSubtype(evidenceType, param) ? 'admitted' : 'fall-through';
}

/**
 * The type an INFERRED symbol type is narrowed to at a parameter, or
 * `undefined` when no narrowing applies.
 *
 * - When the parameter is a subtype of the current type, the target is the
 *   parameter itself (`B` inferred `value`, later required `set`).
 * - When the current type is a UNION that the parameter does not admit as a
 *   whole, but the parameter admits some of its members, the target is the
 *   union of those members. Example: a valueless `s` used at a text
 *   parameter (`ToUpperCase(s)`) is inferred `character | string`; a later
 *   `Sort(s)` requires `indexed_collection`, which admits `string` but not
 *   `character`, so `s` narrows to `string`. A use of a valueless symbol is
 *   a requirement on it, and two requirements together allow only the
 *   members that satisfy both: this is the meet of the requirements, as the
 *   use-bound model in `docs/INFERENCE_ROADMAP.md` (section 2b) describes.
 *   Without this, the result of a program depended on the order of the
 *   uses: `(Sort(s), ToUpperCase(s))` was accepted and
 *   `(ToUpperCase(s), Sort(s))` was refused.
 *
 * Only whole members are kept, so the target is always a subtype of both
 * the current type and the parameter. A member that the parameter admits
 * only in part (`list<number>` at `list<integer>`) is dropped, not
 * sharpened. The caller applies this only to an inferred type: a DECLARED
 * union is a contract, and a parameter that does not admit all of it is
 * still an error.
 */
function inferredNarrowTarget(current: Type, param: Type): Type | undefined {
  if (isSubtype(param, current)) return param;
  if (typeof current === 'string' || current.kind !== 'union') return undefined;
  const admitted = current.types.filter((member) => isSubtype(member, param));
  if (admitted.length === 0 || admitted.length === current.types.length)
    return undefined;
  return widenAll(admitted);
}

/**
 * Whether the STRICT pass of an overload trial refuses `op` at `param`: the
 * operand is typed `error` but holds no error value (a symbol declared
 * `error` with no value, see `isErrorTypedWithoutErrorValue()`) and the
 * parameter reads `unknown` (an absorbed type variable, or a declared
 * `unknown` slot). Such an operand only OVERLAPS the parameter, and the
 * design admits it on the second, overlap pass (`overlapAdmission` below),
 * where a generic arm's result is then read at the bound of its variable
 * (`undecidedResultOf`, `overload.ts`): `Reverse(e)` is typed `string`.
 * Before `error <: unknown` held (user decision D1, 2026-10-21), the plain
 * subtype test refused the operand on the strict pass; this keeps that
 * verdict, which the relation no longer gives. Outside a trial nothing
 * changes: a plain call admits the operand as before.
 */
function strictTrialRefusesUnheldError(
  op: Expression,
  param: Type,
  internals: ValidateArgumentsInternals | undefined
): boolean {
  return (
    internals?.trial === true &&
    internals.overlapTrial !== true &&
    isErrorTypedWithoutErrorValue(op) &&
    paramArms(param).some((a) => a === 'unknown')
  );
}

/**
 * R1 overlap admission (§4.4 of
 * `docs/plans/2026-08-22-type-handlers-on-types.md`) — the verdict for
 * "every other parameter" once the specialized admissions (arrow slots,
 * value components, deferred collections, placeholder signatures) have
 * declined:
 *
 * - a CONCRETE argument decides exactly: a held value satisfying the
 *   parameter admits the operand even though its declared type does not
 *   (`n: number` holding `2` at an `integer` slot), and a wrong one keeps
 *   the boxing-time refusal (`FactorInteger("abc")` is still an error at
 *   boxing);
 * - a SYMBOLIC argument admits iff its type OVERLAPS the parameter — the
 *   two share an inhabitant (`number` at a `complex` slot, they share
 *   `complex`) — deferring the decision to the runtime
 *   conformance check at dispatch (`runtimeConformanceError`); `string` at
 *   `integer` shares nothing and still refuses at boxing.
 *
 * Admission is provisional either way — callers record the position in
 * `deferredIdx` so the final `_infer(param)` narrowing does not write on a
 * guess.
 *
 * Two scoping rules, both load-bearing:
 *
 * - The admission applies only at parameters the runtime conformance check
 *   polices (`runtimeCheckExemptParam` is the shared classifier): the
 *   specialized admissions that already declined are the AUTHORITY for
 *   their kinds — re-admitting after `overlapsForDeferredValidation`
 *   refuted a collection would undo D6.2: `typesOverlap` reads
 *   `list<list<string>> ∧ matrix` as inhabited (the empty list is a value
 *   of both), so without this rule `Determinant(lls)` with
 *   `lls: list<list<string>>` is admitted at boxing (measured 2026-10-25,
 *   `broadcast-shape-lift.test.ts`). `typesOverlap(list<number>, matrix)`
 *   is `false` (measured 2026-10-24), so a plain rank mismatch does not
 *   need the rule. Without the rule, the type of a self-referential alias
 *   at a collection parameter also overflows the stack
 *   (`tuple-shape-gates.test.ts`, measured 2026-10-25). Re-admitting after
 *   `arrowSlotAdmission` refused
 *   would undo Design E, and a nested `any` operand (`tuple<any>`) must stay
 *   refused at a tuple parameter (D8 waives a TOP-LEVEL `any` only; a
 *   nested `unknown` is deferred by `overlapsForDeferredValidation` itself
 *   since 2026-09-30 — `admission-gate-parity` pins both routes).
 * - Never inside a FIRST-PASS overload-resolution trial: arm viability
 *   keeps the strict reading, or a narrower arm becomes spuriously viable
 *   and captures the call — `p: ((integer) -> integer) & ((number) ->
 *   number)` applied to a declared `number` must keep selecting the number
 *   arm and type `number` (`overload-trials.test.ts`). When NO arm is
 *   strictly viable, resolution re-runs with the admission active
 *   (`overlapTrial`), and the selected arm's real validation admits — see
 *   the second-pass block in `validateArguments`.
 */

function overlapAdmission(op: Expression, param: Type): boolean {
  // A callable-plus-numeric union parameter is exempt from the classifier
  // only on account of its callable arm, which is no authority over a
  // non-callable operand — see `unionOfCallableAndNumericArms`. An operand
  // that could be callable does not reach this admission: `arrowSlotAdmission`
  // runs first at such a parameter and returns its own verdict — `admit` or a
  // minted error — for every operand it cannot prove non-callable.
  //
  // A parameter with an `unknown` arm is exempt from the classifier only
  // because it admits every value. An operand typed `error` that does not
  // hold an error value (a symbol declared `error` with no value, see
  // `isErrorTypedWithoutErrorValue()`) is not a subtype of `unknown`, but
  // its type overlaps every type, so such a parameter admits it, as a
  // `number` parameter does. Before, a library operator `(unknown) ->
  // unknown` and a function-literal parameter `a: unknown` refused it, while
  // a function name declared `(unknown) -> unknown` and a parameter `T`
  // with `T: unknown` admitted it.
  if (
    isErrorTypedWithoutErrorValue(op) &&
    paramArms(param).some((a) => a === 'unknown')
  )
    return true;
  if (runtimeCheckExemptParam(param) && !unionOfCallableAndNumericArms(param))
    return false;
  if (concreteValueOf(op) !== undefined)
    return admissionOf(op, param) === 'admit';
  // A symbol that holds a point is judged by that point, as the point
  // literal is (`pointComponentRefuted`): `concreteValueOf()` follows a
  // symbol to a held number, not to a held tuple, so without this test the
  // overlap of the types alone admits `r` holding `(1.5, 2)` at
  // `tuple<integer, integer> | string`, while the literal `(1.5, 2)` is
  // refused there, and `r` is refused at `tuple<integer, integer>` (a
  // parameter exempt from this admission, which the overlap deferral
  // decides). The call then failed only when it was evaluated.
  if (pointComponentRefuted(op, param)) return false;
  const opType = op.type.type;
  if (
    nonEmptyQuestionArms(opType).some(isCollectionTypeNode) &&
    !couldMatchNonEmpty(opType, param)
  )
    return false;
  return typesOverlap(opType, param);
}

/** Whether `t` is a list, set or abstract collection type node. */
function isCollectionTypeNode(t: Type): boolean {
  return (
    typeof t !== 'string' &&
    (t.kind === 'list' ||
      t.kind === 'set' ||
      t.kind === 'collection' ||
      t.kind === 'indexed_collection')
  );
}

/**
 * `checkType()` for an operand at a parameter of a LIBRARY operator that
 * checks its operands in its `canonical` handler: a value of a value kind
 * declared with `admittedAs: 'real'` or `'number'` is admitted where its
 * carrier is (`admitsThroughCarrier()`), as at a parameter that the
 * signature checks (`docs/plans/2026-10-26-value-kinds.md`, section 4.2,
 * group 3): `Rational(2.5 ± 0.1)`, `ND(f, 2.5 ± 0.1)`. Not for an
 * assignment or a declaration, where a measurement is refused by a `real`
 * type (section 4.2: admission is not subtyping).
 */
export function checkOperandType(
  ce: ComputeEngine,
  arg: Expression | undefined | null,
  type: Type
): Expression {
  if (arg !== undefined && arg !== null) {
    const x = arg.canonical;
    if (x.isValid && admitsThroughCarrier(ce, x.type.type, type)) return x;
  }
  return checkType(ce, arg, type);
}

export function checkType(
  ce: ComputeEngine,
  arg: Expression | undefined | null,
  type: Type | undefined
): Expression {
  if (arg === undefined || arg === null) return ce.error('missing');
  if (type === undefined)
    return ce.error('unexpected-argument', arg.toString());

  arg = arg.canonical;

  if (!arg.isValid) return arg;

  if (arg.type.matches(type)) return arg;

  // A one-cluster string literal at a `character` parameter narrows.
  const narrowed = narrowCharacterLiteral(ce, arg, type);
  if (narrowed !== undefined) return narrowed;

  // Value-component type (`0`, `integer<0..10>`): tri-state admission —
  // membership or undecidability admits; only proven refutation errors.
  // See `value-membership.ts`.
  if (hasValueComponent(type) && admissionOf(arg, type) !== 'refute')
    return arg;

  // Broadcastable operand: could be a plain scalar at runtime, admit it.
  if (broadcastableBaseMatches(arg.type.type, type)) return arg;

  // Function-typed operand with placeholder slots: see
  // `admitsPlaceholderSignature` below.
  if (admitsPlaceholderSignature(arg, type)) return arg;

  // Overlap-deferred validation (§D6.2) — see validateArguments.
  if (admittedByDeferredOverlap(arg, type)) return arg;

  // R1 overlap admission — see `overlapAdmission`.
  if (overlapAdmission(arg, type)) return arg;

  return ce.typeError(type, arg.type, arg);
}

/** The signature-kind arms a parameter type offers a function-typed operand:
 * the type itself when it is a signature, the signature members of a union.
 * Used by the placeholder-slot reconciliation below. */
function signatureArmsOf(param: Type): FunctionSignature[] {
  if (typeof param === 'object') {
    if (param.kind === 'signature') return [param];
    if (param.kind === 'union')
      return param.types.filter(
        (t): t is FunctionSignature =>
          typeof t === 'object' && t.kind === 'signature'
      );
  }
  return [];
}

/**
 * A function-typed operand whose INFERRED signature carries placeholder
 * `unknown` slots (inference put nothing there — e.g. `(x) => x` types as
 * `(unknown) -> unknown`) reconciles those slots at the argument boundary,
 * per the placeholder ruling (2026-08-15): each `unknown` slot adopts the
 * expected parameter signature's slot, and the operand is admitted on the
 * refined reading. This is what lets the identity lambda satisfy a parameter
 * declared `(any) -> any`. It cannot live in the raw subtype relation —
 * before the `any`/`unknown` lattice repair this admission rode on the
 * erroneous `any <: unknown` edge, which made `(unknown) -> unknown` a
 * mutual subtype of `(any) -> any`.
 */
function admitsPlaceholderSignature(op: Expression, param: Type): boolean {
  const opType = op.type.type;
  if (typeof opType !== 'object' || opType.kind !== 'signature') return false;
  for (const expected of signatureArmsOf(param)) {
    const refined = adoptTopPlaceholderSlots(opType, expected);
    if (refined !== opType && isSubtype(refined, expected)) return true;
  }
  return false;
}

/**
 * Does `param` expect a CHARACTER and refuse a string?
 *
 * True for the bare `character` type, and for a union that has a `character`
 * arm and no arm that already admits a string. An arm admitting the string
 * operand as-is means the call has a home for the literal as written, so
 * narrowing would silently resolve it to a DIFFERENT arm than the one the
 * author's value matched.
 *
 * "Admits a string" is tested with `isSubtype('string', arm)` rather than by
 * comparing the arm to the literal `'string'`: an identity test missed a
 * reference or alias arm that resolves to `string`, a nested union with a
 * `string` arm inside it, and a SUPERTYPE arm such as `value`, `expression`
 * or `any` — each of which accepts the string without help. `isSubtype`
 * resolves aliases and looks through nested unions itself, so no recursion is
 * needed here.
 *
 * Exported because literal narrowing happens in two places that must agree on
 * which declared types trigger it: argument validation (below) and a typed
 * declaration or assignment (`Declare`/`Assign` in `library/core.ts`).
 */
export function expectsCharacterNotString(param: Type): boolean {
  if (param === 'character') return true;
  if (typeof param === 'string') return false;
  if (param.kind !== 'union') return false;
  let hasCharacter = false;
  for (const arm of param.types) {
    if (isSubtype('string', arm)) return false;
    if (arm === 'character') hasCharacter = true;
  }
  return hasCharacter;
}

/**
 * LITERAL NARROWING: a string literal in a `character`-expecting position
 * becomes the character it denotes.
 *
 * Epsil has no character literal — `"a"` is a string — so without this the
 * `character` type would be unusable in practice: `f(c: character)` could
 * never be called with a written-out character. The criterion is the one
 * `CharacterFrom` applies (`isSingleGraphemeCluster`), so there is exactly one
 * definition of "one character" in the system; a multi-cluster or empty
 * literal returns `undefined` here and falls through to the ordinary
 * `incompatible-type` error.
 *
 * Confined to LITERALS on purpose: a `string`-TYPED expression does NOT
 * implicitly convert (`docs/STRING_ROADMAP.md`, design constraint 4) and must
 * be written `CharacterFrom(s)`.
 *
 * Returns `undefined` when no narrowing applies, so every call site is
 * `narrowCharacterLiteral(...) ?? <its existing behavior>`.
 */
function narrowCharacterLiteral(
  ce: ComputeEngine,
  op: Expression,
  param: Type
): Expression | undefined {
  if (!isString(op)) return undefined;
  if (!expectsCharacterNotString(param)) return undefined;
  return narrowStringLiteralToCharacter(ce, op);
}

/**
 * The operand type the compatibility gate JUDGES for an inline `Function`
 * literal: parameter types that were not AUTHORED are widened to `unknown`.
 *
 * A literal's unannotated parameter gets its type INFERRED from body uses
 * (`l => Length(l)` infers `l: collection`), and that inference is a guess
 * about intent, not a contract — the pinned pipe behavior maps such a stage
 * per element and lets the body go inert (`[1,2,3] |> (l => Length(l)) →
 * [Length(1), …]`), which rule 3 would refuse on the guessed type. An
 * authored `Typed` wrapper (the user's own annotation, or the contextual
 * stamp — which is the slot's own solved type and cannot conflict with the
 * supply by construction) keeps its full weight, and the literal's RESULT
 * type stays authoritative either way (§9 Q3: `k => k + 1` rejects on its
 * inferred `number` result). Non-literal operands are returned unchanged.
 */
export function widenUnannotatedLiteralParams(fn: Expression, t: Type): Type {
  if (!isFunction(fn, 'Function')) return t;
  if (typeof t !== 'object' || t.kind !== 'signature') return t;
  const args = t.args ?? [];
  // The slots of the parameters with a default value are in `optArgs`:
  // slot `i` of `optArgs` is the parameter at position `args.length + i`.
  const optArgs = t.optArgs ?? [];
  if (args.length + optArgs.length === 0) return t;
  const params = fn.ops.slice(1);
  let changed = false;
  const widen = (el: NamedElement, i: number): NamedElement => {
    const p = params[i];
    // Only a `Typed` wrapper is AUTHORED — the same bareness test as
    // `relaxBareParams` (`function-utils.ts`), via
    // `functionLiteralParameterType`. A destructuring PATTERN's tuple shape
    // is written by the author, but its element types are inferred guesses
    // like a bare symbol's, and rule 3 must not refuse on a guess (the
    // pattern's arity/shape mismatches are the arity machinery's business,
    // with its tuple hint).
    if (p === undefined || functionLiteralParameterType(p) !== undefined)
      return el;
    if (el.type === 'unknown') return el;
    changed = true;
    return { ...el, type: 'unknown' as Type };
  };
  const widened = args.map(widen);
  const widenedOpt = optArgs.map((el, i) => widen(el, args.length + i));
  return changed
    ? {
        ...t,
        ...(t.args !== undefined ? { args: widened } : {}),
        ...(t.optArgs !== undefined ? { optArgs: widenedOpt } : {}),
      }
    : t;
}

/**
 * The signature arms of an arrow-typed parameter slot, for compatibility
 * admission (Design E §3,
 * `docs/TYPE-SYSTEM.md`): the slot
 * itself when it is a signature, or the signature members of a union or
 * intersection (`Partition`'s `integer | ((T) any -> boolean)`; a user
 * overload set as a parameter). `undefined` when the slot has no arrow arm —
 * the compatibility gate then does not apply.
 */
function paramArrowArms(
  param: Type
): ReadonlyArray<FunctionSignature> | undefined {
  if (typeof param !== 'object') return undefined;
  // A transparent alias IS its definition (§6b closes the
  // reference-hidden-slot gap: an alias that expands to an arrow is an
  // arrow); a nominal reference stays opaque and the gate declines.
  if (param.kind === 'reference') {
    if (param.alias !== true || param.def === undefined) return undefined;
    return paramArrowArms(param.def);
  }
  if (param.kind === 'signature') return [param];
  // A UNION may mix an arrow arm with non-callable arms (`Partition`'s
  // `integer | ((T) any -> boolean)`): the arrow members are the candidates.
  if (param.kind === 'union') {
    const arms: FunctionSignature[] = [];
    for (const member of param.types)
      if (typeof member === 'object' && member.kind === 'signature')
        arms.push(member);
    return arms.length > 0 ? arms : undefined;
  }
  // An INTERSECTION is a candidate set only when it is a genuine OVERLOAD
  // SET — every member a signature (§3 notes: the runtime selects the
  // applicable arm per call, so one usable arm suffices). A MIXED
  // intersection (`((integer) -> integer) & list<boolean>`) is not reliably
  // callable and must not be compatibility-admitted through its arrow half.
  if (param.kind === 'intersection') {
    const arms: FunctionSignature[] = [];
    for (const member of param.types) {
      if (typeof member !== 'object' || member.kind !== 'signature')
        return undefined;
      arms.push(member);
    }
    return arms.length > 0 ? arms : undefined;
  }
  return undefined;
}
// NOTE: deliberately NOT merged with `signatureArmsOf` above — the two now
// differ in every dimension that matters: this one unfolds alias references,
// admits MIXED unions' arrow members, requires intersections to be pure
// overload sets, and answers `undefined` (gate does not apply) rather than
// `[]`. Forcing them together would perturb `admitsPlaceholderSignature`'s
// semantics for no shared code worth the risk.

/**
 * Rule 2's arity verdict at an arrow-typed slot (Design E §12d): the error to
 * report when NO arm of the slot supplies an arity the operand can accept,
 * `undefined` when the slot admits the operand or the reader cannot word a
 * sentence about it.
 *
 * Deliberately independent of subtyping, and asked BEFORE it. Subtyping is
 * not the relation an arrow slot admits by — Design E admits a callback whose
 * arity range OVERLAPS the slot's — and it does not decide arity fully in any
 * case: a slot arm carrying an optional or variadic tail still admits a
 * callback wider than any call it can make (`(number, number, number) ->
 * number` is a subtype of `(number, number?) -> number`, since the surplus
 * parameter is matched against the optional one). A gate consulted only where
 * matching FAILED therefore never sees those callbacks at all.
 *
 * This asymmetry used to be far wider: until signature subtyping gained the
 * too-MANY-parameters direction for a fixed-arity rhs
 * (`isSubtype`, `common/type/subtype.ts`), an inline binary callback was a
 * strict subtype of a plain unary slot and reached application unreported.
 *
 * The library's own collection operators never reach this mint — their
 * canonical handlers produce the richer per-operator wording ("`CountIf` calls
 * its callback with 1 argument (each element of the collection)…", tuple
 * hint included) before validation runs. This serves user-declared operators,
 * whose supply count comes from the slot arms' own arities.
 *
 * Declines — returns `undefined`, admitting exactly as before — for an
 * anonymous operator (no name to word the sentence around), an operand type
 * carrying free type variables or no readable arity, and any operand that is
 * provably not function-valued (the ordinary `incompatible-type` report says
 * the right thing there).
 */
function arrowSlotArityRejection(
  op: Expression,
  param: Type,
  operatorName: string | undefined
): Expression | undefined {
  if (operatorName === undefined) return undefined;
  const arms = paramArrowArms(param);
  if (arms === undefined) return undefined;
  const opType = widenUnannotatedLiteralParams(op, op.type.type);
  if (freeTypeVariables(opType).size > 0) return undefined;
  if (provablyDisjoint(opType, 'function')) return undefined;
  if (arms.some((arm) => armArityCapable(arm, opType))) return undefined;

  // Word the sentence around the counts the slot actually supplies. A
  // VARIADIC arm has no single count — its range is unbounded above — so it
  // contributes its MINIMUM, phrased as such: reaching here means the operand
  // cannot even accept that minimum (a nullary callback at a `(number+)`
  // slot), which is the only way an unbounded range proves incapability.
  const supplies: { count: number; describes: string }[] = [];
  const seen = new Set<string>();
  for (const arm of arms) {
    const { min, max } = arityBounds(arm);
    const entries: [number, string][] = Number.isFinite(max)
      ? Array.from({ length: max - min + 1 }, (_, k): [number, string] => [
          min + k,
          'per the declared parameter list',
        ])
      : [[min, 'at least, per the declared parameter list']];
    for (const [count, describes] of entries) {
      const key = `${count}:${describes}`;
      if (seen.has(key)) continue;
      seen.add(key);
      supplies.push({ count, describes });
    }
  }
  return callbackArityError(op, operatorName, supplies);
}

/**
 * Compatibility admission at an arrow-typed parameter slot (Design E §3):
 * called from the `!op.type.matches(param)` failure branches — an operand the
 * strict subtype check ADMITS is a fortiori compatible, so this gate only
 * decides the ones strict matching refuses.
 *
 * Returns `'admit'` (compatible — push the operand), an error `Expression`
 * (provably unusable — push the error), or `undefined` when the gate does not
 * apply (no arrow arm in the slot, an operand that is not function-valued, an
 * open operand type) and the legacy repair/error paths should proceed.
 *
 * The rules, in order (rule 2 — arity — is the shipped `callbackArityError`
 * in the operators' own canonical route, not here):
 * - not-callable and open operands fall back to the legacy paths;
 * - rule 5: the operand's declared effects must fit the slot's effect bound
 *   (the EXISTING effect-subset check — `narrowingPreservesEffects` — kept
 *   mandatory; a mixed-union slot has no arm bound to read and passes, which
 *   is conservative-admit and moot for the library's effect-top slots);
 * - rules 1/3/4: `callbackIncompatibility`, admitting if ANY arm admits, and
 *   an arm that supplies a COLLECTION admitting a scalar-parameter callback
 *   through the broadcast the application itself performs
 *   (`broadcastAdmitsCollectionElement`).
 */
function arrowSlotAdmission(
  ce: ComputeEngine,
  op: Expression,
  param: Type,
  displayParam: Type | undefined
): Expression | 'admit' | undefined {
  const arms = paramArrowArms(param);
  if (arms === undefined) return undefined;
  // An arithmetic operator of the value kinds passed as a callback admits a
  // kind value as its operand check does (`groupOneCallbackType()`).
  const opType = widenUnannotatedLiteralParams(
    op,
    isSymbol(op)
      ? groupOneCallbackType(ce, op.symbol, op.type.type, op.operatorDefinition)
      : op.type.type
  );
  if (freeTypeVariables(opType).size > 0) return undefined;
  // Provably not a function value: the ordinary `incompatible-type` error
  // (minted by the caller) says the right thing — this gate has nothing to add.
  if (provablyDisjoint(opType, 'function')) return undefined;
  // Rule 2 OWNS arity (Design E §3): an operand whose arity provably cannot
  // accept what a slot arm supplies is ADMITTED here so the shipped
  // `callback-arity` machinery downstream mints its richer diagnostic
  // ("`CountIf` calls its callback with 1 argument (each element of the
  // collection); … declares 2 parameters", tuple-destructuring hint
  // included). Rejecting on the type rules first — a wrong-arity callback is
  // usually result-disjoint too — replaced that message with a generic
  // `incompatible-type` (caught by `callback-arity.test.ts`).
  //
  // Rule 5 (effects) is checked PER CANDIDATE ARM, not against the whole
  // slot: `narrowingPreservesEffects` reads no bound off a mixed union
  // (`integer | pure-arrow`), so a whole-param check silently waved an
  // effectful callback through a pure arrow arm. Admission requires one arm
  // that is arity-capable AND effect-admitting AND type-compatible.
  // The slot arm's ADMISSIBLE arity range walks required → optional →
  // variadic, exactly as the operand side does — reading `args.length`
  // alone under-counted a slot whose own arrow carries an optional or
  // variadic tail (`((number, number?) -> number)`), and the E3 mint then
  // falsely rejected arity-capable callbacks (dual-review finding).
  let sawArityCapableArm = false;
  for (const arm of arms) {
    if (!armArityCapable(arm, opType)) continue;
    sawArityCapableArm = true;
    if (!narrowingPreservesEffects(opType, arm)) continue;
    if (callbackIncompatibility(arm, opType) === undefined) return 'admit';
    // The BROADCAST admission (user ruling of 2026-09-22). A callback whose
    // parameters are all scalar is applied element-wise to a collection
    // argument instead of binding it whole, so a slot that supplies a
    // collection — `Sort`'s sort key over a list of rows, `GroupBy`'s and
    // `ChunkBy`'s per-element callback — is usable after all, and answers a
    // collection of what the body answers. The lazy callback family takes the
    // same decision in its own canonical handler
    // (`callbackCompatibilityError`, `library/collections.ts`).
    if (broadcastAdmitsCollectionElement(arm, opType)) return 'admit';
  }
  // Arity is already settled: every caller asks `arrowSlotArityRejection` the
  // same question before reaching this gate, so an operand that arrives here
  // with no arity-capable arm is one the mint declined to word a sentence
  // about (an anonymous operator, an unreadable operand arity). Admitting it
  // is what that decline means — byte-identical to the pre-E3 behavior.
  if (!sawArityCapableArm) return 'admit';
  return ce.typeError(displayParam ?? param, op.type, op);
}

export function checkTypes(
  ce: ComputeEngine,
  args: ReadonlyArray<Expression>,
  types: Type[]
): ReadonlyArray<Expression> {
  // Do a quick check for the common case where everything is as expected.
  // Avoid allocating arrays and objects
  if (
    args.length === types.length &&
    args.every((x, i) => x.type.matches(types[i]))
  )
    return args;

  const xs: Expression[] = [];
  for (let i = 0; i <= types.length - 1; i++)
    xs.push(checkType(ce, args[i], types[i]));

  for (let i = types.length; i <= args.length - 1; i++)
    xs.push(ce.error('unexpected-argument', args[i].toString()));

  return xs;
}

/**
 * Check that the argument is pure.
 */
export function checkPure(
  ce: ComputeEngine,
  arg: Expression | Expression | undefined | null
): Expression {
  if (arg === undefined || arg === null) return ce.error('missing');
  arg = arg.canonical;
  if (!arg.isValid) return arg;
  if (arg.isPure) return arg;
  return ce.error('expected-pure-expression', arg.toString());
}

/**
 *
 * If the arguments match the parameters, return null.
 *
 * Otherwise return a list of expressions indicating the mismatched
 * arguments.
 *
 * <!--
 * @todo?:
 * - Some permutations of operands should perhaps always be treated as invalid. Consider:
 *   - A sequence wildcard (non-optional, i.e. '__') followed by either a universal wildcard ('_'),
 *   or another non-optional sequence wildcard. (note that an optional sequence wildcard is
 *   unproblematic here.)
 *
 * -->
 *
 */
/**
 * Strip-before-validate decision (§3.B): at a stripped position, the operand
 * type is examined when it has a `missing` arm or an `any` cell (a tuple
 * component, a list element, a dictionary value or a record field typed
 * `any`), after a structural type alias is replaced by its definition. The
 * `missing` arms are removed and each `any` cell is read as `unknown`; the
 * operand is admitted when the result matches the parameter. An operand with
 * neither a `missing` arm nor an `any` cell is not examined here. So, at a
 * stripped position, a program with no `Missing` can see this change: a
 * `tuple<any, any>` operand is admitted where `tuple` is expected.
 *
 * At any other position, only the ELEMENTS of a collection operand are
 * stripped, and only at a collection-kind parameter — see
 * {@link absentElementsMatchParam}.
 */
function strippedMatchesParam(
  op: Expression,
  param: Type,
  idx: number,
  stripMissing?: (index: number) => boolean
): boolean {
  if (!stripMissing?.(idx)) {
    if (!op.type.facts.containsMissing) return false;
    return absentElementsMatchParam(op, param);
  }
  // An `any` cell inside the operand (a tuple component, a list element)
  // can hold an absent value, as a `T | missing` cell can. At a stripped
  // position the runtime gate answers that absence, so the cell is read as
  // `unknown`, the type of every value. The operand is then admitted only
  // when it is a SUBTYPE of the parameter, the same test as for a `missing`
  // arm, or when the list-length test below admits it. So
  // `Dot((1, 2), (x, y))` with `x` and `y` declared `any` is admitted at the
  // bare `tuple` parameter, as it is when `x` and `y` are declared `unknown`;
  // the Tycho importer declares every parameter of a definition `any` (Tycho
  // ledger row 376). The deferral that admits an `unknown` cell at a typed
  // slot (`overlapsForDeferredValidation`) is not applied: an `any` cell at a
  // typed slot, `tuple<any>` at `tuple<number>`, stays refused
  // (`tycho-item-257-tuple-param-deferral.test.ts`).
  //
  // A structural alias is replaced by its definition first, so that `p`
  // declared with an alias of `tuple<any, any>` is tested on the tuple, as
  // `p` declared `tuple<any, any>` is. The `containsMissing` fact and
  // `stripMissingFromType` read through a structural alias at every depth
  // themselves (`common/type/utils.ts`), so an alias of
  // `missing | tuple<number, number>` needs no resolution here; the explicit
  // resolution is for the `any`-cell test below. A nominal type is not
  // replaced, so it stays refused.
  const t = resolveTypeAlias(op.type.type);
  const hasMissing = op.type.facts.containsMissing;
  const anyAsValue = anyCellsAsUnknown(t);
  if (!hasMissing && anyAsValue === t) return false;
  const stripped = stripMissingFromType(anyAsValue);
  if (stripped === 'never' || isSubtype(stripped, param)) return true;
  // What remains is a top type: the operand is admitted as an operand typed
  // `unknown` or `any` is at every parameter ("assumed to be valid" in
  // `validateArguments`). `missing | unknown` is the type of an index into a
  // `list<unknown>`: with `g: (unknown) -> list<unknown>`, `g(x)[1][2]` was an
  // `incompatible-type` error, although `g(x)[1]` is a list when `x` is.
  if (stripped === 'unknown' || stripped === 'any') return true;
  // A rank-free list of scalars whose length the VALUE knows is the vector
  // of that length. A list holding a restricted cell, `[1{c}, 2{c}]`, and a
  // restricted list, `[1,2]{c}`, are both typed `list<integer | missing>`
  // with no length (a list type with a length is the tensor guard, whose
  // kernels admit union-free cells only), which strips to the rank-free
  // `list<integer>`, and that does not match `vector`, although the operand
  // is a 2-vector: its count is known (the literal's operands, or the
  // restricted list's collection handlers). Without this,
  // `Dot([1,2]{[0<t, t<0]}, [1,1])` was an `incompatible-type` error.
  const dims = staticCollectionDims(stripped);
  if (dims === null || dims.length !== 1 || dims[0] >= 0) return false;
  if (op.isFiniteCollection !== true) return false;
  const count = smallCount(op);
  if (count === undefined || !Number.isFinite(count)) return false;
  const r = resolveTypeAlias(stripped);
  if (typeof r === 'string' || r.kind !== 'list') return false;
  return isSubtype({ ...r, dimensions: [count] }, param);
}

/**
 * `t` with each `any` cell replaced by `unknown`. A cell is an element type, a
 * tuple component, a dictionary value or a record field, at any depth. A
 * top-level `any` (an operand typed `any`, or an arm of a union) is not a
 * cell and is kept. A structural type alias at any depth is replaced by its
 * definition before it is examined. Returns `t` itself when it has no `any`
 * cell.
 *
 * A self-referential alias (`type alias json = list<json> | integer`, or
 * `type alias cyc = cyc | 0`) meets itself again inside its definition.
 * {@link resolveTypeAlias} guards only one chain of references, so the walk
 * counts the unfolds of each alias on the current path in `seen`
 * ({@link unfoldAliasOnDescent}). When an alias has used all of its unfolds
 * on this path, its occurrence is kept unchanged.
 */
function anyCellsAsUnknown(t0: Readonly<Type>, seen?: AliasDescent): Type {
  const unfolded = unfoldAliasOnDescent(t0, seen);
  if (unfolded === undefined) return t0 as Type;
  const t = unfolded.type;
  const next = unfolded.seen;
  if (typeof t === 'string') return t0 as Type;
  const cell = (x: Readonly<Type>): Type =>
    resolveTypeAlias(x) === 'any' ? 'unknown' : anyCellsAsUnknown(x, next);
  switch (t.kind) {
    case 'union':
    case 'intersection': {
      const types = t.types.map((x) => anyCellsAsUnknown(x, next));
      return types.every((x, i) => x === t.types[i])
        ? (t0 as Type)
        : { ...t, types };
    }
    case 'list':
    case 'set':
    case 'collection':
    case 'indexed_collection':
    case 'broadcastable': {
      const elements = cell(t.elements);
      return elements === t.elements ? (t0 as Type) : { ...t, elements };
    }
    case 'tuple': {
      const types = t.elements.map((e) => cell(e.type));
      return types.every((x, i) => x === t.elements[i].type)
        ? (t0 as Type)
        : {
            ...t,
            elements: t.elements.map((e, i) => ({ ...e, type: types[i] })),
          };
    }
    case 'dictionary': {
      const values = cell(t.values);
      return values === t.values ? (t0 as Type) : { ...t, values };
    }
    case 'record':
    case 'object': {
      // A prototype-free map, as in `stripMissingFromType`: a field can be
      // named `__proto__` or `toString`.
      let changed = false;
      const elements: Record<string, Type> = Object.create(null);
      for (const key of Object.keys(t.elements)) {
        elements[key] = cell(t.elements[key]);
        if (elements[key] !== t.elements[key]) changed = true;
      }
      return changed ? { ...t, elements } : (t0 as Type);
    }
    default:
      return t0 as Type;
  }
}

/**
 * A collection whose elements may be absent is admitted at a collection-kind
 * parameter when the collection, with the `missing` arm of its element type
 * removed, fits the parameter.
 *
 * A dictionary lookup or an index with a computed key is typed `T | missing`,
 * so a `Map` over such reads is typed `list<T | missing>` even when every
 * element exists. One such value is admitted at a `T` parameter and checked
 * when its value is known; this function gives the same treatment to a
 * collection of them. With `xs = ["a", "b"]`,
 * `StringJoin(Map(i => xs[i], [1, 2]))` is admitted although its operand is
 * typed `list<missing | string>`, and with the indices `[1, 3]` the operator
 * that reads the absent element answers at run time: `StringJoin` answers an
 * `incompatible-type` error that names it, an aggregate such as `Sum` answers
 * `NaN`. A collection DECLARED with a `missing` element type is admitted in
 * the same way: the rule reads the type, not where the type came from.
 *
 * The strip is `stripMissingFromElements`, the same transform as the strip of
 * a scalar operand at a stripped position. The stripped type is then tested
 * like any other collection operand: it is admitted when it is a subtype of
 * the parameter or when the deferred collection test
 * (`overlapsForDeferredValidation`) admits it. A collection that can hold
 * nothing but absent elements (`list<missing>`) is not admitted, as a scalar
 * operand typed `missing` alone is not.
 */
function absentElementsMatchParam(op: Expression, param: Type): boolean {
  if (!paramArms(param).some(isCollectionKindArm)) return false;
  const stripped = stripMissingFromElements(op.type.type);
  if (stripped === undefined) return false;
  return (
    isSubtype(stripped, param) || overlapsForDeferredValidation(stripped, param)
  );
}

/**
 * A LAZY collection (a comprehension, a `Map` view, …) at a collection-kind
 * parameter is admitted when its element type, with the `nan` arm removed,
 * fits the parameter's element type.
 *
 * The `nan` arm of such an element type is a possibility the type system
 * records, not a value the caller passed: a comprehension whose body reads
 * `l[i]` is typed `indexed_collection<nan | real>`, because an element read
 * outside the list is `NaN`. Refusing it at a `list<real>` parameter made
 * `s(u(L))` an `incompatible-type` error (with `u` and `s` declared
 * `(list<real>) -> unknown`), while the compiled JavaScript code of the same
 * expression returned values. The parameter's own contract is not widened:
 * an EAGER list with a `nan` element (`[1, NaN]`) is still refused, and so
 * is a lazy collection whose elements are nothing but `nan`.
 *
 * A lazy INDEXED collection materializes as a list, so at a `list<…>`
 * parameter it is compared as the list of its elements.
 *
 * User decision of 2026-09-27, option B of the ROADMAP entry "A lazy
 * comprehension is rejected at a `list<real>` parameter that the compiled
 * route accepts".
 */
function lazyCollectionMatchesWithoutNan(op: Expression, param: Type): boolean {
  if (!op.isLazyCollection || op.isFiniteCollection === false) return false;
  const p = resolveTypeAlias(param);
  if (
    typeof p === 'string' ||
    (p.kind !== 'list' &&
      p.kind !== 'collection' &&
      p.kind !== 'indexed_collection')
  )
    return false;
  const t = resolveTypeAlias(op.type.type);
  if (
    typeof t === 'string' ||
    (t.kind !== 'list' &&
      t.kind !== 'collection' &&
      t.kind !== 'indexed_collection')
  )
    return false;
  const el = t.elements;
  if (typeof el === 'string' || el.kind !== 'union') return false;
  const arms = el.types.filter((x) => x !== 'nan');
  if (arms.length === 0 || arms.length === el.types.length) return false;
  const elements: Type =
    arms.length === 1 ? arms[0] : { kind: 'union', types: arms };
  const stripped: Type =
    t.kind === 'indexed_collection' && p.kind === 'list'
      ? { kind: 'list', elements }
      : { ...t, elements };
  return isSubtype(stripped, param);
}

/**
 * Contract B NaN admission (`docs/ERROR-MODEL.md` §4, composition rule
 * step 1): the NaN policy is tested BEFORE ordinary type disjointness, so a
 * proven-`NaN` operand in a `propagate` or `handle` slot is admitted even
 * though `nan` lies outside the slot's carrier — the runtime gate (or the
 * handler) owns it from there. A `reject` slot deliberately gets NO
 * carve-in: the ordinary carrier mismatch already produces the immediate
 * `Error` the policy asks for. Inert while the operator's carriers admit
 * `nan` (`resolvedNanBehaviorAt` answers `'inert'` there), which is every
 * operator not yet migrated to precise Contract B carriers.
 */
function nanPolicyAdmitsParam(
  op: Expression,
  idx: number,
  nanPolicyAt?: (index: number) => 'reject' | 'propagate' | 'handle' | 'inert'
): boolean {
  if (!nanPolicyAt) return false;
  if (op.isNaN !== true) return false;
  const policy = nanPolicyAt(idx);
  return policy === 'propagate' || policy === 'handle';
}

/** Engine-internal knobs of {@link validateArguments} (phase 2c of
 * `docs/TYPE-SYSTEM.md`). Not for library callers. */
export interface ValidateArgumentsInternals {
  /** Whether the operator refuses an absent operand at position `index`
   * at evaluation (`refusesAbsentOperandAt`, `boxed-operator-definition.ts`):
   * the Epsil static check then reports a possibly absent argument there,
   * as it does at a function literal's annotated parameter
   * (`refusesAbsentArgument`). */
  refusesAbsentAt?: (index: number) => boolean;
  /** Repair-free TRIAL mode: this call is an overload arm's trial
   * (`EngineBoxingState.withTrial()`). The two construction-level repairs
   * are admitted by their write-free preconditions and NOT executed
   * (`devolveUnappliedOperator` would declare a shadow and request a
   * rebuild; `repairFreshMatrixInference` would retype symbols and re-box),
   * and the final operand inference is skipped. The winning arm's REAL
   * validation, outside the trial, performs any repairs and the inference,
   * exactly once. */
  trial?: boolean;
  /** Contract B per-slot NaN policy of the operator being validated
   * (`docs/ERROR-MODEL.md` §4). When present, a proven-`NaN` operand in a
   * `propagate`/`handle` slot is admitted ahead of type disjointness — see
   * {@link nanPolicyAdmitsParam}. Passed by the operator boxing sites,
   * which have the definition in hand; ad-hoc library validations against
   * literal signatures do not pass it and keep plain carrier semantics. */
  nanPolicyAt?: (index: number) => 'reject' | 'propagate' | 'handle' | 'inert';
  /** Second-pass trial: the R1 overlap admission is active inside this
   * trial. The FIRST resolution pass keeps trials strict, so an arm that
   * strictly accepts always beats one that merely overlaps — a declared
   * `number` operand selects the `(number) -> number` arm, never the
   * provisionally-overlapping `(integer) -> integer` one
   * (`overload-trials.test.ts`). Only when NO arm is strictly viable does
   * resolution re-run with this flag, so an operand admissible by overlap
   * still finds an arm (`Slice`'s span slot, validated against an overload
   * set). */
  overlapTrial?: boolean;
  /** The OPERATOR (or function-valued symbol) being applied, for diagnostics
   * that name it — the compatibility gate's generic `callback-arity` mint
   * (Design E §12d). Absent where no name is known; the mint then declines
   * rather than word a sentence about an anonymous operator. */
  operatorName?: string;
  /** The definition of the operator being applied, when it is an operator
   * definition. The rules of the value kinds that an operator name selects
   * (the admission of group 1 at `Add`, …, the `compare` rule of `Clamp`)
   * apply only when it is the library definition of that name
   * (`isLibraryKindOperator()`, `kind-admission.ts`). */
  operatorDefinition?: BoxedOperatorDefinition;
  /** The solve `resolveOverload` already ran on this (single-arm, polytype)
   * signature with the identical context — reused instead of re-solving. */
  armSolution?: TypeInferenceResult;
  /** Out-slot: the overload resolution computed by this call, when the
   * signature was an overload set. The caller attaches it to the call
   * expression it constructs, so result typing (`resolvedArm`) reads the
   * SAME resolution the call was validated against instead of re-deriving
   * one with the trial-less prefilter. */
  resolutionOut?: { resolution?: OverloadResolution };
  /** CHECK-ONLY mode: every verdict and every repair or substitution of the
   * ordinary validation, but no inference — a valueless symbol is admitted
   * where it would have been narrowed to the parameter, and the final
   * narrowing pass is skipped. The boxing validation seam of a
   * `canonical`-handler head runs in this mode: the head's own handler has
   * already typed what it types, and the seam is a gate on the declaration,
   * not a second source of types. */
  noInference?: boolean;
  /** Additional absence diagnostics at a read-only source-check use. */
  diagnostic?: boolean;
  /** Ask threadable numeric slots to reject a collection whose static element
   * carrier is provably non-numeric (`validateThreadableOperand`). Set for a
   * `broadcastable: true` library operator on both operator routes — the
   * plain boxing path and the canonical-handler seam — so its declaration
   * refuses `Ln(["a", "b"])` at boxing as the numeric fast path does. A user
   * function (`isUserFunctionDefinition`) leaves it unset: its per-element
   * broadcast reports a mismatch per cell, with the broadcast context, at
   * evaluation. */
  checkNumericCollections?: boolean;
  /** The callee is a USER function, whose application maps over a list of
   * points at a parameter declared as a point (`tuple<real, real>`), see
   * `isPointListArgumentType`. An argument typed as such a list is admitted
   * at that parameter; the evaluation binds each point to the parameter and
   * checks it there. Library operators leave this unset: a tuple parameter
   * of theirs takes one tuple.
   *
   * A tuple at a scalar parameter is admitted as well
   * (`isScalarParameterTuple`): the application maps over its components
   * when the parameter is declared as a scalar, and binds it whole when the
   * type of the parameter is only inferred. */
  mapsPointLists?: boolean;
  /** The callee is a USER function (a function literal, a multi-clause
   * definition, a function held as a value). A `NaN` argument is accepted
   * at a parameter whose whole type is a subtype of `number` (`integer`,
   * `real`, `number`) — see `acceptsNaNArgument`. A union with a member
   * that is not numeric, and a collection of numbers, are checked as usual. Library operators
   * leave this unset: their `NaN` policy is `nanPolicyAt`. */
  userFunction?: boolean;
  /** The callee is a function literal whose parameter annotations are
   * enforced when it is applied (`enforcesParameterAnnotations`,
   * `boxed-operator-definition.ts`). An argument that is absent, or that
   * may be absent while an Epsil static pre-pass runs, is refused at a
   * parameter whose annotation is not numeric and has no `missing` member —
   * see `refusesAbsentArgument`. */
  enforcesParameterAnnotations?: boolean;
  /** Whether a symbol with an inferred type is admitted provisionally at a
   * collection parameter (`isProvisionalCollectionOperand`). Unset, the
   * answer is true for a library operator and false for a user function
   * (`userFunction`). A trial of an overload arm receives the answer of the
   * call it is a trial for. */
  provisionalCollectionOperands?: boolean;
}

/** See `ValidateArgumentsInternals.provisionalCollectionOperands`. */
function admitsProvisionalCollectionOperands(
  internals: ValidateArgumentsInternals | undefined
): boolean {
  return (
    internals?.provisionalCollectionOperands ?? internals?.userFunction !== true
  );
}

/**
 * Whether the argument `op`, whose value is `NaN`, is accepted at the
 * parameter `param` of a user function (user decision 2026-09-30: a `NaN`
 * value is acceptable at a parameter typed `integer` or `real`).
 *
 * `NaN` is what a numeric computation answers when it has no value: a
 * restricted number whose condition fails, a read past the end of a list of
 * numbers, `0/0`. `nan` is a member of `number` and not of `integer` or
 * `real`, so `f(n: integer)` refused an argument that `f(n: number)`
 * accepts, and an Epsil `function` answered an error where the same body
 * declared through `ce.declare` answered `NaN`. A user function accepts it
 * at every numeric parameter; its body then computes with `NaN`. A number
 * that is not `NaN` is checked as before (`1.5` at `integer` is refused).
 *
 * The argument is `NaN` when its value is (`op.isNaN`, a literal) or when
 * its static type is `nan`: a function application reports `isNaN` only
 * once it is evaluated, so `f(g())` with `g: () -> nan` was refused at
 * boxing where `f(NaN)` was accepted. The argument is not evaluated here.
 * An argument typed `missing` (the literal `Missing`) is accepted too: the
 * call of a user function with an absent argument at a numeric parameter is
 * `Missing`, whatever the body (`apply()`, `function-utils.ts`), as an
 * operator over `Missing` is `Missing`. A parameter with a default value
 * receives its default in place of the absent argument.
 */
function acceptsNaNArgument(
  op: Expression,
  param: Type,
  internals: ValidateArgumentsInternals | undefined
): boolean {
  if (internals?.userFunction !== true) return false;
  // The absent value at a point parameter (a tuple of numbers,
  // `pointArity()`) makes the call `Missing`, as at a numeric parameter. A
  // `NaN` point (a tuple whose coordinates are all `NaN`, the value of a
  // read past the end of a list of points) is accepted there, as `NaN` is
  // at a numeric parameter. The scalar `NaN` is still refused: it is not a
  // point.
  if (!isSubtype(param, 'number')) {
    if (pointArity(param) === undefined) return false;
    const opType = resolveTypeAlias(op.type.type);
    return (
      opType === 'missing' ||
      isNaNPointValue(op) ||
      (typeof opType !== 'string' &&
        opType.kind === 'tuple' &&
        opType.elements.length > 0 &&
        opType.elements.every((x) => isSubtype(x.type, 'nan')))
    );
  }
  // An absent argument (the literal `Missing`, typed `missing`) is accepted
  // at a numeric parameter of a user function, as `NaN` is: the call is
  // `Missing` (see above).
  return (
    op.isNaN === true ||
    op.type.matches('nan') ||
    resolveTypeAlias(op.type.type) === 'missing'
  );
}


export function refusesAbsentArgument(
  ce: ComputeEngine,
  op: Expression,
  param: Type,
  internals: ValidateArgumentsInternals | undefined,
  index?: number
): boolean {
  const libraryRefuses =
    index !== undefined &&
    internals?.diagnostic === true &&
    internals?.refusesAbsentAt?.(index) === true;
  if (internals?.enforcesParameterAnnotations !== true && !libraryRefuses)
    return false;
  if (
    param === 'unknown' ||
    isSubtype('missing', param) ||
    isSubtype(param, 'number') ||
    pointArity(param) !== undefined
  )
    return false;
  const t = resolveTypeAlias(op.type.type);
  if (t === 'missing') return true;
  if (internals?.diagnostic !== true) return false;
  if (typeof t === 'string' || t.kind !== 'union') return false;
  return t.types.some((arm) => resolveTypeAlias(arm) === 'missing');
}

/**
 * True when `op` is a symbol that holds a value and whose type was inferred
 * from that value (a symbol declared `unknown` and assigned `5` is typed
 * `integer`), `param` is a collection parameter, and the type of the symbol
 * does not match it.
 *
 * Validation admits such an operand provisionally at a parameter of a
 * library operator. A canonical form must not depend on the value assigned
 * to a symbol: refused at boxing, `Sort(n)` kept its error after `n` was
 * assigned a list. The refusal reads declared types only, as the refusal of
 * a source of a lazy collection operator does
 * (`refusedCollectionSourceOperands`). The evaluation checks the value: a
 * value that is not a collection is an `incompatible-type` error there.
 *
 * Two cases are not included:
 * - A symbol with no value whose type was inferred from an earlier use (`x`
 *   in `3x + 2` is typed `number`). Its type does not depend on a value, and
 *   a use of a symbol with no value narrows its type (`Length(m)` in the
 *   body of a function makes the parameter `m` a collection); a provisional
 *   admission is not narrowed.
 * - The parameters of a user function: the check of the arguments at the
 *   call is the contract of its declaration, and a refused call is checked
 *   again at evaluation (`_refusedOps` in `boxed-function.ts`).
 */
function isProvisionalCollectionOperand(op: Expression, param: Type): boolean {
  if (!isSymbol(op)) return false;
  const def = op.valueDefinition;
  if (def?.inferredType !== true || def.value === undefined) return false;
  if (param === 'any' || param === 'unknown') return false;
  return isSubtype(param, COLLECTION_SHAPE_TYPE) && !op.type.matches(param);
}

/**
 * Whether an argument of type `t` is a tuple at a SCALAR parameter `param`
 * (a number type or `boolean`) of a user function. Such an argument is not
 * refused when the call is boxed: when the parameter is declared as a
 * scalar, the application maps over the components of the tuple and checks
 * each one where it is applied (`declaredScalarTupleCells`,
 * `boxed-function.ts`, user decision 2026-10-03), and when the type of the
 * parameter is only inferred, the application binds the tuple whole. A
 * tuple with a component that is a collection other than a tuple
 * (`([1, 2], [3, 4])`) is data, not a point, and is checked as usual.
 */
function isScalarParameterTuple(t: Type, param: Type): boolean {
  if (param === 'never' || param === 'nothing') return false;
  if (!isSubtype(param, 'number') && !isSubtype(param, 'boolean')) return false;
  const r = resolveTypeAlias(t);
  if (typeof r !== 'object' || r.kind !== 'tuple') return false;
  return r.elements.every((e) => {
    const c = resolveTypeAlias(e.type);
    return (
      (typeof c === 'object' && c.kind === 'tuple') ||
      !isSubtype(c, COLLECTION_SHAPE_TYPE)
    );
  });
}

/**
 * Whether the operand `op`, which has an arm that is a kind type, is
 * admitted at the parameter `param` (position `idx`) by the rules of the
 * value kinds (`kind-admission.ts`, `docs/plans/2026-10-26-value-kinds.md`
 * section 4.2), in addition to subtyping:
 *
 * - at an arithmetic operator of group 1 (`Add`, `Divide`, `Power`, …,
 *   named by `internals.operatorName`), a value of a kind whose head
 *   declares the matching hook, beside numbers only, the kind type itself
 *   or in the cells of a collection, as `checkNumericArgs` admits it on the
 *   canonical route of those operators;
 * - at any other parameter, a value of a kind declared with
 *   `admittedAs: 'real'` or `'number'` whose type, with each kind arm
 *   replaced by the narrowest carrier the parameter admits, is admitted by
 *   the parameter (the carrier rule, `admitsThroughCarrier()`).
 *
 * A user function (a function with a body) admits a kind value only by
 * type (decision B): neither rule applies to it.
 */
function kindOperandAdmitted(
  ce: ComputeEngine,
  op: Expression,
  param: Type,
  idx: number,
  threadable: Threadable | undefined,
  stripMissing: ((index: number) => boolean) | undefined,
  internals: ValidateArgumentsInternals | undefined
): boolean {
  if (internals?.userFunction) return false;
  const t = op.type.type;
  // The rules that the operator NAME selects belong to the library
  // definitions of these names: a host operator declared `Add` in a nested
  // scope is an ordinary operator (`isLibraryKindOperator()`).
  const libraryRules = isLibraryKindOperator(
    ce,
    internals?.operatorName,
    internals?.operatorDefinition
  );
  const hook = libraryRules
    ? groupOneHookOf(internals?.operatorName)
    : undefined;
  if (hook !== undefined) {
    const kinds = kindTypeNamesWithHook(ce, hook);
    return hasKindArm(t, kinds) && !numericOperandTypeRefused(t, kinds);
  }
  // `Clamp`, `ElementMax` and `ElementMin` order their operands, and admit
  // a kind value whose kind type declares `compare` whatever its
  // `admittedAs`, by the rule of the arithmetic operators
  // (`docs/plans/2026-10-26-value-kinds.md`, section 4.4, and decision 8 of
  // section 13): `Clamp(x, lo, hi)` answers `x` or a bound as written, and
  // `ElementMin(2 deg, 3)` is `2 deg`.
  const operatorName = internals?.operatorName;
  if (
    libraryRules &&
    (operatorName === 'Clamp' ||
      operatorName === 'ElementMax' ||
      operatorName === 'ElementMin')
  ) {
    const kinds = kindTypeNamesWithHook(ce, 'compare');
    if (hasKindArm(t, kinds) && !numericOperandTypeRefused(t, kinds))
      return true;
  }
  return admitsThroughCarrier(
    ce,
    t,
    param,
    isThreadableAt(threadable, idx),
    stripMissing?.(idx) === true
  );
}

export function validateArguments(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  signature: Type,
  lazy?: boolean,
  /** Global (`opDef.broadcastable`, `paramsAreScalar`) or PER-POSITION: a
   * declared `broadcastable<T>` signature threads only the slots it marks
   * elementwise, so a sibling slot that binds its argument whole is validated
   * as usual (`docs/plans/2026-08-08-broadcastable-param-semantics.md`). */
  threadable?: Threadable,
  freshlyInferred?: ReadonlySet<BoxedValueDefinition>,
  /** Strip-before-validate (§3.B of the missing-value typing design): for a
   * position where this predicate returns `true`, an operand carrying a
   * `missing` arm is admitted when its stripped type still matches the
   * parameter (a scalar `Missing` → `never`, admissible everywhere). The
   * missing arm is carried by the runtime gate, not the type. */
  stripMissing?: (index: number) => boolean,
  internals?: ValidateArgumentsInternals
): ReadonlyArray<Expression> | null {
  // A `Spread` operand (`f(...p)`) makes the effective arity unknown until
  // the enclosing call's evaluation splices the tuple's elements in — defer
  // ALL validation (including the non-strict missing-argument padding below)
  // to that runtime re-validation. Must precede the non-strict fastpath: the
  // padding would otherwise treat `f(...p)` as an arity-1 call.
  if (ops.some((x) => x.operator === 'Spread')) return null;

  // @fastpath
  if (!ce.strict) {
    // Skip the full per-parameter type checking below, but still pad a
    // missing *required* argument with an `Error("missing")` marker.
    // Returning `null` unconditionally here (the previous behavior) tells
    // the caller "use the operands as-is", so a genuinely missing argument
    // (e.g. `Arctan()`) left a fixed-arity `evaluate` handler destructuring
    // past the end of the operand array — a raw JS `undefined` rather than
    // a boxed error, which crashes instead of degrading gracefully.
    if (typeof signature !== 'string' && signature.kind === 'signature') {
      const requiredCount = signature.args?.length ?? 0;
      if (ops.length < requiredCount) {
        const xs = [...ops];
        while (xs.length < requiredCount) xs.push(ce.error('missing'));
        return xs;
      }
    } else {
      // Overload set: pad only up to the SMALLEST required count across the
      // arms. An arm needing more is simply not the one being called; padding
      // to the largest would manufacture `Error("missing")` operands for a
      // perfectly well-formed call to a shorter arm.
      const arms = overloadArms(signature);
      if (arms) {
        const requiredCount = Math.min(...arms.map((a) => a.args?.length ?? 0));
        if (ops.length < requiredCount) {
          const xs = [...ops];
          while (xs.length < requiredCount) xs.push(ce.error('missing'));
          return xs;
        }
      }
    }
    return null;
  }

  if (typeof signature === 'string') return null;

  // An intersection of signatures is an overload set. Resolve it to a single
  // arm and validate against that (`docs/TYPE-SYSTEM.md`). Resolution is
  // write-free, so no symbol is mutated on
  // account of an arm that is subsequently rejected.
  //
  // `viable` (not `selected`) drives the operand inference at the bottom of
  // this function: the result type comes from the most-specific arm, but the
  // constraint pushed back into an operand must be the JOIN over every arm
  // that survived (§4.3). Those pull in opposite directions.
  let sig: FunctionSignature;
  let viableArms: ReadonlyArray<FunctionSignature> | undefined;
  /** The selected arm's solve, when resolution already computed it — the
   * call-site instantiation below reuses it instead of solving the same arm
   * against the same operands with the same context a second time. */
  let armSolution: TypeInferenceResult | undefined;
  /** The arms that the operand inference joins (`viableArms`, or the
   * signature), as declared, before an instantiation (`distributionTypeAt`). */
  let declaredArms: ReadonlyArray<FunctionSignature>;
  if (signature.kind === 'signature') {
    sig = signature;
    declaredArms = [signature];
  } else {
    const arms = overloadArms(signature);
    if (!arms) return null;
    // The policies reach both the cheap prefilter and the generic solver, so
    // resolution and validation see the same call.
    const policies = {
      lazy,
      threadable,
      couldBeUnkeyedCollection: couldBeUnkeyedCollectionOperand,
      stripMissing,
      freshMatrixRepair: (op: Expression, param: Type) =>
        (!op.type.isUnknown && isUntypedAtCollectionSlot(op, param)) ||
        couldRepairFreshMatrixInference(ce, op, param, freshlyInferred),
      // The provisional admission of a symbol with an inferred type at a
      // collection parameter, which full validation performs for a library
      // operator (see `isProvisionalCollectionOperand`).
      provisionalOperand: admitsProvisionalCollectionOperands(internals)
        ? isProvisionalCollectionOperand
        : undefined,
    };
    // Trial admission (phase 2c): an arm is viable iff running THIS function
    // on it, in trial mode, succeeds. A trial writes on no definition: the
    // construction-level repairs are admitted by precondition and assert
    // they never execute in a trial, and the operand inference at the end of
    // this function is skipped; the winning arm validates again and makes
    // these writes. This replaced the write-free mirror filter, whose gate
    // conditions had to track this function's admission logic by hand.
    //
    // A requirement that a trial writes goes in an environment of its own
    // (`inTrialEnvironment()`), which is thrown away when the trial ends.
    const mkArmTrial =
      (overlapTrial: boolean): ArmTrialFn =>
      (declared, _instance, solution, armOps) => {
        const res = validateArguments(
          ce,
          armOps,
          declared,
          lazy,
          threadable,
          freshlyInferred,
          stripMissing,
          {
            trial: true,
            overlapTrial: overlapTrial || undefined,
            armSolution: solution,
            // The NaN policy is the operator's, not the arm's, so it
            // rides into every arm trial unchanged.
            nanPolicyAt: internals?.nanPolicyAt,
            // The arity verdict at an arrow slot is worded around the
            // operator's name and DECLINES without one, so an unnamed
            // trial would judge an inapplicable callback admissible and
            // report the arm viable.
            operatorName: internals?.operatorName,
            operatorDefinition: internals?.operatorDefinition,
            // The collection verdict is the operator's too: a trial
            // that admitted a `list<string>` at a numeric arm would
            // rank that arm viable, and final validation would then
            // refuse the call instead of selecting a string arm.
            checkNumericCollections: internals?.checkNumericCollections,
            // The provisional admission of a symbol with an inferred
            // type at a collection parameter is the operator's too
            // (`isProvisionalCollectionOperand`).
            provisionalCollectionOperands:
              admitsProvisionalCollectionOperands(internals),
          }
        );
        // `null` = valid, operands unchanged. In trial mode no repair
        // executes, so `substituted` is never set and a non-null result
        // always carries at least one invalid operand — the refuted
        // positions.
        if (res === null) return null;
        const refuted: number[] = [];
        res.forEach((x, k) => {
          if (!x.isValid) refuted.push(k);
        });
        return refuted.length === 0 ? null : refuted;
      };
    const mkTrial = (overlapTrial: boolean): ArmTrialFn =>
      inTrialEnvironment(ce, mkArmTrial(overlapTrial));
    const trial = mkTrial(false);
    const resolution = resolveOverload(
      ce,
      ops,
      arms,
      policies,
      undefined,
      trial
    );
    if (internals?.resolutionOut !== undefined)
      internals.resolutionOut.resolution = resolution;
    let { selected, viable, viableDeclared, selectedSolution } = resolution;
    // R1 second pass (see `ValidateArgumentsInternals.overlapTrial`): no arm
    // is STRICTLY viable — before blaming, re-resolve with the overlap
    // admission active inside the trials, so an operand that merely overlaps
    // an arm's parameter still finds a home and is admitted provisionally by
    // that arm's real validation below.
    if (!selected) {
      const second = resolveOverload(
        ce,
        ops,
        arms,
        policies,
        undefined,
        mkTrial(true)
      );
      if (second.selected) {
        if (internals?.resolutionOut !== undefined)
          internals.resolutionOut.resolution = second;
        ({ selected, viable, viableDeclared, selectedSolution } = second);
      }
    }
    if (!selected) {
      // No arm fits. Blame the operands actually at fault: an operand every
      // near-miss arm accepts at its position stays untouched, so a bad seed
      // does not also indict a perfectly good domain argument.
      const { arityViable, arityTarget, refuted } = diagnoseNoMatch(
        ce,
        ops,
        arms,
        policies,
        trial
      );
      if (arityViable.length === 0) {
        // Wrong number of arguments for every arm. `arityTarget` is the
        // NEAREST accepted count, which also covers a gap in the accepted set
        // (arms of arity 1 and 3 called with 2) — the previous global
        // min/max bracketing waved those through with no marker at all.
        const target = arityTarget ?? ops.length;
        const xs: Expression[] = ops.map((op, idx) =>
          idx < target ? op : ce.error('unexpected-argument', op.toString())
        );
        while (xs.length < target) xs.push(ce.error('missing'));
        return xs;
      }
      const blamed = ops.map((op, idx) => {
        const expected = refuted.get(idx);
        if (expected === undefined) return op;
        // An operand that is already an error is returned as it is. An error
        // value is a member of no type, so every arm refutes it, but its own
        // diagnostic is the precise one: wrapping it in a second
        // `incompatible-type` error ("expected `indexed_collection`, got
        // `error`") hid that diagnostic. `Sort("a" + 1)` now keeps the error
        // of `"a" + 1`, as `Sin("a" + 1)` does.
        if (!op.isValid) return op;
        // When the refuted position is an arrow slot no arm can apply the
        // callback at, say THAT rather than printing two signatures side by
        // side: `expected` is the union of the arms' slots, so the arity
        // verdict reads every arm at once and mints the same sentence a
        // single-arm call gets ("… calls its callback with 1 argument …;
        // `(a, b) => a + b` declares 2 parameters").
        return (
          arrowSlotArityRejection(op, expected, internals?.operatorName) ??
          ce.typeError(expected, op.type, op)
        );
      });
      // Invariant: a call with no selected arm must never come back fully
      // valid. `diagnoseNoMatch` guarantees a non-empty `refuted` whenever an
      // arm was arity-viable, so this is a backstop against a future
      // regression rather than an expected path.
      if (blamed.every((x) => x.isValid))
        blamed[0] = ce.error('unexpected-argument', ops[0]?.toString() ?? '');
      return blamed;
    }
    sig = selected;
    viableArms = viable;
    declaredArms = viableDeclared;
    armSolution = selectedSolution;
  }

  const result: Expression[] = [];
  let isValid = true;
  // Set when an operand was replaced (devolved to an unknown symbol, or
  // repaired by matrix inference). The substituted list must then be returned
  // even if validation succeeds: returning `null` tells the caller to use the
  // original operands, and the original boxed symbol keeps its stale operator
  // binding (`N \equiv 1 \pmod k` stayed bound to the builtin `N`, so a later
  // `N := 11` was invisible to the expression).
  let substituted = false;

  // Positions accepted via overlap-deferred validation (§D6.2): acceptance
  // is an unrefuted possibility, not a proof, so these positions are
  // excluded from the final `_infer(param)` narrowing below — narrowing an
  // inferred symbol to `matrix` on the strength of a guess would
  // over-constrain unrelated later uses.
  const deferredIdx = new Set<number>();

  //
  // Call-site instantiation (§4.3 of the type-variables design). Gated on the
  // O(1) polytype test: a ground signature reaches none of this.
  //
  // Every site below that consumes a parameter type — `matches`, `isSubtype`,
  // `infer` — must see the INSTANTIATED ground parameter, never an open one
  // (§4.2 rule 1). The cheapest way to guarantee that is to instantiate the
  // parameter arrays ONCE, here, so no gate can accidentally read the pattern.
  // `paramStillOpen` records a residue that stayed open (impossible with a
  // total solver, but a leak must SKIP every write rather than write an open
  // type).
  //
  // `armSolution` is that same solve, when overload resolution already ran it
  // on this arm with this context (the policies it passes to `solveArm` are
  // exactly the three below) — reused rather than recomputed.
  const polyArm = polytypeArm(sig);
  const solved = polyArm
    ? (armSolution ??
      // A TRIAL of a single polytype arm: `resolveOverload` already solved
      // it with this exact context — reuse rather than re-solve.
      internals?.armSolution ??
      solveArm(polyArm, ops, {
        threadable,
        stripMissing,
        lazy,
        resolver: ce._typeResolver,
      }))
    : undefined;
  let paramStillOpen = false;
  const groundParam = (param: Type): Type => {
    if (!solved) return param;
    const t = instantiatedParam(param, solved.bindings);
    if (t !== undefined) return t;
    paramStillOpen = true;
    // Still open: admit everything at this position and skip every write.
    return 'any';
  };

  // D8 — absorbed top type × upper bounds. When a variable solved to an
  // ABSORBED `unknown` or `any` (a non-inferable top-typed operand), every
  // constraint that mentions it is satisfied PROVISIONALLY: the position is
  // admitted exactly as the engine's other provisional admissions are, and the
  // runtime stays the honest party. Without this, a generic signature would be
  // statically STRICTER than its ground counterpart on unknown/`any` operands,
  // breaking the §4.5 parity requirement. Deferred like the other provisional
  // admissions, so the final inference pass does not narrow on a guess.
  //
  // The solver also absorbs a top-level operand of type `error` at a call,
  // because a symbol that holds an error value gives its own error at every
  // parameter (`isErrorTypedOperand()`). The solver sees only the type, so
  // it absorbs other operands of type `error` too: a symbol declared `error`
  // that has NO value, or an application whose declared result type is
  // `error`. Neither evaluates to an error. Their positions are recorded in
  // `unheldErrorIdx` and checked after the per-position checks (see below).
  const provisionalIdx = new Set<number>();
  const unheldErrorIdx = new Set<number>();
  if (solved && solved.absorbed.size > 0 && polyArm) {
    const patterns = parameterPositions(polyArm, ops.length);
    patterns.forEach((p, k) => {
      if (p === undefined) return;
      for (const v of freeTypeVariables(p))
        if (solved.absorbed.has(v)) {
          provisionalIdx.add(k);
          const op = ops[k];
          if (op !== undefined && isErrorTypedWithoutErrorValue(op))
            unheldErrorIdx.add(k);
          return;
        }
    });
  }

  const params = sig.args?.map((x) => groundParam(x.type)) ?? [];
  const optParams = sig.optArgs?.map((x) => groundParam(x.type)) ?? [];
  // One instantiation for the whole variadic tail: the solver folds every
  // matching actual into the same variable's bound set (§4.3), so the tail's
  // instantiated pattern is position-independent.
  const varParam =
    sig.variadicArg === undefined
      ? undefined
      : groundParam(sig.variadicArg.type);
  const varParamCount = sig.variadicMin ?? 0;

  // A symbol whose type was inferred, at a collection parameter of a
  // library operator, is admitted provisionally: the refusal reads declared
  // types only (`isProvisionalCollectionOperand`).
  if (admitsProvisionalCollectionOperands(internals)) {
    ops.forEach((op, k) => {
      const param =
        k < params.length
          ? params[k]
          : k - params.length < optParams.length
            ? optParams[k - params.length]
            : varParam;
      if (param !== undefined && isProvisionalCollectionOperand(op, param))
        provisionalIdx.add(k);
    });
  }

  // §8 DISPLAY ONLY. A variable that got no call-site bound and carries no
  // declared bound is shown by its NAME, as the signature wrote it: the
  // message reads `expected indexed_collection<T>`, which says that the
  // slot is generic, rather than the solver's fallback
  // `indexed_collection<unknown>` (user decision D5, 2026-10-21,
  // `docs/plans/2026-10-21-unknown-inference-marker.md`). The bound
  // variables are substituted; the open ones stay variables, so the display
  // type is not reduced (the algebra never sees an open type) and is only
  // ever printed. These bindings never type the call itself.
  const displayBindings =
    solved && solved.unbound.size > 0
      ? Object.fromEntries(
          Object.entries(solved.bindings).filter(
            ([v]) => !solved.unbound.has(v)
          )
        )
      : undefined;
  const displayParam = (param: Type, ground: Type): Type => {
    if (displayBindings === undefined) return ground;
    const t = substituteTypeVariables(param, displayBindings);
    return freeTypeVariables(t).size === 0 ? reduceType(t) : t;
  };
  const displayParams =
    sig.args?.map((x, k) => displayParam(x.type, params[k])) ?? [];
  const displayOptParams =
    sig.optArgs?.map((x, k) => displayParam(x.type, optParams[k])) ?? [];
  const displayVarParam =
    sig.variadicArg === undefined || varParam === undefined
      ? undefined
      : displayParam(sig.variadicArg.type, varParam);

  /** The type to infer into the operand at `idx`. For a plain signature this
   * is the parameter itself; for an overload set it is the JOIN over every
   * viable arm (§4.3) — never the selected arm's parameter, which would
   * over-constrain the symbol (§4.5). */
  const inferenceTypeWithKindsAt = (
    idx: number,
    param: Type
  ): Type | undefined => {
    // §4.2 rule 1: never write while a parameter is still open.
    if (paramStillOpen) return undefined;
    if (!viableArms) return param;
    const joined = joinParamAt(viableArms, idx);
    // BACKSTOP (§4.2). `resolveOverload` instantiates every arm before the
    // join, so `viableArms` is ground and this join is too. A residue would
    // mean an unsolved variable leaked through the solver: skip the write
    // rather than narrow a symbol to a type variable.
    if (joined !== undefined && freeTypeVariables(joined).size > 0)
      return undefined;
    return joined;
  };
  // The type that the narrowing below writes on an operand at a parameter
  // whose type is `param`. A parameter that names a kind type beside other
  // types (`complex | quantity` at `Sin` and `Abs`) admits a value of the
  // kind, but a use there is no evidence that a valueless symbol holds one:
  // `Abs(x)` gives `x` the type `complex | infinity`, not `complex |
  // infinity | quantity`, which would make `x` a possible quantity (it would
  // keep the number rules away from `x - x`). A parameter that is only kind
  // types (`residue`) gives its type.
  const kinds = kindTypeNames(ce);
  const inferenceTypeAt = (idx: number, param: Type): Type | undefined => {
    const t = inferenceTypeWithKindsAt(idx, param);
    if (t === undefined || !hasKindArm(t, kinds)) return t;
    const numeric = withoutKindArms(t, kinds);
    return numeric === 'never' ? t : numeric;
  };

  // Give the elements of a list literal operand an element type
  // (`distributeLiteralElementInference()`), for the type `t` that the
  // narrowing below writes on the operand. At a parameter that a type variable
  // types, `t` is solved from the types of the operands themselves: in
  // `Reverse([p, q])`, `T` is solved from the type `vector<2>` of the list,
  // which reads the free symbol `p` as a number cell without requiring one.
  // Distributing `T = number` made `p` a number, so a later `p ∧ q` was an
  // error. So when an arm is generic, the element type comes from the
  // declared arms with each variable read as its bound
  // (`readTypeVariablesAsBounds()`, `unknown` for a variable with no bound),
  // joined over the arms that the operand inference joins (the viable arms
  // of an overload set): only what the signature requires is distributed.
  // The bound is an upper bound, so it is a requirement only where the
  // variable is covariant. So a generic parameter distributes only when its
  // element type is ground or a bare variable (`list<T>`,
  // `indexed_collection<T>`), or, for a tuple parameter, when each slot is
  // ground or a bare variable (`tuple<T, U>`; `elementIsBareOrGround()`).
  // Under a function
  // type (`list<(T) -> number>`) the bound `number` would require more of an
  // element than the call does (`(integer) -> number` is valid with
  // `T = integer`), and so would a named type that is not covariant in its
  // parameter (`list<sink<T>>`): such a parameter distributes nothing. A
  // ground signature distributes `t`, as before.
  // (ROADMAP CE-663, user decision 2026-10-30.)
  const genericArms = declaredArms.some(
    (arm) => (arm.typeParams?.length ?? 0) > 0
  );
  // Built on the first list literal operand only.
  let boundArms: FunctionSignature[] | undefined;
  const distribute = (op: Expression, idx: number, t: Type): void => {
    if (!isFunction(op, 'List') && !isFunction(op, 'Tuple')) return;
    let d: Type | undefined = t;
    if (genericArms) {
      if (
        !declaredArms.every((arm) =>
          elementIsBareOrGround(parameterPositions(arm, idx + 1)[idx])
        )
      )
        return;
      boundArms ??= declaredArms.map(
        (arm) => readTypeVariablesAsBounds(arm) as FunctionSignature
      );
      d = joinParamAt(boundArms, idx);
    }
    if (d !== undefined) distributeLiteralElementInference(op, d);
  };

  let i = 0;

  // Iterate over any required parameters
  for (const param of params) {
    const idx = i;
    const op = ops[i++];
    if (!op) {
      result.push(ce.error('missing'));
      isValid = false;
      continue;
    }
    if (lazy) {
      result.push(op);
      continue;
    }
    if (!op.isValid) {
      result.push(op);
      isValid = false;
      continue;
    }
    // A valid operand whose type is `error` (a symbol that holds an error
    // value, such as `w` after `w := Ln("a")`) always evaluates to its own
    // error. It passes through at every parameter type, and the evaluation
    // of the call then gives that error, with the frame of the call. The
    // type `error` is a member of no value type, not even `unknown`, so the
    // checks below refused it at some parameters (`unknown`, a collection,
    // `function`) with a new `incompatible-type` error ("expected
    // `unknown`, got `error`") that hid the real error. `checkNumericArgs`
    // passes such an operand through for the same reason. The position is
    // deferred, so the final inference pass does not narrow the symbol to
    // the parameter type.
    if (isErrorTypedOperand(op)) {
      result.push(op);
      deferredIdx.add(result.length - 1);
      continue;
    }
    if (strictTrialRefusesUnheldError(op, param, internals)) {
      result.push(ce.typeError(displayParams[idx] ?? param, op.type, op));
      isValid = false;
      continue;
    }
    if (op.type.isUnknown || op.type.type === 'any') {
      // An expression with an unknown or any type is assumed to be valid,
      // we'll infer the type later
      result.push(op);
      continue;
    }
    // A kind value admitted by the rules of the value kinds — see
    // `kindOperandAdmitted`. Deferred: the final inference pass must not
    // read a kind value as a number.
    if (
      kindOperandAdmitted(
        ce,
        op,
        param,
        idx,
        threadable,
        stripMissing,
        internals
      )
    ) {
      result.push(op);
      deferredIdx.add(result.length - 1);
      continue;
    }
    if (
      isThreadableAt(threadable, idx) &&
      couldBeUnkeyedCollectionOperand(op)
    ) {
      const checked = checkThreadableOperand(
        ce,
        op,
        param,
        displayParams[idx],
        internals
      );
      result.push(checked);
      if (!checked.isValid) isValid = false;
      continue;
    }
    // A list of points at a parameter declared as a point: the
    // application maps over the points (`isPointListArgumentType`). A tuple
    // at a scalar parameter is admitted too (`isScalarParameterTuple`).
    if (
      internals?.mapsPointLists &&
      (isPointListArgumentType(op.type.type, param) ||
        (isPointTensorArgumentType(op.type.type, param) &&
          !(
            pointArgumentMayMixDepths(op.type.type, param) &&
            listMixesPointsAndLists(op)
          )) ||
        (isPointParameterType(param) &&
          isFunction(op, 'List') &&
          op.nops === 0) ||
        isEmptyListArgumentType(op.type.type, param) ||
        isScalarParameterTuple(op.type.type, param))
    ) {
      result.push(op);
      continue;
    }
    // D8 provisional admission (see `provisionalIdx`).
    if (provisionalIdx.has(idx)) {
      result.push(op);
      deferredIdx.add(result.length - 1);
      continue;
    }
    // Rule 2 (arity) is asked ahead of EVERY admission that turns on
    // `matches(param)`, because subtyping answers arity in one direction
    // only: a callback with MORE required parameters than the slot supplies
    // is a strict subtype of the slot's arrow, so each of those admissions
    // would otherwise wave it through to fail at application. That is not
    // hypothetical for the fast paths just below — a symbol holding a binary
    // lambda reaches them with an INFERRED type that matches a unary arrow
    // slot. See `arrowSlotArityRejection`.
    const arityError = arrowSlotArityRejection(
      op,
      param,
      internals?.operatorName
    );
    if (arityError !== undefined) {
      result.push(arityError);
      isValid = false;
      continue;
    }
    if (hasInferredType(op) && op.type.matches(param)) {
      result.push(op);
      continue;
    }

    // A bare parameter typed only by its index reads (`p[1] + 1` gives
    // `tuple<number>`) at a slot that requires a LONGER tuple: index reads
    // do not prove the length of the argument, so this is not a conflict.
    // The parameter takes the tuple of the slot, with the components that
    // the reads gave (`indexReadTupleExtension()`). Without this, the call
    // was admitted with no write, and the parameter kept the shorter tuple
    // that the call refuses.
    //
    // The same parameter at a slot that requires a collection that is not a
    // tuple (`Drop(p, 2)`): the components that no read used take the
    // required element type (`indexReadTupleAtCollectionSlot()`). Without
    // this, `p[2] + 1` typed `p` as `tuple<unknown, number>`, which no
    // collection slot admitted, and the function literal was an error
    // (issue #448).
    if (
      !paramStillOpen &&
      hasInferredType(op) &&
      resolvedValueDefinition(op)?.value === undefined
    ) {
      const extended = ce._withoutFacts(
        () =>
          indexReadTupleExtension(op.type.type, param) ??
          indexReadTupleAtCollectionSlot(op.type.type, param)
      );
      if (extended !== undefined) {
        if (!internals?.noInference && !internals?.trial)
          ce._withoutFacts(() => op._infer(() => extended, 'replace'));
        result.push(op);
        continue;
      }
    }

    // The symbol's type was inferred (not declared), and the required type is
    // a subtype of the current inferred type. Narrowing is sound, so narrow
    // the symbol's type rather than erroring (e.g. `B` inferred as `value`
    // from `SetMinus(A, B)`, later required as `set` in `SetMinus(B, A)`).
    // NOT on the effect axis: see `narrowingPreservesEffects`. NOT to a
    // value-component type (`0`, `integer<0..10>`): one call requiring the
    // value does not prove the symbol always holds it — pinning `k: 0` from
    // `g(k)` would over-constrain every later use. Membership (below)
    // admits the concrete-witness case instead, without the write.
    // NOT while a parameter is still OPEN (§4.2 rule 1): `param` here is the
    // INSTANTIATED ground projection, and a site that could not be
    // instantiated skips the write rather than narrowing to a type variable.
    //
    // The eligibility test and the narrow itself both run with the
    // assumptions hidden. The test reads the operand's type, which an
    // assumption can narrow, and the narrow it gates writes a stored
    // contract that outlives the assumption; a fact that holds only at this
    // boxing must therefore not decide whether the contract is written.
    // `evidenceGuardedNarrow` reads the operand's type and the held value in
    // the same bracket, for the same reason.
    const narrowVerdict = ce._withoutFacts(() => {
      const target = inferredNarrowTarget(op.type.type, param);
      if (!(
        !paramStillOpen &&
        hasInferredType(op) &&
        target !== undefined &&
        !hasValueComponent(param) &&
        // Design E §3: never narrow a symbol's type TO an arrow slot's
        // arrow — the slot is a per-call supply, not evidence of the
        // symbol's own signature, and the write would manufacture a
        // contract that makes a later, differently-instantiated call
        // reject a symbol that both calls admit. The compatibility gate
        // below admits with no write instead.
        paramArrowArms(param) === undefined &&
        narrowingPreservesEffects(op.type.type, target)
      ))
        return 'fall-through';

      // EVIDENCE BEATS REQUIREMENT (`docs/INFERENCE_ROADMAP.md`, Phase 0
      // verdict, ruled 2026-08-18): use-narrowing is the CAS reading — a
      // use of a VALUELESS symbol declares what it must be (`k(n)` makes
      // `n` an integer). A symbol that HOLDS a value has assignment
      // evidence, and a use is a requirement to CHECK against that
      // evidence, not evidence to merge: narrowing here let `x = g()` (a
      // `number`) pass a `(integer) -> …` parameter by rewriting `x`'s
      // type to `integer` — the conflict only surfaced at evaluation, and
      // the stored type was left contradicting the held value.
      //
      // The evidence checked is the HELD VALUE'S own type, not the symbol's
      // stored type: assignment WIDENS (a `Complex(1,-1)` value stores the
      // symbol as `number`), so the stored type can fail a parameter —
      // `number ⊄ complex` — that the actual evidence satisfies. A value
      // whose own type fits is admitted with no write; one that does not
      // falls through to the ordinary `incompatible-type` error, minted at
      // canonicalization.
      return evidenceGuardedNarrow(ce, op, target, internals?.noInference);
    });
    if (narrowVerdict !== 'fall-through') {
      result.push(op);
      continue;
    }

    if (op.operatorDefinition?.inferredSignature && op.type.matches(param)) {
      result.push(op);
      continue;
    }

    // A broadcastable operand whose scalar base matches the parameter could
    // be a plain scalar at runtime: admit it (see broadcastableBaseMatches).
    if (broadcastableBaseMatches(op.type.type, param)) {
      result.push(op);
      continue;
    }

    if (!op.type.matches(param)) {
      // A `NaN` argument at a numeric parameter of a user function — see
      // `acceptsNaNArgument`. Deferred like the other admissions: the final
      // inference pass must not narrow a `nan`-typed symbol to the parameter.
      if (acceptsNaNArgument(op, param, internals)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // An absent argument at an annotated parameter of a function literal
      // is refused before any provisional admission — see
      // `refusesAbsentArgument`.
      if (refusesAbsentArgument(ce, op, param, internals, idx)) {
        result.push(ce.typeError(displayParams[idx] ?? param, op.type, op));
        isValid = false;
        continue;
      }
      // Design E §3: an arrow-typed slot admits by COMPATIBILITY, not
      // subtyping. Admitted operands carry no evidence of the slot's arrow
      // (it is a per-call supply, not the operand's own contract), so they
      // are excluded from the final `_infer(param)` narrowing via
      // `deferredIdx`, exactly like the other provisional admissions.
      const compat = arrowSlotAdmission(ce, op, param, displayParams[idx]);
      if (compat === 'admit') {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      if (compat !== undefined) {
        result.push(compat);
        isValid = false;
        continue;
      }
      // A one-cluster string literal at a `character` parameter narrows to
      // the character it denotes; a multi-cluster one falls through to the
      // ordinary type error below.
      const asCharacter = narrowCharacterLiteral(ce, op, param);
      if (asCharacter !== undefined) {
        result.push(asCharacter);
        substituted = true;
        continue;
      }
      // Value-component parameter (`0`, `integer<0..10>`): tri-state
      // admission (§4.4). A concrete value passing membership ADMITS; a
      // symbolic operand that is not provably disjoint is UNDECIDABLE and
      // is provisionally admitted (the call could be fine — dispatch stays
      // open until the value is known); only proven refutation errors.
      // Mirrored in `paramMatches` (overload.ts). Deferred like the other
      // provisional admissions: the final `_infer(param)` pass must not
      // narrow a symbol's type to the VALUE type (`k := 0; g(k)` would
      // otherwise pin `k: 0`).
      if (hasValueComponent(param) && admissionOf(op, param) !== 'refute') {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // Strip-before-validate (§3.B): admit an operand carrying a `missing`
      // arm whose stripped type still matches the parameter. Accepted
      // provisionally (added to `deferredIdx`) so the final `_infer(param)`
      // narrowing does not widen an unconstrained symbol (I4).
      if (strippedMatchesParam(op, param, idx, stripMissing)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // Contract B NaN admission — see `nanPolicyAdmitsParam`. Deferred
      // like the sibling admissions: the final `_infer(param)` pass must
      // not narrow a `nan`-typed symbol to the carrier.
      if (nanPolicyAdmitsParam(op, idx, internals?.nanPolicyAt)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // A parameter that only mapping uses typed as a number, at a
      // collection slot: admitted, and narrowed by the final inference pass
      // below (CE-1270).
      if (!op.type.isUnknown && isUntypedAtCollectionSlot(op, param)) {
        result.push(op);
        continue;
      }
      if (internals?.trial) {
        // TRIAL mode: the two construction-level repairs are admitted by
        // their write-free preconditions and NOT executed — a repair
        // entangles state that a trial must leave as it was (the
        // devolve shadow participates in the boxing-state rebuild loop; the
        // matrix repair re-boxes). A precondition is not a proof: the
        // winning arm's REAL validation runs the repair and may fail where
        // the trial admitted — that failure surfaces as the call's error,
        // with no second chance, byte-identical to the filter-era behavior.
        if (couldRepairFreshMatrixInference(ce, op, param, freshlyInferred)) {
          result.push(op);
          continue;
        }
        if (isRepairableOperatorSymbol(ce, op)) {
          result.push(op);
          continue;
        }
      } else {
        const repaired = repairFreshMatrixInference(
          ce,
          op,
          param,
          freshlyInferred
        );
        if (repaired) {
          result.push(repaired);
          substituted = true;
          continue;
        }
        // A bare uppercase symbol bound to a standard-library operator (`N`,
        // `D`) used where a value is required almost always means a variable
        // (`N \equiv 1 \pmod k`): devolve it to an unknown symbol, mirroring
        // the checkNumericArgs fallback.
        const devolved = devolveUnappliedOperator(ce, op);
        if (devolved !== null) {
          result.push(devolved);
          substituted = true;
          continue;
        }
      }
      // Overlap-deferred validation (§D6.2): a collection-kind parameter and
      // an operand whose static type does not REFUTE conformance (bare
      // `list`, unknown elements, `broadcastable<R>`, rank-compatible
      // nested lists) is accepted provisionally; runtime conformance is the
      // operator's own evaluate-time gate (handler precedence — a
      // nonconforming or still-symbolic operand stays inert or gets the
      // handler's specific error, e.g. `expected-square-matrix`). A list of
      // `Range` rows at a matrix parameter is deferred too
      // (`admitsRangeRowsAsMatrix`).
      if (
        admittedByDeferredOverlap(op, param) ||
        admitsRangeRowsAsMatrix(op, param, internals)
      ) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // A lazy collection whose element type fits without its `nan` arm —
      // see `lazyCollectionMatchesWithoutNan`.
      if (lazyCollectionMatchesWithoutNan(op, param)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // An inferred signature with placeholder `unknown` slots reconciles
      // against the declared parameter (see `admitsPlaceholderSignature`).
      if (admitsPlaceholderSignature(op, param)) {
        result.push(op);
        continue;
      }
      // R1 overlap admission — see `overlapAdmission`. Deferred: an
      // admission on overlap is a possibility, not a proof. Never in a
      // first-pass TRIAL (arm viability keeps the strict reading — see the
      // scoping notes on `overlapAdmission`); active again in the
      // second-pass `overlapTrial`.
      if (
        (!internals?.trial || internals?.overlapTrial) &&
        overlapAdmission(op, param)
      ) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      result.push(ce.typeError(displayParams[idx] ?? param, op.type, op));
      isValid = false;
      continue;
    }
    result.push(op);
  }

  // Iterate over any optional parameters
  for (const param of optParams) {
    const op = ops[i];
    if (!op) {
      // No more ops, we're done
      break;
    }
    if (lazy) {
      result.push(op);
      i += 1;
      continue;
    }
    if (!op.isValid) {
      result.push(op);
      isValid = false;
      i += 1;
      continue;
    }
    // An operand typed `error` passes through — see the required
    // parameters above.
    if (isErrorTypedOperand(op)) {
      result.push(op);
      deferredIdx.add(result.length - 1);
      i += 1;
      continue;
    }
    if (strictTrialRefusesUnheldError(op, param, internals)) {
      result.push(
        ce.typeError(displayOptParams[i - params.length] ?? param, op.type, op)
      );
      isValid = false;
      i += 1;
      continue;
    }
    if (op.type.isUnknown || op.type.type === 'any') {
      // An expression with an unknown or any type is assumed to be valid,
      // we'll infer the type later
      result.push(op);
      i += 1;
      continue;
    }
    // A kind value — see the required parameters above.
    if (
      kindOperandAdmitted(ce, op, param, i, threadable, stripMissing, internals)
    ) {
      result.push(op);
      deferredIdx.add(result.length - 1);
      i += 1;
      continue;
    }
    if (isThreadableAt(threadable, i) && couldBeUnkeyedCollectionOperand(op)) {
      const checked = checkThreadableOperand(
        ce,
        op,
        param,
        displayOptParams[i - params.length],
        internals
      );
      result.push(checked);
      if (!checked.isValid) isValid = false;
      i += 1;
      continue;
    }
    // A list of points at a parameter declared as a point, and a tuple at a
    // scalar parameter, as at the required parameters above.
    if (
      internals?.mapsPointLists &&
      (isPointListArgumentType(op.type.type, param) ||
        (isPointTensorArgumentType(op.type.type, param) &&
          !(
            pointArgumentMayMixDepths(op.type.type, param) &&
            listMixesPointsAndLists(op)
          )) ||
        (isPointParameterType(param) &&
          isFunction(op, 'List') &&
          op.nops === 0) ||
        isEmptyListArgumentType(op.type.type, param) ||
        isScalarParameterTuple(op.type.type, param))
    ) {
      result.push(op);
      i += 1;
      continue;
    }
    // D8 provisional admission (see `provisionalIdx`).
    if (provisionalIdx.has(i)) {
      result.push(op);
      deferredIdx.add(result.length - 1);
      i += 1;
      continue;
    }
    // Rule 2 (arity) ahead of every `matches(param)` admission — see the
    // required-param gate.
    const optArityError = arrowSlotArityRejection(
      op,
      param,
      internals?.operatorName
    );
    if (optArityError !== undefined) {
      result.push(optArityError);
      isValid = false;
      i += 1;
      continue;
    }
    if (hasInferredType(op) && op.type.matches(param)) {
      // There was an inferred type, and it is contravariant with `number`
      // e.g. "any". We'll narrow it down to `number` when we infer later.
      result.push(op);
      i += 1;
      continue;
    }
    // Inferred (not declared) symbol type, and the required type is a subtype
    // of the current inferred type: narrow rather than error. NOT on the
    // effect axis (`narrowingPreservesEffects`); NOT to a value-component
    // type; NOT to an arrow slot's arrow (Design E — see the required-param
    // gate).
    //
    // Evidence-beats-requirement — see `evidenceGuardedNarrow`. Decision and
    // write are fact-blind for the reason given at the required-parameter
    // gate above.
    const optNarrowVerdict = ce._withoutFacts(() => {
      const target = inferredNarrowTarget(op.type.type, param);
      if (!(
        !paramStillOpen &&
        hasInferredType(op) &&
        target !== undefined &&
        !hasValueComponent(param) &&
        paramArrowArms(param) === undefined &&
        narrowingPreservesEffects(op.type.type, target)
      ))
        return 'fall-through';
      return evidenceGuardedNarrow(ce, op, target, internals?.noInference);
    });
    if (optNarrowVerdict !== 'fall-through') {
      result.push(op);
      i += 1;
      continue;
    }
    // Broadcastable operand: could be a plain scalar at runtime, admit it.
    if (broadcastableBaseMatches(op.type.type, param)) {
      result.push(op);
      i += 1;
      continue;
    }
    if (!op.type.matches(param)) {
      // A `NaN` argument at a numeric parameter of a user function — see
      // the required-param gate.
      if (acceptsNaNArgument(op, param, internals)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      // An absent argument at an annotated parameter of a function literal —
      // see the required-param gate.
      if (refusesAbsentArgument(ce, op, param, internals, i)) {
        result.push(
          ce.typeError(
            displayOptParams[i - params.length] ?? param,
            op.type,
            op
          )
        );
        isValid = false;
        i += 1;
        continue;
      }
      // Design E §3 compatibility admission — see the required-param gate.
      const compat = arrowSlotAdmission(
        ce,
        op,
        param,
        displayOptParams[i - params.length]
      );
      if (compat === 'admit') {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      if (compat !== undefined) {
        result.push(compat);
        isValid = false;
        i += 1;
        continue;
      }
      // Literal narrowing at a `character` parameter — see the required-param
      // gate.
      const asCharacter = narrowCharacterLiteral(ce, op, param);
      if (asCharacter !== undefined) {
        result.push(asCharacter);
        substituted = true;
        i += 1;
        continue;
      }
      // Value-component tri-state admission — see the required-param gate
      // (deferred: the final inference pass must not narrow a symbol to the
      // value type).
      if (hasValueComponent(param) && admissionOf(op, param) !== 'refute') {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      // Strip-before-validate (§3.B) — see the required-param gate.
      if (strippedMatchesParam(op, param, i, stripMissing)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      // Contract B NaN admission — see the required-param gate.
      if (nanPolicyAdmitsParam(op, i, internals?.nanPolicyAt)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      // The two repairs that rewrite an operand at construction time — a
      // fresh matrix inference re-boxed against the parameter, and a bare
      // single-letter builtin (`N`, `D`) devolved to a variable — run here
      // exactly as they do for a required parameter. A trial validation
      // admits an operand by the repair's write-free precondition without
      // running it; a real validation runs the repair. An optional slot sees
      // the same operands a required slot does: `Range(1, N)` puts the bare
      // builtin `N` in the optional upper bound, and `N` must become a
      // variable there as it does in `Range(N)` or `N + 1`.
      if (!op.type.isUnknown && isUntypedAtCollectionSlot(op, param)) {
        result.push(op);
        i += 1;
        continue;
      }
      if (internals?.trial) {
        if (couldRepairFreshMatrixInference(ce, op, param, freshlyInferred)) {
          result.push(op);
          i += 1;
          continue;
        }
        if (isRepairableOperatorSymbol(ce, op)) {
          result.push(op);
          i += 1;
          continue;
        }
      } else {
        const repaired = repairFreshMatrixInference(
          ce,
          op,
          param,
          freshlyInferred
        );
        if (repaired) {
          result.push(repaired);
          substituted = true;
          i += 1;
          continue;
        }
        const devolved = devolveUnappliedOperator(ce, op);
        if (devolved !== null) {
          result.push(devolved);
          substituted = true;
          i += 1;
          continue;
        }
      }
      // Overlap-deferred validation (§D6.2) — see the required-param gate.
      if (
        admittedByDeferredOverlap(op, param) ||
        admitsRangeRowsAsMatrix(op, param, internals)
      ) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      // Lazy collection without its `nan` arm — see the required-param gate.
      if (lazyCollectionMatchesWithoutNan(op, param)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      // Placeholder-signature reconciliation — see the required-param gate.
      if (admitsPlaceholderSignature(op, param)) {
        result.push(op);
        i += 1;
        continue;
      }
      // R1 overlap admission — never in a first-pass trial (see the
      // required-param gate).
      if (
        (!internals?.trial || internals?.overlapTrial) &&
        overlapAdmission(op, param)
      ) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        i += 1;
        continue;
      }
      result.push(
        ce.typeError(displayOptParams[i - params.length] ?? param, op.type, op)
      );
      isValid = false;
      i += 1;
      continue;
    }
    result.push(op);
    i += 1;
  }

  // Iterate over any remaining ops
  if (varParam) {
    let additionalParam = 0;
    for (const op of ops.slice(i)) {
      i += 1;
      additionalParam += 1;
      if (lazy) {
        result.push(op);
        continue;
      }
      if (!op.isValid) {
        result.push(op);
        isValid = false;
        continue;
      }
      // An operand typed `error` passes through — see the required
      // parameters above.
      if (isErrorTypedOperand(op)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      if (strictTrialRefusesUnheldError(op, varParam, internals)) {
        result.push(ce.typeError(displayVarParam ?? varParam, op.type, op));
        isValid = false;
        continue;
      }
      if (op.type.isUnknown || op.type.type === 'any') {
        // An expression with an unknown or any type is assumed to be valid,
        // we'll infer the type later
        result.push(op);
        continue;
      }
      // A kind value — see the required parameters above.
      if (
        kindOperandAdmitted(
          ce,
          op,
          varParam,
          i - 1,
          threadable,
          stripMissing,
          internals
        )
      ) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // The operand index is `i - 1` (already incremented at the loop top).
      if (
        isThreadableAt(threadable, i - 1) &&
        couldBeUnkeyedCollectionOperand(op)
      ) {
        const checked = checkThreadableOperand(
          ce,
          op,
          varParam,
          displayVarParam,
          internals
        );
        result.push(checked);
        if (!checked.isValid) isValid = false;
        continue;
      }
      // D8 provisional admission (see `provisionalIdx`).
      if (provisionalIdx.has(i - 1)) {
        result.push(op);
        deferredIdx.add(result.length - 1);
        continue;
      }
      // Rule 2 (arity) ahead of every `matches(varParam)` admission — see the
      // required-param gate.
      const varArityError = arrowSlotArityRejection(
        op,
        varParam,
        internals?.operatorName
      );
      if (varArityError !== undefined) {
        result.push(varArityError);
        isValid = false;
        continue;
      }
      if (hasInferredType(op) && op.type.matches(varParam)) {
        // There was an inferred type, and it is contravariant with `number`
        // e.g. "any". We'll narrow it down `number` to  when we infer later.
        result.push(op);
        continue;
      }
      // Inferred (not declared) symbol type, and the required variadic type is
      // a subtype of the current inferred type: narrow rather than error. NOT
      // on the effect axis (`narrowingPreservesEffects`); NOT to a
      // value-component type (see the required-param gate).
      //
      // Evidence-beats-requirement — see `evidenceGuardedNarrow`. Decision
      // and write are fact-blind for the reason given at the
      // required-parameter gate above.
      const varNarrowVerdict = ce._withoutFacts(() => {
        const target = inferredNarrowTarget(op.type.type, varParam);
        if (!(
          !paramStillOpen &&
          hasInferredType(op) &&
          target !== undefined &&
          !hasValueComponent(varParam) &&
          paramArrowArms(varParam) === undefined &&
          narrowingPreservesEffects(op.type.type, target)
        ))
          return 'fall-through';
        return evidenceGuardedNarrow(ce, op, target, internals?.noInference);
      });
      if (varNarrowVerdict !== 'fall-through') {
        result.push(op);
        continue;
      }
      // Broadcastable operand: could be a plain scalar at runtime, admit it.
      if (broadcastableBaseMatches(op.type.type, varParam)) {
        result.push(op);
        continue;
      }
      if (!op.type.matches(varParam)) {
        // A `NaN` argument at a numeric parameter of a user function — see
        // the required-param gate.
        if (acceptsNaNArgument(op, varParam, internals)) {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        // Design E §3 compatibility admission — see the required-param gate.
        const compat = arrowSlotAdmission(ce, op, varParam, displayVarParam);
        if (compat === 'admit') {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        if (compat !== undefined) {
          result.push(compat);
          isValid = false;
          continue;
        }
        // Literal narrowing at a `character` parameter — see the
        // required-param gate.
        const asCharacter = narrowCharacterLiteral(ce, op, varParam);
        if (asCharacter !== undefined) {
          result.push(asCharacter);
          substituted = true;
          continue;
        }
        // Value-component tri-state admission — see the required-param gate
        // (deferred: the final inference pass must not narrow a symbol to
        // the value type).
        if (
          hasValueComponent(varParam) &&
          admissionOf(op, varParam) !== 'refute'
        ) {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        // Strip-before-validate (§3.B) — see the required-param gate. The
        // operand index is `i - 1` (already incremented at the loop top).
        if (strippedMatchesParam(op, varParam, i - 1, stripMissing)) {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        // Contract B NaN admission — see the required-param gate.
        if (nanPolicyAdmitsParam(op, i - 1, internals?.nanPolicyAt)) {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        // The two repairs that rewrite an operand at construction time (a
        // fresh matrix inference re-boxed against the parameter, a bare
        // single-letter builtin devolved to a variable) run for a variadic
        // operand as they do for a required or optional one: a trial
        // validation admits by the write-free precondition, a real validation
        // runs the repair. `Max(1, N)` puts the bare builtin `N` in the
        // variadic tail.
        if (!op.type.isUnknown && isUntypedAtCollectionSlot(op, varParam)) {
          result.push(op);
          continue;
        }
        if (internals?.trial) {
          if (
            couldRepairFreshMatrixInference(ce, op, varParam, freshlyInferred)
          ) {
            result.push(op);
            continue;
          }
          if (isRepairableOperatorSymbol(ce, op)) {
            result.push(op);
            continue;
          }
        } else {
          const repaired = repairFreshMatrixInference(
            ce,
            op,
            varParam,
            freshlyInferred
          );
          if (repaired) {
            result.push(repaired);
            substituted = true;
            continue;
          }
          const devolved = devolveUnappliedOperator(ce, op);
          if (devolved !== null) {
            result.push(devolved);
            substituted = true;
            continue;
          }
        }
        // Overlap-deferred validation (§D6.2) — see the required-param gate.
        if (
          admittedByDeferredOverlap(op, varParam) ||
          admitsRangeRowsAsMatrix(op, varParam, internals)
        ) {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        // Lazy collection without its `nan` arm — see the required-param
        // gate.
        if (lazyCollectionMatchesWithoutNan(op, varParam)) {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        // Placeholder-signature reconciliation — see the required-param gate.
        if (admitsPlaceholderSignature(op, varParam)) {
          result.push(op);
          continue;
        }
        // R1 overlap admission — never in a first-pass trial (see the
        // required-param gate).
        if (
          (!internals?.trial || internals?.overlapTrial) &&
          overlapAdmission(op, varParam)
        ) {
          result.push(op);
          deferredIdx.add(result.length - 1);
          continue;
        }
        result.push(ce.typeError(displayVarParam ?? varParam, op.type, op));
        isValid = false;
        continue;
      }
      result.push(op);
    }
    if (additionalParam < varParamCount) {
      // We didn't get enough parameters for the variadic argument
      result.push(ce.error('missing'));
      isValid = false;
    }
  }

  // Are there any remaining parameters?
  if (i < ops.length) {
    for (const op of ops.slice(i)) {
      result.push(ce.error('unexpected-argument', op.toString()));
      isValid = false;
    }
  }

  // An operand of type `error` that does not hold an error value, at a
  // position whose type variable the solver absorbed (see `unheldErrorIdx`
  // above). The operand is checked against the parameter with each absorbed
  // variable read at its declared bound, or at `any` when the variable has
  // no bound, by the same rule as the ground route:
  // - a parameter that accepts the type `error` (`any`, or `error` itself)
  //   admits the operand;
  // - a scalar parameter such as `number`, `string` or `boolean` admits it,
  //   because `typesOverlap()` reports that `error` overlaps every type
  //   (`overlapAdmission()`). So `(T) -> T where T: number` applied to `e`
  //   (declared `error`, with no value) is valid and evaluates to itself, as
  //   `(number) -> number` applied to `e` and `Sqrt(e)` do;
  // - a collection parameter (`T: list`, `T: indexed_collection`) refuses
  //   it, as the ground parameter `list` does, because `overlapAdmission()`
  //   does not apply to the parameters that the runtime conformance check
  //   does not police.
  if (unheldErrorIdx.size > 0 && solved && polyArm) {
    const patterns = parameterPositions(polyArm, ops.length);
    const atBounds: Record<string, Type> = { ...solved.bindings };
    for (const tp of polyArm.typeParams ?? [])
      if (solved.absorbed.has(tp.name)) atBounds[tp.name] = tp.bound ?? 'any';
    for (const idx of unheldErrorIdx) {
      if (idx >= result.length || !result[idx].isValid) continue;
      const pattern = patterns[idx];
      // A parameter that stays open admits everything, as in `groundParam()`.
      const expected =
        (pattern !== undefined
          ? instantiatedParam(pattern, atBounds)
          : undefined) ?? 'any';
      const op = ops[idx];
      if (provablyAdmits('error', expected)) continue;
      // The admission on overlap, deferred as in the per-position checks.
      // As there, it is not active in the first, strict pass of overload
      // resolution, and it is active in the second pass (`overlapTrial`).
      // So `((string) -> string) & ((T) -> T where T: number)` admits `e`,
      // as `((string) -> string) & ((number) -> number)` does (user
      // decision 2026-10-20).
      if (
        op !== undefined &&
        (!internals?.trial || internals?.overlapTrial) &&
        overlapAdmission(op, expected)
      ) {
        deferredIdx.add(idx);
        continue;
      }
      result[idx] = ce.typeError(expected, op?.type, op);
      isValid = false;
    }
  }

  // A bound constraint the per-position gates cannot see (§8): the solved
  // value violates a declared bound, or two contravariant positions demand
  // incompatible instantiations. Every position matched its INSTANTIATED
  // parameter, so this is the only place the conflict can surface. The
  // displayed expected type is always ground (§8 rule 1).
  if (solved && solved.failures.length > 0 && polyArm) {
    const patterns = parameterPositions(polyArm, ops.length);
    for (const f of solved.failures) {
      const idx = f.index ?? 0;
      if (idx >= result.length) continue;
      if (!result[idx].isValid) continue;
      // Contract B NaN admission on the polytype route — the twin of the
      // per-position carve-in (`nanPolicyAdmitsParam`): a proven-`NaN`
      // operand at a `propagate` or `handle` slot is admitted although its
      // type `nan` violates a declared bound that excludes it (a polytype
      // `(T) -> T where T: complex` with `nanBehavior: 'propagate'`) — the
      // runtime gate owns it. No library head spells such a bound yet
      // (`Conjugate` keeps `T: number`, which admits `nan` and never fails
      // here); the seam is pinned on a declared operator in
      // `test/compute-engine/error-model.test.ts`.
      // A bound violation is the only failure a NaN literal can raise here
      // (it demands no contravariant instantiation). Deferred like the
      // sibling admissions, so the final inference pass does not narrow a
      // `nan`-typed symbol to the bound.
      if (
        f.kind === 'bound' &&
        nanPolicyAdmitsParam(ops[idx], idx, internals?.nanPolicyAt)
      ) {
        deferredIdx.add(idx);
        continue;
      }
      // A value of a value kind declared with `admittedAs: 'real'` or
      // `'number'` at a type variable whose declared bound admits its carrier
      // (`(T) -> T where T: number` at `Conjugate`, `Chop`, `Remainder`,
      // `BaseForm`): the carrier is checked against the bound, as at a
      // ground parameter (`admitsThroughCarrier()`), and the call is typed
      // by the rules of the kinds, not by `T`
      // (`docs/plans/2026-10-26-value-kinds.md`, section 4.2 and A14 of
      // section 13). A function with a body admits a kind value only by type
      // (decision B).
      if (
        f.kind === 'bound' &&
        !internals?.userFunction &&
        ops[idx] !== undefined &&
        admitsThroughCarrier(
          ce,
          ops[idx].type.type,
          f.expected,
          isThreadableAt(threadable, idx),
          stripMissing?.(idx) === true
        )
      ) {
        deferredIdx.add(idx);
        continue;
      }
      // A `where T is P` constraint (protocols design P19) is not a subtype
      // violation, so it does not report as one: the offending operand carries
      // `protocol-constraint-unsatisfied`, naming the protocol and the type
      // the variable solved to.
      if (f.kind === 'protocol') {
        result[idx] = ce.error(
          [
            'protocol-constraint-unsatisfied',
            `\`${typeToString(f.solution)}\` does not conform to the \`${f.protocol}\` protocol (\`${f.variable}\` is constrained by \`where ${f.variable} is ${f.protocol}\`)`,
          ],
          ops[idx]?.toString()
        );
        isValid = false;
        continue;
      }
      // For a contravariant (callback) conflict the expected type displayed is
      // the blamed position's parameter with the variable set to what the
      // OTHER constraints pin it to — §8's `(integer) -> boolean`, not the
      // bare constraining type. A violated DECLARED bound gets the same
      // treatment with the variable set to the bound itself: the blamed
      // position may be a CONSTRUCTOR pattern (`list<T>` at a `T: integer`
      // bound), where displaying the bare bound would read "expected
      // `integer`, got `vector<real^2>`" — the instantiated pattern
      // (`list<integer>`) is the position's true expected type. For a
      // bare-variable position the instantiation IS the bound, so the message
      // is unchanged there.
      const pattern = patterns[idx];
      const pinTo =
        f.kind === 'upper' && f.pin !== undefined
          ? f.pin
          : f.kind === 'bound'
            ? f.expected
            : undefined;
      const expected =
        pinTo !== undefined && pattern !== undefined
          ? (instantiatedParam(pattern, {
              ...solved.bindings,
              [f.variable]: pinTo,
            }) ?? f.expected)
          : f.expected;
      result[idx] = ce.typeError(expected, ops[idx]?.type, ops[idx]);
      isValid = false;
    }
  }

  if (!isValid) return result;

  //
  // All arguments are valid, we can infer the domain of the arguments
  //
  // When an operand was substituted, infer on (and return) the substituted
  // list: `result` and `ops` are index-aligned on the valid path (one entry
  // pushed per consumed operand).
  // The whole pass is fact-blind. `couldBeUnkeyedCollectionOperand` reads each
  // operand's EFFECTIVE type to decide whether the parameter type is inferred
  // onto it at all, and that decision writes a contract: an assumption that
  // gives the operand a scalar tier must not suppress a narrowing which
  // outlives the assumption.
  const finalOps = substituted ? result : ops;
  // Check-only mode (`noInference`) and the trial of an overload arm: the
  // verdicts above stand, the narrowing below is skipped. A trial writes on
  // no definition: the winning arm validates again, and makes this write.
  if (internals?.noInference || internals?.trial)
    return substituted ? result : null;
  ce._withoutFacts(() => {
    i = 0;
    for (const param of params) {
      const t = inferenceTypeAt(i, param);
      if (t !== undefined && !lazy && !deferredIdx.has(i))
        if (
          !isThreadableAt(threadable, i) ||
          !couldBeUnkeyedCollectionOperand(finalOps[i])
        ) {
          finalOps[i]._infer(() => t);
          distribute(finalOps[i], i, t);
        }
      i += 1;
    }
    for (const param of optParams) {
      if (!finalOps[i]) break;
      const t = inferenceTypeAt(i, param);
      if (t !== undefined && !lazy && !deferredIdx.has(i))
        if (
          !isThreadableAt(threadable, i) ||
          !couldBeUnkeyedCollectionOperand(finalOps[i])
        ) {
          finalOps[i]._infer(() => t);
          distribute(finalOps[i], i, t);
        }
      i += 1;
    }
    if (varParam) {
      for (const op of finalOps.slice(i)) {
        const t = inferenceTypeAt(i, varParam);
        if (t !== undefined && !lazy && !deferredIdx.has(i))
          if (
            !isThreadableAt(threadable, i) ||
            !couldBeUnkeyedCollectionOperand(op)
          ) {
            op._infer(() => t);
            distribute(op, i, t);
          }
        i += 1;
      }
    }
  });
  return substituted ? result : null;
}

// The two targets of `freshInferenceTarget`, boxed once when the module
// loads. They have no type resolver: `matches()` reads the resolver only to
// parse a type STRING argument, and `freshInferenceTarget` passes a `Type`.
const MATRIX_BOXED_TYPE = new BoxedType('matrix');
const LIST_OF_NUMBERS_BOXED_TYPE = new BoxedType('list<number>');

/**
 * The collection type that the repair below gives its symbols for this
 * parameter, or `undefined` when the repair does not apply. It is `matrix`
 * when a `matrix` argument satisfies the parameter. Otherwise it is
 * `list<number>` when a list of numbers satisfies it: the data parameter of
 * the statistics operators (`list<number> | set<number> | tuple`) refuses a
 * matrix (ROADMAP CE-13), and the symbol in `Histogram(P + 0.5, 1/100)` is a
 * list of data (Tycho item 321).
 *
 * The test is "would an argument of that type satisfy the parameter", not
 * "is the parameter that type". The direction matters for a UNION parameter
 * (`LinearSolve`'s `matrix | vector`): a union is assignable to `R` only when
 * EVERY arm is, so `matrix | vector` does not match `matrix`, while `matrix`
 * *is* assignable to `matrix | vector`. The reversed spelling silently
 * declined the repair for every union-typed parameter.
 */
function freshInferenceTarget(
  expected: Type
): 'matrix' | 'list<number>' | undefined {
  if (MATRIX_BOXED_TYPE.matches(expected)) return 'matrix';
  if (LIST_OF_NUMBERS_BOXED_TYPE.matches(expected)) return 'list<number>';
  return undefined;
}

/**
 * The **write-free** precondition of {@link repairFreshMatrixInference}: true
 * when the repair could apply to this operand/parameter pair.
 *
 * The repair itself mutates definitions, re-boxes, and rolls back on failure,
 * so overload resolution — which must not write (§4.2 of the overload design)
 * — cannot run it to find out. It consults this instead. Deliberately
 * conservative in the ADMITTING direction: it checks the repair's own
 * entry gates (a `matrix`-ish parameter, at least one fresh eligible symbol,
 * and a non-empty structural plan) but not whether the re-box would actually
 * produce a conforming type. An arm kept on a repair that then fails is handed
 * to full validation, which produces the error — exactly what happens for a
 * plain signature. Refusing to model the repair at all would be worse: an
 * operand a plain signature repairs and accepts would silently match no arm.
 */
function couldRepairFreshMatrixInference(
  ce: ComputeEngine,
  op: Expression,
  expected: Type,
  freshlyInferred?: ReadonlySet<BoxedValueDefinition>
): boolean {
  if (!freshlyInferred || !freshInferenceTarget(expected)) return false;

  const eligible = new Set<string>();
  for (const name of op.freeVariables) {
    const site = unitRepairSite(ce, op, name);
    if (site !== undefined) {
      if (site.eligible) eligible.add(name);
      continue;
    }
    const def = ce.lookupDefinition(name);
    if (!def || !isValueDef(def) || !def.value.inferredType) continue;
    // Keep these tests in step with `repairFreshMatrixInference`, which
    // explains them: a parameter is not retyped, and a symbol already typed
    // as a collection or as text is not a numeric guess, so it is not
    // eligible.
    if (isFunctionLiteralParameter(def.value)) continue;
    if (hasNonNumericShapeEvidence(def.value.type.type)) continue;
    if (freshlyInferred.has(def.value) || def.value.type.isUnknown)
      eligible.add(name);
  }
  if (eligible.size === 0) return false;

  const names = matrixInferencePlan(op, eligible);
  return names !== null && names.size > 0;
}

/** The type of a text value: a `string` or a `character`. */
const TEXT_TYPE: Type = Object.freeze({
  kind: 'union',
  types: ['string', 'character'],
}) as Type;

/**
 * True when an inferred type is a collection type or a text type
 * (`string`, `character`, or a union of the two). Such a type is evidence of
 * the symbol's shape, not a numeric guess, so the fresh-matrix repair must not
 * retype the symbol. Shared by {@link couldRepairFreshMatrixInference} and
 * {@link repairFreshMatrixInference} so that the two tests stay the same.
 */
function hasNonNumericShapeEvidence(type: Type): boolean {
  return isSubtype(type, COLLECTION_SHAPE_TYPE) || isSubtype(type, TEXT_TYPE);
}

/**
 * Where the fresh-matrix repair retypes a name whose requirements are in a
 * unit environment (`binding-unit.ts`).
 * - `env`: the environment that the write goes in: that of the trial in
 *   progress, else of the operation in progress (rule 8 of
 *   `docs/plans/2026-11-09-binding-units-slice-1-spec.md`), else of the
 *   occurrence (rule 6).
 * - `key`: the key of the entry: the home scope of a free name, or the value
 *   definition of the occurrence.
 * - `eligible`: the entry is a fresh numeric guess, as `freshlyInferred`
 *   states it for a definition: the root construction in progress wrote it,
 *   or the name has no entry yet, and the occurrence's type (rule 4) is not a
 *   collection or a text type (`hasNonNumericShapeEvidence()`). An entry
 *   that an earlier boxing wrote is not retyped: that boxing's evidence
 *   stays, and its expression keeps its type.
 */
type UnitRepairSite = {
  env: UnitEnvironment | undefined;
  key: object;
  eligible: boolean;
  /** For a parameter of a function literal being boxed: the record of the
   * literal, which holds the entry (`ParameterRecord`). */
  literal?: ParameterRecord;
};

/**
 * The entry of a unit environment that
 * the fresh-matrix repair retypes for the name `name` of `op`
 * (`UnitRepairSite`), or `undefined` when the repair retypes the definition
 * of the name.
 *
 * Boxing writes no definition (rule 1 of
 * `docs/plans/2026-11-09-binding-units-slice-1-spec.md`): the requirements of
 * a free name, and of a name whose definition has an inferred type or the type
 * `unknown`, are entries of the environment (rule 2), and the type of an
 * occurrence reads them (rule 4). The repair replaces that entry. The uses
 * of a parameter of a function literal write entries too
 * (`BoxedSymbol._inferOnParameter()`). A definition that the root
 * construction made in a scope that it created (the index of a `Sum`, a
 * local of a block) is still narrowed by its uses
 * (`BoxedSymbol._unitWriteScope()`): its uses wrote no entry, and the repair
 * retypes that definition.
 */
function unitRepairSite(
  ce: ComputeEngine,
  op: Expression,
  name: string
): UnitRepairSite | undefined {
  const occurrence = symbolOccurrence(op, name);
  if (occurrence === undefined) return undefined;
  const sym = occurrence as Expression & {
    _env?: UnitEnvironment;
    _homeScope?: object;
  };
  const free = isFreeName(sym);
  let key: object | undefined;
  if (free) {
    // A free name that a later declaration with an explicit type resolves
    // to reads that type (rule 4.1): no entry changes it.
    const resolved = freeBinding(sym);
    if (
      resolved !== undefined &&
      (!isValueDef(resolved) ||
        (!resolved.value.inferredType && !resolved.value.type.isUnknown))
    )
      return { env: undefined, key: sym, eligible: false };
    key = sym._homeScope;
  } else {
    const def = sym.valueDefinition;
    if (def === undefined || (!def.inferredType && !def.type.isUnknown))
      return undefined;
    // A definition with a concrete inferred type that the root construction
    // in progress did not make was typed before it, by `ce.infer()`, an
    // assignment or an evaluation (boxing writes no definition, rule 1). It
    // is the evidence of an earlier expression, as an entry that an earlier
    // boxing wrote: the repair does not retype the name.
    if (!def.declaredType.isUnknown && !ce._boxingState.isDefinitionMade(def))
      return { env: undefined, key: def, eligible: false };
    key = def;
  }
  if (key === undefined) return undefined;

  const state = ce._boxingState;
  const trial = state.trialEnvironment();
  // The uses of a parameter of a function literal being boxed write in the
  // environment of the literal (`BoxedSymbol._inferOnParameter()`).
  const literal = free
    ? undefined
    : ce._parameterRecord(key as BoxedValueDefinition);
  const operation =
    literal === undefined ? state.currentOperation() : undefined;
  const own = literal?.env ?? sym._env;
  const entry =
    trial?.lookup(key, name) ??
    operation?.lookup(key, name) ??
    own?.lookup(key, name);
  // The uses of a definition wrote on the definition, not in an
  // environment.
  if (!free && entry === undefined) return undefined;

  const env = trial ?? operation ?? own;
  // The failure leg of the repair undoes its writes through the journal that
  // a root construction opens (`EngineBoxingState.noteUnitWrite()`).
  if (env === undefined || !state.isRootActive)
    return { env: undefined, key, eligible: false };
  const fresh =
    entry === undefined ||
    trial?.get(key, name) !== undefined ||
    operation?.journaledEntry(key, name) === true ||
    own?.journaledEntry(key, name) === true;
  return {
    env,
    key,
    eligible: fresh && !hasNonNumericShapeEvidence(sym.type.type),
    literal,
  };
}

/**
 * The first free occurrence of the symbol `name` in `expr`, depth first. An
 * operand whose scope binds `name` (the parameter of a function literal, the
 * index of a `Sum`) is not entered: its occurrences are another variable.
 */
function symbolOccurrence(
  expr: Expression,
  name: string
): Expression | undefined {
  if (isSymbol(expr)) return expr.symbol === name ? expr : undefined;
  if (!isFunction(expr)) return undefined;
  const scope = expr.localScope;
  if (
    scope !== undefined &&
    (scope.bindings.has(name) || scope.binderNames?.has(name) === true)
  )
    return undefined;
  for (const operand of expr.ops) {
    const found = symbolOccurrence(operand, name);
    if (found !== undefined) return found;
  }
  return undefined;
}

/**
 * Repair bottom-up numeric inference when a matrix-consuming operator gives
 * the enclosing context that was unavailable to Add/Multiply. Only symbols
 * first inferred while canonicalizing this argument are eligible. The repair
 * is deliberately structural and fail-closed: an ambiguous product such as
 * `a A` (both names fresh) is not guessed.
 *
 * Its write-free entry gates are factored into
 * {@link couldRepairFreshMatrixInference} so overload resolution can consult
 * them without mutating; keep the two in step.
 */
function repairFreshMatrixInference(
  ce: ComputeEngine,
  op: Expression,
  expected: Type,
  freshlyInferred?: ReadonlySet<BoxedValueDefinition>
): Expression | null {
  const targetType = freshInferenceTarget(expected);
  if (!freshlyInferred || !targetType) return null;

  const eligible = new Set<string>();
  // The names whose entry of a unit
  // environment the repair replaces (`unitRepairSite()`).
  const sites = new Map<string, UnitRepairSite>();
  for (const name of op.freeVariables) {
    const site = unitRepairSite(ce, op, name);
    if (site !== undefined) {
      if (site.eligible) {
        eligible.add(name);
        sites.set(name, site);
      }
      continue;
    }
    const def = ce.lookupDefinition(name);
    if (!def || !isValueDef(def) || !def.value.inferredType) continue;
    // A parameter of a function literal is not retyped on its definition: its
    // uses write in the environment of the unit, and the repair replaces
    // that entry above (decision D18 of
    // `docs/plans/2026-11-11-bound-once-spec.md`). A parameter with no entry
    // yet has no numeric guess to repair.
    if (isFunctionLiteralParameter(def.value)) continue;
    // "Fresh" = the definition's type was first inferred (unknown → concrete)
    // during this boxing operation — the forward log recorded by
    // `BoxedSymbol._infer()` — or is still unknown (never inferred; the
    // previous snapshot-based provenance excluded unknown-typed definitions
    // from "inferred before", making them always eligible). Keying on the
    // definition's identity rather than its name also means a symbol whose
    // fresh inner-scope definition has been popped, and which now resolves to
    // an outer definition inferred before this box, is correctly ineligible.
    //
    // A symbol whose current type is already a collection type is NOT
    // eligible, even when that type is fresh. The repair exists to correct a
    // NUMERIC guess that `Add` or `Multiply` made bottom-up, before the
    // enclosing matrix operator gave them the context. A collection type is
    // collection evidence, not such a guess: `Length(xs)` narrows an untyped
    // `xs` to `collection`, and a later `First(xs)` in the same boxing
    // (parameter `indexed_collection<any>`) must not then retype `xs` as
    // `matrix`, which made `First(xs)` a row (`vector`) and refused a later
    // `Filter(xs, x => x < p)`. Such an operand is left to the ordinary
    // admission and inference instead. The test uses the `<any>` shape top,
    // so that a collection of any element type, absence markers included,
    // is excluded.
    //
    // A symbol typed as text (`string`, `character`, or their union) is not
    // eligible either, for the same reason: a use at a text parameter
    // (`ToUpperCase(s)` types an untyped `s` as `character | string`) is
    // evidence that the symbol is text, and text is never a matrix. Without
    // this test, a later `Determinant(s)` in the same boxing retyped `s` as
    // `matrix`. The `character | string` union needs this explicit test
    // because `character` is not a collection.
    if (hasNonNumericShapeEvidence(def.value.type.type)) continue;
    if (freshlyInferred.has(def.value) || def.value.type.isUnknown)
      eligible.add(name);
  }
  if (eligible.size === 0) return null;

  const names = matrixInferencePlan(op, eligible);
  if (!names || names.size === 0) return null;

  // Per-name repair-local records for an EXACT failure-leg restore (phase 2a
  // of docs/TYPE-SYSTEM.md). Three families:
  // - `snapshots`: the coupled type/value slots, restored setter-bypassing
  //   via `_restoreTypeSlots` — the old restore wrote through the `type`
  //   setter, which allocates fresh `BoxedType`s (defeating identity-keyed
  //   caches) and, when the previous type was `unknown` (eligible above),
  //   WIPED the definition's assigned value.
  // - `histories`: the provenance array as it stood before the write — the
  //   write below records a provenance entry, and a failed repair must leave
  //   the history byte-identical (including a cap-displaced entry, which the
  //   slice preserves wholesale).
  // - `freshlyAdded`: definitions this repair itself added to
  //   `_freshlyInferred` (an `unknown` → `matrix` transition during a boxing
  //   pass), removed again on failure so a rolled-back repair leaves no
  //   phantom repair eligibility.
  // The narrowing sink is notified only on the SUCCESS path (below): sink
  // retraction would be needed otherwise: an entry recorded at write time for a repair the failure leg then undoes would report a
  // narrowing that never took effect — but a SUCCESSFUL repair permanently
  // narrows an (possibly enclosing) definition, and a contained parse's
  // `scope.narrowings()` must see that.
  // The repair must never execute in the trial of an overload arm (phase
  // 2c), which admits repairs by their write-free precondition
  // (`couldRepairFreshMatrixInference`) without running them; the winning
  // arm re-validates for real, outside the trial. The Epsil static checking
  // pass legitimately reaches this repair: it puts back the definitions of
  // enclosing scopes that it wrote (`DefinitionRestorePoint`).
  console.assert(
    !inTrial(ce),
    'repairFreshMatrixInference must not run in trial (repair-free) validation'
  );

  const snapshots = new Map<string, unknown>();
  const histories = new Map<string, TypeProvenanceEntry[] | undefined>();
  const beforeTypes = new Map<string, BoxedType>();
  const freshlyAdded: BoxedValueDefinition[] = [];
  // True while every repaired definition is a binding under a registered
  // scratch scope (`scratch-scopes.ts`). The inference events below are then
  // flagged `scratch`: no cache that outlives the computation owning that
  // scope can depend on the bindings, so the events leave the versions such
  // caches key on alone (see "Scratch events" in the documentation of
  // `axisMaskOf`). One binding outside a scratch scope keeps the full
  // advance.
  let allScratch = true;
  // For each environment that the
  // repair writes in, the length of its journal before the first write. The
  // failure leg undoes the writes after it: the entries that the repair
  // replaced, and the requirements that the discarded re-box wrote. A write
  // in an environment sends no engine-wide event (rule 9 of
  // `docs/plans/2026-11-09-binding-units-slice-1-spec.md`), so the events
  // below are sent only for a write on a definition.
  const marks = new Map<UnitEnvironment, number>();
  // The literal being boxed writes the entry of a parameter on its
  // definition when its boxing ends (`BoxedSymbol._inferOnParameter()`), so
  // it records the entry that the repair replaces too. For each record of
  // requirements that the repair changes, its content before the repair:
  // the failure leg puts it back, with the records of the discarded re-box.
  const parameterRecords = new Map<
    Map<BoxedValueDefinition, ParameterRequirement>,
    Map<BoxedValueDefinition, ParameterRequirement>
  >();
  let definitionWrites = false;
  for (const name of names) {
    const site = sites.get(name);
    if (site !== undefined) {
      const env = site.env!;
      ce._boxingState.noteUnitWrite(env);
      if (!marks.has(env)) marks.set(env, env.journalLength());
      const entry = ce.type(targetType);
      env.set(site.key, name, entry);
      const parameter = site.key as BoxedValueDefinition;
      const requirements =
        ce._boxingState.trialEnvironment() === undefined
          ? site.literal?.requirements
          : undefined;
      if (requirements !== undefined) {
        if (!parameterRecords.has(requirements))
          parameterRecords.set(requirements, new Map(requirements));
        requirements.set(parameter, {
          type: entry,
          cause: {
            operator: op.operator,
            ops: isFunction(op) ? op.ops : [],
            expr: op,
          },
          // The repair replaces a numeric guess.
          numeric: requirements.get(parameter)?.numeric,
        });
      }
      continue;
    }
    definitionWrites = true;
    const def = ce.lookupDefinition(name);
    if (!def || !isValueDef(def) || !def.value.inferredType) return null;
    if (!isScratchBinding(ce, def)) allScratch = false;
    snapshots.set(name, def.value._typeSlotSnapshot());
    histories.set(name, def.value._typeProvenance?.slice());
    beforeTypes.set(name, def.value.type);
    const wasUnknown = def.value.type.isUnknown;
    def.value._setType(() => ce.type(targetType));
    // Freeze the contextual assignment during re-canonicalization so the
    // numeric fast path cannot immediately narrow it back to `real`.
    def.value.inferredType = false;
    // The write is now channel-visible where it matters: provenance (the
    // matrix inference is evidence, with the operand as its cause) and the
    // fresh-inference set (matching `_noteInferenceWrite`'s condition).
    recordTypeProvenance(def.value, {
      type: def.value.type,
      kind: 'inferred',
      axis: 'type',
      cause: op,
    });
    if (
      wasUnknown &&
      ce._inferenceTxDepth > 0 &&
      !ce._freshlyInferred?.has(def.value)
    ) {
      const set = (ce._freshlyInferred ??= new Set());
      set.add(def.value);
      freshlyAdded.push(def.value);
    }
  }
  if (definitionWrites)
    ce._noteStateEvent({
      kind: 'inference',
      ...(allScratch ? { scratch: true } : {}),
    });

  const repaired = ce.box(op.json);
  if (repaired.type.matches(expected)) {
    const sink = ce._narrowingSink;
    for (const name of names) {
      if (sites.has(name)) continue;
      const def = ce.lookupDefinition(name);
      if (def && isValueDef(def)) {
        def.value.inferredType = true;
        // Report the COMMITTED net transition to a contained parse's
        // narrowing capture — only now, when the write is permanent.
        if (sink !== undefined)
          sink._recordNarrowing(
            name,
            def,
            beforeTypes.get(name)!,
            def.value.type
          );
      }
    }
    return repaired;
  }

  for (const name of names) {
    if (sites.has(name)) continue;
    const def = ce.lookupDefinition(name);
    if (def && isValueDef(def)) {
      def.value._restoreTypeSlots(snapshots.get(name));
      def.value._typeProvenance = histories.get(name);
    }
  }
  for (const [env, mark] of marks) env.undoJournal(mark);
  for (const [requirements, before] of parameterRecords) {
    requirements.clear();
    for (const [parameter, type] of before) requirements.set(parameter, type);
  }
  for (const fresh of freshlyAdded) ce._freshlyInferred?.delete(fresh);
  if (definitionWrites)
    ce._noteStateEvent({
      kind: 'inference',
      ...(allScratch ? { scratch: true } : {}),
    });
  return null;
}

function matrixInferencePlan(
  expr: Expression,
  eligible: ReadonlySet<string>
): Set<string> | null {
  if (isSymbol(expr))
    return eligible.has(expr.symbol) ? new Set([expr.symbol]) : null;

  if (!isFunction(expr)) return null;

  if (expr.operator === 'Negate')
    return matrixInferencePlan(expr.op1, eligible);

  if (expr.operator === 'Add' || expr.operator === 'Subtract') {
    // A sum is a matrix when at least one term is a matrix: `Add`
    // broadcasts a scalar term over the cells of a matrix term, and the
    // `Add` type handler types `matrix + scalar` as `matrix`. So a constant
    // numeric term (no free variables, such as the `0.5` of `P + 0.5`) is a
    // scalar that the sum accepts, the same way a literal factor is accepted
    // by the `Multiply` branch below. Before this, such a term made the whole
    // plan fail, so `Histogram(P + 0.5, …)` kept the `number` type that
    // bottom-up inference gave `P`, while `Histogram(2P, …)` was repaired.
    // A term with a free variable and no plan still makes the plan fail:
    // `sin(P)` because its symbol cannot be both a matrix and a scalar
    // operand, and a symbol that an earlier boxing already inferred `number`
    // (`Det(A + B)` after `A + 1`) because that earlier numeric use of `A`
    // is kept as the stronger evidence.
    const result = new Set<string>();
    for (const term of expr.ops) {
      const plan = matrixInferencePlan(term, eligible);
      if (!plan) {
        if (
          term.freeVariables.length === 0 &&
          isScalarTermOutsidePlan(term, eligible)
        )
          continue;
        return null;
      }
      for (const name of plan) result.add(name);
    }
    return result.size > 0 ? result : null;
  }

  // A quotient with a scalar denominator is a matrix when its numerator is:
  // `Divide` broadcasts over the cells of the numerator. The canonical form
  // of `(P - 0.5)/√(…)` keeps the `Divide`, so without this branch the plan
  // of such a quotient failed. A denominator that contains an eligible
  // symbol is not accepted: a matrix denominator is not a cell-wise
  // quotient. A denominator with other free variables (`√(v² + 1)` with a
  // declared real `v`) is accepted, as the `Multiply` branch accepts a
  // scalar factor that is not eligible.
  if (expr.operator === 'Divide' && expr.nops === 2) {
    if (!isScalarTermOutsidePlan(expr.op2, eligible)) return null;
    return matrixInferencePlan(expr.op1, eligible);
  }

  if (expr.operator === 'Multiply') {
    const candidates = expr.ops
      .map((factor) => matrixInferencePlan(factor, eligible))
      .filter((x): x is Set<string> => x !== null);
    // Numeric literals and already-declared scalar factors may scale the one
    // matrix factor. More than one candidate is underdetermined (`a A`).
    if (candidates.length !== 1) return null;
    return candidates[0];
  }

  if (expr.operator === 'Power' && expr.op2?.isInteger === true)
    return matrixInferencePlan(expr.op1, eligible);

  return null;
}

/**
 * True when `term` is a number-typed operand that contains none of the
 * `eligible` symbols. The matrix inference plan accepts such a term as a
 * scalar beside a matrix term of a sum, or as the denominator of a
 * quotient, because the result of either operation is then still a matrix.
 */
function isScalarTermOutsidePlan(
  term: Expression,
  eligible: ReadonlySet<string>
): boolean {
  if (!term.type.matches('number')) return false;
  for (const name of term.freeVariables) if (eligible.has(name)) return false;
  return true;
}

/** Recursively examine the symbols and operators and for any
 * that don't have a definition, suggest an alternative name.
 */
function spellcheckSymbols(expr: Expression): Record<string, string> {
  const { symbols, operators } = getKnownNames(expr.engine);
  const suggestions: Record<string, string> = {};

  // `bound` holds the parameters of the enclosing function literals. A
  // parameter is a known name in the body of its literal, although it is not
  // in the scope of the engine: `Filter(xs, y ↦ y > 0)` reported
  // `Unknown symbol "y". Did you mean "x"?`.
  const visit = (expr: Expression, bound: ReadonlySet<string>): void => {
    if (isSymbol(expr) && !expr.symbol.startsWith('_')) {
      if (bound.has(expr.symbol)) return;
      if (!(expr.symbol in suggestions) && !symbols.includes(expr.symbol)) {
        const match = fuzzyStringMatch(expr.symbol, symbols);
        if (match) suggestions[expr.symbol] = match;
      }
    } else if (isFunction(expr) && !expr.operator.startsWith('_')) {
      const operator = expr.operator;
      if (!(operator in suggestions) && !operators.includes(operator)) {
        const match = fuzzyStringMatch(operator, operators);
        if (match) suggestions[operator] = match;
      }
      let inner = bound;
      if (operator === 'Function') {
        const names = new Set(bound);
        for (const operand of expr.ops.slice(1)) {
          // A parameter with a default value, `["Optional", param, d]`,
          // binds the name of `param`.
          const param = optionalParameterTarget(operand);
          const p = isFunction(param, 'Typed') ? param.op1 : param;
          if (isSymbol(p)) names.add(p.symbol);
        }
        inner = names;
      }
      for (const op of expr.ops) visit(op, inner);
    }
  };

  visit(expr, new Set());
  return suggestions;
}

/** Collect, in a single walk of the scope chain, the names of all known
 * symbols (value defs) and operators (operator defs) visible in the current
 * scope. A name bound to both appears in both lists. */
function getKnownNames(ce: ComputeEngine): {
  symbols: string[];
  operators: string[];
} {
  const symbols: string[] = [];
  const operators: string[] = [];
  let currentScope: Scope | null = ce.context.lexicalScope;
  while (currentScope) {
    for (const [key, def] of currentScope.bindings) {
      if (isValueDef(def)) symbols.push(key);
      if (isOperatorDef(def)) operators.push(key);
    }
    currentScope = currentScope.parent;
  }

  return { symbols, operators };
}

export function spellCheckMessage(expr: Expression): string {
  const suggestions = spellcheckSymbols(expr);
  if (Object.keys(suggestions).length === 0) return '';

  if (Object.keys(suggestions).length === 1) {
    const [symbol, suggestion] = Object.entries(suggestions)[0];
    return `Unknown symbol "${symbol}". Did you mean "${suggestion}"?`;
  }

  const lines: string[] = [];
  for (const [symbol, suggestion] of Object.entries(suggestions)) {
    lines.push(`- "${symbol}" -> "${suggestion}"?`);
  }
  return `Unknown symbols found:\n${lines.join('\n')}`;
}
