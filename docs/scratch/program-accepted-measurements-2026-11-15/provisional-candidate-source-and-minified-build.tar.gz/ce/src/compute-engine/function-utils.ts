import { cacheOff } from '../common/cache-switches.js';
import { MathJsonSymbol } from '../math-json.js';
import {
  debugStatementHook,
  debugStatementResultHook,
  invokeDebugHook,
  isDebugHookFailure,
} from '../common/debug-hook.js';
import { isThenable, CancellationError, checkDeadline, budgetCauseOf, isTimeoutCancellation } from '../common/interruptible.js';
import { cmp } from './boxed-expression/compare.js';
import {
  bindingInContext,
  callableBindingInContext,
  unresolvedFreeHome,
  evaluateInOwnBindings,
  isParameterActivation,
  rebindToBindings,
  rewriteWithBinders,
  sameBindingDef,
  boundVariableNames,
  boundVariableNamesInOperand,
  shadowedKey,
  withCallableBinding,
} from './boxed-expression/binders.js';
import {
  binderBoundAt,
  declaredBinders,
  mapOwnIndexClause,
  ownIndexClauseAt,
  pointVariableNames,
  someOwnIndexClause,
} from './boxed-expression/binding-sites.js';
import { hasAsyncOnlyApplication } from './boxed-expression/async-only-descendants.js';
import type {
  BoxedDefinition,
  BoxedOperatorDefinition,
  BoxedValueDefinition,
  EvaluateOptions,
  Expression,
  ExpressionInput,
  FunctionInterface,
  IComputeEngine as ComputeEngine,
  Scope,
  ParameterRecord,
} from './global-types.js';
import type { EffectHandlers } from './types-effects.js';
import { runWithEvaluationEffects } from './effects-registry.js';
import {
  isStackOverflow,
  recursionLimitError,
} from './engine-runtime-state.js';
import {
  isSymbol,
  isFunction,
  isDictionary,
  isString,
  isNumber,
  isAbsentSymbol,
  isNaNPointValue,
  isExpression,
  sym,
  isFreeName,
  isFreeCallHead,
  freeBinding,
  readBinding,
} from './boxed-expression/type-guards.js';
import {
  adoptLazyView,
  canHoldLazyView,
  canonicalizedLazyViewsIn,
  carryLazyViewContexts,
  hasLazyViewRecord,
  isLazyCallbackView,
  lazyViewActivationOf,
  lazyViewRecordSerial,
  shareLazyViewRecord,
  wasCanonicalizedIn,
} from './boxed-expression/lazy-view-context.js';
import { markLocalBinding } from './boxed-expression/declared-local.js';
import {
  functionLiteralBoundNames,
  functionLiteralDeclaredSignature,
  functionLiteralParameterName,
  functionLiteralParameterNames,
  functionLiteralParameterType,
  ANONYMOUS_SLOT_NAMES,
  freeAnonymousSlots,
  isDestructuringParameter,
  isUnknownTypedParameter,
  isRestParameter,
  capturedSymbols,
  markFunctionLiteralParameter,
  isFunctionLiteralParameter,
  markFunctionLiteralCaptures,
  mentionsQuantifiedVariable,
  restParameterIndex,
  restParameterSymbol,
  resolveFunctionLiteralTypes,
  isOptionalParameter,
  optionalParameterDefault,
  optionalParameterTarget,
  requiredParameterCount,
} from './boxed-expression/function-literal.js';
import {
  collectTuplePattern,
  tuplePatternNames,
} from './boxed-expression/tuple-pattern.js';
import {
  callFrameBodyOf,
  chainContains,
  activationOnLinks,
  functionValueTemplateOf,
  registerCallFrame,
  registerFunctionValueScope,
  scopeActivationTemplate,
} from './boxed-expression/ambient-chain.js';
import { isErrorTypedOperand } from './boxed-expression/error-typed-operand.js';
import { pointArity } from './collection-utils.js';
import {
  GENERIC_DEFAULT_MESSAGE,
  NESTED_DEFAULT_MESSAGE,
  SYMBOL_DEFAULT_MESSAGE,
  boxParameterDefault,
  isConstantSymbolDefault,
  literalSymbolNames,
  markSignatureMarkerOperand,
  literalParameterDefault,
  typeHasParameterDefault,
} from './boxed-expression/parameter-defaults.js';
import {
  errorValue,
  isInvalidNonCollection,
  withErrorFrames,
} from './boxed-expression/error-value.js';
import { canonicalFailureOf } from './boxed-expression/canonical-failure.js';
import { withSeparateCanonicalReads } from './boxed-expression/transient-canonical.js';
import {
  listRecursionPlan,
  evaluateListRecursion,
} from './boxed-expression/recursive-list-builder.js';
import {
  beginProvisionalCapture,
  endProvisionalCapture,
  provisionalLiteral,
  registerProvisionalDependents,
  scopeOfBinding,
  setProvisionalLiteral,
  takeProvisionalDependents,
  type ProvisionalCapture,
  type ProvisionalDependent,
} from './boxed-expression/provisional-application.js';
import { isShadowOf } from './library-shadowing.js';
import { isScratchBinding } from './scratch-scopes.js';
import { isTransitivelyPure } from './boxed-expression/transitive-purity.js';
import { isExactRealLiteral } from './boxed-expression/constraint-subject.js';
import {
  exactArgumentSourceOf,
  setExactArgumentSource,
} from './boxed-expression/exact-argument-source.js';
import {
  effectsContractStateOf,
  latestDeclaredEffectsSite,
  recordEffectsTransition,
} from './boxed-expression/effects-provenance.js';
import {
  EffectContractError,
  effectContractErrorValue,
  functionLiteralParameterSignature,
  inferFunctionLiteralEffects,
  isEffectContractError,
  presentedValueType,
} from './boxed-expression/effects-inference.js';
import { isTestedAtRead } from './boxed-expression/store-admission.js';
import { effectsOf } from './boxed-expression/effects-of.js';
import { readsOtherBindings } from './boxed-expression/names-read.js';
import { isOperatorDef } from './boxed-expression/definition-guards.js';
import { releaseKeptEagerSourceValues } from './boxed-expression/eager-source-values.js';
import {
  beginAsyncStatement,
  beginTopLevelEvaluation,
  copyContextStack,
} from './boxed-expression/evaluation-epoch.js';
import {
  isInferredTypedParameter,
  markInferredTypeOperand,
} from './boxed-expression/inferred-annotations.js';
import {
  memoDepsStillValid,
  snapshotMemoDeps,
  type MemoDeps,
} from './boxed-expression/collection-element-memo.js';
import { beginStoreGuard } from './boxed-expression/store-guard.js';
import { notePendingCallScope } from './pending-call-scopes.js';
import {
  forgetBodyScopeApplied,
  noteBodyScopeApplied,
  noteCallFrame,
  staticBindingIn,
  staticParentOf,
  staticViewDiverges,
} from './static-typing-view.js';
import {
  isEffectSubset,
  isPureComputedEffects,
} from '../common/type/effects.js';
import type {
  FunctionSignature,
  NamedElement,
  ParameterDefault,
  Type,
} from '../common/type/types.js';
import { parseType } from '../common/type/parse.js';
import { isPolymorphicType } from '../common/type/instantiate.js';
import {
  DependentRebuildError,
  GENERIC_ANNOTATION_COVERAGE_MESSAGE,
  GENERIC_PARTIAL_APPLICATION_MESSAGE,
  INVALID_SIGNATURE_MARKER_MESSAGE,
  TYPE_VARIABLE_INTRODUCTION_MESSAGE,
  isTypeCompatibilityError,
  typeCompatibilityErrorValue,
  withoutFailedElementCheck,
} from './boxed-expression/type-compatibility-error.js';
import { substituteDeclaredBounds } from './boxed-expression/generic-instantiation.js';
import { isSubtype, widen } from '../common/type/subtype.js';
import { typeToString } from '../common/type/serialize.js';
import {
  DECLARED_MISSING_MESSAGE,
  declaredTypeNamesMissing,
  hasKindArm,
  isGroupedTypeText,
  returnTypeText,
  signatureArms,
  signatureEffects,
  stripNumericRanges,
} from '../common/type/utils.js';
import { kindTypeNames } from './boxed-expression/value-kinds.js';
import { _BoxedValueDefinition } from './boxed-expression/boxed-value-definition.js';
import { recordTypeProvenance } from './boxed-expression/type-provenance.js';
import { sharedEvaluationStarts } from './boxed-expression/shared-evaluation-memo.js';
import { enterFunctionBody, exitFunctionBody } from './statement-position.js';
import { beforeDefinitionWrite } from './boxed-expression/definition-restore-point.js';

// Lazy reference to `validateArguments` (from `boxed-expression/validate.ts`).
// A static import would create a cycle: `validate.ts → utils.ts →
// boxed-operator-definition.ts → function-utils.ts`. Injected once by
// `boxed-expression/init-lazy-refs.ts` at engine load. The type is written
// inline (not `import type`) so madge does not detect a type-only cycle.
type ValidateArgumentsFn = (
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  signature: Type,
  lazy?: boolean,
  threadable?: boolean,
  freshlyInferred?: ReadonlySet<BoxedValueDefinition>
) => ReadonlyArray<Expression> | null;

let _validateArguments: ValidateArgumentsFn | undefined;
export function _setValidateArguments(fn: ValidateArgumentsFn): void {
  _validateArguments = fn;
}

// Lazy reference to `declaredArgumentUndecided` (from
// `boxed-expression/boxed-function.ts`, which imports this module). Injected
// once by `boxed-expression/init-lazy-refs.ts` at engine load.
type ArgumentUndecidedFn = (
  declared: Type,
  ops: ReadonlyArray<Expression>
) => boolean;

let _declaredArgumentUndecided: ArgumentUndecidedFn | undefined;
export function _setDeclaredArgumentUndecided(fn: ArgumentUndecidedFn): void {
  _declaredArgumentUndecided = fn;
}

/**
 * The inert `Apply` nodes that a function literal answers when the type of an
 * argument does not decide an annotation of the author, so the application
 * waits for a later evaluation to check the value. A route that calls the
 * literal by name replaces such a node with the call by that name
 * (`apply()`, `applyFunctionLiteral`, `boxed-expression/boxed-function.ts`).
 */
const UNDECIDED_APPLICATIONS = new WeakSet<Expression>();

/** True when `result` is the inert application that `literal` itself answers
 * for an argument whose type does not decide an annotation. An inner literal
 * can answer such a node as the value of the body of `literal`: that is a
 * value of `literal`, and the call of `literal` does not wait. */
export function isUndecidedLiteralApplication(
  result: Expression | undefined,
  literal: Expression
): boolean {
  return (
    result !== undefined &&
    UNDECIDED_APPLICATIONS.has(result) &&
    isFunction(result, 'Apply') &&
    result.op1 === literal
  );
}

/***
 * ### THEORY OF OPERATIONS
 *
 * The body of a `["Function"]` expression is a `["Block"]` expression,
 * which is scoped. The function arguments are declared in that scope as well.
 *
 * Some expressions with anonymous parameters (e.g. `["Add", "_", 1]`)
 * are rewritten to a `["Function"]` expression with anonymous parameters
 * (e.g. `["Function", ["Block", ["Add", "_", 1]], "_"]`).
 *
 *
 * #### DURING CANONICALIZATION (in canonicalFunctionLiteralArguments())
 *
 * 1/ If not a `["Function"]` expression, the expression is rewritten
 *    to a `["Function"]` expression with anonymous parameters
 * 2/ A `Block` scope is created
 * 3/ The function parameters are declared in the Block's scope
 * 4/ The function body is canonicalized in the context of the scope.
 *    The Block's localScope captures the defining scope as its parent.
 *
 *
 * #### DURING EVALUATION (executing the result of makeLambda())
 *
 * 1/ The arguments are evaluated in the **calling** scope
 * 2/ A call frame is created per call, with parent = the **defining**
 *    scope (`definingScopeOf()`: the activation that the function value
 *    keeps, or the scope the literal was boxed in), giving true lexical
 *    scoping
 * 3/ The frame is an activation of the body scope: it holds the static
 *    definition of each parameter and of each local of the body, with the
 *    values of this call (`holdBodyLocals()`)
 * 4/ The body is evaluated in the context of the frame. A nested scoped
 *    expression (Sum, Product, a Block) reads a parameter on the
 *    activation links from the evaluation in progress; the scopes of the
 *    body are not changed
 * 5/ The occurrences of the parameters that the result still names are
 *    replaced with their values (`bindingKeyedSubs()`). A function value
 *    of the result keeps the activation it was made in
 *    (`captureNestedLocals()`), and is not rebuilt
 * 6/ The frame is popped
 * 7/ The result is returned
 *
 */

/**
 * From an expression, return a predicate function, which can be used to filter.
 */
export function predicate(
  _expr: Expression
): (...args: Expression[]) => boolean {
  // Expression-backed predicates are not implemented; the conservative
  // fallback rejects every candidate.
  return () => false;
}

/**
 * From an expression, create an ordering function, which can be used to sort.
 */
export function order(
  _expr: Expression
): (a: Expression, b: Expression) => -1 | 0 | 1 {
  // Expression-backed comparators are not implemented. Use the canonical
  // expression order as the fallback.
  return (a: Expression, b: Expression) => {
    const c = cmp(a, b);
    if (c === '=') return 0;
    if (c === '<' || c === '<=') return -1;
    return 1;
  };
}

/**
 * Given an expression, rewrite it to a symbol or canonical Function form.
 *
 * - symbol (no change):
 *      "Sin"
 *     -> "Sin"
 *
 * - built-in function:
 *      ["BuiltinFunction", "Sin"]
 *     -> "Sin"
 *
 * - parenthesized expression:
 *      ["Delimiter", ["Add", "_", 1], "'()'"]
 *     -> ["Function", ["Block", ["Add", "_", 1]], "_"]
 *
 * - explicit parameters (adding a block to serve as a scope for the arguments):
 *      ["Function", ["Add", "x", 1], "x"]
 *      -> ["Function", ["Block", ["Add", "x", 1]], "x"]
 *
 *
 * - single anonymous parameters:
 *      ["Add", "_", 1]
 *      -> ["Function", ["Block", ["Add", "_", 1]], "_"]
 *
 * - multiple anonymous parameters:
 *      ["Add", "_1", "_2"]
 *      -> ["Function", ["Block", ["Add", "_1", "_2"]], "_1", "_2"]
 *
 *
 */
/**
 * The written (non-canonical) form of the canonical function literal `x`,
 * when `x` was canonicalized from a `["Function", body, ...params]` literal
 * whose parameters are all unannotated, and `undefined` otherwise.
 *
 * The canonical body of such a literal reads each parameter as a possible
 * number, so it may have folded `x/x` to `1`, and it types its result from
 * that reading. A binder over elements that are not numbers must not apply
 * that body: the parameter takes the element type, and the body is
 * canonicalized again from this written form with that type, as an inline
 * literal is. For the values of a VALUE KIND
 * (`Map(f, [ResidueClass(2, 4), ResidueClass(3, 4)])`, with `f` boxed before
 * the call) the folded body gave a wrong value
 * (`docs/plans/2026-10-26-value-kinds.md`, section 4.2, decision B). For rows
 * (`Scan([[1, 2], [3, 4]], f, 0)` with `f = (a, t) ↦ a + t`) the body typed
 * the running sum as a number, so the scan was typed as a list of numbers.
 *
 * `scope` is the lexical scope in which `x` was canonicalized. The written
 * form must be canonicalized again in that scope, not in the scope of the
 * caller: a free name of the body (`k` in `x ↦ k·x`) is then bound to the
 * definition that `x` reads, also when the scope of the caller declares
 * another `k`.
 */
export function writtenUntypedFunctionLiteral(
  x: Expression
): { literal: Expression; scope: Scope } | undefined {
  // The map keeps only the written operands. The non-canonical `Function`
  // expression is built here, when a caller asks for it, because few
  // literals boxed before a call are applied to elements that are not
  // numbers.
  const written = WRITTEN_UNTYPED_LITERALS.get(x);
  if (written === undefined) return undefined;
  return {
    literal: x.engine._fn('Function', [...written.ops], { canonical: false }),
    scope: written.scope,
  };
}

const WRITTEN_UNTYPED_LITERALS = new WeakMap<
  Expression,
  { ops: ReadonlyArray<Expression>; scope: Scope }
>();

export function canonicalFunctionLiteral(
  expr: Expression | undefined,
  options?: {
    params?: ReadonlyArray<Expression>;
    /** Types INFERRED for bare parameters, by name, bound as inferred types
     * when the body is canonicalized (see `canonicalFunctionLiteralArguments`).
     * Read only for a raw `["Function", …]` literal. */
    inferredParamTypes?: ReadonlyMap<string, Type>;
    /** True when a raw `["Function", …]` literal stands for a bare body
     * with a bound variable, as the LaTeX parser writes the body of
     * `\lim_{x \to 0}`. Its parameters are then bound variables
     * (`canonicalFunctionLiteralArguments()`). A body that is not a literal
     * is read so when the caller names its variables (`params`, the
     * integrand of `Integrate`). Without `params`, the body is canonicalized
     * in the scope of the caller before its variables are known, so the
     * reading of `x(2)` is already made there. */
    liftedBody?: boolean;
  }
): Expression | undefined {
  if (!expr) return undefined;

  //
  // 0/ A string literal is never a function. Without this guard a string
  //    falls through to the shorthand path below and becomes a constant
  //    nullary function `() ↦ "s"`, so e.g. `Map("nf", [1,2,3])` would map to
  //    `["nf","nf","nf"]` instead of being rejected.
  //
  if (isString(expr)) return undefined;

  //
  // 1/ Canonical function literal
  //
  if (expr.operator === 'Function' && expr.isCanonical) return expr;

  //
  // 2/ If a symbol, e.g. "Sin", return unchanged
  //    When evaluating, the type of the symbol need to be checked to
  //    make sure it's a function
  //
  //    Exception: the BARE wildcard `_` is the identity-function shorthand
  //    (`Map(_, xs)` ≡ `Map(x ↦ x, xs)`). It falls through to the shorthand
  //    path below, which turns it into `(_1) ↦ _1`. Only the bare `_`
  //    qualifies: `_1`/`_2`/… are positional parameters of an ENCLOSING
  //    shorthand, and a named wildcard is a pattern variable — neither is an
  //    identity function.
  //
  //    A raw symbol with no definition is a free name: its canonical form
  //    records the scope it is boxed in, from which a callback reads its
  //    definition when it is applied (`callableBindingInContext()`). Boxing
  //    declares no name, so the canonical form writes nothing.
  if (isSymbol(expr) && !isSymbol(expr, '_')) {
    const symbol: Expression = expr;
    return !symbol.isCanonical &&
      symbol.engine._resolveOnlyDepth === 0 &&
      symbol.engine.lookupDefinition(sym(symbol)!) === undefined
      ? symbol.canonical
      : symbol;
  }

  //
  // 3/ `BuiltinFunction`, e.g. ["BuiltinFunction", "Sin"]
  //    This operator is just a "tag" indicating the nature of the
  //    symbol.
  //
  if (isFunction(expr, 'BuiltinFunction')) return expr.op1;

  //
  // 3b/ A qualified name, e.g. ["Module", "Floor"]: its canonical form is
  //    the symbol bound to the library definition (or an error when the
  //    name is not in the library), which is a function operand as the
  //    bare symbol is in step 2.
  //
  if (isFunction(expr, 'Module')) return expr.canonical;

  //
  // 4/ Parenthesized expression, e.g. ["Delimiter", ["Sin", "_"], "'()'"]
  //
  if (isFunction(expr, 'Delimiter')) {
    // If the expression is a sequence, we need to extract the first
    // element
    const exprOp1 = expr.op1;
    if (isFunction(exprOp1, 'Sequence')) {
      if (exprOp1.nops === 1) {
        expr = exprOp1;
      } else {
        return canonicalFunctionLiteral(
          expr.engine._fn('Block', exprOp1.ops, { canonical: false }),
          options
        );
      }
    }

    return canonicalFunctionLiteral(
      isFunction(expr) ? expr.op1 : undefined,
      options
    );
  }

  //
  // 5/ Function expression
  //
  // If this is a function literal, split the body and the parameters
  // For example, `["Function", ["Add", "x", 1], "x"]`
  if (isFunction(expr, 'Function'))
    return canonicalFunctionLiteralOperands(expr.engine, expr.ops, {
      inferredParamTypes: options?.inferredParamTypes,
      liftedBody: options?.liftedBody,
    });

  //
  // 5.5/ An expression that DENOTES a function without being a literal — a
  //      qualified protocol member `Comparable.compare` (which is
  //      `Field(Comparable, "compare")`), `InverseFunction(f)`,
  //      `Derivative(f, n)` — is a function VALUE, exactly like the symbol
  //      case 2: return it unchanged and let application reach the value
  //      through evaluation (`makeLambda` routes it through `Apply`).
  //      Without this gate the shorthand path below reads it as a lambda
  //      BODY and turns its free symbols into parameters, so
  //      `Map(Comparable.compare, xs)` bound each ELEMENT to `Comparable`
  //      and mapped `Field(element, "compare")` — an absence marker per
  //      element. Same predicate as `apply()`'s symbolic-application gate,
  //      so the two tiers agree — plus its syntactic sibling for a RAW
  //      operand (a lazy operator's held callback), whose type still reads
  //      `unknown` and cannot answer the type-based predicate.
  //
  if (
    denotesFunction(expr) ||
    isQualifiedProtocolMember(expr) ||
    isRawFunctionValuedApplication(expr)
  )
    return expr;

  //
  // 6/ Shorthand function literal,
  // e.g. `["Add", "_", 1]` or `["Add", "x", 1]`
  //
  console.assert(expr.operator !== 'Function');

  const ce = expr.engine;
  let [body, params] = anonymousParameters(expr);

  if (params.length === 0) {
    // There are no wildcards

    // The caller knows the intended parameter list (`Integrate` passes its
    // integration variables): build the literal from the RAW body with those
    // parameters, so body occurrences bind to them through the normal §6.1
    // pre-declare mechanism in `canonicalFunctionLiteralArguments`. Inferring
    // parameters from the body's unknowns and swapping the parameter list
    // afterwards is NOT equivalent: the inferred parameters are declared in
    // the body scope and the body's occurrences bound to them, so the swap
    // leaves those occurrences bound to discarded parameters (Tycho item
    // 178(a): a parsed `∫_{-x}^{x} cos(x) dn` compared `isSame` false
    // against `ce.box()` of its own `.json`, because the body's `x` stayed
    // bound to a discarded inferred parameter while the bounds' `x` bound
    // the engine's). Wildcard parameters win over caller-supplied ones: a
    // body using `_` names its own parameters.
    if (options?.params !== undefined && options.params.length > 0)
      return canonicalFunctionLiteralArguments(ce, [body, ...options.params], {
        liftedBody: true,
      });

    // Check if we have some unknowns
    // We'll need the canonical form of the expression, so we'll create a block if necessary
    const explicitBlock = body.operator === 'Block';
    const written = body;
    if (!explicitBlock) body = ce.function('Block', [body]);
    else body = body.canonical;
    // A bare expression of UNKNOWN type is a callee the engine cannot read
    // as a lambda body: it is returned as a function VALUE, like the
    // expressions of step 5.5 (`isHeldCallee`). The test runs on the
    // canonical expression, inside the block built for it: the raw operand
    // of a lazy operator reads `unknown` whatever it is, so step 5.5 could
    // not answer for it either, and an expression that DENOTES a function
    // once canonical (`g(f)` for a two-parameter `g`, a partial application
    // typed as a function) is a function value here as well. The callee is
    // returned CANONICAL, bound in the caller's scope — not the raw operand,
    // whose type still reads `unknown` to the consumer of the callback
    // (`Map(g(0), xs)` for `g := (a, b) ↦ "s"` typed its result from the
    // source, as a list of integers), and not the statement of the block,
    // whose symbols are bound in the block's own scope. A `Block` the author
    // wrote is a literal body and is never a callee.
    if (
      !explicitBlock &&
      isFunction(body) &&
      body.nops === 1 &&
      (isHeldCallee(body.op1) || denotesFunction(body.op1))
    )
      return written.canonical;
    // A slot name (`_`, `_1`…`_9`) is never a parameter here: the body has
    // no free slot (`anonymousParameters` found none), so each slot it still
    // mentions belongs to a nested literal or to the stage of a nested
    // `Pipe`, as in `10 + Pipe(ys, _ * 2)`.
    const unknowns = body.unknowns.filter((x) => !ANONYMOUS_SLOT_NAMES.has(x));
    if (unknowns.length > 0) {
      params = unknowns.map((x) => ce.symbol(x, { canonical: false }));
      // Note: we assume the order of parameters is the order in
      // which they appear in the expression.
    }
  }

  return canonicalFunctionLiteralArguments(ce, [body, ...params], {
    liftedBody: true,
  });
}

/**
 * Rebuild an INLINE function-literal operand with its unannotated parameters
 * wrapped in `["Typed", param, type]`, from the operand's RAW structure.
 *
 * This is the shared rewrite of the per-application element-type inference
 * (`docs/TYPE-SYSTEM.md`): a call site
 * that knows what a callback's parameter will be bound to annotates the
 * literal it passes, so the literal behaves EXACTLY like the hand-annotated
 * spelling — the body scope declares the parameter with that type, every
 * type-reading gate sees it, and a violated annotation is a loud error
 * (ruling 2, "annotation-as-contract").
 *
 * Returns the rewritten RAW literal, or `undefined` when nothing is rewritten.
 * The result is NEVER canonicalized here: the caller substitutes it into the
 * operand array and the normal canonicalization
 * (`canonicalFunctionLiteralArguments` and its §6.1 pre-declare mechanism)
 * derives the body from raw structure, which is what preserves capture. A
 * scope-graft of an already-bound body is the closure-capture bug factory.
 *
 * Declines, all v1 scope exclusions:
 * - a SYMBOL operand (`Filter(xs, f)`) — a named literal may be SHARED, and
 *   one application site must not retype it for every other. Deliberately
 *   discriminated on the RAW operand: `canonicalFunctionLiteral` LIFTS a
 *   symbol into a literal, so the canonical operand cannot tell the two
 *   spellings apart;
 * - a string, and any operand that is not `Function`-headed (the shorthand
 *   `_ > 5` lifts to a literal only later);
 * - an operand that is already CANONICAL — its raw structure is gone;
 * - a literal with no explicit parameter list, and any parameter that is
 *   already annotated (an author's annotation is never overwritten). The
 *   exception is an annotation `unknown`, or a transparent alias of it: it
 *   is read as a bare parameter (`isUnknownTypedParameter()`), so the slot
 *   type replaces it.
 */
export function annotateFunctionLiteralParams(
  ce: ComputeEngine,
  op: ExpressionInput,
  paramTypes: ReadonlyArray<Type | undefined>
): Expression | undefined {
  const raw = ce.expr(op, { form: 'raw' });
  if (raw.isCanonical) return undefined;
  if (!isFunction(raw, 'Function')) return undefined;

  const ops = raw.ops;
  // `["Function", body]` has no explicit parameter list: its parameters, if
  // any, are the anonymous wildcards the body mentions, which the shorthand
  // path derives later.
  if (ops.length < 2) return undefined;

  let rewritten = false;
  const params = ops.slice(1).map((operand, i) => {
    const t = paramTypes[i];
    // An inferred type can hold the marker `missing` (the element type
    // `tuple<string, missing>` of `{"a" -> Missing}`), which an annotation
    // may not name (`declaredTypeNamesMissing()`): the parameter stays bare,
    // and the body types it from its uses.
    if (t === undefined || declaredTypeNamesMissing(t)) return operand;
    // A parameter with a default value is annotated inside its `Optional`
    // wrapper, and keeps its default operand.
    const optional = isFunction(operand, 'Optional') ? operand : undefined;
    const written = optional?.op1 ?? operand;
    // A parameter annotated `unknown` is a bare parameter, and takes the
    // type of the slot as a bare one does.
    const param = isUnknownTypedParameter(written) ? written.op1 : written;
    // Not a bare symbol: an already-annotated parameter, or an error.
    if (!isSymbol(param)) return operand;
    rewritten = true;
    // The same normalized spelling `normalizeTypedParameter` produces (a
    // string type operand), so the rebuilt literal behaves exactly like the
    // hand-written one; the mark is what keeps the two apart when the
    // literal is printed.
    const typeOperand = ce.string(typeToString(t));
    markInferredTypeOperand(typeOperand);
    const typed = ce._fn('Typed', [param, typeOperand], { canonical: false });
    return optional === undefined
      ? typed
      : ce._fn('Optional', [typed, ...optional.ops.slice(1)], {
          canonical: false,
        });
  });
  if (!rewritten) return undefined;

  return ce._fn('Function', [ops[0], ...params], { canonical: false });
}

/**
 * The function literal `literal` with each untyped parameter that the
 * declared function type `declared` types with a value kind annotated with
 * that type, as a `Typed` parameter is (`annotateFunctionLiteralParams()`).
 * `literal` is the MathJSON or the boxed value of a declaration
 * (`ce.declare('g', { signature, evaluate: literal })`) or of an assignment
 * to a symbol declared with a function type. A canonical literal is read
 * from its written form (`writtenUntypedFunctionLiteral()`).
 *
 * The body of an untyped parameter is canonicalized with the parameter
 * `unknown`, which folds `x/x` to `1` before a call can pass a kind value.
 * Typed by the declaration (`(real | umeasurement) -> …`,
 * `(residue) -> residue`), the parameter holds a possible kind value, and
 * the body keeps `x/x` (`docs/plans/2026-10-26-value-kinds.md`, section
 * 4.2, decision B).
 *
 * Only the parameters whose declared type has a kind arm are annotated: the
 * other parameters keep the reading of an untyped parameter. The annotation
 * is marked as inferred, so the literal prints as written. `undefined` when
 * no parameter is annotated: `declared` is not a signature or an
 * intersection of signatures, or no
 * parameter type has a kind arm, or the literal has no parameter list or
 * annotates its parameters itself.
 */
export function kindTypedFunctionLiteral(
  ce: ComputeEngine,
  literal: unknown,
  declared: Type
): Expression | undefined {
  let input: ExpressionInput;
  if (Array.isArray(literal) && literal[0] === 'Function')
    input = literal as unknown as ExpressionInput;
  else if (isExpression(literal) && isFunction(literal, 'Function')) {
    const x = literal as Expression;
    const written = x.isCanonical
      ? writtenUntypedFunctionLiteral(x)?.literal
      : x;
    if (written === undefined) return undefined;
    input = written;
  } else return undefined;
  const arms = signatureArms(declared);
  if (arms === undefined) return undefined;
  // An overloaded signature (`((residue) -> residue) & ((integer) ->
  // integer)`) has one body for every arm, so a parameter is typed with the
  // union of its types in the arms that have it (`integer | residue`): the
  // body must keep `x/x` for the kind arm and still accept the others.
  const arity = Math.max(...arms.map((arm) => arm.args?.length ?? 0));
  if (arity === 0) return undefined;
  const kinds = kindTypeNames(ce);
  const types: (Type | undefined)[] = [];
  for (let i = 0; i < arity; i++) {
    const atI = arms.flatMap((arm) =>
      arm.args?.[i] === undefined ? [] : [arm.args[i].type]
    );
    types.push(
      atI.some((t) => hasKindArm(t, kinds)) ? widen(...atI) : undefined
    );
  }
  if (types.every((t) => t === undefined)) return undefined;
  return annotateFunctionLiteralParams(ce, input, types);
}

/**
 * Canonicalize the operands of a `["Function", …]` literal — the body followed
 * by its parameter list.
 *
 * This is `canonicalFunctionLiteralArguments` plus the anonymous-parameter
 * rule, and it is what every route that canonicalizes a *user-written*
 * `Function` literal must use (the `Function` operator's own `canonical`
 * handler, and `canonicalFunctionLiteral` for a function-slot operand).
 * Callers that synthesize a closure from a body and a known binder list (a
 * `Match` arm, `D`) deliberately use `canonicalFunctionLiteralArguments`
 * directly: their body's `_` is not a parameter.
 *
 * The rule: in `["Function", body]` — no explicit parameter list — anonymous
 * parameters used by the body (`_`, `_1`, …) ARE the parameter list, exactly
 * as in the shorthand spelling, so `["Function", ["Add", "_", 1]]` and
 * `["Add", "_", 1]` denote the same lambda. Without it the literal becomes a
 * NULLARY function that never binds its argument (`() ↦ _ + 1`), and
 * `Filter(xs, ["Function", ["Less", "_", 10]])` throws instead of filtering.
 *
 * This form is also the engine's OWN serialization: `toMathJson()` emits a
 * wildcard-parameter lambda by DROPPING the parameter list (see the `Function`
 * case of `serializePrettyJsonFunction`), so `["Function", ["Greater", "_1", 5]]`
 * has to round-trip back to the unary lambda it came from.
 *
 * A body with no wildcard keeps the literal nullary — `["Function", 42]` and
 * `["Function", ["Add", "x", 1]]` are thunks, not unary functions.
 *
 * Regressed in 0e8c11b9, which replaced `canonicalFunctionExpression` (it
 * derived the wildcard parameters from the body) with
 * `canonicalFunctionLiteral`, whose `Function` branch forwarded the operands
 * unchanged.
 */
export function canonicalFunctionLiteralOperands(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  options?: {
    inferredParamTypes?: ReadonlyMap<string, Type>;
    /** See `canonicalFunctionLiteralArguments()`. */
    liftedBody?: boolean;
  }
): Expression | undefined {
  // A parameter annotated `unknown` is a bare parameter: remove the
  // annotation first, so that the written form recorded below is the one of
  // a literal with no annotation (`writtenUntypedFunctionLiteral()`).
  if (ops.slice(1).some((x) => isUnknownTypedParameter(x)))
    ops = ops.map((x, i) => (i > 0 && isUnknownTypedParameter(x) ? x.op1 : x));
  if (ops.length === 1) {
    const [body, params] = anonymousParameters(ops[0]);
    if (params.length > 0)
      return canonicalFunctionLiteralArguments(ce, [body, ...params], options);
  }
  const result = canonicalFunctionLiteralArguments(ce, ops, options);
  // A literal with explicit parameters, none of them annotated, keeps its
  // written form: see `writtenUntypedFunctionLiteral()`.
  if (
    result !== undefined &&
    ops.length > 1 &&
    !ops.every((x) => x.isCanonical) &&
    ops.slice(1).every((x) => isSymbol(x))
  )
    WRITTEN_UNTYPED_LITERALS.set(result, {
      ops,
      scope: ce.context.lexicalScope,
    });
  return result;
}

/**
 * The anonymous ("wildcard") parameters `_`, `_1`, … `_9` that `expr` uses, in
 * index order, together with the body in which the bare `_` has been
 * normalized to `_1`. The parameter list is empty when the expression uses no
 * wildcard — the caller then decides what the parameters are (the shorthand
 * path falls back to the body's unknowns; the `["Function", body]` path keeps
 * the literal nullary).
 */
export function anonymousParameters(
  expr: Expression
): [body: Expression, params: Expression[]] {
  // Replace '_' with '_1'. The substitution is NOT canonicalized: a
  // canonical substitute is canonicalized in the CALLER's lexical scope,
  // which auto-declares `_1` there with the type the body infers for it.
  // The stray declaration outlived the lift: after `xs |> _^2` the global
  // scope held `_1: number`, and the next lift of `Take(_, 2)` bound its
  // parameter to that declaration, put an `incompatible-type` error in the
  // body, and threw in `makeLambda`. The body is canonicalized by
  // `canonicalFunctionLiteralArguments`, inside the literal's own scope,
  // where the parameters are declared.
  //
  // Only the FREE slots count (`freeAnonymousSlots`): a slot inside a nested
  // shorthand literal, or declared by a nested literal's parameter list, is
  // that literal's own parameter. Before this, a whole-tree scan gave
  // `["Function", ["Add", "_1", [["Function", ["Multiply", "_1", "_2"]], 2, 3]]]`
  // the two parameters `_1`, `_2` instead of one (GitHub issue #381).
  //
  // The rename follows the same rule: it does not rename a `_` that a
  // nested literal binds, because a nested literal may declare `_` as an
  // explicit parameter next to `_1`, and renaming its `_` would give it two
  // parameters named `_1`.
  const slots = freeAnonymousSlots(expr);
  // A nested literal that declares `_1` but not `_` can use the outer `_`:
  // in `["Function", ["Apply", ["Function", ["Add", "_1", "_"], "_1"], 2]]`,
  // the inner `_` is the outer parameter. Renaming it to `_1` would make it
  // the inner parameter instead (the literal applied to 5 gave 4, not 7). In
  // that case the outer parameter keeps the name `_`, which is a valid
  // parameter name, in the first position. The other slots (`_2`, …) follow
  // it in index order, as they do after a rename.
  const captured = slots.has('_') && !slots.has('_1') && renameIsCaptured(expr);
  const body = slots.has('_') && !captured ? renameBareSlot(expr) : expr;
  const params: Expression[] = [];
  if (captured) params.push(expr.engine.symbol('_', { canonical: false }));
  else if (slots.has('_')) slots.add('_1');

  for (let i = 1; i < 10; i++)
    if (slots.has(`_${i}`))
      params.push(body.engine.symbol(`_${i}`, { canonical: false }));

  return [body, params];
}

/** True if `renameBareSlot(expr)` would rename a `_` that is inside a
 * nested literal which declares `_1` (and not `_`): the renamed symbol would
 * then refer to the nested literal's parameter, not to the enclosing one.
 * The walk enters the same nodes as `renameBareSlot`. */
function renameIsCaptured(expr: Expression, insideBinderOf1 = false): boolean {
  if (isSymbol(expr, '_')) return insideBinderOf1;
  if (!isFunction(expr)) return false;
  if ((expr as { _numericStore?: unknown })._numericStore !== undefined)
    return false;
  if (expr.operator === 'Function') {
    if (expr.nops < 2) return false;
    const bound = functionLiteralBoundNames(expr.ops.slice(1));
    if (bound.includes('_')) return false;
    return renameIsCaptured(
      expr.ops[0],
      insideBinderOf1 || bound.includes('_1')
    );
  }
  return expr.ops.some((x) => renameIsCaptured(x, insideBinderOf1));
}

/** A raw copy of `expr` in which the bare slot `_` is renamed `_1` where it
 * is free. A nested `Function` literal with no parameter list takes its own
 * slots, so it is not entered. A nested literal with a parameter list is
 * entered only when it does not declare `_`: its other `_` refer to the
 * enclosing literal (`freeAnonymousSlots`). Unchanged subtrees are shared,
 * not copied. */
function renameBareSlot(expr: Expression): Expression {
  if (isSymbol(expr, '_'))
    return expr.engine.symbol('_1', { canonical: false });
  if (!isFunction(expr)) return expr;
  if (
    expr.operator === 'Function' &&
    (expr.nops < 2 ||
      functionLiteralBoundNames(expr.ops.slice(1)).includes('_'))
  )
    return expr;
  if ((expr as { _numericStore?: unknown })._numericStore !== undefined)
    return expr;
  const ops =
    expr.operator === 'Function'
      ? [renameBareSlot(expr.ops[0]), ...expr.ops.slice(1)]
      : expr.ops.map(renameBareSlot);
  if (ops.every((x, i) => x === expr.ops[i])) return expr;
  return expr.engine.function(expr.operator, ops, { form: 'raw' });
}

/** Assuming that ops has the following form:
 * - body
 * - ...params
 * return a canonical function literal (["Function", body, ...params]) where
 * body is potentially wrapped in a Block expression and the arguments are
 * declared in the scope of the body.
 */
export function canonicalFunctionLiteralArguments(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  options?: {
    /** Types INFERRED for bare parameters, by name. Such a parameter is
     * declared in the body scope with that type as an INFERRED type (a use
     * may still widen it, and, unlike an annotation, nothing is enforced at
     * apply time); a parameter not in the map starts `unknown`. An annotated
     * parameter is never affected. This is how a fold types its accumulator
     * to the fixpoint of its seed and its combiner's result
     * (`canonicalFoldCombiner`, `library/collections.ts`). */
    inferredParamTypes?: ReadonlyMap<string, Type>;
    /** True when the literal stands for a body with bound variables (the
     * integrand of `Integrate`, the body of a `Limit`), not for a literal the
     * user wrote. Its parameters are bound variables: `x(2)` in the body
     * stays the product `2x`, as it does for the index of a `Sum`
     * (`_isLiftedBodyParameter`). */
    liftedBody?: boolean;
    /** True for the second boxing of a body (see `typesToBoxAgain()`): the
     * body is not boxed a third time. */
    secondBoxing?: boolean;
  }
): Expression | undefined {
  if (ops.length === 0) return undefined;
  const rawOps = ops;
  // The outermost literal being boxed holds `startingTypes` until it
  // returns. A body whose first boxing was discarded in it starts at the
  // types that boxing found and is boxed once, unless the caller gives types.
  if (startingTypes === undefined)
    try {
      startingTypes = new WeakMap();
      return canonicalFunctionLiteralArguments(ce, ops, options);
    } finally {
      startingTypes = undefined;
    }
  const known =
    options?.secondBoxing === true || options?.inferredParamTypes
      ? undefined
      : startingTypes.get(ops[0]);
  if (known !== undefined)
    return canonicalFunctionLiteralArguments(ce, ops, {
      ...options,
      inferredParamTypes: known,
      secondBoxing: true,
    });

  // ── The E2 pre-pass (generic-literals design §2.3), ordered FIRST ──────────
  //
  // A full-signature marker in the body slot is the literal's contract
  // of record. It has to be read BEFORE the parameter operands are normalized:
  // a hand-authored E2 (and the M2 lowering) may carry `["Typed", x, "'T'"]`
  // parameters, and `T` is not a declared type name — type resolution would
  // fail on it below. Under the erasure ruling (G1) those annotations are
  // redundant anyway: the marker states the parameter types, and quantified
  // positions are erased so the body canonicalizes exactly as an untyped
  // literal's does.
  const erased = eraseGenericParameters(ce, ops);
  let genericMarker = false;
  if (erased !== undefined) {
    // A well-formedness violation is reported in place; otherwise continue with
    // the erased operands.
    if (erased.error !== undefined) return erased.error;
    ops = erased.ops!;
    genericMarker = erased.generic === true;
  }

  // Signature-string sugar (typed-literals design §3.2/§10):
  // `["Function", body, "'(n: integer) -> complex'"]` desugars into the
  // structural form — each named argument becomes a `["Typed", name, type]`
  // parameter and a non-`unknown` result becomes the body's return-type
  // ascription. Applied only when the single parameter operand is a string
  // parsing to a signature type with every argument named, no variadic
  // marker and no optional argument without a default value (an argument
  // with a default, `k: number = 2`, becomes an `Optional` parameter);
  // anything else falls through to the standard expected-a-symbol error —
  // except a string that IS signature-shaped and fails to parse as a type,
  // which reports the type parser's own diagnostic (see
  // `signatureStringError`) rather than blaming the operand.
  if (ops.length === 2 && isString(ops[1])) {
    // A `where` clause IS accepted here (generic-literals design §2.2, E1):
    // the string parses to a signature carrying `typeParams` and desugars into
    // the E2 form — bare symbols at the quantified positions (erasure, G1) and
    // the full signature as the body's ascription — which then re-enters this
    // function and takes the E2 pre-pass above.
    const desugared = desugarSignatureString(ce, ops[0], ops[1].string);
    if (desugared?.error !== undefined)
      return ce._fn('Function', [ops[0], desugared.error]);
    if (desugared !== undefined)
      return canonicalFunctionLiteralArguments(ce, desugared.ops!, options);
  }

  // Parameters: a bare symbol (inferred type) or an annotated parameter
  // `["Typed", symbol, type]`. Anything else is an error. An annotated
  // parameter keeps its `Typed` wrapper, normalized so the type operand is a
  // string (mirroring how `Declare` keeps its type operand raw), except a
  // parameter annotated `unknown` (or an alias of it), which becomes the
  // bare symbol.
  // An annotated parameter `["Typed", symbol, type]`, checked and normalized.
  // Used for a parameter and for the parameter inside an `Optional` wrapper.
  const typedParameter = (x: Expression & FunctionInterface): Expression => {
    // `Typed(k, "number?")` is the spelling of an optional parameter in a
    // signature, not a type: the type parser refuses it, and the parameter
    // was read as unannotated, so the `?` had no effect. A parameter of a
    // literal is optional when it has a default value, `Optional(k, 2)`.
    const text = isString(x.op2) ? x.op2.string.trim() : undefined;
    if (text !== undefined && text.endsWith('?'))
      return ce.error(
        [
          'invalid-parameter-annotation',
          'write `Optional(k, default)` for an optional parameter',
        ],
        x.toString()
      );
    const normalized = normalizeTypedParameter(ce, x);
    // A `where` clause on a PARAMETER annotation is a rank-2 spelling, and
    // stays rejected (G6, §2.2): a type variable enters a literal only
    // through a whole-signature clause.
    const t = functionLiteralParameterType(normalized);
    if (t !== undefined && isPolymorphicType(t))
      return ce.error(TYPE_VARIABLE_INTRODUCTION_MESSAGE, x.toString());
    // A parameter annotation is not the top-level signature of a
    // definition, so a default value of a parameter in it
    // (`Typed(f, "(number, number = 2) -> number")`) would never be used.
    if (t !== undefined && typeHasParameterDefault(t))
      return ce.error(NESTED_DEFAULT_MESSAGE, x.toString());
    // A parameter may not be declared with the marker `missing`: `Missing`
    // is a result only (`declaredTypeNamesMissing()`).
    if (t !== undefined && declaredTypeNamesMissing(t))
      return ce.error(
        ['invalid-type-annotation', DECLARED_MISSING_MESSAGE],
        x.toString()
      );
    // A parameter declared `unknown`, or a transparent alias of it, is a
    // parameter with no declaration (user decision 2026-10-30, recorded
    // with GitHub issue #488). The annotation is removed here, so every
    // later step sees a bare parameter: the body can narrow its type
    // (`t[1]` makes `t` an indexed collection, so a list argument is bound
    // whole), and a collection argument is mapped or bound whole exactly
    // as for `t`.
    if (isUnknownTypedParameter(normalized)) return x.op1;
    return normalized;
  };

  // The names of every parameter of the literal, read from the operands as
  // written. A default value may not name one of them.
  const writtenParameterNames = new Set<string>();
  for (const x of ops.slice(1)) {
    const target = isFunction(x, 'Optional') ? x.op1 : x;
    for (const name of functionLiteralParameterNames(target))
      writtenParameterNames.add(name);
  }

  // A parameter with a default value, `["Optional", param, default]`.
  // `param` is a symbol or an annotated symbol: a rest parameter or a
  // destructuring pattern cannot have a default. The default operand is
  // canonicalized here, in the scope where the literal is written, and must
  // be a constant that a signature can hold (`literalParameterDefault()`): a
  // number, a string, a boolean, `[]`, `{}`, or a constant symbol
  // (`isConstantSymbolDefault()`: a constant — a library constant or a
  // symbol declared constant — or a symbol that the annotation of the
  // parameter lists, `mode: symbol<Auto> = Auto`). The
  // symbol is checked before the default is canonicalized, so that a
  // refused symbol is not declared. Its
  // check against the parameter type happens after the body is
  // canonicalized, when the type that the body infers for a bare parameter
  // is known.
  const optionalParameter = (x: Expression & FunctionInterface): Expression => {
    // `Optional(k)` with no default would bind `k` to nothing when the
    // argument is left out, which needs rules of its own.
    if (x.nops < 2) return ce.error('missing', x.toString());
    if (x.nops > 2) return ce.error('unexpected-argument', x.ops[2].toString());
    const inner = x.op1;
    let target: Expression;
    if (isSymbol(inner)) target = inner;
    else if (isFunction(inner, 'Typed') && isSymbol(inner.op1)) {
      target = typedParameter(inner);
      if (isFunction(target, 'Error')) return target;
    } else return ce.error('expected-a-symbol', inner.toString());
    // `Nothing` and `Missing` are not values a call can receive in place of
    // an argument: `Nothing` is the value of an empty block, not an argument
    // value, and `Missing` is a result only. A default that names a parameter
    // of this literal is refused (see `writtenParameterNames`).
    const name = sym(x.op2);
    if (name === 'Nothing' || name === 'Missing')
      return ce.error(
        [
          'expected-a-literal-default',
          `\`${name}\` is not a default value; leave the parameter optional instead`,
        ],
        x.toString()
      );
    if (name !== undefined && writtenParameterNames.has(name))
      return ce.error(
        [
          'expected-a-literal-default',
          'a default value cannot name a parameter',
        ],
        x.toString()
      );
    if (
      name !== undefined &&
      name !== 'True' &&
      name !== 'False' &&
      !isConstantSymbolDefault(ce, name, functionLiteralParameterType(target))
    )
      return ce.error(
        ['expected-a-literal-default', SYMBOL_DEFAULT_MESSAGE],
        x.toString()
      );
    const defaultOp = x.op2.canonical;
    if (literalParameterDefault(defaultOp) === undefined)
      return ce.error(
        [
          'expected-a-literal-default',
          isSymbol(defaultOp)
            ? SYMBOL_DEFAULT_MESSAGE
            : 'a default value is a number, a string, a boolean, `[]` or `{}`',
        ],
        x.toString()
      );
    return ce._fn('Optional', [target, defaultOp], { canonical: false });
  };

  let seenOptional = false;
  const params = ops.slice(1).map((x, i) => {
    // The parameters with a default value come after the required ones, and
    // a rest parameter cannot follow one: a call that leaves out an argument
    // would otherwise not know which parameter is left out.
    if (isFunction(x, 'Optional')) {
      seenOptional = true;
      return optionalParameter(x);
    }
    if (seenOptional)
      return ce.error(
        [
          'expected-a-symbol',
          isFunction(x, 'Spread')
            ? 'a function with a rest parameter has no default values: drop the default or the rest parameter'
            : 'a required parameter cannot follow a parameter with a default value',
        ],
        x.toString()
      );
    if (isSymbol(x)) return x;
    // A REST parameter — `["Spread", symbol]`, spelled `(a, ...rest) => …` in
    // Epsil. It binds one name to a `Tuple` of every argument from its own
    // position onwards, so it is only meaningful as the LAST operand of the
    // parameter list: a rest parameter anywhere else would leave the
    // parameters after it with no argument to take. It also has to hold
    // exactly one symbol — there is no name to bind otherwise — and it carries
    // no type annotation (`["Typed", ["Spread", …], …]` reaches the
    // `expected-a-symbol` fallback at the end of this list).
    if (isFunction(x, 'Spread')) {
      if (i !== ops.length - 2)
        return ce.error('unexpected-argument', x.toString());
      if (x.nops !== 1 || !isSymbol(x.op1))
        return ce.error('expected-a-symbol', x.toString());
      return x;
    }
    // A DESTRUCTURING parameter — a raw `["Tuple", …]` pattern, spelled
    // `((p, q)) => …` in Epsil. It counts as one parameter and binds its leaf
    // names; the pattern operand is kept RAW (`isDestructuringParameter`).
    if (isDestructuringParameter(x)) {
      const bad = illFormedPatternLeaf(x);
      if (bad !== undefined) return ce.error('expected-a-symbol', bad);
      return x;
    }
    if (isFunction(x, 'Typed') && isSymbol(x.op1)) return typedParameter(x);
    return ce.error('expected-a-symbol', x.toString());
  });

  // Collect the declared types of annotated parameters so they are visible
  // during body canonicalization (the §6.1 pre-declare mechanism). A
  // destructuring pattern contributes every leaf name it binds — each is an
  // ordinary parameter as far as the body is concerned, and each must shadow a
  // library constant of the same spelling exactly as a named parameter does.
  const shadowNames: string[] = [];
  const shadowTypes = new Map<string, Type>();
  for (const param of params) {
    const names = functionLiteralParameterNames(param);
    if (names.length === 0) continue;
    shadowNames.push(...names);
    const t = functionLiteralParameterType(param);
    if (t !== undefined) shadowTypes.set(names[0], t);
    // A rest parameter has no annotation, but its value is always a `Tuple`
    // of the trailing arguments: a finite tuple of any arity. Declare it as
    // `tuple` in the body, so that `Length(rest)` is an `integer`, not an
    // `integer` that can also be infinite.
    else if (isFunction(param, 'Spread')) shadowTypes.set(names[0], 'tuple');
  }

  // A body-slot return-type ascription `["Typed", body, type]` is normalized
  // per §4.2: the `Typed` wrapper moves INSIDE the Block, wrapping the last
  // statement, so the body slot stays a scoped Block.
  let bodyOp = ops[0];
  let returnTypeOp: Expression | undefined;
  if (isFunction(bodyOp, 'Typed')) {
    returnTypeOp = normalizeTypeOperand(ce, bodyOp.op2);
    // A polytype in the body slot is ALWAYS a full signature (§2.2), and a
    // well-formed one was already recognized — and its quantified parameter
    // positions erased — by the E2 pre-pass above. Anything polymorphic still
    // arriving here is not a single signature (an overload INTERSECTION with a
    // generic arm), which is not a shape a literal can implement.
    if (
      !genericMarker &&
      isString(returnTypeOp) &&
      isPolytypeString(ce, returnTypeOp.string)
    )
      return ce._fn('Function', [
        ce.error(INVALID_SIGNATURE_MARKER_MESSAGE, returnTypeOp.string),
        ...params,
      ]);
    bodyOp = bodyOp.op1;
  }

  // If the body is not scoped, we need to create a new scope
  // and add the parameters to it.
  // `["Function", ["Add", "_", 1], "_"]`
  // becomes `["Function", ["Block", ["Add", "_", 1]], "_"]`
  //
  // The body is canonicalized here. While it is, the parameter names are pushed
  // onto the engine's shadowed-parameter stack so a parameter named like a
  // constant (`i`, `e`, ...) resolves to the parameter, not the constant —
  // `Function(2·i, i)` stays `(i) ↦ 2·i` instead of becoming `(i) ↦ 2i`. The
  // shadowing only blocks the constant substitution; the parameter is still
  // auto-declared as an ordinary local in the body scope, so the closure-capture
  // machinery is unaffected. Annotated parameters additionally carry their
  // declared type so the auto-declaration uses that type (see §6.1).
  // An inferred hint applies to a BARE parameter only: an annotation is the
  // author's contract and is never replaced by an inference.
  const inferredHints =
    options?.inferredParamTypes !== undefined
      ? new Map(
          [...options.inferredParamTypes].filter(
            ([name]) => shadowNames.includes(name) && !shadowTypes.has(name)
          )
        )
      : undefined;
  ce._pushShadowedParameters(
    shadowNames,
    shadowTypes.size > 0 ? shadowTypes : undefined,
    inferredHints !== undefined && inferredHints.size > 0
      ? inferredHints
      : undefined,
    undefined,
    true,
    options?.liftedBody === true
  );
  // What a first boxing of the body that is discarded must leave as it was
  // (`typesToBoxAgain()`): the entries of the unit environments and the
  // requirements on the parameters of the enclosing literals.
  const firstBoxing =
    options?.secondBoxing === true || bodyOp.isCanonical
      ? undefined
      : {
          marks: ce._boxingState.journalMarks(),
          restore: ce._saveParameterRequirements(),
        };
  let boxAgain: Map<string, Type> | undefined;
  // Collect the juxtapositions the body reads as multiplication only because
  // their leading symbol has no function definition yet — see
  // `boxed-expression/provisional-application.ts`.
  beginProvisionalCapture();
  let captured: ProvisionalCapture | undefined;
  let block: Expression;
  let shadowedDefs: ReadonlyMap<string, BoxedDefinition> = new Map();
  let record: ParameterRecord | undefined;
  // The body is not in a branch, also when the literal is written in one:
  // a `Declare` at the own level of the body declares a local of the body
  // (`enterFunctionBody()`, `statement-position.ts`).
  enterFunctionBody();
  const build = (): Expression => {
    if (returnTypeOp === undefined) {
      if (isFunction(bodyOp, 'Block')) {
        // The canonical form of the body depends on the parameter frame
        // pushed above, so the read neither takes nor gives the canonical
        // forms of the reads outside this literal
        // (`withSeparateCanonicalReads()`). Otherwise, a raw block met again
        // in the same read (the fold refinement canonicalizes the same raw
        // combiner once per step, with another inferred accumulator type)
        // got the canonical form of the first step.
        let b = withSeparateCanonicalReads(() => bodyOp.canonical);
        // `get canonical` short-circuits on an invalid expression (a `Block`
        // containing an `Error` node) and returns it unbound — and therefore
        // unscoped. Rebuild it from its statements so `Block`
        // canonicalization runs and creates the scope the parameter
        // declarations below rely on. An EMPTY block is canonical and scoped
        // as it is (`canonicalBlock`), so it never reaches this rebuild.
        if (!b.isScoped) b = ce.function('Block', [...bodyOp.ops]);
        return b;
      }
      return ce.function('Block', [bodyOp]);
    }
    // Wrap the body Block's last statement in the return-type ascription.
    const statements: Expression[] = isFunction(bodyOp, 'Block')
      ? [...bodyOp.ops]
      : [bodyOp];
    if (statements.length === 0) statements.push(ce.Nothing);
    const lastIdx = statements.length - 1;
    statements[lastIdx] = ce._fn('Typed', [statements[lastIdx], returnTypeOp], {
      canonical: false,
    });
    return ce.function('Block', statements);
  };
  try {
    // A second boxing reads none of the canonical forms of the discarded
    // one (`withSeparateCanonicalReads()`).
    block =
      options?.secondBoxing === true
        ? withSeparateCanonicalReads(build)
        : build();
    // Read the bindings the body's bare-parameter references auto-declared
    // (and shared) while the frame is still on the stack — the parameter
    // declarations below adopt them.
    shadowedDefs = ce._currentShadowedParameterDefs();
    record = ce._currentParameterRecord();
    if (firstBoxing !== undefined)
      boxAgain = typesToBoxAgain(params, shadowedDefs, record);
  } finally {
    exitFunctionBody();
    captured = endProvisionalCapture(boxAgain === undefined);
    ce._popShadowedParameters();
  }

  // A use changed the type of a bare parameter from a number type to
  // another type: the nodes built before that use read the parameter as a
  // number (`A·B − B·A` cancels to `0`). This boxing is discarded, and the
  // body is boxed once more from its raw operands, each such parameter
  // starting at its final type.
  if (boxAgain !== undefined) {
    ce._boxingState.undoJournalsTo(firstBoxing!.marks);
    firstBoxing!.restore();
    startingTypes!.set(rawOps[0], boxAgain);
    return canonicalFunctionLiteralArguments(ce, rawOps, {
      ...options,
      inferredParamTypes: new Map([
        ...(options?.inferredParamTypes ?? []),
        ...boxAgain,
      ]),
      secondBoxing: true,
    });
  }

  // The body has no scope when the `canonical` handler of `Block` threw: the
  // engine then logs the exception and boxes the block NON-canonical, with no
  // scope. The literal cannot declare its parameters without that scope, so
  // throw the exception of the handler again: the caller gets the original
  // message, not a failure on the missing scope. Through `ce.box()`, the
  // `Function` operator's own catch then logs that message and boxes the
  // literal non-canonical, as for any other failed `canonical` handler.
  const blockScope = block.isScoped ? block.localScope : undefined;
  if (blockScope === undefined) {
    const failure = canonicalFailureOf(block);
    if (failure !== undefined) throw failure.error;
    throw new Error(
      `The body of the function literal could not be canonicalized: ${block.toString()}`
    );
  }
  // Declare the arguments in the scope of the body of the function, for any
  // parameter that was not already auto-declared during body canonicalization
  // (e.g. a parameter unreferenced in the body). Annotated parameters get
  // their declared type, non-inferred.
  for (const param of params) {
    for (const name of functionLiteralParameterNames(param)) {
      if (blockScope.bindings.has(name)) continue;
      // A destructuring pattern's leaves carry no annotation of their own, so
      // they are always declared with the inferred `unknown` type below.
      const t = isDestructuringParameter(param)
        ? undefined
        : functionLiteralParameterType(param);
      // A parameter whose first reference sat in a NESTED Block scope (an `if`
      // branch, a loop body, the body of a nested function literal)
      // auto-declared its shared binding there, not here. Adopt that binding as
      // the parameter's: it is the one every body occurrence resolves to, and
      // the one that carries the type evidence inference wrote (e.g. `cs[j]` ⇒
      // `cs: indexed_collection`). Declaring a fresh binding instead severs the
      // signature from the body's evidence: the lambda auto-broadcast then
      // wrongly maps the function over a collection argument that the body
      // consumes whole, and — for a parameter named after a library constant —
      // the parameter-repair rewrite below re-boxes the body occurrences, which
      // turns a nested `i` back into the imaginary unit.
      // An ANNOTATED parameter's shared binding already carries the declared
      // type: the first reference creates it with that type, non-inferred (see
      // the annotated branch of the shadowed-parameter resolution in
      // `engine-expression-entrypoints.ts`).
      const shared = shadowedDefs.get(name);
      if (shared !== undefined) blockScope.bindings.set(name, shared);
      else if (t !== undefined)
        ce.declare(name, { inferred: false, type: t }, blockScope);
      else
        ce.declare(
          name,
          { inferred: true, type: inferredHints?.get(name) ?? 'unknown' },
          blockScope
        );
    }
  }

  // Re-bind parameter occurrences that were canonicalized OUTSIDE this Block.
  //
  // Canonicalizing an already-canonical body is a no-op, so a body that was
  // bound before the literal was built keeps those bindings — and its
  // parameter occurrences then denote whatever the enclosing scope had, not
  // this literal's parameters. The shorthand route does exactly that: `Pipe`
  // is lazy and takes `.canonical` of its right operand, so `x |> Map(f, _)`
  // binds `_1` in the CALLER's scope before `Map(f, _1)` is wrapped into
  // `(_1) ↦ Map(f, _1)`. The parameter then looks like a free variable, and
  // anything keyed on binding — the post-evaluation substitution in
  // `makeLambda`, symbol equality — cannot see it is the parameter.
  //
  // Rebinding is scoped to the names this literal binds, so nothing else in
  // the body moves.
  // Record the binding of each parameter as a parameter binding
  // (`markFunctionLiteralParameter()`): a call of a parameter named `Return`
  // is then not read as the `Return` statement.
  const parameterDefs = new Set<BoxedValueDefinition>();
  const parameterBindings = new Map<BoxedValueDefinition, BoxedDefinition>();
  for (const param of params)
    for (const name of functionLiteralParameterNames(param)) {
      const binding = blockScope.bindings.get(name);
      if (binding !== undefined && 'value' in binding) {
        markFunctionLiteralParameter(ce, binding.value);
        parameterDefs.add(binding.value);
        parameterBindings.set(binding.value, binding);
      }
    }
  // The default value of a parameter must fit the parameter type: the
  // annotation, or, for a bare parameter, the type that the body's uses
  // inferred (`(x, k = "a") => x * k` is refused, because `Multiply` needs a
  // number). A default that does not fit makes the parameter the error
  // `incompatible-type`, as an argument of the wrong type is.
  params.forEach((param, i) => {
    const defaultOp = optionalParameterDefault(param);
    if (defaultOp === undefined) return;
    const d = literalParameterDefault(defaultOp);
    if (d === undefined) return;
    const name = functionLiteralParameterName(param);
    const binding = blockScope.bindings.get(name);
    const type =
      functionLiteralParameterType(param) ??
      (binding !== undefined && 'value' in binding
        ? (record?.requirements.get(binding.value)?.type.type ??
          binding.value.type.type)
        : undefined);
    if (type === undefined) return;
    // A symbol that the annotation lists (`mode: symbol<Auto> = Auto`) fits
    // it: it was checked before the default was canonicalized.
    if (d.kind === 'symbol' && literalSymbolNames(type).includes(d.name))
      return;
    if (!defaultOp.type.matches(type))
      params[i] = ce.typeError(type, defaultOp.type, defaultOp);
  });
  // The rebinding of the body is a step of the boxing of the literal: a use
  // of a parameter that it boxes records its requirement as a use of the
  // body did.
  // The frame of a function literal always has a record
  // (`_pushShadowedParameters()`).
  console.assert(record !== undefined, 'A function literal has a record');
  const closing = record!;
  block = ce._withClosingLiteral(parameterDefs, closing, () =>
    rebindParameters(block, params)
  );

  // The boxing of the literal is complete: what the uses of each parameter
  // required is written on its definition, once (decision D18 of
  // `docs/plans/2026-11-11-bound-once-spec.md`). The definitions were made
  // by this boxing and belong to the literal, so the write has no rollback
  // record; one state event follows it (below). The cause of the use that last changed
  // the requirement is the provenance of the type (`_typeProvenance`), as
  // for an inference written on a definition.
  let typeChanged = false;
  let allCreated = true;
  let widening = false;
  let allScratch = true;
  for (const [value, { type, cause }] of closing.requirements) {
    // A definition that already has the type (the body of a literal boxed
    // again, which keeps its scope) is not written: the write would replace
    // its `BoxedType` and move its `_writeVersion`, which the memos of the
    // elements of a lazy collection read (`collection-element-memo.ts`).
    // A parameter with assignment evidence (`Assign(x, [1, 2])` in the
    // body, `joinAssignmentEvidence()` in `library/core.ts`) has the join of
    // its assigned value types as its type, and a use does not narrow it
    // (`BoxedSymbol._inferWithoutFacts()`): the record of the uses made
    // before the assignment is not written over it.
    if (value._assignmentEvidence && value.value === undefined) continue;
    const current = value.type;
    if (
      current.type === type.type ||
      (typeof current.type === 'object' &&
        typeof type.type === 'object' &&
        current.toString() === type.toString() &&
        isSubtype(current.type, type.type) &&
        isSubtype(type.type, current.type))
    )
      continue;
    if (!isSubtype(type.type, current.type)) widening = true;
    value._setType(() => type);
    value.inferredType = true;
    typeChanged = true;
    if (!closing.created.has(value)) allCreated = false;
    if (!isScratchBinding(ce, parameterBindings.get(value) ?? value))
      allScratch = false;
    if (cause !== undefined) {
      cause.expr ??= ce._fn(
        cause.operator,
        cause.ops.map((o: ExpressionInput) => ce.expr(o, { form: 'raw' })),
        { canonical: false }
      );
      recordTypeProvenance(value, {
        type,
        kind: 'inferred',
        axis: 'type',
        cause: cause.expr,
      });
    }
  }
  // One state event for the literal when a write changed a type: a type
  // cached on another node during the boxing (the recursive call of a
  // function whose signature is derived from a copy of the literal) can
  // depend on the type of a parameter before the literal is complete, and
  // its cache is keyed on the versions that the event advances. Cache keys
  // that hold the definitions they read (decision D17 of
  // `docs/plans/2026-11-11-bound-once-spec.md`) would remove this event.
  // A narrowing made when no evaluation that keeps its result in the memo
  // of shared evaluations started since the boxing started does not advance
  // the evaluation version (`parameter`, `noteStateEvent`): no result of
  // the memo can have read the types of these parameters.
  if (typeChanged)
    ce._noteStateEvent({
      kind: 'inference',
      valueType: true,
      widening,
      ...(allScratch ? { scratch: true } : {}),
      ...(!widening &&
      allCreated &&
      sharedEvaluationStarts() === closing.memoStarts
        ? { parameter: true }
        : {}),
    });
  const literal = ce._fn('Function', [
    block,
    ...bindParameterOperands(ce, block, params),
  ]);

  // Resolve the annotations NOW, while the scope that declares any
  // user-declared type name they use is still current: the literal can escape
  // it (assigned outward, returned, stored in a collection) and its type
  // operands are TEXT, which no longer resolves from where a later reader
  // stands. See `RESOLVED_TYPE_OPERANDS` (`function-literal.ts`).
  resolveFunctionLiteralTypes(literal);

  // Record the occurrences of the body that read a symbol from outside the
  // literal (`markFunctionLiteralCaptures()`): when the body is evaluated
  // they read the value that the symbol has at that time, so their type now
  // does not bound the value that a call reads.
  if (isFunction(literal)) markFunctionLiteralCaptures(literal.ops[0]);

  // Definition order must not change semantics. If the body froze a
  // juxtaposition as multiplication only because its leading symbol had no
  // function definition at this moment, keep the RAW operands so the literal
  // can be re-derived when that symbol gains one
  // (`repairProvisionalDependents`).
  // The literal may also be a RE-canonicalization of one already built (the
  // `Function` operator's canonical handler runs a second time, on the
  // literal's own operands): its body is then the very `Block` recorded the
  // first time round, and the raw operands to re-derive from are the ones
  // recorded with it.
  const provisional =
    captured?.heads !== undefined
      ? {
          ops,
          heads: captured.heads,
          scope: ce.context.lexicalScope,
        }
      : provisionalLiteral(ops[0]);

  if (provisional !== undefined) {
    setProvisionalLiteral(literal, provisional);
    setProvisionalLiteral(block, provisional);
  }

  return literal;
}

/** While a literal is boxed (the outermost one makes it): for the raw body
 * operand of a literal whose first boxing was discarded, the types its
 * parameters start at in a second boxing (`typesToBoxAgain()`). */
let startingTypes: WeakMap<object, ReadonlyMap<string, Type>> | undefined;

/**
 * The bare parameters of a literal (no annotation, not a rest or
 * destructuring parameter) that the first boxing of its body must box again,
 * with the type each starts at in the second boxing: a parameter whose
 * recorded type was a number type at a use (`ParameterRequirement.numeric`)
 * and is another type at the end. `undefined` when there is none.
 */
function typesToBoxAgain(
  params: ReadonlyArray<Expression>,
  defs: ReadonlyMap<string, BoxedDefinition>,
  record: ParameterRecord | undefined
): Map<string, Type> | undefined {
  let result: Map<string, Type> | undefined;
  for (const param of params) {
    const target = optionalParameterTarget(param);
    if (!isSymbol(target)) continue;
    const def = defs.get(target.symbol);
    if (def === undefined || !('value' in def)) continue;
    const requirement = record?.requirements.get(def.value);
    if (
      requirement?.numeric !== true ||
      isSubtype(requirement.type.type, 'number')
    )
      continue;
    (result ??= new Map()).set(target.symbol, requirement.type.type);
  }
  return result;
}

/** Definitions currently being re-derived, so a repair that itself installs a
 * definition cannot re-enter one. */
const REPAIRING = new WeakSet<object>();

/** The `Function` literal a dependent currently holds: the operator
 * definition's lambda, or the value definition's value. */
function dependentLiteral(def: ProvisionalDependent): Expression | undefined {
  if ('signature' in def)
    return (def as { _lambdaLiteral?: Expression })._lambdaLiteral;
  return def.value;
}

/** Install a re-derived literal on a dependent, whichever kind it is.
 *
 * This is the one site that mutates a pre-existing definition IN PLACE
 * during the provisional-repair cascade: it does not route through
 * `updateDef`. The Epsil static check records a definition handed to this
 * repair before it runs (`provisionalRegistryRollbackPoint()`). */
function installRebuiltLiteral(
  ce: ComputeEngine,
  def: ProvisionalDependent,
  rebuilt: Expression
): void {
  // Effects-axis provenance (W2 of
  // `docs/EFFECTS-MODEL.md`): the re-derivation
  // re-stamps the inferred effect set from the rebuilt body, and a change
  // records an entry whose cause is the REBUILT literal — deliberately
  // overriding any ambient canonicalization cause, which would
  // misattribute the re-derivation to the enclosing expression.
  const effectsBefore = effectsContractStateOf(def);
  // `_update()` re-registers the definition for whatever names the rebuilt body
  // still reads provisionally.
  if ('signature' in def) {
    // A re-derivation keeps the mark of a local (`_bindsLocal`). A declared
    // contract that was trusted at install stays trusted
    // (`_contractTrusted`).
    const op = def as { _rederiving?: boolean };
    op._rederiving = true;
    try {
      def._update(
        (def as { _bindsLocal?: boolean })._bindsLocal === true
          ? markLocalBinding({ evaluate: rebuilt })
          : { evaluate: rebuilt }
      );
    } finally {
      op._rederiving = false;
    }
    recordEffectsTransition(
      def,
      effectsBefore,
      effectsContractStateOf(def),
      def.signature,
      rebuilt
    );
  } else {
    // A value definition under a DECLARED effects contract (`(number) pure
    // -> number`) checks the rebuilt literal against it, as the operator
    // branch does inside `_update()`: a body that a product reading kept
    // pure (`x ↦ 2h(x)` with `h` not yet a function) can become an
    // effectful application when `h` gains a definition. The check throws
    // before the write, so the previous literal stays, and the caller keeps
    // the definition registered and reports the error. A walk that saw an
    // unresolved head cannot decide the check, and the literal is installed
    // as for the operator branch.
    const declared = signatureEffects(def.type.type);
    const name = dependentName(def);
    if (name !== undefined && (declared !== undefined || def.effectsDeclared)) {
      const inferred = inferFunctionLiteralEffects(ce, rebuilt, {
        selfName: name,
      });
      if (
        !inferred.unresolvedHead &&
        !isEffectSubset(inferred.effects, declared)
      )
        throw new EffectContractError(
          name,
          declared,
          inferred.effects,
          latestDeclaredEffectsSite(def)
        );
    }
    def.value = rebuilt;
    registerProvisionalDependents(ce, rebuilt, def);
    // No effects-provenance recording on this branch — deliberately. The
    // `value` setter writes the stored expression only; it never touches the
    // definition's `type` or `effectsDeclared`, which are the two fields the
    // effects contract state is read from, so the before/after comparison a
    // recording would make is identical by construction and could never
    // produce an entry. (W2 of the effects-axis provenance design covers the
    // OPERATOR branch above, whose `_update()` genuinely re-derives and
    // re-stamps the effect set.)
  }
}

/**
 * Make the operator definition `def` give no value: the rebuild of its body,
 * against the new definition of a name that the body reads, gave an invalid
 * body.
 *
 * The definition constructor refuses an invalid body, so `def` keeps its
 * previous literal, and it stays registered, so that a later definition of
 * the name retries it. But the previous literal was made when the name had no
 * definition, and an application of it reads the new definition of the name:
 * with `g(t) := 2a(t)` before `a(x, y) := x + y`, `g(1)` multiplied 2 by the
 * partial application of `a` and gave `2·(y ↦ 1 + y)`. In the other order,
 * the definition of `g` is refused and `g(1)` stays `g(1)`. So the
 * evaluation handlers of `def` are replaced by a handler that gives no value,
 * and an application of `def` stays unevaluated, as in the other order. A
 * later rebuild that succeeds installs a new body with `_update()`, which
 * replaces these handlers.
 *
 * This is an in-place change of a definition, as in `installRebuiltLiteral`:
 * it advances the version of the definition, and it is reported as a repair
 * event, so that a memoized result of an application of `def` is not used.
 */
function holdDependentWithInvalidBody(
  ce: ComputeEngine,
  def: BoxedOperatorDefinition
): void {
  beforeDefinitionWrite(def);
  def._writeVersion += 1;
  def.evaluate = () => undefined;
  def.evaluateAsync = undefined;
  ce._noteStateEvent({
    kind: 'binding-repair',
    ...(isScratchBinding(ce, def) ? { scratch: true } : {}),
  });
}

/** The name a dependent definition is installed under. Both definition classes
 * are constructed with it (`_BoxedOperatorDefinition`,
 * `_BoxedValueDefinition`), but it is not on the public definition interfaces,
 * so read it defensively: a dependent with no readable name simply does not
 * cascade. */
function dependentName(def: ProvisionalDependent): string | undefined {
  const name = (def as { name?: unknown }).name;
  return typeof name === 'string' && name.length > 0 ? name : undefined;
}

/** How deep the `repairWave` recursion currently is. Depth 0 on entry marks
 * the OUTERMOST wave: the one that owns the deferred queue below, because it
 * is the only one that runs after every `REPAIRING` guard has been released. */
let WAVE_DEPTH = 0;

/** Dependents skipped because an enclosing wave already held them under the
 * `REPAIRING` guard, with the name whose wave skipped them. Nothing else
 * retriggers such a definition, so it would stay stale forever: with
 * `outer(a,b) = middle(a) + base(b)`, `middle(a) = base(a)`, `outer`
 * registered on `base` BEFORE `middle`, installing `base` rebuilds `outer`
 * against middle's stale signature, and middle's cascade then finds `outer`
 * guarded and skips it. Drained by the outermost wave. */
let DEFERRED: {
  name: string;
  def: ProvisionalDependent;
  /** The scopes of the binding of `name`, as the wave that skipped `def`
   * had them: the drain repairs with the same selection. */
  declaredIn: Scope | undefined;
  boundIn: Scope | undefined;
}[] = [];

/** Whether the scopes `a` and `b` stand for the same lexical level, for the
 * selection of `repairWave()`. Two scope objects do when they are the same
 * object, when they share their map of bindings (the copy of a scope that a
 * capture makes), or when one is a run of the other:
 * the activation that an evaluation pushes in place of the local scope of a
 * scoped node (`scopeActivationTemplate()`). A run has the parent of its
 * template as its parent, not the template, so the parent links alone do not
 * relate a binding in a call frame under a run to a literal that was
 * canonicalized in the template. */
function sameLexicalLevel(a: Scope, b: Scope): boolean {
  if (a === b || a.bindings === b.bindings) return true;
  const ta = scopeActivationTemplate(a);
  const tb = scopeActivationTemplate(b);
  return ta === b || tb === a || (ta !== undefined && ta === tb);
}

/** The scope that holds the definition `def` under `name`, for the repair
 * that follows a rebuild of `def`: that repair re-derives only the
 * definitions that can see `def`. `home` is the scope the literal of `def`
 * was canonicalized in. The binding is in `home` or in a scope above it (a
 * definition is made in the scope of its statement, and its literal is
 * canonicalized there), or else on the chain of the current scope.
 * `undefined` when neither chain holds it: the repair then takes every
 * waiting definition. */
function scopeOfDependent(
  ce: ComputeEngine,
  name: string,
  def: ProvisionalDependent,
  home: Scope | undefined
): Scope | undefined {
  const holds = (binding: { value?: unknown; operator?: unknown }): boolean =>
    binding.value === def || binding.operator === def;
  return (
    scopeOfBinding(home, name, holds) ??
    scopeOfBinding(ce.context?.lexicalScope, name, holds)
  );
}

/** Rebuilds already spent on each definition in the current top-level wave,
 * reset when it ends. */
let REBUILD_COUNTS: WeakMap<ProvisionalDependent, number> | undefined;

/** Rebuilds allowed per definition per top-level wave. Two, because the
 * sibling shape above needs exactly a second rebuild (once in the wave that
 * skipped it, once from the drain) and nothing legitimately needs a third: a
 * genuinely cyclic, evidence-free pair would otherwise re-defer each other
 * without end. A definition that hits the cap stays REGISTERED, so a later
 * definition of a name it waits on still retries it. */
const MAX_REBUILDS_PER_WAVE = 2;

/**
 * `name` just became callable: re-derive every definition whose body read
 * `name` as a multiplication operand, from the raw operands recorded at
 * canonicalization time.
 *
 * Injected into `boxed-expression/provisional-application.ts` by
 * `init-lazy-refs.ts` — `updateDef` (`boxed-expression/utils.ts`) is the choke
 * point that fires it, and it cannot import this module.
 */
export function repairProvisionalDependents(
  ce: ComputeEngine,
  name: string,
  justInstalled?: ProvisionalDependent,
  declaredIn?: Scope,
  boundIn?: Scope
): void {
  const outermost = WAVE_DEPTH === 0;
  let firstError: { error: unknown } | undefined;
  WAVE_DEPTH += 1;
  try {
    repairWave(ce, name, justInstalled, declaredIn, boundIn);
  } catch (error) {
    firstError = { error };
  } finally {
    WAVE_DEPTH -= 1;
  }

  if (outermost) {
    // Every guard this wave took is released by now, so a skipped dependent
    // can be repaired. Each drained repair can itself skip (and defer) more,
    // so loop until the queue is empty; `MAX_REBUILDS_PER_WAVE` is what
    // bounds it. The waves fired from here are not outermost — they append to
    // the queue this loop is draining rather than starting a drain of their
    // own.
    WAVE_DEPTH += 1;
    try {
      while (DEFERRED.length > 0) {
        const batch = DEFERRED;
        DEFERRED = [];
        // The defs were re-registered when they were skipped, so firing the
        // name once picks up every dependent that queued under it.
        // A name is fired once for each pair of scopes of its binding: the
        // selection of a wave depends on them.
        const fired: typeof batch = [];
        for (const entry of batch) {
          if (
            fired.some(
              (f) =>
                f.name === entry.name &&
                f.declaredIn === entry.declaredIn &&
                f.boundIn === entry.boundIn
            )
          )
            continue;
          fired.push(entry);
          try {
            repairWave(
              ce,
              entry.name,
              undefined,
              entry.declaredIn,
              entry.boundIn
            );
          } catch (error) {
            firstError ??= { error };
          }
        }
      }
    } finally {
      WAVE_DEPTH -= 1;
      DEFERRED = [];
      REBUILD_COUNTS = undefined;
    }
  }

  if (firstError !== undefined) throw firstError.error;
}

/** One re-derivation wave. See `repairProvisionalDependents`, which wraps it
 * with the deferred-queue drain. */
function repairWave(
  ce: ComputeEngine,
  name: string,
  justInstalled?: ProvisionalDependent,
  declaredIn?: Scope,
  boundIn?: Scope
): void {
  // When the new binding of `name` is in a known scope (`declaredIn`), only
  // the dependents that can see it are taken: those whose literal was
  // canonicalized in `declaredIn` or in a scope under it, read from the
  // literal each one holds NOW, the scope the rebuild below uses. The others
  // stay registered, since `name` still resolves for them as it did. A
  // dependent with no recorded literal is taken, as before: the loop below
  // drops it.
  const defs = takeProvisionalDependents(
    ce,
    name,
    declaredIn === undefined && boundIn === undefined
      ? undefined
      : (def) => {
          const home = provisionalLiteral(dependentLiteral(def))?.scope;
          if (home === undefined) return true;
          if (declaredIn !== undefined) {
            for (let s: Scope | null | undefined = home; s; s = s.parent)
              if (s === declaredIn) return true;
            return false;
          }
          // With `boundIn`, the definition is taken when a scope of its
          // chain holds the binding itself: the same record, or a record
          // with the same value or operator definition. One binding can be
          // in several scopes that are not related by their parent links:
          // `ce.createScope()` installs a definition of another scope, and an
          // activation holds the records of its template scope
          // (`scopeActivation()`). Two scope objects can also
          // stand for one lexical level (`sameLexicalLevel()`), and the
          // binding can be a local that the literal assigns in its own body,
          // in a scope under `home`: the literal reads it, so its definition
          // is taken too (`repairProvisionalDependents()`,
          // `provisional-application.ts`).
          const bound = boundIn!.bindings.get(name) as
            { value?: unknown; operator?: unknown } | undefined;
          for (let s: Scope | null | undefined = home; s; s = s.parent) {
            if (sameLexicalLevel(s, boundIn!)) return true;
            const seen = s.bindings.get(name) as
              { value?: unknown; operator?: unknown } | undefined;
            if (seen === undefined || bound === undefined) continue;
            if (
              seen === bound ||
              (seen.value !== undefined && seen.value === bound.value) ||
              (seen.operator !== undefined && seen.operator === bound.operator)
            )
              return true;
          }
          for (let s: Scope | null | undefined = boundIn; s; s = s.parent)
            if (sameLexicalLevel(s, home)) return true;
          return false;
        }
  );
  if (defs === undefined) return;
  // A rebuild can THROW: the definition constructors validate (a violated
  // effect contract, an invalid body). The queue has already been drained, so
  // an error escaping the loop would lose every dependent not yet processed.
  // Each one is therefore rebuilt in isolation; a failed one keeps its previous
  // definition (`_update()` constructs before it swaps) and is RE-REGISTERED so
  // a later redefinition of `name` retries it; and the first error is rethrown
  // once the loop is done — a contract violation must still surface.
  let firstError: { error: unknown } | undefined;
  // Every definition this wave puts under the `REPAIRING` guard, released
  // together once the wave — INCLUDING the cascade below — is done. See the
  // cascade comment for why the release cannot happen per-definition.
  const guarded: ProvisionalDependent[] = [];
  // The definitions this wave actually re-installed, with the name each is
  // installed under. Collected during the loop and cascaded AFTER it (see
  // below), not fired per-rebuild.
  const cascade: {
    name: string;
    def: ProvisionalDependent;
    home: Scope | undefined;
  }[] = [];
  try {
    for (const def of defs) {
      if (REPAIRING.has(def)) {
        // Mid-repair further up the stack, or held under the guard until its
        // own wave's cascade finishes. Either way it must go BACK into the
        // registry: `takeProvisionalDependents` has already removed it, and
        // since the cascade keeps a definition guarded well after its own
        // rebuild re-registered it, dropping it here would leave it waiting on
        // nothing — permanently unrepairable by a later definition of `name`.
        registerProvisionalDependents(ce, dependentLiteral(def), def);
        // Re-registering alone does not retrigger it, so queue it for the
        // drain the outermost wave runs once the guards are released.
        if ((REBUILD_COUNTS?.get(def) ?? 0) < MAX_REBUILDS_PER_WAVE)
          DEFERRED.push({ name, def, declaredIn, boundIn });
        continue;
      }
      // The definition just installed FOR `name` is dropped, not re-derived: it
      // is a recursive body waiting on itself, and re-canonicalizing it against
      // its own fresh definition cannot teach it anything (direct body evidence
      // was already captured in flight). Dropping rather than re-registering is
      // safe: a later redefinition of `name` registers fresh dependents.
      if (def === justInstalled) continue;
      const literal = dependentLiteral(def);
      const info = provisionalLiteral(literal);
      if (info === undefined || !info.heads.has(name)) continue;
      const rebuilds = (REBUILD_COUNTS ??= new WeakMap());
      const spent = rebuilds.get(def) ?? 0;
      if (spent >= MAX_REBUILDS_PER_WAVE) {
        // Out of budget for this top-level wave. Back into the registry, so a
        // later definition still retries it.
        registerProvisionalDependents(ce, literal, def);
        continue;
      }
      rebuilds.set(def, spent + 1);
      REPAIRING.add(def);
      guarded.push(def);
      let rebuilt: Expression | undefined;
      try {
        // Re-canonicalized in the scope the literal was built in: its free
        // symbols must resolve exactly as they did then, except for the one that
        // has since become a function.
        rebuilt = ce._inScope(info.scope, () =>
          canonicalFunctionLiteralArguments(ce, info.ops)
        );
        // A value definition gets the rebuilt literal even when it is
        // INVALID: a fresh parse made after `name` was defined produces
        // exactly that invalid application, and fresh-parse parity is the
        // contract. Keeping the stale product instead would silently answer
        // a different question. An operator definition does not: its
        // `_update()` throws for an invalid body, and the `catch` below keeps
        // the previous definition, re-registers it and reports the error.
        if (rebuilt !== undefined && rebuilt !== literal) {
          installRebuiltLiteral(ce, def, rebuilt);
          // The rebuilt literal is installed in place, without `updateDef`,
          // so this is the repair event for it. It advances the definition
          // version that memoized signatures key on
          // (`declaredResultMemoKey`): a signature derived from the old
          // literal may now be wrong. The `binding-repair` that `updateDef`
          // emits for a FRESH declaration relies on this advance, since it
          // does not advance the version itself. A dependent that is a
          // scratch binding (`scratch-scopes.ts`) is flagged, as in
          // `updateDef`.
          ce._noteStateEvent({
            kind: 'binding-repair',
            ...(isScratchBinding(ce, def) ? { scratch: true } : {}),
          });
          const installedName = dependentName(def);
          if (installedName !== undefined)
            cascade.push({ name: installedName, def, home: info.scope });
        }
      } catch (error) {
        // When the definition constructor refuses an invalid body, the error
        // carries the first error of the body, which the operator routes
        // give as the value of the statement (`DependentRebuildError`).
        const bodyError =
          rebuilt !== undefined && error instanceof Error
            ? errorValue(rebuilt)
            : undefined;
        firstError ??= {
          error:
            bodyError !== undefined
              ? new DependentRebuildError(bodyError, (error as Error).message)
              : error,
        };
        // The previous body is kept for a later retry, but it must not give
        // a value: a definition made now has the invalid rebuilt body. The
        // test is on the body itself, not on `bodyError`: `errorValue()`
        // does not report an error inside a collection literal, and
        // `(2, a(t, Error("missing")))` is invalid all the same.
        if (rebuilt !== undefined && !rebuilt.isValid && 'signature' in def)
          holdDependentWithInvalidBody(ce, def);
        registerProvisionalDependents(ce, literal, def);
      }
    }

    // A successful rebuild IS that definition's own name gaining a better
    // definition — `middle` now takes a list — but `installRebuiltLiteral`
    // mutates the definition in place (`def._update()` / `def.value = …`) and
    // never passes through `updateDef`, the choke point that fires the repair.
    // So fire it here, or a chain `outer → middle → inner` would leave `outer`
    // stale once `inner` arrives.
    //
    // COLLECT-THEN-FIRE, breadth-wise: the cascade runs after the whole loop
    // above, not inside it. In a diamond — `top` depending on `left` and
    // `right`, both depending on `base` — installing `base` rebuilds `left`
    // and `right` in this wave, and `top` is then rebuilt ONCE, against two
    // already-current forwarders, instead of once per forwarder. Error
    // isolation also stays per level: a cascaded wave that throws does not
    // cost this wave its remaining siblings.
    //
    // Each rebuilt definition is passed as `justInstalled` so it is not
    // re-derived against itself, exactly as on the `updateDef` route.
    for (const entry of cascade) {
      try {
        repairProvisionalDependents(
          ce,
          entry.name,
          entry.def,
          undefined,
          scopeOfDependent(ce, entry.name, entry.def, entry.home)
        );
      } catch (error) {
        firstError ??= { error };
      }
    }
  } finally {
    // Released only now. A definition must stay guarded through the cascade of
    // its OWN repair wave: that is what cuts a mutual forward reference. With
    // `pa` and `pb` waiting on each other, repairing `pb` cascades to `pa`,
    // whose cascade comes back to `pb` — still in `REPAIRING`, so it is skipped
    // and the recursion bottoms out. Deleting per-definition inside the loop
    // (as this did before the cascade existed) would make that cycle
    // unbounded.
    for (const def of guarded) REPAIRING.delete(def);
  }
  if (firstError !== undefined) throw firstError.error;
}

/**
 * The first leaf of a destructuring parameter pattern that is not a binding
 * position, rendered for a diagnostic, or `undefined` when the pattern is
 * well formed.
 *
 * A pattern in PARAMETER position is a BINDING pattern, not a `match` pattern:
 * its leaves are names (`_` discards a position) and nested patterns. A literal
 * or an expression leaf — `((1, q)) => …` — has nothing to bind, so it is
 * rejected rather than read as a value to match against.
 */
function illFormedPatternLeaf(pattern: Expression): string | undefined {
  if (!isFunction(pattern, 'Tuple')) return undefined;
  for (const el of pattern.ops) {
    if (isFunction(el, 'Tuple')) {
      const bad = illFormedPatternLeaf(el);
      if (bad !== undefined) return bad;
      continue;
    }
    if (!isSymbol(el)) return el.toString();
  }
  return undefined;
}

/**
 * Make each PARAMETER OPERAND denote the binding the body `Block` declares for
 * it — step 5 of the binder discipline
 * (`docs/SCOPING-MODEL.md`), for the one binder
 * that is not definition-driven.
 *
 * What arrived there differed by route, exactly as it did for `Series` and
 * `Integrate` before their migration: the parse and `ce.box` routes leave the
 * parameter RAW (a symbol with no definition), while
 * `ce.function('Function', [body, ce.symbol('x')])` hands over a symbol
 * carrying the CALLER's binding — a binding that has nothing to do with this
 * literal and, for a caller-assigned `x`, holds a value.
 *
 * Afterwards the literal has exactly ONE binding for the parameter, referenced
 * from both the parameter operand and the body's occurrences. That is what
 * makes the "two live bindings at once" state (`Limit`'s migration attempt,
 * §Stages 5–8 round) detectable rather than silent: a second binder declaring
 * the parameter in ITS scope would show up here as a parameter operand that no
 * longer matches the body.
 */
function bindParameterOperands(
  ce: ComputeEngine,
  block: Expression,
  params: ReadonlyArray<Expression>
): ReadonlyArray<Expression> {
  const scope = block.localScope;
  if (!scope) return params;
  const bindLeaf = (leaf: Expression): Expression => {
    if (isFunction(leaf, 'Tuple'))
      return ce._fn('Tuple', leaf.ops.map(bindLeaf), { canonical: false });
    const name = sym(leaf);
    if (name === undefined || name === '_') return leaf;
    return ce._bindingSymbol(name, scope) ?? leaf;
  };
  const bindParam = (param: Expression): Expression => {
    // A parameter with a default value binds through the parameter inside
    // its `Optional` wrapper; the default operand is not a parameter, and
    // keeps the binding of the scope where the literal is written.
    if (isFunction(param, 'Optional')) {
      const inner = bindParam(param.op1);
      return inner === param.op1
        ? param
        : ce._fn('Optional', [inner, param.op2], { canonical: false });
    }
    // A destructuring pattern binds through its LEAVES: each is pointed at the
    // Block's own binding, the same repair the named-parameter branch below
    // makes, so `staticParameterBinding` can read a leaf's definition straight
    // off the operand.
    if (isDestructuringParameter(param)) return bindLeaf(param);
    const name = functionLiteralParameterName(param);
    if (!name) return param;
    // Inline value-def check (`isValueDef` lives in `utils.ts`, which this
    // module cannot import).
    const binding = scope.bindings.get(name);
    if (binding === undefined || !('value' in binding)) return param;
    const def = (binding as { value: BoxedValueDefinition }).value;
    // A REST parameter's name lives on the symbol INSIDE its `Spread` wrapper,
    // exactly as an annotated parameter's lives inside its `Typed` wrapper, so
    // both read and rebuild that inner operand rather than the wrapper.
    const restSym = restParameterSymbol(param);
    const site = restSym ?? (isFunction(param, 'Typed') ? param.op1 : param);
    if (
      (site as { valueDefinition?: BoxedValueDefinition }).valueDefinition ===
      def
    )
      return param;
    // Built on the Block's OWN binding rather than by name: `ce.symbol()` would
    // short-circuit to the interned constant for a parameter named after one
    // (`Pi`, `e`, `i`, ...) and hand back something that is not this
    // parameter at all.
    const bound = ce._bindingSymbol(name, scope);
    if (bound === undefined) return param;
    if (restSym !== undefined)
      return ce._fn('Spread', [bound], { canonical: false });
    if (!isFunction(param, 'Typed')) return bound;
    return ce._fn('Typed', [bound, param.op2], { canonical: false });
  };
  return params.map(bindParam);
}

/** Point every occurrence of this literal's parameter names at the binding the
 * body Block declares for them. See the call site for why an already-canonical
 * body can arrive bound elsewhere.
 *
 * EVERY parameter, named as well as anonymous. The invariant is that a
 * parameter occurrence in the body denotes THIS literal's parameter — and
 * nothing else about the body moves, because only the names this literal binds
 * are targets and only occurrences that resolve elsewhere are touched.
 *
 * This used to be restricted to the anonymous placeholders (`_`, `_1`, …)
 * produced by the shorthand/pipe desugaring, because widening it broke three
 * things. All three were the same latent defect rather than a reason to keep
 * the restriction, and are fixed: `Integrate` handed the antiderivative
 * machinery a body still bound to the literal's Block while that machinery
 * minted the integration variable in the caller's scope (`liftIntegrand`,
 * `library/calculus.ts`), and a BINDING SITE held raw by a lazy operator must
 * not be canonicalized (the raw-occurrence rule of `rebindToBindings`).
 *
 * The walk itself is `rebindToBindings` (`binders.ts`), shared with the binder
 * mechanism's post-phase: this is the same repair, for the one binder that is
 * not definition-driven. */
function rebindParameters(
  block: Expression,
  params: ReadonlyArray<Expression>
): Expression {
  const scope = block.localScope;
  if (!scope) return block;

  const names: string[] = [];
  for (const param of params) {
    for (const name of functionLiteralParameterNames(param)) {
      if (names.includes(name)) continue;
      // Inline value-def check (`isValueDef` lives in `utils.ts`, which this
      // module cannot import).
      const binding = scope.bindings.get(name);
      if (binding !== undefined && 'value' in binding) names.push(name);
    }
  }
  if (names.length === 0) return block;

  // The replacement symbols are built on the Block's OWN bindings
  // (`_bindingSymbol`), not resolved by name: `ce.symbol()` binds against the
  // current lexical scope — the enclosing one — and, for a parameter named
  // after a library constant, short-circuits to the constant even inside the
  // Block's scope. The rewrite itself still runs in that scope, so a node it
  // rebuilds canonicalizes where its operands are bound. `skipRootBinds`: the
  // Block's own bindings ARE the rebind targets, so the root must not shadow
  // them; a nested binder that re-binds one of these names owns its
  // occurrences (`shadowed`).
  const ce = block.engine;
  const targets = new Map<string, Expression>();
  for (const name of names) {
    const bound = ce._bindingSymbol(name, scope);
    if (bound !== undefined) targets.set(name, bound);
  }
  return ce._inScope(scope, () =>
    rebindToBindings(block, scope, targets, { skipRootBinds: true })
  );
}

/**
 * The full signature a `Function` literal's body-slot marker declares
 * (`["Function", ["Typed", body, "'(x: T) -> T where T'"], "x"]`, or the
 * ground `"'(x: number) -> number'"`), or `undefined` when the body slot
 * carries no such marker.
 *
 * The decomposition predicate of `functionLiteralDeclaredSignature`, read
 * BEFORE canonicalization: an UNGROUPED signature spelling is the literal's own
 * contract; a grouped one (`"'((number) -> number)'"`) is an ordinary
 * return-type ascription and never reaches the well-formedness check below.
 *
 * Deliberately narrower than `isPolytypeString`: only a single SIGNATURE is a
 * shape a literal can implement. An overload intersection with a generic arm
 * parses as a polytype too, and is left for the return-slot rejection.
 */
function bodySlotSignature(
  ce: ComputeEngine,
  body: Expression | undefined
):
  | { sig?: FunctionSignature; operand?: Expression; error?: Expression }
  | undefined {
  // Both marker shapes `functionLiteralReturnMarker` reads: the authoring form
  // `["Typed", body, sig]` in the body slot, and the CANONICAL form, where the
  // marker has moved INSIDE the Block and wraps its last statement. A
  // hand-authored canonical-form literal reaches this route too, and the reader
  // downstream (`functionLiteralDeclaredSignature`) recognizes it as the
  // contract — so it must take the same well-formedness and erasure pass.
  const marker = isFunction(body, 'Block') ? body.ops[body.nops - 1] : body;
  if (!isFunction(marker, 'Typed')) return undefined;
  const op = marker.op2;
  if (op === undefined) return undefined;
  const s = isString(op) ? op.string : sym(op);
  // `->` is a necessary condition for a signature spelling: the cheap gate that
  // keeps an ordinary `-> real` ascription off the resolver-parse path.
  if (s === undefined || !s.includes('->')) return undefined;
  if (isGroupedTypeText(s)) return undefined;
  let t: Type;
  try {
    t = parseType(s, ce._typeResolver);
  } catch (e) {
    // The text IS signature-shaped (ungrouped, with an arrow), so the failure
    // is the author's contract not parsing — not "this is not a marker".
    // Swallowing it here dropped the whole ascription silently (an Epsil
    // `function f<U>(x: U) -> tr<U, U>` typed as `(unknown) -> unknown`).
    return { error: signatureStringError(ce, s, e) };
  }
  if (typeof t === 'string' || t.kind !== 'signature') return undefined;
  // A parameter of the signature may not name the marker `missing`
  // (`declaredTypeNamesMissing()`).
  if (declaredTypeNamesMissing(t))
    return {
      error: ce.error(
        ['invalid-type-annotation', DECLARED_MISSING_MESSAGE],
        `"${s}"`
      ),
    };
  return { sig: t, operand: op };
}

/**
 * The error expression for a signature-string annotation — the E1 sugar's
 * parameter-slot string or the E2 body-slot marker — that is signature-shaped
 * but does not parse as a type.
 *
 * A structured `TypeVariableError` code (`generic-alias-arity`,
 * `variance-violation`, …) becomes the error's own code, so the real cause
 * survives; anything else the type parser rejects is reported as
 * `invalid-type-annotation` carrying the type parser's message. The code is
 * also the head of a `TypeVariableError`'s message, so it is stripped from the
 * detail rather than repeated.
 */
function signatureStringError(
  ce: ComputeEngine,
  signature: string,
  e: unknown
): Expression {
  const err = e as { code?: string; rawMessage?: string };
  let detail = err.rawMessage ?? (e instanceof Error ? e.message : String(e));
  if (err.code !== undefined && detail.startsWith(`${err.code}: `))
    detail = detail.slice(err.code.length + 2);
  return ce.error(
    [err.code ?? 'invalid-type-annotation', detail],
    `"${signature}"`
  );
}

/**
 * The E2 pre-pass (generic-literals design §2.3): validate a full-signature
 * marker in the body slot and ERASE the parameter annotations it quantifies.
 *
 * Returns `undefined` when there is no such marker (the overwhelmingly common
 * case — one `isFunction(_, 'Typed')` test), `{ error }` when the marker is not
 * well-formed, and `{ ops, generic }` with the erased operands otherwise.
 *
 * A GROUND marker (`"'(x: number) -> number'"`) takes the well-formedness half
 * only — it quantifies nothing, so there is nothing to erase. It is checked
 * because it is a contract of record just as a quantified one is (ruled
 * 2026-08-04): an arity mismatch means the author wrote a signature that the
 * literal cannot implement, and the "returns a function" reading has its own
 * spelling (a GROUPED marker), which never reaches here.
 *
 * **Well-formedness.** The marker is the literal's contract of record, not a
 * cosmetic mirror, so its shape is checked: a signature with exactly as many
 * arguments as the literal has parameters, whose optional arguments are the
 * parameters with a default value (each with the literal's default), and
 * with a variadic argument only for a rest parameter. **Positional mapping is authoritative** — the marker's argument
 * NAMES are cosmetic, the literal's operand names stay the names of record
 * (the `docs/EFFECTS-MODEL.md` mirror rule).
 *
 * **Erasure (G1).** A parameter whose marker argument type mentions a
 * quantified variable loses its own `Typed` annotation and becomes a bare
 * symbol, so the body canonicalizes exactly as an untyped literal's does and no
 * type variable ever becomes the type of a symbol (the §4.2 ground invariant).
 * A GROUND annotation at a ground marker position is kept and enforced as
 * usual; a ground annotation at a quantified position is dropped in favour of
 * the marker (single source of truth) — but only once it is known to COVER the
 * variable's bound (§2.4 rule 4). The declaration boundary cannot answer that
 * question on this route: it reads the literal's parameters AFTER erasure, by
 * which point a contradicting annotation no longer exists.
 */
function eraseGenericParameters(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>
):
  | { ops?: ReadonlyArray<Expression>; error?: Expression; generic?: boolean }
  | undefined {
  const marker = bodySlotSignature(ce, ops[0]);
  if (marker === undefined) return undefined;

  const params = ops.slice(1);
  if (marker.error !== undefined)
    return { error: ce._fn('Function', [marker.error, ...params]) };
  const sig = marker.sig!;

  const args = sig.args ?? [];
  // A REST parameter is the one variadic shape a marker may state, and it MUST
  // state it: the marker mirrors the parameter list, so `(a, ...rest) => …`
  // carries `(…, any*) -> R` with one positional entry per FIXED parameter and
  // the variadic tail standing for the rest parameter. Without this the Epsil
  // lowering of `function h<T>(x: T, ...rest) -> T { … }` either had to spell
  // the rest parameter as an ordinary slot — which typed `h` as fixed-arity
  // binary, so `h(1)` reported a missing argument and `h(1, 2, 3)` an
  // unexpected one — or be rejected here as ill-formed.
  const restAt = restParameterIndex(params);
  const fixedCount = restAt < 0 ? params.length : restAt;
  const markerIsVariadic = sig.variadicArg !== undefined;
  const literalIsVariadic = restAt >= 0;
  // An optional argument of the marker states a parameter with a default
  // value (`(x: T, k: number = 2) -> T where T`). Each one must have a
  // default, and the parameter of the literal at the same position must be
  // an `Optional` parameter with the same default. A required argument of
  // the marker matches a parameter without a default, or a parameter with
  // a default: the Epsil lowering of `function g<T>(x: T, k: number = 2)`
  // writes the marker `(x: T, k: number) -> T where T`, and the default is
  // carried into the marker below. A literal default that is not a valid
  // default value is reported by the parameter check that follows this
  // pre-pass.
  const optArgs = sig.optArgs ?? [];
  const slots = [...args, ...optArgs];
  const optionalMatches = optArgs.every((a, j) => {
    const op = optionalParameterDefault(params[args.length + j]);
    if (a.default === undefined || op === undefined) return false;
    const d = markerPassDefault(op);
    return d === undefined || sameParameterDefault(d, a.default);
  });
  if (
    !optionalMatches ||
    requiredParameterCount(params) > args.length ||
    markerIsVariadic !== literalIsVariadic ||
    slots.length !== fixedCount
  )
    return {
      error: ce._fn('Function', [
        ce.error(INVALID_SIGNATURE_MARKER_MESSAGE, typeToString(sig)),
        ...params,
      ]),
    };

  // The defaults of the marker are those of its optional arguments; a
  // default in a deeper position (a parameter of a parameter's type) is
  // refused as in any other signature that is not top-level.
  if (
    slots.some((a) => typeHasParameterDefault(a.type)) ||
    (sig.variadicArg !== undefined &&
      typeHasParameterDefault(sig.variadicArg.type)) ||
    typeHasParameterDefault(sig.result) ||
    (sig.typeParams?.some((p) => typeHasParameterDefault(p.bound)) ?? false)
  )
    return {
      error: ce._fn('Function', [
        ce.error(NESTED_DEFAULT_MESSAGE, typeToString(sig)),
        ...params,
      ]),
    };

  // The marker becomes the declared signature of the literal, so a
  // parameter with a default that the marker lists as a required argument
  // would lose its default. Such an argument becomes an optional argument
  // with the literal's default, and the marker is written again.
  //
  // The new marker keeps the argument names of the marker, as a marker that
  // already lists its defaults does, so a named call uses the same names
  // whichever way the marker is written. One exception: a default can be a
  // symbol, and a signature refuses a default that names one of its own
  // arguments (`(a: T, d: number = d)` does not parse). An argument whose
  // name is the name of a symbol default takes the name of the literal's
  // parameter at its position (`(a: T, d: number) -> T` on the parameters
  // `x, Optional(k, d)` becomes `(a: T, k: number = d) -> T`). When that
  // parameter has no single name (a wildcard `_` or `_1`, or a destructuring
  // pattern), or when its name is already the name of another argument, the
  // argument has no name.
  //
  // When a default is a symbol that names a parameter of the literal
  // (`x, Optional(k, x)`), the marker is not written again: the parameter
  // check that follows reports that default as the only error.
  let body = ops[0];
  let markerOperand: Expression | undefined;
  const required = requiredParameterCount(params);
  const literalNames = new Set<string>();
  for (const p of params)
    for (const name of functionLiteralParameterNames(
      optionalParameterTarget(p)
    ))
      literalNames.add(name);
  if (required < args.length) {
    const promoted = args.slice(required).map((a, i) => {
      const op = optionalParameterDefault(params[required + i]);
      const d = op === undefined ? undefined : markerPassDefault(op);
      return d === undefined ? undefined : { ...a, default: d };
    });
    const symbolDefaults = new Set<string>();
    for (const a of [...promoted, ...optArgs])
      if (a?.default?.kind === 'symbol') symbolDefaults.add(a.default.name);
    if (
      promoted.every((a) => a !== undefined) &&
      ![...symbolDefaults].some((name) => literalNames.has(name))
    ) {
      const keptNames = new Set<string>();
      for (const a of [...slots, sig.variadicArg])
        if (a?.name !== undefined && !symbolDefaults.has(a.name))
          keptNames.add(a.name);
      const named = (a: NamedElement, i: number): NamedElement => {
        if (a.name === undefined || !symbolDefaults.has(a.name)) return a;
        const name = functionLiteralParameterName(params[i]);
        if (name === '' || /^_\d*$/.test(name) || keptNames.has(name))
          return { type: a.type, ...(a.default ? { default: a.default } : {}) };
        return { ...a, name };
      };
      const newSig: FunctionSignature = {
        ...sig,
        args: args.slice(0, required).map((a, i) => named(a, i)),
        optArgs: [...promoted, ...optArgs].map((a, i) =>
          named(a, required + i)
        ),
      };
      if (sig.variadicArg !== undefined)
        newSig.variadicArg = named(sig.variadicArg, restAt);
      if (required === 0) delete newSig.args;
      markerOperand = ce.string(typeToString(newSig));
    }
  }

  // The marker is well-formed: the `Typed` operator accepts the defaults of
  // its parameters, in both marker shapes (the canonical shape is a `Typed`
  // statement inside the body Block, canonicalized with that Block). The
  // operand that is marked is always a new string written into the body: an
  // operand that the author holds could be used again in another `Typed`,
  // which must still refuse a default.
  if (markerOperand === undefined && marker.operand !== undefined) {
    const text = isString(marker.operand)
      ? marker.operand.string
      : sym(marker.operand);
    if (text !== undefined && text.includes('='))
      markerOperand = ce.string(text);
  }
  if (markerOperand !== undefined) {
    body = replaceSignatureMarkerOperand(ce, body, markerOperand);
    markSignatureMarkerOperand(markerOperand);
  }

  // A GROUND marker quantifies nothing: the well-formedness check above is the
  // whole pre-pass for it, and every parameter annotation stays.
  if (!isPolymorphicType(sig))
    return { ops: body === ops[0] ? ops : [body, ...params], generic: false };

  // §2.4 rule 4 (CONTRAVARIANT): a ground annotation at a quantified position
  // must accept every instantiation the clause admits — `bound <: annotation`.
  // `substituteDeclaredBounds` leaves an UNBOUNDED variable alone; its
  // kind-level reading is `any`, so supply that bound explicitly (as
  // `acceptsGenericFunctionLiteral` does at the declaration boundary).
  const bounded = (sig.typeParams ?? []).map((p) =>
    p.bound === undefined ? { ...p, bound: 'any' as Type } : p
  );

  let erased = false;
  let coverageError: Expression | undefined;
  const newParams = params.map((p, i) => {
    // A parameter with a default value is read inside its `Optional`
    // wrapper. Its default is checked against the parameter's type, and the
    // type of a quantified position is known only at a call, so a default
    // there is refused.
    if (
      coverageError === undefined &&
      isOptionalParameter(p) &&
      slots[i] !== undefined &&
      mentionsQuantifiedVariable(slots[i].type, sig)
    ) {
      coverageError = ce.error(GENERIC_DEFAULT_MESSAGE, p.toString());
      return p;
    }
    if (!isFunction(p, 'Typed') || !isSymbol(p.op1)) return p;
    if (!mentionsQuantifiedVariable(slots[i].type, sig)) return p;
    const annotation = functionLiteralParameterType(p);
    if (
      coverageError === undefined &&
      annotation !== undefined &&
      !isSubtype(substituteDeclaredBounds(bounded, slots[i].type), annotation)
    )
      coverageError = ce.error(
        GENERIC_ANNOTATION_COVERAGE_MESSAGE,
        p.toString()
      );
    erased = true;
    return p.op1;
  });
  if (coverageError !== undefined)
    return { error: ce._fn('Function', [coverageError, ...params]) };
  return erased || body !== ops[0]
    ? { ops: [body, ...newParams], generic: true }
    : { ops, generic: true };
}

/** `body`, the body operand of a function literal with a full-signature
 * marker, with the type operand of the marker replaced by `operand`. The
 * marker is `["Typed", body, signature]` in the body slot, or, in the
 * canonical shape, the `Typed` last statement of the body Block. */
function replaceSignatureMarkerOperand(
  ce: ComputeEngine,
  body: Expression,
  operand: Expression
): Expression {
  if (isFunction(body, 'Block')) {
    const last = body.ops[body.nops - 1];
    if (!isFunction(last, 'Typed')) return body;
    return ce._fn(
      'Block',
      [
        ...body.ops.slice(0, -1),
        ce._fn('Typed', [last.op1, operand], { canonical: false }),
      ],
      { canonical: false }
    );
  }
  if (!isFunction(body, 'Typed')) return body;
  return ce._fn('Typed', [body.op1, operand], { canonical: false });
}

/** The default value of a literal parameter's default operand `op`, read
 * before the parameters are canonicalized. Only the shapes that must be
 * canonical to be read are canonicalized: a `["List"]` or a `["Dictionary"]`
 * with no operand (a raw `["Dictionary"]` is an empty dictionary only once it
 * is canonical), a `Negate` of a number and a `Delimiter` around a number.
 * Every other operand is read as written. A compound operand is not a valid
 * default, and the parameter check refuses it; to canonicalize it here
 * would declare its symbols in the enclosing scope, also when the marker is
 * refused. */
function markerPassDefault(op: Expression): ParameterDefault | undefined {
  const canonicalize =
    ((isFunction(op, 'List') || isFunction(op, 'Dictionary')) &&
      op.nops === 0) ||
    (isFunction(op, 'Negate') && op.nops === 1 && isNumber(op.op1)) ||
    (isFunction(op, 'Delimiter') && op.nops >= 1 && isNumber(op.op1));
  return literalParameterDefault(canonicalize ? op.canonical : op);
}

/** True when two parameter default values are the same value. */
function sameParameterDefault(
  a: ParameterDefault,
  b: ParameterDefault
): boolean {
  if (a.kind === 'value')
    return b.kind === 'value' && Object.is(a.value, b.value);
  if (a.kind === 'symbol') return b.kind === 'symbol' && a.name === b.name;
  return a.kind === b.kind;
}

/** Desugar a signature-string `Function` parameter (typed-literals design
 * §3.2 sugar) into structural operands `{ ops: [body, ...params] }`, or
 * `undefined` when the string is not a fully-named, non-variadic signature
 * type whose optional arguments all have a default value, or `{ error }`
 * when it is signature-shaped but does not parse. An argument with a default
 * (`k: number = 2`) becomes `["Optional", ["Typed", k, "number"], 2]`. An
 * `unknown`/`any` argument or result type stays unannotated; an explicit
 * `Typed` body ascription is kept over the signature's result type.
 *
 * The `typeToString` round-trips below re-serialize a type that was just
 * resolved, which DISCARDS the resolution of a user-declared type name (a
 * `TypeReference` serializes to its bare name) — the hazard the
 * operator-definition signature had (`boxed-operator-definition.ts`,
 * "assembled as a Type OBJECT, never as a string that is re-parsed"). It is
 * safe HERE only because the text goes straight back into
 * `canonicalFunctionLiteralArguments`, which parses it again with the
 * resolver and records the resolution against the operand node
 * (`RESOLVED_TYPE_OPERANDS`, `function-literal.ts`) while the name is still in
 * the type registry. Type names are not lexically scoped: the registry belongs
 * to the engine, and only a rollback of the registry removes a name (the Epsil
 * static pre-pass, a failed sum-type declaration). Do not move this serialization to a place that can run after
 * such a rollback. */
function desugarSignatureString(
  ce: ComputeEngine,
  body: Expression,
  signature: string
): { ops?: Expression[]; error?: Expression } | undefined {
  let type: Type;
  try {
    type = parseType(signature);
  } catch {
    // The signature may name a user-declared type; retry with the engine's
    // resolver (second, so the memo-cached parse carries the common case).
    try {
      type = parseType(signature, ce._typeResolver);
    } catch (e) {
      // A string that is not signature-shaped is not a signature the author
      // failed to write — it falls through to the parameter-name reading and
      // its `expected-a-symbol` error. One that IS (an ungrouped arrow, the
      // same gate `bodySlotSignature` uses) reports why it did not parse,
      // instead of blaming the operand for not being a symbol.
      if (!signature.includes('->') || isGroupedTypeText(signature))
        return undefined;
      return { error: signatureStringError(ce, signature, e) };
    }
  }
  if (typeof type === 'string' || type.kind !== 'signature') return undefined;
  // An optional argument with a default value (`k: number = 2`) desugars to
  // a parameter with a default, `["Optional", param, default]`. An optional
  // argument without a default (`k: number?`) and a variadic argument have
  // no parameter spelling in a literal.
  if (type.variadicArg) return undefined;
  if (type.optArgs?.some((a) => a.default === undefined)) return undefined;
  const args = [...(type.args ?? []), ...(type.optArgs ?? [])];
  if (args.some((a) => !a.name)) return undefined;

  const isWide = (t: Type): boolean => t === 'unknown' || t === 'any';
  // A `where` clause (E1, generic-literals design §2.3): an argument whose
  // type mentions a quantified variable produces a BARE parameter symbol —
  // erasure (G1) — since the marker ascribed onto the body states its type and
  // no type variable may become the type of a symbol. Ground-typed arguments
  // keep their `Typed` marker and are enforced as usual.
  const generic = isPolymorphicType(type);
  // The parameter symbols are built RAW: a canonical `ce.symbol(name)` reads a
  // library constant of that spelling, and `ce.symbol('i')` is not a symbol at
  // all but the imaginary-unit number literal — which the parameter reading
  // below then rejects with `expected-a-symbol`. A raw symbol is also what
  // every other parameter-building route produces (`anonymousParameters`,
  // `annotateFunctionLiteralParams`), so the desugared operands are
  // indistinguishable from the hand-written structural spelling.
  const paramSymbol = (name: string): Expression =>
    ce.symbol(name, { canonical: false });
  const params = args.map((a) => {
    const param =
      isWide(a.type) || (generic && mentionsQuantifiedVariable(a.type, type))
        ? paramSymbol(a.name!)
        : ce._fn(
            'Typed',
            [paramSymbol(a.name!), ce.string(typeToString(a.type))],
            { canonical: false }
          );
    return a.default === undefined
      ? param
      : ce._fn('Optional', [param, boxParameterDefault(ce, a.default)], {
          canonical: false,
        });
  });
  let newBody = body;
  if (generic) {
    // A `where` clause is the ONLY record the literal keeps of its type
    // variables, so the full signature is ascribed unconditionally — unlike the
    // result-type cases below, a body-slot ascription does not get to win here
    // and silently drop the clause (it stays, as an inner statement ascription).
    newBody = ce._fn('Typed', [body, ce.string(typeToString(type))], {
      canonical: false,
    });
  } else if (isFunction(body, 'Typed')) {
    // The body's own ascription wins over the signature string's result.
  } else if (signatureEffects(type) !== undefined) {
    // Arrow-level effects are PRESERVED onto the constructed signature
    // (`docs/EFFECTS-MODEL.md`, "Epsil surface"), so the FULL signature is
    // ascribed — regardless of `isWide(type.result)`, since the wide-result
    // convention keeps the return inferred downstream.
    newBody = ce._fn('Typed', [body, ce.string(typeToString(type))], {
      canonical: false,
    });
  } else if (!isWide(type.result))
    // `returnTypeText`, not `typeToString`: a result that is itself a signature
    // has to stay GROUPED here, or the marker it builds re-reads as the
    // literal's OWN contract (`functionLiteralDeclaredSignature`) instead of
    // the return type the signature string declared.
    newBody = ce._fn('Typed', [body, ce.string(returnTypeText(type.result))], {
      canonical: false,
    });
  return { ops: [newBody, ...params] };
}

/** Normalize a `Typed` type operand (a string literal or a type-name symbol)
 * to a string literal, so a type-name symbol such as `real` is not
 * auto-declared as a variable. */
function normalizeTypeOperand(
  ce: ComputeEngine,
  t: Expression | undefined
): Expression {
  if (!t) return ce.string('unknown');
  // An operand that is already a string is returned as the SAME node: the
  // inference mark of a parameter annotation is keyed on it (see
  // `isInferredTypedParameter`, `boxed-expression/inferred-annotations.ts`).
  // The node keeps the metadata it carries
  // (source offsets, verbatim LaTeX); nothing reads a type operand's
  // metadata, so this changes no behavior.
  if (isString(t)) return t;
  const s = sym(t);
  return s !== undefined ? ce.string(s) : t;
}

/** Rebuild an annotated parameter `["Typed", symbol, type]` with its type
 * operand normalized to a string literal. */
function normalizeTypedParameter(
  ce: ComputeEngine,
  param: Expression
): Expression {
  if (!isFunction(param)) return param;
  return ce._fn('Typed', [param.op1, normalizeTypeOperand(ce, param.op2)], {
    canonical: false,
  });
}

/**
 * The declared type to bind an annotated parameter's fresh-scope binding with
 * (`inferred: false`), or `undefined` to fall back to the historical inferred
 * binding (`{ value, inferred: true }`).
 *
 * Only strict mode attaches a declared type — that is where step 4/step 3
 * validation runs, so a provably-wrong value has already been rejected. The
 * value is nonetheless bound under the declared type only when it is provably
 * compatible: an `unknown`/`any`/symbolic value passes validation as "not
 * provably wrong", but binding it under a narrower fixed type would trip the
 * value-definition covariant check (`value.type.matches(declaredType)`), which
 * throws. Falling back to inferred there keeps the historical symbolic
 * beta-reduction (e.g. an undeclared-symbol argument).
 */
function typedBinding(
  ce: ComputeEngine,
  param: Expression,
  value: Expression
): Type | undefined {
  if (!ce.strict) return undefined;
  const t = functionLiteralParameterType(param);
  if (t === undefined) return undefined;
  return value.type.matches(t) ? t : undefined;
}

/**
 * Canonicalize `expr` with the shorthand-lambda placeholders it mentions
 * (`_`, `_1`…`_9`) bound to FRESH, valueless locals. A placeholder inside a
 * nested `Function` literal is that literal's own parameter and is not
 * pre-declared here (`freeAnonymousSlots`).
 *
 * `Pipe` is lazy, so it canonicalizes its held right operand in the CALLER's
 * scope — before `canonicalFunctionLiteral` wraps `Map(f, _1)` into
 * `(_1) ↦ Map(f, _1)`. A placeholder is a parameter of that literal and must
 * shadow a same-named global, in particular its VALUE: with a global
 * `_1 := 7`, `Map`'s canonical handler saw a non-collection source operand,
 * declined (`checkCollectionOperand`), and `[1,2,3] |> Map(k ↦ k², _1)`
 * returned an unevaluated `Map`.
 *
 * The placeholders are PRE-DECLARED in a throwaway scope rather than left to
 * auto-declaration. `_pushShadowedParameters` alone does not shadow here:
 * its untyped branch deliberately reuses an existing non-constant binding
 * (that IS the valued global), and its typed branch auto-declares into the
 * current lexical scope — the very scope the global lives in. The throwaway
 * scope is `noAutoDeclare`, so a genuine free variable in the operand still
 * auto-declares in the caller's scope exactly as before; only the
 * placeholders are intercepted.
 *
 */
export function canonicalWithFreshPlaceholders(expr: Expression): Expression {
  // When `expr` is itself a literal (a pipe stage), its own slot parameters
  // are pre-declared too, so the body of the literal is read, not the
  // literal: `freeAnonymousSlots` does not report the names a literal binds.
  const names = [
    ...freeAnonymousSlots(
      isFunction(expr, 'Function') && expr.nops > 0 ? expr.ops[0] : expr
    ),
  ];
  if (names.length === 0) return expr.canonical;
  const ce = expr.engine;
  const scope: Scope = {
    parent: ce.context.lexicalScope,
    bindings: new Map(),
    noAutoDeclare: true,
  };
  for (const name of names)
    ce._declareSymbolValue(name, { type: 'unknown', inferred: true }, scope);
  return ce._inScope(scope, () => expr.canonical);
}

/**
 * How an application treats an argument whose value is — or embeds — an
 * `Error`. See `docs/LANGUAGE-MODEL.md`
 *
 * - `'bubble'` (the default): error is the absorbing element of strict
 *   evaluation, so the application evaluates to that error value and the body
 *   never runs.
 * - `'bind'`: the error is an ordinary value, bound to the parameter. Reserved
 *   for the non-strict OBSERVERS — the `Match` case guards and bodies, which
 *   have already decided on the error subject and are the rescue construct.
 */
export type ErrorArgPolicy = 'bubble' | 'bind';

/** The first argument that is — or embeds — an `Error`, as its error value.
 * A plain loop: this runs on every application. */
function firstErrorArg(
  args: ReadonlyArray<Expression>
): Expression | undefined {
  for (const a of args) {
    const err = errorValue(a);
    if (err !== undefined) return err;
  }
  return undefined;
}

/**
 * A function-valued expression that is not itself a `Function` literal
 * DENOTES a function (e.g. `Derivative(f, n)`, `InverseFunction(f)`, a
 * qualified protocol member `Comparable.compare` — which is
 * `Field(Comparable, "compare")`); it cannot be beta-reduced and must reach
 * its function value through evaluation. Letting the shorthand-lambda path
 * treat such an expression as a lambda BODY would substitute the argument
 * for its free symbol (`Apply(InverseFunction(f), 2)` → `InverseFunction(2)`;
 * `Map(Comparable.compare, xs)` → each element read as the base of a `Field`
 * access), or, for `Derivative(f, n)` whose `derivative()` representation is
 * the self-applied lambda `Apply(Derivative(f, n), _)`, re-evaluate the inner
 * `Derivative`, regenerating the same lambda and recursing forever (stack
 * overflow). Wildcards (`_`, `_1`…`_9`) mark a genuine shorthand body, so an
 * expression containing one is NOT gated here and still beta-reduces. (The
 * `lazy` attribute was considered as the gate and rejected: laziness governs
 * whether operands are evaluated, not whether the expression is
 * function-valued.)
 *
 * Consulted by `apply()` (stay symbolic, as `Apply(fn, args)`) and by
 * `canonicalFunctionLiteral` (return the expression unchanged instead of
 * running the shorthand path), so the application tier and the
 * canonicalization tier agree on which expressions are function VALUES.
 */
function denotesFunction(e: Expression | undefined | null): boolean {
  return (
    isFunction(e) &&
    e.operator !== 'Function' &&
    e.type.matches('function') &&
    freeAnonymousSlots(e).size === 0
  );
}

/**
 * A function application whose result type is UNKNOWN is held as a callee:
 * `g(f)` for an undeclared `g`, `xs[1]` for a list of unknown elements,
 * `Filter(IsEven)` with its collection operand missing. The engine cannot
 * tell whether such an expression is a function, so it does not read it as
 * a shorthand function literal over its free symbols. Doing so answered
 * `Apply(g(f), x)` with `g(x)` — the lambda `f ↦ g(f)` applied to `x` — and
 * the answer changed once `g` got a value, because `g(f)` is then a
 * (curried) function and `Apply(g(f), x)` is `g(f, x)`. Instead the
 * application stays `Apply(g(f), x)` and evaluates once the callee has a
 * value (GitHub issue #426).
 *
 * The shorthand literal keeps every callee of a KNOWN non-function type:
 * `Apply(x + 1, 2)` is `3` because `x + 1` is a `number`, and `Apply(3, 5)`
 * is `3`. A body with a wildcard (`_`, `_1`…) is a shorthand literal
 * whatever its type. A `Block` is never a callee: it is the body of a
 * literal.
 *
 * Consulted where {@link denotesFunction} is: by `apply()` and by
 * `canonicalFunctionLiteral` (on the canonical body, since a raw operand of
 * a lazy operator reads `unknown` whatever it is).
 */
function isHeldCallee(e: Expression | undefined | null): boolean {
  return (
    isFunction(e) &&
    e.operator !== 'Function' &&
    e.operator !== 'Block' &&
    e.type.isUnknown &&
    freeAnonymousSlots(e).size === 0
  );
}

/**
 * A `Field(⟨symbol⟩, ⟨string⟩)` expression whose base names a protocol with
 * that FUNCTION member — the qualified protocol member `Comparable.compare`,
 * which evaluates to the protocol-dispatching function literal.
 *
 * This is {@link denotesFunction}'s syntactic sibling, needed because a lazy
 * operator's held operand arrives RAW (`Map` holds its callback), where every
 * type still reads `unknown` and the type-based predicate cannot answer.
 * Recognition is registry-keyed, never scope-keyed — matching what `Field`'s
 * own evaluation does (`protocolOfSymbol`, engine-protocols.ts), including
 * its guard: a base symbol that HOLDS a value is that value, and `Field`
 * reads the value's field, not the protocol. (Checked by name via `lookup`,
 * not `.canonical`, so an undeclared protocol name is not auto-declared as a
 * side effect of asking.)
 */
function isQualifiedProtocolMember(e: Expression): boolean {
  if (!isFunction(e, 'Field')) return false;
  const base = sym(e.op1);
  const member = isString(e.op2) ? e.op2.string : undefined;
  if (base === undefined || member === undefined) return false;
  const ce = e.engine;
  if (ce._protocolRegistry[base]?.members[member]?.kind !== 'function')
    return false;
  const def = lookup(base, ce.context.lexicalScope);
  if (def !== undefined && 'value' in def && def.value.value !== undefined)
    return false;
  return true;
}

/**
 * The operators whose application always gives a function value
 * (`InverseFunction(f)` is the inverse of `f`, `Derivative(f, n)` its
 * `n`-th derivative). This is {@link denotesFunction}'s syntactic sibling for
 * a RAW operand, such as the held callback of a lazy operator, whose type
 * reads `unknown` and cannot answer the type-based predicate. Without it,
 * `Map(InverseFunction(Sin), xs)` was read as a shorthand literal with no
 * parameter and refused. (CE-129)
 */
function isRawFunctionValuedApplication(e: Expression): boolean {
  return (
    isFunction(e) &&
    (e.operator === 'InverseFunction' ||
      e.operator === 'Derivative' ||
      e.operator === 'Composition') &&
    freeAnonymousSlots(e).size === 0
  );
}

/**
 * Options accepted by {@link apply} and the lambda {@link makeLambda} builds.
 *
 * `holdArguments` is how a `hold` function (an Epsil `hold f(e) = …`, i.e. a
 * user-defined function whose operator definition is `lazy`) reaches its
 * body: the arguments are bound to the parameters AS WRITTEN — canonical and
 * bound in the caller's scope, but not evaluated — instead of being evaluated
 * first. Reading such a parameter in the body then evaluates the argument
 * expression there (call-by-name); a structural operator such as `Head` sees
 * the expression itself. The flag is set by the multi-clause selector for a
 * `hold` definition (`selectAndApply`, multi-clause.ts) and by nothing else:
 * an ordinary application always evaluates its arguments first.
 */
export type ApplyOptions = Partial<EvaluateOptions> & {
  holdArguments?: boolean;
  /**
   * The application is one element of the map of a `broadcastable<T>` or a
   * point-list parameter (`ApplyWhole`). An argument with no value does not
   * make it wait (`docs/ERROR-MODEL.md`, "A symbolic argument whose type does
   * not decide"): a length error of the mapped arguments needs the map to run.
   */
  mapElement?: boolean;
  /**
   * Under `.N()`, the written arguments behind the (approximated) `args`,
   * one per argument position, `undefined` where there is none to record
   * (`exactArgumentSources`). The activation of a plain parameter records
   * its entry (`exact-argument-source.ts`), and a jump in the body re-reads
   * the exact value from it when the float is near the jump.
   */
  exactSources?: ReadonlyArray<Expression | undefined>;
  /**
   * The names of the literal's BOUND-VARIABLE parameters (an Epsil `hold
   * mySum(body, bind i, n)`; `ClauseAttributes.bind` in `multi-clause.ts`).
   * Each must be applied to a SYMBOL — the variable the caller names — and is
   * SUBSTITUTED into the body rather than bound to a value: `Sum(body, i, 1,
   * n)` becomes `Sum(body, k, 1, n)` for `mySum(k^2, k, 3)`, so the binder
   * inside the body re-canonicalizes with the caller's symbol as its index
   * and its rebinding of that symbol in the other (held) arguments is the
   * binder's own. Only meaningful with `holdArguments`.
   */
  bindParameters?: readonly string[];
  /**
   * Run the body statements with `evaluateStatementsAsync()`, so that the
   * application returns a `Promise` that yields between time slices and
   * honors the abort signal. Set by every asynchronous application route,
   * together with the `_effects`, `_contextStack` and `_precisionWindow` of
   * that evaluation: the call of a named function (`boxed-function.ts`), the
   * `evaluateAsync` handlers of `Apply`, `ApplyWhole` and `Pipe`
   * (`library/core.ts`), and the multi-clause selector
   * (`selectAndApplyAwaiting`, `multi-clause.ts`). With the flag, `apply()`
   * answers a `Promise` for a function literal, a composition, a symbol
   * callee, and a callee that `makeLambda` applies through an `Apply` call
   * (an expression that `canonicalFunctionLiteral` does not change into a
   * literal). The application of a
   * function literal declines to await (it is synchronous) when an argument
   * has a free symbol. When another application of the same literal with
   * awaited statements is suspended and this one is not in its call frame,
   * this one starts when that one ends (`blockingAsyncApplication()`).
   */
  awaitStatements?: boolean;
  /**
   * The breadcrumb of the call, for the error a surplus argument produces:
   * `operator` is the head the caller applied (the name a literal is held
   * by, or `Apply`), and `firstArgumentIndex` the 1-based operand position
   * of the first argument at that head (`1` for `h(1, 2, 3)`, `2` for
   * `Apply(h, 1, 2, 3)`, whose first operand is the callee). The literal
   * does not know the head it is applied through, so the caller supplies
   * it; without it the error carries no frame.
   */
  arityFrame?: { operator: string; firstArgumentIndex: number };
};

/**
 * The written arguments to record on the activations of a call under
 * `.N()` (`ApplyOptions.exactSources`), one per operand of `ops`, or
 * `undefined` at a position with nothing to record.
 *
 * A recorded argument is evaluated again, exactly, from inside the
 * function, when a jump in the body needs its exact value
 * (`exactRealValueOf`, `boxed-expression/constraint-subject.ts`). So it
 * must be pure (the re-read repeats no effect) and must resolve the same
 * from inside the function, where a name can be a parameter of the callee:
 * - an exact number literal is itself;
 * - a symbol is read now, in the caller's frame: the source its own
 *   activation records (a parameter of the caller passed on, `f2 := x ↦
 *   f(x) + 1`), its exact value when it holds one (a global `y`), the
 *   expression it holds when that expression has the properties of the
 *   next rule, or the symbol itself for a constant such as `Pi`;
 * - an expression with no free symbol (`(25! − 1)/24!`, `Sum(1/k, k, 1,
 *   n)` with a literal `n`) is itself when it is transitively pure;
 * - anything else is not recorded: the body then reads the float.
 * Nothing is evaluated here: the cost of an exact evaluation is paid only
 * by a re-read near a jump.
 *
 * The application of a function literal with a one-statement body also
 * reads these sources: when one of them differs from its approximated
 * argument, it puts the sources in the body in place of the parameters
 * and approximates the result (`applyWrittenArguments` in `makeLambda`).
 */
export function exactArgumentSources(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>
): ReadonlyArray<Expression | undefined> {
  return ops.map((op) => {
    if (isNumber(op)) return isExactRealLiteral(op) ? op : undefined;
    if (isSymbol(op)) {
      const def = ce.lookupDefinition(op.symbol);
      if (def === undefined || !('value' in def)) return undefined;
      const recorded = exactArgumentSourceOf(
        def.value,
        ce.context.lexicalScope
      );
      if (recorded !== undefined) return recorded;
      const value = ce._getSymbolValue(op.symbol);
      if (value !== undefined && isExactRealLiteral(value)) return value;
      // A value that is an expression is recorded as an expression written
      // in place of the symbol would be (the last rule below).
      if (
        value !== undefined &&
        isFunction(value) &&
        !containsFreeSymbol(value) &&
        isTransitivelyPure(value)
      )
        return value;
      // A constant whose value is not an exact literal (`Pi`, whose stored
      // value is a float held until `.N()`) is its own exact source: it is
      // pure, and it means the same from inside the function.
      return def.value.isConstant ? op : undefined;
    }
    if (!isFunction(op) || containsFreeSymbol(op)) return undefined;
    return isTransitivelyPure(op) ? op : undefined;
  });
}

/**
 * True when the approximated argument `arg` is the written argument
 * `source` itself. Two number literals must also be both exact or both
 * inexact: `isSame()` is true for an exact rational and the float of the
 * same value.
 */
function isSameWritten(source: Expression, arg: Expression): boolean {
  if (isNumber(source) && isNumber(arg) && source.isExact !== arg.isExact)
    return false;
  return source.isSame(arg);
}

/**
 * True when a second approximation of the written argument `source` costs
 * little: `source` is a number or a symbol, or it applies library
 * operators only, and none of them is a scoped operator (a `Sum`, a
 * `Product`, a loop). The caller of an application under `.N()` has
 * approximated the argument already, so an application that puts `source`
 * in the body (`applyWrittenArguments` in `makeLambda`) approximates it a
 * second time: with `f := x ↦ Sin(x)`, `f(Sum(1/k, k, 1, 10000)).N()` took
 * two times as long as `Sin(Sum(1/k, k, 1, 10000)).N()`. An application
 * with an argument for which this is false takes the ordinary route, which
 * binds the approximation and re-reads the exact argument only near a jump
 * (`exact-argument-source.ts`). The same test tells whether the body of a
 * literal is short enough to evaluate synchronously on the asynchronous
 * route.
 */
function isCheapWrittenArgument(source: Expression): boolean {
  if (!isFunction(source)) return true;
  if (source.isScoped) return false;
  const def = source.operatorDefinition;
  if (def === undefined || def.isUserFunctionDefinition) return false;
  return source.ops.every(isCheapWrittenArgument);
}

/**
 * The application `steps[0](steps[1](… steps[n-1](...args)))` of a
 * composition, as an unevaluated canonical expression. The last step takes
 * all the arguments, every other step the single result of the one after it
 * (Wolfram's `Composition[f, g, h][x, y]` is `f[g[h[x, y]]]`). A symbol step
 * is called by name, so a library head or a user function dispatches as in a
 * direct call; any other step (a function literal, a held callee) is applied
 * with `Apply`. Shared by `apply()` and the compilers, which lower the nested
 * call and so agree with the interpreter by construction.
 *
 * The call of a symbol step is boxed against the definition that the step
 * was boxed with (`callableBindingInContext`, `callableApplication`), as
 * the application of a symbol is in `makeLambda`. A definition of the same
 * name in the scope where the composition is applied (a block local `f`)
 * does not replace the function that the step names.
 */
export function composedApplication(
  ce: ComputeEngine,
  steps: ReadonlyArray<Expression>,
  args: ReadonlyArray<Expression>
): Expression {
  let value: ReadonlyArray<Expression> = args;
  let result: Expression | undefined;
  for (let i = steps.length - 1; i >= 0; i--) {
    const step = steps[i];
    const name = sym(step);
    if (name !== undefined) {
      result = callableApplication(
        ce,
        name,
        [...value],
        callableBindingInContext(ce, name, ownCallableBinding(step), step),
        step
      );
    } else result = ce.function('Apply', [step, ...value]);
    value = [result];
  }
  return result ?? ce.function('Identity', [...args]);
}

/** The definition a symbol `step` was boxed with, in the form that
 * `callableBindingInContext` reads, or `undefined` when it has none. */
function ownCallableBinding(step: Expression): BoxedDefinition | undefined {
  return step.valueDefinition !== undefined
    ? { value: step.valueDefinition }
    : step.operatorDefinition !== undefined
      ? { operator: step.operatorDefinition }
      : undefined;
}

/**
 * True when each symbol step of the composition `fn` names, in the current
 * scope, the definition that `composedApplication` calls: the definition the
 * step was boxed with (`callableBindingInContext`). A compiler resolves a
 * call by its name in the scope of the compilation, so when a definition of
 * the same name hides the one the step names (a composition made with a
 * global `f`, compiled inside a scope that declares another `f`), the
 * compiled call would not call the function that the interpreter calls.
 * The compilers decline such a composition.
 */
export function compositionStepsResolveHere(fn: Expression): boolean {
  if (!isFunction(fn)) return true;
  const ce = fn.engine;
  return fn.ops.every((step) => {
    const name = sym(step);
    if (name === undefined) return true;
    return (
      callableBindingInContext(ce, name, ownCallableBinding(step), step) ===
      ce.lookupDefinition(name)
    );
  });
}

/**
 * The function literal `(_x1, …, _xn) => f(g(h(_x1, …, _xn)))` of the
 * composition `fn` = `Composition(f, g, h)`, or `undefined`. The compilers
 * lower a composition that is an operand, not a call head (the callback of
 * `Map(Composition(Sin, Exp), xs)`), as this literal, which each target
 * compiles like any other callback literal.
 *
 * `n` is the parameter count of the last step, read from its signature. When
 * that count is not fixed (an optional or a variadic parameter, an overload
 * set, a step with no signature, as for `Add`), there is no literal: a guessed
 * count could call the steps with other arguments than the interpreter does.
 * The parameter names are chosen so that no symbol of a step is captured.
 *
 * There is no literal either for a composition with a free anonymous slot
 * (`Composition(Sin, _)`, the shorthand of a function of `_`, see `apply()`),
 * or for one whose symbol step names a definition that a definition of the
 * same name hides in the current scope (`compositionStepsResolveHere`).
 *
 * With `canonical` false, the literal is returned non-canonical, so that the
 * caller can put it in place of the composition in an operand of another
 * expression and canonicalize that expression: the literal is then
 * canonicalized in the context of its consumer, as a literal written there
 * is (the parameter of a callback of `Map` gets the element type).
 */
export function compositionLiteral(
  fn: Expression,
  canonical = true
): Expression | undefined {
  if (!isFunction(fn, 'Composition') || fn.nops === 0) return undefined;
  if (freeAnonymousSlots(fn).size > 0 || !compositionStepsResolveHere(fn))
    return undefined;
  // The callback compilers can hand over a step that is not canonical, and
  // the type of a symbol that is not canonical is `unknown`.
  const arms = signatureArms(fn.ops[fn.nops - 1].canonical.type.type);
  if (arms?.length !== 1) return undefined;
  const [arm] = arms;
  if (arm.optArgs?.length || arm.variadicArg || arm.typeParams?.length)
    return undefined;
  const count = arm.args?.length ?? 0;
  const ce = fn.engine;
  const used = new Set(fn.symbols);
  let prefix = '_x';
  while ([...used].some((s) => s.startsWith(prefix))) prefix = `_${prefix}`;
  // The literal is built non-canonical and canonicalized as a whole, so its
  // parameters are bound in the scope of the literal. A canonical parameter
  // symbol made here would be bound in the enclosing scope instead: it would
  // take the type of a declaration of the same name there (`_x: string`),
  // or declare the name there when it has none.
  const params = Array.from({ length: count }, (_, i) =>
    ce.symbol(count === 1 ? prefix : `${prefix}${i + 1}`, { canonical: false })
  );
  let value: ReadonlyArray<Expression> = params;
  for (let i = fn.nops - 1; i >= 0; i--) {
    const step = fn.ops[i];
    const name = sym(step);
    value = [
      name !== undefined
        ? ce._fn(name, [...value], { canonical: false })
        : ce._fn('Apply', [step, ...value], { canonical: false }),
    ];
  }
  const literal = ce._fn('Function', [value[0], ...params], {
    canonical: false,
  });
  return canonical ? literal.canonical : literal;
}

/**
 * The value of `call`, an application that `apply()` makes on the
 * asynchronous route (`ApplyOptions.awaitStatements`), as a `Promise`, as
 * for a function literal on that route. The call is evaluated with
 * `evaluateAsync`, so an operator that has only an `evaluateAsync` handler
 * is evaluated, with the abort signal, the effect handlers, the
 * evaluation-context stack and the precision window of the enclosing
 * evaluation, as each statement of a body is (`evaluateStatementsAsync`).
 * The `Promise` is typed as an `Expression` because `apply()` and the
 * function that `makeLambda` returns answer one on that route only.
 */
function awaitedApplication(
  call: Expression,
  options: ApplyOptions
): Expression {
  return call.evaluateAsync({
    signal: options.signal,
    numericApproximation: options.numericApproximation,
    _effects: options._effects,
    _contextStack: options._contextStack,
    _precisionWindow: options._precisionWindow,
  }) as unknown as Expression;
}

/**
 * Apply arguments to an expression which is either:
 * - a `["Function"]` expression
 * - the symbol for a function, e.g. `Sin`.
 *
 * When the literal DECLINES the application — it is not unrolled because it
 * re-entered itself with a symbolic argument (`SymbolicRecursion`), or a
 * strict engine was handed an invalid collection argument — the answer is
 * `declined` when the caller supplies one (the application as the caller
 * wrote it, `R(3, x, y)`, for a symbol bound to a literal), and otherwise an
 * inert `Apply` of the literal. A body that evaluates to an error value does
 * NOT decline: that error is the answer (`bodyResultValue`).
 *
 * An application that waits because the type of an argument does not decide an
 * annotation of the literal (`isUndecidedLiteralApplication`) has the same
 * answer: `declined` when the caller supplies one, otherwise the inert `Apply`.
 */
export function apply(
  fn: Expression,
  args: ReadonlyArray<Expression>,
  options?: ApplyOptions,
  errorPolicy: ErrorArgPolicy = 'bubble',
  declined?: Expression
): Expression {
  // Rung 2: applying something that IS an error bubbles it (`err(x)`), as does
  // applying a function literal to an error argument.
  //
  // A bare SYMBOL callee is deliberately excluded here: it is dispatched below
  // through `ce.function(sym, args).evaluate()`, where the direct-call route
  // decides — bubbling for a user function, freezing for a built-in operator
  // (`err |> Sin` must stay `Sin(err)`, exactly like `Sin(err)`; operators are
  // rung 3). That is what keeps `x |> f` ≡ `f(x)` for every callee.
  if (errorPolicy === 'bubble' && !isSymbol(fn)) {
    const err = errorValue(fn) ?? firstErrorArg(args);
    if (err !== undefined) return err;
  }

  // `Composition(f, g)` applied is the nested call `f(g(…args))`, each step
  // through its own head (`composedApplication`). Under `.N()` the caller
  // has approximated the arguments already, and the approximation can lose
  // the exact value that a step reads (the float of `(25! − 1)/24!` is the
  // integer 25, so its `Floor` is 25, not 24). So the nested call takes the
  // written argument (`ApplyOptions.exactSources`) at each position where
  // one is recorded, and the approximated argument elsewhere. A recorded
  // source is pure (`exactArgumentSources`), so evaluating it again repeats
  // no effect. The application of a function literal uses a costly source
  // only through the activation of its parameter, which re-reads it near a
  // jump of the body; a composition has no activation, so it always uses
  // the source, at the cost of a second approximation of that argument.
  //
  // A composition with a free anonymous slot (`Composition(Sin, _)`) is not
  // a composition value: as for any other expression with a free slot, it
  // is the shorthand of a function of `_` (`_ ↦ Composition(Sin, _)`), and
  // it is applied below through `makeLambda`.
  if (isFunction(fn, 'Composition') && freeAnonymousSlots(fn).size === 0) {
    const sources = options?.exactSources;
    const callArgs =
      options?.numericApproximation === true &&
      sources !== undefined &&
      sources.length === args.length
        ? args.map((arg, i) => sources[i] ?? arg)
        : args;
    const call = composedApplication(fn.engine, fn.ops, callArgs);
    // On the asynchronous route (`awaitStatements`), the nested call is
    // awaited (`awaitedApplication`), so a step that has only an
    // `evaluateAsync` handler is evaluated.
    if (options?.awaitStatements) return awaitedApplication(call, options);
    return call.evaluate(
      options?.numericApproximation ? { numericApproximation: true } : undefined
    );
  }

  if (denotesFunction(fn) || isHeldCallee(fn))
    return fn.engine._fn('Apply', [fn, ...args]);

  if (isFunction(fn, 'Apply') && denotesFunction(fn.op1))
    return fn.engine._fn('Apply', [fn.op1, ...args]);

  const result = makeLambda(fn, errorPolicy)?.(args, options);
  // An application with awaited statements (`awaitStatements`) answers a
  // `Promise`, which gives `undefined` when the application declines.
  if (isThenable(result))
    return (result as unknown as Promise<Expression | undefined>).then(
      (value) =>
        (isUndecidedLiteralApplication(value, fn) ? declined : undefined) ??
        value ??
        declined ??
        fn.engine.withEvaluationContext(options, () =>
          fn.engine.function('Apply', [fn, ...args])
        )
    ) as unknown as Expression;
  if (result)
    return isUndecidedLiteralApplication(result, fn)
      ? (declined ?? result)
      : result;
  return declined ?? fn.engine.function('Apply', [fn, ...args]);
}

/**
 * The arguments `args` of a call of a function literal whose parameter
 * operands are `params`, with the default operand of each parameter with a
 * default value (`["Optional", k, 2]`) that the call leaves out appended.
 *
 * Only a full call is completed: one whose arguments cover every parameter
 * before the first parameter with a default. A call with fewer arguments is
 * a partial application, and is returned unchanged. An argument that the
 * call supplies is kept, also when it is absent (`Missing`, `NaN`): a
 * default fills only a parameter that the call leaves out.
 */
export function literalArgumentsWithDefaults(
  params: ReadonlyArray<Expression>,
  args: ReadonlyArray<Expression>
): ReadonlyArray<Expression> {
  if (args.length < requiredParameterCount(params)) return args;
  if (args.length >= params.length) return args;
  const added: Expression[] = [];
  for (let i = args.length; i < params.length; i++) {
    const d = optionalParameterDefault(params[i]);
    if (d === undefined) break;
    added.push(d);
  }
  return added.length === 0 ? args : [...args, ...added];
}

/**
 * Evaluate a sequence of statements, handling Return/Break/Continue.
 *
 * `lastStatementOptions` is either nothing (an exact evaluation) or a
 * numeric-approximation request, and it applies to the LAST statement only.
 * The value of the last statement is the value of the sequence, so it can be
 * computed numerically: a jump in it (`Floor(x)`, `x < 25`) then reads the
 * exact argument behind a parameter bound to a float, as at the top level
 * (`exact-argument-source.ts`). The statements before it always run
 * exactly: an intermediate value that a later statement reads (`a := √2;
 * a^2`) must not be rounded on the way. The request is forwarded by the
 * application of a user function (`resultStatementRequest`, `makeLambda`)
 * and by a `Block` evaluated with a numeric request (`evaluateBlock`,
 * `library/control-structures.ts`).
 *
 * Used by both:
 * - `evaluateBlock` in control-structures.ts (Block evaluation handler)
 * - `makeLambda` below (iterates body.ops directly instead of calling
 *   body.evaluate(), because body is a Block whose _localScope has param
 *   bindings from canonicalization — declared with type 'unknown' but no
 *   value. If body.evaluate() were called, Block would push its _localScope
 *   as the eval context, and lookup() would find those stale bindings
 *   before reaching the freshScope where actual param values live.)
 *
 * With `program`, the statements belong to an explicit Program. Each
 * statement is its own top-level
 * evaluation. Each statement after the first then starts a new top-level
 * evaluation (`beginTopLevelEvaluation`, `evaluation-epoch.ts`), so that a
 * result of a call whose head had no value, stored by an earlier statement,
 * resolves its head again when a later statement reads it
 * (`EVALUATED_UNRESOLVED_CALLS`, `boxed-function.ts`). A statement can
 * start an `evaluateAsync()` that it does not await; that evaluation runs
 * its later parts after this loop has moved on, and keeps the number it
 * started with, which its context stack carries (`beginAsyncEvaluation`,
 * `evaluation-epoch.ts`).
 */
export function evaluateStatements(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  lastStatementOptions?: { numericApproximation: true },
  program = false
): Expression {
  noteStatementListScope(ce);
  const run: StatementRun = { scope: ce.context.lexicalScope };
  let result: Expression = ce.Nothing;
  const last = ops.length - 1;
  for (let i = 0; i <= last; i++) {
    const op = ops[i];
    if (program && i > 0) beginTopLevelEvaluation(ce);
    // Debugger pause point (see `common/debug-hook.ts`): only statements
    // that originated from source (carrying `sourceOffsets`) fire — the
    // hook may BLOCK. One comparison per statement when no debugger is
    // attached.
    if (debugStatementHook !== undefined && op.sourceOffsets !== undefined)
      invokeDebugHook(() => debugStatementHook!(op));
    // Evaluate the statement. `Break`/`Continue` are inert registered
    // operators and `Return` is unregistered, so a literal control-flow
    // statement evaluates to itself with its operand evaluated.
    let failure: unknown;
    let reportingFrame = ce._deadlineFrame;
    const savedRoute = ce._epsilDeclarationRoute;
    if (program) ce._epsilDeclarationRoute = ['DeclareType', 'DeclareSumType', 'DeclareProtocol', 'DeclareConformance', 'DefineFunction'].includes(op.operator);
    try {
      if (program) checkDeadline(ce._deadlineFrame);
      const evaluate = () => ce._boxingState.asProgramStatement(() => op.evaluate(i === last ? lastStatementOptions : undefined));
      result = program && ce._epsilStatementTimeLimitMs !== undefined
        ? ce.withTimeLimit({ ms: ce._epsilStatementTimeLimitMs, label: 'epsil:statement' }, evaluate)
        : program ? evaluate() : op.evaluate(i === last ? lastStatementOptions : undefined);
    } catch (error) {
      if (!program || isDebugHookFailure(error)) throw error;
      failure = error;
      reportingFrame = ce._deadlineFrame;
      result = programFailureValue(ce, error);
    } finally { ce._epsilDeclarationRoute = savedRoute; }
    try {
    // Before the hooks below, so that they receive the error of a function
    // that the statement made break a contract.
    if (result.operator !== 'Error')
      result = afterFunctionAssignment(ce, run, op) ?? result;
    // Post-statement debugger hook (break-on-error-value); same guard shape
    // as the pre-statement hook above.
    if (
      debugStatementResultHook !== undefined &&
      op.sourceOffsets !== undefined
    )
      invokeDebugHook(() => debugStatementResultHook!(op, result));
    // The Epsil interpreter's hook, with the same guard: it reports a
    // nested statement whose value is discarded and holds an error.
    if (
      ce._epsilStatementResultHook !== undefined &&
      (program || op.sourceOffsets !== undefined)
    )
      ce._epsilStatementResultHook(op, result, program ? i : undefined, failure);
    } finally {
      if (program && isTimeoutCancellation(failure)) ce._deadlineFrame = reportingFrame;
    }
    // Short-circuit on a control-flow result — whether the statement was a
    // literal `Break`/`Continue`/`Return` or *evaluated to* one (e.g.
    // `If(cond, Break)`). The control-flow expression itself is the block's
    // value, so it propagates through nested blocks up to the enclosing
    // `Loop` (which consumes `Break`/`Continue`) or function application
    // (which unwraps `Return` — see `unwrapReturn`).
    //
    // An `Error` VALUE short-circuits the same way: a non-final statement's
    // value is nobody's, so a refusal that is the statement's value (a
    // mistyped write, a `const` reassignment, a readonly protocol-property
    // set) would otherwise VANISH and execution would continue past the
    // fault — `executeEpsil` already surfaces exactly these as
    // `runtime-error` diagnostics for top-level statements; inside a
    // function body or block the error value propagating out IS the
    // diagnostic channel. Top-level `Error` operator only: a still-symbolic
    // statement carrying an embedded error operand is an ordinary inert
    // value, not a fault.
    const h = result.operator;
    if (h === 'Return' || h === 'Break' || h === 'Continue' || (!program && h === 'Error') || (program && isTimeoutCancellation(failure)))
      break;
  }
  return statementListValue(ce, ops, result);
}

/** Convert ordinary Program statement throws to values. Cancellation stops
 * the sequence; a spent deadline is hidden while its diagnostics are built. */
function programFailureValue(ce: ComputeEngine, error: unknown): Expression {
  const message = error instanceof Error ? error.message : String(error);
  if (error instanceof CancellationError) {
    if (isTimeoutCancellation(error)) ce._deadlineFrame = undefined;
    const cause = ['timeout', 'step-budget', 'iteration-limit-exceeded', 'recursion-depth-exceeded'].includes(String(error.cause)) ? String(error.cause) : budgetCauseOf(error);
    return ce._fn('Error', [ce.string(message), ce.string(cause)]);
  }
  if (error instanceof Error && error.name === 'ConstantAssignmentError') {
    const name = (error as Error & { constantName: string }).constantName;
    return ce.error(['constant-assignment', name]);
  }
  return ce._fn('Error', [ce.string(message)]);
}

/** A run of a list of statements: the scope where its statements run, and
 * the earlier statements of the run that assigned a function literal to a
 * symbol, with the symbol. */
type StatementRun = {
  scope: Scope;
  assigned?: { name: string; literal: Expression }[];
};

/**
 * Statement `op` of the run `run` of a list of statements has run. When
 * `op` assigns a function literal to a symbol `h`, the signature of each
 * function that an earlier statement of the run assigned, and whose literal
 * applies `h`, is derived again, and `op` is added to `run.assigned`.
 * Returns the error value of the statement when a function derived again
 * breaks a contract, else `undefined`.
 *
 * The signature of a user function is derived when its `Assign` runs. The
 * derivation reads the operator definition of each function that the body
 * calls with a parameter of the function (`wholeCollectionParameterType()`,
 * `boxed-expression/effects-inference.ts`): when the slot of the callee
 * takes a whole collection, the slot of the parameter takes one too. In
 * `Block(Assign(q, a ↦ h(a)), Assign(h, t ↦ Count(t)), q([1, 2]))`, `h` has
 * no operator definition when `Assign(q, …)` runs, so the slot of `a` is a
 * scalar slot, and `q([1, 2])` applied `q` to each element: `Count(1)` and
 * `Count(2)` are errors. Derived again after `Assign(h, …)`, the slot of
 * `a` takes the list whole, and the value is `2`, as with the two `Assign`
 * in the other order, and as with `ce.assign()`, whose definitions are
 * derived again by `repairProvisionalDependents()`.
 *
 * A function whose signature changed is a callee that changed too, so the
 * functions that call it are derived again (`r` in `r(x) = q(x)`), in
 * passes: each pass derives again the functions that apply a name whose
 * signature changed in the pass before. A function can be derived in more
 * than one pass, when two of its callees change in different passes. The
 * number of passes is at most the number of entries plus one, so a cycle of
 * calls whose signatures do not settle ends.
 *
 * Only a function with an inferred signature is derived again. A function
 * with a declared signature does not depend on its callees. A literal with
 * an annotated parameter has a signature derived from the type of the
 * literal when it is assigned (`_derivedSignature`), and it is not derived
 * again here: `Block(Assign(q, (a, n: number) ↦ h(a) + n), Assign(h, t ↦
 * Count(t)), q([1, 2], 1))` still applies `q` to each element. An `Assign`
 * that is not a statement of the list (inside an `If` or a nested `Block`)
 * is not seen either.
 *
 * When the new definition of a function breaks a contract (a callee with a
 * `scope` effect makes the body write outside a function that does not
 * declare it), the function keeps its previous definition, and the error
 * is the value of the statement, as when the `Assign` of the function runs
 * after the `Assign` of its callee.
 */
function afterFunctionAssignment(
  ce: ComputeEngine,
  run: StatementRun,
  op: Expression
): Expression | undefined {
  if (!isFunction(op, 'Assign') || op.nops !== 2) return undefined;
  const target = op.op1;
  const literal = op.op2;
  if (!isSymbol(target) || !isFunction(literal, 'Function')) return undefined;
  const assigned = run.assigned;
  const name = target.symbol;
  let error: Expression | undefined;
  if (
    assigned !== undefined &&
    assigned.some((e) => e.name !== name && appliedNames(e.literal).has(name))
  )
    error = ce._inScope(run.scope, () =>
      deriveCallerSignatures(ce, assigned, name)
    );
  (run.assigned ??= []).push({ name, literal });
  return error;
}

/**
 * Derive again the signature of each function of `assigned` whose literal
 * applies `callee`, then of each function whose literal applies a function
 * whose signature changed, in passes (see `afterFunctionAssignment()`).
 * Called in the scope of the run, where each name resolves to the
 * definition that the statements of the run installed. Returns the error
 * value of the first contract that a new definition breaks, else
 * `undefined`.
 */
function deriveCallerSignatures(
  ce: ComputeEngine,
  assigned: ReadonlyArray<{ name: string; literal: Expression }>,
  callee: string
): Expression | undefined {
  let firstError: Expression | undefined;
  let changed = new Set([callee]);
  for (let pass = 0; changed.size > 0 && pass <= assigned.length; pass++) {
    const next = new Set<string>();
    for (const entry of assigned) {
      const heads = appliedNames(entry.literal);
      let applies = false;
      for (const name of changed)
        if (name !== entry.name && heads.has(name)) applies = true;
      if (!applies) continue;
      const def = ce.lookupDefinition(entry.name);
      if (def === undefined || !isOperatorDef(def)) continue;
      const opDef = def.operator;
      const literal = opDef._lambdaLiteral;
      if (!opDef.inferredSignature || literal === undefined) continue;
      const before = opDef.signature.toString();
      // `_update()` writes the signature and the literal before it checks
      // the effects contract, so a throw leaves the definition partly
      // updated. The snapshot restores the fields that an update with only
      // `evaluate` can write (`_rederivationSnapshot()`), not the types of
      // the captured bindings that `_update()` records for the check of a
      // later call (`noteDefinitionCapturedTypes()`): those are the types
      // at the time of the failed update.
      const snapshot = opDef._rederivationSnapshot();
      try {
        installRebuiltLiteral(ce, opDef, literal);
      } catch (e) {
        opDef._restoreRederivationSnapshot(snapshot);
        if (isEffectContractError(e))
          firstError ??= effectContractErrorValue(ce, e);
        else if (isTypeCompatibilityError(e))
          firstError ??= typeCompatibilityErrorValue(ce, e);
        else throw e;
        continue;
      }
      ce._noteStateEvent({
        kind: 'binding-repair',
        ...(isScratchBinding(ce, opDef) ? { scratch: true } : {}),
      });
      if (opDef.signature.toString() !== before) next.add(entry.name);
    }
    changed = next;
  }
  return firstError;
}

/** The names of the operators that `literal` applies, computed once per
 * literal. The canonical literal of a statement is the same object on each
 * run of the statement. */
const APPLIED_NAMES = new WeakMap<Expression, ReadonlySet<string>>();

function appliedNames(literal: Expression): ReadonlySet<string> {
  let names = APPLIED_NAMES.get(literal);
  if (names !== undefined) return names;
  const found = new Set<string>();
  // An expression can share a subexpression in more than one place: each
  // node is visited once.
  const seen = new Set<Expression>();
  const visit = (expr: Expression): void => {
    if (!isFunction(expr) || seen.has(expr)) return;
    seen.add(expr);
    found.add(expr.operator);
    for (const x of expr.ops) visit(x);
  };
  visit(literal);
  names = found;
  APPLIED_NAMES.set(literal, names);
  return names;
}

/**
 * The value of a list of statements `ops` whose last evaluated statement
 * gave `result`. An assignment or a declaration is a statement with no
 * value, so a list whose last statement is an `Assign` or a `Declare` (also
 * under the return-type annotation `Typed` of a function body) has the
 * value `Nothing`: `Block(Assign(b, 2))` is `Nothing`. A control-flow value
 * (`Return`, `Break`, `Continue`) and an `Error` are kept.
 */
function statementListValue(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  result: Expression
): Expression {
  const h = result.operator;
  if (h === 'Return' || h === 'Break' || h === 'Continue' || h === 'Error')
    return result;
  const lastOp = ops[ops.length - 1];
  if (lastOp === undefined) return result;
  const last = isFunction(lastOp, 'Typed') ? lastOp.op1 : lastOp;
  return last.operator === 'Assign' || last.operator === 'Declare'
    ? ce.Nothing
    : result;
}

/** The scopes in which a list of statements has run
 * (`noteStatementListScope()`). */
const STATEMENT_LIST_SCOPES = new WeakSet<Scope>();

/**
 * True when a list of statements (a `Block`, or the body of a function
 * application) has run in `scope`, through `evaluateStatements()` or
 * `evaluateStatementsAsync()`. The top level of the Epsil runner is not such
 * a scope: its statement loop does not call these functions.
 */
function isStatementListScope(scope: Scope): boolean {
  return STATEMENT_LIST_SCOPES.has(scope);
}

/** Record the current lexical scope as one where a list of statements runs
 * (`isStatementListScope()`). */
function noteStatementListScope(ce: ComputeEngine): void {
  STATEMENT_LIST_SCOPES.add(ce.context.lexicalScope);
}

/**
 * The asynchronous twin of `evaluateStatements`: each statement is awaited
 * with `evaluateAsync`, so a statement holding an asynchronous-only
 * application (an operator with only an `evaluateAsync` handler) is
 * evaluated instead of staying inert. Same debugger hooks, same
 * short-circuit on a control-flow or `Error` value. A numeric-approximation
 * request reaches a statement on this route exactly when it reaches it on
 * the synchronous route: `numericApproximation` applies to the last
 * statement only (see `evaluateStatements`).
 *
 * With `program`, each statement after the first starts a new top-level
 * evaluation, as on the synchronous route: the statement runs on a copy of
 * `contextStack` that carries a new number (`beginAsyncStatement`,
 * `evaluation-epoch.ts`). The number of an asynchronous evaluation is
 * carried by its context stack, so the new number does not change the
 * number of another asynchronous evaluation that runs at the same time, nor
 * the number of an evaluation that an earlier statement started and did
 * not await.
 */
export async function evaluateStatementsAsync(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  signal?: AbortSignal,
  effects?: EffectHandlers,
  contextStack?: EvaluateOptions['_contextStack'],
  numericApproximation?: true,
  precisionWindow?: EvaluateOptions['_precisionWindow'],
  program = false
): Promise<Expression> {
  // Before the first `await`, so the current lexical scope is still the
  // scope of these statements.
  noteStatementListScope(ce);
  // The scope is read before the first `await`: after an `await`, the
  // current scope can be the scope of another evaluation.
  const run: StatementRun = { scope: ce.context.lexicalScope };
  let result: Expression = ce.Nothing;
  const last = ops.length - 1;
  for (let i = 0; i <= last; i++) {
    const op = ops[i];
    const stack =
      program && i > 0 && contextStack !== undefined
        ? beginAsyncStatement(contextStack)
        : contextStack;
    if (debugStatementHook !== undefined && op.sourceOffsets !== undefined)
      invokeDebugHook(() => debugStatementHook!(op));
    // `effects` is the host capability registry the enclosing asynchronous
    // evaluation captured, and `contextStack` its evaluation-context stack
    // (which holds the block scope); each statement must run with the same
    // ones (for a statement of a program, a copy of the stack with the same
    // frames and a new number).
    let failure: unknown;
    let reportingFrame = ce._deadlineFrame;
    const savedRoute = ce._epsilDeclarationRoute;
    if (program) ce._epsilDeclarationRoute = ['DeclareType', 'DeclareSumType', 'DeclareProtocol', 'DeclareConformance', 'DefineFunction'].includes(op.operator);
    try {
      if (program) checkDeadline(ce._deadlineFrame);
      if (signal?.aborted) throw new CancellationError({ cause: signal.reason });
      const evaluate = () => op.evaluateAsync({
        signal,
        numericApproximation: i === last ? numericApproximation : undefined,
        _effects: effects, _contextStack: stack, _precisionWindow: precisionWindow,
      });
      result = await (program && ce._epsilStatementTimeLimitMs !== undefined
        ? (() => { let pending!: Promise<Expression>; ce.withTimeLimit({ ms: ce._epsilStatementTimeLimitMs!, label: 'epsil:statement' }, () => { pending = evaluate(); }); return pending; })()
        : evaluate());
    } catch (error) {
      if (!program || signal?.aborted || isDebugHookFailure(error)) throw error;
      failure = error;
      reportingFrame = ce._deadlineFrame;
      result = programFailureValue(ce, error);
    } finally { ce._epsilDeclarationRoute = savedRoute; }
    try {
    // Before the hooks, as on the synchronous route.
    if (result.operator !== 'Error')
      result = afterFunctionAssignment(ce, run, op) ?? result;
    if (
      debugStatementResultHook !== undefined &&
      op.sourceOffsets !== undefined
    )
      invokeDebugHook(() => debugStatementResultHook!(op, result));
    if (
      ce._epsilStatementResultHook !== undefined &&
      (program || op.sourceOffsets !== undefined)
    )
      ce._epsilStatementResultHook(op, result, program ? i : undefined, failure);
    } finally {
      if (program && isTimeoutCancellation(failure)) ce._deadlineFrame = reportingFrame;
    }
    const h = result.operator;
    if (h === 'Return' || h === 'Break' || h === 'Continue' || (!program && h === 'Error') || (program && isTimeoutCancellation(failure)))
      break;
  }
  return statementListValue(ce, ops, result);
}

/**
 * Unwrap a `["Return", value]` expression to its value at a function
 * application boundary. `evaluateStatements` propagates `Return` wrapped so
 * that it can escape nested blocks and loops; the function boundary is where
 * it is consumed.
 */
function unwrapReturn(ce: ComputeEngine, expr: Expression): Expression {
  if (expr.operator === 'Return' && isFunction(expr))
    return expr.ops.length > 0 ? expr.op1 : ce.Nothing;
  return expr;
}

/**
 * Make the call frame `frame` an activation of `bodyScope`, the scope of the
 * body of the literal that it applies: the frame holds the binding of each
 * parameter and of each local of the body (its static definition), and the
 * value of each in this call. A parameter has the value of its argument
 * (`parameters`, with the value of each), a local starts with no value, and
 * the `Declare` statement of the local writes its value there.
 */
function holdBodyLocals(
  frame: Scope,
  bodyScope: Scope,
  parameters: ReadonlyMap<BoxedValueDefinition, Expression> = new Map()
): void {
  const values = new Map<object, unknown>(parameters);
  for (const [name, binding] of bodyScope.bindings) {
    if (!isValueDefinitionHalf(binding)) continue;
    const def = binding.value as BoxedValueDefinition;
    if (def._blockLocal !== true || def._programVariable) continue;
    frame.bindings.set(name, binding);
    values.set(def, undefined);
  }
  registerCallFrame(frame, bodyScope, values);
}

/**
 * Bind a parameter in a call frame's `freshScope`. When the literal has a
 * static binding for the parameter (the binding of its body scope), the
 * frame holds that definition and `parameters` gets its value for this call
 * (`holdBodyLocals()`, `docs/SCOPING-MODEL.md`): two calls in progress
 * share the definition and keep their values in their own activations.
 * Otherwise the frame declares a binding of its own with the value.
 *
 * The static binding is read from the PARAMETER OPERAND, a live reference to
 * the binding of the body scope, not from `bodyScope.bindings`.
 *
 * Only strict mode declares with the declared type (`inferred: false`); see
 * `typedBinding` for why an `unknown`/`any`/symbolic value still falls back to
 * the historical inferred binding.
 */
function declareParameterActivation(
  ce: ComputeEngine,
  name: string,
  param: Expression,
  value: Expression,
  freshScope: Scope,
  bodyScope: Scope | undefined,
  parameters: Map<BoxedValueDefinition, Expression>
): void {
  // The frame holds the static definition of the parameter, and its value
  // in this call (`holdBodyLocals()`).
  const staticDef = staticParameterBinding(param, name, bodyScope);
  if (staticDef !== undefined) {
    parameters.set(staticDef, value);
    freshScope.bindings.set(name, { value: staticDef });
    return;
  }
  const pType = typedBinding(ce, param, value);
  // A parameter binding does not refuse an argument that holds a failed
  // element (`[1, Error(…)]` at a parameter declared `list<number>`): the
  // body reads the failed element as a value. Only a declared variable
  // refuses it (`withoutFailedElementCheck`). An argument can be a closure
  // that writes outside itself, so the binding is marked as a local.
  if (pType !== undefined)
    withoutFailedElementCheck(() =>
      ce.declare(
        name,
        markLocalBinding({ value, type: pType, inferred: false }),
        freshScope
      )
    );
  else
    ce.declare(name, markLocalBinding({ value, inferred: true }), freshScope);
}

/** True when `binding` is a definition with a value half (`isValueDef`
 * lives in `utils.ts`, which this module cannot import). */
function isValueDefinitionHalf(binding: object): binding is { value: object } {
  return (
    'value' in binding &&
    (binding as { value?: unknown }).value !== undefined &&
    typeof (binding as { value?: unknown }).value === 'object'
  );
}

/** One name a call frame binds for one parameter. */
type ParameterBinding = {
  name: string;
  /**
   * The node that carries the name's declared type and its static binding: the
   * parameter operand itself for a plain (or `Typed`) parameter, and the
   * pattern's leaf SYMBOL for a destructured position. `bindParameterOperands`
   * points both at the body Block's own binding, which is what lets
   * `staticParameterBinding` read the definition straight off the node.
   */
  site: Expression;
  value: Expression;
  /**
   * The position of the parameter in the literal's parameter list, for a
   * plain (not destructuring) parameter. The `site` of a parameter with a
   * default value is the node inside its `Optional` wrapper, so the
   * position cannot be found again by searching the list for `site`.
   */
  index?: number;
};

/**
 * Expand a call's (parameter, argument) pairs into the name-level bindings its
 * frame installs, destructuring each `((p, q))` pattern parameter against its
 * argument.
 *
 * Returns the `Error` value instead when a pattern does not match its
 * argument's shape. That is the SAME error `let (p, q) = v` produces for the
 * same mismatch — both routes go through `collectTuplePattern`, and neither has
 * a mismatch-specific error of its own.
 */
function parameterBindings(
  params: ReadonlyArray<Expression>,
  args: ReadonlyArray<Expression>
): { leaves: ParameterBinding[]; error?: undefined } | { error: Expression } {
  const leaves: ParameterBinding[] = [];
  for (let i = 0; i < args.length && i < params.length; i++) {
    const param = params[i];
    if (!isDestructuringParameter(param)) {
      const name = functionLiteralParameterName(param);
      // A REST parameter's site is the symbol inside its `Spread` wrapper:
      // that node carries the binding the literal's body declares for the
      // name, which is what `staticParameterBinding` reads off it. A
      // parameter with a default value is read inside its `Optional`
      // wrapper.
      const site = restParameterSymbol(param) ?? optionalParameterTarget(param);
      if (name) leaves.push({ name, site, value: args[i], index: i });
      continue;
    }
    const pairs: [name: string, value: Expression][] = [];
    const err = collectTuplePattern(param, args[i], pairs);
    if (err) return { error: err };
    const sites = patternLeafSites(param);
    for (const [name, value] of pairs)
      leaves.push({ name, site: sites.get(name) ?? param, value });
  }
  return { leaves };
}

/** Each name a destructuring pattern binds, mapped to the leaf symbol NODE
 * that binds it. */
function patternLeafSites(pattern: Expression): Map<string, Expression> {
  const sites = new Map<string, Expression>();
  const walk = (p: Expression): void => {
    if (isFunction(p, 'Tuple')) {
      for (const el of p.ops) walk(el);
      return;
    }
    const n = sym(p);
    if (n !== undefined && n !== '_' && !sites.has(n)) sites.set(n, p);
  };
  walk(pattern);
  return sites;
}

/** The literal's OWN binding for a parameter: the operand's, falling back to
 * the body scope's for a literal whose operand was never bound to it (a
 * hand-built `Function` node that skipped `bindParameterOperands`). */
function staticParameterBinding(
  param: Expression,
  name: string,
  bodyScope: Scope | undefined
): BoxedValueDefinition | undefined {
  // A parameter with a default value is read inside its `Optional` wrapper.
  param = optionalParameterTarget(param);
  const site =
    restParameterSymbol(param) ??
    (isFunction(param, 'Typed') ? param.op1 : param);
  const def = (site as { valueDefinition?: BoxedValueDefinition })
    .valueDefinition;
  if (def !== undefined) return def;
  const binding = bodyScope?.bindings.get(name);
  return binding !== undefined && 'value' in binding
    ? binding.value
    : undefined;
}

/**
 * If `expr` is a bare symbol bound to a user-defined function literal (an
 * operator definition created by `helper(x) = …`), return the underlying
 * `Function` literal so the function can escape its defining scope as a
 * first-class value. Otherwise return `expr`.
 *
 * Must be called while the defining call frame is still pushed, so the
 * operator definition is reachable via `lookupDefinition`.
 */
export function resolveEscapingLambda(
  ce: ComputeEngine,
  expr: Expression
): Expression {
  if (!isSymbol(expr)) return expr;
  const def = ce.lookupDefinition(expr.symbol);
  if (def && 'operator' in def) {
    const literal = (def.operator as { _lambdaLiteral?: Expression })
      ._lambdaLiteral;
    if (literal !== undefined) return literal;
  }
  return expr;
}

/**
 * The value `value` that an `Assign` is about to store, with each symbol that
 * reads a VARIABLE OF THE RUN — a parameter of a call being evaluated, or a
 * local of a block being evaluated — replaced with the value that variable
 * holds now.
 *
 * A plain value is copied at the assignment. An evaluated value can still
 * name such a variable: a held operand (`If(x > y, x, 0)` with `y` free
 * evaluates to `If(y < 3, x, 0)`, its condition read with `x = 3` and its
 * branches held), a `Hold(x)`. When the variable is assigned again before
 * the stored value is read, the stored value read the NEW value: with
 * `r := If(x > y, x, 0); x := 100; r` inside `x ↦ …` called with `3`, the
 * call gave `If(y < 3, 100, 0)`, the condition read with one value and the
 * branch with the other. And a block local that the value names leaves the
 * block with it, unbound (`If(y < 3, b, 0)`). The value stored now names
 * the value instead: `If(y < 3, 3, 0)`.
 *
 * Not replaced:
 * - A function literal, at the root or nested: a closure keeps the
 *   variable, and reads its last value, as a closure over a global or a
 *   block local of the enclosing scope does.
 * - A lazy collection: `assignedValue` lists it, and a lazy collection that
 *   reads a local keeps the activation it was made in
 *   (`lazy-view-context.ts`).
 * - Inside an operator that binds names (`Sum`, `Product`, a `Block`), an
 *   occurrence of a name that operator binds, in an operand where it is in
 *   scope: there the name is the operator's own variable (`Sum(k·b, k =
 *   1..3)` with a run variable `k` keeps its index `k`). The other names in
 *   its operands are replaced, so `If(c, Sum(b·k, k = 1..3), 0)` stores the
 *   value of `b`, and so is the index in the bounds of its own `Limits`
 *   clause, which read the enclosing variable (`Sum(x, Limits(x, 1, x))`
 *   stores the upper bound `3`). A name bound by a binder stays bound in
 *   the binders nested in it.
 * - The target of a storing operator (`Assign`, `Declare`): a name, not a
 *   read, so `Hold(Assign(b, 4))` keeps `b`.
 * - A variable with no value, and any other symbol (a global, a constant).
 * - A symbol bound to a constant definition that is not the binding of its
 *   name in the current scope: the library `Pi` in a result that the engine
 *   built (`Sum(1/n², n, 1, ∞)` is `π²/6`) inside a block whose local is
 *   named `Pi`. The evaluation of such a symbol reads its own constant, not
 *   the local, so the stored value must keep it.
 *
 * The values of a dictionary are read like the operands of a list.
 *
 * `assignedValue` applies it, so every store of a plain value does: `Assign`
 * to a name, each leaf of a destructuring `Assign` or `Declare`, and
 * `Declare` with a value.
 */
export function snapshotRunVariables(
  ce: ComputeEngine,
  value: Expression
): Expression {
  if ((!isFunction(value) && !isDictionary(value)) || value.isLazyCollection)
    return value;
  // A variable of the run is a parameter of a function literal, whose value
  // a call holds, or a binding of the scope of a list of statements
  // being run (`isStatementListScope`: a `Block`, a function body).
  //
  // The value of the variable of the run that `name` (bound to `own`, the
  // definition the occurrence carries) reads now, or `undefined` when it does
  // not read one.
  // The occurrence was resolved to `binding` by the caller: a symbol by its
  // data binding (`bindingInContext`), the head of a call by its callable
  // binding (`callableBindingInContext`), which a later declaration of the
  // same name that is not the one the call was bound to cannot shadow.
  const runValue = (
    name: string,
    binding: BoxedDefinition | undefined
  ): Expression | undefined => {
    if (binding === undefined || !('value' in binding)) return undefined;
    const def = binding.value;
    if (!isFunctionLiteralParameter(def)) {
      let scope: Scope | null = ce.context.lexicalScope;
      while (scope && scope.bindings.get(name) !== binding)
        scope = scope.parent;
      if (!scope || !isStatementListScope(scope)) return undefined;
    }
    // A variable whose value names the variable itself (`t := t + 1` with
    // `t` given no value first: its value is `t + 1`) is a symbol in that
    // value, and the stored value already reads it as one: replacing it
    // would add its value once more (`t + 2` would become `t + 3`).
    const held = def.storedValue;
    if (held === undefined || held.has(name)) return undefined;
    return held;
  };
  const current = (s: Expression & { symbol: string }): Expression => {
    // A free name (`isFreeName()`, `binding-unit.ts`) reads the binding
    // that its name resolves to, which is never a parameter of a call or the
    // variable of a binder (`freeBinding()`).
    const binding = isFreeName(s)
      ? freeBinding(s)
      : bindingInContext(
          ce,
          s.symbol,
          s.valueDefinition ?? s.operatorDefinition
        );
    // An occurrence bound to a constant reads the value of its own
    // definition, whatever binding of the same name the scope chain holds
    // (the `isConstant` branch of `BoxedSymbol.evaluate()`). So a result
    // that the engine built with the library `Pi`, assigned in a block that
    // declares a local `Pi`, keeps the library constant. A binding that is an
    // activation of the occurrence's own definition (a constant block local
    // cloned for one run on the asynchronous route) is the same binding
    // (`sameBindingDef()`), and its value is read as before.
    const own = s.valueDefinition;
    if (
      own?.isConstant === true &&
      binding !== undefined &&
      'value' in binding &&
      !sameBindingDef(binding.value, own)
    )
      return s;
    return runValue(s.symbol, binding) ?? s;
  };
  // One memo entry per node and set of shadowed names: a subexpression
  // shared by several operands is rewritten once per set.
  const memo = new Map<Expression, Map<string, Expression>>();
  const keyOf = (shadowed: ReadonlySet<string> | undefined) =>
    shadowed === undefined ? '' : [...shadowed].sort().join('\u001f');
  const walk = (
    e: Expression,
    shadowed: ReadonlySet<string> | undefined
  ): Expression => {
    if (isSymbol(e)) return shadowed?.has(e.symbol) ? e : current(e);
    if (!isFunction(e) && !isDictionary(e)) return e;
    if (isFunction(e)) {
      if (e.operator === 'Function' || e.isLazyCollection) return e;
      if (e._numericStore !== undefined) return e;
    }
    const key = keyOf(shadowed);
    const hit = memo.get(e)?.get(key);
    if (hit !== undefined) return hit;
    if (isDictionary(e)) {
      // The values of a dictionary are read like the operands of a list;
      // its keys are strings. Memoized like an application: a dictionary
      // shared under several keys is rewritten once.
      let changed = false;
      const entries = e.keys.map((k) => {
        const v = e.get(k)!;
        const next = walk(v, shadowed);
        if (next !== v) changed = true;
        return ce.function('KeyValuePair', [ce.string(k), next]);
      });
      const rebuilt = changed ? ce.function('Dictionary', entries) : e;
      let entry = memo.get(e);
      if (entry === undefined) memo.set(e, (entry = new Map()));
      entry.set(key, rebuilt);
      return rebuilt;
    }
    // The names this operator binds shadow each operand where they are in
    // scope (`boundVariableNamesInOperand`), as in `rewriteWithBinders`: an
    // iterator clause's index is not in scope in an earlier clause, and the
    // bounds of a `Limits` clause (the collection of an `Element` clause)
    // read the ENCLOSING binding of the index (`ownIndexClauseAt`).
    const binds = boundVariableNames(e);
    const binders = binds.length > 0 ? declaredBinders(e, 'post') : undefined;
    const shadowedIn = (i: number): ReadonlySet<string> | undefined => {
      if (binds.length === 0) return shadowed;
      const here =
        binders === undefined
          ? binds
          : boundVariableNamesInOperand(e, i, binders);
      if (here.length === 0) return shadowed;
      return new Set(shadowed ? [...shadowed, ...here] : here);
    };
    const ops = e.ops;
    const next = ops.map((op, i) => {
      // The target of a storing operator is a name, not a read: in
      // `Hold(Assign(b, 4))` the `b` stays `b`.
      if (i === 0 && (e.operator === 'Assign' || e.operator === 'Declare'))
        return op;
      const own = ownIndexClauseAt(e, i, binders);
      if (own !== undefined)
        return mapOwnIndexClause(op, own, shadowed, shadowedIn(i), (o, s) =>
          walk(o, s)
        );
      return walk(op, shadowedIn(i));
    });
    const form = e.isCanonical
      ? 'canonical'
      : e.isStructural
        ? 'structural'
        : 'raw';
    // A call whose HEAD reads a variable of the run that holds a function
    // value (`f(1)` with `f` a parameter) is part of the plain value: the
    // function held now is applied, `Apply(<value of f>, 1)`, so assigning
    // another function to `f` later does not change the stored value. A
    // head bound by an enclosing binder is that binder's variable.
    const head = shadowed?.has(e.operator)
      ? undefined
      : runValue(
          e.operator,
          callableBindingInContext(
            ce,
            e.operator,
            e.valueDefinition !== undefined
              ? { value: e.valueDefinition }
              : e.operatorDefinition !== undefined
                ? { operator: e.operatorDefinition }
                : undefined,
            e
          )
        );
    const result =
      head !== undefined && head.type.matches('function')
        ? ce.function('Apply', [head, ...next], { form })
        : next.every((op, i) => op === ops[i])
          ? e
          : // The rebuilt application keeps the callable its head was bound
            // to: rebuilt in the current scope, `h(b)` would resolve `h` to a
            // different, inner `h` (`withCallableBinding`).
            withCallableBinding(e, () =>
              ce.function(e.operator, next, { form, scope: e.localScope })
            );
    let entry = memo.get(e);
    if (entry === undefined) memo.set(e, (entry = new Map()));
    entry.set(key, result);
    return result;
  };
  return walk(value, undefined);
}

/** Find a referenced name in a value, including the values of a dictionary.
 * `has()` walks the values of a dictionary (its keys are strings, not
 * symbols), with one visited set for the whole value. */
function hasReferencedName(
  expr: Expression,
  names: string | string[]
): boolean {
  return expr.has(names);
}

/**
 * The call frames of an application that received a collection argument (a
 * list, a tuple, a range, …, not a string). A declared result of the called
 * function is judged with the broadcast allowance only in such a frame
 * (`callFrameReceivedCollection()`, read by the `Typed` evaluate handler):
 * a function computed once per element of a list argument returns a list
 * of results, while a function with no collection argument whose body
 * builds a list breaks its declared scalar result.
 */
const COLLECTION_ARGUMENT_FRAMES = new WeakSet<Scope>();

/**
 * Whether the innermost function-application frame of `ce` received a
 * collection argument (`COLLECTION_ARGUMENT_FRAMES`). `true` outside any
 * application, where no call can say otherwise.
 */
export function callFrameReceivedCollection(ce: ComputeEngine): boolean {
  const stack = ce._evalContextStack;
  for (let i = stack.length - 1; i >= 0; i--) {
    if (stack[i].name !== 'call') continue;
    return COLLECTION_ARGUMENT_FRAMES.has(stack[i].lexicalScope);
  }
  return true;
}

/**
 * The call frames of the applications of function literals (`makeLambda`):
 * the scope that holds the parameters and the locals of the body of one
 * application, with the serial number of its creation. A frame stays in
 * this map after its call ends, because a function value that the call
 * returned keeps the frame in its chain. `holdsFrameSince` reads the serial
 * numbers.
 */
const CALL_FRAMES = new WeakMap<Scope, number>();

/** The serial number of the next frame added to `CALL_FRAMES`. */
let nextCallFrameSerial = 0;

function addCallFrame(frame: Scope): void {
  CALL_FRAMES.set(frame, nextCallFrameSerial++);
}

/**
 * Whether `result` holds a closure or another scoped node whose chain reads
 * a call frame with a serial number of `first` or more, that is a frame
 * that the application which started at `first` created, directly or in a
 * call that it made.
 *
 * Such a frame holds state of this application: a closure in the result
 * can write a parameter or a local of the frame
 * (`mk = n ↦ (() ↦ Block(n := n + 1, n))`). The application memo must not
 * keep such a result: two calls with the same arguments would then share
 * one closure, and thus one counter. With `wrap = m ↦ mk(m)`, the second
 * evaluation of `wrap(5)()` gave `7`, not `6`.
 */
function holdsFrameSince(result: Expression, first: number): boolean {
  const seen = new Set<Expression>();
  const visit = (e: Expression): boolean => {
    if (seen.has(e)) return false;
    seen.add(e);
    if (isDictionary(e)) return e.values.some(visit);
    // A numeric store holds numbers only: reading its operands would
    // materialize them.
    if (!isFunction(e) || e._numericStore !== undefined) return false;
    if (e.localScope) {
      for (
        let s: Scope | null | undefined = e.localScope;
        s != null;
        s = s.parent
      ) {
        const serial = CALL_FRAMES.get(s);
        if (serial !== undefined && serial >= first) return true;
      }
    }
    return e.ops.some(visit);
  };
  return visit(result);
}

/**
 * Record in `kept` each function value, lazy collection or other scoped
 * node of `expr` that does not read the call with the frame `closureParent`
 * and the body scope `leaving`: its activation does not reach the frame, or
 * its chain reads neither scope. The operands of
 * a recorded node are not visited. The substitution of the parameters at
 * the end of the call leaves these nodes alone (`bindingKeyedSubs`).
 *
 * The body of a node that reads the call is searched: it can hold a closure
 * of another call, put there in place of a parameter of another frame. With `f = (n, g) ↦ Block(h := (m ↦ (y ↦ n
 * + m(y))), If(n = 0, h(g), f(n − 1, h(g))))`, the closure that the call
 * with `n = 0` returns reads `n` through the frame of `h`, and holds in
 * place of `m` the closure that the call with `n = 1` made. Both closures
 * are made from the same literal, so the `n` of each has the same binding.
 * Without the record, the substitution at the end of the call with `n = 0`
 * (`bindingKeyedSubs`) put `0` in place of the `n` of the other closure too,
 * and `f(1, y ↦ 0)(0)` gave `0`, not `1`.
 */
function recordNodesOfOtherCalls(
  expr: Expression,
  closureParent: Scope,
  leaving: Scope,
  kept: Set<Expression>,
  seen: Set<Expression> = new Set()
): void {
  if (isDictionary(expr)) {
    for (const [, value] of expr.entries)
      recordNodesOfOtherCalls(value, closureParent, leaving, kept, seen);
    return;
  }
  if (!isFunction(expr) || expr._numericStore !== undefined) return;
  if (seen.has(expr)) return;
  seen.add(expr);
  // A lazy collection whose activation does not reach the frame of the call
  // belongs to another call. One that reaches it is not searched.
  const viewActivation = lazyViewActivationOf(expr);
  if (viewActivation !== undefined) {
    if (!chainContains(viewActivation, closureParent)) kept.add(expr);
    return;
  }
  const body = expr.operator === 'Function' ? expr.op1 : expr;
  const scope = isFunction(body) ? body.localScope : undefined;
  // A function value whose activation does not reach the frame of the call
  // belongs to another call.
  if (keepsActivation(expr) && !chainContains(scope?.parent, closureParent)) {
    kept.add(expr);
    return;
  }
  // A node whose chain reads neither the body scope of the applied literal
  // nor the frame of the call does not read this call.
  if (
    scope &&
    !chainContains(scope.parent, leaving) &&
    !chainContains(scope.parent, closureParent)
  ) {
    kept.add(expr);
    return;
  }
  for (const op of expr.ops)
    recordNodesOfOtherCalls(op, closureParent, leaving, kept, seen);
}

/** One parameter's post-evaluation substitution: the literal's OWN binding for
 * it, its name, the value to substitute, and whether the ARGUMENT mentions the
 * name (see `bindingKeyedSubs`).
 *
 * `freeBinding` is the definition that a free name or a free call head of
 * that name (`isFreeName()`, `isFreeCallHead()`, `binding-unit.ts`)
 * resolved to when its value was captured. An occurrence of the name that
 * is free is replaced only when it resolves to this definition. A
 * substitution of the parameters of a call leaves it unset, and never
 * replaces a free
 * occurrence: a free name was boxed outside the literal, and it never
 * denotes a parameter. */
type ParameterSub = readonly [
  binding: BoxedValueDefinition | undefined,
  name: string,
  value: Expression,
  ambiguous: boolean,
  freeBinding?: BoxedDefinition,
];

/**
 * Substitute by BINDING identity: rewrite an occurrence only when it resolves
 * to the given binding, whatever it is spelled.
 *
 * "Resolves to" is `sameBindingDef`, so a call frame's ACTIVATION of the
 * parameter counts as the parameter.
 *
 * `ambiguous` is the item-26 guard, and it is the one thing the two sides of an
 * activation are still distinguished for. When the argument itself mentions the
 * parameter's name, an occurrence bound on the ACTIVATION side may have been
 * bound by canonicalizing the ARGUMENT in-frame rather than by the body —
 * substituting it double-applies (`Apply(x ↦ x, Hold(raw x))` must stay
 * `Hold(x)`). An occurrence carrying the literal's own binding cannot have come
 * from the argument, so it stays substitutable even when ambiguous
 * (`Apply(w ↦ If(c, w, 0), w + 1)` = `If(c, w + 1, 0)`).
 *
 * Both halves skip an occurrence below a binder that binds the parameter's
 * name — a nested literal's parameter list, but also a scoped operator's
 * `localScope` (the parser leaves a `Sum`'s binding-site symbol raw). That
 * binder owns its occurrences, and the walker's `shadowed` set carries exactly
 * that. The RAW-name half needs the exclusion because it matches by name. The
 * binding-keyed half needs it too: usually a nested literal that re-binds the
 * name declares a DIFFERENT binding, so its occurrences do not match
 * (`(x ↦ (x ↦ x))(1)` keeps its inner binder), but the nested literal can be
 * THIS literal itself. A user function that calls itself from a lazy
 * operator's callback — `m(n) := Map(x ↦ If(x < 1, 0, m(x − 1)), [n])` —
 * evaluates the inner call to a held `Map` that holds the same callback
 * literal, whose parameter and body occurrences carry the same binding as the
 * frame being settled. Substituting into them rewrote the inner literal's
 * parameter list to `Typed(1, "number")` and gave an `expected-a-symbol`
 * error.
 *
 * The substitution is capture-avoiding: a binder that binds a name free in a
 * value, and that holds an occurrence to replace, has that name renamed to a
 * fresh one first (`captureAvoidingBinderVisitor`). Without it, `y ↦ (x ↦
 * y^x)` applied to `x` gave `x ↦ x^x` (GitHub issue #489). When a correct
 * rename cannot be decided before the result runs, the substitution throws
 * `UnavoidableCapture`, and the application declines
 * (`declineUnavoidableCapture`).
 *
 * A parameter that the result writes is not substituted at all (the
 * written-parameter rule, `parameterWrites`). The substitution cannot
 * replace the target of the write, and a read of the parameter after the
 * write must give the written value, not the value of the argument; a
 * check at each write cannot decide this, because two sibling blocks of
 * the result can share the binding of the parameter, and a write in one
 * changes what a read in the other gives. So, when the result holds an
 * `Assign` or a `Declare` that writes the parameter `p`:
 *
 * - Every occurrence of `p` keeps the binding of the parameter. A function
 *   value of the result keeps the activation it was made in
 *   (`captureNestedLocals()`), which reaches the call frame, so it reads
 *   and writes the value of `p` in that frame.
 *   The function value then shares the binding of `p` across its
 *   applications:
 *   capturing a binding does not freeze its value, and a parameter reads
 *   the activation of its invocation, here the call that made the literal
 *   (`docs/SCOPING-MODEL.md`, "Callable resolution"). With `mk = n ↦ (() ↦
 *   Block(n := n + 1, n))`, `c = mk(5)` gives `6` for the first `c()` and
 *   `7` for the second, as the same closure does in JavaScript. A write of
 *   `p` outside every function value of the result (a statement of a
 *   held `Block` at the top of the result) would run after the frame is
 *   gone, so the application declines. So does a read of `p` outside every
 *   function value: it keeps the binding of the parameter, which has
 *   no frame after the call, and it resolves by name later. A lazy
 *   collection that keeps the activation it was made in counts as a
 *   function value here, with its callback: `n ↦ Map(x ↦ Block(n := n + x,
 *   n), [1, 2])` applied to `5` is a `Map` that lists as `[6, 8]`. With a global
 *   `y = 100`, `y ↦ Pair(Hold(y), () ↦ Block(y := y + 1, y))` applied to
 *   `5` gave a held `y` that released to `100`. A `Function` literal that
 *   the call did not evaluate (a branch of an `If` whose condition is
 *   undecided, a held literal) is not a function value and keeps no
 *   activation, so a write in it counts as a write outside every function
 *   value: with a global `n = 100`, `n ↦ Hold(() ↦ Assign(n, 2))`, with
 *   the `Assign` boxed before, applied to `5`, released and applied, set
 *   the global `n` to `2`.
 * - A write or a read of `p` that denotes the parameter only by its name
 *   (a symbol with no binding, in held content) declines too, also inside
 *   a function value: such an occurrence finds no frame and resolves by
 *   name when it runs. With a global `y = 100`, `y ↦
 *   Hold(() ↦ Block(y := y + 1, y))` applied to `5`, released and applied,
 *   gave `101` and set the global `y` to `101`.
 *
 * `kept` holds the nodes of `expr` that do not read this call
 * (`recordNodesOfOtherCalls`): a closure that another call made, which
 * keeps the activation of that call. An occurrence of the parameter in such a
 * node denotes the parameter in that other frame, and is neither
 * substituted nor counted as a write or a read here. A literal that a
 * recursive application of the same literal makes holds occurrences with
 * the same binding as the parameter of this application: with
 * `h = (g, k) ↦ If(k = 0, g, h(x ↦ x + k, k − 1))`, the deepest call put its
 * `0` in place of the `k` of the closure that the call with `k = 1` made,
 * and `h(x ↦ x, 3)(100)` gave `100`, not `101`.
 */
function bindingKeyedSubs(
  expr: Expression,
  subs: ReadonlyArray<ParameterSub>,
  kept?: ReadonlySet<Expression>
): Expression {
  const substituted = subs.filter((sub) => {
    const writes = parameterWrites(expr, sub, kept);
    if ((writes & (WRITE_OUTSIDE_LITERAL | WRITE_IN_LITERAL)) === 0)
      return true;
    if (
      (writes &
        (WRITE_OUTSIDE_LITERAL | READ_OUTSIDE_LITERAL | MATCHED_BY_NAME)) !==
      0
    )
      throw new UnavoidableCapture();
    return false;
  });
  if (substituted.length === 0) return expr;
  const { visitSymbol, visitApplication } = parameterSubVisitors(substituted);
  const binds = parameterSubBinds(substituted, kept);
  return rewriteWithBinders(
    expr,
    visitSymbol,
    undefined,
    false,
    undefined,
    visitApplication,
    captureAvoidingBinderVisitor(expr, substituted, binds, kept),
    binds
  );
}

/** A bit of `parameterWrites`: a write outside every `Function` literal. */
const WRITE_OUTSIDE_LITERAL = 1;
/** A bit of `parameterWrites`: a write inside a `Function` literal. */
const WRITE_IN_LITERAL = 2;
/** A bit of `parameterWrites`: a read outside every `Function` literal. */
const READ_OUTSIDE_LITERAL = 4;
/** A bit of `parameterWrites`: a read or a write that denotes the parameter
 * only by its name. A `Function` literal that encloses it does not clear it. */
const MATCHED_BY_NAME = 8;

/**
 * Where `expr` writes and reads the parameter of `sub`, as a set of bits:
 * `WRITE_OUTSIDE_LITERAL` for a write that no `Function` literal of `expr`
 * encloses, `WRITE_IN_LITERAL` for a write in a `Function` literal,
 * `READ_OUTSIDE_LITERAL` for a read (a symbol occurrence, or a call whose
 * operator is the parameter) that no `Function` literal encloses, and
 * `MATCHED_BY_NAME` for a read or a write that denotes the parameter only by
 * its name, wherever it is. `0` when `expr` has no occurrence of the
 * parameter.
 *
 * A write is an `Assign` or a `Declare` whose target denotes the parameter:
 * the symbol of the parameter, a tuple pattern that holds it, or an indexed
 * target (`At`) whose collection is a write of it. A read of the parameter
 * in an index (`At(L, y)`) is not a write. The symbol denotes the parameter
 * when it has its name and its binding is the parameter's or an activation
 * of it (`sameBindingDef`); a symbol that has no binding (in a held
 * operand) denotes it by its name. The target of a canonical `Assign` or
 * `Declare` has no binding either, but it denotes the parameter as the
 * statement does, not by name. A held binder (a held `Block` whose
 * `Declare` makes the name a local, a held `Sum` with the index `y`) binds
 * the name by its syntax (`heldBoundNames`).
 *
 * An occurrence below a node that binds the name itself
 * (`parameterOwnBinding`) denotes another binding and does not count.
 *
 * The walk enters the values of a dictionary, as the substitution does
 * (`rewriteWithBinders`). It reads each node once: a result can share a
 * subexpression on many paths (a tuple that holds the previous tuple
 * twice), and without the memo the walk is exponential in the depth.
 */
function parameterWrites(
  expr: Expression,
  sub: ParameterSub,
  kept?: ReadonlySet<Expression>
): number {
  const [binding, name] = sub;
  // `0` when `def` (the binding of an occurrence of the name) is not the
  // parameter's, `MATCHED_BY_NAME` when the occurrence has no binding or
  // the parameter has none to compare, `BOUND` when the binding is the
  // parameter's or an activation of it.
  const BOUND = 1;
  const match = (def: BoxedValueDefinition | undefined): number => {
    if (def === undefined || binding === undefined) return MATCHED_BY_NAME;
    return sameBindingDef(def, binding) ? BOUND : 0;
  };
  const denotes = (sym: Expression & { symbol: string }): number =>
    sym.symbol !== name
      ? 0
      : match(
          (sym as { valueDefinition?: BoxedValueDefinition }).valueDefinition
        );
  // How the target of a write denotes the parameter, as `match` does. The
  // target of a canonical `Assign` or `Declare` has no binding: the write
  // finds it in the scope where it runs, so it denotes the parameter as the
  // statement does, not by name. The target of a held statement (it is
  // not canonical) denotes the parameter by name.
  const targetWrites = (target: Expression, canonical: boolean): number => {
    if (isSymbol(target)) {
      const matched = denotes(target);
      return canonical && matched === MATCHED_BY_NAME && binding !== undefined
        ? BOUND
        : matched;
    }
    if (isFunction(target, 'Tuple'))
      return target.ops.reduce(
        (bits, op) => bits | targetWrites(op, canonical),
        0
      );
    if (isFunction(target, 'At'))
      return target.op1 === undefined ? 0 : targetWrites(target.op1, canonical);
    return target.has(name) ? BOUND : 0;
  };
  // The reads of the target of a write: the indexes of an `At` target
  // (`At(L, y)` reads `y`), not the names that it writes.
  const targetReads = (target: Expression): number => {
    if (isSymbol(target)) return 0;
    if (isFunction(target, 'Tuple'))
      return target.ops.reduce((bits, op) => bits | targetReads(op), 0);
    if (isFunction(target, 'At'))
      return target.ops.reduce(
        (bits, op, i) => bits | (i === 0 ? targetReads(op) : walk(op)),
        0
      );
    return walk(target);
  };
  const ownBinding = parameterOwnBinding([sub]);
  const memo = new Map<Expression, number>();
  const walk = (e: Expression): number => {
    if (isSymbol(e)) {
      const matched = denotes(e);
      return matched === 0
        ? 0
        : READ_OUTSIDE_LITERAL | (matched & MATCHED_BY_NAME);
    }
    if (!isDictionary(e) && (!isFunction(e) || e._numericStore !== undefined))
      return 0;
    // A node that another call captured (see `bindingKeyedSubs`).
    if (kept?.has(e)) return 0;
    const known = memo.get(e);
    if (known !== undefined) return known;
    let result = 0;
    if (isDictionary(e)) {
      for (const key of e.keys) result |= walk(e.get(key)!);
    } else if (isFunction(e)) {
      const write =
        (isFunction(e, 'Assign') || isFunction(e, 'Declare')) &&
        e.op1 !== undefined;
      if (write) {
        const matched = targetWrites(e.op1, e.isCanonical);
        if (matched !== 0)
          result = WRITE_OUTSIDE_LITERAL | (matched & MATCHED_BY_NAME);
      }
      // A call whose operator is the parameter reads it, with the binding
      // rules of the substitution (`applicationValue`): a call with no
      // binding and no operator definition denotes the parameter by name.
      if (e.operator === name) {
        const def = e.valueDefinition;
        const matched =
          def === undefined && e.operatorDefinition !== undefined
            ? 0
            : match(def);
        if (matched !== 0)
          result |= READ_OUTSIDE_LITERAL | (matched & MATCHED_BY_NAME);
      }
      const own = ownBinding(e, name);
      if (own !== 'all') {
        // A held node has no scope: the operands where its index binds the
        // name are read from its syntax (`binderBoundAt`).
        const binders =
          own === 'none'
            ? undefined
            : declaredBinders(e, own === 'held' ? 'pre' : 'post');
        e.ops.forEach((op, i) => {
          if (own === 'none') {
            result |= write && i === 0 ? targetReads(op) : walk(op);
            return;
          }
          const clause = ownIndexClauseAt(e, i, binders);
          if (clause === undefined || clause.name !== name || !isFunction(op)) {
            const bound =
              own === 'held'
                ? binderBoundAt(binders, name, i)
                : boundVariableNamesInOperand(e, i, binders).includes(name);
            if (!bound) result |= walk(op);
            return;
          }
          // The operands of the clause that are outside the scope of its
          // index (its bounds, its collection) read the enclosing binding.
          op.ops.forEach((o, j) => {
            if (clause.outside(j)) result |= walk(o);
          });
        });
      }
      // A function value, or a lazy collection with its callback, keeps the
      // activation it was made in, which reaches the call frame (one that
      // does not is in `kept`), so an occurrence bound to the parameter
      // inside it reads and writes the frame. An occurrence matched by name
      // keeps its bit. A `Function` node outside both (a literal that the
      // call did not evaluate: a branch of an undecided `If`, a held
      // literal) keeps no activation, so a write in it stays a write
      // outside every function value.
      if (keepsActivation(e) || lazyViewActivationOf(e) !== undefined) {
        if ((result & WRITE_OUTSIDE_LITERAL) !== 0) result |= WRITE_IN_LITERAL;
        result &= ~(WRITE_OUTSIDE_LITERAL | READ_OUTSIDE_LITERAL);
      }
    }
    memo.set(e, result);
    return result;
  };
  return walk(expr);
}

/**
 * True when the scope entry `entry` of `name` holds the binding of the
 * parameter `name` of `subs` (`sameBindingDef`).
 */
function isParameterEntry(
  subs: ReadonlyArray<ParameterSub>,
  entry: BoxedDefinition | undefined,
  name: string
): boolean {
  return (
    entry !== undefined &&
    'value' in entry &&
    subs.some(
      ([binding, param]) =>
        param === name &&
        binding !== undefined &&
        sameBindingDef(entry.value, binding)
    )
  );
}

/**
 * How `node` binds `name` itself, so that an occurrence of `name` below it
 * does not denote the parameter `name` of `subs`. `'all'`: in every
 * operand (a `Function` literal whose parameter list holds the name, a
 * `Block` that makes the name a local of the whole block). `'scope'`: in
 * the operands where the scope of `node` holds the name with a binding
 * that is not the parameter's (an index of a `Sum`, a local function); an
 * index binds its own clause and the later ones only, and the bounds of
 * its own clause are outside its scope (`boundVariableNamesInOperand`,
 * `ownIndexClauseAt`). `'held'`: like `'scope'`, for a node that is not
 * canonical (held content), which has no scope: an index of its clauses
 * binds the name, read from its syntax (`heldBoundNames`). A held `Block`
 * whose `Declare` makes the name a local gives `'all'`. `'none'`: in no
 * operand. A scope entry that holds the binding of the parameter does not
 * bind the name (`parameterSubBinds`).
 */
function parameterOwnBinding(
  subs: ReadonlyArray<ParameterSub>
): (node: Expression, name: string) => 'all' | 'scope' | 'held' | 'none' {
  return (node, name) => {
    if (isFunction(node, 'Function')) {
      for (let i = 1; i < node.ops.length; i++)
        if (functionLiteralParameterNames(node.ops[i]).includes(name))
          return 'all';
    } else if (
      !node.isCanonical &&
      node.localScope === undefined &&
      heldBoundNames(node).includes(name)
    )
      return node.operator === 'Block' ? 'all' : 'held';
    if (blockLocals(node).has(name)) return 'all';
    const entry = node.localScope?.bindings.get(name);
    if (entry !== undefined && !isParameterEntry(subs, entry, name))
      return 'scope';
    return 'none';
  };
}

/**
 * The hook of `bindingKeyedSubs` that gives the names that a node binds,
 * from the names of its scope (`boundVariableNames`).
 *
 * A scope entry that holds the binding of the parameter of `subs` with the
 * same name (`sameBindingDef`) does not bind the name: it holds the binding
 * of a parameter of an enclosing literal. Canonicalization puts it there
 * when a nested `Block` (the body of a nested literal, or an inner block of
 * the body) reads the parameter, and an occurrence below it still denotes
 * the parameter. When it counted as a binder, the substitution skipped the
 * occurrence, and a later read found another binding of the name: with
 * `F = (y, w) ↦ (x ↦ y^x)`, `F(x)(5)(y)` gave `y^y`, not `x^y`.
 *
 * A `Block` binds each local that it makes for all of its statements
 * (`blockLocalNames`), also when its scope does not hold the binding
 * of the local (a run of the block declares it again): a `Declare` of a
 * fresh local `y` in a nested block makes a local of that block, which the
 * substitution of the parameter `y` does not touch. A held `Block` (not
 * canonical) has no scope: it binds the targets of its `Declare`
 * statements (`heldBoundNames`), so `y ↦ Hold(Block(Declare(y), y))`
 * applied to `5` keeps its block as it is. A held operator with binding
 * sites (`Sum`, `Product`, `Comprehension`, `Integrate`, …) has no scope
 * either: it binds the indexes of its clauses, read from its syntax
 * (`heldBoundNames`), each in the operands where the index is in scope
 * (`rewriteWithBinders`). So `k ↦ Hold(Sum(k·y, Limits(k, 1, 3)))` applied
 * to `5` keeps its sum as it is, and `k ↦ Hold(Sum(j·y, Limits(j, 1, k)))`
 * applied to `5` gives `Hold(Sum(j·y, Limits(j, 1, 5)))`: the bounds of a
 * clause are outside the scope of its own index.
 *
 * A `Function` literal still binds each name of its parameter list. The
 * literal that is applied can be in the result (a user function that calls
 * itself from the callback of a lazy operator), and its parameter list and
 * its body then hold the parameter's own binding. They must keep it (see
 * `bindingKeyedSubs`).
 */
function parameterSubBinds(
  subs: ReadonlyArray<ParameterSub>,
  foreign?: ReadonlySet<Expression>
): (node: Expression, names: readonly string[]) => readonly string[] {
  return (node, names) => {
    // A node that another call captured binds every parameter for the
    // substitution (see `bindingKeyedSubs`).
    if (foreign?.has(node)) {
      const added = subs
        .map(([, name]) => name)
        .filter((name) => !names.includes(name));
      return added.length === 0 ? names : [...names, ...added];
    }
    if (isFunction(node, 'Function')) return names;
    const held = !node.isCanonical && node.localScope === undefined;
    const locals = held ? heldBoundNames(node) : blockLocalNames(node);
    const kept = names.filter(
      (name) =>
        locals.includes(name) ||
        !isParameterEntry(subs, node.localScope?.bindings.get(name), name)
    );
    const added = locals.filter((name) => !names.includes(name));
    return kept.length === names.length && added.length === 0
      ? names
      : [...kept, ...added];
  };
}

/** The two visitors of `bindingKeyedSubs` for `subs`: one for the symbol
 * occurrences of the parameters and one for their calls. `symbolValue` and
 * `applicationValue` are their tests, which build nothing: the value that
 * replaces the symbol, or the function value that replaces the operator of
 * the call, or `undefined` when the substitution keeps it. */
function parameterSubVisitors(subs: ReadonlyArray<ParameterSub>): {
  visitSymbol: (
    sym: Expression & { symbol: string },
    shadowed: ReadonlySet<string> | undefined
  ) => Expression;
  visitApplication: (
    app: Expression,
    ops: ReadonlyArray<Expression>,
    shadowed: ReadonlySet<string> | undefined
  ) => Expression | undefined;
  symbolValue: (
    sym: Expression & { symbol: string },
    shadowed: ReadonlySet<string> | undefined
  ) => Expression | undefined;
  applicationValue: (
    app: Expression,
    shadowed: ReadonlySet<string> | undefined
  ) => Expression | undefined;
} {
  const symbolValue = (
    sym: Expression & { symbol: string },
    shadowed: ReadonlySet<string> | undefined
  ): Expression | undefined => {
    const def = (sym as { valueDefinition?: BoxedValueDefinition })
      .valueDefinition;
    const free = isFreeName(sym);
    for (const [binding, name, value, ambiguous, captured] of subs) {
      // A free name whose value was captured (`freeBinding` of the
      // substitution): it is replaced when it resolves to the captured
      // definition.
      if (
        free &&
        captured !== undefined &&
        sym.symbol === name &&
        shadowed?.has(name) !== true &&
        freeBinding(sym) === captured
      )
        return value;
      // Bound: it denotes this parameter — either the literal's own binding
      // or this frame's activation of it.
      if (
        def !== undefined &&
        binding !== undefined &&
        sameBindingDef(def, binding) &&
        (!ambiguous || def === binding) &&
        shadowed?.has(name) !== true
      )
        return value;
      // Raw: a lazy operator holds its operands unevaluated, so the body
      // source reaches here un-canonicalized and its parameter references
      // carry no binding at all (`Map`'s held body, a pipe's `_1` topic). An
      // unbound occurrence has nothing else it could denote inside this
      // frame, so the name is the whole answer — the same rule the equality
      // contract uses for a raw operand. A free name (`isFreeName()`,
      // `binding-unit.ts`) carries no binding but is not raw: it was boxed
      // outside the literal, and it never denotes a parameter.
      if (
        def === undefined &&
        !free &&
        sym.symbol === name &&
        shadowed?.has(name) !== true
      )
        return value;
    }
    return undefined;
  };
  // A call of a parameter that holds a function is an occurrence of the
  // parameter too, with the same two halves as a symbol: `f(x)` becomes
  // `Apply(value, x)`. Without it, `function g(f) { [f(x) for x in [1, 2]]
  // }` applied to `a ↦ a + 1` returned the lazy comprehension with the call
  // `f(x)`, which read `f` after the call frame was popped: its cells were
  // `f(1)` and `f(2)`.
  const applicationValue = (
    app: Expression,
    shadowed: ReadonlySet<string> | undefined
  ): Expression | undefined => {
    const name = app.operator;
    if (shadowed?.has(name) === true) return undefined;
    const def = app.valueDefinition;
    // Several substitutions can have the name (the locals of nested scopes,
    // innermost first). A raw occurrence
    // matches by name alone, so the first substitution of that name, the
    // innermost local, decides: when its value is not a function, the call
    // is not a call of a function value and is kept, and an outer local of
    // the same name, which the inner one shadows, is not used. A bound
    // occurrence takes the first substitution whose binding matches.
    // A free call head (`isFreeCallHead()`) carries no binding but is not
    // raw: it never denotes a parameter. It is replaced only by a
    // substitution that captured the value of the definition that it
    // resolves to (`freeBinding` of the substitution).
    if (def === undefined && isFreeCallHead(app)) {
      const resolved = freeBinding(app);
      if (resolved === undefined) return undefined;
      for (const [, param, value, , captured] of subs)
        if (param === name && captured === resolved)
          return value.type.matches('function') ? value : undefined;
      return undefined;
    }
    const raw = def === undefined && app.operatorDefinition === undefined;
    for (const [binding, param, value, ambiguous] of subs) {
      if (param !== name) continue;
      const bound =
        raw ||
        (def !== undefined &&
          binding !== undefined &&
          sameBindingDef(def, binding) &&
          (!ambiguous || def === binding));
      if (!bound) continue;
      return value.type.matches('function') ? value : undefined;
    }
    return undefined;
  };
  // A symbol value is inserted as a copy (the same occurrence: its home
  // scope and its unit are kept, `_unshared()`). The node of the argument
  // is also an operand of the call, and the boxing of a closure in the
  // result marks its occurrences (`markFunctionLiteralCaptures()`): a mark
  // on the shared node changed the type of the call after its evaluation.
  const visitSymbol = (
    sym: Expression & { symbol: string },
    shadowed: ReadonlySet<string> | undefined
  ): Expression => {
    const value = symbolValue(sym, shadowed);
    if (value === undefined) return sym;
    return isSymbol(value)
      ? (value as unknown as { _unshared(): Expression })._unshared()
      : value;
  };
  const visitApplication = (
    app: Expression,
    ops: ReadonlyArray<Expression>,
    shadowed: ReadonlySet<string> | undefined
  ): Expression | undefined => {
    const value = applicationValue(app, shadowed);
    return value === undefined
      ? undefined
      : applyFunctionValue(value, app, ops);
  };
  return { visitSymbol, visitApplication, symbolValue, applicationValue };
}

/**
 * The `visitBinder` hook of `bindingKeyedSubs` that makes the substitution
 * capture-avoiding, or `undefined` when no value has a free name.
 *
 * A value can mention a name that a binder of `expr` binds. When an
 * occurrence of the parameter is below that binder, the substituted value
 * lands in its scope, and the binder captures the name of the value:
 * applying `y ↦ (x ↦ y^x)` to the free symbol `x` gave `x ↦ x^x`, and
 * applying the result to `y` gave `y^y`, not `x^y`. The hook renames the
 * bound name of such a binder to a fresh name before the walk descends
 * into it (`renameBoundVariables`), so the result is `x_1 ↦ x^(x_1)`.
 *
 * A binder is renamed only when both hold: it binds a name that is free in
 * the value of a parameter that is not shadowed at the binder, and the
 * subtree of the binder has an occurrence of that parameter which the
 * substitution replaces. Every other binder is kept as it is, with its
 * identity, so a value with no capture prints as before.
 *
 * The free names of the values and the names used in `expr` are computed
 * only when the walk reaches a binder, and once per substitution.
 *
 * The target of an `Assign` of a held block is a local of the block or not
 * depending on the scope where the block is released
 * (`heldBlockAssignTargets`). When such a target would capture a name of a
 * value, the hook throws `UnavoidableCapture`, and the application declines
 * (it stays unevaluated). So does a rename that `renameBoundVariables`
 * cannot do.
 */
function captureAvoidingBinderVisitor(
  expr: Expression,
  subs: ReadonlyArray<ParameterSub>,
  binds: (node: Expression, names: readonly string[]) => readonly string[],
  kept?: ReadonlySet<Expression>
):
  | ((
      node: Expression,
      shadowed: ReadonlySet<string> | undefined
    ) => Expression | undefined)
  | undefined {
  if (subs.length === 0) return undefined;
  let free: ReadonlyArray<ReadonlySet<string>> | undefined;
  let used: Set<string> | undefined;
  return (node, shadowed) => {
    // Nothing is substituted in a node that another call captured (see
    // `bindingKeyedSubs`), so no name of it needs a rename.
    if (kept?.has(node)) return undefined;
    // A local of a `Block` that an `Assign` or a `Declare` statement makes
    // is bound by the block too, although its scope does not hold its
    // binding when the block is not running (`blockLocalNames`). A node
    // that is not canonical, other than a `Function` literal, has no scope:
    // what it binds is read from its syntax (`heldBoundNames`).
    const block = isFunction(node, 'Function') ? node.ops[0] : node;
    const held = !(
      node.isCanonical ||
      node.localScope !== undefined ||
      isFunction(node, 'Function')
    );
    const bound = held
      ? new Set(heldBoundNames(node))
      : new Set([
          ...binds(node, boundVariableNames(node)),
          ...blockLocalNames(block),
        ]);
    // The target of an `Assign` of a held block may or may not be a local
    // of the block when it is released (`heldBlockAssignTargets`): when it
    // would capture, the application declines.
    const maybeBound = held ? heldBlockAssignTargets(node) : undefined;
    // The variable of a held `D`, `Series` or indefinite `Integrate` is free
    // (`pointVariableNames()`): the value of the node is a function of it.
    // A replacement of the variable inside the node gives an invalid node
    // or the value of another expression (`D(k^2, k)` with `k` replaced by
    // `3` is `D(9, 3)`), and a rename gives a function of another name. A
    // value that holds the name, put in the node, is captured by the
    // variable (`k ↦ Hold(D(k·y, y))` applied to `y` would give
    // `D(y·y, y)`, whose value is `2y`, not `y`). In both cases the
    // application declines.
    const point = held ? pointVariableNames(node) : undefined;
    if (
      bound.size === 0 &&
      (maybeBound?.size ?? 0) === 0 &&
      point === undefined
    )
      return undefined;
    free ??= subs.map(([, , value]) => freeNamesOf(value));
    // A sub that replaces the name `name` by the symbol `name` changes no
    // occurrence of the node, as `pointEntries()` (`boxed-function.ts`)
    // skips it: `(x ↦ Hold(D(x^2, x)))(x)` keeps the held node.
    const isIdentity = (sub: ParameterSub, name: string) =>
      sub[1] === name && isSymbol(sub[2], name);
    const capturesIn = (name: string) => {
      const capturing = subs.filter(
        (sub, i) =>
          free![i].has(name) &&
          shadowed?.has(sub[1]) !== true &&
          !isIdentity(sub, name)
      );
      return (
        capturing.length > 0 && substitutesIn(node, capturing, shadowed, binds)
      );
    };
    for (const name of maybeBound ?? [])
      if (capturesIn(name)) throw new UnavoidableCapture();
    for (const name of point ?? []) {
      if (capturesIn(name)) throw new UnavoidableCapture();
      const replaced = subs.filter(
        (sub) =>
          sub[1] === name &&
          shadowed?.has(name) !== true &&
          !isIdentity(sub, name)
      );
      if (replaced.length > 0 && substitutesIn(node, replaced, shadowed, binds))
        throw new UnavoidableCapture();
    }
    const names: string[] = [];
    for (const name of bound) if (capturesIn(name)) names.push(name);
    if (names.length === 0) return undefined;
    used ??= namesIn([expr, ...subs.map(([, , value]) => value)]);
    return renameBoundVariables(node, names, used);
  };
}

/** True when the substitution of `subs` in `node`, under the names
 * `shadowed`, replaces at least one occurrence. The walk is the walk of the
 * substitution (`rewriteWithBinders`), with the same shadowing rules, but
 * the visitors only test each occurrence and build nothing. The first
 * occurrence that the substitution replaces ends the walk: the visitor
 * throws `SUBSTITUTES`, which only this function catches. */
function substitutesIn(
  node: Expression,
  subs: ReadonlyArray<ParameterSub>,
  shadowed: ReadonlySet<string> | undefined,
  binds: (node: Expression, names: readonly string[]) => readonly string[]
): boolean {
  const { symbolValue, applicationValue } = parameterSubVisitors(subs);
  try {
    rewriteWithBinders(
      node,
      (sym, sh) => {
        if (symbolValue(sym, sh) !== undefined) throw SUBSTITUTES;
        return sym;
      },
      shadowed,
      false,
      undefined,
      (app, _ops, sh) => {
        if (applicationValue(app, sh) !== undefined) throw SUBSTITUTES;
        return undefined;
      },
      undefined,
      binds
    );
  } catch (e) {
    if (e === SUBSTITUTES) return true;
    throw e;
  }
  return false;
}

/** Thrown by the visitors of `substitutesIn` to end its walk. */
const SUBSTITUTES = { substitutes: true };

/**
 * The names that occur free in `expr`: the symbols and the operators of the
 * calls that no binder of `expr` binds.
 *
 * The scope of a `Block` also holds a binding for each free symbol of the
 * block that resolved to nothing when it was boxed: boxing declares it there
 * with no value and the type `unknown` (`placeholderBindings`). Such a
 * binding binds nothing, so an occurrence bound to it is free, although the
 * name is in the scope: the `x` of `t ↦ x`, boxed when no `x` is declared.
 * An occurrence bound to such a binding that is also below a real binder of
 * its name is then counted as free too. That can only cause a rename that is
 * not necessary, never a capture.
 */
function freeNamesOf(expr: Expression, operators = true): ReadonlySet<string> {
  const names = new Set<string>();
  const placeholders = placeholderBindings(expr);
  const isFree = (
    name: string,
    def: BoxedValueDefinition | undefined,
    shadowed: ReadonlySet<string> | undefined
  ) =>
    shadowed?.has(name) !== true ||
    (def !== undefined && placeholders.has(def));
  rewriteWithBinders(
    expr,
    (sym, shadowed) => {
      const def = (sym as { valueDefinition?: BoxedValueDefinition })
        .valueDefinition;
      if (isFree(sym.symbol, def, shadowed)) names.add(sym.symbol);
      return sym;
    },
    undefined,
    false,
    undefined,
    (app, _ops, shadowed) => {
      if (operators && isFree(app.operator, app.valueDefinition, shadowed))
        names.add(app.operator);
      return undefined;
    }
  );
  return names;
}

/**
 * The bindings of the scopes of the `Block` nodes of `expr` that boxing
 * declared for a free symbol (`engine-expression-entrypoints.ts`): a value
 * binding with no value and an inferred type, which is not a parameter of a
 * function literal, and not a local of the block (a `Declare` local,
 * `blockLocalNames`). The same test as the captured symbols of a function
 * literal (`capturedSymbols()`, `boxed-expression/function-literal.ts`).
 */
function placeholderBindings(expr: Expression): Set<BoxedValueDefinition> {
  const result = new Set<BoxedValueDefinition>();
  const seen = new Set<Expression>();
  const visit = (e: Expression): void => {
    if (seen.has(e)) return;
    seen.add(e);
    if (isDictionary(e)) {
      for (const key of e.keys) visit(e.get(key)!);
      return;
    }
    if (!isFunction(e)) return;
    if ((e as { _numericStore?: unknown })._numericStore !== undefined) return;
    const scope = e.localScope;
    if (e.operator === 'Block' && scope !== undefined) {
      const locals = new Set(blockLocalNames(e));
      for (const [name, b] of scope.bindings) {
        if (!('value' in b) || locals.has(name)) continue;
        const def = b.value;
        if (
          def.inferredType &&
          def.value === undefined &&
          def._blockLocal !== true &&
          (b as { _declaredByStatement?: boolean })._declaredByStatement !==
            true &&
          !isFunctionLiteralParameter(def)
        )
          result.add(def);
      }
    }
    for (const op of e.ops) visit(op);
  };
  visit(expr);
  return result;
}

/** Every name in `exprs`: the symbols, the operators and the bound names.
 * A node reached through several operands is read once. */
function namesIn(exprs: ReadonlyArray<Expression>): Set<string> {
  const names = new Set<string>();
  const seen = new Set<Expression>();
  const visit = (e: Expression): void => {
    if (seen.has(e)) return;
    seen.add(e);
    if (isSymbol(e)) names.add(e.symbol);
    else if (isDictionary(e)) for (const key of e.keys) visit(e.get(key)!);
    else if (isFunction(e)) {
      names.add(e.operator);
      for (const name of boundVariableNames(e)) names.add(name);
      // A store-backed list holds numbers only, and reading its `ops`
      // would box every element.
      if ((e as { _numericStore?: unknown })._numericStore !== undefined)
        return;
      for (const op of e.ops) visit(op);
    }
  };
  for (const e of exprs) visit(e);
  return names;
}

/**
 * The binder `node` with each of its bound names `names` renamed to a fresh
 * name, so that a substitution below the binder does not capture a free name
 * of a replacement. `Expression.subs()` calls it (`capturedNames()` in
 * `boxed-expression/boxed-function.ts` finds the names). The fresh name of
 * `k` is `k_1`, or `k_2` when `k_1` is used in `node` or in one of the
 * replacements `values`. The rename itself is the one that function
 * application uses (`renameBoundVariables`).
 *
 * `undefined` when a correct rename cannot be decided before the node runs:
 *
 * - the name is the target of an `Assign` of a `Block` that is not canonical
 *   (a held block), and not of a `Declare`: the `Assign` makes a local only
 *   when the name is not declared in the scope where the block is released
 *   (`heldBlockAssignTargets`). With `s` declared, `Hold(Block(s := 3, y +
 *   s))` with `y` replaced by `s` must keep `s := 3` as a write of the
 *   declared `s`;
 * - the name is declared only by a `Declare` or an `Assign` in an operand
 *   with no scope of its own (a branch of an `If`): the later reads denote
 *   the local only when that branch runs (`blockLocals`);
 * - one of the other cases where `renameBoundVariables` throws
 *   `UnavoidableCapture`.
 */
export function renameCapturingBinder(
  node: Expression,
  names: ReadonlyArray<string>,
  values: ReadonlyArray<Expression>,
  readsFunctionBody: boolean
): Expression | undefined {
  const held = !(
    node.isCanonical ||
    node.localScope !== undefined ||
    isFunction(node, 'Function')
  );
  if (held) {
    const assigned = heldBlockAssignTargets(node);
    if (names.some((name) => assigned.has(name))) return undefined;
  }
  try {
    const used = namesIn([node, ...values]);
    const chosen = new Map<string, string>();
    const renamed = renameBoundVariables(node, names, used, chosen);
    if (!readsFunctionBody || !isFunction(renamed)) return renamed;
    // `subs()` reads a `Function` literal operand of a node with index
    // variables (the integrand of a definite `Integrate`) by its body, with
    // the index variables of the node as the bound names
    // (`subsBinderView()`, `boxed-function.ts`), and so does the evaluation
    // of the node: the parameters of the literal and the index variables are
    // the same variables. The rename above does not enter the literal, which
    // binds the name again, so each parameter of the literal that is a
    // renamed name gets the same fresh name too. Without it,
    // `Integrate(j·x, Limits(x, 0, 1))` with `j` replaced by `x` gave
    // `Integrate(Function(x·x, x), Limits(x_1, 0, 1))`, whose value is `x²`,
    // not `x/2`.
    let changed = false;
    const ops = renamed.ops.map((op) => {
      if (!isFunction(op, 'Function')) return op;
      const params = boundVariableNames(op).filter((name) =>
        names.includes(name)
      );
      if (params.length === 0) return op;
      const literal = renameBoundVariables(op, params, used, chosen);
      if (literal === undefined || literal === op) return op;
      changed = true;
      return literal;
    });
    if (!changed) return renamed;
    const ce = node.engine;
    if (renamed.isCanonical)
      return ce._fn(renamed.operator, ops, { scope: renamed.localScope });
    return ce.function(renamed.operator, ops, {
      form: renamed.isStructural ? 'structural' : 'raw',
    });
  } catch (e) {
    if (e instanceof UnavoidableCapture) return undefined;
    throw e;
  }
}

/**
 * The names that a `Block` that is not canonical (a held block) may or may
 * not bind when it is released (`heldBlockAssignTargets`): the target of an
 * `Assign` statement that no `Declare` statement declares, and the target of
 * an `Assign` or a `Declare` in an operand of a statement (a branch of an
 * `If`). An empty set for every other node. `subsIfCaptureFree()`
 * (`boxed-expression/subs-capture-mode.ts`) declines when a replacement
 * below the block holds one of these names free.
 */
export function heldBlockUndecidedLocals(
  node: Expression
): ReadonlySet<string> {
  if (
    !isFunction(node, 'Block') ||
    node.isCanonical ||
    node.localScope !== undefined
  )
    return new Set();
  return heldBlockAssignTargets(node);
}

/**
 * The names that occur free in `expr`, as the capture-avoiding substitution
 * of function application reads them (`freeNamesOf`): the symbols and the
 * operators of the calls that no binder of `expr` binds. With `operators`
 * set to `false`, the operators of the calls are left out: `subs()`
 * replaces a symbol operand, not the name of a call.
 */
export function freeNamesForSubs(
  expr: Expression,
  operators = true
): ReadonlySet<string> {
  return freeNamesOf(expr, operators);
}

/**
 * The binder `node` with each of its bound names `names` renamed to a fresh
 * name that is not in `used` (`x` becomes `x_1`, or `x_2` when `x_1` is
 * used). The fresh names are added to `used`.
 *
 * `node` is a `Function` literal, whose parameters are declared in the scope
 * of its body `Block`, or a scoped operator (`Sum`, `Block`,
 * `Comprehension`, …), which declares its index or its variables in its own
 * scope. A `Block` (the body of a literal, or a scoped `Block`) also binds
 * the locals that its `Declare` statements make (`blockLocalNames`). Its
 * scope does not hold the binding of such a local when the block is not
 * running: a run of the block declares the local again.
 *
 * The renamed binder gets a NEW scope, a copy of that scope with the same
 * parent, in which each fresh name is declared with the type of the binding
 * it replaces (`unknown` for a local with no binding). The new scope gets
 * its own copy of the record of the locals, with the fresh names. The
 * original scope and its record are not changed: they belong to the
 * expression that every other copy of the binder shares.
 *
 * An occurrence is renamed when it denotes the binding of `node`: it resolves
 * to that binding (`sameBindingDef`), or it has no binding (a held operand
 * is not canonical) and the name is in scope in that operand. An occurrence
 * of a local with no binding in the scope denotes the local when it does not
 * resolve to the binding of the name outside the block. An occurrence below
 * a nested binder of the same name belongs to the nested binder and keeps its
 * name, and so does a symbol of the same name with another binding. The
 * occurrences are replaced by symbols bound to the new scope, so every other
 * symbol keeps its binding. In the bounds of a `Limits` clause and in the
 * collection of an `Element` clause, the index of the clause is not in
 * scope (`ownIndexClause()`, `binding-sites.ts`), so an occurrence there
 * with no binding keeps its name.
 *
 * A `Function` literal that is not canonical has no body scope: its names
 * are renamed by name, with raw symbols, also as the operator of a call.
 * Another node that is not canonical (a held `Sum` or `Block`) has no scope
 * either, and is renamed by name too (`renameHeldBinder`).
 *
 * Each scope below a renamed binder that has a scope is copied, with the
 * copy of the scope above it as its parent (`rerootScopes`), so that a name
 * looked up from a nested `Block` or `Sum` finds the fresh names.
 *
 * After a rename of a parameter of a `Function` literal, a named argument of
 * a call of the result must use the new name: with `G = y ↦ (x ↦ y + x)`,
 * `G(x)` is `x_1 ↦ x + x_1`, which accepts `NamedArgument("x_1", 2)` and
 * gives `argument-name-unknown` for `NamedArgument("x", 2)`, while the
 * result of `G(z)` accepts `x`.
 *
 * When a correct rename cannot be decided before the result runs, this
 * function throws `UnavoidableCapture`, and the application declines (it
 * stays unevaluated): for a local that only a `Declare` in an operand with
 * no scope declares (`blockLocals`), for a canonical binder with no scope,
 * for a fresh name with no binding, and for the body scope of a nested
 * literal that is being applied or that chains to the locals a closure
 * captured (`rerootScopes`).
 *
 * `chosen` maps a name to the fresh name that an earlier rename gave it: a
 * name in `chosen` gets that fresh name again, and a new fresh name is added
 * to `chosen`.
 */
function renameBoundVariables(
  node: Expression,
  names: ReadonlyArray<string>,
  used: Set<string>,
  chosen: Map<string, string> = new Map()
): Expression | undefined {
  const ce = node.engine;
  if (!isFunction(node)) return undefined;
  const isLiteral = node.operator === 'Function';
  const holder = isLiteral ? node.ops[0] : node;
  const scope = holder?.localScope;
  // The hook calls this function only for a node that binds a name
  // (`rewriteWithBinders`): a node other than a `Function` literal binds a
  // name only through its scope, so it has a scope here. A node with no
  // scope here would be renamed with no binding for its fresh names, and the
  // substitution would then be done into the original node, where the value
  // is captured: a wrong value with no sign of the failure. So the
  // application declines (`UnavoidableCapture`). No public input is known to
  // reach this branch: for a canonical node other than a `Function` literal,
  // the hook reads the bound names from the bindings of its scope
  // (`boundVariableNames`) and from the locals of a `Block` with a scope
  // (`blockLocalNames`), so a node with no scope binds no name, and the hook
  // returns before it calls this function.
  // A node that is not canonical (a held operand) has no scope either, and
  // binds by its syntax (`heldBoundNames`): it is renamed by name below.
  if (
    !isLiteral &&
    node.isCanonical &&
    (holder === undefined || !isFunction(holder) || scope === undefined)
  )
    throw new UnavoidableCapture();

  // A name that `chosen` already maps keeps that fresh name, so that two
  // binders renamed one after the other give the same name the same fresh
  // name (`renameCapturingBinder`). A new fresh name is added to `chosen`.
  const fresh = new Map<string, string>();
  for (const name of names) {
    let id = chosen.get(name);
    if (id === undefined) {
      let i = 1;
      while (used.has(`${name}_${i}`)) i += 1;
      id = `${name}_${i}`;
      chosen.set(name, id);
    }
    used.add(id);
    fresh.set(name, id);
  }

  if (!isLiteral && scope === undefined) return renameHeldBinder(node, fresh);

  if (holder === undefined || !isFunction(holder) || scope === undefined) {
    return rewriteWithBinders(
      node,
      (sym, shadowed) => {
        const id = fresh.get(sym.symbol);
        return id === undefined || shadowed?.has(sym.symbol) === true
          ? sym
          : ce.symbol(id, { canonical: false });
      },
      undefined,
      true,
      undefined,
      // A call of a renamed parameter that holds a function: `f(y)` becomes
      // `f_1(y)`.
      (app, ops, shadowed) => {
        const id = fresh.get(app.operator);
        if (id === undefined || shadowed?.has(app.operator) === true)
          return undefined;
        return ce.function(id, [...ops], {
          form: app.isCanonical ? 'canonical' : 'raw',
        });
      }
    );
  }

  const locals = blockLocals(holder);
  const parameters = new Set(isLiteral ? boundVariableNames(node) : []);
  const newScope: Scope = {
    ...scope,
    bindings: new Map(scope.bindings),
  };
  // The variables of the binder, under their fresh names.
  if (scope.binderNames !== undefined)
    newScope.binderNames = new Set(
      [...scope.binderNames].map((name) => fresh.get(name) ?? name)
    );
  const targets = new Map<
    string,
    {
      old: BoxedValueDefinition | undefined;
      // The binding of the name outside the binder, for a local with no
      // binding in the scope (`old` is `undefined`).
      outer: BoxedValueDefinition | undefined;
      id: string;
      symbol: Expression;
    }
  >();
  for (const [name, id] of fresh) {
    const binding = scope.bindings.get(name);
    const old =
      binding !== undefined && 'value' in binding ? binding.value : undefined;
    let outer: BoxedValueDefinition | undefined;
    if (old === undefined && locals.has(name) && scope.parent !== null) {
      const def = ce._inScope(scope.parent, () => ce.lookupDefinition(name));
      if (def !== undefined && 'value' in def) outer = def.value;
    }
    newScope.bindings.delete(name);
    ce.declare(
      id,
      { type: old?.type ?? 'unknown', inferred: old?.inferredType ?? true },
      newScope
    );
    const def = newScope.bindings.get(id);
    if (parameters.has(name) && def !== undefined && 'value' in def)
      markFunctionLiteralParameter(ce, def.value);
    // The renamed local of a block is a local of the block too.
    if (old?._blockLocal === true && !old._programVariable && def !== undefined && 'value' in def)
      def.value._blockLocal = true;
    // `ce.declare` of a value definition (a `type`) makes a value binding,
    // so the symbol exists. Without it the binder could not be renamed, and
    // the substitution into the original binder would capture the value.
    // No public input is known to reach the decline: `ce.declare` makes a
    // value binding for every type, a function type included, and
    // `_bindingSymbol` returns a symbol for each value binding.
    const symbol = ce._bindingSymbol(id, newScope);
    if (symbol === undefined) throw new UnavoidableCapture();
    targets.set(name, { old, outer, id, symbol });
  }

  // `inScope` says whether a name of `node` is in scope in the operand: an
  // occurrence with no binding is renamed only there.
  const denotes = (
    name: string,
    def: BoxedValueDefinition | undefined,
    inScope: (name: string) => boolean
  ) => {
    const target = targets.get(name);
    if (target === undefined) return undefined;
    if (def === undefined) return inScope(name) ? target : undefined;
    if (target.old !== undefined)
      return sameBindingDef(def, target.old) ? target : undefined;
    // A local with no binding in the scope: in the block, the name denotes
    // the local, unless the occurrence resolves to the binding outside.
    if (!locals.has(name)) return undefined;
    return target.outer !== undefined && sameBindingDef(def, target.outer)
      ? undefined
      : target;
  };
  // True when the scope entry `entry` of `name` holds the binding that is
  // renamed (`sameBindingDef`). Canonicalization puts the binding of a
  // parameter of the literal in the scope of a nested `Block` that reads
  // it. Such an entry does not bind the name: an occurrence below it still
  // denotes the renamed binding, and is renamed too. This is the rule that
  // the substitution uses for the parameter it replaces
  // (`parameterSubBinds`). Without it, with `F = y ↦ (x ↦ Block(Block(y^x)))`,
  // `F(x)` gave `x_1 ↦ Block(Block(x^(x_2)))`: the occurrence kept the
  // name `x`, and the substitution of `y` renamed it a second time.
  const isRenamedEntry = (
    entry: BoxedDefinition | undefined,
    name: string
  ): boolean => {
    const old = targets.get(name)?.old;
    return (
      old !== undefined &&
      entry !== undefined &&
      'value' in entry &&
      sameBindingDef(entry.value, old)
    );
  };
  const renameBinds = (node: Expression, bound: readonly string[]) => {
    if (isFunction(node, 'Function')) return bound;
    const kept = bound.filter(
      (name) => !isRenamedEntry(node.localScope?.bindings.get(name), name)
    );
    return kept.length === bound.length ? bound : kept;
  };
  const rename = (e: Expression, inScope: (name: string) => boolean) =>
    rewriteWithBinders(
      e,
      (sym, shadowed) => {
        if (shadowed?.has(sym.symbol) === true) return sym;
        const def = (sym as { valueDefinition?: BoxedValueDefinition })
          .valueDefinition;
        return denotes(sym.symbol, def, inScope)?.symbol ?? sym;
      },
      undefined,
      false,
      undefined,
      // A call of a renamed parameter that holds a function: `f(t)` becomes
      // `f_1(t)`.
      (app, ops, shadowed) => {
        if (shadowed?.has(app.operator) === true) return undefined;
        const def = app.valueDefinition;
        if (def === undefined && app.operatorDefinition !== undefined)
          return undefined;
        // A free call head (`isFreeCallHead()`) is never a parameter.
        if (isFreeCallHead(app)) return undefined;
        const target = denotes(app.operator, def, inScope);
        if (target === undefined) return undefined;
        return ce.function(target.id, [...ops], {
          form: app.isCanonical ? 'canonical' : 'raw',
        });
      },
      undefined,
      renameBinds
    );

  // Each scope below the binder is copied onto the scope above it in the
  // renamed binder, with its bindings and its record of the locals
  // (`rerootScopes`). Without the copy, the scope of a `Block` or a `Sum`
  // in the body keeps the original scope of the binder as its parent, where
  // the fresh names are not declared: a run of a nested block that assigns
  // a renamed local wrote it outside the binder.
  const rerootMemo = new Map<Scope, Map<Expression, Expression>>();
  // In a copy of a nested scope, an entry that holds the renamed binding
  // (`isRenamedEntry`) is replaced by the entry of the fresh name, which
  // the renamed occurrences below it denote.
  const rebind = (bindings: Map<string, BoxedDefinition>) => {
    for (const [name, { id }] of targets) {
      if (!isRenamedEntry(bindings.get(name), name)) continue;
      bindings.delete(name);
      const entry = newScope.bindings.get(id);
      if (entry !== undefined) bindings.set(id, entry);
    }
  };
  // The scopes nested in the body of a function value have the body scope
  // of its literal as their parent (`captureNestedLocals()`), not `scope`.
  // The renamed value has its own copies of them, on `newScope`.
  const template = bodyScopeTemplate(scope);
  if (functionValueTemplateOf(scope) !== undefined)
    registerFunctionValueScope(newScope, newScope);
  const reroot = (e: Expression) =>
    rerootScopes(e, newScope, rerootMemo, rebind, template);

  return ce._inScope(newScope, () => {
    if (isLiteral) {
      const all = () => true;
      const block = ce._fn(
        'Block',
        holder.ops.map((op) => reroot(rename(op, all))),
        { scope: newScope, metadata: { sourceOffsets: holder.sourceOffsets } }
      );
      const literal = ce._fn(
        'Function',
        [
          block,
          ...node.ops.slice(1).map((param) => reroot(rename(param, all))),
        ],
        { metadata: { sourceOffsets: node.sourceOffsets } }
      );
      resolveFunctionLiteralTypes(literal);
      markFunctionLiteralCaptures(block);
      return literal;
    }
    const binders = declaredBinders(holder, 'post');
    return ce.function(
      holder.operator,
      holder.ops.map((op, i) => {
        const here = boundVariableNamesInOperand(holder, i, binders);
        // The bounds of a `Limits` clause and the collection of an
        // `Element` clause read the binding outside the binder, not the
        // index of the clause: `mapOwnIndexClause` takes the index out of
        // the names in scope there.
        const own = ownIndexClauseAt(holder, i, binders);
        if (own !== undefined)
          return mapOwnIndexClause(op, own, undefined, new Set(here), (o, s) =>
            reroot(rename(o, (name) => s?.has(name) === true))
          );
        return reroot(
          rename(op, (name) => here.includes(name) || locals.has(name))
        );
      }),
      {
        form: holder.isCanonical
          ? 'canonical'
          : holder.isStructural
            ? 'structural'
            : 'raw',
        scope: newScope,
      }
    );
  });
}

/**
 * The names that the node `node`, which is not canonical (a held operand,
 * the operand of `Hold`), binds by its syntax. Such a node has no scope, so
 * `boundVariableNames` does not see them. The names are:
 *
 * - for a `Block`, the targets of its `Declare` statements (a tuple pattern
 *   gives each of its names): when the held block is released and
 *   canonicalized, they are locals of the block (`canonicalBlock()`,
 *   `library/control-structures.ts`). The target of an `Assign` statement is
 *   a local only when the name is not visible in the scope where the block
 *   is released, which is not known here (`heldBlockAssignTargets`);
 * - for an operator with binding sites (`Sum`, `Product`, `Comprehension`,
 *   …), the indexes of its clauses (`declaredBinders()`,
 *   `binding-sites.ts`), except the variable of a `D`, the expansion
 *   variable of a `Series` and the variable of an indefinite integral,
 *   which the value of the node is a function of (`pointVariableNames()`).
 *   Such a variable is free: an occurrence of it denotes the name of the
 *   enclosing scope, and it is never renamed.
 *
 * A `Function` literal that is not canonical binds its parameters, which
 * `boundVariableNames` reads from its syntax already.
 */
function heldBoundNames(node: Expression): readonly string[] {
  if (!isFunction(node)) return [];
  if (node.operator === 'Block') return [...heldBlockTargets(node, 'Declare')];
  const binders = declaredBinders(node, 'pre');
  if (binders === undefined) return [];
  const free = pointVariableNames(node);
  return [...binders.visibleFrom.keys()].filter(
    (name) => free?.has(name) !== true
  );
}

/**
 * The targets of the `Declare` statements, or of the `Assign` statements, of
 * the `Block` `node`, which is not canonical: a tuple pattern gives each of
 * its names, and `Nothing` is not a name.
 */
function heldBlockTargets(
  node: Expression,
  statement: 'Assign' | 'Declare'
): Set<string> {
  const names = new Set<string>();
  if (!isFunction(node, 'Block')) return names;
  for (const op of node.ops) {
    const s = isFunction(op, 'Typed') ? op.op1 : op;
    if (!isFunction(s, statement)) continue;
    const target = s.op1;
    if (isSymbol(target)) names.add(target.symbol);
    else if (isFunction(target, 'Tuple'))
      for (const name of tuplePatternNames(target)) names.add(name);
  }
  names.delete('Nothing');
  return names;
}

/**
 * The targets of the `Assign` statements of the `Block` `node`, which is not
 * canonical (a held block), that are not also the target of a `Declare`
 * statement of the block.
 *
 * When the held block is released and canonicalized, such a target is a
 * local of the block only when the name is not visible in the scope where
 * the block is canonicalized; otherwise the `Assign` writes the variable
 * outside the block (`canonicalBlock()`, `library/control-structures.ts`).
 * That scope is not known before the release, so the substitution cannot
 * tell whether the name is bound by the block: with `s` declared,
 * `y ↦ Hold(Block(Assign(s, 3), y + s))` applied to `s` must give a block
 * that, released, assigns the declared `s` and gives `6`. Renaming the
 * target to `s_1` gave `s + 3` and left `s` with no value; not renaming it
 * gives the wrong value when `s` is not declared. So the application
 * declines (`captureAvoidingBinderVisitor`).
 *
 * The targets of the `Assign` and `Declare` statements in an operand of a
 * statement (a branch of an `If`) are included too. When the block is
 * released, such an operand has no scope of its own, so its `Assign` or
 * `Declare` makes a local of the block when it runs, and only when it runs
 * (`blockLocals`). Which reads denote that local is thus not known before
 * the run: with `s` not declared, `y ↦ Hold(Block(If(True, Assign(s, 3), 0),
 * y + s))` applied to `s` gave a block that, released, gives `6`, not
 * `s + 3`. The walk does not enter a nested `Block`, a `Function` literal, or
 * an operator with binding sites (`declaredBinders()`, `binding-sites.ts`):
 * the substitution visits each of them as a binder of its own.
 */
function heldBlockAssignTargets(node: Expression): Set<string> {
  const names = heldBlockTargets(node, 'Assign');
  if (isFunction(node, 'Block')) {
    const visit = (e: Expression): void => {
      if (!isFunction(e)) return;
      if (e.operator === 'Block' || e.operator === 'Function') return;
      if (declaredBinders(e, 'pre') !== undefined) return;
      if (e.operator === 'Assign' || e.operator === 'Declare') {
        const target = e.op1;
        if (isSymbol(target)) names.add(target.symbol);
        else if (isFunction(target, 'Tuple'))
          for (const name of tuplePatternNames(target)) names.add(name);
      }
      for (const op of e.ops) visit(op);
    };
    for (const op of node.ops) {
      const s = isFunction(op, 'Typed') ? op.op1 : op;
      if (isFunction(s, 'Assign') || isFunction(s, 'Declare')) {
        for (const value of s.ops.slice(1)) visit(value);
      } else visit(s);
    }
    names.delete('Nothing');
  }
  for (const name of heldBlockTargets(node, 'Declare')) names.delete(name);
  return names;
}

/**
 * The node `node`, which is not canonical and is not a `Function` literal,
 * with each name that is a key of `fresh` renamed to its value where the
 * name denotes a variable that `node` binds (`heldBoundNames`). The node
 * has no scope, so the occurrences are renamed by name, with raw symbols,
 * also as the operator of a call, and the node is rebuilt in its own form.
 *
 * A local of a `Block` is in scope in every statement. The index of a
 * clause is in scope in the operands before the first clause (the body),
 * and from its own clause on (`binderBoundAt()`, `binding-sites.ts`), but
 * not in the bounds of its own `Limits` clause or the collection of its own
 * `Element` clause (`ownIndexClauseAt()`). An occurrence below a nested
 * binder that has a scope and binds the same name belongs to that binder,
 * and keeps its name. A nested binder that is not canonical and binds the
 * same name is renamed with it, its binding site included, so the result
 * binds the same occurrences.
 */
function renameHeldBinder(
  node: Expression,
  fresh: ReadonlyMap<string, string>
): Expression {
  if (!isFunction(node)) return node;
  const ce = node.engine;
  const rename = (e: Expression, inScope: ReadonlySet<string> | undefined) =>
    rewriteWithBinders(
      e,
      (sym, shadowed) => {
        const id = fresh.get(sym.symbol);
        return id === undefined ||
          inScope?.has(sym.symbol) !== true ||
          shadowed?.has(sym.symbol) === true
          ? sym
          : ce.symbol(id, { canonical: false });
      },
      undefined,
      false,
      undefined,
      (app, ops, shadowed) => {
        const id = fresh.get(app.operator);
        if (
          id === undefined ||
          inScope?.has(app.operator) !== true ||
          shadowed?.has(app.operator) === true
        )
          return undefined;
        return ce.function(id, [...ops], {
          form: app.isCanonical ? 'canonical' : 'raw',
        });
      }
    );
  const isBlock = node.operator === 'Block';
  const binders = isBlock ? undefined : declaredBinders(node, 'pre');
  const ops = node.ops.map((op, i) => {
    const here = new Set(
      [...fresh.keys()].filter(
        (name) => isBlock || binderBoundAt(binders, name, i)
      )
    );
    const own = ownIndexClauseAt(node, i, binders);
    if (own !== undefined)
      return mapOwnIndexClause(op, own, undefined, here, rename, true);
    return rename(op, here);
  });
  if (ops.every((op, i) => op === node.ops[i])) return node;
  return ce.function(node.operator, ops, {
    form: node.isStructural ? 'structural' : 'raw',
  });
}

/**
 * `expr` with each scope of its canonical nodes replaced by a copy whose
 * parent is the copy of the scope of the nearest enclosing scoped node, and
 * `parent` for the outermost ones. A copy keeps the bindings of its scope
 * (the same definitions, so a symbol bound to one still denotes it). The
 * scopes of `expr` are not changed: they belong to the expression that
 * every other copy shares.
 *
 * `renameBoundVariables` calls it for the operands of a renamed binder,
 * which gets a new scope. A name is looked up through the chain of parents,
 * so a scope below the binder must chain to the new scope, where the fresh
 * names are declared, and not to the original one. A node that is not
 * canonical has no scope, and is kept. `memo` keeps a node that is reached
 * through several operands shared in the result.
 *
 * The body scope of a nested `Function` literal is copied like any other
 * scope, with all its bindings: the copy then binds what the original
 * binds, and its parent is the copy of the scope that the original chains
 * to. The body scope of a literal that is being applied
 * (`appliedBodyScopes`) is not copied, and the application declines
 * (`UnavoidableCapture`).
 *
 * `rebind`, when given, is called with the bindings of each copy before the
 * walk descends into it: the rename replaces there the entry of a renamed
 * binding by the entry of its fresh name.
 *
 * `from`, when given, is the original scope that `parent` copies. A scoped
 * node whose scope does not have `from` as its parent is not below the
 * renamed binder in the chain of scopes, and is kept with its scope: a
 * closure value that a `Sum` holds (the result of evaluating
 * `Block(a := 2, x ↦ a·x)`) chains to the scope of the block that made it,
 * where `a` is `2`, and a copy onto the scope of the `Sum` lost `a`. No
 * occurrence in such a node resolves to the renamed binding, so it needs no
 * fresh name.
 */
function rerootScopes(
  expr: Expression,
  parent: Scope,
  memo: Map<Scope, Map<Expression, Expression>>,
  rebind?: (bindings: Map<string, BoxedDefinition>) => void,
  from?: Scope
): Expression {
  if (!isFunction(expr) && !isDictionary(expr)) return expr;
  if (!expr.isCanonical) return expr;
  const hit = memo.get(parent)?.get(expr);
  if (hit !== undefined) return hit;
  if (isFunction(expr, 'Function')) {
    const own = expr.op1?.localScope;
    // A closure value whose body chains to the locals it captured is not
    // below the renamed binder (see `from` above), and is kept.
    if (own !== undefined && appliedBodyScopes.has(own))
      throw new UnavoidableCapture();
  }
  const ce = expr.engine;
  let result: Expression = expr;
  if (isDictionary(expr)) {
    let changed = false;
    const entries = expr.entries.map(([key, value]) => {
      const next = rerootScopes(value, parent, memo, rebind, from);
      changed ||= next !== value;
      return ce._fn('KeyValuePair', [ce.string(key), next]);
    });
    if (changed) result = ce.function('Dictionary', entries);
  } else if (
    isFunction(expr) &&
    expr.localScope !== undefined &&
    (from === undefined || expr.localScope.parent === from)
  ) {
    const own = expr.localScope;
    const scope: Scope = {
      ...own,
      parent,
      bindings: new Map(own.bindings),
    };
    rebind?.(scope.bindings);
    result = ce._fn(
      expr.operator,
      expr.ops.map((op) => rerootScopes(op, scope, memo, rebind, own)),
      { scope, metadata: { sourceOffsets: expr.sourceOffsets } }
    );
  } else if (
    isFunction(expr) &&
    expr.localScope === undefined &&
    expr.ops.length > 0
  ) {
    // A store-backed list holds numbers only, and reading its `ops` would
    // box every element.
    if ((expr as { _numericStore?: unknown })._numericStore === undefined) {
      const ops = expr.ops.map((op) =>
        rerootScopes(op, parent, memo, rebind, from)
      );
      if (ops.some((op, i) => op !== expr.ops[i]))
        result = ce._fn(expr.operator, ops, {
          metadata: { sourceOffsets: expr.sourceOffsets },
        });
    }
  }
  let byNode = memo.get(parent);
  if (byNode === undefined) {
    byNode = new Map();
    memo.set(parent, byNode);
  }
  byNode.set(expr, result);
  return result;
}

/**
 * The locals of the `Block` `node`, or `[]` when `node` is not a canonical
 * `Block`: the names that its `Declare` statements declare.
 */
function blockLocalNames(node: Expression | undefined): readonly string[] {
  return [...blockLocals(node)];
}

/**
 * The locals of the `Block` `node` (`blockLocalNames`). The canonicalization
 * of the block declares the target of each `Declare` statement in the scope
 * of the block before the statements (`canonicalBlock()`,
 * `library/control-structures.ts`), so the name denotes the local in the
 * whole block. A `Declare` of a tuple pattern declares each name of the
 * pattern.
 */
function blockLocals(node: Expression | undefined): ReadonlySet<string> {
  const result = new Set<string>();
  if (!isFunction(node, 'Block') || node.localScope === undefined)
    return result;
  for (const op of node.ops) {
    const s = isFunction(op, 'Typed') ? op.op1 : op;
    if (!isFunction(s, 'Declare')) continue;
    const target = s.op1;
    if (isSymbol(target)) result.add(target.symbol);
    else if (isFunction(target, 'Tuple'))
      for (const name of tuplePatternNames(target)) result.add(name);
  }
  return result;
}

/**
 * The call `app` of a name that holds the function `fn`, with the name
 * replaced by the function: `Apply(fn, ...ops)`, where `ops` are the
 * operands of `app` after a rewrite. It is canonical when `app` is.
 */
function applyFunctionValue(
  fn: Expression,
  app: Expression,
  ops: ReadonlyArray<Expression>
): Expression {
  return fn.engine.function('Apply', [fn, ...ops], {
    form: app.isCanonical ? 'canonical' : 'raw',
  });
}

/**
 * Thrown by an application of a user-function literal that is re-entered —
 * an application of the same literal is already on the evaluation stack —
 * with an argument that contains a free symbol. Caught by the outermost
 * application of that literal (`guardSymbolicRecursion`), which then
 * declines, so the whole application stays inert.
 *
 * A recursive definition is not unrolled symbolically: `R(i,x,y) :=
 * R(i-1,x,y) + 0.5·S(x,y,R(i-1,x,y))` with `x`, `y` free answers `R(3, x, y)`,
 * not a closed form. The closed form's size is inherent in such a definition
 * (each level embeds the previous one as many times as the body mentions it),
 * and entering the body once while leaving the inner self-calls inert would
 * answer neither a closed form nor a clean decline. Ground arguments —
 * numbers, strings, booleans, constants with a value, collections and
 * dictionaries of those, closed function literals — never throw here: a
 * recursive scanner over a literal list, or a string-building recursion,
 * recurses as before, and the pure-application memo makes the number-literal
 * route linear. The check is dynamic rather than a scan of the body for its
 * own name, so mutual recursion (`f` → `g` → `f`) is caught the same way.
 * The ruling and its measurements: `ROADMAP.md`, "Symbolic evaluation of a
 * recursive user function: not unrolled".
 *
 * Two boundaries. A `hold`/`bind` operator whose bound-variable reduction
 * substitutes into the body and applies the result
 * (`invokeWithBoundVariables`) is applied through a literal of a different
 * structure at each level, which the per-literal count never sees twice, so
 * such a recursion is not declined here — the recursion limit
 * (`ce.recursionLimit`) still ends it. And a `catch` between the re-entry
 * and the outermost application that does not let the signal through
 * (`rules.ts` treats any exception as "this rule failed") ends the recursion
 * at that point with a locally degraded answer rather than the clean
 * decline; the `canonical`-handler catches in `box.ts` let it through.
 *
 * Not an `Error`: it is control flow, and it must not be mistaken for a
 * failed evaluation by a handler that reports exceptions. Recognized by
 * `name`, never `instanceof`, across plugin-bundle boundaries.
 */
class SymbolicRecursion {
  readonly name = 'SymbolicRecursion';
  /** The structural hash of the literal whose application is abandoned. */
  constructor(readonly literal: number) {}
}

/**
 * Applications of each literal currently on the evaluation stack, keyed by
 * the literal's structural hash rather than its identity: a literal with a
 * function-typed parameter is rebuilt on every application (its inferred
 * type changes), so the object the outer and the inner application see is
 * not the same one, while its structure is. Entries are removed when the
 * outermost application exits, so the map never grows.
 */
const activeApplications = new Map<number, number>();

/**
 * The call frames of the applications whose statements are awaited
 * (`ApplyOptions.awaitStatements`) and have not ended, each with the
 * structural hash of its literal, and the number of such applications for
 * each hash.
 *
 * `activeApplications` counts an awaited application for its synchronous
 * part only (see `guardSymbolicRecursion`), so it does not see a recursive
 * application that the body of an awaited application starts in a later
 * time slice. That application runs on a copy of the context stack of its
 * caller, which holds the frame of each enclosing application. An
 * application is thus inside an awaited application of its own literal when
 * one of the frames of its context stack is in this map with the same hash
 * (`insideAwaitedApplication()`). A concurrent evaluation has its own
 * context stack, which does not hold these frames, so it does not see them.
 * The count only makes the test cheap when no awaited application of the
 * literal is in flight.
 */
const awaitedFrames = new WeakMap<Scope, number>();
const awaitedApplicationCount = new Map<number, number>();

/** Is one of the frames of `contexts` the call frame of an application of
 * the literal with the structural hash `literal` whose statements are
 * awaited (`awaitedFrames`)? */
function insideAwaitedApplication(
  literal: number,
  contexts: ReadonlyArray<{ lexicalScope: Scope }>
): boolean {
  if (!awaitedApplicationCount.has(literal)) return false;
  return contexts.some((c) => awaitedFrames.get(c.lexicalScope) === literal);
}

/** An application of a literal whose statements are awaited
 * (`ApplyOptions.awaitStatements`): its call frame, and a promise that is
 * settled when the application ends. */
type AsyncApplication = {
  frame: Scope;
  done: Promise<void>;
  finish: () => void;
};

/**
 * For each body scope, the applications of its literal whose statements are
 * awaited and have not ended, the most recent last.
 *
 * The applications of one body scope with awaited statements end in the
 * reverse order of their start. The application of a recursive call in the
 * body starts in the call frame of the most recent application and ends
 * before it: it can be suspended too. Another application (from a
 * concurrent evaluation, or from a call that the body starts without
 * waiting for the result, such as the elements of a broadcast) waits until
 * the most recent application ends (`blockingAsyncApplication()`), and is
 * then awaited too: with `h(n) = AsyncOnly(n)`, two overlapping
 * `h(1).evaluateAsync()` and `h(2).evaluateAsync()` both evaluate
 * `AsyncOnly`.
 *
 * The scope object is the key, not the structural hash of the literal: an
 * identical literal on another engine, or a second definition with the same
 * text on this one, has its own body scope and does not wait.
 */
const asyncInFlight = new WeakMap<object, AsyncApplication[]>();

/**
 * The most recent application of the literal whose body scope is
 * `bodyScope` with awaited statements, when an application that starts with
 * the evaluation contexts `contexts` must wait until it ends: it is not one
 * of the call frames of `contexts`. `undefined` when the application can
 * start now.
 */
function blockingAsyncApplication(
  bodyScope: Scope,
  contexts: ReadonlyArray<{ lexicalScope: Scope }>
): AsyncApplication | undefined {
  const inFlight = asyncInFlight.get(bodyScope);
  const last = inFlight?.[inFlight.length - 1];
  if (last === undefined) return undefined;
  return contexts.some((c) => c.lexicalScope === last.frame) ? undefined : last;
}

/**
 * Does an evaluated argument contain a free symbol — a symbol occurrence,
 * not bound by a binder inside the argument, whose binding has no value? That
 * is the argument a recursive definition is not unrolled over.
 *
 * Deliberately not `expr.unknowns`: that resolves each name in the current
 * evaluation context, and inside the body of `R(i,x,y)` the caller's `x`
 * looks bound — to the frame's own parameter `x` — so every argument would
 * count as ground. A symbol node's `value` instead follows the binding the
 * node denotes (a foreign parameter activation is skipped;
 * `valueDefinitionInContext`, `binders.ts`); a constant without a stored
 * value (`True`) and the absence marker `Nothing` are values, not unknowns.
 * Names bound inside the argument
 * (a closed literal's parameters, a `Sum` index) are shadowed as the walk
 * descends, so a closed callback literal is ground; dictionary values are
 * walked like operands, since a dictionary is not a function node.
 */
function containsFreeSymbol(
  expr: Expression,
  shadowed?: ReadonlySet<string>,
  // Per-call memo of the answer for a function node under a given set of
  // shadowed names: an argument that shares its operands (the previous
  // result of the very function being applied, embedded once per mention of
  // the parameter) is walked once per node, not once per path — the same
  // hazard `rewriteWithBinders` guards against, and an evaluated argument is
  // exactly such a value.
  memo: Map<Expression, Map<string, boolean>> = new Map()
): boolean {
  if (isSymbol(expr)) {
    if (shadowed?.has(expr.symbol)) return false;
    // A constant (`True`, `False`, `π`) is a value whether or not it stores
    // one, and `Nothing` is the absence marker, not an unknown.
    if (expr.valueDefinition?.isConstant || expr.symbol === 'Nothing')
      return false;
    return expr.value === undefined;
  }
  if (!isFunction(expr) && !isDictionary(expr)) return false;
  // Written-out data (a list or tuple of numbers, strings and failed cells,
  // `_isLiteralData()`) holds no symbol. Its answer is decided once per node,
  // so a recursion that passes a long list to each call does not walk the
  // list again at each call.
  if (isFunction(expr) && expr._isLiteralData()) return false;
  // A dictionary and a function node are memoized alike: a shared dictionary
  // reached on several paths is walked once too.
  const key = shadowedKey(shadowed);
  const hit = memo.get(expr)?.get(key);
  if (hit !== undefined) return hit;
  let result: boolean;
  if (isDictionary(expr))
    result = expr.values.some((v) => containsFreeSymbol(v, shadowed, memo));
  else {
    // A bound name shadows the operands it is IN SCOPE in
    // (`boundVariableNamesInOperand`): an iterator clause's index does not
    // shadow an earlier clause's collection or guard.
    const binds = boundVariableNames(expr);
    // The clause ordering is read once per node, not once per operand.
    const binders =
      binds.length > 0 ? declaredBinders(expr, 'post') : undefined;
    result = expr.ops.some((op, i) => {
      const here =
        binders === undefined
          ? binds
          : boundVariableNamesInOperand(expr, i, binders);
      const inner =
        here.length > 0
          ? new Set(shadowed ? [...shadowed, ...here] : here)
          : shadowed;
      // The bounds of a `Limits` clause and the collection of an `Element`
      // clause are outside the scope of the clause's own index
      // (`ownIndexClause()`, `binding-sites.ts`).
      const own = ownIndexClauseAt(expr, i, binders);
      if (own !== undefined)
        return someOwnIndexClause(op, own, shadowed, inner, (o, s) =>
          containsFreeSymbol(o, s, memo)
        );
      return containsFreeSymbol(op, inner, memo);
    });
  }
  let byShadowing = memo.get(expr);
  if (byShadowing === undefined) {
    byShadowing = new Map();
    memo.set(expr, byShadowing);
  }
  byShadowing.set(key, result);
  return result;
}

/**
 * Count the applications of `literal` on the stack around `fn`, and turn a
 * `SymbolicRecursion` raised for it inside the OUTERMOST application into a
 * decline (`undefined` — the application stays inert). See
 * `SymbolicRecursion`.
 */
function guardSymbolicRecursion(
  literal: Expression,
  fn: (
    params: ReadonlyArray<Expression>,
    options?: ApplyOptions
  ) => Expression | undefined
): (
  params: ReadonlyArray<Expression>,
  options?: ApplyOptions
) => Expression | undefined {
  const key = literal.hash;
  return (params, options) => {
    const depth = activeApplications.get(key) ?? 0;
    // An application inside an awaited application of the same literal
    // (`awaitedFrames`) is not the outermost one, whatever the count of
    // `activeApplications` is: the outermost application is the awaited
    // one, and it declines.
    const enclosed = insideAwaitedApplication(
      key,
      options?._contextStack ?? literal.engine._evalContextStack
    );
    activeApplications.set(key, depth + 1);
    try {
      // An application that answers a `Promise` (`awaitStatements`) is
      // counted for its synchronous part only: a count held while it is
      // suspended would make a concurrent application with a free symbol
      // in an argument (`f(y)` on this engine, or on another engine with an
      // identical literal, since the map is keyed by hash) throw instead of
      // staying inert. The applications its body makes in later time slices
      // find its frame on their context stack (`insideAwaitedApplication`).
      // A `SymbolicRecursion` that one of them raises rejects the `Promise`
      // of this application, and the outermost application declines.
      const result = fn(params, options);
      if (!enclosed && isThenable(result))
        return (result as unknown as Promise<Expression | undefined>).catch(
          (e: unknown) => {
            if (e instanceof SymbolicRecursion && e.literal === key)
              return undefined;
            throw e;
          }
        ) as unknown as Expression;
      return result;
    } catch (e) {
      if (
        e instanceof SymbolicRecursion &&
        e.literal === key &&
        depth === 0 &&
        !enclosed
      )
        return undefined;
      throw e;
    } finally {
      if (depth === 0) activeApplications.delete(key);
      else activeApplications.set(key, depth);
    }
  };
}

/**
 * Thrown by the substitution of the parameter values into the result of an
 * application (`bindingKeyedSubs`) when it cannot decide, before the result
 * runs, how to substitute the values correctly: how to rename a binder of
 * the result so that the binder does not capture a name of a value, or how
 * to keep a parameter that the result writes. Caught by
 * `declineUnavoidableCapture` around the application, which then declines:
 * the application stays inert and gives no value, as for a
 * `SymbolicRecursion`. A wrong value, or an error for the user, is never the
 * answer. The cases are listed in the doc comments of `bindingKeyedSubs`,
 * `captureAvoidingBinderVisitor` and `renameBoundVariables`.
 *
 * The substitution runs after the body of the application, so a decline
 * does not undo what the body did: an assignment of the body to a symbol of
 * an enclosing scope stays done. Each evaluation of the inert application
 * runs the body again, and does it again.
 *
 * Not an `Error`: it is control flow, like `SymbolicRecursion`.
 */
class UnavoidableCapture {
  readonly name = 'UnavoidableCapture';
}

/**
 * The application `fn`, with an `UnavoidableCapture` that it raises turned
 * into a decline (`undefined`: the application stays inert). The signal is
 * caught by the application that raised it: an application in the body of
 * another one has its own wrapper, so only that inner application declines.
 * An application that answers a `Promise` (`awaitStatements`) declines when
 * the `Promise` is rejected with the signal.
 */
function declineUnavoidableCapture(
  fn: (
    params: ReadonlyArray<Expression>,
    options?: ApplyOptions
  ) => Expression | undefined
): (
  params: ReadonlyArray<Expression>,
  options?: ApplyOptions
) => Expression | undefined {
  return (params, options) => {
    try {
      const result = fn(params, options);
      if (isThenable(result))
        return (result as unknown as Promise<Expression | undefined>).catch(
          (e: unknown) => {
            if (e instanceof UnavoidableCapture) return undefined;
            throw e;
          }
        ) as unknown as Expression;
      return result;
    } catch (e) {
      if (e instanceof UnavoidableCapture) return undefined;
      throw e;
    }
  };
}

/**
 * Wrap a lambda so each invocation is counted against `recursionLimit`: a
 * runaway user-function recursion (`f(x) := … f(x-1) …` with no reachable base
 * case) throws a `CancellationError` (`cause: 'recursion-depth-exceeded'`)
 * instead of overflowing the native JS call stack with a `RangeError`.
 *
 * Each level of a recursion uses several kilobytes of the JavaScript stack
 * (about 4 KB for `f(n) := n f(n-1)`), and the size of the stack depends on
 * the host. The JavaScript stack can thus be full before the depth reaches
 * the limit: with a stack of about 1 MB (the Node default), `f(2)` used to
 * overflow at a depth of about 230, below the default limit of 256. Two
 * mechanisms give the same `CancellationError` in that case:
 * - `ce._enterRecursion()` throws it when less than 64 KB of the stack is
 *   free (`enterRecursion()`, `engine-runtime-state.ts`), so the `finally`
 *   blocks of every level have room to run;
 * - when the stack overflows anyway (a single level used more than 64 KB),
 *   the first application that the overflow reaches converts it, so the
 *   frames above see a cancellation, which every handler lets through, and
 *   not a native fault, which a built-in handler would turn into an
 *   `internal-error` value. A `RangeError` that is not a stack overflow is
 *   not converted.
 */
function wrapRecursion(
  ce: ComputeEngine,
  fn: (
    params: ReadonlyArray<Expression>,
    options?: ApplyOptions
  ) => Expression | undefined
): (
  params: ReadonlyArray<Expression>,
  options?: ApplyOptions
) => Expression | undefined {
  return (params, options) => {
    // An application that answers a `Promise` (`awaitStatements`) holds
    // its level of the counter for its synchronous part only, so the
    // counter does not see the depth of a recursion whose levels run in
    // later time slices. Each such level runs on a copy of the context
    // stack of its caller with a `call` frame for each enclosing
    // application, so the depth is the number of those frames.
    if (
      options?.awaitStatements === true &&
      callFrameCount(options._contextStack ?? ce._evalContextStack) >=
        ce.recursionLimit
    )
      throw recursionLimitError();
    const depth = ce._enterRecursion();
    try {
      // An application that answers a `Promise` (`awaitStatements`) holds
      // its level for its synchronous part only: the recursion limit guards
      // the synchronous call stack, and the applications its body makes in
      // later time slices enter and leave the recursion themselves.
      return fn(params, options);
    } catch (e) {
      if (isStackOverflow(e)) throw recursionLimitError();
      throw e;
    } finally {
      ce._exitRecursion(depth);
    }
  };
}

/** The number of user-function call frames (the contexts named `call`) on
 * an evaluation-context stack. */
function callFrameCount(
  stack: ReadonlyArray<{ name: undefined | string }>
): number {
  let count = 0;
  for (const context of stack) if (context.name === 'call') count += 1;
  return count;
}

/**
 * For the body scope of each function literal that is being applied, the
 * number of applications of that literal currently on the stack.
 */
const appliedBodyScopes = new WeakMap<Scope, { count: number }>();

/** Record an application of the literal whose body scope is `bodyScope`. */
function enterAppliedBodyScope(bodyScope: Scope): void {
  const entry = appliedBodyScopes.get(bodyScope);
  if (entry === undefined) appliedBodyScopes.set(bodyScope, { count: 1 });
  else entry.count += 1;
}

function exitAppliedBodyScope(bodyScope: Scope): void {
  const entry = appliedBodyScopes.get(bodyScope);
  if (entry === undefined) return;
  if (entry.count > 1) entry.count -= 1;
  else {
    appliedBodyScopes.delete(bodyScope);
    forgetBodyScopeApplied(bodyScope);
  }
}

/**
 * The parent of every call frame of the function literal whose body scope is
 * `bodyScope`: the activation that a function value keeps, or, for a literal
 * that is not a function value (held unevaluated in a lazy collection), the
 * activation of its defining scope on the links from the current lexical
 * scope (`activationOnLinks`), or that scope itself.
 */
function definingScopeOf(ce: ComputeEngine, bodyScope: Scope): Scope | null {
  const scope = bodyScope.parent;
  if (!scope) return scope;
  return activationOnLinks(ce.context.lexicalScope, scope);
}

/**
 * The scope where the function literal `literal` was defined, or
 * `undefined` when `literal` is not a function literal with a scoped body.
 */
export function functionLiteralDefiningScope(
  literal: Expression | undefined
): Scope | undefined {
  if (!isFunction(literal, 'Function')) return undefined;
  const body = literal.op1;
  if (!isFunction(body) || !body.localScope) return undefined;
  return body.localScope.parent ?? undefined;
}

/**
 * The closure that the evaluation of the function literal `fn` creates, or
 * `undefined` when the literal is its own value: a function value, which
 * keeps the activation it was made in (`captureNestedLocals()`), evaluates
 * to itself. The `Function` handler calls it.
 */
export function captureAtCreation(
  ce: ComputeEngine,
  fn: Expression | undefined
): Expression | undefined {
  if (fn === undefined || keepsActivation(fn)) return undefined;
  return captureNestedLocals(ce, fn);
}

/**
 * True when `expr` is a function value that keeps the activation it was
 * made in: the scope of its body stands for the body scope of a literal
 * (`registerFunctionValueScope()`), and its parent is that activation. Such
 * a value evaluates to itself.
 */
function keepsActivation(expr: Expression): boolean {
  if (!isFunction(expr, 'Function')) return false;
  const scope = expr.op1.localScope;
  return scope !== undefined && functionValueTemplateOf(scope) !== undefined;
}

/** The body scope of the literal that `scope` stands for: the body scope
 * of the literal a function value was made from, or `scope` itself. */
function bodyScopeTemplate(scope: Scope): Scope {
  return functionValueTemplateOf(scope) ?? scope;
}

/**
 * The function value that the evaluation of the function literal `fn`
 * makes when the scope it is written in is a block, a loop or a binder that
 * is being evaluated, or `undefined` when there is none. The value keeps the
 * activation of that scope (and, through its links, the activations it was
 * evaluated in): its body reads the locals of this run of the block and the
 * variables of this iteration of a binder (`renewIterationActivation()`),
 * also after the run ends. Two closures made by the same run share its
 * locals, and a write that follows the creation is visible to both.
 *
 * The value is the literal with a new body `Block`: the same operands, on a
 * new scope whose parent is the activation and that stands for the body
 * scope of the literal (`registerFunctionValueScope()`). The operands and
 * the scoped nodes nested in them are those of the literal. A rebuild of
 * the value (`subs()`, `simplify()`) keeps the scope of its body, so it
 * keeps the activation.
 */
export function captureNestedLocals(
  ce: ComputeEngine,
  fn: Expression | undefined
): Expression | undefined {
  if (fn === undefined || !isFunction(fn, 'Function')) return undefined;
  const block = fn.op1;
  if (!isFunction(block)) return undefined;
  const scope = block.localScope;
  if (!scope?.parent) return undefined;
  const live = activationOnLinks(ce.context.lexicalScope, scope.parent);
  if (
    scopeActivationTemplate(live) === undefined &&
    callFrameBodyOf(live) === undefined
  )
    return undefined;
  const valueScope: Scope = { ...scope, parent: live };
  registerFunctionValueScope(valueScope, scope);
  const body = ce._fn('Block', block.ops, {
    scope: valueScope,
    metadata: { sourceOffsets: block.sourceOffsets },
  });
  return ce._fn('Function', [body, ...fn.ops.slice(1)], {
    metadata: { sourceOffsets: fn.sourceOffsets },
  });
}

/**
 * For the body of each function literal, the lazy callback views of the body
 * that a lazy operator of the body holds (see `heldLazyViewsOf`), or `null`
 * when it has none. Computed once per body.
 */
const HELD_LAZY_VIEWS = new WeakMap<
  Expression,
  ReadonlySet<Expression> | null
>();

/** Whether the operands of `expr` stay as they are written when `expr` is
 * evaluated: an operator with lazy operands, or a lazy collection that keeps
 * its source. */
function holdsItsOperands(expr: Expression): boolean {
  const def = expr.operatorDefinition;
  return def?.lazy === true || def?.collection?.isLazy !== undefined;
}

/**
 * The lazy callback views of the function body `body` that are an operand
 * of an operator of the body that holds its operands (`Dedup(Map(f, xs))`,
 * `Take(Map(f, xs), 2)`), or `null` when there is none. Such a view is not
 * evaluated when the body is, so it has no record (see
 * `adoptHeldLazyViews`). The walk does not go into a function literal (its
 * body is evaluated, and adopts its views, when it is applied) and goes
 * into the values of a dictionary.
 */
function heldLazyViewsOf(body: Expression): ReadonlySet<Expression> | null {
  const known = HELD_LAZY_VIEWS.get(body);
  if (known !== undefined) return known;
  let held: Set<Expression> | null = null;
  const seen = new Set<Expression>();
  const visit = (expr: Expression): void => {
    if (seen.has(expr)) return;
    seen.add(expr);
    if (isDictionary(expr)) {
      for (const key of expr.keys) visit(expr.get(key)!);
      return;
    }
    if (!isFunction(expr) || !canHoldLazyView(expr)) return;
    const holds = holdsItsOperands(expr);
    for (const op of expr.ops) {
      if (holds && isLazyCallbackView(op)) (held ??= new Set()).add(op);
      visit(op);
    }
  };
  visit(body);
  HELD_LAZY_VIEWS.set(body, held);
  return held;
}

/**
 * The value `result` that a call of the function whose body is `body`
 * returns, where each view of the call that was never evaluated and has no
 * record is replaced by a new node that has a record of this call
 * (`adoptLazyView`, `boxed-expression/lazy-view-context.ts`), on the context
 * stack `stack` of the call, whose frame is `frame`. Such a view is read
 * later, and was written in this call: it calls its callback in the context
 * of this call, as an evaluated view does. The views of the call are:
 *
 * - a held view of the body (`heldLazyViewsOf`). A new node is needed
 *   because the held node is a node of the function body, which every call
 *   of the function shares;
 * - a view canonicalized during this call (`wasCanonicalizedIn`), such as
 *   the `Map` of `ReleaseHold(Hold(Dedup(Map(f, xs))))`, which is not a
 *   node of the body.
 *
 * The nodes above a replaced node are rebuilt on their own scope, and keep
 * their own record. A view that the call did not make (the value of a
 * symbol that the body reads, made at the top level or in another call) is
 * kept.
 *
 * A body with no held view, in a call where each view that it canonicalized
 * has a record (the result of an evaluation, such as the view that the
 * evaluation of `Map(f, xs)` returns, gets one at once), costs two lookups.
 * Otherwise the walk goes into the operands of each node of `result` that
 * can hold a view (`canHoldLazyView`) and into the values of a dictionary,
 * once per node, and allocates only for a node that changes.
 */
function adoptHeldLazyViews(
  ce: ComputeEngine,
  result: Expression,
  body: Expression,
  stack: ReadonlyArray<ComputeEngine['_evalContextStack'][number]>,
  frame: Scope
): Expression {
  const held = heldLazyViewsOf(body);
  const canonicalized = canonicalizedLazyViewsIn(frame);
  if (held === null && !canonicalized) return result;
  const memo = new Map<Expression, Expression>();
  const visit = (expr: Expression): Expression => {
    const known = memo.get(expr);
    if (known !== undefined) return known;
    let next = expr;
    if (isDictionary(expr)) {
      const keys = expr.keys;
      let values: Expression[] | undefined;
      keys.forEach((key, i) => {
        const value = expr.get(key)!;
        const v = visit(value);
        if (v !== value && values === undefined)
          values = keys.slice(0, i).map((k) => expr.get(k)!);
        values?.push(v);
      });
      if (values !== undefined)
        next = ce.function(
          'Dictionary',
          keys.map((key, i) =>
            ce._fn('KeyValuePair', [ce.string(key), values![i]])
          )
        );
    } else if (isFunction(expr) && canHoldLazyView(expr)) {
      let ops: Expression[] | undefined;
      expr.ops.forEach((op, i) => {
        const v = visit(op);
        if (v !== op && ops === undefined) ops = expr.ops.slice(0, i);
        ops?.push(v);
      });
      const adopt =
        (held?.has(expr) === true ||
          (canonicalized &&
            isLazyCallbackView(expr) &&
            wasCanonicalizedIn(expr, frame))) &&
        !hasLazyViewRecord(expr);
      if (ops !== undefined || adopt) {
        next = ce._fn(expr.operator, ops ?? [...expr.ops], {
          scope: expr.localScope,
        });
        shareLazyViewRecord(expr, next);
        if (adopt) adoptLazyView(next, stack);
      }
    }
    memo.set(expr, next);
    return next;
  };
  return visit(result);
}

/**
 * Substitute, in a HELD argument, every symbol bound in the CALLER's frames
 * that the callee cannot reach: a symbol whose live binding is found on the
 * current (caller's) scope chain but not on `captured` — the callee's
 * defining scope chain, which is what its call frame will chain to. The
 * substituted expression is that binding's value: for a hold parameter of the
 * calling function, the expression IT was handed (inlined recursively, so a
 * chain of forwarding hold functions collapses to the original argument); for
 * a `let` local, its stored value. A binding without a value (a valueless
 * declaration) is left as the symbol.
 *
 * Symbols shadowed by a binder inside the argument (`Sum(x^2, x, 1, n)`'s
 * `x`) are never touched — `rewriteWithBinders` reports them — and a symbol
 * whose binding is reachable from `captured` stays symbolic: that is the
 * ordinary case (`hold f(e) = e; f(a + 1)` keeps `a + 1`), and it is why this
 * is a substitution of FRAME-LOCALS only, not an evaluation. The recursion
 * is bounded by the set of the definitions being inlined on the current
 * path, so a frame-local whose value mentions itself cannot loop.
 *
 * The inlined value of a definition does not depend on where it occurs, so
 * it is computed once per top-level call (`memo`), and a chain of locals
 * that each call the previous one twice is inlined in linear time. A value
 * whose computation stopped at a definition of the current path depends on
 * that path, and is not kept.
 */
function inlineFrameLocals(
  ce: ComputeEngine,
  expr: Expression,
  captured: Scope | null | undefined,
  visited: Set<BoxedValueDefinition> = new Set(),
  memo: Map<BoxedValueDefinition, Expression> = new Map(),
  cuts: { count: number } = { count: 0 }
): Expression {
  const reachableFrom = (
    start: Scope | null | undefined,
    name: string,
    own: BoxedValueDefinition
  ): BoxedValueDefinition | undefined => {
    for (let s = start; s; s = s.parent) {
      const found = s.bindings.get(name);
      if (
        found !== undefined &&
        'value' in found &&
        sameBindingDef(found.value, own)
      )
        return found.value;
    }
    return undefined;
  };
  // The value of the caller-frame binding `own` of `name`, inlined, or
  // `undefined` when the name stays.
  const frameValue = (
    name: string,
    own: BoxedValueDefinition | undefined,
    shadowed: ReadonlySet<string> | undefined
  ): Expression | undefined => {
    if (shadowed?.has(name) || own === undefined) return undefined;
    if (reachableFrom(captured, name, own) !== undefined) return undefined;
    const live = reachableFrom(ce.context.lexicalScope, name, own);
    if (live === undefined) return undefined;
    if (visited.has(live)) {
      cuts.count += 1;
      return undefined;
    }
    const known = memo.get(live);
    if (known !== undefined) return known;
    const value = live.value;
    if (value === undefined) return undefined;
    // `visited` holds the definitions being inlined on the current path
    // only: a second occurrence of the same local beside this one is
    // inlined too.
    visited.add(live);
    const cutsBefore = cuts.count;
    try {
      const inlined = inlineFrameLocals(
        ce,
        value,
        captured,
        visited,
        memo,
        cuts
      );
      if (cuts.count === cutsBefore) memo.set(live, inlined);
      return inlined;
    } finally {
      visited.delete(live);
    }
  };
  return rewriteWithBinders(
    expr,
    (sym, shadowed) =>
      frameValue(sym.symbol, sym.valueDefinition, shadowed) ?? sym,
    undefined,
    false,
    new Map(),
    // A call whose head is such a binding (`g(k)` with `g` a local that
    // holds a function) applies its value.
    (app, ops, shadowed) => {
      const value = frameValue(app.operator, app.valueDefinition, shadowed);
      return value === undefined
        ? undefined
        : ce.function('Apply', [value, ...ops]);
    }
  );
}

/**
 * The value that a `hold` application binds to a parameter for the held
 * argument `arg`: the argument as written, bound (`.canonical`), with each
 * symbol bound in the caller's frames that the callee cannot reach replaced
 * by its value (`inlineFrameLocals`). `captured` is the scope the literal
 * was defined in.
 */
function heldArgumentValue(
  ce: ComputeEngine,
  arg: Expression,
  captured: Scope | null | undefined
): Expression {
  return inlineFrameLocals(ce, arg.canonical, captured);
}

/**
 * Replace, in a HELD operand, each symbol that denotes a parameter of a
 * running function call with the value that the call bound to it.
 *
 * A lazy operator that transforms its operand as written (`ReplaceAll`) sees
 * a parameter of the enclosing function as the bare symbol: in
 * `x ↦ ReplaceAll(x, a → b)` applied to `a`, the rules are matched against
 * the symbol `x`, find nothing to replace, and the call returns `a`. A
 * function literal means the same as its body with the arguments put in
 * place of the parameters (Wolfram's `Function[x, x /. a -> b][a]` is `b`),
 * and the value of a call already reads that way after the body has run: a
 * parameter left in the result, also inside a held operand, is replaced by
 * its argument (`bindingKeyedSubs`), so `x ↦ Hold(x)` applied to `3` is
 * `Hold(3)`. This gives the same reading to the operand BEFORE the operator
 * transforms it.
 *
 * Only parameters are replaced. A `let` local of the body and a top-level
 * symbol with an assigned value stay symbols, as a held operand keeps them
 * everywhere else (`x := 5; ReplaceAll(x^2, x → 3)` is `9`). This differs
 * from Wolfram, where `t = a; t /. a -> b` is `b`; the user decided on
 * 2026-10-24 to keep both cases as they are (GitHub issue #476).
 *
 * An occurrence is a parameter when the binding that its NAME resolves to on
 * the current scope chain is a parameter activation, and the occurrence
 * carries that binding or no binding at all (a raw operand, as the box route
 * hands it over, is not bound yet). A symbol below a binder that binds its
 * name (`Sum(x^2, x, 1, n)`) is left alone; the binder is seen only in a
 * canonical `expr`, so canonicalize a raw operand first.
 *
 * With `keepWildcards`, a symbol whose name starts with `_` is left alone:
 * in the left side of a rule it is a pattern wildcard, also when an
 * anonymous function took it as its parameter.
 */
export function inlineCallParameters(
  ce: ComputeEngine,
  expr: Expression,
  options?: { keepWildcards?: boolean }
): Expression {
  return rewriteWithBinders(expr, (sym, shadowed) => {
    const name = sym.symbol;
    if (shadowed?.has(name)) return sym;
    if (options?.keepWildcards && name.startsWith('_')) return sym;
    let live: BoxedValueDefinition | undefined;
    for (
      let s: Scope | null | undefined = ce.context.lexicalScope;
      s;
      s = s.parent
    ) {
      const found = s.bindings.get(name);
      if (found === undefined) continue;
      if ('value' in found) live = found.value;
      break;
    }
    if (live === undefined || !isParameterActivation(live)) return sym;
    // A free name (`isFreeName()`, `binding-unit.ts`) carries no binding,
    // but it is not a raw operand: it was boxed outside the function
    // literal, so it never denotes a parameter.
    if (isFreeName(sym)) return sym;
    const own = sym.valueDefinition;
    if (own !== undefined && !sameBindingDef(own, live)) return sym;
    return live.storedValue ?? sym;
  });
}

/**
 * The value of a call of a function literal when a captured symbol of its
 * body (`capturedSymbols()`) holds, at the time of the call, a value that
 * is not of the type the body was typed with: an `incompatible-type` error,
 * as a library operator gives for an operand of the wrong type. `undefined`
 * when each captured value is of its type.
 *
 * The type of the literal relies on the type of each captured symbol. A
 * free name of the body reads the binding that its name has in the scope
 * that the literal is written in, and an assignment of a value of another
 * type to that binding changes its type, and so the type of the literal.
 * But a value can reach a binding without changing its type: a host that
 * writes the value of a definition directly. Without this check,
 * the call then gave a value outside its static type.
 *
 * `capturedScope` is the scope the literal was defined in, the parent of
 * each call frame: the body reads a captured symbol there.
 * (User decision 2026-10-25, option (c) of CE-473 in `ROADMAP.md`.)
 */
function capturedValueMismatch(
  ce: ComputeEngine,
  fnExpr: Expression & FunctionInterface,
  capturedScope: Scope
): Expression | undefined {
  const mismatch = capturedValueMismatchEntry(fnExpr, capturedScope);
  if (mismatch === undefined) return undefined;
  return ce.typeError(
    mismatch.expected.type,
    mismatch.value.type,
    mismatch.value
  );
}

/**
 * True when `def` holds the function literal `value` under a declared
 * signature with a placeholder (`_signatureSkeleton`, a declared
 * `-> unknown` result), and the signature that `def` derives from `value`
 * is of the type `expected`.
 *
 * A function literal is stored without the declared types of its scalar
 * parameters, so its own type reads each such parameter as `unknown` and
 * can have a wider result: with `f` declared
 * `(real | signed_infinity | nan) -> unknown`, `f := x ↦ x + A cos(x) + d`
 * is stored with the type `(x: unknown) -> number`. The definition reports
 * the result under the declared parameters, `nan | real | signed_infinity`,
 * which is the type that `ce.assign()` accepted, and a body that reads `f`
 * is typed with it. The definition derives that signature again from the
 * stored literal when a symbol the literal reads changes type (`A` assigned
 * a complex value gives `-> number`), so such a change is still a mismatch.
 * The derivation is memoized on the definition, so this check does not box
 * the literal again on each call.
 * (`_deriveSignature()`, `boxed-expression/boxed-value-definition.ts`.)
 *
 * The check is relaxed only when `def.type` is that derivation: the
 * declared result is the placeholder `unknown` (a skeleton whose only
 * placeholder is a parameter keeps its declared result, which says nothing
 * about the value), the type is declared and not inferred (an inferred type
 * is the recorded type, not derived from the literal), and `value` is the
 * stored value that the derivation reads (not an assumed value).
 */
function derivedSignatureMatches(
  def: BoxedValueDefinition,
  value: Expression,
  expected: Expression['type']
): boolean {
  if (!isFunction(value, 'Function')) return false;
  const skeleton = def._signatureSkeleton;
  if (
    typeof skeleton !== 'object' ||
    skeleton.kind !== 'signature' ||
    skeleton.result !== 'unknown' ||
    def.inferredType ||
    def.storedValue !== value
  )
    return false;
  const derived = def.type;
  return (
    derived.matches(expected) ||
    derived.matches(stripNumericRanges(expected.type))
  );
}

/**
 * The first captured symbol of `fnExpr` whose value is not of the type the
 * body was typed with: its name, that type, and the value it holds. This is
 * the test of `capturedValueMismatch()`, with the evidence that a message
 * can name. `undefined` when each captured value is of its type.
 */
function capturedValueMismatchEntry(
  fnExpr: Expression & FunctionInterface,
  capturedScope: Scope
):
  | { name: string; expected: Expression['type']; value: Expression }
  | undefined {
  if (CALLER_CHECKED.has(fnExpr)) return undefined;
  const captured = capturedSymbols(fnExpr);
  if (captured.length === 0) return undefined;
  for (const { name, occurrence } of captured) {
    let binding: BoxedDefinition | undefined;
    for (let s: Scope | null | undefined = capturedScope; s; s = s.parent) {
      binding = s.bindings.get(name);
      if (binding !== undefined) break;
    }
    if (binding === undefined || !('value' in binding)) continue;
    const def = binding.value;
    // A constant has a library value that no host writes. A held symbol is
    // read as the symbol, not as its value.
    if (def.isConstant) continue;
    if (def.holdUntil !== 'evaluate' && def.holdUntil !== 'never') continue;
    const value = def.value;
    if (value === undefined || value.operator === 'Unevaluated') continue;
    // A value that the store admitted only because its type OVERLAPS the
    // declared type of the symbol (`storeAdmission()` in
    // `effects-inference.ts`) has a type outside the type the body was typed
    // with by design. It is not a mismatch here: the read of the symbol in
    // the body tests the evaluated value against the declared type
    // (`BoxedSymbol._testedRead()`) and gives the `incompatible-type` error
    // when the value is outside it. Example: with `a: real` and
    // `P: tuple<real, real> := (-sqrt(1 - a^2), a)`, a call of
    // `t ↦ P + (t, t)` gives a point when `a = 0.5` and the error when
    // `a = 5`. The value is skipped only when that read tests it
    // (`isTestedAtRead()`): a symbol whose type was inferred from its value
    // has no declared type to test against.
    if (isTestedAtRead(def, value)) continue;
    const expected = occurrence.type;
    // A value of type `unknown` (an expression whose type is not inferred
    // yet) gives no evidence of a mismatch. The ranges of a numeric type are
    // not compared: the type of a number value does not always carry its
    // value (the index `i` of `Sum(…, (i, 1, 3))` is typed `integer<1..3>`,
    // and the value `1` that it holds can be typed `integer`).
    //
    // The `missing` arms of the value's type are removed before the
    // comparison, at the top and in every element or component: a declared
    // type cannot name `missing`, and a value can still hold the marker (a
    // selection with no match gives `Missing` in a cell of a non-numeric
    // list). So `cd: list<color>` at `[Missing, Rgb(0, 1, 0)]` (type
    // `list<color | missing>`) is read by a function literal, as the store
    // check `matchesOrAbsent()` (`effects-inference.ts`) accepts it and as
    // the compile check `assertHeldValueType()` (`compile-inner.ts`) reads
    // it. The type compared is the type the value presents
    // (`presentedValueType()`): a value typed `missing` alone passes, and a
    // number held through a restriction is read as the literal it holds, as
    // in the store check and the compile check. ROADMAP CE-791.
    const present = presentedValueType(fnExpr.engine, value);
    if (
      expected.isUnknown ||
      present.isUnknown ||
      present.matches(expected) ||
      present.matches(stripNumericRanges(expected.type))
    )
      continue;
    if (derivedSignatureMatches(def, value, expected)) continue;
    return { name, expected, value };
  }
  return undefined;
}

/**
 * The function literals whose call is checked by its caller, with the
 * number of such calls running. The caller (a call of a named definition,
 * `withCallerCapturedCheck()`) compares the value of the call with the
 * static type of the call node, which describes a mapped or a partial
 * application too, so the literal does not refuse the call itself
 * (`capturedValueMismatch()`).
 */
const CALLER_CHECKED = new Map<Expression, number>();

/**
 * Run `f`, a call of the canonical function literal `literal` whose caller
 * checks the value against the static type of the call node, with the check
 * of the literal itself (`capturedValueMismatch()`) turned off for
 * `literal`. A `Promise` answer turns the check on again when it settles.
 */
export function withCallerCapturedCheck<T>(literal: Expression, f: () => T): T {
  CALLER_CHECKED.set(literal, (CALLER_CHECKED.get(literal) ?? 0) + 1);
  const release = () => {
    const n = (CALLER_CHECKED.get(literal) ?? 1) - 1;
    if (n <= 0) CALLER_CHECKED.delete(literal);
    else CALLER_CHECKED.set(literal, n);
  };
  let result: T;
  try {
    result = f();
  } catch (e) {
    release();
    throw e;
  }
  if (result instanceof Promise) {
    return result.finally(release) as unknown as T;
  }
  release();
  return result;
}

/**
 * True when a captured symbol of the canonical function literal `literal`
 * holds now a value that is not of the type the body was typed with
 * (`capturedValueMismatch()`), read in the scope the literal was defined in.
 */
export function capturedValueMismatchNow(literal: Expression): boolean {
  return capturedValueMismatchNowEntry(literal) !== undefined;
}

/**
 * The first captured symbol of the canonical function literal `literal`
 * that holds now a value that is not of the type the body was typed with:
 * its name, that type, and the value. This is the test of
 * `capturedValueMismatchNow()`, with the evidence that a message can name.
 */
export function capturedValueMismatchNowEntry(
  literal: Expression
):
  | { name: string; expected: Expression['type']; value: Expression }
  | undefined {
  if (!isFunction(literal, 'Function')) return undefined;
  const body = literal.ops[0];
  if (!body.isScoped || body.localScope === undefined) return undefined;
  const ce = literal.engine;
  const capturedScope =
    definingScopeOf(ce, body.localScope) ?? ce.context.lexicalScope;
  const fnExpr = literal as Expression & FunctionInterface;
  if (CALLER_CHECKED.has(fnExpr)) {
    // The check of the literal is off while its caller runs; ask it anyway.
    const n = CALLER_CHECKED.get(fnExpr)!;
    CALLER_CHECKED.delete(fnExpr);
    try {
      return capturedValueMismatchEntry(fnExpr, capturedScope);
    } finally {
      CALLER_CHECKED.set(fnExpr, n);
    }
  }
  return capturedValueMismatchEntry(fnExpr, capturedScope);
}

function makeLambda(
  expr: Expression,
  errorPolicy: ErrorArgPolicy = 'bubble'
):
  | ((
      params: ReadonlyArray<Expression>,
      options?: ApplyOptions
    ) => Expression | undefined)
  | undefined {
  const ce = expr.engine;

  // If the expression is a symbol, interpret it as an operator
  if (isSymbol(expr)) {
    const sym = expr.symbol;
    return (args, options) => {
      const own =
        expr.valueDefinition !== undefined
          ? { value: expr.valueDefinition }
          : expr.operatorDefinition !== undefined
            ? { operator: expr.operatorDefinition }
            : undefined;
      const binding = callableBindingInContext(ce, sym, own, expr);
      // On the asynchronous route (`awaitStatements`), `applyNamedLiteral`
      // declines, and the call is awaited (`awaitedApplication`): an
      // operator that has only an `evaluateAsync` handler is evaluated, so
      // `1 |> f` is `f(1)` under `evaluateAsync()`.
      const answer = applyNamedLiteral(ce, sym, args, options, binding);
      if (answer !== undefined) return answer;
      const call = callableApplication(ce, sym, args, binding, expr);
      if (options?.awaitStatements) return awaitedApplication(call, options);
      return call.evaluate(options);
    };
  }

  const canonicalExpr = canonicalFunctionLiteral(expr);
  // Not a function literal (e.g. a bare string or number): decline so callers
  // fall through to their symbolic `Apply(fn, args)` fallback instead of
  // throwing (`apply()` uses `makeLambda(fn)?.(...)`).
  if (!canonicalExpr) return undefined;

  expr = canonicalExpr;

  // An expression that DENOTES a function without being a literal (a
  // qualified protocol member `Comparable.compare`, `InverseFunction(f)`, …)
  // came back unchanged from `canonicalFunctionLiteral` (its case 5.5). It
  // cannot be beta-reduced here: apply it through `Apply`, whose strict
  // evaluation reduces the callee to its function value first (a qualified
  // member evaluates to the protocol-dispatching literal), then applies.
  if (expr.operator !== 'Function') {
    const fnExpr = expr;
    return (args, options) => {
      const call = ce.function('Apply', [fnExpr, ...args]);
      if (options?.awaitStatements) return awaitedApplication(call, options);
      return call.evaluate(options);
    };
  }

  console.assert(expr.operator === 'Function');
  console.assert(expr.isCanonical);

  // expr is a canonical Function expression — it satisfies FunctionInterface
  const fnExpr = expr as Expression & FunctionInterface;

  //
  // No parameters (nullary function). Extra arguments are ignored (historical
  // contract). Two cases:
  //
  if (fnExpr.ops.length === 1) {
    console.assert(fnExpr.ops[0] !== undefined);
    const onlyBody = fnExpr.ops[0];

    // (a) The body is not a scoped Block: there is no per-call local state to
    //     instantiate, so evaluate it directly (fast path for plain thunks and
    //     bare-expression bodies).
    if (!onlyBody.isScoped || !onlyBody.localScope)
      return wrapRecursion(ce, (_args, options) => onlyBody.evaluate(options));

    // (b) The body IS a scoped Block: it may declare mutable locals (`let`)
    //     captured by an escaping closure — e.g. a counter factory
    //     `() => do { let count = 0; () => do { count = count + 1; count } }`.
    //     Those locals must live in a fresh per-call scope so separate
    //     invocations don't share state. Evaluate the block's statements in a
    //     fresh scope (parent = the defining scope), as the parameterized
    //     `invoke` path below does: a function value made in the body keeps
    //     that scope. Unlike `invoke`, arguments are ignored rather than
    //     arity-checked, preserving the nullary contract.
    const nullaryBody = onlyBody as Expression & FunctionInterface;
    return wrapRecursion(ce, (_args, options) => {
      const bodyScope = bodyScopeTemplate(nullaryBody.localScope!);
      const capturedScope =
        definingScopeOf(ce, nullaryBody.localScope!) ?? ce.context.lexicalScope;
      const mismatch = capturedValueMismatch(ce, fnExpr, capturedScope);
      if (mismatch !== undefined) return mismatch;
      const freshScope: Scope = { parent: capturedScope, bindings: new Map() };
      addCallFrame(freshScope);
      // No frame reads this scope until it is pushed (`pending-call-scopes.ts`).
      notePendingCallScope(freshScope);
      enterAppliedBodyScope(bodyScope);
      noteBodyScopeApplied(ce, bodyScope);
      // The frame is an activation of the body scope: the `Declare`
      // statements of the body write the values of its locals there, as on
      // the parameterized `invoke` path.
      holdBodyLocals(freshScope, bodyScope);
      noteCallFrame(freshScope, bodyScope);
      // Named 'call': a function-application activation frame. The debugger's
      // statement hook uses this to delimit stack frames (one per
      // activation — nested unnamed Block/loop contexts group into it).
      ce.pushScope(freshScope, 'call');
      let result: Expression;
      try {
        // The last statement of the body takes the numeric request itself
        // (see `resultStatementRequest`); the statements before it run
        // exactly.
        result = unwrapReturn(
          ce,
          evaluateStatements(
            ce,
            nullaryBody.ops,
            resultStatementRequest(fnExpr, nullaryBody.ops, options)
          )
        );
        result = resolveEscapingLambda(ce, result);
        // A held view of the body gets a record of this call.
        result = adoptHeldLazyViews(
          ce,
          result,
          nullaryBody,
          ce._evalContextStack,
          freshScope
        );
        if (options?.numericApproximation)
          result = result.evaluate({ numericApproximation: true });
      } finally {
        ce.popScope();
        exitAppliedBodyScope(bodyScope);
      }
      return bodyResultValue(result);
    });
  }

  const [body, ...params] = fnExpr.ops;

  console.assert(body.isScoped);
  if (!body.localScope)
    throw new Error('Function body must be a scoped Block expression');

  // body is a Block (scoped) — safe to access .ops and .localScope
  const bodyFn = body as Expression & FunctionInterface;
  // The body scope of the literal, also for a function value, whose own body
  // scope stands for it and is read only for its parent: a call frame
  // applies it, and the scopes nested in the body have it as their parent.
  const bodyScope = bodyScopeTemplate(bodyFn.localScope!);

  // Apply-time enforcement (§6.4) is a strict-mode feature gated on the literal
  // carrying at least one annotated parameter — untyped literals skip it
  // entirely (zero overhead). Computed once; `ce.strict` is re-checked at
  // invocation time.
  const hasAnnotatedParam = params.some(
    (p) => functionLiteralParameterType(p) !== undefined
  );

  // The index of the REST parameter (`(a, ...rest) => …`), or `-1` when the
  // literal has none. Canonicalization guarantees there is at most one and
  // that it is the last operand, so this index is also the number of FIXED
  // parameters the call must supply before the rest parameter takes over.
  const restIndex = params.findIndex((p) => isRestParameter(p));

  // The number of parameters before the first parameter with a default value
  // (`["Optional", k, 2]`). A call with at least this many arguments is a
  // full call: `withDefaults` gives each parameter with a default that the
  // call leaves out its default operand, before the arguments are evaluated,
  // so the body always has every parameter bound. A call with fewer
  // arguments is a partial application (step 3 of `invoke`).
  const withDefaults = (
    args: ReadonlyArray<Expression>
  ): ReadonlyArray<Expression> => literalArgumentsWithDefaults(params, args);

  // A GENERIC literal has no annotated parameter to gate on — erasure removed
  // them — yet its polytype marker IS a contract, and an ANONYMOUS application
  // (`Apply(Function(…), …)`) never passes a symbol's boxed-definition seam
  // where the check would otherwise happen. So the apply-time validation gate
  // widens to the marker (§2.5): `fnExpr.type.type` is then the polytype, and
  // `_validateArguments` is already polytype-aware.
  const declaredSignature = functionLiteralDeclaredSignature(fnExpr);
  const isGenericLiteral =
    declaredSignature !== undefined &&
    (declaredSignature.typeParams?.length ?? 0) > 0;
  const validateApplication = hasAnnotatedParam || isGenericLiteral;
  // The checks of the arguments of a call read the parameters of the
  // signature and never its result, so they do not type the body. The
  // parameters are kept until the type generation moves
  // (`_typeCacheGeneration()`). That key is enough: the slots it does not
  // follow are those of the parameters with no annotation, and each check
  // below relaxes them; the annotated slots and the rest tail are fixed for
  // the literal. A literal with a full-signature marker states its parameters
  // in its type, and a read made while the type of the literal is being
  // computed gets what the type gives at that time.
  let parameterSignatureCell:
    { generation: number; signature: Type } | undefined;
  const parameterSignature = (): Type => {
    if (
      declaredSignature !== undefined ||
      (fnExpr as { _isTypeInFlight?: () => boolean })._isTypeInFlight?.()
    )
      return fnExpr.type.type;
    const generation = ce._typeCacheGeneration();
    if (parameterSignatureCell?.generation !== generation)
      parameterSignatureCell = {
        generation,
        signature:
          functionLiteralParameterSignature(fnExpr) ?? fnExpr.type.type,
      };
    return parameterSignatureCell.signature;
  };

  // A BARE parameter of a PARTIALLY annotated literal imposes NO constraint
  // (ruled 2026-08-09). The §6.4 gate above is all-or-nothing — one annotation
  // turns validation on for EVERY parameter — but a bare parameter's signature
  // slot is only whatever inference left there (`unknown` by default), which is
  // not a contract its author wrote. Validating against it rejects values that
  // are legitimately unconstrained: `nothing` is deliberately not a subtype of
  // `unknown`, so `Reduce(xs, (acc, n: integer) => acc + n)` errored with
  // `incompatible-type unknown nothing` on the sentinel a seedless fold used to
  // start from. So for VALIDATION ONLY, a bare parameter's slot is relaxed to
  // `any`; annotated parameters keep their exact enforcement, and the literal's
  // reported type is untouched.
  //
  // Skipped entirely when the literal carries a whole-signature marker (§2.5):
  // there the arrow IS the contract for every position, annotated operand or
  // not (a GENERIC literal's parameter annotations were erased — relaxing them
  // would silently disable its check).
  const bareParamIndexes =
    declaredSignature === undefined
      ? params.reduce<number[]>((acc, p, i) => {
          if (functionLiteralParameterType(p) === undefined) acc.push(i);
          return acc;
        }, [])
      : [];

  /** `t` with the argument slot of each parameter in `indexes` widened to
   * `any`. */
  const relaxParamSlots = (t: Type, indexes: ReadonlyArray<number>): Type => {
    if (indexes.length === 0) return t;
    if (typeof t === 'string' || t.kind !== 'signature') return t;
    // The slots of the parameters with a default value are in `optArgs`,
    // after the required ones: slot `i` of `optArgs` is the parameter at
    // position `args.length + i`.
    const args = t.args ?? [];
    const optArgs = t.optArgs ?? [];
    if (args.length + optArgs.length === 0) return t;
    let changed = false;
    const relax = (arg: NamedElement, i: number): NamedElement => {
      if (!indexes.includes(i)) return arg;
      changed = true;
      return { ...arg, type: 'any' as Type };
    };
    const relaxed = args.map(relax);
    const relaxedOpt = optArgs.map((arg, i) => relax(arg, args.length + i));
    // A signature rebuilt field-by-field must carry its adjuncts; the spread
    // does that (`typeParams`, `effects`).
    return changed
      ? {
          ...t,
          ...(t.args !== undefined ? { args: relaxed } : {}),
          ...(t.optArgs !== undefined ? { optArgs: relaxedOpt } : {}),
        }
      : t;
  };
  const relaxBareParams = (t: Type): Type =>
    relaxParamSlots(t, bareParamIndexes);

  // The parameters with no annotation that the author wrote: a bare parameter,
  // and a parameter annotated by element-type inference (`Filter(C, z ↦ …)`).
  // Only an annotation of the author makes a call wait for a later value
  // (step 4b below). The type that inference wrote is only a reading of the
  // current collection, and a function literal without an annotation applies
  // its body to a symbolic argument.
  //
  // The signature of a generic literal is a contract for every position: a
  // parameter that mentions a type variable has no annotation left to read, and
  // its slot in the signature is exempt from the check. The argument list of a
  // non-generic whole-signature marker is not a contract for a bare parameter.
  const unannotatedParamIndexes = isGenericLiteral
    ? []
    : params.reduce<number[]>((acc, p, i) => {
        if (
          functionLiteralParameterType(p) === undefined ||
          isInferredTypedParameter(optionalParameterTarget(p))
        )
          acc.push(i);
        return acc;
      }, []);
  const hasAuthorAnnotation =
    validateApplication && unannotatedParamIndexes.length < params.length;

  // The parameters annotated with a NUMERIC type (`x: number`, `n: integer`,
  // `t: real`). Two values that are not members of such a type are accepted
  // there:
  //
  // - The absent value `Missing`. A call with `Missing` at such a parameter
  //   is `Missing`, as an operator over `Missing` gives `Missing`, whatever
  //   the body: `f(x: number) = x + 1` and `(x: integer) ↦ [x]` answer
  //   `Missing` for `Missing` (`docs/ERROR-MODEL.md`, "`Missing` is a result
  //   only — user decision of 2026-11-02", which replaces the reading of
  //   2026-09-30 that `Missing` is bound as `NaN` there). A partial
  //   application binds it, and the validation is told to skip it
  //   (`acceptNaNAtNumericParams`).
  // - `NaN`, whatever the numeric type: it is what a numeric computation
  //   answers when it has no value (a restricted number whose condition
  //   fails, a read past the end of a list of numbers), and `f(n: integer)`
  //   must not refuse it where `f(n: number)` runs. `nan` is not a member
  //   of `integer` or `real` in the type lattice, so the validation is told
  //   to skip it (`acceptNaNAtNumericParams`). A number that is not `NaN` is
  //   still checked: `f(n: integer)` refuses `1.5`.
  //
  // At a parameter annotated as a point (a tuple of numbers, `pointArity()`)
  // a call with `Missing` is `Missing` too (`absentResultParamIndexes`).
  // A `NaN` point (a tuple whose coordinates are all `NaN`, the value of a
  // read past the end of a list of points) is accepted there, as `NaN` is
  // at a numeric parameter, and the body runs with it: with
  // `f = (p: tuple<real, real>) ↦ PointX(p)`, `f(At([(1, 2)], 5))` is
  // `NaN`. The scalar `NaN` is still refused there: it is not a point.
  // At a parameter annotated
  // with any other type (a list, a string) the absent value stays as it is,
  // and the validation refuses it with `incompatible-type` unless the
  // annotation has a `missing` member.
  //
  // The indexes are positions in `params`, which pair one to one with the
  // leading arguments and with the argument slots of the literal's
  // signature (`args`, then `optArgs`). A rest parameter takes no annotation, so it is never in the
  // list, and it is the last parameter, so it does not shift the others.
  const numericParamIndexes = params.reduce<number[]>((acc, p, i) => {
    const t = functionLiteralParameterType(p);
    if (t !== undefined && isSubtype(t, 'number')) acc.push(i);
    return acc;
  }, []);
  /** The parameters annotated as a point, where a `NaN` point is accepted. */
  const pointParamIndexes = params.reduce<number[]>((acc, p, i) => {
    const t = functionLiteralParameterType(p);
    if (t !== undefined && pointArity(t) !== undefined) acc.push(i);
    return acc;
  }, []);
  /** The parameters where `Missing` makes the call `Missing`: the numeric
   * parameters and the parameters annotated as a point. */
  const absentResultParamIndexes = params.reduce<number[]>((acc, p, i) => {
    const t = functionLiteralParameterType(p);
    if (
      t !== undefined &&
      (isSubtype(t, 'number') || pointArity(t) !== undefined)
    )
      acc.push(i);
    return acc;
  }, []);
  /** `t` with the slot of each numeric parameter whose argument in `values`
   * is `NaN` or `Missing`, and of each point parameter whose argument is a
   * `NaN` point, widened to `any`, so that the validation accepts that
   * value. */
  const acceptNaNAtNumericParams = (
    t: Type,
    values: ReadonlyArray<Expression>
  ): Type => {
    if (numericParamIndexes.length === 0 && pointParamIndexes.length === 0)
      return t;
    if (typeof t === 'string' || t.kind !== 'signature') return t;
    // Slot `i` of `optArgs` (the parameters with a default value) is the
    // parameter at position `args.length + i`.
    const args = t.args ?? [];
    const optArgs = t.optArgs ?? [];
    if (args.length + optArgs.length === 0) return t;
    let changed = false;
    const accept = (arg: NamedElement, i: number): NamedElement => {
      const v = values[i];
      if (v === undefined) return arg;
      const admitted = numericParamIndexes.includes(i)
        ? v.isNaN === true || isAbsentSymbol(v)
        : pointParamIndexes.includes(i) && isNaNPointValue(v);
      if (!admitted) return arg;
      changed = true;
      return { ...arg, type: 'any' as Type };
    };
    const accepted = args.map(accept);
    const acceptedOpt = optArgs.map((arg, i) => accept(arg, args.length + i));
    return changed
      ? {
          ...t,
          ...(t.args !== undefined ? { args: accepted } : {}),
          ...(t.optArgs !== undefined ? { optArgs: acceptedOpt } : {}),
        }
      : t;
  };

  // The return-type ascription operand (§4.2 marker: the last Block statement
  // wrapped in `["Typed", stmt, type]`), reused verbatim when re-attaching the
  // return type onto a curried literal (§6.5 point 3). `undefined` when the
  // literal has no return ascription.
  const lastStatement = bodyFn.ops[bodyFn.ops.length - 1];
  const returnTypeOp = isFunction(lastStatement, 'Typed')
    ? lastStatement.op2
    : undefined;

  const invokeWithBoundVariables = (
    args: ReadonlyArray<Expression>,
    options: ApplyOptions
  ): Expression | undefined => {
    const bound = new Set(options.bindParameters);
    const substitutions: Record<string, Expression> = {};
    const keptParams: Expression[] = [];
    const keptArgs: Expression[] = [];
    for (let i = 0; i < params.length; i++) {
      const name = functionLiteralParameterName(params[i]);
      const arg = args[i];
      if (name !== undefined && bound.has(name)) {
        // No argument at a bound position (partial application) leaves the
        // parameter in place — nothing to substitute yet.
        if (arg === undefined) {
          keptParams.push(params[i]);
          continue;
        }
        substitutions[name] = arg;
        continue;
      }
      // A held argument is put in the body as the caller boxed it, with its
      // bindings: a binder of the body built around it binds the occurrences
      // of its variable there (`Sum(body, i, 1, n)` with `body` the caller's
      // `k^2`, and `i` the caller's `k`). A name bound in the caller's
      // frames, which the callee does not reach, is replaced by its value
      // (`heldArgumentValue()`), as for an application with no bound
      // variable.
      if (options.holdArguments && name !== undefined && arg !== undefined) {
        substitutions[name] = heldArgumentValue(
          ce,
          arg,
          definingScopeOf(ce, bodyFn.localScope!) ?? ce.context.lexicalScope
        );
        continue;
      }
      keptParams.push(params[i]);
      if (arg !== undefined) keptArgs.push(arg);
    }
    if (Object.keys(substitutions).length === 0)
      return invoke(args, { ...options, bindParameters: undefined });
    // Substitute the caller's symbols for the bound parameters in the body —
    // EVERY occurrence of the name, binder positions and shadowed occurrences
    // included: `bind i` means "the name the body uses as a bound variable",
    // and in `Sum(body, i, 1, n)` that `i` is Sum's own index (Sum's binder
    // claims it at definition time, shadowing the parameter), which is
    // precisely the occurrence that must become the caller's `k`. Then
    // rebuild the literal without those parameters; canonicalizing it in the
    // CALLER's context (the current one) is where the body's binder
    // (`Sum(body, k, 1, n)`) declares the caller's `k`. A binder of the
    // body whose variable is substituted gets a copy of its scope in each
    // call: the scope declares the variable under its new name, with the
    // type of this call (`integer<1..n>` of a `Sum` index), and a later call
    // would read that declaration in a shared scope.
    const copies = new WeakSet<Expression>();
    const newBody = rewriteWithBinders(
      body,
      (sym) => substitutions[sym.symbol] ?? sym,
      undefined,
      false,
      new Map(),
      undefined,
      (node) => {
        if (
          copies.has(node) ||
          !isFunction(node) ||
          node.localScope === undefined ||
          !boundVariableNames(node).some(
            (name) => bound.has(name) && substitutions[name] !== undefined
          )
        )
          return undefined;
        const copy = ce._fn(node.operator, [...node.ops], {
          scope: {
            ...node.localScope,
            bindings: new Map(node.localScope.bindings),
          },
        });
        copies.add(copy);
        return copy;
      }
    );
    const reduced = ce.function('Function', [newBody, ...keptParams]);
    return apply(reduced, keptArgs, {
      ...options,
      bindParameters: undefined,
    });
  };

  // The element function of a lazy `Map` under `.N()` is a literal whose
  // body is the numeric marker, `NumericApproximation(e)`
  // (`lazyMapNumericApproximation` and `lazyBroadcastMap` in
  // `collection-utils.ts`). An application of this literal gives the `.N()`
  // of `e` with the arguments AS WRITTEN in place of the parameters, so that
  // `Map(f, [v]).N()` is `[f(v).N()]`. The arguments are not evaluated
  // before they are put in `e`:
  // - an exact evaluation can be slow: with `H = Sum(1/k, k, 1, 6000)`, the
  //   exact value of `H` is a rational with thousands of digits, and
  //   `Sin(H).N()` reads `H` numerically;
  // - a numeric evaluation loses the exact structure that a function reads
  //   under `.N()`: `Sin(Pi).N()` is `0` (the float of π gives `1.2e-16` at
  //   machine precision), `Floor((25! − 1)/24!).N()` is `24` (the float of
  //   the argument is `25`), and `Numerator(v).N()` is the numerator of the
  //   exact `v`.
  // `markerBody` is `e`, or `undefined` when the body is not the marker.
  const markerOp = bodyFn.ops.length === 1 ? bodyFn.ops[0] : undefined;
  const markerBody =
    markerOp !== undefined &&
    isFunction(markerOp, 'NumericApproximation') &&
    markerOp.nops === 1
      ? markerOp.op1
      : undefined;

  /**
   * The value of an application of the literal with the numeric marker
   * (`markerBody` above): the `.N()` of the marker's operand, with each
   * argument as written in place of its parameter. `undefined` when the
   * application must take the ordinary route, which evaluates the
   * arguments exactly and binds them in a call frame: an application with
   * awaited arguments, or a substitution that is not safe
   * (`substitutedBody`).
   */
  const applyMarkerBody = (
    args: ReadonlyArray<Expression>,
    options: ApplyOptions | undefined,
    iterationStatements: ReadonlyArray<Expression> | undefined
  ): Expression | undefined => {
    if (markerBody === undefined || options?.awaitStatements) return undefined;
    // The substituted body is canonicalized and evaluated in a scope whose
    // parent is the scope where the literal was defined, as a call frame is
    // (and as in `applyWrittenArguments`). A function that the body calls
    // reads the locals of that scope only through this chain:
    // `Block(Declare(c, 'real', 5), DefineFunction(h, k ↦ c + k), Map(k ↦ h(k) + 1, [1, 2]))`
    // is `[7, 8]` with `evaluateAsync({ numericApproximation: true })`.
    const callerScope = ce.context.lexicalScope;
    const capturedScope =
      definingScopeOf(ce, bodyFn.localScope!) ?? callerScope;
    // A name that an argument reads (a symbol, or the function of a call
    // such as `h(1)`) is read by name in this scope too. When the scope
    // where the literal was defined binds such a name to another definition
    // than the one the argument is bound to, the ordinary route applies: its
    // call frame reads each argument in the scope of the caller. Evaluating
    // the body in the scope of the caller instead is not sound either: for
    // a lazy `Map` read after its `Block` returned, that is the scope of the
    // reader, where the locals of the block are free symbols. An argument
    // with no name (the elements of a list of numbers) costs no lookup.
    const switchScope = capturedScope !== callerScope;
    if (
      switchScope &&
      ce._inScope(capturedScope, () =>
        args.some((arg) => readsOtherBindings(ce, arg))
      )
    )
      return undefined;
    if (switchScope)
      ce.pushScope({ parent: capturedScope, bindings: new Map() });
    try {
      const applied = substitutedBody(
        markerBody,
        args,
        options,
        iterationStatements
      );
      // As the evaluate handler of `NumericApproximation` does.
      return applied === undefined ? undefined : bodyResultValue(applied.N());
    } finally {
      if (switchScope) ce.popScope();
    }
  };

  /**
   * `e`, an expression of the body, with each of `values` in place of its
   * parameter, canonical. `undefined` when the substitution is not safe, and
   * the application must then take the ordinary route, which binds the
   * arguments in a call frame:
   * - a parameter that is not a plain symbol (an annotated, destructuring
   *   or rest parameter), or a count of values that is not the count of
   *   parameters: the ordinary route validates, destructures and collects;
   * - a body or a value that is not pure: a value put in two places is
   *   evaluated two times, and an effect of the body belongs in a call
   *   frame;
   * - a value that has a symbol of `e`: the substitution could put it
   *   under a binder of `e` that has the same name (the index of a `Sum`);
   * - an application with held arguments, the statements of a loop, or an
   *   active debugger, which need the call frame.
   */
  const substitutedBody = (
    e: Expression,
    values: ReadonlyArray<Expression>,
    options: ApplyOptions | undefined,
    iterationStatements: ReadonlyArray<Expression> | undefined
  ): Expression | undefined => {
    if (
      iterationStatements !== undefined ||
      options?.holdArguments ||
      restIndex >= 0 ||
      validateApplication ||
      values.length !== params.length ||
      debugStatementHook !== undefined ||
      debugStatementResultHook !== undefined ||
      !isPureComputedEffects(effectsOf(body))
    )
      return undefined;
    const bodySymbols = new Set(e.symbols);
    const written = new Map<string, Expression>();
    for (let i = 0; i < params.length; i++) {
      // A parameter with a default value is read inside its `Optional`
      // wrapper; its value is the default when the call left it out.
      const param = optionalParameterTarget(params[i]);
      const value = values[i];
      if (!isSymbol(param) || !value.isPure) return undefined;
      if (value.symbols.some((s) => bodySymbols.has(s))) return undefined;
      written.set(param.symbol, value);
    }
    // A binder of `e` that binds the name of a parameter (`x ↦ D(x^2, x)`)
    // makes the substitution not safe: its occurrences are not replaced, but
    // the value of `D`, of `Series` or of an indefinite `Integrate` is an
    // expression in that name, which then denotes the parameter. The
    // substituted `D(x^2, x)` gave `2x` under `.N()`, not the derivative at
    // the argument. The call frame replaces such occurrences.
    let bindsParameter = false;
    const applied = rewriteWithBinders(e, (sym, shadowed) => {
      if (!shadowed?.has(sym.symbol)) return written.get(sym.symbol) ?? sym;
      if (written.has(sym.symbol)) bindsParameter = true;
      return sym;
    });
    if (bindsParameter) return undefined;
    return applied.canonical;
  };

  // The one statement of the body, when the body is a single expression
  // with no return-type ascription and no `Return`.
  const onlyStatement =
    bodyFn.ops.length === 1 &&
    !isFunction(bodyFn.ops[0], 'Typed') &&
    !isFunction(bodyFn.ops[0], 'Return')
      ? bodyFn.ops[0]
      : undefined;

  /**
   * The part of an application memo key that `args` give, or `undefined`
   * when the application is not memoized: an argument is not a number
   * literal, the application runs the statements of a loop, or the body is
   * not pure. Purity is read per application (see `invoke`). The part
   * says whether the assumptions are hidden right now, and spells `-0`
   * apart from `0`, which `JSON.stringify` would collapse. It also says
   * whether the statements are awaited and the body applies an operator
   * that has only an `evaluateAsync` handler (`asyncOnly`): the synchronous
   * route leaves such an application unevaluated, and its answer must not
   * be served to the asynchronous route, or the reverse.
   */
  const applicationMemoArgs = (
    args: ReadonlyArray<Expression>,
    iterationStatements: ReadonlyArray<Expression> | undefined,
    asyncOnly = false
  ): string | undefined =>
    iterationStatements === undefined &&
    args.every((a) => isNumber(a)) &&
    isPureComputedEffects(effectsOf(body))
      ? `${asyncOnly ? 'A' : ''}${ce._factsHidden() ? 'H' : ''}|${args
          .map((a) => (Object.is(a.re, -0) ? '-0' : JSON.stringify(a.json)))
          .join('|')}`
      : undefined;

  /**
   * Under `.N()`, the value of an application whose written arguments
   * (`ApplyOptions.exactSources`, `exactArgumentSources`) are not all
   * equal to their approximations: the `.N()` of the body with the written
   * arguments in place of the parameters (`substitutedBody`). This is what
   * the element function of a lazy `Map` does (`applyMarkerBody`), so that
   * `f(v).N()`, `Apply(f, v).N()` and `Map(f, [v]).N()` agree. The caller
   * has approximated the arguments already, and an approximation loses the
   * exact structure that the body reads under `.N()`: at machine precision
   * the float of π gives `Sin(x)` the value `1.2e-16` where `Sin(Pi).N()`
   * is `0`, and the float of `(25! − 1)/24!` is the integer 25, whose
   * numerator is 25. `undefined` when the ordinary route applies:
   * - the request is exact, or no written argument is known;
   * - each written argument is the same as its approximation (an integer,
   *   a float): the ordinary route gives the same value, and it keeps the
   *   application memo;
   * - a value has a free symbol: the ordinary route does not unroll a
   *   recursion over it (`SymbolicRecursion`);
   * - a written argument costs much to approximate a second time
   *   (`isCheapWrittenArgument`);
   * - the body has more than one statement, or it applies this literal: a
   *   recursive body runs exactly in its call frame, and memoizes its exact
   *   value (`resultStatementRequest`);
   * - the substitution is not safe (`substitutedBody`);
   * - with `awaitStatements`, a body that is not short.
   * With `awaitStatements`, the answer is a `Promise`, as on the ordinary
   * route.
   */
  const applyWrittenArguments = (
    args: ReadonlyArray<Expression>,
    options: ApplyOptions | undefined,
    iterationStatements: ReadonlyArray<Expression> | undefined
  ): Expression | undefined => {
    const sources = options?.exactSources;
    if (
      options?.numericApproximation !== true ||
      onlyStatement === undefined ||
      sources === undefined ||
      sources.length !== args.length ||
      !sources.some((s, i) => s !== undefined && !isSameWritten(s, args[i]))
    )
      return undefined;
    const values = args.map((arg, i) => sources[i] ?? arg);
    if (values.some((v) => containsFreeSymbol(v))) return undefined;
    if (!sources.every((s) => s === undefined || isCheapWrittenArgument(s)))
      return undefined;
    if (appliesLiteral(onlyStatement, fnExpr)) return undefined;
    // The asynchronous route yields between time slices while the body
    // runs. The body is evaluated here synchronously, so it must be short:
    // it applies library operators only, and no scoped operator. It must
    // also apply no operator that has only an `evaluateAsync` handler,
    // which the synchronous evaluation leaves unevaluated.
    if (
      options.awaitStatements &&
      (!isCheapWrittenArgument(onlyStatement) ||
        hasAsyncOnlyApplication(onlyStatement, true))
    )
      return undefined;
    // The application memo, as on the ordinary route (`invoke`): a body
    // with no recursion that is called many times with the same exact
    // argument under `.N()` (`f(3/7)` in each term of a sum) is evaluated
    // once. The key is spelled from the written values, and it starts with
    // `W`, so it never matches an entry of an exact request (`E`) or of an
    // ordinary numeric request (`N`), whose arguments are the
    // approximations. No key is made when the substitution below can
    // decline for a reason that changes from one call to the next (held
    // arguments, the statements of a loop, an active debugger): an entry is
    // stored only after the substitution succeeded.
    const memoArgs =
      options.holdArguments ||
      debugStatementHook !== undefined ||
      debugStatementResultHook !== undefined
        ? undefined
        : applicationMemoArgs(values, iterationStatements);
    const memoKey =
      memoArgs === undefined
        ? undefined
        : `W${ce.precision}:${ce._requestedPrecision ?? ''}${memoArgs}`;
    const hit =
      memoKey === undefined
        ? undefined
        : validApplicationMemo(ce, fnExpr)?.results.get(memoKey);
    if (hit !== undefined)
      return options.awaitStatements
        ? (Promise.resolve(hit) as unknown as Expression)
        : hit;
    // A body that evaluates a host operator that does not state
    // `pure: true`, or the handler of one that states it but changed state,
    // is not memoized (`host-handler-changes.ts`), nor a body that read a
    // provisional answer (`store-guard.ts`).
    const guard = beginStoreGuard();
    // The substituted body is canonicalized and evaluated in a scope whose
    // parent is the scope where the literal was defined, as a call frame
    // is: a name of the body that is not a parameter (a local of the
    // `Block` that made the literal, read after the `Block` returned)
    // resolves there, not in the scope of the caller.
    const capturedScope =
      definingScopeOf(ce, bodyFn.localScope!) ?? ce.context.lexicalScope;
    ce.pushScope({ parent: capturedScope, bindings: new Map() });
    // A result that reads a frame of a call made from here is not kept by
    // the memo (`holdsFrameSince`).
    const firstFrameSerial = nextCallFrameSerial;
    let result: Expression | undefined;
    try {
      result = substitutedBody(
        onlyStatement,
        values,
        options,
        iterationStatements
      )?.N();
    } finally {
      ce.popScope();
    }
    if (result === undefined) return undefined;
    result = bodyResultValue(result);
    // A read of a sequence term that was stopped in this application is not
    // memoized, as on the ordinary route (`sequence-read-stops.ts`).
    // A re-entrant evaluation of a lazy collection node and a re-entrant
    // read of a signature are accepted, as on the ordinary route below.
    if (
      memoKey !== undefined &&
      result.isValid &&
      guard.movedOnly('lazyValueProvisional', 'reentrantSignature') &&
      // No frame was made: the walk is not needed.
      (nextCallFrameSerial === firstFrameSerial ||
        !holdsFrameSince(result, firstFrameSerial))
    )
      applicationMemoForStore(ce, fnExpr)?.results.set(memoKey, result);
    // The lambda is typed synchronous: a `Promise` comes back only for the
    // caller that set `awaitStatements`.
    if (options.awaitStatements)
      return Promise.resolve(result) as unknown as Expression;
    return result;
  };

  const invoke = (
    args: ReadonlyArray<Expression>,
    options?: ApplyOptions,
    iterationStatements?: ReadonlyArray<Expression>
  ): Expression | undefined => {
    args = withDefaults(args);
    // BOUND-VARIABLE parameters (`bindParameters`) are eliminated first, by
    // substitution: the parameter is replaced in the body by the symbol the
    // caller passed (every occurrence of the name, inner binders included —
    // see `invokeWithBoundVariables`), and the reduced literal — without that
    // parameter — is applied to the remaining arguments under the same
    // options. The caller (`selectAndApply`) has already checked that each
    // such argument is a symbol.
    if (
      options?.bindParameters !== undefined &&
      options.bindParameters.length > 0
    )
      return invokeWithBoundVariables(args, options);

    // An application with awaited statements waits until the suspended
    // application of this literal that blocks it ends (see `asyncInFlight`),
    // and then starts again.
    if (
      options?.awaitStatements === true &&
      options._effects !== undefined &&
      iterationStatements === undefined
    ) {
      const {
        _effects: effects,
        _contextStack: stack,
        _precisionWindow: precision,
      } = options;
      const contexts = stack ?? ce._evalContextStack;
      let blocking = blockingAsyncApplication(bodyFn.localScope!, contexts);
      if (blocking !== undefined)
        return (async () => {
          while (blocking !== undefined) {
            await blocking.done;
            blocking = blockingAsyncApplication(bodyFn.localScope!, contexts);
          }
          return runWithEvaluationEffects(
            ce,
            effects,
            () => lambda(args, options),
            stack,
            precision
          );
          // The lambda is typed synchronous: a `Promise` comes back only for
          // the caller that set `awaitStatements`.
        })() as unknown as Expression;
    }

    // The scope the literal was defined in — the parent of every call frame
    // (step 5), and the chain a held argument's symbols must be resolvable
    // through (`inlineFrameLocals`).
    const capturedScope =
      definingScopeOf(ce, bodyFn.localScope!) ?? ce.context.lexicalScope;

    // A captured symbol that holds a value of a type other than the one the
    // body was typed with makes the call an error (`capturedValueMismatch`).
    const mismatch = capturedValueMismatch(ce, fnExpr, capturedScope);
    if (mismatch !== undefined) return mismatch;

    // A `hold` application binds each argument as WRITTEN. `.canonical` is
    // value-safe — it binds structure (a held operand reaching here from the
    // box or parse route is still unbound) but does not substitute assigned
    // symbol values — so the parameter ends up bound to the caller's
    // expression, and reading it in the body evaluates it there.
    //
    // One class of symbol IS substituted: a CALLER-FRAME binding — a hold
    // parameter of the calling function, or a `let` local of its body — that
    // the callee could not otherwise resolve, because a call frame chains to
    // the callee's DEFINING scope, never to the caller's (step 5 below). With
    // `hold p1(e) = Head(e); hold p3(x) = p1(x)`, the argument `x` names
    // p3's frame binding; left as the symbol, p1 would read it in a chain
    // that has no `x` (`Head(e)` → `Symbol`, and evaluation only half
    // resolves). Inlining that binding's value — the expression p3 itself
    // was handed — makes forwarding a held argument mean the same expression,
    // which is what call-by-name promises. Bindings the callee CAN reach
    // through its own chain (a top-level `let a`, or a frame binding of an
    // enclosing function the callee was defined inside) stay symbolic, so
    // `hold f(e) = e; f(a + 1)` still binds `e` to `a + 1`, not to `4`.
    //
    // An evaluated argument that is a lazy collection keeps the activation it
    // was made in (`lazy-view-context.ts`): the callee reads it there.
    const argValue = (a: Expression): Expression => {
      if (options?.holdArguments)
        return heldArgumentValue(ce, a, capturedScope);
      return a.evaluate();
    };
    //
    // 1/ If there are more arguments than expected, exit
    //
    // A literal with a REST parameter has no upper arity: the surplus is what
    // the rest parameter collects (below, after the error check).
    // The first surplus argument is the value of the application, as an
    // error: `h(1, 2, 3)` for a two-parameter `h` is
    // `Error("unexpected-argument", "3")` with the frame `(h, 3)`, as a call
    // of a declared function reports it (`checkArity()` marks the surplus
    // operand, and the call frames it). A call of a symbol that holds a
    // literal is not checked against the literal's arity when it is boxed
    // (an inferred signature carries no constraint), so this is where the
    // surplus is found. A literal with NO parameter, including the shorthand
    // constant function (`Apply(3, 5)` is `3`), ignores its arguments: it
    // takes the nullary route above, not this one. See `docs/ERROR-MODEL.md`
    // §1.
    if (restIndex < 0 && args.length > params.length) {
      const frame = options?.arityFrame;
      return withErrorFrames(
        ce.error('unexpected-argument', args[params.length].toString()),
        frame === undefined
          ? []
          : [
              {
                operator: frame.operator,
                index: frame.firstArgumentIndex + params.length,
              },
            ]
      );
    }

    //
    // 2/ An argument that is — or embeds — an `Error` (rung 2 of the
    //    error-propagation design): the application evaluates to that error
    //    value, and the body never runs. Under the `'bind'` policy the caller
    //    is an observer that has already decided on the error (a `Match` case),
    //    so it is bound like any other value.
    //
    if (errorPolicy === 'bubble') {
      const err = firstErrorArg(args);
      if (err !== undefined) return err;
      // Not dead: `errorValue` does NOT descend into collection values, so an
      // argument like `[1, "a" + 1]` is invalid without yielding an error to
      // bubble. A `List` or `Set` literal whose only errors are failed cells
      // is a collection value (`isInvalidNonCollection()` is `false` for
      // it): the body runs with it, as a `Map` callback receives the inner
      // list of `[[1, "a" + 1], [3]]` and `(u) => 1` gives `1` for it. Any
      // other invalid argument (a `Tuple` with a failed coordinate) FREEZES
      // the application (`docs/ERROR-MODEL.md` §3), so the body does not
      // run for it.
      if (ce.strict && args.some((x) => isInvalidNonCollection(x)))
        return undefined;
    }

    //
    // 2b/ A REST parameter collects every argument from its own position
    //     onwards into ONE `Tuple` argument (empty when the call supplies
    //     none). After this collapse the call is an ordinary saturated
    //     `params.length`-ary one, so steps 3 to 5 need no rest-specific case.
    //     A call with fewer arguments than the FIXED parameters takes the
    //     currying path below instead, where the rest parameter is carried
    //     into the residual literal unchanged.
    //
    // The collapse itself happens in step 4, AFTER the arguments are
    // evaluated and checked: packing the raw trailing arguments first hid an
    // argument that only became an error when evaluated (`boom() |> ((...r)
    // => 42)` on the held pipe route ran the body), because the error check
    // does not look inside a tuple.
    const saturated =
      restIndex >= 0 ? args.length >= restIndex : args.length >= params.length;

    //
    // 3/ If there are fewer arguments than expected, curry the function
    //
    if (!saturated) {
      // G5 (§2.5): a GENERIC literal is not curried. The residual literal has
      // no honest type — a variable consumed by the supplied prefix occurs
      // nowhere in the remaining arrow, so the clause is unsolvable. Fires on
      // the polytype marker regardless of `hasAnnotatedParam`: erasure leaves a
      // generic literal with no annotated parameter at all, so the prefix
      // validation below never runs for one. (Measured before the guard: the
      // residual was built by re-attaching the FULL n-ary marker onto the
      // (n-k)-ary curried literal, whose §2.3 arity check then rejected it —
      // `(_1) => Error("A function-literal signature marker must be …")`,
      // an error buried in the body rather than a diagnostic on the call.)
      // Partial INSTANTIATION is the principled lift; recorded as future work.
      if (isGenericLiteral)
        return ce.error(GENERIC_PARTIAL_APPLICATION_MESSAGE, expr.toString());

      // A function that holds its arguments is not curried: its partial
      // application is the `missing` error of the first absent argument,
      // with the frame of that argument (as `unexpected-argument` above),
      // unless a supplied argument is already an error: step 2 above returns
      // that error first, and it is the value. The
      // residual below is an ordinary function literal: a call of it
      // evaluates its own argument, and the `Apply` in its body evaluates
      // the held prefix. So its value could differ from the full call: with
      // `hf(a, b) = Head(a)` held and `c := 3`, the full call `hf(c + 1, 0)`
      // is `Add`, and a call of the residual of `hf(c + 1)` with `0` was
      // `Integer`.
      //
      // This line gives the error for a `lazy` operator whose `evaluate` is
      // a function literal and whose signature is not declared. The other
      // held routes do not come here: a declared signature, and an Epsil
      // `hold` function (`selectAndApply` in `multi-clause.ts`), check the
      // arity of the call first, and put `Error("missing")` in the place of
      // the absent argument. The three routes give the same error value.
      if (options?.holdArguments) {
        const frame = options.arityFrame;
        return withErrorFrames(
          ce.error('missing'),
          frame === undefined
            ? []
            : [
                {
                  operator: frame.operator,
                  index: frame.firstArgumentIndex + args.length,
                },
              ]
        );
      }

      // Evaluate the supplied arguments in the calling scope
      let evaluatedKnownArgs = args.map(argValue);

      // An argument that only became an error when EVALUATED (`f(g(1))` with
      // `g(1)` failing) bubbles like a literal one — see step 2.
      if (errorPolicy === 'bubble') {
        const err = firstErrorArg(evaluatedKnownArgs);
        if (err !== undefined) return err;
      }

      // Validate the applied prefix against the declared parameter types
      // (§6.4/§6.5). On mismatch, return the inert application with the
      // error-marked arguments. This form is internal: each route that
      // calls a literal gives the error itself as the value of the call
      // (`refusedLiteralArgumentError` and `_refusedArgumentError`,
      // `boxed-expression/boxed-function.ts`; `docs/ERROR-MODEL.md`).
      if (ce.strict && hasAnnotatedParam && _validateArguments) {
        const fullSig = acceptNaNAtNumericParams(
          relaxBareParams(parameterSignature()),
          evaluatedKnownArgs
        );
        if (typeof fullSig !== 'string' && fullSig.kind === 'signature') {
          const prefixSig: Type = {
            kind: 'signature',
            args: (fullSig.args ?? []).slice(0, args.length),
            // The arrow's `where` clause is an adjunct field: a signature
            // rebuilt field-by-field carries it (the rebuild invariant).
            ...(fullSig.typeParams !== undefined
              ? { typeParams: fullSig.typeParams }
              : {}),
            result: fullSig.result,
          };
          const validated = _validateArguments(
            ce,
            evaluatedKnownArgs,
            prefixSig
          );
          if (validated !== null) {
            // Any invalid operand: mismatch — return the inert application.
            // A `List` or `Set` with a failed cell is a value (see step 2).
            if (validated.some((x) => isInvalidNonCollection(x)))
              return ce._fn('Apply', [fnExpr, ...validated]);
            // All valid: an operand was substituted (e.g. devolved); proceed
            // with the substituted arguments.
            evaluatedKnownArgs = [...validated];
          }
        }
      }

      // Generate unique parameter names for the remaining (unapplied)
      // params. A name must also differ from every symbol of the supplied
      // arguments: the residual passes them next to its own parameters, so
      // with `A = (x, y) ↦ x + y`, `A(_1)` would otherwise be
      // `(_1) ↦ Apply(A, _1, _1)`, which gives `4`, not `_1 + 2`, for `2`.
      // A name must also differ from every symbol of a default value: the
      // residual keeps the defaults of its parameters, and a default that
      // names one of them is refused (`(x, k = _1) => x * k` with no
      // argument would otherwise give `(_2, Optional(_1, _1))`).
      const unappliedParams = params.slice(args.length);
      const allSymbols = new Set([
        ...body.symbols,
        ...functionLiteralBoundNames(params),
        ...evaluatedKnownArgs.flatMap((arg) => arg.symbols),
        ...params.flatMap((p) => optionalParameterDefault(p)?.symbols ?? []),
      ]);
      const extraSymbols = unappliedParams.map((_, i) => {
        let name = `_${i + 1}`;
        let counter = 0;
        while (allSymbols.has(name)) name = `_${i + 1}_${counter++}`;
        allSymbols.add(name);
        return ce.symbol(name, { canonical: false });
      });

      // The curried literal's remaining params keep their annotations (§6.5
      // point 2): an unapplied `["Typed", p, T]` is re-wrapped around the fresh
      // symbol with its original (already-normalized) type operand.
      //
      // An unapplied DESTRUCTURING parameter becomes the single fresh symbol:
      // the residual re-applies the ORIGINAL literal, which does its own
      // destructuring, so the residual's parameter receives the tuple whole.
      //
      // An unapplied REST parameter stays a rest parameter in the residual:
      // its fresh symbol is re-wrapped in `Spread`, so the residual still has
      // no upper arity and still binds a tuple of whatever the saturating call
      // supplies.
      //
      // An unapplied parameter with a default value keeps its `Optional`
      // wrapper and its default operand in the residual: the residual of
      // `((x, k = 2) => x * k)()` is `(_1, Optional(_2, 2)) => Apply(lit, _1,
      // _2)`, so a call of the residual with one argument gives `k` its
      // default.
      const extras = unappliedParams.map((param, i) => {
        if (isRestParameter(param))
          return ce._fn('Spread', [extraSymbols[i]], { canonical: false });
        const target = optionalParameterTarget(param);
        const fresh = isFunction(target, 'Typed')
          ? ce._fn('Typed', [extraSymbols[i], target.op2], { canonical: false })
          : extraSymbols[i];
        const d = optionalParameterDefault(param);
        return d === undefined
          ? fresh
          : ce._fn('Optional', [fresh, d], { canonical: false });
      });

      // The residual is DEFERRED for every body (`docs/EFFECTS-MODEL.md`,
      // "Currying / partial application"): it re-applies the ORIGINAL literal
      // to the prefix once the last argument arrives, so `(a, b) ↦ body`
      // applied to `1` becomes `(_1) ↦ Apply((a, b) ↦ body, 1, _1)`. The body
      // is not evaluated at partial application, for two reasons:
      //
      // - An effectful body would fire its effects at partial application,
      //   and again at saturation.
      // - A pure body evaluated with only the prefix is simplified before the
      //   remaining arguments are known, so the curried value could differ
      //   from the full call: with `M = (x, y) ↦ x·y`, `Apply(Apply(M, 0), ∞)`
      //   was `0`, but `Apply(M, 0, ∞)` is `NaN`. A block local that
      //   the body reads was also read at partial application, not at the
      //   call that supplies the last argument.
      //
      // Re-application, not a substitution of the prefix VALUES into the
      // body, keeps the body untouched, and the binding of the parameters
      // goes through the same scope machinery as a saturated call.
      //
      // The prefix ARGUMENTS are evaluated here (above): producing an operand
      // is not the body's effect, and eager operands are evaluated at the
      // call that supplies them.
      //
      // A fresh symbol standing for an unapplied REST parameter holds the
      // TUPLE of the trailing arguments, so it is passed on as `Spread(sym)`
      // — spliced back into an argument run by the enclosing call — rather
      // than as one tuple argument, which the original literal would have
      // collected into a tuple of a tuple.
      const deferred = ce._fn(
        'Apply',
        [
          fnExpr,
          ...evaluatedKnownArgs,
          ...unappliedParams.map((param, i) =>
            isRestParameter(param) ? extras[i] : extraSymbols[i]
          ),
        ],
        { canonical: false }
      );
      return ce.function('Function', [
        returnTypeOp !== undefined
          ? ce._fn('Typed', [deferred, returnTypeOp], { canonical: false })
          : deferred,
        ...extras,
      ]);
    }

    // The element function of a lazy `Map` under `.N()` puts the arguments
    // as written in its body (`applyMarkerBody`).
    const markerValue = applyMarkerBody(args, options, iterationStatements);
    if (markerValue !== undefined) return markerValue;

    // Under `.N()`, an application whose written arguments are not their
    // approximations takes the same route (`applyWrittenArguments`).
    const writtenValue = applyWrittenArguments(
      args,
      options,
      iterationStatements
    );
    if (writtenValue !== undefined) return writtenValue;

    //
    // 4/ Evaluate arguments in the calling scope before switching context
    //
    // An argument that evaluates to an absent value (`At(L, 100)`) is passed
    // as it is, also at a parameter with a default.
    let evaluatedArgs: Expression[] = args.map(argValue);

    // An argument that only became an error when EVALUATED (`f(g(1))` with
    // `g(1)` failing) bubbles like a literal one — see step 2.
    if (errorPolicy === 'bubble') {
      const err = firstErrorArg(evaluatedArgs);
      if (err !== undefined) return err;
    }

    // An absent value at a numeric or a point parameter makes the call
    // `Missing` (see `absentResultParamIndexes`). An error argument outranks
    // it (above).
    if (absentResultParamIndexes.some((k) => isAbsentSymbol(evaluatedArgs[k])))
      return ce.Missing;

    // The rest collapse announced in step 2b: the evaluated trailing
    // arguments become ONE `Tuple` argument, so the binding below is an
    // ordinary `params.length`-ary one.
    const uncollapsedArgs = evaluatedArgs;
    if (restIndex >= 0)
      evaluatedArgs = [
        ...evaluatedArgs.slice(0, restIndex),
        ce.function('Tuple', evaluatedArgs.slice(restIndex)),
      ];

    //
    // 4b/ In strict mode, validate the evaluated arguments against the
    //     literal's declared parameter types (only when the literal carries at
    //     least one annotated parameter — untyped literals skip this entirely,
    //     §6.4). On mismatch, return the inert application carrying the
    //     error-marked arguments. This form is internal: each route that
    //     calls a literal (`Apply`, a named call, a mapped list cell) gives
    //     the error itself as the value of the call
    //     (`refusedLiteralArgumentError` and `_refusedArgumentError`,
    //     `boxed-expression/boxed-function.ts`; `docs/ERROR-MODEL.md`).
    //
    if (ce.strict && validateApplication && _validateArguments) {
      const validated = _validateArguments(
        ce,
        evaluatedArgs,
        acceptNaNAtNumericParams(
          relaxBareParams(parameterSignature()),
          evaluatedArgs
        )
      );
      if (validated !== null) {
        // Any invalid operand: mismatch — return the inert application.
        // A `List` or `Set` with a failed cell is a value (see step 2).
        if (validated.some((x) => isInvalidNonCollection(x)))
          return ce._fn('Apply', [fnExpr, ...validated]);
        // All valid: an operand was substituted (e.g. devolved); proceed with
        // the substituted arguments.
        evaluatedArgs = [...validated];
      }
    }

    // An argument with no concrete value whose type does not show that it fits
    // the annotation of the author: the application waits, and a later
    // evaluation checks the value. With `h = (k: integer) ↦ 2k` and `m` with
    // no value, the result `2m` would hold no trace of the annotation, and
    // after `m := 1.5` it would give `3`, where `h(1.5)` is an
    // `incompatible-type` error. The inert form holds the arguments as the
    // call gave them, because a later application collects a rest parameter
    // again. Held arguments are expressions and not values, so they are not
    // checked here. (`docs/ERROR-MODEL.md`, "A symbolic argument whose type
    // does not decide".)
    if (
      ce.strict &&
      hasAuthorAnnotation &&
      options?.holdArguments !== true &&
      options?.mapElement !== true &&
      _declaredArgumentUndecided?.(
        relaxParamSlots(parameterSignature(), unannotatedParamIndexes),
        evaluatedArgs
      )
    ) {
      const undecided = ce._fn('Apply', [fnExpr, ...uncollapsedArgs]);
      UNDECIDED_APPLICATIONS.add(undecided);
      return undecided;
    }

    // A pure literal over number-literal arguments: answer a memoized result
    // of the same application taken earlier in this evaluation (see
    // `IComputeEngine._applicationMemo`). Purity is read HERE, per
    // application, not when this wrapper was built — the wrapper is built
    // once per definition, and a callee the body applies may have been
    // redefined impure since (`effectsOf` is memoized, so the read is
    // cheap). The key carries the numeric-approximation flag — the exact
    // and the `.N()` answers differ — and spells `-0` apart from `0`, which
    // `JSON.stringify` would collapse. It also carries whether the
    // assumptions are hidden right now: a body that reads a symbol whose
    // value an `assume(x = …)` put in force answers differently inside a
    // fact-blind bracket, and the two answers must not be confused
    // (`docs/plans/2026-08-30-assumptions-memo-inventory.md`). Both keys,
    // the numeric key and the exact key, also carry the precision of the
    // engine and the digits that an enclosing `N(x, n)` requests: `N(x, n)`
    // computes at `n` digits with no reset of the engine
    // (`_withTransientPrecision`), thus the stamps of the memo do not
    // change, and a value computed at one precision must not be served at
    // another. The exact key needs them too: an exact evaluation can give a
    // float (a body `N(Pi)`), and the body of a function that a numeric
    // request applies runs through the exact route first.
    const precisionKey = `${ce.precision}:${ce._requestedPrecision ?? ''}`;
    // On the asynchronous route, does the body apply an operator that has
    // only an `evaluateAsync` handler, directly or through a helper
    // function (`hasAsyncOnlyApplication`)? The synchronous route leaves
    // such an application unevaluated. The application memo then keeps the
    // answers of the two routes apart (`applicationMemoArgs`), and the
    // list-recursion plan below, which runs its steps synchronously, is
    // not used.
    const asyncOnly =
      options?.awaitStatements === true && hasAsyncOnlyApplication(body, true);
    const memoArgs = applicationMemoArgs(
      evaluatedArgs,
      iterationStatements,
      asyncOnly
    );
    const numeric = options?.numericApproximation === true;
    const memoKey =
      memoArgs === undefined
        ? undefined
        : `${numeric ? 'N' : 'E'}${precisionKey}${memoArgs}`;
    if (memoKey !== undefined) {
      const hit = validApplicationMemo(ce, fnExpr)?.results.get(memoKey);
      if (hit !== undefined) return hit;
    }
    // The result is not memoized when the store guard refuses it
    // (`store-guard.ts`). For example, a read of a sequence term that is
    // stopped in this application (too many terms, or a recursion that is
    // too deep) declines the term for this read only, and a later
    // application can give the term (see `sequence-read-stops.ts`). A body
    // that evaluates a host operator that does not state `pure: true`, or
    // the handler of one that states it but changed state, is not memoized
    // either (`host-handler-changes.ts`).
    const guard = beginStoreGuard();

    // A recursive definition is not unrolled symbolically: a re-entrant
    // application with an argument that contains a free symbol abandons the
    // outermost application of this literal, which stays inert (see
    // `SymbolicRecursion`). Ground arguments never abandon anything. An
    // application is re-entrant when an application of this literal is
    // still in its synchronous part (`activeApplications`), or when it is
    // inside an awaited application of this literal, whose body runs in
    // later time slices (`insideAwaitedApplication`).
    if (
      ((activeApplications.get(fnExpr.hash) ?? 0) > 1 ||
        insideAwaitedApplication(
          fnExpr.hash,
          options?._contextStack ?? ce._evalContextStack
        )) &&
      evaluatedArgs.some((a) => containsFreeSymbol(a))
    )
      throw new SymbolicRecursion(fnExpr.hash);

    // A list-producing recursion can run one ordinary call frame per step.
    // Analyze current bindings and effects here, after argument validation,
    // instead of changing the stored definition or trusting assignment-time
    // purity. Private step results never enter the application memo.
    if (
      iterationStatements === undefined &&
      !options?.holdArguments &&
      evaluatedArgs.length === params.length &&
      evaluatedArgs.every(isNumber) &&
      !asyncOnly &&
      debugStatementHook === undefined &&
      debugStatementResultHook === undefined
    ) {
      const plan = listRecursionPlan(fnExpr);
      if (plan !== undefined) {
        const result = evaluateListRecursion(
          plan,
          evaluatedArgs,
          (next, step) =>
            invoke(
              next,
              { ...options, numericApproximation: false },
              step === undefined ? bodyFn.ops : [step]
            )
        );
        return result !== undefined && numeric
          ? evaluateInOwnBindings(ce, result, { numericApproximation: true })
          : result;
      }
    }

    //
    // 5/ Create a fresh scope per call with parent = the defining scope.
    //    bodyFn.localScope.parent is the scope where the Function was defined.
    //    This gives true lexical scoping: the fresh scope chain is
    //    [fresh scope (params)] -> [defining scope] -> ...
    //    The calling scope is never in the chain. (`capturedScope` is
    //    computed at the top of `invoke`: the hold-argument inlining above
    //    needs it before any argument is bound.)
    //
    const freshScope: Scope = {
      parent: capturedScope,
      bindings: new Map(),
    };
    // The serial number of this frame: a result that reads this frame, or a
    // frame made after it, is not kept by the application memo
    // (`holdsFrameSince`).
    const firstFrameSerial = nextCallFrameSerial;
    addCallFrame(freshScope);
    // No frame reads this scope until it is pushed (`pending-call-scopes.ts`).
    notePendingCallScope(freshScope);

    // Declare parameters in the fresh scope. Annotated parameters are declared
    // with their declared type, non-inferred (§6.4); bare parameters stay
    // inferred as before. A DESTRUCTURING parameter binds one name per pattern
    // leaf, taken from the matching component of its (tuple) argument; a shape
    // mismatch is an error value and the body never runs.
    const bound = parameterBindings(params, evaluatedArgs);
    if (bound.error !== undefined) return bound.error;
    const leaves = bound.leaves;
    const paramNames = leaves.map((l) => l.name);
    const parameterValues = new Map<BoxedValueDefinition, Expression>();
    for (const leaf of leaves)
      // Arguments were validated in step 4b, so a strict-mode typed binding
      // is known compatible.
      declareParameterActivation(
        ce,
        leaf.name,
        leaf.site,
        leaf.value,
        freshScope,
        bodyScope,
        parameterValues
      );
    holdBodyLocals(freshScope, bodyScope, parameterValues);
    // The written argument behind a plain parameter's activation, for the
    // exact re-read of a jump in the body (`ApplyOptions.exactSources`,
    // `exact-argument-source.ts`). A destructured leaf has no argument of
    // its own, and the rest parameter collects several.
    const sources = options?.exactSources;
    if (sources !== undefined)
      for (const leaf of leaves) {
        const i = leaf.index;
        if (i === undefined || i === restIndex) continue;
        const source = sources[i];
        if (source === undefined) continue;
        const activation = freshScope.bindings.get(leaf.name);
        if (activation !== undefined && isValueDefinitionHalf(activation))
          setExactArgumentSource(freshScope, activation.value, source);
      }

    // The body scope is being applied: the static view reads that
    // (`appliedBodyScopes`).
    enterAppliedBodyScope(bodyScope);
    noteBodyScopeApplied(ce, bodyScope);
    noteCallFrame(freshScope, bodyScope);

    // Are the statements awaited (`awaitStatements`)? An argument can have
    // a free symbol: a recursive application in the body finds the frame of
    // this application on its context stack (`awaitedFrames`) and abandons
    // this application, as on the synchronous route. An application that
    // another suspended application of this literal blocks waited at the
    // start of `invoke` (see `asyncInFlight`), so none blocks this one now;
    // the test is repeated, and a blocked application runs synchronously.
    const awaiting =
      options?.awaitStatements === true &&
      options._effects !== undefined &&
      iterationStatements === undefined &&
      blockingAsyncApplication(
        bodyFn.localScope!,
        options._contextStack ?? ce._evalContextStack
      ) === undefined;
    // An application whose statements are awaited puts its call frame on
    // its own copy of the evaluation-context stack, as the asynchronous
    // route of a named function does (`applyAwaiting`). The caller can start
    // another application on its stack while this one is suspended (the
    // elements of a broadcast): that one must not find the frame of this one
    // on its stack, which would read as a recursive call in this frame
    // (`blockingAsyncApplication()`), and a frame that it pushes must not
    // cover the frame of this one.
    const enclosingStack = ce._evalContextStack;
    const ownStack = awaiting ? copyContextStack(enclosingStack) : undefined;
    if (ownStack !== undefined) ce._evalContextStack = ownStack;

    // Push fresh scope and evaluate block contents directly.
    // We evaluate bodyFn.ops (the Block's children) rather than calling
    // body.evaluate() — see evaluateStatements JSDoc for why.
    // Named 'call': a function-application activation frame. The debugger's
    // statement hook uses this to delimit stack frames (one per
    // activation — nested unnamed Block/loop contexts group into it).
    // The views that this call makes are counted: when none was made, the
    // end of the call does not walk the substituted result.
    const viewSerial = lazyViewRecordSerial();
    if (args.some((a) => a.isCollection === true && !isString(a)))
      COLLECTION_ARGUMENT_FRAMES.add(freshScope);
    ce.pushScope(freshScope, 'call');
    // The scope holds the values of the parameters: its pop must advance the
    // cache version (see `_bindsValues`).
    ce.context._bindsValues = true;
    let result: Expression;
    // The numeric request, when the last statement of the body takes it
    // itself (see `resultStatementRequest`). A list-producing recursion
    // runs its private step statements exactly, whatever the request.
    const statementRequest =
      iterationStatements === undefined
        ? resultStatementRequest(fnExpr, bodyFn.ops, options)
        : undefined;
    // The exact answer of a numerically requested application, kept for
    // the memo (see the numeric pass below). There is none when the last
    // statement of the body took the numeric request itself.
    let exactResult: Expression | undefined = undefined;
    // What follows the statements runs the same on both routes: `settle` in
    // the frame, `cleanup` when the frame leaves, `conclude` after.
    const settle = (statements: Expression): void => {
      result = unwrapReturn(ce, statements);

      // A function body whose final value is a *bare symbol* bound to a
      // user-defined function literal (`helper(x) = …`, which creates an
      // operator definition local to this call frame) must return that
      // function as a first-class value so it can escape the frame. The
      // operator definition is unreachable once the frame is popped, but its
      // stored literal (`_lambdaLiteral`) is a plain value. Resolve it here,
      // while the frame is still pushed and the definition is reachable.
      // (Built-in operators are not lambdas and are unaffected.)
      result = resolveEscapingLambda(ce, result);

      // A held view of the body gets a record of this call, before the
      // substitution below, which carries it.
      result = adoptHeldLazyViews(
        ce,
        result,
        body,
        ce._evalContextStack,
        freshScope
      );

      // Substitute unresolved parameter occurrences with their final values.
      // Match the literal's binding: a same-named free symbol from an argument
      // or a nested lambda denotes a different binding and must stay unchanged.
      // See docs/SCOPING-MODEL.md, "Symbol identity" and "Callable resolution".
      if (hasReferencedName(result, paramNames)) {
        // ONE binding per parameter — the literal's own, which the frame
        // holds with the value of this call (`declareParameterActivation`).
        // The raw-occurrence case is name-keyed — a raw symbol carries no
        // binding at all.
        //
        // The value substituted is the parameter's value when the call ends,
        // which the frame holds: the body may have assigned the parameter
        // (`a ↦ Block(Assign(a, [7, 8]), Map(u ↦ 2u, a))`), and the lazy
        // `Map` it returns reads `[7, 8]`, as `Reverse(a)` in the same place
        // does. The argument is the value only when the frame holds none.
        const subs: ParameterSub[] = [];
        for (const leaf of leaves) {
          if (!hasReferencedName(result, leaf.name)) continue;
          const frame = freshScope.bindings.get(leaf.name);
          const value =
            (frame !== undefined && 'value' in frame
              ? frame.value.storedValue
              : undefined) ?? leaf.value;
          subs.push([
            staticParameterBinding(leaf.site, leaf.name, bodyScope),
            leaf.name,
            value,
            hasReferencedName(value, leaf.name),
          ]);
        }
        if (subs.length > 0) {
          // The function values and the scoped nodes of the result that
          // belong to other calls: the substitution leaves them alone.
          const keptNodes = new Set<Expression>();
          recordNodesOfOtherCalls(result, freshScope, bodyScope, keptNodes);
          const unsubstituted = result;
          result = bindingKeyedSubs(result, subs, keptNodes);
          // The substituted result keeps the creation context of each lazy
          // callback view. It is walked only when a view was made during
          // the call.
          if (lazyViewRecordSerial() !== viewSerial)
            carryLazyViewContexts(unsubstituted, result);
        }
      }

      // Honor a numeric-approximation request (`N(f(2))`) by approximating
      // the (exactly-evaluated) result HERE, while the function's scope
      // frame is still pushed. Approximating after the frame is popped
      // would re-resolve free symbols in the *caller's* dynamic context,
      // breaking lexical scoping (see scope.test.ts "Dynamic scoping").
      //
      // In-frame, though, the pass must not re-resolve those symbols by NAME
      // either — that was Channel C of the name-capture defect: `let a = x + 1;
      // g(x) = a; N(g(5))` gave `6` while `g(5)` gave `x + 1`, because the
      // numeric pass looked `x` up again and found the frame's parameter. Every
      // occurrence that genuinely refers to a parameter has already been
      // replaced by its value (`bindingKeyedSubs`, above), so what remains
      // means its own binding and is resolved as such.
      if (numeric) {
        // When the body applies itself it ran EXACTLY (its statements
        // evaluate with no options, see `resultStatementRequest`), so the
        // exact answer of this application is in hand before the numeric
        // pass below and is memoized under the exact key as well. A
        // recursive body applies itself through the exact route whatever
        // the outer request was: `P(k)` requested numerically evaluates
        // `P(k-1)` exactly. Without this entry a run of numeric requests
        // `P(0)`, `P(1)`, … `P(n)` — the elements of a lazy comprehension
        // pulled one at a time — never found the previous element's exact
        // result and re-ran the recursion from the bottom at every element.
        // A body that does not apply itself gave the request to its last
        // statement, so its value is already numeric and no exact answer
        // exists.
        if (statementRequest === undefined) exactResult = result;
        result = evaluateInOwnBindings(ce, result, {
          numericApproximation: true,
        });
      }
    };
    const cleanup = (): void => {
      ce.popScope();
      exitAppliedBodyScope(bodyScope);
    };
    const conclude = (store = true): Expression => {
      if (
        store &&
        memoKey !== undefined &&
        // A re-entrant evaluation of a lazy collection node (a node of the
        // body evaluated again by a recursive application) is not a
        // provisional answer here: it computes the full value of the node
        // in the scope of its own application. Only the memo of that node,
        // which keys on the node and not on the application, must not keep
        // it (`_memoizedLazyCollectionValue`). Refusing it would remove
        // this memo from every recursive function whose body holds such a
        // node.
        //
        // A re-entrant read of a signature is accepted too. The first
        // application of a recursive function reads the type of its body,
        // and that starts the derivation of the signature of the function;
        // the recursive call in the body reads that signature while it is
        // derived (`noteReentrantSignatureRead()`). The provisional answer
        // is a type of the derivation, which the derivation does not keep;
        // the values of the body are computed from the values of the
        // arguments. Refusing it would remove this memo from the first
        // application of every recursive function, so each level would be
        // computed again (`recursive-application-memo-across-evaluations.test.ts`).
        guard.movedOnly('lazyValueProvisional', 'reentrantSignature') &&
        // A result that holds state of this application is a new value at
        // each call (`holdsFrameSince`). Both entries are stored, so both
        // are tested.
        !holdsFrameSince(result, firstFrameSerial) &&
        (exactResult === undefined ||
          !holdsFrameSince(exactResult, firstFrameSerial))
      ) {
        // The exact entry is stored whether or not the numeric pass produced
        // a valid result: the exact answer is what a recursive body, which
        // applies itself exactly, looks up.
        const exactEntry = exactResult?.isValid ? exactResult : undefined;
        const resultEntry = result.isValid ? result : undefined;
        if (exactEntry !== undefined || resultEntry !== undefined) {
          const memo = applicationMemoForStore(ce, fnExpr);
          if (memo !== undefined) {
            if (exactEntry !== undefined)
              memo.results.set(`E${precisionKey}${memoArgs}`, exactEntry);
            if (resultEntry !== undefined)
              memo.results.set(memoKey, resultEntry);
          }
        }
      }
      return bodyResultValue(result);
    };

    // Await the statements (`awaiting`). Everything after the first `await`
    // runs with this evaluation's registry and this application's context
    // stack in place of the engine's: other evaluations run in between.
    if (ownStack !== undefined) {
      const { signal, _effects, _precisionWindow: precision } = options!;
      const effects = _effects!;
      const stack = ownStack;
      const inContext = <T>(f: () => T): T =>
        runWithEvaluationEffects(ce, effects, f, stack, precision);
      let finish: () => void = () => {};
      const application: AsyncApplication = {
        frame: freshScope,
        done: new Promise<void>((resolve) => (finish = resolve)),
        finish: () => finish(),
      };
      let inFlight = asyncInFlight.get(bodyFn.localScope!);
      if (inFlight === undefined) {
        inFlight = [];
        asyncInFlight.set(bodyFn.localScope!, inFlight);
      }
      inFlight.push(application);
      const applications = inFlight;
      const literal = fnExpr.hash;
      awaitedFrames.set(freshScope, literal);
      awaitedApplicationCount.set(
        literal,
        (awaitedApplicationCount.get(literal) ?? 0) + 1
      );
      // Other evaluations run while the statements are awaited. A result
      // computed before one of them wrote a value the body reads must not
      // enter the memo, whose record is stamped at store time: the
      // dependencies of the literal are snapshotted now, and the store is
      // skipped when one of them, or a world stamp, moved during the wait.
      const depsBefore =
        memoKey === undefined ? undefined : snapshotMemoDeps(fnExpr);
      const worldBefore = ce._worldVersion;
      const epochBefore = ce._objectStoreEpoch;
      const answer = (async () => {
        try {
          try {
            const statements = await evaluateStatementsAsync(
              ce,
              bodyFn.ops,
              signal,
              effects,
              stack,
              statementRequest?.numericApproximation,
              precision
            );
            inContext(() => settle(statements));
          } finally {
            inContext(cleanup);
          }
        } finally {
          const index = applications.lastIndexOf(application);
          if (index >= 0) applications.splice(index, 1);
          if (applications.length === 0)
            asyncInFlight.delete(bodyFn.localScope!);
          awaitedFrames.delete(freshScope);
          const count = (awaitedApplicationCount.get(literal) ?? 1) - 1;
          if (count > 0) awaitedApplicationCount.set(literal, count);
          else awaitedApplicationCount.delete(literal);
          application.finish();
        }
        return inContext(() =>
          conclude(
            depsBefore !== undefined &&
              ce._worldVersion === worldBefore &&
              ce._objectStoreEpoch === epochBefore &&
              memoDepsStillValid(fnExpr, depsBefore)
          )
        );
      })();
      // The part of the application before its first `await` ran with the
      // own stack of the application in place of the engine's.
      ce._evalContextStack = enclosingStack;
      // The lambda is typed synchronous: a `Promise` comes back only for
      // the caller that set `awaitStatements`.
      return answer as unknown as Expression;
    }

    try {
      settle(
        evaluateStatements(
          ce,
          iterationStatements ?? bodyFn.ops,
          statementRequest
        )
      );
    } finally {
      cleanup();
    }
    // The memo key of an application on the asynchronous route whose body
    // applies an asynchronous-only operator is the key of that route
    // (`asyncOnly`). An answer computed synchronously is not stored under it.
    return conclude(!asyncOnly);
  };

  // `invoke` applies `lambda` again when an application waited for another
  // one (see `asyncInFlight`), so that the recursion guards count it.
  const lambda = wrapRecursion(
    ce,
    guardSymbolicRecursion(fnExpr, declineUnavoidableCapture(invoke))
  );
  return lambda;
}

/**
 * The options the LAST statement of a function body is evaluated with under
 * a numeric-approximation request: the request itself when no statement of
 * the body applies the function again, nothing otherwise. The statements
 * before the last one always run exactly (`evaluateStatements`).
 *
 * The value of the body is the value of its last statement, so
 * `f(2000).N()` with `f(n) = Σ_{k=1}^{n} 1/k²` can sum floats the way
 * `Sum(1/k², k, 1, 2000).N()` does; summing two thousand exact rationals
 * and numericizing the result cost twenty times more, and the same body at
 * n = 400000 did not finish.
 *
 * The request is also what makes a jump in the last statement correct.
 * Under `.N()` a parameter is bound to the float of its argument, and a
 * jump (`Floor(x)`, `x < 25`) reads the exact argument again only when it is
 * evaluated with the request (`exact-argument-source.ts`). So with
 * `f := x ↦ Block(z := 1, Floor(x))`, `f((25! − 1)/24!).N()` is `24`: an
 * exact run of the last statement would floor the float `25`.
 *
 * The statements before the last one run exactly: an intermediate value
 * that a later statement reads (`a := √2; a^2`) must not be rounded on the
 * way, and `f(x).N()` must agree with `N(f(x))` on both evaluation routes
 * (`evaluateStatements`, `evaluateStatementsAsync`). An early `Return` in
 * one of them gives an exactly computed value, which the application then
 * numericizes.
 *
 * A self-recursive body runs exactly, and only its value is numericized.
 * The exact run gives the application memo an exact entry beside the
 * numeric one, which a later exact request, or a recursive application from
 * another request, is answered from
 * (`recursive-application-memo-across-evaluations.test.ts`). The recursion
 * depth is bounded by the call stack, so an exact run of a recursive body
 * costs little, and a float chain would gain nothing measurable (a harmonic
 * recursion of depth 120 takes 16 ms either way). The check reads the
 * definitions in force at application time, as `listRecursionPlan` does: a
 * reassigned name can make a body recursive, or not, after the literal was
 * stored.
 */
function resultStatementRequest(
  literal: Expression,
  ops: ReadonlyArray<Expression>,
  options: ApplyOptions | undefined
): { numericApproximation: true } | undefined {
  if (options?.numericApproximation !== true || ops.length === 0)
    return undefined;
  if (ops.some((op) => appliesLiteral(op, literal))) return undefined;
  return { numericApproximation: true };
}

/**
 * Whether `expr` applies or names the function literal `literal`, at any
 * depth: a symbol or an application whose definition in force holds the
 * literal. A user function is stored in one of three ways, and all three are
 * read: as the VALUE of a symbol (`ce.declare('f', 'function')` then
 * `ce.assign('f', literal)`), as an OPERATOR definition made from the literal
 * (`f(n) := …`, `DefineFunction`, `ce.assign('f', literal)` with no prior
 * declaration — the literal is its `_lambdaLiteral`), or as one CLAUSE of a
 * multi-clause operator definition (`f(0) := …; f(n) := …`), whose clause
 * records are under the key `multi-clause.ts` stores them at (that module
 * imports this one, so the records are read structurally here). A recursion
 * through another function (`even` applies `odd`, which applies `even`) is
 * not seen: the forwarded request then reaches the recursive body, which
 * costs the exact memo entry of its applications and nothing else.
 */
function appliesLiteral(
  expr: Expression,
  literal: Expression,
  seen = new Set<Expression>()
): boolean {
  if (seen.has(expr)) return false;
  seen.add(expr);
  if (isFunction(expr) || isSymbol(expr)) {
    // A call or a symbol boxed before the function was defined has no
    // definition of its own (a free name): it reads the definition that its
    // name resolves to now.
    const binding = readBinding(expr);
    if (
      binding !== undefined &&
      'value' in binding &&
      binding.value.value === literal
    )
      return true;
    const opDef = (
      binding !== undefined && 'operator' in binding
        ? binding.operator
        : undefined
    ) as
      | (BoxedOperatorDefinition & {
          _multiClauseFunction?: {
            clauses?: ReadonlyArray<{ literal: Expression }>;
          };
        })
      | undefined;
    if (opDef !== undefined) {
      if (opDef._lambdaLiteral === literal) return true;
      const clauses = opDef._multiClauseFunction?.clauses;
      if (clauses !== undefined && clauses.some((c) => c.literal === literal))
        return true;
    }
  }
  if (!isFunction(expr) || expr._numericStore !== undefined) return false;
  if (expr.operatorDefinition?.holdClass === 'quote') return false;
  return expr.ops.some((op) => appliesLiteral(op, literal, seen));
}

/**
 * How many results one function literal's application memo holds before it
 * is emptied and refilled. The memo lives for the engine's lifetime (see
 * `IComputeEngine._applicationMemo`), so without a bound it would grow with
 * every distinct argument tuple the literal is ever applied to. The bound
 * is per literal: a literal is the key of a `WeakMap`, so its results die
 * with it. Emptying the whole map, rather than evicting the oldest entry,
 * keeps a hit at one map read; a recursion that spans an emptying re-runs
 * at most one memo's worth of applications. One application can add TWO
 * entries — the exact result and the numerically requested one — so the
 * emptying leaves room for both.
 */
export const MAX_APPLICATION_MEMO_RESULTS = 4096;

type ApplicationMemo = NonNullable<
  ReturnType<NonNullable<ComputeEngine['_applicationMemo']>['get']>
>;

/**
 * The memo record of `fnExpr` when every stamp on it is still current: the
 * world version, the object-store epoch and the dependency snapshot
 * (`memoDepsStillValid`). `undefined` when there is no record or a stamp
 * moved; the record is then stale in its entirety, because every result in
 * it was computed under the same stamps.
 *
 * The WORLD axis, not the semantic one: a plain value write moves `semantic`
 * but not `world`, and a write the entries do not depend on must not empty
 * the record — an assignment made between two element pulls of a lazy
 * collection would otherwise restart the recursion the memo exists for. A
 * write the entries DO depend on is caught per definition by
 * `memoDepsStillValid`, which reads one `_writeVersion` per value definition
 * the body reads (`collection-element-memo.ts`).
 */
function validApplicationMemo(
  ce: ComputeEngine,
  fnExpr: Expression
): ApplicationMemo | undefined {
  // An application evaluated inside a type computation reads the static
  // bindings (`static-typing-view.ts`): its parameters have no value there,
  // so its result is not the result of the call. The memo is not keyed on
  // the view, so it is neither read nor written while the view differs from
  // the bindings.
  if (staticViewDiverges(ce)) return undefined;
  const memo = cacheOff('appmemo')
    ? undefined
    : ce._applicationMemo?.get(fnExpr);
  if (
    memo !== undefined &&
    memo.worldVersion === ce._worldVersion &&
    memo.objectStoreEpoch === ce._objectStoreEpoch &&
    memoDepsStillValid(fnExpr, memo.deps as MemoDeps)
  )
    return memo;
  return undefined;
}

/**
 * The memo record of `fnExpr` to store a result into: the current one when
 * its stamps are still valid, otherwise a fresh record stamped now. A
 * record with no room left under `MAX_APPLICATION_MEMO_RESULTS` for the two
 * entries one call can add is emptied before the store. `undefined` when the
 * literal is not memoizable — its
 * dependencies cannot be snapshotted (a free name with no binding at all,
 * resolved dynamically at walk time).
 */
function applicationMemoForStore(
  ce: ComputeEngine,
  fnExpr: Expression
): ApplicationMemo | undefined {
  // See `validApplicationMemo()`: no store while the static view differs.
  if (staticViewDiverges(ce)) return undefined;
  ce._applicationMemo ??= new WeakMap();
  let memo = validApplicationMemo(ce, fnExpr);
  if (memo === undefined) {
    const deps = snapshotMemoDeps(fnExpr);
    if (deps === undefined) return undefined;
    memo = {
      worldVersion: ce._worldVersion,
      objectStoreEpoch: ce._objectStoreEpoch,
      deps,
      results: new Map(),
    };
    ce._applicationMemo.set(fnExpr, memo);
  } else if (memo.results.size + 2 > MAX_APPLICATION_MEMO_RESULTS) {
    // The caller may insert two entries (the exact key and the numeric one),
    // so the bound is checked with room for both.
    memo.results.clear();
  }
  return memo;
}

/**
 * The value a function application answers with, given what its body
 * evaluated to.
 *
 * A valid result is the answer. A body that evaluated to an `Error` value —
 * or to a tree that embeds one reachable without crossing a selecting
 * operator or a collection literal — answers with that error: a user
 * function bubbles the error values its body produces, exactly as a library
 * operator does — "Error values propagate through ordinary function
 * application" (`docs/LANGUAGE-MODEL.md`), the rule `docs/ERROR-MODEL.md` §3
 * lays out. Any other invalid result is a frozen
 * container (`[1, <error>]`) or an undecided selection (`If(x == 4, 5,
 * <error>)`), and is the answer with its diagnostic in place.
 *
 * Nothing here DECLINES the application. Until 2026-09-03 an invalid result
 * declined it (`result.isValid ? result : undefined`), which left the call
 * inert: `len(5)` for `len := x ↦ Length(x)` answered `len(5)` where
 * `Length(5)` itself is the `incompatible-type` error, and an Epsil
 * function could never return the error values its body produced. The
 * model forbids an inert answer to a decided failure (§1).
 */
function bodyResultValue(result: Expression): Expression {
  if (result.isValid) return result;
  return errorValue(result) ?? result;
}

/**
 * The value of the application of the user function `name` to `args`,
 * computed without boxing the application, or `undefined` when the caller
 * must box it (`ce.function(name, args).evaluate(options)`).
 *
 * A named callback (`filter(1..5000, isEven)`) is applied once per element.
 * Boxing `isEven(n)` canonicalizes and validates a new node at each element,
 * and the evaluation of that node then walks the steps of the direct call
 * (broadcasts, absent operands, conformance) before it calls the operator
 * handler, which applies the function literal. For the applications below,
 * each of those steps does nothing, so the handler is called directly, in
 * the same evaluation bracket that `BoxedFunction.evaluate()` puts around
 * it (the effect registry, the evaluation depth, the numeric request):
 *
 * - the definition is an operator definition made from one function
 *   literal (`_lambdaLiteral`; not a definition by clauses, not a `hold`
 *   function), and its signature is the one inferred or derived from the
 *   literal: a signature declared on the name has checks of its own;
 * - the body of the literal is pure, so that an application can be done a
 *   second time by the boxed route with the same result;
 * - the literal has one parameter per argument and no rest parameter, and
 *   each argument is a number that is not `NaN`, or a string: such an
 *   argument cannot be broadcast, threaded, absent or an error;
 * - the request is an exact evaluation (no `numericApproximation`, no
 *   `materialization`, no other option).
 *
 * The literal still decides what it decides itself: the validation of its
 * annotated parameters, the recursion limit, the application memo. A result
 * that is not an ordinary value (no result, an invalid result such as the
 * refusal of an argument by an annotated parameter or an error that the
 * body gave, a lazy collection) is not used: the boxed route then makes the
 * application again and gives its own answer, with its own error frames.
 * The body is pure, so its second run has no visible effect.
 */
/** Box a call against the chosen lexical callable without changing the
 * environment in which its written arguments will later evaluate. */
export function callableApplication(
  ce: ComputeEngine,
  name: string,
  args: ReadonlyArray<Expression>,
  binding: BoxedDefinition | undefined,
  occurrence?: Expression
): Expression {
  if (binding === undefined) {
    // A free name that resolves to nothing from its home scope: the call is
    // boxed there (`unresolvedFreeHome()`).
    const home = unresolvedFreeHome(occurrence);
    return home === undefined
      ? ce.function(name, args)
      : ce._inScope(home, () => ce.function(name, args));
  }
  if (ce.lookupDefinition(name) === binding) return ce.function(name, args);
  const bindings = new Map([[name, binding]]);
  ce.pushScope({ parent: ce.context.lexicalScope, bindings });
  try {
    return ce.function(name, args);
  } finally {
    bindings.clear();
    ce.popScope();
  }
}

function applyNamedLiteral(
  ce: ComputeEngine,
  name: string,
  args: ReadonlyArray<Expression>,
  options: ApplyOptions | undefined,
  binding: BoxedDefinition | undefined
): Expression | undefined {
  if (
    options !== undefined &&
    !Object.entries(options).every(
      ([key, value]) =>
        (key === 'numericApproximation' || key === 'materialization') && !value
    )
  )
    return undefined;
  if (binding === undefined || !isOperatorDef(binding)) return undefined;
  const def = binding.operator as BoxedOperatorDefinition & {
    _isLambda?: boolean;
    _signatureSkeleton?: unknown;
  };
  const literal = def._lambdaLiteral;
  if (
    literal === undefined ||
    def._isLambda !== true ||
    !def.isUserFunctionDefinition ||
    def.lazy === true ||
    def.evaluate === undefined ||
    def._signatureSkeleton !== undefined ||
    !(def.inferredSignature || def._derivedSignature) ||
    !isFunction(literal, 'Function') ||
    literal.nops !== args.length + 1
  )
    return undefined;
  for (let i = 1; i < literal.nops; i++)
    if (isRestParameter(literal.ops[i])) return undefined;
  for (const arg of args) {
    if (isString(arg)) continue;
    if (!isNumber(arg) || arg.isNaN !== false) return undefined;
  }
  if (!isPureComputedEffects(effectsOf(literal.op1))) return undefined;

  const capturesEffects = ce._evaluationEffects === undefined;
  if (capturesEffects) ce._evaluationEffects = ce.effects;
  ce._evaluationDepth += 1;
  const enclosingNumericRequest = ce._numericRequest;
  ce._numericRequest = false;
  let result: Expression | undefined;
  try {
    result = def.evaluate(args, {
      engine: ce,
      numericApproximation: false,
      materialization: false,
      effects: ce._evaluationEffects ?? ce.effects,
    });
  } finally {
    ce._evaluationDepth -= 1;
    ce._numericRequest = enclosingNumericRequest;
    releaseKeptEagerSourceValues(ce);
    if (capturesEffects) ce._evaluationEffects = undefined;
  }
  if (result === undefined || !result.isValid || result.isLazyCollection)
    return undefined;
  return result;
}

/**
 * Return a lambda function, assuming a scoped environment has been
 * created and there is a single numeric argument
 */
export function makeLambdaN1(
  expr: Expression
): ((arg: number) => number) | undefined {
  const lambda = makeLambda(expr);
  if (!lambda) return undefined;
  return (arg) =>
    (lambda([expr.engine.number(arg)])?.valueOf() as number) ?? NaN;
}

/**
 * Given an expression such as:
 * - ["Function", ["Add", 1, "x"], "x"]
 * - ["Function", ["Divide", "_", 2]]
 * - ["Multiply, "_", 3]
 * - ["Add, "_1", "_2"]
 * - "Sin"
 *
 * return a JS function that can be called with arguments.
 */
export function applicable(
  fn: Expression
): (
  xs: ReadonlyArray<Expression>,
  options?: ApplyOptions
) => Expression | undefined {
  // A callee that IS an error — an `Error` node, or a tree embedding one
  // reachable without crossing a selecting operator or a collection literal
  // (a predicate the compatibility gate rejected at canonicalization arrives
  // here as `Error(incompatible-type, literal)`) — is not applicable: every
  // call answers `undefined`, so a consumer reports the callee's own
  // diagnostic (`invalidPredicateError` in `library/collections.ts`) instead
  // of reading an error VALUE as a per-element failure of a sound predicate.
  // The walk is `errorValue`, the same one `apply()` bubbles on, so a literal
  // whose only error sits under a selecting arm (`x ↦ If(x > 0, True,
  // Length(x))`) stays applicable and answers per call. This is the one
  // place the distinction is drawn: `makeLambda` no longer declines an
  // application whose BODY produced an error value (`bodyResultValue`),
  // which is what used to make an invalid callee answer `undefined` as a
  // side effect.
  if (errorValue(fn) !== undefined) return () => undefined;
  // A callee that is a symbol holding an error value (`w` after
  // `w := Ln("a")`, see `isErrorTypedOperand()`) is valid, but it cannot be
  // applied either. Each call gives the error of the symbol, read when the
  // call is made, as an element-valued failure: `Map(w, [1, 2]).at(1)` and
  // the elements of `Filter([1, 2], w)` are that error. (The evaluation of
  // such a lazy collection operator gives the error for the whole call
  // before it applies its callback: `heldErrorCallback()`,
  // `boxed-function.ts`.)
  const apply =
    makeLambda(fn) ??
    ((xs: ReadonlyArray<Expression>, options?: ApplyOptions) =>
      fn.engine.function('Apply', [fn, ...xs]).evaluate(options));
  if (!isErrorTypedOperand(fn)) return apply;
  return (xs, options) =>
    isErrorTypedOperand(fn) ? fn.evaluate() : apply(xs, options);
}

/**
 * Use `applicableN1()` when the function is known to be a function with a
 * single real argument that returns a real value.
 *
 * Unlike `apply()`, `applicableN1()` returns a function that can be called
 * with an argument.
 *
 */
export function applicableN1(fn: Expression): (x: number) => number {
  // The same guard as `applicable()`: a callee that is an error has no
  // numeric answer. Without it the closure would return the error VALUE and
  // the `NaN` below would come only from `re` defaulting on a non-number.
  if (errorValue(fn) !== undefined) return () => NaN;
  const lambda = makeLambda(fn);
  const ce = fn.engine;

  if (lambda) return (x) => lambda([ce.number(x)])?.re ?? NaN;

  return (x) => ce.function('Apply', [fn, ce.number(x)]).evaluate().re;
}

/**
 * Given a string like "f(x,y)" return, ["f", ["x", "y"]]
 */
export function parseFunctionSignature(
  s: string
): [id: string, args: string[] | undefined] {
  const m = s.match(/(.+)\((.*)\)/);
  if (!m) return [s, undefined];
  const id = m[1];
  const args = m[2].split(',').map((x) => x.trim());
  return [id, args];
}

/** Lookup a definition matching a symbol in a lexical scope chain */
export function lookup(
  id: MathJsonSymbol,
  scope: Scope
): undefined | BoxedDefinition {
  console.assert(typeof id === 'string' && id.length > 0);
  // Inside a type computation, the scopes are read in the static view
  // (`static-typing-view.ts`): a call frame of a function literal does not
  // answer, and the body scope answers the bindings that the call took out
  // of it.
  let currentScope: Scope | null = scope;
  while (currentScope) {
    const def = staticBindingIn(currentScope, id, currentScope === scope);
    if (def) return def;

    currentScope = staticParentOf(currentScope);
  }
  return undefined;
}

/** Could this definition satisfy a function-application (operator) position?
 * An operator def always can; a value def can unless its declared type
 * PROVABLY excludes functions (a plain `number`, `string`, collection, …).
 * A value def with an indeterminate type (`unknown`/`any`/`value`) may hold a
 * function literal, so it can. (Inline property checks, not
 * `isValueDef`/`isOperatorDef` from `boxed-expression/utils`, to avoid a
 * dependency cycle.)
 */
export function isApplicableDef(def: BoxedDefinition): boolean {
  if ('operator' in def) return true;
  if ('value' in def) {
    const value = (def as { value: BoxedValueDefinition }).value;
    const t = value.type;
    const tt = t.type;
    if (t.isUnknown) return true;
    if (tt === 'any' || tt === 'value' || tt === 'unknown') return true;
    return t.matches('function');
  }
  return true;
}

/**
 * Lookup a definition for a symbol in FUNCTION-APPLICATION (operator)
 * position. Like {@link lookup}, but an inner binding that PROVABLY cannot be
 * applied — a value def whose type excludes functions, e.g. a user symbol
 * `N = 85` shadowing the built-in `N` operator — defers to an outer
 * applicable definition of the same name. A bare-symbol reference still
 * resolves to the inner value (`N + 1` is `86`); only the operator position
 * skips it (`N(x)` numericizes). If no applicable definition exists anywhere
 * in the chain, the innermost binding is returned unchanged so the ordinary
 * "not a function" diagnostics still apply.
 *
 * Pass `engine` from a CANONICALIZATION-time caller. A name introduced by the
 * construct being canonicalized — a function literal's parameter, a `Block`'s
 * `Declare`d local — shadows any same-named binding of the enclosing context,
 * and must do so in operator position as well as in value position. Its
 * binding may not exist yet when a call to it is canonicalized (the body of
 * `(g) ↦ g(2)` is canonicalized before its parameters are declared), and
 * without the engine the walk then escapes to the enclosing binding and caches
 * it on the node: `const g = (x) ↦ x + 1; const f = (g) ↦ g(2)` applied the
 * OUTER `g`, so `f(x ↦ 10x)` answered 3 instead of 20. Callers with no
 * canonicalization in progress (the compiler, `D`) omit it.
 */
export function lookupApplicable(
  id: MathJsonSymbol,
  scope: Scope,
  engine?: ComputeEngine
): undefined | BoxedDefinition {
  console.assert(typeof id === 'string' && id.length > 0);

  // `Module` is the operator of every qualified name (`["Module", "Pi"]`):
  // as a head, it always reads the definition of the system scope, the root
  // of the chain, whatever the program binds (a parameter, a block local, a
  // binder index, a declaration of the host). So no binding of a program
  // changes what a qualified name reads.
  if (id === 'Module') {
    let root: Scope = scope;
    while (root.parent) root = root.parent;
    const system = root.bindings.get(id);
    if (system !== undefined) return system;
  }

  // A shadowed name resolves to the binding the shadowing construct's own
  // references already created, if any; otherwise the walk below stops before
  // the scope enclosing that construct, so a binding from outside it is never
  // reached. Returning nothing leaves the head undeclared, which is exactly the
  // state it would be in with no enclosing binding of that name — the caller
  // then auto-declares it locally, as it already does for `(g) ↦ g(2)` written
  // where no outer `g` exists.
  let boundary: Scope | undefined;
  if (engine?._isShadowedParameter(id)) {
    boundary = engine._shadowedParameterBoundary(id);
    // A binder inside the construct that binds the same name (a
    // comprehension index named like the parameter) shadows the parameter
    // in its own scope. In `(f) ↦ [[f(x) for x in xs] for f in fs]` the call
    // `f(x)` is a call of the index, not of the parameter. The binder
    // records the names it binds on its scope (`binderNames`) before its
    // operands are canonicalized.
    for (let s: Scope | null = scope; s && s !== boundary; s = s.parent) {
      const def = s.binderNames?.has(id) ? s.bindings.get(id) : undefined;
      if (def !== undefined) return def;
    }
    const shadowed = engine._shadowedParameterDef(id);
    if (shadowed !== undefined) return shadowed;
  }

  let innermost: BoxedDefinition | undefined;
  let currentScope: Scope | null = scope;
  while (currentScope && currentScope !== boundary) {
    const def = currentScope.bindings.get(id);
    if (def) {
      if (isApplicableDef(def)) return def;
      innermost ??= def;
    }
    currentScope = currentScope.parent;
  }
  return innermost;
}

/**
 * True when `name`, the name of the qualified call
 * `["Apply", ["Module", name], …]` (the Epsil `std::name(…)`), is shadowed
 * in `scope`, where `library` is the definition of `name` in the system
 * scope. The answer is read before the arguments are canonicalized.
 *
 * The name is not shadowed when the lookup of a head (`lookupApplicable()`,
 * with the parameter shadows) gives `library`, or an extension or a copy of
 * it that keeps its handlers, or gives nothing for a name that is not a
 * parameter being canonicalized. The call is then the plain call
 * `[name, …args]`, built by the normal route. Otherwise it is the same call
 * bound to `library`, built by `ce._libraryCall()`.
 */
export function shadowsQualifiedName(
  ce: ComputeEngine,
  name: string,
  library: BoxedDefinition,
  scope: Scope
): boolean {
  const current = lookupApplicable(name, scope, ce);
  // A parameter of a function literal whose body is being canonicalized gets
  // its binding on its first reference, so the lookup gives nothing for a
  // parameter that the body has not named yet. It still shadows the library
  // name: with `function g(Floor) { std::floor(2.5) }`, a plain call
  // `Floor(2.5)` would be a call of the parameter.
  return current === undefined
    ? ce._isShadowedParameter(name)
    : isShadowOf(current, library);
}

/** True when `s` is a type string that parses to a POLYTYPE (a `where`
 * clause). Used to reject a generic annotation on a function literal (D7,
 * §4.1 of the type-variables design); a non-type string is not our business
 * and answers `false`. */
function isPolytypeString(ce: ComputeEngine, s: string): boolean {
  if (!s.includes('where')) return false;
  try {
    return isPolymorphicType(parseType(s, ce._typeResolver));
  } catch {
    return false;
  }
}
