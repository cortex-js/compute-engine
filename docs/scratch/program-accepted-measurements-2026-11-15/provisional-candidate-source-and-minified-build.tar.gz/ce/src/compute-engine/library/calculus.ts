import { describeType } from '../boxed-expression/operand-descriptor.js';
import { appliedLiteralResultType } from '../boxed-expression/call-result-type.js';
import { heldDenotedType } from './held-operand-type.js';
import { BoxedType } from '../../common/type/boxed-type.js';
import type {
  BoxedDefinition,
  BoxedValueDefinition,
  Expression,
  IComputeEngine as ComputeEngine,
  OperandDescriptor,
  PureEngineView,
  Scope,
  SymbolDefinitions,
} from '../global-types.js';

import type { Type } from '../../common/type/types.js';
import type { MathJsonExpression } from '../../math-json/types.js';
import {
  functionResult,
  isPointElementType,
  stripMissingFromType,
  stripNumericRanges,
} from '../../common/type/utils.js';
import { isSubtype, widen } from '../../common/type/subtype.js';
import { parseType } from '../../common/type/parse.js';
import {
  checkType,
  checkOperandType,
  devolveValueElements,
} from '../boxed-expression/validate.js';
import {
  rebindEscaping,
  rebindEscapingCurrentScope,
  liftIntegrand,
  defaultImplicitVariable,
  implicitVariableCandidates,
  hasSymbolicTranscendental,
  resolveToList,
  collectBinderNames,
  namesReadByCalledFunctions,
  withValueShield,
  isOperatorDef,
  isValueDef,
  awaitedOperandOptions,
} from '../boxed-expression/utils.js';
import {
  isAbsentArithmeticOperand,
  isExpression,
  isFunction,
  isNumber,
  isString,
  isSymbol,
  sym,
  readBinding,
} from '../boxed-expression/type-guards.js';
import {
  ANONYMOUS_SLOT_NAMES,
  functionLiteralParameterName,
  functionLiteralParameterNames,
} from '../boxed-expression/function-literal.js';
import { paramsAreScalar } from '../boxed-expression/boxed-function.js';
import { errorValueWhere } from '../boxed-expression/error-value.js';
import { indefiniteIntegralVariables } from '../boxed-expression/binding-sites.js';
import {
  BOUND_ROLE,
  CLAUSE_ROLE,
  RAW_ROLE,
  operandRolesFrom,
} from './operand-roles.js';
import { isFunctionSymbolName } from '../boxed-expression/implicit-variable-rule.js';
import {
  conditionalValue,
  restrictionParts,
  isRestriction,
} from '../boxed-expression/conditional-value.js';
import {
  boundVariableBindings,
  boundVariableNames,
  boundVariableNamesInOperand,
  calledParameterValue,
  callableBindingInContext,
  ownBindingRewriteCount,
  parameterActivationValue,
  parameterValueVariesWith,
  rewriteWithBinders,
  sameBindingDef,
  withCallableBinding,
} from '../boxed-expression/binders.js';
import {
  memoDepsStillValid,
  snapshotMemoDeps,
  type MemoDeps,
} from '../boxed-expression/collection-element-memo.js';
import {
  beginObjectDeps,
  endObjectDeps,
  mergeObjectDeps,
  objectDepsValid,
  stampObjectDepsAtEnd,
  type ObjectDeps,
} from '../boxed-expression/object-deps.js';
import { containsObject } from '../boxed-expression/object-walk.js';
import { isTransitivelyPure } from '../boxed-expression/transitive-purity.js';
import { beginStoreGuard } from '../boxed-expression/store-guard.js';

import {
  applicable,
  applicableN1,
  canonicalFunctionLiteral,
  canonicalFunctionLiteralArguments,
  isApplicableDef,
} from '../function-utils.js';
import { monteCarloEstimate } from '../numerics/monte-carlo.js';
import { rationalize } from '../numerics/rationals.js';
import {
  divergentTailSign,
  tailIsFinite,
  tailReachesInfinity,
} from '../numerics/divergent-tail.js';
import { logSpaceProduct } from '../symbolic/log-space-product.js';
import {
  isIterationLimitCancellation,
  throwIfCallerCancellation,
} from '../../common/interruptible.js';
import { mixTags } from '../numerics/random.js';
import {
  adaptiveQuadrature,
  initialPanelsForDimensions,
  insideReplay,
  quadratureBeatsMonteCarlo,
} from '../numerics/gauss-kronrod.js';
import { integrateSemiInfiniteOscillatory } from '../numerics/oscillatory-quadrature.js';
import {
  centeredDiffHigherOrder,
  centeredDiffHigherOrderVector,
  limit,
  LIMIT_PROBE_ITERATION_BUDGET,
} from '../numerics/numeric.js';
import {
  derivative,
  differentiate,
  derivativeKeyUseCount,
  isDifferentiating,
  blockValue,
  literalBodyOverHoles,
  memoizedDerivativeResult,
  memoizedPartialDerivative,
  substituteParameters,
} from '../symbolic/derivative.js';
import {
  MAX_SIZE_EAGER_COLLECTION,
  typeCouldBeCollection,
  typeCouldBeNumericCollection,
  typeCouldBeNumericTuple,
  isTupleShapedType,
} from '../collection-utils.js';
// Self-registers the `expr.explain('D')` driver (see explain.ts)
import '../symbolic/explain-derivative.js';
import {
  antiderivative,
  unstableClosedForms,
} from '../symbolic/antiderivative.js';
import { integratePiecewise } from '../symbolic/piecewise-integrate.js';
import {
  withRadianConvention,
  rewriteAngularUnit,
} from '../symbolic/angular-unit.js';
import {
  integrateBoseMoment,
  polygammaDomainKnown,
} from '../symbolic/special-integrate.js';
import {
  continuousRange,
  finiteConstant,
  integrateBetaMoment,
  integrateDefiniteElementary,
  integrateTrigPolynomial,
} from '../symbolic/definite-integrate.js';
import { exactSign } from '../symbolic/contour.js';
import { integrateDiscreteMoments } from '../symbolic/definite-discrete.js';
import {
  hasHighDegreeReciprocalDenominator,
  integrateReciprocalRational,
} from '../symbolic/definite-reciprocal.js';
import { integrateComposition } from '../symbolic/integration-composition.js';
import { isElementaryIntegrationFunction } from '../symbolic/integration-normalize.js';
import { logarithmicParameterDifference } from '../symbolic/integration-logarithmic.js';
import {
  integrateBySubstitution,
  hasLargeIntegrationPower,
  generalizedBeta,
  exactExpression,
} from '../symbolic/definite-transform.js';
import {
  betaLogMoment,
  logarithmicParameter,
} from '../symbolic/definite-parameter.js';
import { integrateRationalTrig } from '../symbolic/definite-trig-transform.js';
import { integrateWeightedDiscrete } from '../symbolic/definite-periodic.js';
import {
  integrateDiscreteAlgebra,
  integrateDiscreteReciprocal,
} from '../symbolic/definite-discrete-algebra.js';
import {
  logarithmicSeriesMoment,
  integratedPowerSeries,
  telescopingProduct,
  infiniteTelescopingProduct,
} from '../symbolic/definite-summation.js';
import {
  integrateDefiniteSeries,
  integratePolynomialSeries,
  integrateProductDerivative,
} from '../symbolic/definite-series.js';
import {
  definiteIntegralByResidues,
  divergentIntegralValue,
  singularPathValue,
} from '../symbolic/contour-definite-integrate.js';
import {
  getPolynomialCoefficients,
  polynomialDegree,
} from '../boxed-expression/polynomials.js';
import {
  endpointPoleVerdict,
  halfLineEndpointPoleSign,
  isRealOnInterval,
  interiorPoleVerdict,
  symbolicExponentBaseZeros,
  symbolicPoleMayBeInside,
  type PoleVerdict,
} from '../symbolic/interior-pole.js';
import { dSolve } from '../symbolic/differential-equations.js';
import { rSolve } from '../symbolic/recurrences.js';
import {
  nDSolve,
  nDSolveFunction,
  interpolatingFunctionRows,
  symbolArg,
  symbolOrListArg,
} from '../differential-equation-utils.js';
import { evalDenseRows } from '../numerics/differential-equations.js';
import { hasNonRealConstant, symbolicLimit } from '../symbolic/limit.js';
import { residue } from '../symbolic/residue.js';
import { computeSeries, normalStrip } from '../symbolic/series.js';
import {
  canonicalLimits,
  canonicalLimitsSequence,
  canonicalWithEscapingReturn,
} from './utils.js';
import { implicitCompile } from '../implicit-compile.js';
import { resolveDerivativeFunctionLiteral } from '../derivative-function-literal.js';
import {
  implicitIntegrationVariable,
  unusedVariableName,
} from '../boxed-expression/integration-variables.js';
import { holdsKindValue } from '../boxed-expression/residue-class.js';
import {
  libraryNamesShadowedIn,
  libraryRuleBlocked,
  shadowsLibraryOperator,
} from '../library-shadowing.js';

/** `list<any>`, parsed once when the module loads, so the list tests below
 * do not parse the string on each call. */
const LIST_OF_ANY_TYPE = parseType('list<any>');

/**
 * The highest order the `D(f, {x, n})` spelling expands into `n` repeated
 * variables. Each order is one differentiation pass, so the work scales
 * with the VALUE of `n`; a larger order stays inert. A dedicated per-file
 * constant, as for the other value-scaled caps.
 */
const MAX_DERIVATIVE_ORDER = 1000;

/**
 * The highest total order for which the multi-index `Derivative` of an
 * operator (`Derivative(Power, k₁, k₂)`) builds its nested `D` expression,
 * one `D` for each unit of order. The evaluation of that expression recurses
 * once for each `D`, and near 500 levels it overflows the call stack (a
 * `RangeError` escaped the handler). A larger total order stays inert. The
 * cap loses few closed forms: measured, `Power` closes at order 32 but
 * stays inert at 64 after about 2 s of work, and `Arctan2` stays inert at
 * 64. `Multiply`, whose high partials are 0, is the exception.
 */
const MAX_NESTED_PARTIAL_ORDER = 64;

//
// ── Improper-integral endpoint limits (conditional-values Phase 3a) ──────
//
// FTC substitutes each bound into the antiderivative. At a *limit-point* bound
// (0, ±∞) the substitution can leave a parameter-dependent indeterminate — a
// Power with a base of 0/±∞ and a symbolic exponent (`0^{n+1}`, `∞^{1−s}`), or
// `e^{c·(±∞)}` with a symbolic rate `c`. Each such term has a limit of 0 on a
// convergence condition (`n+1 > 0`, `1−s < 0`, `c > 0`); we resolve it to 0 and
// carry the condition, so the definite integral becomes a restricted value.
// `Erf(c·(±∞))` and `Erfc(c·(±∞))`, from the antiderivative of a Gaussian
// with a symbolic coefficient, saturate to `±1` (`0` or `2`) under `c > 0`.
// Anything outside this small table fails closed (caller stays inert) rather
// than leaking an indeterminate form.
//

/**
 * The result of a binder whose value is an open expression in its variables
 * (`D`, `Series`, an indefinite `Integrate`), re-bound to the enclosing
 * scope (`rebindEscapingCurrentScope`), with each occurrence of one of the
 * `variables` that now denotes a parameter of the running function call
 * replaced by the value of the parameter in the call.
 *
 * In `x ↦ D(x^2, x)`, the value `2x` of the derivative is an expression in
 * the parameter `x`. The re-binding binds the `x` of `2x` to the binding of
 * the call frame for the parameter. The call replaces such occurrences by the
 * argument when its body is evaluated, except when the argument contains a
 * symbol with the same name (`x + 1`): an occurrence bound to the frame can
 * then come from the argument, which was bound in the frame, and the call
 * does not replace it (`bindingKeyedSubs`, `function-utils.ts`). So
 * `(x ↦ D(x^2, x))(x + 1)` gave `2x`. An occurrence that comes from the
 * variable of the binder cannot come from the argument, so it is replaced
 * here, where this is known: the value is `2(x + 1)`.
 *
 * `expression` is the node of the binder, from the options of its evaluate
 * handler. The evaluation of a scoped node pushes the local scope of the node
 * before it calls the handler, and the re-binding reads that scope on top of
 * the stack. A host can call the handler with no `expression`: then no scope
 * was pushed, the scope on top is the scope of the host (the global scope),
 * and the result is not re-bound. A re-binding there would box each symbol
 * of that scope again in its parent scope, which declares the name in the
 * parent scope: `x` in the system scope, where it reads as a library
 * definition that the global `x` hides, so the result would be written
 * `["Cos", ["Module", "x"]]`.
 */
function rebindEscapingBinderResult(
  ce: ComputeEngine,
  result: Expression,
  variables: readonly string[],
  numericApproximation: boolean | undefined,
  expression: Expression | undefined
): Expression {
  const rebound =
    expression?.localScope === undefined
      ? result
      : rebindEscapingCurrentScope(ce, result);
  if (variables.length === 0) return rebound;
  let closedValues = true;
  const inlined = rewriteWithBinders(rebound, (s, shadowed) => {
    if (shadowed?.has(s.symbol) || !variables.includes(s.symbol)) return s;
    const value = parameterActivationValue(ce, s);
    if (value === undefined) return s;
    if (value.freeVariables.length > 0) closedValues = false;
    return value;
  });
  // The result was folded before the values were put in it: `2x` at `3.5`
  // is `2 · 3.5`. It is folded again, with the numeric request of the
  // handler, when each value has no free variable.
  // A value with a free variable is not evaluated here, in the call frame:
  // its `x` would be read as the parameter `x`.
  // A series keeps its `BigO` remainder through this fold:
  // `Series(sin x, x, 0, 3)` at `0.5` is `0.479… + BigO(0.03125)`.
  return inlined !== rebound && closedValues
    ? inlined.evaluate({ numericApproximation })
    : inlined;
}

/**
 * The value of an `Integrate` node, `expression`, re-bound on the way out of
 * its frame (`rebindEscapingBinderResult`, with the variables of its
 * indefinite limits).
 *
 * The evaluate handler of `Integrate` calls it on every value that can hold
 * an occurrence of an integration variable. Such a value can come from
 * another `Integrate` that the handler makes and evaluates while its own
 * frame is on top (the integrand with the values of the parameters of a
 * call, with renamed variables, or with inlined user functions). The scope
 * of that integral is a child of the scope of this one, so its value is
 * re-bound to the variable of THIS integral, which is discarded when the
 * handler returns: the value must be re-bound once more. With
 * `g(f) := ∫ f dx`, the `x` of the value `x²/2` of `g(x)` was not the
 * global `x`.
 */
function rebindIntegralResult(
  ce: ComputeEngine,
  value: Expression,
  expression: Expression | undefined,
  numericApproximation: boolean | undefined
): Expression {
  return rebindEscapingBinderResult(
    ce,
    value,
    [...((expression && indefiniteIntegralVariables(expression)) ?? [])],
    numericApproximation,
    expression
  );
}

/**
 * The names of the parameters of the running function call that `operand`
 * reads, whose value holds a symbol with the name of one of `variables` but
 * does not vary with that variable (`parameterValueVariesWith`). Call it
 * inside the evaluation of the binder (`D`, `Integrate`) whose variables
 * these are.
 *
 * In `(x, y) ↦ D(x·y, x)` applied at `(3, x)`, the value of `y` is the `x`
 * of the caller. Read during the differentiation, it was folded with the
 * variable `x` of the `D`: the product rule gave `x + 3`, and
 * `(x, a) ↦ ∫ a·x dx` at `(x + 1, x)` gave `x³/2`. The binder shields these
 * parameters, so that they are opaque symbols while it works (`D(x·y, x)`
 * is `y`), and the call puts their values in its result after.
 */
function independentParameterNames(
  ce: ComputeEngine,
  operand: Expression,
  variables: readonly string[]
): string[] {
  if (variables.length === 0) return [];
  const names = new Set<string>();
  rewriteWithBinders(operand, (s, shadowed) => {
    const name = s.symbol;
    if (shadowed?.has(name) || variables.includes(name) || names.has(name))
      return s;
    const v = parameterActivationValue(ce, s);
    if (
      v !== undefined &&
      variables.some((n) => v.has(n)) &&
      !variables.some((n) => parameterValueVariesWith(ce, v, n))
    )
      names.add(name);
    return s;
  });
  return [...names];
}

/**
 * The call `app` of a parameter of the running function call that holds a
 * function, as an application of that function: `f(x)` becomes
 * `Apply(value, x)`, where `ops` are the operands of `app` after a rewrite.
 * `undefined` when the operator of `app` is not such a parameter, or is
 * bound by a binder between the operand and `app` (`shadowed`).
 *
 * `differentiate()` reads the body of a called function by the name of the
 * function. The value of the parameter `w` in `w ↦ D(w(x), x)` applied to
 * `x ↦ 5·w(x)` calls the user function `w(x) := x + 100`, a different
 * function with the same name: read by name, the call was taken for a
 * recursive call and the derivative was `Apply(Derivative(w, 1), x)`, whose
 * `w` was then read as the user function. The application of the value is
 * differentiated as the value, with the name `w` bound to the user function
 * while the binder works (`withOperandBindings`): the derivative is 5.
 *
 * The name of each parameter that is replaced is added to `replaced`.
 */
function callOfFunctionParameter(
  ce: ComputeEngine,
  app: Expression,
  ops: ReadonlyArray<Expression>,
  shadowed: ReadonlySet<string> | undefined,
  replaced: Set<string>
): Expression | undefined {
  if (shadowed?.has(app.operator)) return undefined;
  const value = calledParameterValue(ce, app);
  if (value === undefined || !value.type.matches('function')) return undefined;
  replaced.add(app.operator);
  return ce.function('Apply', [value, ...ops], {
    form: app.isCanonical ? 'canonical' : 'raw',
  });
}

/**
 * The value of `app`, an application `Apply(ℓ, …ops)` of a function literal
 * `ℓ`, where `ops` are the operands of `app` after a rewrite: the body of
 * the literal with the arguments in place of its parameters, as the
 * evaluation of `Apply` gives it (`Apply(t ↦ t^2, x)` is `x^2`).
 * `undefined` when `app` is not such an application, or when its
 * evaluation does not reduce it (the arguments do not fit the parameters).
 */
function appliedFunctionLiteral(
  ce: ComputeEngine,
  app: Expression,
  ops: ReadonlyArray<Expression>
): Expression | undefined {
  if (app.operator !== 'Apply' || !isFunction(ops[0], 'Function'))
    return undefined;
  const value = ce.function('Apply', ops).evaluate();
  return value.operator === 'Apply' ? undefined : value;
}

/**
 * Run `fn` with each of `names` bound to the definition that its
 * occurrences in `operand` denote, in a scope pushed for the run.
 *
 * `names` are parameters of the running function call whose calls in
 * `operand` were replaced by applications of their values
 * (`callOfFunctionParameter`). An occurrence of such a name that is left in
 * `operand` comes from a value: in `w ↦ D(w(x), x)` applied to
 * `x ↦ 5·w(x)`, the `w` of the value is the user function `w`, not the
 * parameter. `differentiate()` and the integration read a called function by
 * its name in the current scope, where the name is the parameter. In the
 * pushed scope, the name is the user function.
 *
 * A name is bound only when all its occurrences in `operand` denote one
 * definition that is not the parameter (an occurrence of the parameter that
 * is not a call, such as `w` in `Length([w])`, is still there). Otherwise,
 * the scope does not bind it.
 */
function withOperandBindings<T>(
  ce: ComputeEngine,
  operand: Expression | undefined,
  names: ReadonlySet<string>,
  fn: () => T
): T {
  if (operand === undefined || names.size === 0) return fn();
  const bindings = new Map<string, BoxedDefinition>();
  for (const name of names) {
    // `undefined`: no occurrence yet; `null`: no single definition.
    let entry: BoxedDefinition | null | undefined;
    const note = (e: Expression, isParameter: boolean): void => {
      if (entry === null) return;
      const own =
        e.valueDefinition !== undefined
          ? { value: e.valueDefinition }
          : e.operatorDefinition !== undefined
            ? { operator: e.operatorDefinition }
            : undefined;
      const found =
        isParameter || own === undefined
          ? undefined
          : callableBindingInContext(ce, name, own);
      if (found === undefined) entry = null;
      else if (entry === undefined) entry = found;
      else if (entry !== found) entry = null;
    };
    rewriteWithBinders(
      operand,
      (s, shadowed) => {
        if (s.symbol === name && !shadowed?.has(name))
          note(s, parameterActivationValue(ce, s) !== undefined);
        return s;
      },
      undefined,
      false,
      undefined,
      (app, _ops, shadowed) => {
        if (app.operator === name && !shadowed?.has(name))
          note(app, calledParameterValue(ce, app) !== undefined);
        return undefined;
      }
    );
    if (entry && entry !== ce.lookupDefinition(name)) bindings.set(name, entry);
  }
  if (bindings.size === 0) return fn();
  ce.pushScope({ parent: ce.context.lexicalScope, bindings });
  try {
    return fn();
  } finally {
    // The scope borrows definitions: popping it must not dispose of their
    // facts.
    bindings.clear();
    ce.popScope();
  }
}

/**
 * Classify a single node as a limit-point endpoint leak. Returns:
 *   - `{ value, guard }`  — a resolvable leak: its limit `value` under `guard`;
 *   - `'unresolvable'`    — a leak-family shape not covered (fail closed);
 *   - `null`             — not a leak (recurse into children).
 * A decidable (numeric) exponent is not a leak: it would already have folded.
 */
function classifyEndpointLeak(
  node: Expression,
  ce: ComputeEngine
): { value: Expression; guard: Expression } | 'unresolvable' | null {
  if (!isFunction(node, 'Power')) return classifyErfEndpointLeak(node, ce);
  const base = node.op1;
  const exp = node.op2;

  // x^p as x → 0⁺ : residual `0^p` → 0 when Re(p) > 0.
  if (base.isSame(0)) {
    if (isNumber(exp)) return null;
    return {
      value: ce.Zero,
      guard: ce.function('Greater', [guardRealPart(exp, ce), ce.Zero]),
    };
  }

  // x^p as x → +∞ : residual `(+∞)^p` → 0 when Re(p) < 0.
  if (base.isInfinity === true && base.isPositive === true) {
    if (isNumber(exp)) return null;
    return {
      value: ce.Zero,
      guard: ce.function('Less', [guardRealPart(exp, ce), ce.Zero]),
    };
  }

  // (−∞)^p : sign oscillation — not in the table.
  if (base.isInfinity === true && base.isNegative === true) {
    if (isNumber(exp)) return null;
    return 'unresolvable';
  }

  // e^{c·(±∞)} as x → ±∞ : → 0 when the exponent → −∞.
  if (isSymbol(base, 'ExponentialE')) return classifyExpEndpointLeak(exp, ce);

  return null;
}

/**
 * Whether `e` is a number literal `±∞` or `~∞`, or holds one at any depth.
 * `has()` cannot answer this: it searches symbols, and the infinities are
 * number literals, so `has(['PositiveInfinity', 'NegativeInfinity'])` is
 * `false` for `(−∞)·√(s⁻²)`.
 */
function holdsInfinity(e: Expression): boolean {
  if (isNumber(e)) return e.isInfinity === true;
  return isFunction(e) && e.ops.some(holdsInfinity);
}

/**
 * Split `q = (±∞)·c` into the sign of its single infinite factor and the
 * finite, non-numeric cofactor `c`. Returns `null` when `q` is not such a
 * product (a numeric cofactor is decidable and would already have folded),
 * and `'unresolvable'` when `q` holds two infinite factors.
 *
 * A sum `(±∞)·c + d` whose other terms `d` hold no infinity is split as its
 * infinite term: the finite terms do not change the limit of `e^{q}` or
 * `Erf(q)`. The value at the lower bound of `∫_{−∞}^{x} e^{−(z−m)²/(2s²)} dz`
 * is `Erf((−∞)·√(s⁻²) − m·√(s⁻²))`, which the sum handler keeps as a sum
 * because the sign of `√(s⁻²)` is not known.
 */
function splitInfiniteProduct(
  q: Expression,
  ce: ComputeEngine
): { infSign: 1 | -1; cofactor: Expression } | 'unresolvable' | null {
  if (isFunction(q, 'Add')) {
    const infinite = q.ops.filter(holdsInfinity);
    if (infinite.length !== 1)
      return infinite.length === 0 ? null : 'unresolvable';
    return splitInfiniteProduct(infinite[0], ce);
  }
  if (!isFunction(q, 'Multiply')) return null;
  let infSign: 0 | 1 | -1 = 0;
  const rest: Expression[] = [];
  for (const f of q.ops) {
    if (f.isInfinity === true) {
      if (infSign !== 0) return 'unresolvable';
      // The undirected infinity `~∞` has neither sign: `e^{q}` and
      // `Erf(q)` have no limit there.
      if (f.isPositive === true) infSign = 1;
      else if (f.isNegative === true) infSign = -1;
      else return 'unresolvable';
    } else rest.push(f);
  }
  if (infSign === 0 || rest.length === 0) return null;
  const cofactor = rest.length === 1 ? rest[0] : ce.function('Multiply', rest);
  if (isNumber(cofactor)) return null;
  return { infSign, cofactor };
}

/**
 * Classify an exponential endpoint leak `e^{q}` by its exponent `q`. Resolves
 * only `q = (±∞)·c` with a single infinite factor and a finite, non-numeric
 * cofactor `c`: the limit is 0 when `q → −∞`, i.e. `c > 0` for a `−∞` factor,
 * `c < 0` for a `+∞` factor.
 */
function classifyExpEndpointLeak(
  q: Expression,
  ce: ComputeEngine
): { value: Expression; guard: Expression } | 'unresolvable' | null {
  const split = splitInfiniteProduct(q, ce);
  if (split === null || split === 'unresolvable') return split;
  const { infSign, cofactor } = split;
  // `e^{c·(−∞)}` → 0 when Re(c) > 0, and `e^{c·(+∞)}` → 0 when Re(c) < 0.
  const re = guardRealPart(cofactor, ce);
  const guard =
    infSign < 0
      ? ce.function('Greater', [re, ce.Zero])
      : ce.function('Less', [re, ce.Zero]);
  return { value: ce.Zero, guard };
}

/**
 * Classify an error-function endpoint leak `Erf(q)` or `Erfc(q)` with
 * `q = (±∞)·c`, a single infinite factor and a finite, non-numeric cofactor
 * `c`. Such a term is the value at an infinite bound of the antiderivative of
 * a Gaussian with a symbolic coefficient: `∫_{−∞}^{x} e^{−z²/(2s²)} dz` is
 * `√(π/2)·√(s²)·(Erf(x/(√2·√(s²))) + 1)` for a real `s`, the normal
 * distribution of Tycho row 428. `Erf` saturates at a signed real infinity,
 * `Erf(+∞) = 1` and `Erf(−∞) = −1`, so for `c > 0` the value is the sign of
 * the infinite factor, and `Erfc = 1 − Erf` gives `0` at `+∞` and `2` at
 * `−∞`. The guard `c > 0` is carried as the condition of the result, the
 * way `∫₀^∞ e^{−cx} dx` is `1/c {0 < c}`; a cofactor that is not a positive
 * real number (a negative `c` flips both values, a complex `c` outside
 * `|arg c| < π/4` has no limit) leaves the guard false and the result with
 * no value. `Erfi` grows without bound at a real infinity, so an `Erfi`
 * leak is unresolvable.
 */
function classifyErfEndpointLeak(
  node: Expression,
  ce: ComputeEngine
): { value: Expression; guard: Expression } | 'unresolvable' | null {
  if (!isFunction(node, 'Erf') && !isFunction(node, 'Erfc')) {
    if (!isFunction(node, 'Erfi')) return null;
    const split = splitInfiniteProduct(node.op1, ce);
    return split === null ? null : 'unresolvable';
  }
  const split = splitInfiniteProduct(node.op1, ce);
  if (split === null || split === 'unresolvable') return split;
  const { infSign, cofactor } = split;
  const erf = infSign; // Erf(c·(±∞)) for c > 0
  const value = node.operator === 'Erf' ? ce.number(erf) : ce.number(1 - erf); // Erfc
  const guard = ce.function('Greater', [cofactor, ce.Zero]);
  return { value, guard };
}

/**
 * The operand of a convergence guard on the real part of `p` (`Re(p) > 0`,
 * `Re(p) < 0`): `Real(p)` when `p` holds a constant that is not real, and
 * `p` itself otherwise.
 *
 * An ordered comparison with a value that is not a real number is `False`
 * (`0 < 1 + iπ` is `False`), so a guard written over `p` itself would reject
 * a convergent integral with a complex exponent: `∫₀¹ x^{iπ} dx` converges
 * to `1/(1 + iπ)`, because `Re(1 + iπ) = 1 > 0`. A constant part of `p` is
 * not real when it has no free variable and its type is not `real`
 * (`iπ`, `ln(−1)`, `√(−2)`). A `p` whose constants are all real (`n + 1`,
 * with `n` free) keeps the guard `n + 1 > 0`, as written for a real
 * parameter.
 */
function guardRealPart(p: Expression, ce: ComputeEngine): Expression {
  const hasNonRealConstantPart = (e: Expression): boolean => {
    if (e.unknowns.length === 0) return !e.type.matches('real');
    return isFunction(e) && e.ops.some(hasNonRealConstantPart);
  };
  if (!hasNonRealConstantPart(p)) return p;
  return ce.function('Real', [p]);
}

/** Integrands that `Integrate` is evaluating after it replaced the parameters
 * of the running function call by their values (see the `Integrate`
 * evaluate handler). */
const substitutedIntegrands: Expression[] = [];

/**
 * Whether the convergence guards require an expression to be both positive
 * and negative. Each guard is a comparison of an expression with 0
 * (`0 < p`, `p < 0`, and the same inside an `And`). A set of guards that
 * contradict each other holds for no value of the parameter, so a result
 * under them has no value (`∫₀^∞ xⁿ dx` leaks `0^(n+1)`, a limit under
 * `n + 1 > 0`, and `∞^(n+1)`, a limit under `n + 1 < 0`): the caller leaves
 * the integral unevaluated instead of returning a value under a condition
 * that nothing satisfies.
 */
function guardsContradict(guards: ReadonlyArray<Expression>): boolean {
  const positive: Expression[] = [];
  const negative: Expression[] = [];
  const collect = (g: Expression): void => {
    if (isFunction(g, 'And')) {
      g.ops.forEach(collect);
      return;
    }
    if (!isFunction(g, 'Less') && !isFunction(g, 'Greater')) return;
    if (g.nops !== 2) return;
    // `a < b` and `b > a` both say `b − a > 0`.
    const [small, large] = g.operator === 'Less' ? g.ops : [g.op2, g.op1];
    if (small.isSame(0)) positive.push(large);
    else if (large.isSame(0)) negative.push(small);
  };
  guards.forEach(collect);
  return positive.some((p) => negative.some((n) => p.isSame(n)));
}

/**
 * The functions of one real argument that have a limit, finite or infinite,
 * at `+∞` and at `−∞`: each one is monotone on the real line, or on each
 * side of `0`, or has a limit at both ends (`SinIntegral`). Such a function
 * of `(±∞)·a` has a value for each real `a ≠ 0`: `SinIntegral((+∞)·a)`, the
 * value of `∫₀^∞ sin(ax)/x dx`, is `π/2` for `a > 0` and `−π/2` for `a < 0`.
 * For `Root`, only the radicand is the argument.
 */
const LIMIT_AT_INFINITY_FUNCTIONS = new Set([
  'Abs',
  'Arctan',
  'Arsinh',
  'Cosh',
  'Exp',
  'Ln',
  'Root',
  'Sign',
  'SinIntegral',
  'Sinh',
  'Sqrt',
  'Tanh',
]);

/**
 * Whether an infinity in the operands `ops` of a node with the operator
 * `operator` gives a value that the walk of `resolveEndpointLeaks` can keep.
 *
 * Arithmetic keeps the infinity in the value, where its sign stays visible:
 * `(+∞)·y`, the value of `∫₀^∞ y dx`, is `+∞` for `y > 0` and `−∞` for
 * `y < 0`. A `Power` keeps an infinity in its base for the same reason, and
 * a function of `LIMIT_AT_INFINITY_FUNCTIONS` keeps one in its first
 * operand. Any other function, or another operand, that holds an infinity
 * returns `false`, and the integral stays unevaluated: the walk cannot tell
 * whether such a term has a limit. Most of them have none. The
 * antiderivative `sin(xy)/y` of `cos(xy)` gives `sin((+∞)·y)/y` at
 * `x = +∞`, but `sin(xy)` oscillates, so `∫₀^∞ cos(xy) dx` diverges. An
 * infinity in an exponent (`a^{(+∞)·y}`) depends on the base and on the sign
 * of `y`. The leaks that have a known limit and a convergence condition
 * (`e^{c·(±∞)}`, `Erf(c·(±∞))`) are replaced by `classifyEndpointLeak`
 * before this test.
 */
function passesInfinityThrough(
  operator: string,
  ops: ReadonlyArray<Expression>
): boolean {
  if (
    operator === 'Add' ||
    operator === 'Subtract' ||
    operator === 'Multiply' ||
    operator === 'Negate' ||
    operator === 'Divide'
  )
    return true;
  if (operator === 'Power' || LIMIT_AT_INFINITY_FUNCTIONS.has(operator))
    return !ops.slice(1).some(holdsInfinity);
  return !ops.some(holdsInfinity);
}

/**
 * Walk an FTC result, replacing endpoint-limit leaks (`classifyEndpointLeak`)
 * by their resolved values and conjoining their convergence guards. Returns
 * `{ value, guard }` (guard `True` when leak-free — the value is then the
 * untouched input), or `null` when a leak cannot be resolved (fail closed).
 */
function resolveEndpointLeaks(
  expr: Expression,
  ce: ComputeEngine
): { value: Expression; guard: Expression } | null {
  const leak = classifyEndpointLeak(expr, ce);
  if (leak === 'unresolvable') return null;
  if (leak) return leak;
  if (!isFunction(expr)) return { value: expr, guard: ce.True };

  const guards: Expression[] = [];
  const newOps: Expression[] = [];
  let changed = false;
  for (const op of expr.ops) {
    const r = resolveEndpointLeaks(op, ce);
    if (r === null) return null;
    newOps.push(r.value);
    if (r.value !== op) changed = true;
    if (!isSymbol(r.guard, 'True')) guards.push(r.guard);
  }
  if (guardsContradict(guards)) return null;
  if (!passesInfinityThrough(expr.operator, newOps)) return null;
  const value = changed ? ce.function(expr.operator, newOps) : expr;
  const guard =
    guards.length === 0
      ? ce.True
      : guards.length === 1
        ? guards[0]
        : ce.function('And', guards);
  return { value, guard };
}

/**
 * Evaluate the definite value `F(upper) − F(lower)` of an antiderivative when
 * the value of `F` at a bound is a limit. At an infinite bound, naive
 * substitution can leave an `∞·0` product — an antiderivative term such as
 * `poly(var)·e^{−c·var}` — which `evaluate()` collapses to `NaN`; the
 * mathematically correct endpoint value is the limit `lim_{var→±∞} F(var)`.
 * A finite bound is a direct substitution, and when that has no value either
 * (`t·ln t − t` at `0` is `0·(−∞)`, for `∫₀¹ ln t dt`), the value is the
 * one-sided limit from inside the interval (`t·ln t → 0` as `t → 0⁺`, so the
 * integral is `−1`). Only a FINITE limit is taken at a finite bound: an
 * infinite one is the sign of a pole at the bound, which the caller decides
 * from the integrand (`endpointPoleVerdict`), not from the antiderivative.
 * Returns `undefined` (caller falls back to an inert integral) when an
 * endpoint cannot be resolved to a definite value.
 */
function improperEndpointValue(
  antideriv: Expression,
  variable: string,
  lower: Expression,
  upper: Expression,
  ce: ComputeEngine,
  numericApproximation: boolean
): Expression | undefined {
  // The direction of integration: `1` when `lower < upper`. The one-sided
  // limit at the lower bound is taken in that direction, at the upper bound
  // in the opposite one.
  const orientation = decidedSign(ce.function('Subtract', [upper, lower]));
  const endpoint = (
    bound: Expression,
    side: 1 | -1
  ): Expression | undefined => {
    if (bound.isInfinity === true) {
      const lim = symbolicLimit(antideriv, variable, bound, undefined, ce);
      if (lim === undefined || lim.operator === 'Limit' || lim.isNaN === true)
        return undefined;
      return lim;
    }
    const v = antideriv
      .subs({ [variable]: bound })
      .evaluate({ numericApproximation });
    // An error (`cos(1/t)` at `0` is `cos(~∞)`, an incompatible-type error)
    // is no value either.
    if (v.isNaN !== true && v.isValid) return v;
    if (orientation !== 1 && orientation !== -1) return undefined;
    const lim = symbolicLimit(
      antideriv,
      variable,
      bound,
      orientation * side,
      ce
    );
    // A limit that holds an infinity anywhere (`−∞·0^n`, whose finiteness
    // depends on `n`) is not a finite value.
    if (
      lim === undefined ||
      lim.operator === 'Limit' ||
      lim.isNaN === true ||
      lim.isInfinity === true ||
      holdsInfinity(lim) ||
      lim.has(variable)
    )
      return undefined;
    return numericApproximation ? lim.N() : lim;
  };
  const fUpper = endpoint(upper, -1);
  if (fUpper === undefined) return undefined;
  const fLower = endpoint(lower, 1);
  if (fLower === undefined) return undefined;
  const result = fUpper.sub(fLower).evaluate({ numericApproximation });
  return result.isNaN === true ? undefined : result;
}

/** An `Abs(u)` or `Sign(u)` subexpression of an integrand whose argument is
 * a polynomial of degree 1 or 2 in the integration variable, with
 * coefficients free of the variable. The integrand has a kink (or a jump) at
 * each real `root` of `u` (none, one or two). `coefs` are the coefficients of
 * `u`, constant term first. */
type IntegrandKink = {
  arg: Expression;
  coefs: Expression[];
  roots: Expression[];
};

/** Whether operand `index` of `expr` is inside a nested binder of the name
 * `variable`: an inner `Integrate`, `Sum`, function literal, etc. that binds
 * its own variable with that name. There, an occurrence of the name is the
 * inner variable, not the integration variable of the outer integral, and
 * it must be neither collected as a kink nor replaced. In
 * `∫_0^1 (∫_{−a}^{a} |x| cos x dx) dx`, the `|x|` belongs to the inner
 * integral, and replacing it by `x` changed the inner value. */
function bindsVariableInOperand(
  expr: Expression,
  index: number,
  variable: string
): boolean {
  return boundVariableNamesInOperand(expr, index).includes(variable);
}

/** Collect the kinks of `expr` in `variable` (see `IntegrandKink`). An `Abs`
 * or `Sign` whose argument is not linear in the variable is not collected;
 * its own argument is still searched. The operands of a nested binder of
 * the same name are not searched (see `bindsVariableInOperand`). */
function collectIntegrandKinks(
  expr: Expression,
  variable: string,
  out: IntegrandKink[]
): void {
  if (!isFunction(expr)) return;
  const degree =
    (expr.operator === 'Abs' || expr.operator === 'Sign') &&
    expr.nops === 1 &&
    expr.op1.has(variable)
      ? polynomialDegree(expr.op1, variable)
      : 0;
  if (
    (degree === 1 || degree === 2) &&
    !out.some((kink) => kink.arg.isSame(expr.op1))
  ) {
    const coefs = getPolynomialCoefficients(expr.op1, variable);
    if (coefs && coefs.length === degree + 1) {
      const ce = expr.engine;
      const [c, b, a] = coefs.map((x) => x.evaluate());
      if (degree === 1 && !b.isSame(0)) {
        const root = ce.function('Divide', [ce.function('Negate', [c]), b]);
        out.push({ arg: expr.op1, coefs: [c, b], roots: [root.evaluate()] });
        return;
      }
      if (degree === 2 && !a.isSame(0)) {
        // The real roots of `a·x² + b·x + c`. A discriminant whose sign
        // cannot be decided leaves the quadratic out, as before.
        const disc = ce
          .function('Subtract', [
            ce.function('Square', [b]),
            ce.function('Multiply', [ce.number(4), a, c]),
          ])
          .evaluate();
        const sign = decidedSign(disc);
        if (sign !== undefined) {
          const roots: Expression[] = [];
          if (sign === 0)
            roots.push(
              ce
                .function('Divide', [
                  ce.function('Negate', [b]),
                  ce.function('Multiply', [ce.number(2), a]),
                ])
                .evaluate()
            );
          else if (sign > 0)
            for (const pm of [1, -1])
              roots.push(
                ce
                  .function('Divide', [
                    ce.function('Add', [
                      ce.function('Negate', [b]),
                      ce.function('Multiply', [
                        ce.number(pm),
                        ce.function('Sqrt', [disc]),
                      ]),
                    ]),
                    ce.function('Multiply', [ce.number(2), a]),
                  ])
                  .evaluate()
              );
          out.push({ arg: expr.op1, coefs: [c, b, a], roots });
          return;
        }
      }
    }
  }
  expr.ops.forEach((op, i) => {
    if (!bindsVariableInOperand(expr, i, variable))
      collectIntegrandKinks(op, variable, out);
  });
}

/** The sign of `value` (`−1`, `0` or `1`), or `undefined` when it cannot be
 * decided: the value has free symbols, is not real, or is so close to zero
 * that a machine-precision comparison cannot be trusted. */
function decidedSign(value: Expression): -1 | 0 | 1 | undefined {
  const v = value.evaluate();
  if (v.isSame(0)) return 0;
  if (v.isPositive === true) return 1;
  if (v.isNegative === true) return -1;
  const n = v.N();
  if (!isNumber(n) || n.isComplex) return undefined;
  const r = n.re;
  if (Number.isNaN(r) || Math.abs(r) < 1e-10) return undefined;
  return r > 0 ? 1 : -1;
}

/**
 * Evaluate a definite integral whose integrand has kinks (`Abs(u)` or
 * `Sign(u)` with `u` linear in the integration variable) by splitting the
 * interval at the kinks.
 *
 * The fundamental theorem of calculus needs an antiderivative that is
 * continuous on the whole interval. The antiderivative of such an integrand
 * often has a `Sign(u)` term (`∫ |x| cos x dx = sin(x)|x| + cos(x)·sgn(x)`),
 * which jumps where `u` changes sign. When that point is inside the bounds,
 * `F(b) − F(a)` adds the jump to the result (`∫_{−π}^{π} |x| cos x dx` gave
 * `−2`, the correct value is `−4`). When the point is at a bound, `Sign(0) = 0`
 * is neither one-sided value and `F(b) − F(a)` is wrong too.
 *
 * On each piece between consecutive kinks, each `u` keeps one sign, so
 * `Abs(u)` is replaced by `u` or `−u` and `Sign(u)` by `1` or `−1`. Each
 * piece is then integrated separately and the results are added.
 *
 * Returns:
 * - the value of the integral when every piece has a closed form;
 * - `'inert'` when a piece has no closed form: the caller keeps the whole
 *   definite integral unevaluated rather than returning a partial sum;
 * - `undefined` when the integrand has no kink or the position of a kink
 *   relative to the bounds cannot be decided (symbolic bounds). The caller
 *   then continues with the whole-interval antiderivative.
 */
function integrateAcrossKinks(
  ce: ComputeEngine,
  integrand: Expression,
  variable: string,
  lower: Expression,
  upper: Expression,
  numericApproximation: boolean
): Expression | 'inert' | undefined {
  const kinks: IntegrandKink[] = [];
  collectIntegrandKinks(integrand, variable, kinks);
  if (kinks.length === 0) return undefined;

  // A kink whose coefficient is not real, as in `|x + i|`, is not a kink:
  // `|x + i| = √(x² + 1)` is smooth, and `u` has no real point where it
  // changes sign. The built-in antiderivative of `|u|` and `sgn(u)` is valid
  // only for a real `u`, so keep the integral unevaluated.
  const notReal = (e: Expression) => {
    const n = e.N();
    return isNumber(n) && n.isComplex;
  };
  if (kinks.some(({ coefs }) => coefs.some(notReal))) return 'inert';

  const diff = (a: Expression, b: Expression) =>
    decidedSign(ce.function('Subtract', [a, b]));

  // `dir` is the direction of integration: 1 when `lower < upper`, −1 when
  // the bounds are reversed. The cuts are ordered in that direction, which
  // keeps `∫_a^b = Σ ∫_{p_i}^{p_{i+1}}` valid in both cases.
  const dir = diff(upper, lower);
  if (dir === undefined || dir === 0) return undefined;

  // The kinks STRICTLY inside the bounds, deduplicated and sorted in the
  // direction of integration. A kink at a bound or outside the bounds does
  // not cut the interval, but its `Abs`/`Sign` is still resolved below.
  const cuts: Expression[] = [];
  for (const root of kinks.flatMap((kink) => kink.roots)) {
    const afterLower = diff(root, lower);
    const beforeUpper = diff(upper, root);
    if (afterLower === undefined || beforeUpper === undefined) return undefined;
    if (afterLower * dir <= 0 || beforeUpper * dir <= 0) continue;
    let at = cuts.length;
    for (let i = 0; i < cuts.length; i++) {
      const order = diff(root, cuts[i]);
      if (order === undefined) return undefined;
      if (order === 0) {
        at = -1;
        break;
      }
      if (order * dir < 0) {
        at = i;
        break;
      }
    }
    if (at >= 0) cuts.splice(at, 0, root);
  }

  const points = [lower, ...cuts, upper];
  const pieces: Expression[] = [];
  for (let i = 0; i + 1 < points.length; i++) {
    const [p, q] = [points[i], points[i + 1]];
    // A point strictly inside the piece, where the sign of each `u` is read.
    // No kink is strictly inside the piece, so any such point gives the sign
    // `u` has on the whole piece.
    const sample =
      p.isInfinity === true && q.isInfinity === true
        ? ce.Zero
        : p.isInfinity === true
          ? ce.function('Subtract', [q, ce.number(dir)])
          : q.isInfinity === true
            ? ce.function('Add', [p, ce.number(dir)])
            : ce.function('Divide', [ce.function('Add', [p, q]), ce.number(2)]);
    const signs: number[] = [];
    for (const { coefs } of kinks) {
      // The value of the polynomial at `sample`, by Horner's rule.
      let value: Expression = coefs[coefs.length - 1];
      for (let n = coefs.length - 2; n >= 0; n--)
        value = ce.function('Add', [
          ce.function('Multiply', [value, sample]),
          coefs[n],
        ]);
      const s = decidedSign(value);
      if (s === undefined || s === 0) return undefined;
      signs.push(s);
    }
    const resolve = (e: Expression): Expression => {
      if (!isFunction(e)) return e;
      if ((e.operator === 'Abs' || e.operator === 'Sign') && e.nops === 1) {
        const j = kinks.findIndex((kink) => kink.arg.isSame(e.op1));
        if (j >= 0) {
          if (e.operator === 'Sign') return ce.number(signs[j]);
          return signs[j] > 0 ? e.op1 : ce.function('Negate', [e.op1]);
        }
      }
      const ops = e.ops.map((op, n) =>
        bindsVariableInOperand(e, n, variable) ? op : resolve(op)
      );
      if (ops.every((op, n) => op === e.ops[n])) return e;
      return ce.function(e.operator, ops);
    };
    const piece = ce
      .function('Integrate', [
        resolve(integrand),
        ce.function('Limits', [ce.symbol(variable), p, q]),
      ])
      .evaluate({ numericApproximation });
    if (piece.has('Integrate')) return 'inert';
    pieces.push(piece);
  }
  return ce.function('Add', pieces).evaluate({ numericApproximation });
}

/**
 * Evaluate a definite integral whose integrand has a power with a symbolic
 * exponent whose base is zero at a point strictly inside the bounds —
 * `∫₋₁¹ t^(−n) dt`, `∫₀² (t − 1)^(−n) dt`, `∫₋₁¹ t^n dt` — by splitting the
 * interval at those points (see `symbolicExponentBaseZeros`).
 *
 * The antiderivative difference over the whole interval is a closed form
 * (`1/(1 − n) − (−1)^(1 − n)/(1 − n)`) whatever `n` is, although the integral
 * diverges for every `n ≥ 1`: the fundamental theorem of calculus needs an
 * integrand that is bounded between the bounds. Each piece has the zero AT a
 * bound, where the antiderivative route resolves the endpoint `0^(1 − n)`
 * into a convergence guard (`resolveEndpointLeaks`), and the pieces add up
 * to `1/(1 − n) − (−1)^(1 − n)/(1 − n) {n < 1}`: the value, with the
 * condition under which it is the value of the integral. (Mathematica gives
 * the same: `ConditionalExpression[(1 + E^(-I n π))/(1 − n), Re[n] < 1]`.)
 *
 * Returns the sum when every piece has a value, `'inert'` when a piece stays
 * unevaluated (the caller keeps the whole integral unevaluated rather than a
 * partial sum) or a zero cannot be given exactly, and `undefined` when there
 * is no such zero or a bound is not a finite real number.
 */
function integrateAtSymbolicExponentZeros(
  ce: ComputeEngine,
  integrand: Expression,
  variable: string,
  lower: Expression,
  upper: Expression,
  numericApproximation: boolean
): Expression | 'inert' | undefined {
  const zeros = symbolicExponentBaseZeros(
    integrand,
    variable,
    lower,
    upper,
    ce
  );
  // A zero that cannot be given exactly (a base of degree 3 or more): the
  // whole-interval closed form would be wrong, and a float cut would lose
  // the condition, so the integral stays unevaluated.
  if (zeros === null) return 'inert';
  if (zeros === undefined || zeros.length === 0) return undefined;
  // The cuts in the direction of integration, which keeps
  // `∫_a^b = Σ ∫_{p_i}^{p_{i+1}}` valid for reversed bounds too.
  const reversed = decidedSign(ce.function('Subtract', [upper, lower])) === -1;
  const points = [lower, ...(reversed ? [...zeros].reverse() : zeros), upper];
  const pieces: Expression[] = [];
  for (let i = 0; i + 1 < points.length; i++) {
    const piece = ce
      .function('Integrate', [
        integrand,
        ce.function('Limits', [ce.symbol(variable), points[i], points[i + 1]]),
      ])
      .evaluate({ numericApproximation });
    if (piece.has('Integrate')) return 'inert';
    pieces.push(piece);
  }
  return ce.function('Add', pieces).evaluate({ numericApproximation });
}

/** The binders, other than `Integrate`, that `evaluateInnerIntegrals`
 * replaces by their value in an integrand. */
const INTEGRAND_BINDERS_EVALUATED_FIRST = new Set(['Sum', 'Product', 'D']);

/** `expr` with each inner `Integrate` subexpression replaced by its value,
 * when that value has no `Integrate` left. Otherwise the inner integral is
 * kept as it is. An inner integral binds its own variable, so its value can
 * be computed before the outer integral: `∫_0^1 x·(∫_{−1}^{1} x² dx) dx` is
 * `∫_0^1 (2/3)·x dx`. A `Sum`, `Product` or `D` is replaced by its value in
 * the same way (`INTEGRAND_BINDERS_EVALUATED_FIRST`). `variables` are the
 * names of the integration variables of this integral and of the enclosing
 * integrals. The operands of other binders (a function literal) and of a
 * quote operator (`Hold`) are not searched. */
function evaluateInnerIntegrals(
  expr: Expression,
  variables: ReadonlyArray<string>
): Expression {
  if (!isFunction(expr)) return expr;
  // The content of a quote operator is not evaluated: `Hold(Σ_{k=1}^3 k)`
  // stays held, and an effect in it does not run.
  if (expr.operatorDefinition?.holdClass === 'quote') return expr;
  if (expr.operator === 'Integrate') {
    const value = expr.evaluate();
    return value.has('Integrate') ? expr : value;
  }
  // A held `Sum`, `Product` or `D` is evaluated as a whole, as an inner
  // integral is: `∫_0^1 2·D(x^3, x) dx` is `∫_0^1 6x^2 dx`, and
  // `∫_0^1 Σ_{k=1}^3 k·x dx` is `∫_0^1 6x dx`. The evaluation keeps the
  // binders: the index of a `Sum` stays bound inside the `Sum`, and the
  // variable of `D` is the symbol of the integrand, so the value
  // (`3x^2`) is a function of the integration variable. When the value
  // still has the operator (no closed form), the operator is kept. The
  // operator is kept too when the value holds a restriction `If(c, e)`: an
  // infinite series `Σ_{n=0}^∞ n·x^n` evaluates to
  // `If(|x| < 1, x/(1 − x)^2)`, which no antiderivative rule reads, where the
  // series rules integrate the held `Sum` term by term.
  if (INTEGRAND_BINDERS_EVALUATED_FIRST.has(expr.operator)) {
    // A `Sum` or `Product` with a bound that reads an integration variable
    // is kept (the index of a `Limits` or `Element` clause is not a bound).
    // The evaluation of such a sum floors a numeric bound, so the
    // integrand is a step function of the variable, but its closed form
    // reads the bound as an integer and is a smooth function:
    // `∫_0^3 Σ_{k=1}^{x} (1/k − 1/(k+1)) dx` is 0 + 1/2 + 2/3 = 7/6, and the
    // integral of the closed form `1 − 1/(x+1)` is 3 − ln 4.
    // Only a free occurrence counts: in the bound `Σ_{x=1}^{2} 1`, the `x`
    // is bound by the nested sum. `D(x, x)` has `x` free (it is the
    // derivative at `x`), but its value is the constant 1: a pure bound
    // that names a variable is evaluated, and its value is read and used in
    // place of the bound. A bound with an effect is not evaluated here, and
    // the operator is kept.
    let held: Expression = expr;
    if (expr.operator !== 'D') {
      const reads = (e: Expression) =>
        e.freeVariables.some((name) => variables.includes(name));
      let changed = false;
      let keep = false;
      const clauses = expr.ops.slice(1).map((l) => {
        const isClause = isFunction(l, 'Limits') || isFunction(l, 'Element');
        const bounds = isClause ? l.ops.slice(1) : [l];
        const values = bounds.map((b) => {
          if (keep || !reads(b)) return b;
          if (!b.isPure) {
            keep = true;
            return b;
          }
          const v = b.evaluate();
          if (reads(v)) keep = true;
          else changed = true;
          return v;
        });
        if (!isClause || values.every((v, i) => v === bounds[i])) return l;
        return expr.engine.function(l.operator, [l.op1, ...values]);
      });
      if (keep) return expr;
      if (changed)
        held = expr.engine.function(expr.operator, [expr.op1, ...clauses]);
    }
    const value = held.evaluate();
    return value.has(expr.operator) ||
      value.getSubexpressions('If').some((x) => isRestriction(x))
      ? expr
      : value;
  }
  let changed = false;
  const ops = expr.ops.map((op, i) => {
    if (boundVariableNamesInOperand(expr, i).length > 0) return op;
    const value = evaluateInnerIntegrals(op, variables);
    if (value !== op) changed = true;
    return value;
  });
  return changed ? expr.engine.function(expr.operator, ops) : expr;
}

/** `expr` with each subexpression that `evaluateInnerIntegrals` replaces by
 * its value (an inner `Integrate`, `Sum`, `Product` or `D`) replaced by 0.
 * The walk stops where `evaluateInnerIntegrals` stops: at a quote operator
 * and at an operand where a binder binds a variable. The result is in raw
 * form, so a product with the 0 is not folded and keeps its other factors:
 * the free symbols of the result are the free symbols of `expr` that are
 * outside those subexpressions. */
function withoutEvaluatedFirst(expr: Expression): Expression {
  if (!isFunction(expr)) return expr;
  if (expr.operatorDefinition?.holdClass === 'quote') return expr;
  if (
    expr.operator === 'Integrate' ||
    INTEGRAND_BINDERS_EVALUATED_FIRST.has(expr.operator)
  )
    return expr.engine.Zero;
  let changed = false;
  const ops = expr.ops.map((op, i) => {
    if (boundVariableNamesInOperand(expr, i).length > 0) return op;
    const value = withoutEvaluatedFirst(op);
    if (value !== op) changed = true;
    return value;
  });
  return changed
    ? expr.engine.function(expr.operator, ops, { form: 'raw' })
    : expr;
}

/** Whether `expr` has a `Sign(u)` subexpression whose argument depends on
 * `variable`. Such a term of an antiderivative jumps where `u` changes sign,
 * so the antiderivative may not be continuous between the bounds. */
function hasVariableSign(expr: Expression, variable: string): boolean {
  if (!isFunction(expr)) return false;
  if (expr.operator === 'Sign' && expr.has(variable)) return true;
  return expr.ops.some((op) => hasVariableSign(op, variable));
}

/** A numeric integrand split into its real and imaginary parts.
 *
 * The compiled runner and the interpreted `applicable` both answer a complex
 * value as an object with numeric `re`/`im` fields (a real value as a plain
 * number, or an object with `im` = 0). The quadrature kernels integrate REAL
 * functions, so the caller integrates `re` first and, when `sawImaginary()`
 * reports that some sample carried a non-zero imaginary part, integrates
 * `im` as well and combines the two into one complex result. Reading only
 * `.re` — the previous behavior — silently dropped the imaginary part:
 * `∫₀^π e^{ix} dx` numericized to `0` instead of `2i`. */
type IntegrandParts = {
  re: (...args: number[]) => number;
  im: (...args: number[]) => number;
  sawImaginary: () => boolean;
  /** True once any sample produced a number at all. An integrand that never
   * does — one holding a free symbol the caller could not detect, such as an
   * operator name (`D`) used as a variable — has no numeric value, and the
   * integral must stay symbolic rather than answer `NaN`. */
  sawNumeric: () => boolean;
  /** True when no sample produced a number, and every sample was a value
   * with no number: the number `NaN` (compiled code, or a `NaN` literal), the
   * absent marker (`Missing`, a compiled `undefined`), or
   * arithmetic built around it (`0.5·Missing`, which is `Missing`). The
   * integrand then HAS a value at every sample, the undefined one, and so
   * does the integral: `NaN` (user decision 2026-10-23), as `NIntegrate` and
   * the compiled routes give for `∫₀¹ Which(t > 5, 1) dt`. A sample that is a
   * symbolic expression (`0.5·D`) is not such a value: it means the integrand
   * still holds a free symbol, and the integral stays symbolic. */
  sawOnlyUndefinedValues: () => boolean;
  /** The same part (`re` or `im`) without the sample cache. Monte Carlo must
   * use it: its points are random and do not repeat, so each lookup misses,
   * and with 10⁷ samples the string keys and lookups cost much more than a
   * cheap compiled integrand. */
  uncached: (
    part: (...args: number[]) => number
  ) => (...args: number[]) => number;
  /** The same part (`re` or `im`) for a caller that computes a value a second
   * time at a point, only to measure how the value changes with the result of
   * an inner integral (`replayIntegrand` of `adaptiveQuadrature`). The value
   * is computed without the sample cache, so the inner integrals are called
   * again, and it does not change what `sawImaginary`, `sawNumeric` and
   * `sawOnlyUndefinedValues` report: it is not a sample of the integrand.
   * An effect of the integrand (`Random()`, an assignment) runs again, so
   * the caller uses it only for an integrand that is transitively pure. */
  replayed: (
    part: (...args: number[]) => number
  ) => (...args: number[]) => number;
};

/** The panel budget of the adaptive Gauss–Kronrod quadrature of a ONE-limit
 * integral whose integrand did not compile. One interpreted evaluation costs
 * microseconds, not nanoseconds, so the default budget (1500 panels, up to
 * about 45 000 evaluations) is too large. The 16 starting panels cost 240
 * evaluations, the 15 common endpoints of the starting panels 15 more (see
 * `hiddenEdgeError`, `numerics/gauss-kronrod.ts`), and each bisection costs
 * 30 more, so 330 panels cost at most 240 + 15 + 314 × 30 = 9 675
 * evaluations: no more than the 1e4 samples of the
 * Monte-Carlo fallback for an interpreted integrand. A smooth integrand
 * converges far inside this budget. When the quadrature neither converges nor
 * beats Monte Carlo, the 1e4 samples are drawn AFTER it, so the worst case is
 * about 2 × 1e4 evaluations for each part (real, imaginary) of the
 * integrand, against 1e4 when the quadrature was skipped. The budget still leaves room for the
 * endpoint-divergence test, which needs two blocks of 20 bisections toward
 * one endpoint. Next to a singular endpoint, the tanh-sinh rule of
 * `resolveSingularEndpoints` (`numerics/endpoint-quadrature.ts`) can add up to
 * 2 × 330 = 660 evaluations. */
const INTERPRETED_QUADRATURE_PANELS = 330;

function numericIntegrandParts(
  raw: (...args: number[]) => unknown
): IntegrandParts {
  let imaginary = false;
  let numeric = false;
  let undefinedValue = false;
  let symbolic = false;
  const parts = (v: unknown): [re: number, im: number] => {
    if (typeof v === 'number') {
      if (!Number.isNaN(v)) numeric = true;
      else undefinedValue = true;
      return [v, 0];
    }
    if (v === undefined || v === null) {
      undefinedValue = true;
      return [NaN, NaN];
    }
    if (typeof v === 'object') {
      const re = (v as { re?: unknown }).re;
      const im = (v as { im?: unknown }).im;
      if (typeof re !== 'number') {
        symbolic = true;
        return [NaN, NaN];
      }
      const imN = typeof im === 'number' ? im : 0;
      if (!Number.isNaN(re)) numeric = true;
      // `Nothing` (an integrand that is a `Nothing` branch at this point)
      // has no value, as `Missing` has none: it is not a symbolic sample.
      else if (
        isExpression(v) &&
        !(isNumber(v) && v.isNaN === true) &&
        !isAbsentArithmeticOperand(v) &&
        sym(v) !== 'Nothing'
      )
        symbolic = true;
      else undefinedValue = true;
      // Any non-zero imaginary component — a non-finite one included, so
      // that `re: 1, im: Infinity` is not mistaken for a real sample and the
      // non-finite part reaches the estimate — makes the integrand complex.
      if (imN !== 0) imaginary = true;
      return [re, imN];
    }
    return [NaN, NaN];
  };
  // One evaluation of `raw` yields BOTH parts, but the real part is integrated
  // first and the imaginary part in a second pass over (mostly) the same
  // sample points. Keep the computed pairs so the second pass does not
  // re-evaluate an expensive integrand (a nested integral, a special
  // function) at a point the first pass already visited. A Monte-Carlo pass
  // of a single integral reads the integrand through `uncached` instead. The
  // cache is bounded: an iterated integral can evaluate the integrand at very
  // many points, which must not all be retained — past the cap, points are
  // evaluated without caching.
  const MAX_CACHED_SAMPLES = 1 << 16;
  const cache = new Map<string, [re: number, im: number]>();
  const at = (args: number[]): [re: number, im: number] => {
    const key = args.length === 1 ? String(args[0]) : args.join(',');
    const hit = cache.get(key);
    if (hit !== undefined) return hit;
    const pair = parts(raw(...args));
    if (cache.size < MAX_CACHED_SAMPLES) cache.set(key, pair);
    return pair;
  };
  // The real part is read in the first pass, which does not revisit a point,
  // so once the cache is full a lookup there can only miss: skip the key and
  // the lookup. The imaginary pass still looks up, because the first
  // `MAX_CACHED_SAMPLES` points of the first pass are in the cache.
  const re = (...args: number[]) =>
    cache.size >= MAX_CACHED_SAMPLES ? parts(raw(...args))[0] : at(args)[0];
  const im = (...args: number[]) => at(args)[1];
  const reUncached = (...args: number[]) => parts(raw(...args))[0];
  const imUncached = (...args: number[]) => parts(raw(...args))[1];
  const replayedPart =
    (index: 0 | 1) =>
    (...args: number[]) => {
      const flags = [imaginary, numeric, undefinedValue, symbolic];
      try {
        return parts(raw(...args))[index];
      } finally {
        [imaginary, numeric, undefinedValue, symbolic] = flags;
      }
    };
  const reReplayed = replayedPart(0);
  const imReplayed = replayedPart(1);
  return {
    re,
    im,
    sawImaginary: () => imaginary,
    sawNumeric: () => numeric,
    sawOnlyUndefinedValues: () => undefinedValue && !numeric && !symbolic,
    uncached: (part) =>
      part === re ? reUncached : part === im ? imUncached : part,
    replayed: (part) =>
      part === re ? reReplayed : part === im ? imReplayed : part,
  };
}

/** Assemble the numeric result of an integral from its real part and, when
 * present, its imaginary part. A NaN estimate (a divergent level, a NaN
 * bound) has no value to report an uncertainty ABOUT — `Measurement(NaN,
 * NaN)` would dress that up as a measured quantity — so it answers `NaN`.
 * The two error bars combine in quadrature. */
function measurementFromParts(
  ce: ComputeEngine,
  re: { estimate: number; error: number },
  im?: { estimate: number; error: number }
): Expression {
  if (Number.isNaN(re.estimate)) return ce.NaN;
  // A divergent real integral (an integrand that overflows at every node next
  // to the singular bound) has an infinite estimate and an error that is NaN:
  // answer the infinity itself, not `Measurement(∞, NaN)` (CE-185.4).
  if (im === undefined && !Number.isFinite(re.estimate))
    return ce.number(re.estimate);
  if (im === undefined)
    // A numeric estimate is a float, even when its value is an integer
    return ce.expr([
      'Measurement',
      ce.number(ce._inexactNumericValue(re.estimate + 0)),
      ce.number(re.error),
    ]);
  if (Number.isNaN(im.estimate)) return ce.NaN;
  return ce.expr([
    'Measurement',
    // A numeric estimate is a float, even when both its parts are integers
    ce.number(ce._inexactNumericValue({ re: re.estimate, im: im.estimate })),
    ce.number(Math.hypot(re.error, im.error)),
  ]);
}

/**
 * The sign of a definite integral over a half-infinite interval whose
 * antiderivative difference is not finite (`∫₀^∞ −dt/t³`, where
 * `1/(2t²)` at `0` is `~∞`), or `undefined` when it cannot be decided.
 *
 * The integrand diverges at the finite bound (`halfLineEndpointPoleSign`,
 * `symbolic/interior-pole.ts`). Poles strictly inside the interval are
 * decided before (`interiorPoleVerdict`). The antiderivative at the infinite
 * bound tells what the tail adds: a finite value adds nothing infinite, so
 * the integral has the sign of the pole (`∫₀^∞ (t − 1)/t³ dt` is `−∞`); an
 * infinite value of the same sign agrees with it; an infinite value of the
 * other sign gives an integral with no value (`∫₀^∞ (t − 1)/t² dt`: `−∞`
 * next to `0`, `+∞` on the tail), the verdict `mixed`. A value that is not
 * a number (`t − ln|t|` at `∞`) leaves the integral undecided.
 *
 * The sign of each part is its contribution to `F(upper) − F(lower)`: the
 * pole contributes the sign of the integrand next to it when the integral
 * runs away from the finite bound toward `+∞` or toward the finite bound
 * from `−∞`, and the opposite sign otherwise; the tail contributes `F(upper)`
 * or `−F(lower)`.
 */
function halfLinePoleVerdict(
  ce: ComputeEngine,
  integrand: Expression,
  antiderivative: Expression,
  variable: string,
  lower: Expression,
  upper: Expression
): { sign: 'positive' | 'negative' | 'mixed' } | undefined {
  const realInfinity = (b: Expression) =>
    b.isInfinity === true && (b.sgn === 'positive' || b.sgn === 'negative');
  const lowerInfinite = realInfinity(lower);
  const upperInfinite = realInfinity(upper);
  if (lowerInfinite === upperInfinite) return undefined;
  const finite = lowerInfinite ? upper : lower;
  const infinite = lowerInfinite ? lower : upper;
  if (finite.isFinite !== true) return undefined;
  // The direction from the finite bound into the interval.
  const side: 1 | -1 = infinite.sgn === 'positive' ? 1 : -1;
  const sign = halfLineEndpointPoleSign(integrand, variable, finite, side, ce);
  if (sign === undefined) return undefined;
  const flip = (s: 'positive' | 'negative') =>
    s === 'positive' ? 'negative' : 'positive';
  // `side` is `1` for `∫ₐ^∞` and `∫_∞^a`, `-1` for `∫ₐ^{−∞}` and `∫_{−∞}^a`.
  const pole = (lowerInfinite ? -side : side) === 1 ? sign : flip(sign);
  const atInfinity = antiderivative.subs({ [variable]: infinite }).evaluate();
  if (atInfinity.isFinite === true) return { sign: pole };
  if (atInfinity.isInfinity !== true) return undefined;
  const s = atInfinity.sgn;
  if (s !== 'positive' && s !== 'negative') return undefined;
  const tail = upperInfinite ? s : flip(s);
  return tail === pole ? { sign: pole } : { sign: 'mixed' };
}

/** The integrals for which `exactDivergenceValue` is running the exact
 * route, by engine: a key made of the hashes of the integrand and of the two
 * bounds. The exact route cannot ask it again for the same integral (through
 * a `.N()` of the integral inside the symbolic route), and another integral,
 * evaluated meanwhile by an integration provider, is not blocked. */
const exactDivergenceChecks = new WeakMap<object, Set<string>>();

/**
 * The value that the exact route gives to a definite integral that the
 * numeric route found divergent, or whose quadrature overflowed, with no
 * sign: `+∞` or `−∞`, or `NaN` for an integral with no value.
 * `undefined` when the exact route gives
 * anything else (an unevaluated integral, a finite value): the numeric
 * answer then stands.
 *
 * Compiled code already takes the closed form of such an integral, so `.N()`
 * and `NIntegrate` agree with it: `∫₀^∞ (x − 1) dx` is `+∞` everywhere, where
 * the numeric route alone cannot tell whether the negative part next to `0`
 * cancels the divergence of the tail.
 *
 * `fn` is the integrand as a function literal of one parameter, and `lower`
 * and `upper` are the values of the bounds. The exact route runs only on
 * these divergent or overflowing integrals, and costs one symbolic
 * integration.
 */
function exactDivergenceValue(
  ce: ComputeEngine,
  fn: Expression,
  lower: Expression,
  upper: Expression
): Expression | undefined {
  if (!isFunction(fn, 'Function') || fn.nops !== 2) return undefined;
  const parameter = fn.ops[1];
  if (!isSymbol(parameter)) return undefined;
  let active = exactDivergenceChecks.get(ce);
  if (active === undefined) {
    active = new Set();
    exactDivergenceChecks.set(ce, active);
  }
  const key = `${fn.hash} ${lower.hash} ${upper.hash}`;
  if (active.has(key)) return undefined;
  active.add(key);
  let value: Expression;
  try {
    value = ce
      .function('Integrate', [
        fn,
        ce.function('Limits', [parameter, lower, upper]),
      ])
      .evaluate();
  } finally {
    active.delete(key);
  }
  if (
    value.isInfinity === true &&
    (value.sgn === 'positive' || value.sgn === 'negative')
  )
    return value.sgn === 'positive' ? ce.PositiveInfinity : ce.NegativeInfinity;
  if (value.isNaN === true) return ce.NaN;
  return undefined;
}

/**
 * The compiled integrand `run` of the pure function literal `fn`, with each
 * sample where it is `NaN` computed again by `fn` compiled in
 * `mode: 'complex'`. The integrand compiles in the default `'strict'` mode,
 * where an operation whose value is complex gives `NaN`, while the value of
 * the integrand is complex there: `∫_{-0.2}^{∞} y^{-1/2} e^{-y/2} dy` has an
 * imaginary part, from the samples at `y < 0`. The complex form is compiled
 * at the first `NaN` sample, so an integrand with none keeps the real
 * kernel only; when it does not compile, the `NaN` stands. The `NaN` also
 * stands when the complex value has a `NaN` part (`x¹⁰⁰·e⁻ˣ` is `∞·0` on
 * both lanes past `x ≈ 1200`): the log-space fallback of
 * `withLogSpaceFallback()` then computes that sample, and it reads only a
 * number.
 */
function withComplexAtNaN<A extends number[]>(
  ce: ComputeEngine,
  fn: Expression,
  run: (...args: A) => unknown
): (...args: A) => unknown {
  let complexRun: ((...args: A) => unknown) | null | undefined;
  return (...args: A) => {
    const v = run(...args);
    if (typeof v !== 'number' || !Number.isNaN(v)) return v;
    if (complexRun === undefined) {
      const compiled = implicitCompile(ce, fn, 'integrand-complex', {
        mode: 'complex',
      });
      complexRun = compiled?.success
        ? (compiled.run as (...args: A) => unknown)
        : null;
    }
    if (complexRun === null) return v;
    const w = complexRun(...args);
    if (typeof w === 'number') return w;
    const z = w as { re?: unknown; im?: unknown } | null | undefined;
    if (
      typeof z?.re === 'number' &&
      typeof z.im === 'number' &&
      !Number.isNaN(z.re) &&
      !Number.isNaN(z.im)
    )
      return w;
    return v;
  };
}

/**
 * The compiled integrand `run` of the function literal `fn`, with each sample
 * where it is `NaN` or an infinity computed again in log space
 * (`logSpaceProduct`, `symbolic/log-space-product.ts`), when `fn` is a
 * product that has such a form. `x¹⁰⁰·e⁻ˣ` is `∞·0 = NaN` past `x ≈ 1200`,
 * where `exp(100·ln x − x)` is a number, and the quadrature of the `NaN`
 * tail did not converge: `∫₀^∞ x¹⁰⁰·e⁻ˣ dx` gave a Monte-Carlo value about
 * `10¹¹²` (`100! ≈ 9.3·10¹⁵⁷`). A finite sample is not changed. The log-space
 * value replaces a sample that is not finite when it is finite, or when the
 * sample is `NaN` and it is an infinity. `run` itself is returned when there
 * is no such form, or when the integrand is not transitively pure (it is
 * evaluated again at such a sample). The form is compiled at the first
 * sample that is not finite; when it does not compile, `run`'s value
 * stands. The compiled
 * `_SYS.integrate` does the same (`_SYS.finiteOr`, `compileIntegrate` in
 * `compilation/javascript-target.ts`).
 */
function withLogSpaceFallback<A extends number[]>(
  ce: ComputeEngine,
  fn: Expression,
  run: (...args: A) => unknown
): (...args: A) => unknown {
  if (!isFunction(fn, 'Function')) return run;
  // The integrand is evaluated a second time at such a sample: an effect
  // (`Random()`) would run again, and the log-space form reads a factor
  // twice (for its sign and its magnitude).
  if (!isTransitivelyPure(fn)) return run;
  run = withComplexAtNaN(ce, fn, run);
  const parameters = fn.ops.slice(1);
  const names = parameters.map((p) => sym(p));
  if (names.some((n) => n === undefined)) return run;
  const body = logSpaceProduct(fn.op1, names as string[]);
  if (body === undefined) return run;
  // Compiled at the first sample that is not finite: most integrands have
  // none.
  let alternative: ((...args: A) => unknown) | null | undefined;
  return (...args: A) => {
    const v = run(...args);
    if (typeof v !== 'number' || Number.isFinite(v)) return v;
    if (alternative === undefined) {
      const compiled = implicitCompile(
        ce,
        ce.function('Function', [body, ...parameters]),
        'integrand-log'
      );
      alternative = compiled?.success
        ? (compiled.run as (...args: A) => unknown)
        : null;
    }
    if (alternative === null) return v;
    const w = alternative(...args);
    if (typeof w !== 'number') return v;
    return Number.isFinite(w) || (Number.isNaN(v) && !Number.isNaN(w)) ? w : v;
  };
}

/** The value of a definite integral with a proven pole strictly inside its
 * bounds: `+∞`/`−∞` when the integrand keeps one sign across every pole,
 * `NaN` when it changes sign (no value, not even an infinite one). */
function poleVerdictValue(
  ce: ComputeEngine,
  pole: { sign: string }
): Expression {
  return pole.sign === 'positive'
    ? ce.PositiveInfinity
    : pole.sign === 'negative'
      ? ce.NegativeInfinity
      : ce.NaN;
}

/**
 * The condition under which the closed form that the power rule gives for
 * `∫ c·(a·x + b)^e dx`, `c·(a·x + b)^(e + 1) / (a·(e + 1))`, is the
 * antiderivative: the symbolic exponent `e` is not `−1`. At `e = −1` the
 * antiderivative is `c·ln|a·x + b| / a` instead, and the closed form has no
 * value: `∫₁² t^(−n) dt` is `(2^(1 − n) − 1)/(1 − n)` for `n ≠ 1` and `ln 2`
 * at `n = 1`. A definite integral evaluated by the power rule carries the
 * condition as a guard, `(2^(1 − n) − 1)/(1 − n) {n ≠ 1}`, which is
 * discharged when the exponent is known not to be `−1` (`n` declared greater
 * than 2; see `conditionalValue`). The power may be written as a quotient
 * (`a / t^n`), and each term of a sum contributes its own guard. `undefined`
 * when the integrand has no term that is a constant times a power of a
 * linear base with a symbolic exponent (a number literal, an exponent that
 * depends on the variable, or a constant such as `π` give no guard), or
 * when a term has several factors that depend on the variable.
 */
function powerRuleParameterGuard(
  ce: ComputeEngine,
  integrand: Expression,
  variable: string
): Expression | undefined {
  let e = integrand;
  while (isFunction(e, 'Block') && e.nops === 1) e = e.op1;
  // Each term of a sum is integrated by its own rule: the guards of the
  // terms are conjoined (`∫₁² (t^(−n) + t^(−m)) dt` needs `n ≠ 1` and
  // `m ≠ 1`).
  if (isFunction(e, 'Add')) {
    const guards: Expression[] = [];
    for (const term of e.ops) {
      const g = powerRuleParameterGuard(ce, term, variable);
      if (g !== undefined && !guards.some((h) => h.isSame(g))) guards.push(g);
    }
    if (guards.length === 0) return undefined;
    return guards.length === 1 ? guards[0] : ce.function('And', guards);
  }
  // `c / (a·x + b)^e` is the power with the exponent `−e`.
  if (isFunction(e, 'Divide') && !e.op1.has(variable)) {
    const d = e.op2;
    if (!isFunction(d, 'Power')) return undefined;
    return powerRuleParameterGuard(
      ce,
      ce.function('Power', [d.op1, ce.function('Negate', [d.op2])]),
      variable
    );
  }
  let power: Expression = e;
  if (isFunction(e, 'Multiply')) {
    const dependent = e.ops.filter((op) => op.has(variable));
    if (dependent.length !== 1) return undefined;
    power = dependent[0];
  }
  if (!isFunction(power, 'Power')) return undefined;
  const [base, exponent] = [power.op1, power.op2];
  if (
    isNumber(exponent) ||
    exponent.has(variable) ||
    exponent.unknowns.length === 0
  )
    return undefined;
  if (polynomialDegree(base, variable) !== 1) return undefined;
  // An exponent linear in its one unknown gives the guard on that unknown:
  // `n ≠ 1` for the exponent `−n`, not `−n ≠ −1`.
  const unknowns = exponent.unknowns;
  if (unknowns.length === 1) {
    const coeffs = getPolynomialCoefficients(exponent, unknowns[0]);
    if (coeffs !== null && coeffs.length === 2) {
      const [c0, c1] = coeffs;
      if (isNumber(c1) && c1.isNumberLiteral && !c1.isSame(0)) {
        const at = ce
          .function('Divide', [
            ce.function('Subtract', [ce.number(-1), c0]),
            c1,
          ])
          .evaluate();
        return ce.function('NotEqual', [ce.symbol(unknowns[0]), at]);
      }
    }
  }
  return ce.function('NotEqual', [exponent, ce.number(-1)]);
}

/**
 * Whether the numeric value of `e` has an imaginary part that is not a
 * rounding error: larger than 10⁻⁹ times the magnitude of the real part, or
 * than 10⁻⁹ when the real part is smaller than 1. An expression with no
 * numeric value gives `false`.
 *
 * The type `real` holds finite real numbers only, so an expression of that
 * type has no imaginary part. Its type is read first because it costs less
 * than its numeric approximation.
 */
function hasImaginaryPart(e: Expression): boolean {
  if (!isNumber(e) && isSubtype(e.type.type, 'real')) return false;
  const n = isNumber(e) ? e : e.N();
  if (!isNumber(n)) return false;
  const { re, im } = n;
  return (
    Number.isFinite(im) &&
    Math.abs(im) > 1e-9 * Math.max(1, Number.isFinite(re) ? Math.abs(re) : 1)
  );
}

/**
 * Whether `e` is a sum with a term that is not real while the sum itself is
 * real: `iπ/2 + artanh(2)`, where the imaginary parts cancel.
 */
function hasNonRealTerms(e: Expression): boolean {
  return (
    isFunction(e, 'Add') &&
    isNumber(e.N()) &&
    !hasImaginaryPart(e) &&
    e.ops.some(hasImaginaryPart)
  );
}

/** Whether the numeric values of `a` and `b` agree to 10⁻⁹, relative. */
function sameNumericValue(a: Expression, b: Expression): boolean {
  const x = a.N();
  const y = b.N();
  if (!isNumber(x) || !isNumber(y)) return false;
  const d = Math.hypot(x.re - y.re, x.im - y.im);
  return Number.isFinite(d) && d <= 1e-9 * Math.max(1, Math.hypot(y.re, y.im));
}

/**
 * Whether `integrand` is proven real on the closed interval between the exact
 * bounds `lower` and `upper`. `continuousRange` encloses its values with exact
 * interval arithmetic, and declines each operation that could leave the
 * reals: `√u` or `ln u` where `u` can be negative, a denominator that can be
 * 0. Without a proof (float or infinite bounds, an operator that
 * `continuousRange` does not know), the answer is `false`. A sampling of the
 * integrand is not a proof: `√x` is real at three sample points of `[−1, 3]`,
 * and `∫₋₁³ √x dx = 2√3 + (2/3)i` is a correct complex value.
 */
function provenRealOnInterval(
  integrand: Expression,
  variable: string,
  lower: Expression,
  upper: Expression
): boolean {
  if (!finiteConstant(lower) || !finiteConstant(upper)) return false;
  const order = exactSign(
    integrand.engine.function('Subtract', [upper, lower])
  );
  if (order === undefined) return false;
  const [lo, hi] = order < 0 ? [upper, lower] : [lower, upper];
  return continuousRange(integrand, variable, lo, hi) !== undefined;
}

/**
 * The integration variables and bounds of the `Limits` of `limits` that have
 * both bounds: the enclosing integrals of an inner integral of an iterated
 * integral, for `symbolicPoleMayBeInside`.
 */
function outerRanges(
  limits: ReadonlyArray<Expression>
): { name: string; lower: Expression; upper: Expression }[] {
  const ranges: { name: string; lower: Expression; upper: Expression }[] = [];
  for (const l of limits) {
    if (!isFunction(l, 'Limits')) continue;
    const name = sym(l.op1);
    if (!name || name === 'Nothing') continue;
    if (sym(l.op2) === 'Nothing' || sym(l.op3) === 'Nothing') continue;
    ranges.push({ name, lower: l.op2, upper: l.op3 });
  }
  return ranges;
}

/** An integration variable and its bounds. */
type IntegrationRange = { name: string; lower: Expression; upper: Expression };

/**
 * The ranges of the integrals whose evaluation is running and encloses the
 * one being evaluated. An iterated integral written as nested integrals
 * (`\int_5^{10}\int_3^4 (y-x)^{-2}\,dx\,dy` on the parse route) is an
 * `Integrate` whose integrand holds another `Integrate`. The outer integral
 * evaluates the inner one first (see `evaluateInnerIntegrals`), and the
 * inner one must know the range of `y` to prove that its pole `x = y` is
 * outside `[3, 4]` (see `symbolicPoleMayBeInside`). Set by
 * `withEnclosingRanges` for the duration of the inner evaluation.
 *
 * The ranges belong to the evaluation of one engine: they are kept per
 * engine, so that an integral evaluated by another engine while an integral
 * runs (a host callback, for example) does not read them.
 */
const enclosingRangesOf = new WeakMap<
  ComputeEngine,
  ReadonlyArray<IntegrationRange>
>();

/** The ranges of the integrals that enclose the one that `ce` evaluates
 * (see `enclosingRangesOf`). */
function enclosingRanges(ce: ComputeEngine): ReadonlyArray<IntegrationRange> {
  return enclosingRangesOf.get(ce) ?? [];
}

/** `fn()`, with the enclosing ranges of `ce` set to `ranges` while it runs. */
function withEnclosingRanges<T>(
  ce: ComputeEngine,
  ranges: ReadonlyArray<IntegrationRange>,
  fn: () => T
): T {
  const saved = enclosingRangesOf.get(ce);
  enclosingRangesOf.set(ce, ranges);
  try {
    return fn();
  } finally {
    if (saved === undefined) enclosingRangesOf.delete(ce);
    else enclosingRangesOf.set(ce, saved);
  }
}

/**
 * The value of `∫ body d(variable)` over a numeric interval with orientation
 * `orientation` (the sign of `upper − lower`) when `body` does not depend on
 * `variable` and its numeric value is an infinity: that infinity for `+1`,
 * its negation for `−1`. `undefined` in every other case — a body that
 * depends on the variable, a finite or non-numeric value, an impure body
 * (evaluating it here would run its effects once more than the quadrature
 * does), or a zero-length interval (decided by the caller).
 */
function infiniteConstantIntegral(
  ce: ComputeEngine,
  body: Expression,
  variable: string,
  orientation: number
): Expression | undefined {
  if (orientation !== 1 && orientation !== -1) return undefined;
  if (body.has(variable) || !body.isPure) return undefined;
  const value = body.N();
  if (!isNumber(value) || value.isInfinity !== true) return undefined;
  return orientation === 1 ? value : value.neg();
}

/**
 * `body` with each symbol that has an assigned value replaced by that value,
 * except the symbols named in `variables` (the integration variables).
 *
 * The interior-pole check (`interiorPoleVerdict`) only locates the poles of a
 * denominator whose single free symbol is the integration variable, so with
 * `q := 1` it could not see the pole of `(y − q)⁻²` at `y = 1`. The compiled
 * integrand reads the value of `q`, so the quadrature integrates the function
 * with the pole: the check must examine the same function. This is a numeric
 * evaluation, so reading the assigned values is correct here. A symbol with
 * no value, and a constant (`Pi`, `ExponentialE`), are left as they are.
 */
function withAssignedValues(
  ce: ComputeEngine,
  body: Expression,
  variables: readonly string[]
): Expression {
  const values: Record<string, Expression> = {};
  let found = false;
  for (const name of body.symbols) {
    if (variables.includes(name)) continue;
    const def = ce.lookupDefinition(name);
    if (!isValueDef(def) || def.value.isConstant === true) continue;
    const value = def.value.value;
    if (value === undefined || value === null) continue;
    values[name] = value;
    found = true;
  }
  return found ? body.subs(values) : body;
}

/**
 * `e` written as `factor · rest`, where `factor` does not depend on
 * `variable` and `rest` has no free symbol other than `variable`:
 * `1/(a·t)` is `(1/a) · (1/t)`. `undefined` when `e` cannot be written so
 * by splitting products, quotients, negations and integer powers
 * (`1/(t + a)` cannot).
 */
function splitConstantFactor(
  ce: ComputeEngine,
  e: Expression,
  variable: string
): { factor: Expression; rest: Expression } | undefined {
  if (!e.has(variable)) return { factor: e, rest: ce.One };
  if (e.unknowns.every((name) => name === variable))
    return { factor: ce.One, rest: e };
  if (!isFunction(e)) return undefined;
  if (e.operator === 'Multiply') {
    const factors: Expression[] = [];
    const rests: Expression[] = [];
    for (const op of e.ops) {
      const s = splitConstantFactor(ce, op, variable);
      if (s === undefined) return undefined;
      factors.push(s.factor);
      rests.push(s.rest);
    }
    return {
      factor: ce.function('Multiply', factors),
      rest: ce.function('Multiply', rests),
    };
  }
  if (e.operator === 'Divide') {
    const n = splitConstantFactor(ce, e.op1, variable);
    const d = splitConstantFactor(ce, e.op2, variable);
    if (n === undefined || d === undefined) return undefined;
    return {
      factor: ce.function('Divide', [n.factor, d.factor]),
      rest: ce.function('Divide', [n.rest, d.rest]),
    };
  }
  if (e.operator === 'Negate') {
    const s = splitConstantFactor(ce, e.op1, variable);
    if (s === undefined) return undefined;
    return { factor: ce.function('Negate', [s.factor]), rest: s.rest };
  }
  if (e.operator === 'Power') {
    // Only an integer exponent distributes over a product for every value
    // of the factors: `(a·t)^(1/2)` is not `a^(1/2)·t^(1/2)` for `a, t < 0`.
    const k = e.op2;
    if (!isNumber(k) || !k.isNumberLiteral || !Number.isInteger(k.re))
      return undefined;
    const s = splitConstantFactor(ce, e.op1, variable);
    if (s === undefined) return undefined;
    return {
      factor: ce.function('Power', [s.factor, k]),
      rest: ce.function('Power', [s.rest, k]),
    };
  }
  return undefined;
}

/**
 * Whether `factor` is not zero for any value of its free symbols at which it
 * is defined: a nonzero number, a quotient whose numerator is never zero, a
 * product of such factors, a negative power (`1/a` is never zero), or a
 * value whose sign is decided.
 */
function neverZero(factor: Expression): boolean {
  if (isNumber(factor)) return factor.isNaN !== true && !factor.isSame(0);
  if (isFunction(factor)) {
    if (factor.operator === 'Divide' || factor.operator === 'Negate')
      return neverZero(factor.op1);
    if (factor.operator === 'Multiply') return factor.ops.every(neverZero);
    // `eᶻ` is never zero for a finite `z`. An exponent that is not proven
    // infinite (a symbol with no value) counts as finite.
    if (factor.operator === 'Exp')
      return factor.op1.isFinite !== false && factor.op1.isNaN !== true;
    if (factor.operator === 'Power') {
      const k = factor.op2;
      if (isSymbol(factor.op1, 'ExponentialE'))
        return k.isFinite !== false && k.isNaN !== true;
      if (isNumber(k) && k.isNumberLiteral && k.re < 0) return true;
      if (isNumber(k) && k.isNumberLiteral && k.re > 0)
        return neverZero(factor.op1);
    }
  }
  const s = decidedSign(factor);
  return s === 1 || s === -1;
}

/**
 * The interior-pole verdict (see `interiorPoleVerdict`) of an integrand that
 * has a free symbol other than `variable` only in a constant factor:
 * `1/(a·t)` over `[−1, 1]`. `interiorPoleVerdict` locates the pole of such
 * an integrand at `t = 0`, but cannot confirm it, because its samples of the
 * integrand are not numbers while `a` is free. Here the integrand is split
 * into `factor · rest` (`(1/a) · (1/t)`) and the check runs on `rest`.
 *
 * - When `rest` changes sign across a pole (`mixed`), the integral has no
 *   value for every value of the free symbols at which `factor` is not zero.
 *   Where `factor` is undefined (`1/a` at `a = 0`), the integrand is
 *   undefined everywhere and the integral has no value either. So the
 *   verdict is `mixed` when `factor` is never zero (see `neverZero`), and
 *   `unknown` otherwise: `∫₋₁¹ a/t dt` is `0` for `a = 0`.
 * - When `rest` keeps one sign (`1/(a·t²)`), the sign of the integral is
 *   that sign times the sign of `factor`: the verdict is `positive` or
 *   `negative` when the sign of `factor` is decided (`a` declared positive),
 *   and `unknown` otherwise.
 *
 * An `unknown` verdict keeps the integral unevaluated. `undefined` when the
 * integrand cannot be split, has no free symbol other than `variable`, or
 * `rest` has no proven pole.
 */
function constantFactorPoleVerdict(
  ce: ComputeEngine,
  integrand: Expression,
  variable: string,
  lower: Expression,
  upper: Expression
): PoleVerdict | undefined {
  if (integrand.unknowns.every((name) => name === variable)) return undefined;
  const split = splitConstantFactor(ce, integrand, variable);
  if (split === undefined) return undefined;
  const verdict = interiorPoleVerdict(split.rest, variable, lower, upper, ce);
  if (verdict === undefined) return undefined;
  if (verdict.sign === 'mixed')
    return neverZero(split.factor) ? verdict : { sign: 'unknown' };
  if (verdict.sign === 'positive' || verdict.sign === 'negative') {
    const s = decidedSign(split.factor);
    if (s === 1) return verdict;
    if (s === -1)
      return { sign: verdict.sign === 'positive' ? 'negative' : 'positive' };
  }
  return { sign: 'unknown' };
}

/**
 * The integral over `[lower, upper]` of `integrand`, a lifted integrand that
 * does not depend on the variable of the limit: a limit that names no
 * variable, for an integrand with no parameter for it
 * (`implicitIntegrationVariable`). The value is `c·(upper − lower)`, where
 * `c` is the value of the integrand, with `evaluate()` or, when `numeric` is
 * true, `N()`. A function literal with no parameter whose body is a block of
 * several statements is not lifted (`liftIntegrand`): it is applied to no
 * arguments, so that its block runs as a call does.
 *
 * - Equal bounds (`isSame`, also `+∞` and `+∞`) give `0`, before the
 *   integrand is read: `∞ − ∞` and `∞·0` have no value.
 * - An integrand whose VALUE is exactly `0` gives `0`, also over an infinite
 *   interval. With `c := 0`, `\int_0^\infty c` is `0`, as compiled code
 *   gives. The test is exact: `10^{-12}` over `[0, ∞)` is `+∞`.
 * - A `NaN` product (a bound with the value `NaN`) gives `undefined`: the
 *   integral stays unevaluated, as with a named variable.
 * - A function literal that still has parameters gives `undefined`.
 */
function constantIntegral(
  ce: ComputeEngine,
  integrand: Expression,
  lower: Expression,
  upper: Expression,
  numeric: boolean
): Expression | undefined {
  if (lower.isSame(upper)) return ce.Zero;
  let body: Expression | undefined = integrand;
  if (isFunction(integrand, 'Function')) {
    if (integrand.nops > 1) return undefined;
    body = applicable(integrand)([]);
    if (body === undefined) return undefined;
  }
  const value = numeric ? body.N() : body.evaluate();
  if (isNumber(value) && value.isSame(0)) return ce.Zero;
  const result = ce
    .function('Multiply', [value, ce.function('Subtract', [upper, lower])])
    .evaluate({ numericApproximation: numeric });
  return result.isNaN === true ? undefined : result;
}

/**
 * The name of the variable of the integrand `f(t)` that `NIntegrate` builds
 * for a function given by its name (`NIntegrate(Tan, 0, 3)`). The name is
 * unlikely to occur in the body of a user function: the interior-pole check
 * finds the integration variable by its name, so a body symbol with the same
 * name would be taken for it.
 */
const NINTEGRATE_VARIABLE = 'NIntegrateVariable';

/**
 * The function literal `(p_1, …, p_n) ↦ body`, where the parameter named
 * `params[i]` replaces each occurrence of the symbol named `holes[i]` in
 * `body`, typed `types[i]` when `types` has that entry. Returns `undefined`
 * when a parameter cannot be made.
 *
 * The parameter symbols are declared in a scope that is discarded before the
 * literal is made. The literal then binds its parameters in the scope of its
 * own body (`bindParameterOperands`, `function-utils.ts`). A parameter made
 * with `ce.symbol()` is declared in the caller's scope instead, with the type
 * that the body infers for it, and that type then applies to every later use
 * of the same name in the caller's scope.
 */
function functionLiteralOverHoles(
  ce: ComputeEngine,
  body: Expression,
  holes: ReadonlyArray<string>,
  params: ReadonlyArray<string>,
  types?: ReadonlyArray<Expression | undefined>
): Expression | undefined {
  const symbols: Expression[] = [];
  let lifted: Expression;
  ce.pushScope();
  try {
    for (const name of params) {
      ce.declare(name, 'unknown');
      const param = ce._bindingSymbol(name, ce.context.lexicalScope);
      if (param === undefined) return undefined;
      symbols.push(param);
    }
    const subs: Record<string, Expression> = {};
    holes.forEach((hole, i) => {
      subs[hole] = symbols[i];
    });
    // A hole can be the operator of a call (`_2(_)` for the parameter `f` of
    // `(a, f) ↦ f(a)·h(a)`), and `subs()` replaces symbols only.
    lifted = substituteParameters(ce, body, subs);
  } finally {
    ce.popScope();
  }
  // `ce.function()` (not `_fn`): the canonical handler wraps the body in the
  // scoped Block that `makeLambda` requires.
  return ce.function('Function', [
    lifted,
    ...symbols.map((symbol, i) =>
      types?.[i] ? ce._fn('Typed', [symbol, types[i]]) : symbol
    ),
  ]);
}

/**
 * The names of the holes that stand for `count` parameters of a function
 * literal in `literalBodyOverHoles()`. The first one is `_`, the variable in
 * which `derivative()` differentiates the body that it receives.
 */
function parameterHoles(count: number): string[] {
  return Array.from({ length: Math.max(count, 1) }, (_, i) =>
    i === 0 ? '_' : `_${i + 1}`
  );
}

/**
 * The derivative `body`, which is in terms of `holes`, as a function literal
 * with the parameters `params`, the parameters of the function that was
 * differentiated. A parameter keeps its name and its type, unless `body` holds
 * its name: that name is a free name of a called function
 * (`literalBodyOverHoles()`), which the parameter would bind, so the parameter
 * gets a new name. With `a := 3` and `h := x ↦ a·x`, the derivative of
 * `a ↦ h(a)` is `a_1 ↦ a`.
 */
function literalWithParameters(
  ce: ComputeEngine,
  body: Expression,
  holes: ReadonlyArray<string>,
  params: ReadonlyArray<Expression>
): Expression | undefined {
  const binders = collectBinderNames(body);
  const names: string[] = [];
  for (const param of params) {
    const base = functionLiteralParameterName(param);
    let name = base;
    for (
      let i = 1;
      body.has(name) || binders.has(name) || names.includes(name);
      i++
    )
      name = `${base}_${i}`;
    names.push(name);
  }
  return functionLiteralOverHoles(
    ce,
    body,
    holes,
    names,
    params.map((p) => (isFunction(p, 'Typed') ? p.op2 : undefined))
  );
}

/**
 * The interior-pole verdict of `NIntegrate(f, lower, upper)` (see
 * `interiorPoleVerdict`), or `undefined` when no pole was proven. With
 * `check` set to `endpointPoleVerdict`, the verdict for a pole AT a bound.
 *
 * - For a one-parameter `Function` literal, the check examines its body. The
 *   parameter is shielded, so that a global value of a symbol with the same
 *   name is not read.
 * - For a function given by its name (`Tan`, or a user function `g`), the
 *   check examines the call `f(t)`, where `t` is a real variable declared in a
 *   scope of its own. The variable is made with `_bindingSymbol()`, never
 *   `ce.symbol()`, which can return a library constant. When the call itself
 *   gives no verdict, its evaluated form is examined: evaluating the call of
 *   a user function `g := x ↦ 1/x²` gives `t⁻²`, whose denominator the check
 *   can read.
 *   A function that is not pure is not probed (no verdict).
 *
 * In both cases the values of the other assigned symbols are substituted
 * first (see `withAssignedValues`).
 */
function nIntegratePoleVerdict(
  ce: ComputeEngine,
  f: Expression,
  lower: number,
  upper: number,
  check: typeof interiorPoleVerdict = interiorPoleVerdict
): PoleVerdict | undefined {
  if (isFunction(f, 'Function')) {
    if (f.nops !== 2) return undefined;
    const variable = sym(f.op2);
    if (!variable) return undefined;
    return withValueShield(ce, [variable], () =>
      check(
        withAssignedValues(ce, f.op1, [variable]),
        variable,
        lower,
        upper,
        ce
      )
    );
  }

  const name = sym(f);
  if (!name) return undefined;
  const variable = NINTEGRATE_VARIABLE;
  ce.pushScope();
  try {
    ce.declare(variable, 'real');
    const t = ce._bindingSymbol(variable, ce.context.lexicalScope);
    if (!t) return undefined;
    const call = ce.function(name, [t]);
    // The check samples the call, and its evaluation below runs the handler
    // with the symbolic argument `t`. For a function that is not pure (a
    // handler that reads a random value or has an effect), each such run is
    // an extra call that the quadrature does not make, and that can change
    // the values of the later samples. No pole is probed.
    if (call.isPure !== true) return undefined;
    const verdict = check(
      withAssignedValues(ce, call, [variable]),
      variable,
      lower,
      upper,
      ce
    );
    if (verdict !== undefined) return verdict;
    let evaluated: Expression;
    try {
      evaluated = call.evaluate();
    } catch {
      return undefined;
    }
    if (evaluated.isSame(call)) return undefined;
    return check(
      withAssignedValues(ce, evaluated, [variable]),
      variable,
      lower,
      upper,
      ce
    );
  } finally {
    ce.popScope();
  }
}

/**
 * The integrand `fn` as the two parts (real, imaginary) that the quadrature
 * integrates (`numericIntegrandParts`), and whether it compiled. An integrand
 * that does not compile is evaluated by the interpreter. `shield` runs the
 * compilation and the construction of the log-space fallback
 * (`withLogSpaceFallback`): the `Integrate` route hides there the values of
 * the symbols that have the name of an integration variable
 * (`withValueShield`).
 */
function integrandPartsOf(
  ce: ComputeEngine,
  fn: Expression,
  shield: <T>(run: () => T) => T
): { integrand: IntegrandParts; compiled: boolean } {
  const compiled = shield(() => implicitCompile(ce, fn, 'integrand'));
  const raw: (x: number) => unknown = compiled?.success
    ? shield(() =>
        withLogSpaceFallback(ce, fn, compiled.run as (x: number) => unknown)
      )
    : (
        (app) => (x: number) =>
          app([ce.number(x)])
      )(applicable(fn));
  return {
    integrand: numericIntegrandParts(raw),
    compiled: compiled?.success === true,
  };
}

/** One part (real or imaginary) of the integrand on the two halves of the
 * interval (see `endpointHalves`). */
type EndpointHalvesPart = {
  /** Half the length of the interval, `|U − L|/2`. */
  width: number;
  /** The sign of `U − L`. */
  sign: 1 | -1;
  /** `u ↦ f(L + sign·u)` and `u ↦ f(U − sign·u)`, for `u` in `[0, width]`. */
  lower: (u: number) => number;
  upper: (u: number) => number;
  /** Whether both halves compiled. */
  compiled: boolean;
};

/**
 * Rewrite the sums of `expr` so that the constant terms of a sum are added
 * together: a sum that is an operand of a sum, the negation of a sum and the
 * product of a number literal and a sum are expanded into the terms of the
 * sum that holds them. After the substitution `t = 1 − u`, the factor
 * `1 − t` of an integrand is `1 − (1 − u)`, which the canonical form keeps
 * (it does not distribute a `Negate` over a sum), and which is computed in
 * doubles as `1 − fl(1 − u)`: `0` for `u < 2⁻⁵⁴`. Rewritten, it is `u`.
 * Only sums are changed: the power `(1 − u)²` stays a power, so that no
 * polynomial is expanded. The caller passes an expression without a binder
 * (see `endpointHalves`), so that every operator can be built again with
 * its new operands.
 */
function distributeSums(ce: ComputeEngine, expr: Expression): Expression {
  if (!isFunction(expr)) return expr;
  const ops = expr.ops.map((x) => distributeSums(ce, x));
  const changed = ops.some((x, i) => x !== expr.ops[i]);
  const op = expr.operator;
  if (op === 'Negate' && ops.length === 1 && isFunction(ops[0], 'Add'))
    return ce.function(
      'Add',
      ops[0].ops.map((x) => x.neg())
    );
  if (op === 'Add') {
    let expanded = false;
    const terms = ops.flatMap((x): ReadonlyArray<Expression> => {
      if (isFunction(x, 'Add')) {
        expanded = true;
        return x.ops;
      }
      if (
        isFunction(x, 'Multiply') &&
        x.nops === 2 &&
        isNumber(x.op1) &&
        isFunction(x.op2, 'Add')
      ) {
        expanded = true;
        // `ce.function('Multiply', …)`, not `.mul()`, which can expand a
        // term that is itself a product of sums.
        const c = x.op1;
        return x.op2.ops.map((y) => ce.function('Multiply', [c, y]));
      }
      return [x];
    });
    if (expanded) return ce.function('Add', terms);
  }
  if (!changed) return expr;
  // A call keeps the binding of its callee: in a scope that declares
  // another `g`, the call `g(1 − t)` of the integrand still calls its own `g`
  // (`withCallableBinding`).
  return withCallableBinding(expr, () => ce.function(op, ops));
}

/** True when `expr` or one of its subexpressions binds a variable (a sum, an
 * integral, a function literal, a block). */
function holdsBinder(expr: Expression): boolean {
  if (!isFunction(expr)) return false;
  return boundVariableNames(expr).length > 0 || expr.ops.some(holdsBinder);
}

/**
 * The integrand on the two halves of a finite interval `[L, U]`, each
 * written in the distance `u` to its bound: `f(L + s·u)` and `f(U − s·u)`
 * for `u` in `[0, |U − L|/2]`, with `s` the sign of `U − L`, so that
 * `∫_L^U f = s·(∫_0^w f(L + s·u) du + ∫_0^w f(U − s·u) du)`.
 *
 * A bound that is not `0` is a double, and the doubles next to it are about
 * `2⁻⁵²·|bound|` apart, so the adaptive quadrature can bisect the panel at
 * that bound only about 50 times. For a slowly integrable singularity at the
 * bound, a large part of the integral is closer to the bound than that, and
 * the model of the part that is not sampled (`shellTail`,
 * `numerics/endpoint-quadrature.ts`) needs more shells: the result has an
 * error wider than its value (`∫_{1/2}^1 dt/((1 − t)(−ln(1 − t))^1.1)` gave
 * `3 ± 36`, for 10.3733). Next to `u = 0` the doubles go down to `2⁻¹⁰⁷⁴`.
 * A change of variable inside the quadrature does not help: the integrand
 * computes `1 − t` from a double `t`. The substitution is made in the
 * expression, before it is compiled, and the sums are rewritten
 * (`distributeSums`) so that `1 − t` is computed as `u`.
 *
 * The integrand is built and compiled only when `halves` is called, which
 * `integrateRealPart` does only for a singular corner that it could not
 * resolve. It is `undefined` when the interval is not finite, when `fn` is
 * not a function literal of one parameter, when it is not transitively pure
 * (an effect would run again for each new sample) or when its body binds a
 * variable (the substitution would have to follow the scopes), and when a
 * half does not compile while `fn` did (an interpreted half would be slower
 * than the integrand it replaces).
 *
 * The bounds `lowerBound` and `upperBound` are used as they are when they
 * are number literals, so that `1 − (1 − u)` is `u` exactly; otherwise the
 * double values `lower` and `upper` are used.
 */
function endpointHalves(
  ce: ComputeEngine,
  fn: Expression,
  bounds: {
    lowerBound: Expression;
    upperBound: Expression;
    lower: number;
    upper: number;
  },
  original: { compiled: boolean },
  shield: <T>(run: () => T) => T
): (part: 're' | 'im') => EndpointHalvesPart | undefined {
  let built:
    | { lower: IntegrandParts; upper: IntegrandParts; compiled: boolean }
    | null
    | undefined;
  const build = () => {
    const { lower, upper } = bounds;
    if (!isFinite(lower) || !isFinite(upper) || lower === upper) return null;
    if (!isFunction(fn, 'Function') || fn.nops !== 2) return null;
    const variable = functionLiteralParameterName(fn.ops[1]);
    if (variable === undefined || variable === 'Nothing') return null;
    // The canonical body of a function literal is a `Block`, the scope of
    // the parameter, which binds its name: the binder test reads the
    // statement of a block of one statement.
    const body =
      isFunction(fn.op1, 'Block') && fn.op1.nops === 1 ? fn.op1.op1 : fn.op1;
    if (!isTransitivelyPure(fn) || holdsBinder(body)) return null;
    // The quadrature integrates over the real parts of the bounds, so a
    // complex literal is replaced by its real part, as any other bound.
    const exact = (b: Expression, x: number) =>
      isNumber(b) && b.im === 0 ? b : ce.number(x);
    const lo = exact(bounds.lowerBound, lower);
    const hi = exact(bounds.upperBound, upper);
    // The new variable is the parameter of the literal, with its binding.
    // `ce.symbol(variable)` would declare the name in the scope of the
    // caller (`NIntegrate` evaluates in that scope), or give another
    // expression (`i` is the imaginary unit).
    const u = fn.ops[1];
    if (!isSymbol(u) || u.symbol !== variable) return null;
    const s = upper > lower ? u : u.neg();
    const half = (at: Expression) => {
      const shifted = distributeSums(ce, body.subs({ [variable]: at }));
      return integrandPartsOf(
        ce,
        ce.expr(['Function', shifted, variable]),
        shield
      );
    };
    const near = half(ce.function('Add', [lo, s]));
    const far = half(ce.function('Add', [hi, s.neg()]));
    const compiled = near.compiled && far.compiled;
    if (original.compiled && !compiled) return null;
    return { lower: near.integrand, upper: far.integrand, compiled };
  };
  return (part) => {
    if (built === undefined) built = build();
    if (built === null) return undefined;
    return {
      width: Math.abs(bounds.upper - bounds.lower) / 2,
      sign: bounds.upper > bounds.lower ? 1 : -1,
      lower: built.lower[part],
      upper: built.upper[part],
      compiled: built.compiled,
    };
  };
}

/**
 * The integral of one part of the integrand over the two halves of the
 * interval (`endpointHalves`), when it is better than a result with a
 * singular corner that was not resolved: `divergent` when a half diverges
 * (with shells of one sign), or the sum of the halves when each half
 * converged or was extrapolated. Otherwise `undefined`, and the caller keeps
 * its result. Each half has the panel budget of the first quadrature, so
 * that the half with the singular bound can bisect its corner deep enough
 * for the model of the part that is not sampled (`shellTail`,
 * `numerics/endpoint-quadrature.ts`): with half the budget, the error of
 * `∫_0^{1/4} du/(u·(−ln u)^1.1)` is two times larger. The half without a
 * singularity converges on few panels.
 */
function integrateEndpointHalves(
  ce: ComputeEngine,
  halves: EndpointHalvesPart
):
  | { estimate: number; error: number; divergent?: true; undecided?: true }
  | undefined {
  const options = {
    deadline: ce._deadlineFrame,
    singularEndpoints: true,
    ...(halves.compiled ? {} : { maxIntervals: INTERPRETED_QUADRATURE_PANELS }),
  };
  const parts = [halves.lower, halves.upper].map((g) =>
    adaptiveQuadrature(g, 0, halves.width, options)
  );
  if (parts.some((p) => p.nanRegion === true || p.oscillates === true))
    return undefined;
  // The halves are `undecided` when every divergent half is (see
  // `undecided` in `QuadratureResult`, `numerics/endpoint-quadrature.ts`).
  if (parts.some((p) => p.divergent))
    return parts.every((p) => !p.divergent || p.undecided === true)
      ? { estimate: NaN, error: NaN, divergent: true, undecided: true }
      : { estimate: NaN, error: NaN, divergent: true };
  if (
    parts.every(
      (p) =>
        (p.converged || p.extrapolated === true) &&
        Number.isFinite(p.estimate) &&
        Number.isFinite(p.error)
    )
  )
    return {
      estimate: halves.sign * (parts[0].estimate + parts[1].estimate),
      error: parts[0].error + parts[1].error,
    };
  return undefined;
}

/**
 * Integrate ONE real-valued part (`re` or `im`) of a one-limit integrand over
 * `[lower, upper]`. `Integrate(…).N()` and `NIntegrate` both call this
 * function, so the two operators use the same methods in the same order:
 *
 * 1. on a semi-infinite interval, the oscillatory quadrature;
 * 2. the adaptive Gauss–Kronrod quadrature, corrected next to a singular
 *    endpoint by the extrapolation of the shells of the corner panel and
 *    checked against the tanh-sinh rule (`singularEndpoints`,
 *    `numerics/endpoint-quadrature.ts`); on a finite interval, a singular
 *    corner that it could not resolve is computed again on the two halves
 *    of the interval, each written in the distance to its bound
 *    (`options.halves`, see `endpointHalves`);
 * 3. `NaN` when the quadrature finds that the integral diverges;
 * 4. Monte Carlo, only when the quadrature does not converge, did not find
 *    a singular corner it could not resolve (`singularCorner`), and sampling
 *    could give a better result. A quadrature result that did not converge
 *    and is kept reports an error of at least `|estimate|/√mcSamples`.
 *
 * `options.compiled` tells whether the integrand compiled: it selects the
 * quadrature panel budget and the Monte-Carlo sample count. `options.uncached`
 * maps `jsf` to the same function without the sample cache of
 * `numericIntegrandParts()`. `options.replayed` maps `jsf` to the function
 * that the quadrature calls to measure how a value changes with the result
 * of an inner integral (`IntegrandParts.replayed`). The caller leaves it out
 * when the integrand must not be evaluated a second time at a point (it is
 * not transitively pure).
 * `options.draw` is the random stream of the Monte-Carlo fallback.
 *
 * `divergent` is `true` when the estimate is `NaN` because the quadrature
 * found that the integral diverges (step 3). The caller can then look for a
 * pole at a bound to give the sign of the divergence (see
 * `endpointPoleVerdict`), except when `undecided` is also set: the
 * quadrature could not tell a divergence from a convergence.
 */
function integrateRealPart(
  ce: ComputeEngine,
  jsf: (x: number) => number,
  lower: number,
  upper: number,
  options: {
    compiled: boolean;
    uncached: (part: (x: number) => number) => (x: number) => number;
    replayed?: (part: (x: number) => number) => (x: number) => number;
    draw: () => number;
    /** Whether the integrand computes an integral. The caller sets it when the
     * expression of the integrand holds one. An integral in the body of a
     * function that the integrand calls is not in this expression: this
     * function sets it when the quadrature finds an inner one
     * (`innerQuadrature`). The passes over the real and imaginary parts share
     * this object, because the second pass can read every sample of the first
     * from the cache of `numericIntegrandParts`, and then runs no inner
     * quadrature. */
    nested: { holdsIntegral: boolean };
    /** The same part of the integrand on the two halves of the interval,
     * each written in the distance to its bound (see `endpointHalves`). The
     * quadrature integrates them when it finds a singular corner that it
     * could not resolve (`singularCorner`). It returns `undefined` when the
     * integrand cannot be written in this form. */
    halves?: () => EndpointHalvesPart | undefined;
  }
): {
  estimate: number;
  error: number;
  divergent?: true;
  /** Set with `divergent` when the quadrature could not tell a divergence
   * from a convergence (see `undecided` in `QuadratureResult`,
   * `numerics/endpoint-quadrature.ts`): the caller must not give the result
   * the sign of a pole at a bound. */
  undecided?: true;
  infinite?: 1 | -1;
  overflow?: true;
  /** Set with `divergent` when only the halves of the interval found the
   * divergence (`options.halves`): the result without them, which the
   * caller keeps when nothing confirms the divergence. */
  unconfirmed?: { estimate: number; error: number };
} {
  // Semi-infinite interval: a conditionally-convergent oscillatory
  // integrand (∫₀^∞ sin x/x, ∫₀^∞ sin(x²)) defeats Monte-Carlo
  // importance sampling. Try the dedicated lobe-integration +
  // ε-acceleration quadrature first; it returns null (→ Monte Carlo)
  // for non-oscillatory or divergent integrands.
  const aInf = !isFinite(lower);
  const bInf = !isFinite(upper);
  if (aInf !== bInf) {
    // Reversed bounds (`∫_{+∞}^0`) integrate over the ordered interval and
    // negate. Without this, `∫_{+∞}^0 sin x/x dx` gave `+π/2`: the infinite
    // LOWER bound was read as `−∞`.
    const sign = lower > upper ? -1 : 1;
    const lo = Math.min(lower, upper);
    const hi = Math.max(lower, upper);
    // An integrand that did not compile is slower to evaluate, so the
    // adaptive quadrature that the routine tries last over the whole
    // interval gets the smaller panel budget `INTERPRETED_QUADRATURE_PANELS`.
    const oscOptions = options.compiled
      ? undefined
      : { maxIntervals: INTERPRETED_QUADRATURE_PANELS };
    const osc = !isFinite(hi)
      ? integrateSemiInfiniteOscillatory(jsf, lo, ce._deadlineFrame, oscOptions)
      : integrateSemiInfiniteOscillatory(
          (t) => jsf(-t),
          -hi,
          ce._deadlineFrame,
          oscOptions
        );
    if (osc) return { estimate: sign * osc.estimate, error: osc.error };
  }

  // (2) Deterministic adaptive Gauss–Kronrod (GK15) for finite or
  // transformable (semi-infinite / doubly-infinite) bounds — near
  // machine precision on smooth integrands, and matches the compiled
  // integration path. Falls through to Monte Carlo only when it fails
  // to converge (endpoint singularities, oscillatory tails) AND the
  // sampler could actually do better — a stalled panel budget still
  // routinely carries a tighter bound than 1e7 samples can reach, and
  // for an expensive integrand (an inner quadrature, a compiled model)
  // those samples cost minutes.
  //
  // An integrand that did not compile (an operator with only a
  // JavaScript `evaluate` handler, for example) runs the quadrature
  // too, with a smaller panel budget (`INTERPRETED_QUADRATURE_PANELS`)
  // because each evaluation is slower. Its Monte-Carlo fallback
  // draws only 1e4 samples, about 1e-2 relative error, so skipping
  // the quadrature gave `∫₀¹ x² dx` as `0.33 ± 0.003`.
  const mcSamples = options.compiled ? 1e7 : 1e4;
  // `deadline`: bounds the adaptive loop (a per-panel check that
  // throws the timeout) AND is re-published as the ambient deadline so an
  // integrand that is itself an integral — interpreted, or compiled
  // to `_SYS.integrate`, which has no engine access — inherits it
  // (Tycho item 183).
  const gk = adaptiveQuadrature(jsf, lower, upper, {
    deadline: ce._deadlineFrame,
    singularEndpoints: true,
    // The reported error includes the errors of the integrals that the
    // integrand computes (see `withNestedErrors`,
    // `numerics/gauss-kronrod.ts`). This quadrature asks for them for each
    // integrand, because a test of the expression does not see an integral in
    // the body of a function that the integrand calls.
    nestedErrors: true,
    // `jsf` reads a value that it computed before from the sample cache, and
    // then calls no inner integral.
    replayIntegrand: options.replayed?.(jsf),
    ...(options.compiled
      ? {}
      : { maxIntervals: INTERPRETED_QUADRATURE_PANELS }),
  });
  if (gk.innerQuadrature === true) options.nested.holdsIntegral = true;
  // A diagnosed divergence has no finite value. Monte Carlo would
  // still return one — a mean of samples that never saw the
  // singularity — so the fallback is skipped, not just the report. An
  // integrand that oscillates without a value at a bound
  // (`∫₀¹ sin(ln(1 − x))/(1 − x) dx`) is `NaN` with no sign: it is not
  // reported as `divergent`, so the caller does not look for the sign of a
  // pole at the bound (which gave `−∞` for that integral).
  if (gk.divergent) {
    if (gk.oscillates === true) return { estimate: NaN, error: NaN };
    // The quadrature could not tell a divergence from a convergence
    // (`undecided`): the tail gives no sign. `∫₂^∞ dx/(x·(ln x)^1.001)`
    // converges, and its integrand is positive on the whole tail.
    if (gk.undecided === true)
      return { estimate: NaN, error: NaN, divergent: true, undecided: true };
    // Over an infinite bound, a divergence of the tail gives its sign
    // (`divergentTailSign`): `∫₀^∞ x dx` is `+∞`.
    const infinite = divergentTailSign(jsf, lower, upper);
    return infinite === 0
      ? { estimate: NaN, error: NaN, divergent: true }
      : { estimate: NaN, error: NaN, divergent: true, infinite };
  }
  // The integrand is `NaN` on a set that is not some isolated points (for
  // example, an integrand that has no real value on a part of the interval):
  // the integral has no value. The samples of Monte Carlo would also be
  // `NaN` there, and they cost up to `1e7` evaluations.
  if (gk.nanRegion === true) return { estimate: NaN, error: NaN };
  // An integrand that overflows on the tail of an infinite interval
  // (`∫₀^∞ eˣ dx`) gives a quadrature that is not a number and is not
  // reported as divergent. The tail gives the sign of the divergence
  // (`divergentTailSign`). When it does not (the sign changes,
  // `∫₀^∞ (eˣ − 5) dx`) but the integrand reaches an infinite value on the
  // tail (`tailReachesInfinity`), the result is reported as an `overflow`,
  // with no value: Monte Carlo would give a finite mean of samples that
  // changes at each run. The caller can still ask the exact route
  // (`exactDivergenceValue`). An integrand that is only `NaN` on the tail
  // (`sinh x / cosh² x`, an `∞/∞`) keeps the methods below.
  if (!Number.isFinite(gk.estimate) && (aInf || bInf)) {
    const infinite = divergentTailSign(jsf, lower, upper);
    if (infinite !== 0) return { estimate: NaN, error: NaN, infinite };
    if (tailReachesInfinity(jsf, lower, upper))
      return { estimate: NaN, error: NaN, overflow: true };
    // Every sample of the tail is finite: the quadrature overflowed in the
    // size of the integral (`tailIsFinite`), and the integral has no value
    // in double precision. Monte Carlo would give a random finite value.
    if (tailIsFinite(jsf, lower, upper)) return { estimate: NaN, error: NaN };
  }
  if (
    (gk.converged || gk.extrapolated === true) &&
    Number.isFinite(gk.estimate)
  )
    return { estimate: gk.estimate, error: gk.error };
  // A singular corner that the quadrature could not resolve, on a finite
  // interval: the integral is computed again on the two halves of the
  // interval, each written in the distance `u` to its bound
  // (`endpointHalves`), and the result of the halves replaces this one when
  // it is better (`integrateEndpointHalves`). An integrand that holds an
  // integral is not computed again: each sample runs an inner quadrature.
  if (
    gk.singularCorner === true &&
    options.halves !== undefined &&
    !options.nested.holdsIntegral &&
    isFinite(lower) &&
    isFinite(upper)
  ) {
    const halves = options.halves();
    const split =
      halves !== undefined ? integrateEndpointHalves(ce, halves) : undefined;
    // The divergence test of the adaptive quadrature can find a divergence
    // where a slow singularity converges, or not decide (`undecided`):
    // `∫_{1/2}^1 dt/((1 − t)(−ln(1 − t))^1.001) = 1000.37` gives an
    // undecided half. A divergence of the halves carries the result that
    // this function gives without them (`unconfirmed`, the `singularCorner`
    // result below, whose error is widened to cover the corners: `3.96 ±
    // 4415` for that integral), and the caller keeps that result when
    // nothing confirms the divergence (the sign of a pole at a bound, which
    // is not looked for when the halves are `undecided`, or the exact route).
    if (split?.divergent === true && Number.isFinite(gk.estimate))
      return {
        ...split,
        unconfirmed: {
          estimate: gk.estimate,
          error: Math.max(
            gk.error,
            Math.abs(gk.estimate) / Math.sqrt(mcSamples)
          ),
        },
      };
    if (split !== undefined && split.divergent !== true) return split;
  }
  // A result that did not converge: its error estimate can be far too small
  // (the adaptive quadrature gave `508.24896298688 ± 0.00000000053` for
  // `∫₀¹ x^(−0.999) dx = 1000` before the extrapolation of the endpoint
  // shells). The error that is reported is at least the standard error of
  // the Monte-Carlo estimate it replaces, `|estimate|/√mcSamples`. The
  // result is kept when its own error is not larger than that.
  //
  // A result next to a singular corner that the quadrature could not resolve
  // (`singularCorner`) is kept too, whatever its error: Monte Carlo
  // under-weights the neighborhood of the singularity and gave
  // `0.3220 ± 0.0063` for `∫₀^0.01 dx/(x·(−ln x)·ln²(−ln x)) = 0.6548…`,
  // where the quadrature gave `0.5028 ± 0.0176`.
  if (
    (gk.singularCorner === true || quadratureBeatsMonteCarlo(gk, mcSamples)) &&
    Number.isFinite(gk.estimate)
  )
    return {
      estimate: gk.estimate,
      error: Math.max(gk.error, Math.abs(gk.estimate) / Math.sqrt(mcSamples)),
    };

  // An integrand that holds an integral has no Monte-Carlo fallback: each
  // of the `mcSamples` samples would run an inner quadrature, and the inner
  // integral can itself have no value at some points (`∫₀^10 ∫₃^4 (y − x)⁻²
  // dx dy`, for `y` in `[3, 4]`). A result with a finite error is kept, with
  // the same floor as above; otherwise the integral has no value.
  if (options.nested.holdsIntegral)
    return Number.isFinite(gk.estimate) && Number.isFinite(gk.error)
      ? {
          estimate: gk.estimate,
          error: Math.max(
            gk.error,
            Math.abs(gk.estimate) / Math.sqrt(mcSamples)
          ),
        }
      : { estimate: NaN, error: NaN };

  // This integral is an inner integral of an integrand that is evaluated
  // again only to measure how its value changes with an inner result
  // (`insideReplay`, `numerics/gauss-kronrod.ts`). The samples would cost
  // `mcSamples` evaluations, and their mean does not follow the changed
  // result of the quadrature above.
  if (insideReplay()) return { estimate: NaN, error: NaN };

  const mce = monteCarloEstimate(
    options.uncached(jsf),
    lower,
    upper,
    mcSamples,
    ce._deadlineFrame,
    options.draw
  );
  // KNOWN LIMITATION (CORRECTNESS_FINDINGS #29 / C15): the reported
  // error bar is the Monte-Carlo standard error, which is *optimistic*
  // (~1.3–1.6× too small) for endpoint-singular integrands such as
  // ∫₋₁¹ √(1−x²)/(1+x²) dx or ∫₀¹ x^(−1/2) dx. Uniform sampling
  // under-weights the neighborhood of the singularity, so the sample
  // variance underestimates the true quadrature error and the ± bound
  // can be tighter than the actual deviation from the exact value. A
  // faithful bound needs singularity-aware quadrature (e.g. tanh-sinh
  // with endpoint clustering); until then the estimate is sound but the
  // uncertainty on singular integrands should be treated as a lower
  // bound, not a guarantee.
  return { estimate: mce.estimate, error: mce.error };
}

/**
 * The type of the integral of an integrand of type `t`. An integrand whose
 * value is a list (`∫ [x, 2x] dx`) gives one integral per element, so the
 * integral of a list is a list of the same shape, with number elements. Any
 * other integrand gives a number.
 */
function integralTypeOf(t: Readonly<Type> | undefined): Type {
  if (t === undefined) return 'number';
  if (typeof t === 'object' && t.kind === 'list')
    return { ...t, elements: integralTypeOf(t.elements) };
  // A tuple integrand is integrated coordinate by coordinate: the integral
  // is a tuple with one element per coordinate.
  if (typeof t === 'object' && t.kind === 'tuple')
    return {
      kind: 'tuple',
      elements: t.elements.map((e) => ({ ...e, type: integralTypeOf(e.type) })),
    };
  if (
    typeof t === 'string' &&
    t !== 'unknown' &&
    isSubtype(t, LIST_OF_ANY_TYPE)
  )
    return { kind: 'list', elements: 'number' };
  return 'number';
}

/**
 * Is a value of type `t` possibly a list or a tuple that an integral
 * integrates element by element? Return the list and tuple arms of `t`,
 * and whether `t` also has a scalar arm, or `undefined` when `t` has no
 * list or tuple arm, or has an arm that is neither a list, a tuple, a
 * number nor an absence marker.
 *
 * A `missing` arm is removed first, if the type has one. The restriction
 * `If(c, e)` of a list `e` is typed as `e`, for example `vector<2>`. The arms
 * of a union are read one by one: the piecewise
 * `Which(y < 1/2, [y, 2y], True, 0)` is typed `integer | vector<2>`, and its
 * value is a list in which each element is a
 * piecewise expression (`distributeRestriction()`).
 */
function listIntegrandShape(
  t: Readonly<Type> | undefined
): { lists: Type[]; scalar: boolean } | undefined {
  if (t === undefined || t === 'unknown') return undefined;
  const isList = (x: Type) =>
    x !== 'unknown' &&
    x !== 'never' &&
    x !== 'nothing' &&
    (isSubtype(x, LIST_OF_ANY_TYPE) || isTupleShapedType(x));
  const stripped = stripMissingFromType(t);
  if (isList(stripped)) return { lists: [stripped], scalar: false };
  if (typeof stripped !== 'object' || stripped.kind !== 'union')
    return undefined;
  const lists: Type[] = [];
  let scalar = false;
  for (const arm of stripped.types) {
    if (arm === 'nothing' || arm === 'never') continue;
    if (isList(arm)) lists.push(arm);
    else if (isSubtype(arm, 'number')) scalar = true;
    else return undefined;
  }
  return lists.length > 0 ? { lists, scalar } : undefined;
}

/**
 * An integral whose integrand is a LIST (`∫_0^1 [x, 2x] dx`, or the outer
 * integral of `∫_0^1 ∫_0^{G} x·y dx dy` with `G = [1, 2, 3]`, whose integrand
 * is an integral with a list bound) is one integral per element of the list:
 * `Integrate([f1, f2], limits)` is `[Integrate(f1, limits), Integrate(f2,
 * limits)]`. This is the same rule as for a list bound. When a bound is also
 * a list, the element `i` of the integrand is paired with the element `i` of
 * the bound, and the lengths must agree.
 *
 * Return `undefined` when the integrand is not a list: the caller then
 * integrates it as usual. A list bound whose length is not the length of the
 * integrand is the `incompatible-dimensions` error, under `evaluate()` and
 * `N()` alike, as a mismatch of two list bounds is.
 *
 * A TUPLE integrand (`∫_0^1 (x, 2x) dx`) is integrated coordinate by
 * coordinate, as `Sum` sums a tuple summand coordinate by coordinate: the
 * value is the tuple of the integrals of the coordinates, `(1/2, 1)`. A
 * tuple is a point, not a list, so its coordinates are never paired with the
 * elements of a list bound. A list bound instead gives one integral of the
 * whole tuple per element of the bound, and the value is a list of tuples:
 * `∫_0^{[1, 2]} (x, 2x) dx` is `[(1/2, 1), (2, 4)]`. When several bounds are
 * lists, they are paired element by element and their lengths must agree.
 */
function integrateListIntegrand(
  ce: ComputeEngine,
  integrand: Expression,
  limits: ReadonlyArray<Expression>,
  numericApproximation: boolean
): Expression | undefined {
  // The integrand is a `List` value, or, for a function literal, its body
  // is typed as a list. Checking the type first means that an integrand that
  // is not a list is not evaluated here. The result type can also be a union
  // of a list and scalars or absence markers (`listIntegrandShape()`): a
  // restriction `If(c, e)` of a list `e` is typed `list<number>`,
  // and `Which(c, [y, 2y], True, 0)` is typed `integer | vector<2>`. Both
  // are integrated element by element (see `distributeRestriction()`
  // below). The evaluated value decides: when it is not a list, the caller
  // integrates it as usual.
  let value: Expression | undefined;
  if (isFunction(integrand, 'List') || isFunction(integrand, 'Tuple'))
    value = integrand;
  else if (isFunction(integrand, 'Function')) {
    if (listIntegrandShape(functionResult(integrand.type.type)) === undefined)
      return undefined;
  } else return undefined;

  // The integration variables are bound by `Integrate`: a same-named global
  // assignment (`x := 5`) must not substitute into the integrand or into a
  // bound that refers to an outer integration variable.
  const names: string[] = [];
  for (const l of limits)
    if (isFunction(l)) {
      const v = sym(l.op1);
      if (v && v !== 'Nothing') names.push(v);
    }
  // Every name a parameter binds: an annotated parameter, a parameter with
  // a default value and a destructuring pattern are read through their
  // wrappers.
  if (isFunction(integrand, 'Function'))
    for (const p of integrand.ops.slice(1))
      names.push(...functionLiteralParameterNames(p));

  return withValueShield(ce, names, () => {
    // A function literal whose body is a list because a call in it maps over
    // a list argument (`y ↦ y·c(y, L, E)` with `E` a list) is split into one
    // integrand per element of that list (`y ↦ y·c(y, L, E_k)`), without
    // evaluating the call (`threadedListIntegrands()`). Each integral then
    // goes through the scalar route, as it does when the argument is one
    // element of the list.
    let elements: ReadonlyArray<Expression> | undefined =
      value === undefined && isFunction(integrand, 'Function')
        ? threadedListIntegrands(ce, integrand, names)
        : undefined;
    if (elements === undefined) {
      // The integrand is evaluated exactly, also under `N()`: an inner
      // integral with a free outer integration variable has no numeric
      // value, but its exact value can be a list of expressions in that
      // variable.
      value ??= liftIntegrand(integrand).evaluate();
      value = distributeRestriction(ce, value);
      if (isFunction(value, 'Tuple'))
        return integrateTupleIntegrand(ce, value, limits, numericApproximation);
      if (!isFunction(value, 'List')) return undefined;
      elements = value.ops;
    }
    const count = elements.length;

    // Evaluate each bound once, and pair a list bound with the integrand.
    const bounds: (Expression[] | undefined)[] = [];
    for (const l of limits) {
      if (!isFunction(l, 'Limits')) {
        bounds.push(undefined);
        continue;
      }
      const values = [l.op2, l.op3].map((b) =>
        sym(b) === 'Nothing' ? b : numericApproximation ? b.N() : b.evaluate()
      );
      for (const b of values) {
        if (!isFunction(b, 'List') || b.nops === count) continue;
        return ce.error('incompatible-dimensions', `${count} vs ${b.nops}`);
      }
      bounds.push(values);
    }

    const results = elements.map((element, i) => {
      const elementLimits = limits.map((l, k) => {
        const b = bounds[k];
        if (!isFunction(l, 'Limits') || b === undefined) return l;
        const [lo, hi] = b.map((x) => (isFunction(x, 'List') ? x.ops[i] : x));
        return ce.function('Limits', [l.op1, lo, hi]);
      });
      const integral = ce.function('Integrate', [element, ...elementLimits]);
      return numericApproximation ? integral.N() : integral.evaluate();
    });
    return ce.function('List', results);
  });
}

/**
 * The library operators through which `threadedListParts()` maps a list
 * operand: each of them applied to one list and scalars is the list of its
 * applications to the elements of the list.
 */
const LIST_THREADING_OPERATORS = new Set([
  'Multiply',
  'Add',
  'Negate',
  'Divide',
]);

/**
 * The integrands, one per element, of the function literal `literal` whose
 * body is a list because a call in it maps over a list argument. With
 * `c(y, D, e) := ∫_{−D}^{D} n(x, y, e) dx` and `E = [0.001, 0.005]`, the
 * integrand `y ↦ y·c(y, L, E)` gives `[y ↦ y·c(y, L, 0.001), y ↦ y·c(y, L,
 * 0.005)]`. The call `c(y, L, E)` is not evaluated: evaluating it writes the
 * body of `c` into each element, and the integral of that body is slow to
 * decline when `L` has no value. An integrand with one element of `E` keeps
 * the call, so the list keeps it too. (User decision 2026-10-28 on CE-604
 * in `ROADMAP.md`.)
 *
 * The split follows the broadcast rules, and declines (returns `undefined`)
 * for anything outside the cases below; the caller then evaluates the
 * integrand as before:
 * - a call of a user function whose parameters are all scalars
 *   (`paramsAreScalar()`) maps over each list argument, and the lists must
 *   have the same length;
 * - `Multiply`, `Add`, `Negate` and `Divide` map over ONE list operand, the
 *   other operands being scalars;
 * - a list operand does not read an integration variable (`names`), and its
 *   value is a nonempty `List` whose elements are not collections. That
 *   operand alone is evaluated.
 *
 * The split is only for a body that holds a call of a user function, which
 * the evaluation of the whole integrand would replace by the body of the
 * function: the case of the decision. A body such as `(Σ k·x)·E`, with no
 * such call, is evaluated by the caller as before: the scalar route does not
 * evaluate a held operator of the integrand (`Sum`, `Product`, `D`), so the
 * split would lose the exact value that the evaluation of the whole
 * integrand finds.
 *
 * A list of more than `MAX_SIZE_EAGER_COLLECTION` elements is not split: a
 * broadcast over it gives a lazy `Map`, and the caller keeps that result.
 *
 * The body must be transitively pure (`isTransitivelyPure()`): every node
 * other than the list operands is copied into each integrand, so a
 * `Random()` argument would be drawn once per element, where the broadcast
 * draws it once and shares the value.
 *
 * The structure is checked before any list operand is evaluated, so that a
 * decline for the structure evaluates nothing. A decline after the
 * evaluation (lists of different lengths, an integrand whose body is still
 * typed as a list, such as a call of a function that returns a list) costs
 * one more evaluation of the list operands in the caller; they are pure, so
 * the value is the same.
 *
 * Each integrand is rebuilt from the bound nodes of `literal`: only the list
 * operands are replaced, and each rebuilt node keeps the binding of its
 * operator and its scope (`rebuildWithBinding()`). A call of `c` stays a call
 * of the `c` it named, also when the integral is evaluated in a scope that
 * declares another `c`.
 */
function threadedListIntegrands(
  ce: ComputeEngine,
  literal: Expression,
  names: ReadonlyArray<string>
): Expression[] | undefined {
  if (!isFunction(literal, 'Function') || !isTransitivelyPure(literal.op1))
    return undefined;
  const plan = threadingPlan(literal.op1, names);
  if (
    plan === undefined ||
    plan === null ||
    !holdsUserFunctionCall(literal.op1) ||
    holdsHeldOperator(literal.op1)
  )
    return undefined;
  const elements = new Map<Expression, ReadonlyArray<Expression>>();
  for (const leaf of planLeaves(plan)) {
    const known = leaf.count;
    if (typeof known === 'number' && known > MAX_SIZE_EAGER_COLLECTION)
      return undefined;
    const value = leaf.evaluate();
    if (
      !isFunction(value, 'List') ||
      value.nops === 0 ||
      value.nops > MAX_SIZE_EAGER_COLLECTION ||
      value.ops.some((x) => typeCouldBeCollection(x.type.type))
    )
      return undefined;
    elements.set(leaf, value.ops);
  }
  const count = elements.values().next().value!.length;
  for (const xs of elements.values()) if (xs.length !== count) return undefined;
  const integrands = Array.from({ length: count }, (_, k) =>
    rebuildWithBinding(ce, literal, [
      buildThreadedElement(ce, plan, elements, k),
      ...literal.ops.slice(1),
    ])
  );
  if (
    integrands.some(
      (f) =>
        !isFunction(f, 'Function') ||
        listIntegrandShape(functionResult(f.type.type)) !== undefined
    )
  )
    return undefined;
  return integrands;
}

/**
 * How an expression of the body of an integrand maps over its list operands
 * (see `threadedListIntegrands()`): a `leaf` is a list operand, replaced by
 * its element k in the integrand k; a `node` is rebuilt over the elements of
 * its operands, where an operand that is `null` cannot be a collection and is
 * kept as it is.
 */
type ThreadingPlan =
  | { kind: 'leaf'; expr: Expression }
  | {
      kind: 'node';
      expr: Expression;
      ops: ReadonlyArray<ThreadingPlan | null>;
    };

/**
 * The plan of `e` (see `ThreadingPlan`), read from its structure and types
 * only: nothing is evaluated. `null` when `e` cannot be a collection, and
 * `undefined` when the split declines.
 */
function threadingPlan(
  e: Expression,
  names: ReadonlyArray<string>
): ThreadingPlan | null | undefined {
  if (!typeCouldBeCollection(e.type.type)) return null;

  if (isFunction(e, 'Block')) {
    if (e.nops !== 1) return undefined;
    const op = threadingPlan(e.op1, names);
    return op ? { kind: 'node', expr: e, ops: [op] } : undefined;
  }

  if (isFunction(e) && e.operator !== 'List') {
    const def = e.operatorDefinition;
    let userCall: boolean;
    let libraryCall = false;
    if (def === undefined) {
      // A call of a function held as a value (`ce.declare('c', 'function')`
      // then `ce.assign('c', literal)`).
      userCall = valueCallMapsOverLists(e);
    } else {
      const sig = def.signature.type;
      userCall =
        def.isUserFunctionDefinition &&
        !def.lazy &&
        paramsAreScalar(def) &&
        typeof sig === 'object' &&
        sig.kind === 'signature' &&
        e.nops <= (sig.args?.length ?? 0) + (sig.optArgs?.length ?? 0);
      libraryCall =
        !def.isUserFunctionDefinition &&
        LIST_THREADING_OPERATORS.has(e.operator);
    }
    if (!userCall && !libraryCall) return undefined;
    const ops = e.ops.map((op) => threadingPlan(op, names));
    if (ops.some((x) => x === undefined)) return undefined;
    const lists = ops.filter((x) => x !== null).length;
    if (lists === 0 || (libraryCall && lists > 1)) return undefined;
    return { kind: 'node', expr: e, ops: ops as ThreadingPlan[] };
  }

  // A list operand: a symbol or a `List` that does not read an integration
  // variable. It is evaluated later, by `threadedListIntegrands()`.
  if (e.symbols.some((s) => names.includes(s))) return undefined;
  return { kind: 'leaf', expr: e };
}

/** True when `e` is, or holds, a call of a user function. */
function holdsUserFunctionCall(e: Expression): boolean {
  if (!isFunction(e)) return false;
  if (e.operatorDefinition?.isUserFunctionDefinition === true) return true;
  if (e.operatorDefinition === undefined && valueHeldLiteral(e) !== undefined)
    return true;
  return e.ops.some((op) => holdsUserFunctionCall(op));
}

/**
 * The operators that hold their operands and that are not binders, which
 * `holdsHeldOperator()` reads in addition to the binders.
 */
const HELD_INTEGRAND_OPERATORS = new Set([
  'Limit',
  'Hold',
  'ND',
  'NIntegrate',
  'Derivative',
]);

/**
 * True when the expression `e` of an integrand, read as written (the body
 * of a called function is not read), holds a binder other than `Block`
 * (`Sum`, `Product`, `D`, `Integrate`: a definition with `scoped`) or
 * another operator that holds its operands (`HELD_INTEGRAND_OPERATORS`).
 * The scalar route does not evaluate the other operators (a `Limit`, a
 * `Hold`) before it integrates, where the evaluation of the whole integrand
 * does. It evaluates an inner `Integrate`, `Sum`, `Product` or `D`
 * (`evaluateInnerIntegrals`), but it keeps one whose value still has the
 * operator or is conditional (a restriction), and a `Sum` or `Product` with a
 * bound that reads an integration variable. The evaluation of the whole
 * integrand evaluates them in these cases too. So the split declines for
 * all of them, and `∫_0^1 (Σ_{k=1}^3 k·x)·f(x, E) dx` is `[9/2, 15/2]` on
 * the route that evaluates the integrand whole.
 */
function holdsHeldOperator(e: Expression): boolean {
  if (!isFunction(e)) return false;
  if (HELD_INTEGRAND_OPERATORS.has(e.operator)) return true;
  if (e.operator !== 'Block' && e.operatorDefinition?.scoped) return true;
  return e.ops.some((op) => holdsHeldOperator(op));
}

/**
 * The `expected-function` error that boxing the call `e` gives now, when the
 * head of `e` is a data symbol now and was not one when `e` was boxed.
 * `undefined` for every other node.
 *
 * A call `g(x)` that is boxed while `g` has no definition is valid: the name
 * can still become a function. After `ce.declare('g', 'real')`, the same call
 * boxed again is the error `expected-function`, but the node that was boxed
 * before the declaration does not change.
 *
 * The head is read through the binding of the call
 * (`callableBindingInContext()`), as the evaluation of the call reads it,
 * and the call is boxed again with that binding (`withCallableBinding()`): a
 * declaration of the same name in another scope does not change the answer.
 * A head with an inferred or unknown type, or with a type that a function
 * can have, is skipped before the call is boxed again. The boxing of the
 * call decides for the other heads (`S(B)` with `S` declared `set<number>`
 * is a valid application), so the rule is stated once, where `box.ts` makes
 * the error.
 */
function callOfDataSymbolError(
  ce: ComputeEngine,
  e: Expression
): Expression | undefined {
  if (!isFunction(e) || e.operatorDefinition !== undefined) return undefined;
  // A free call head (`isFreeCallHead()`, `binding-unit.ts`) has no
  // definition of its own: it reads the value definition that its name
  // resolves to now.
  const read = readBinding(e);
  const own = read !== undefined && 'value' in read ? read.value : undefined;
  if (own === undefined) return undefined;
  const binding = callableBindingInContext(ce, e.operator, { value: own });
  if (binding === undefined || !isValueDef(binding)) return undefined;
  const type = binding.value.type;
  if (
    binding.value.inferredType ||
    type.isUnknown ||
    type.couldMatch('function')
  )
    return undefined;
  const boxedAgain = withCallableBinding(e, () =>
    ce.function(e.operator, e.ops)
  );
  return isExpectedFunctionError(boxedAgain) ? boxedAgain : undefined;
}

/** True when `e` is an `Error` expression with the code `expected-function`. */
function isExpectedFunctionError(e: Expression): boolean {
  if (!isFunction(e, 'Error')) return false;
  const code = e.op1;
  return (
    isFunction(code, 'ErrorCode') &&
    isString(code.op1) &&
    code.op1.string === 'expected-function'
  );
}

/**
 * The `expected-function` error that is the value of `expression` when it
 * holds a call whose head became a data symbol after the call was boxed
 * (`callOfDataSymbolError()`), or `undefined`. `expression` is the node of
 * an operator that reads its first operand without evaluating it (`D`,
 * `Limit`, `NIntegrate`), and the evaluate handler of that operator returns
 * this error in place of its own value.
 *
 * Such an operator gives a value for the call: `D` differentiates `g(x)` to
 * `Apply(Derivative(g, 1), x)`, and `Limit` and `NIntegrate` sample it and
 * give `NaN`. The same expression boxed after the declaration holds the
 * error in place of the call, and the error is its value before the handler
 * runs. The error returned here is that value: the error of the first such
 * call that an error walk reaches (`errorValueWhere()`), with the same
 * breadcrumb frames.
 *
 * A call below a selecting operator is not reached, because the error is
 * then not the value of the expression boxed after the declaration before
 * its handler runs: the call in `If(x > 2, g(x), x^x)` is not demanded over
 * `[0, 1]`, so `NIntegrate` of it has a value. A call below a collection
 * literal is not reached either. When no call is reached, the handler works
 * as it does for a head with no definition. Its value can then differ from
 * the value of the expression boxed after the declaration:
 * `D(If(x > 2, g(x), x^2), x)` keeps a derivative for each branch, where the
 * expression boxed after the declaration is the error, because `D`
 * differentiates the branch that holds it.
 */
function dataSymbolCallError(
  ce: ComputeEngine,
  expression: Expression | undefined
): Expression | undefined {
  if (expression === undefined) return undefined;
  return errorValueWhere(expression, (e) => callOfDataSymbolError(ce, e));
}

/**
 * The function literal that the call `e` applies when its operator is a
 * function HELD AS A VALUE (`ce.declare('c', 'function')`, then
 * `ce.assign('c', literal)`): the value of the definition the call is bound
 * to, read through `callableBindingInContext()`, as the evaluation of the
 * call reads it. `undefined` when `e` is not such a call, or when the value
 * is not a `Function` literal.
 */
function valueHeldLiteral(e: Expression): Expression | undefined {
  if (!isFunction(e) || e.operatorDefinition !== undefined) return undefined;
  // A free call head (`isFreeCallHead()`, `binding-unit.ts`) reads the
  // value definition that its name resolves to now.
  const read = readBinding(e);
  const def = read !== undefined && 'value' in read ? read.value : undefined;
  if (def === undefined) return undefined;
  const binding = callableBindingInContext(e.engine, e.operator, {
    value: def,
  });
  if (binding === undefined || !('value' in binding)) return undefined;
  const literal = binding.value.value;
  return isFunction(literal, 'Function') ? literal : undefined;
}

/**
 * True when a call `e` of a function held as a value maps over its list
 * arguments: every parameter is a scalar, read from the signature the
 * evaluation of the call reads (the declared signature, or the type of the
 * literal when the name is declared `function`), and the call has no more
 * arguments than the literal has parameters. A parameter that takes a whole
 * collection (`(t, e) ↦ t·Length(e)`) makes the call bind the list whole,
 * and the split declines.
 *
 * A literal that calls itself by name declines too: the evaluation reads its
 * signature with the evidence of the self-calls (`namedLiteralSignatureType()`
 * in `boxed-expression/effects-inference.ts`, which this module may not
 * import), and a self-call with a list can make a parameter a collection.
 */
function valueCallMapsOverLists(e: Expression): boolean {
  const literal = valueHeldLiteral(e);
  const def = e.valueDefinition;
  if (!isFunction(literal) || def === undefined || !isFunction(e)) return false;
  if (callsOperator(literal.op1, e.operator)) return false;
  const declared = def.type?.type;
  const gate =
    typeof declared === 'object' &&
    declared.kind === 'signature' &&
    !def.inferredType
      ? declared
      : literal.type.type;
  return paramsAreScalar(gate) && e.nops <= literal.nops - 1;
}

/** True when `e` is, or holds, a call whose operator is `name`. */
function callsOperator(e: Expression, name: string): boolean {
  if (!isFunction(e)) return false;
  if (e.operator === name) return true;
  return e.ops.some((op) => callsOperator(op, name));
}

/** The list operands of `plan`, each once. */
function planLeaves(plan: ThreadingPlan): Expression[] {
  if (plan.kind === 'leaf') return [plan.expr];
  const leaves = plan.ops.flatMap((op) => (op ? planLeaves(op) : []));
  return [...new Set(leaves)];
}

/**
 * The element `k` of the expression of `plan`: each list operand is replaced
 * by its element `k` (from `elements`), and every other node is kept, or
 * rebuilt with its binding (`rebuildWithBinding()`).
 */
function buildThreadedElement(
  ce: ComputeEngine,
  plan: ThreadingPlan,
  elements: ReadonlyMap<Expression, ReadonlyArray<Expression>>,
  k: number
): Expression {
  if (plan.kind === 'leaf') return elements.get(plan.expr)![k];
  const e = plan.expr;
  if (!isFunction(e)) return e;
  return rebuildWithBinding(
    ce,
    e,
    e.ops.map((op, i) => {
      const p = plan.ops[i];
      return p ? buildThreadedElement(ce, p, elements, k) : op;
    })
  );
}

/**
 * The node `e` over the operands `ops`, bound to the definition of the
 * operator of `e` (`withCallableBinding()`), with the scope of `e`, in the
 * form of `e`. A rebuild through `ce.function()` alone would look the
 * operator up in the current scope, which can declare another function with
 * that name.
 */
function rebuildWithBinding(
  ce: ComputeEngine,
  e: Expression,
  ops: ReadonlyArray<Expression>
): Expression {
  const form = e.isCanonical
    ? 'canonical'
    : e.isStructural
      ? 'structural'
      : 'raw';
  return withCallableBinding(e, () =>
    ce.function(e.operator, ops, { form, scope: e.localScope })
  );
}

/**
 * An evaluated integrand that is a restriction of a list by a condition on
 * the integration variable, `If(c, [e1, e2])`, is the list
 * `[If(c, e1), If(c, e2)]`: at each point the two forms have the same
 * elements, and the list form lets `integrateListIntegrand` integrate one
 * element at a time. A piecewise `Which(c1, v1, c2, v2, …)` whose values
 * include a list is distributed the same way: element k is
 * `Which(c1, v1[k], c2, v2[k], …)`, where a value that is not a list is the
 * same for every k. A product `Multiply(a, If(c, L))` (or of a `Which`)
 * whose other factors are not lists is distributed too, as
 * `[a·If(c, L1), a·If(c, L2)]`. A value of a `Which` that is itself a
 * held restriction, `Which` or product of them (a nested piecewise with an
 * undecided condition) is distributed the same way, and its element k is
 * used in element k of the outer `Which`.
 *
 * A tuple is distributed as a list is, and the result is a `Tuple`:
 * `If(c, (e1, e2))` is `(If(c, e1), If(c, e2))`. The values of a
 * `Which` that are distributed must all be lists or all be tuples.
 *
 * Nothing is distributed when the type of a condition can hold a
 * collection (a list of booleans is a mask, which a restriction and `Which`
 * already apply element by element, and a symbol declared `list<boolean>`
 * with no value can become one), when two distributed values have
 * different lengths, or when a value or another factor whose type can hold
 * a collection cannot be distributed (it would otherwise be copied whole
 * into each element). Any other value is returned unchanged.
 */
function distributeRestriction(
  ce: ComputeEngine,
  value: Expression
): Expression {
  const result = distributedElements(ce, value);
  return result ? ce.function(result.head, result.elements) : value;
}

/**
 * The elements of the distributed form of `x` (see
 * `distributeRestriction()`), and the head, `List` or `Tuple`, of that
 * form. Return `undefined` when `x` is not distributed.
 */
function distributedElements(
  ce: ComputeEngine,
  x: Expression
): { head: 'List' | 'Tuple'; elements: ReadonlyArray<Expression> } | undefined {
  const mayBeCollection = (e: Expression) => typeCouldBeCollection(e.type.type);
  const indexed = (e: Expression) =>
    isFunction(e, 'List') || isFunction(e, 'Tuple')
      ? { head: e.operator as 'List' | 'Tuple', elements: e.ops }
      : undefined;

  const restriction = restrictionParts(x);
  if (restriction !== undefined) {
    const { value: body, condition: cond } = restriction;
    const parts = indexed(body);
    if (parts === undefined || mayBeCollection(cond)) return undefined;
    return {
      head: parts.head,
      elements: parts.elements.map((e) => ce.function('If', [cond, e])),
    };
  }

  if (isFunction(x, 'Which') && x.nops >= 2 && x.nops % 2 === 0) {
    for (let i = 0; i < x.nops; i += 2)
      if (mayBeCollection(x.ops[i])) return undefined;
    // `Which` holds its values while a condition is undecided, so a value
    // such as `1/ElementMax(E, y)` is not a `List` yet. A value that is
    // transitively pure and typed as a list is evaluated here; an impure one
    // (a `Random()` draw) is left held, so that nothing is drawn for a
    // branch that is not taken.
    const values: Array<ReadonlyArray<Expression> | Expression> = [];
    let head: 'List' | 'Tuple' | undefined;
    let count = 0;
    for (let i = 1; i < x.nops; i += 2) {
      let v = x.ops[i];
      if (
        indexed(v) === undefined &&
        isTransitivelyPure(v) &&
        listIntegrandShape(v.type.type) !== undefined
      )
        v = v.evaluate();
      const parts = indexed(v) ?? distributedElements(ce, v);
      if (parts === undefined) {
        if (mayBeCollection(v)) return undefined;
        values.push(v);
        continue;
      }
      if (head === undefined) {
        head = parts.head;
        count = parts.elements.length;
      } else if (head !== parts.head || count !== parts.elements.length)
        return undefined;
      values.push(parts.elements);
    }
    if (head === undefined) return undefined;
    const elementOf = (v: ReadonlyArray<Expression> | Expression, k: number) =>
      Array.isArray(v) ? v[k] : (v as Expression);
    return {
      head,
      elements: Array.from({ length: count }, (_, k) =>
        ce.function(
          'Which',
          x.ops.map((op, i) =>
            i % 2 === 0 ? op : elementOf(values[(i - 1) / 2], k)
          )
        )
      ),
    };
  }

  if (!isFunction(x, 'Multiply')) return undefined;
  let index = -1;
  let parts:
    { head: 'List' | 'Tuple'; elements: ReadonlyArray<Expression> } | undefined;
  for (let i = 0; i < x.nops && parts === undefined; i++) {
    parts = distributedElements(ce, x.ops[i]);
    index = i;
  }
  if (parts === undefined) return undefined;
  if (x.ops.some((op, i) => i !== index && mayBeCollection(op)))
    return undefined;
  return {
    head: parts.head,
    elements: parts.elements.map((e) =>
      ce.function(
        'Multiply',
        x.ops.map((op, i) => (i === index ? e : op))
      )
    ),
  };
}

/**
 * The integral of a tuple, `value`, which is the evaluated integrand of
 * `integrateListIntegrand`. The caller has shielded the integration
 * variables from their global values.
 *
 * When no bound is a list, the value is the tuple of the integrals of the
 * coordinates. When a bound is a list, the value is a list with one integral
 * of the whole tuple per element of the bound (each a tuple). Two list
 * bounds of different lengths are the `incompatible-dimensions` error, under
 * `evaluate()` and `N()` alike, as for a list integrand.
 */
function integrateTupleIntegrand(
  ce: ComputeEngine,
  value: Expression & import('../global-types.js').FunctionInterface,
  limits: ReadonlyArray<Expression>,
  numericApproximation: boolean
): Expression {
  const integrate = (limits: ReadonlyArray<Expression>) => (x: Expression) => {
    const integral = ce.function('Integrate', [x, ...limits]);
    return numericApproximation ? integral.N() : integral.evaluate();
  };

  // Evaluate each bound once, and find the length of the list bounds.
  let count: number | undefined;
  const bounds: (Expression[] | undefined)[] = [];
  for (const l of limits) {
    if (!isFunction(l, 'Limits')) {
      bounds.push(undefined);
      continue;
    }
    const values = [l.op2, l.op3].map((b) =>
      sym(b) === 'Nothing' ? b : numericApproximation ? b.N() : b.evaluate()
    );
    for (const b of values) {
      if (!isFunction(b, 'List')) continue;
      if (count === undefined) count = b.nops;
      else if (count !== b.nops)
        return ce.error('incompatible-dimensions', `${count} vs ${b.nops}`);
    }
    bounds.push(values);
  }

  // The limits of the integral for element `i` of the list bounds. The
  // bound values computed above are used, so that a bound with side effects
  // (`Random()`) is evaluated once, and all the coordinates see one value.
  const limitsAt = (i: number) =>
    limits.map((l, k) => {
      const b = bounds[k];
      if (!isFunction(l, 'Limits') || b === undefined) return l;
      const [lo, hi] = b.map((x) => (isFunction(x, 'List') ? x.ops[i] : x));
      return ce.function('Limits', [l.op1, lo, hi]);
    });

  if (count === undefined)
    return ce.function('Tuple', value.ops.map(integrate(limitsAt(0))));

  const results: Expression[] = [];
  for (let i = 0; i < count; i++)
    results.push(ce.function('Tuple', value.ops.map(integrate(limitsAt(i)))));
  return ce.function('List', results);
}

/**
 * Iterated numeric quadrature for a multi-limit `Integrate`, e.g.
 * `Integrate(f, Limits(x, 0, 3), Limits(y, 0, 2))`. Limits follow the
 * Mathematica iterator convention (matching the symbolic path): the FIRST
 * limit is the OUTERMOST integral, so the bounds of limit i may reference the
 * variables of limits 0..i−1 (`Integrate(1, Limits(x,0,1), Limits(y,0,x))` is
 * the triangle, ½). A bound that references its own or a LATER (inner)
 * integration variable, or that otherwise fails to numericize, declines
 * (returns `undefined`, keeping the integral symbolic) rather than
 * integrating wrongly.
 *
 * `evaluatedBounds`, when given, holds for each limit the values of its lower
 * and upper bounds that the caller already computed with `.N()`. A bound that
 * does not reference an integration variable uses that value, and is not
 * evaluated again. This is necessary when a bound has side effects: a bound
 * `Random()` must use the same draw that the caller saw, and must not
 * consume a second one.
 */
/**
 * The point at fraction `s` (in `(0, 1)`) of the range between `lo` and
 * `hi`, for the grid of `dependentPoleScan`. A finite range is divided
 * linearly. An infinite bound uses the transform of the quadrature
 * (`adaptiveQuadrature`): `lo + s/(1 − s)` for `[lo, +∞)`,
 * `hi − s/(1 − s)` for `(−∞, hi]`, and `u/(1 − u²)` with `u = 2s − 1` for
 * `(−∞, +∞)`. The bounds may be in either order.
 */
function scanPoint(lo: number, hi: number, s: number): number {
  const loInf = !Number.isFinite(lo);
  const hiInf = !Number.isFinite(hi);
  if (!loInf && !hiInf) return lo + s * (hi - lo);
  if (loInf && hiInf) {
    const u = 2 * s - 1;
    return u / (1 - u * u);
  }
  const finite = loInf ? hi : lo;
  const infinite = loInf ? lo : hi;
  return finite + Math.sign(infinite) * (s / (1 - s));
}

/**
 * A finite range inside the range between `lo` and `hi`, with the same
 * orientation, for the interior-pole check of `dependentPoleScan`. The check
 * accepts an infinite bound, but then also tests the integrand at points far
 * past the grid, and the scan needs only the poles near the grid. A finite
 * bound is kept. An infinite bound is
 * replaced by a point `1024·max(1, |b|)` past the other bound `b`, or by
 * `±1024` when both bounds are infinite: the points of the grid of a
 * dimension with an infinite range (`scanPoint`) are within `±63` of its
 * finite bound, so a pole that moves with them stays inside the cut range.
 */
function finiteScanRange(lo: number, hi: number): [number, number] {
  const loInf = !Number.isFinite(lo);
  const hiInf = !Number.isFinite(hi);
  if (!loInf && !hiInf) return [lo, hi];
  if (loInf && hiInf) return [Math.sign(lo) * 1024, Math.sign(hi) * 1024];
  const finite = loInf ? hi : lo;
  const cut =
    finite + Math.sign(loInf ? lo : hi) * 1024 * Math.max(1, Math.abs(finite));
  return loInf ? [cut, hi] : [lo, cut];
}

/**
 * The expressions in `e` that can be zero where `e` is unbounded: the
 * divisor of a `Divide` and the base of a `Power` with a negative numeric
 * exponent, with a `Negate`, `Sqrt`, `Abs` or a positive numeric power
 * removed, and each factor of a product taken separately. For
 * `1/√((x − a)² + (y − b)²)` the result is `[(x − a)² + (y − b)²]`.
 * `budget` limits the number of nodes that are visited; the result is
 * `undefined` when the walk uses all of it.
 */
function singularBases(
  e: Expression,
  budget = { nodes: 400 }
): Expression[] | undefined {
  const bases: Expression[] = [];
  const addBase = (d: Expression): void => {
    if (!isFunction(d)) return;
    if (d.operator === 'Multiply') {
      for (const factor of d.ops) addBase(factor);
      return;
    }
    if (
      d.operator === 'Negate' ||
      d.operator === 'Sqrt' ||
      d.operator === 'Abs'
    ) {
      addBase(d.op1);
      return;
    }
    if (d.operator === 'Power') {
      const exponent = d.op2;
      if (isNumber(exponent) && exponent.isNumberLiteral && exponent.re > 0)
        addBase(d.op1);
      return;
    }
    bases.push(d);
  };
  const walk = (x: Expression): boolean => {
    if (budget.nodes-- <= 0) return false;
    if (!isFunction(x)) return true;
    if (x.operator === 'Divide') addBase(x.op2);
    else if (x.operator === 'Power') {
      const exponent = x.op2;
      if (isNumber(exponent) && exponent.isNumberLiteral && exponent.re < 0)
        addBase(x.op1);
    }
    return x.ops.every(walk);
  };
  return walk(e) ? bases : undefined;
}

/**
 * The point where `base` is zero, when `base` is a positive definite
 * quadratic polynomial in the two variables `vars` and that point is in the
 * closed box `box` (the bounds of each variable, in either order). An
 * example is `(x − 1/64)² + (y − 1/64)²`, which is zero only at
 * `(1/64, 1/64)`.
 *
 * The point is found with floating-point numbers: the values of `base` at
 * six points of the box give the coefficients of the quadratic, and two
 * more points check that `base` is near that quadratic. The coordinates are
 * then approximated by rational numbers. The point is kept only when the
 * exact evaluation of `base` there is exactly zero, and when the exact
 * values of `base` on a grid around the point prove that `base` is the
 * quadratic form below. Thus the result is exact, and the variables can be
 * shifted to the point without a rounding error (see
 * `integrateAroundSingularPoint`). A divisor with floating-point
 * coefficients passes only when its exact evaluation gives these values with
 * no rounding error, as `(x − 0.3)² + (y − 0.3)²` does.
 *
 * The result has the exact coordinates and `quadratic`, the form
 * `½·uᵀ·H·u` that is equal to `base` at the point plus `u`, with the exact
 * Hessian `H` of `base`. The result is `undefined` in every other case.
 */
function quadraticZeroPoint(
  ce: ComputeEngine,
  base: Expression,
  vars: readonly [string, string],
  box: readonly [readonly [number, number], readonly [number, number]]
): { point: [Expression, Expression]; quadratic: Expression } | undefined {
  const [x, y] = vars;
  if (polynomialDegree(base, x) !== 2 || polynomialDegree(base, y) !== 2)
    return undefined;
  if (base.symbols.some((s) => s !== x && s !== y)) return undefined;
  // The samples below evaluate `base`, so an effect in it (`Random()`) would
  // run more times than the quadrature runs it.
  if (!isTransitivelyPure(base)) return undefined;

  // The value of `base` at the point `(s, t)` of the box, in coordinates
  // that are 0 at the center of the box and ±1 at its edges.
  const center = box.map(([lo, hi]) => (lo + hi) / 2);
  const half = box.map(([lo, hi]) => Math.abs(hi - lo) / 2);
  const at = (s: number, t: number): number =>
    base
      .subs({
        [x]: ce.number(center[0] + half[0] * s),
        [y]: ce.number(center[1] + half[1] * t),
      })
      .N().re;
  const f00 = at(0, 0);
  const f10 = at(1, 0);
  const fm10 = at(-1, 0);
  const f01 = at(0, 1);
  const f0m1 = at(0, -1);
  const f11 = at(1, 1);
  const b0 = (f10 - fm10) / 2;
  const b1 = (f01 - f0m1) / 2;
  const h00 = f10 + fm10 - 2 * f00;
  const h11 = f01 + f0m1 - 2 * f00;
  const h01 = f11 - f10 - f01 + f00;
  const quadraticAt = (s: number, t: number) =>
    f00 + b0 * s + b1 * t + (h00 * s * s + 2 * h01 * s * t + h11 * t * t) / 2;
  const samples = [f00, f10, fm10, f01, f0m1, f11];
  if (!samples.every(Number.isFinite)) return undefined;
  const scale = Math.max(...samples.map(Math.abs));
  if (!(scale > 0)) return undefined;
  for (const [s, t] of [
    [0.3711, -0.6143],
    [-0.8292, 0.2875],
  ]) {
    const value = at(s, t);
    if (!(Math.abs(value - quadraticAt(s, t)) <= 1e-9 * scale))
      return undefined;
  }
  // Positive definite: the quadratic has one minimum, at `−H⁻¹·b`.
  const det = h00 * h11 - h01 * h01;
  if (!(h00 > 0 && det > 1e-12 * h00 * h11)) return undefined;
  const s = -(h11 * b0 - h01 * b1) / det;
  const t = -(h00 * b1 - h01 * b0) / det;
  if (!(Math.abs(quadraticAt(s, t)) <= 1e-9 * scale)) return undefined;

  // The exact point, and a check that it is in the box.
  const point: Expression[] = [];
  for (const [i, value] of [
    center[0] + half[0] * s,
    center[1] + half[1] * t,
  ].entries()) {
    const r = rationalize(value, 1e-10 * Math.max(1, Math.abs(value), half[i]));
    const exact = ce.number(r);
    const [lo, hi] = box[i];
    const v = exact.re;
    if (!(v >= Math.min(lo, hi) && v <= Math.max(lo, hi))) return undefined;
    point.push(exact);
  }
  const exactAt = (dx: number, dy: number): Expression =>
    base
      .subs({
        [x]: ce.function('Add', [point[0], ce.number(dx)]),
        [y]: ce.function('Add', [point[1], ce.number(dy)]),
      })
      .evaluate();
  // `isSame`, not `is`: `is(0)` accepts a value within the tolerance of the
  // engine, such as `10⁻¹²`, and a divisor `r² + 10⁻¹²` must not be replaced
  // by `r²`.
  if (!exactAt(0, 0).isSame(ce.Zero)) return undefined;

  // The second derivatives of `base`, from its values at the point moved by
  // 1 in each variable, if `base` is the quadratic form (checked below).
  const vx = exactAt(1, 0);
  const vy = exactAt(0, 1);
  const hxx = ce.function('Add', [vx, exactAt(-1, 0)]).evaluate();
  const hyy = ce.function('Add', [vy, exactAt(0, -1)]).evaluate();
  const hxy = ce
    .function('Subtract', [exactAt(1, 1), ce.function('Add', [vx, vy])])
    .evaluate();
  if (![hxx, hyy, hxy].every((h) => isNumber(h) && Number.isFinite(h.re)))
    return undefined;
  const quadratic = ce.function('Add', [
    ce.function('Multiply', [
      ce.Half,
      hxx,
      ce.function('Power', [ce.symbol(x), ce.number(2)]),
    ]),
    ce.function('Multiply', [hxy, ce.symbol(x), ce.symbol(y)]),
    ce.function('Multiply', [
      ce.Half,
      hyy,
      ce.function('Power', [ce.symbol(y), ce.number(2)]),
    ]),
  ]);
  // A proof that `base` at the point plus `u` is the quadratic form, for
  // every `u`. The difference of the two is a polynomial of degree 2 or less
  // in each variable, since `base` is one (checked at the start). Such a
  // polynomial is zero when it is zero at the nine points of the grid
  // `{−1, 0, 1}²`. The floating-point checks above do not prove this: in a
  // box of width 10⁻⁵, the term `(x − a)²·(y − a)²` of
  // `(x − a)² + (y − a)² + (x − a)²·(y − a)²` is below their tolerance, but
  // it changes `hxy` from 0 to 1.
  for (const dx of [-1, 0, 1]) {
    for (const dy of [-1, 0, 1]) {
      const difference = ce
        .function('Subtract', [
          exactAt(dx, dy),
          quadratic.subs({ [x]: ce.number(dx), [y]: ce.number(dy) }),
        ])
        .evaluate();
      if (!difference.isSame(ce.Zero)) return undefined;
    }
  }
  return { point: [point[0], point[1]], quadratic };
}

/**
 * The largest number of singular points at which
 * `integrateAroundSingularPoint` cuts a box. With `n` points, the box has
 * up to `(n + 1)²` parts, plus three for each part cut again at its center.
 */
const MAX_SINGULAR_POINTS = 4;

/**
 * The double integral of `body` over the box `box` (the bounds of the two
 * variables `vars`, in either order), computed as the sum of the integrals
 * over the parts of the box around its singular points, or `undefined` when
 * the integrand has no such point in the box or a part has no result.
 *
 * A singular point is the zero of a positive definite quadratic divisor,
 * such as `1/√((x − a)² + (y − b)²)` at `(a, b)` (see `quadraticZeroPoint`).
 * The integral of `r^(−p)` near such a point is finite when `p < 2`, but the
 * nested quadrature of `nIntegrateMultiple` fails on it: the inner integral
 * on the line through the point diverges, and next to the point the inner
 * integrand has a peak that is too narrow to resolve.
 *
 * Thus the box is cut at each coordinate of each singular point, so that
 * each singular point is a corner of each part that touches it. A part
 * whose corners hold two or more singular points (two points on a diagonal,
 * or on one line) is cut again at its center: each of its four quarters then
 * has at most one singular point, at a corner. For the singular points
 * `(1/4, 1/4)` and `(1/2, 1/2)` of the unit square, the cuts are at `1/4` and
 * `1/2` in each variable, and the square `[1/4, 1/2]²` between the two points
 * is cut again at `3/8`.
 *
 * In a part with a singular corner, the variables are shifted so that the
 * corner is at the origin. The shift is made on the expression, with exact
 * coordinates, and the divisor of that point is replaced by its exact
 * quadratic form in the shifted variables: with the shift made on
 * floating-point numbers, `x − 0.3` is exactly zero for each `x` nearer to
 * `0.3` than about `5·10⁻¹⁷`, and the integrand is infinite at the
 * quadrature nodes next to the corner. The other divisors are shifted too,
 * but they are not zero in that part, so their rounding error is small.
 * Two divisors that are zero at the same point give `undefined`: the one
 * that is not replaced would keep the rounding error at the corner.
 *
 * Each part is integrated by `nIntegrateMultiple`. The result is the sum of
 * the estimates and of the errors of the parts; an infinite part gives its
 * infinity, two infinities of different signs or a `NaN` part give `NaN`. A
 * part that has no result, or that has a complex value, gives `undefined`,
 * and the caller then integrates the whole box as before. More than
 * `MAX_SINGULAR_POINTS` singular points also give `undefined`, since the
 * number of parts grows as the square of the number of points.
 */
function integrateAroundSingularPoint(
  ce: ComputeEngine,
  body: Expression,
  vars: readonly [string, string],
  box: readonly [readonly [number, number], readonly [number, number]]
): Expression | undefined {
  if (!box.every(([lo, hi]) => Number.isFinite(lo) && Number.isFinite(hi)))
    return undefined;
  const bases = singularBases(body);
  if (bases === undefined) return undefined;
  type SingularPoint = NonNullable<ReturnType<typeof quadraticZeroPoint>> & {
    base: Expression;
    coordinates: [number, number];
  };
  const points: SingularPoint[] = [];
  const seen: Expression[] = [];
  for (const candidate of bases) {
    if (!candidate.has(vars[0]) || !candidate.has(vars[1])) continue;
    if (seen.some((b) => candidate.isSame(b))) continue;
    seen.push(candidate);
    const zero = quadraticZeroPoint(ce, candidate, vars, box);
    if (zero === undefined) continue;
    // A second divisor that is zero at the same point would keep the
    // rounding error of the shift, since only one divisor is replaced by its
    // exact form.
    if (points.some((p) => p.point.every((c, i) => c.isSame(zero.point[i]))))
      return undefined;
    if (points.length === MAX_SINGULAR_POINTS) return undefined;
    points.push({
      ...zero,
      base: candidate,
      coordinates: [zero.point[0].re, zero.point[1].re],
    });
  }
  if (points.length === 0) return undefined;

  // The cuts of each dimension, in the order of its bounds: the lower bound,
  // the coordinates of the points strictly between the bounds, and the upper
  // bound.
  const cuts = box.map(([lo, hi], i): number[] => {
    const direction = Math.sign(hi - lo);
    const inside = [...new Set(points.map((p) => p.coordinates[i]))]
      .filter((c) => c !== lo && c !== hi)
      .sort((a, b) => direction * (a - b));
    return [lo, ...inside, hi];
  });
  // The parts of the box, each with the index of the singular point at one
  // of its corners, or -1 when it has none.
  type Part = { x: [number, number]; y: [number, number]; corner: number };
  const parts: Part[] = [];
  const cornersOf = (x: [number, number], y: [number, number]): number[] => {
    const corners: number[] = [];
    for (const [k, { coordinates }] of points.entries())
      if (x.includes(coordinates[0]) && y.includes(coordinates[1]))
        corners.push(k);
    return corners;
  };
  for (let i = 1; i < cuts[0].length; i++) {
    for (let j = 1; j < cuts[1].length; j++) {
      const x: [number, number] = [cuts[0][i - 1], cuts[0][i]];
      const y: [number, number] = [cuts[1][j - 1], cuts[1][j]];
      // A part of zero width, when the two bounds of a dimension are equal,
      // adds 0. It is left out: on the line through a singular point, the
      // inner integral diverges, and the quadrature of the part could give
      // `0·∞`, which is `NaN`.
      if (x[0] === x[1] || y[0] === y[1]) continue;
      const corners = cornersOf(x, y);
      if (corners.length <= 1) {
        parts.push({ x, y, corner: corners[0] ?? -1 });
        continue;
      }
      const xm = (x[0] + x[1]) / 2;
      const ym = (y[0] + y[1]) / 2;
      for (const qx of [
        [x[0], xm],
        [xm, x[1]],
      ] as [number, number][]) {
        for (const qy of [
          [y[0], ym],
          [ym, y[1]],
        ] as [number, number][])
          parts.push({ x: qx, y: qy, corner: cornersOf(qx, qy)[0] ?? -1 });
      }
    }
  }
  // One point, already at the origin and at a corner of the box: the
  // quadrature of the whole box resolves it.
  if (parts.length === 1 && points[0].point.every((p) => p.isSame(ce.Zero)))
    return undefined;

  // The integrand of each part: shifted to the singular point at its
  // corner, or, for a part with no singular corner, not shifted.
  const shiftedFns: Expression[] = [];
  for (const { point, quadratic, base } of points) {
    const shift = Object.fromEntries(
      vars.map((v, i) => [v, ce.function('Add', [ce.symbol(v), point[i]])])
    );
    const shiftedBase = base.subs(shift);
    const shiftedBody = body.subs(shift);
    // The shifted divisor is already the quadratic form when the point is
    // the origin (`x² + y²`): there is nothing to replace, and `replace()`
    // gives `null`. Otherwise the divisor must be gone from the shifted
    // integrand, or the rounding error of the shift stays.
    let replaced: Expression | null = shiftedBody;
    if (!shiftedBase.isSame(quadratic)) {
      replaced = shiftedBody.replace(
        { match: shiftedBase, replace: quadratic },
        { recursive: true }
      );
      if (replaced === null) return undefined;
      let left = false;
      const visit = (e: Expression): void => {
        if (left) return;
        if (e.isSame(shiftedBase)) left = true;
        else if (isFunction(e)) e.ops.forEach(visit);
      };
      visit(replaced);
      if (left) return undefined;
    }
    shiftedFns.push(ce.expr(['Function', replaced, ...vars]));
  }
  const unshiftedFn = ce.expr(['Function', body, ...vars]);

  let estimate = 0;
  let error = 0;
  let infinity = 0;
  let noValue = false;
  for (const part of parts) {
    const fn = part.corner < 0 ? unshiftedFn : shiftedFns[part.corner];
    const [px, py] = part.corner < 0 ? [0, 0] : points[part.corner].coordinates;
    const [a, b] = part.x.map((v) => v - px);
    const [c, d] = part.y.map((v) => v - py);
    const r = nIntegrateMultiple(
      ce,
      fn,
      [
        ce.function('Limits', [ce.symbol(vars[0]), ce.number(a), ce.number(b)]),
        ce.function('Limits', [ce.symbol(vars[1]), ce.number(c), ce.number(d)]),
      ],
      undefined,
      false
    );
    if (r === undefined) return undefined;
    const value = isFunction(r, 'Measurement') ? r.op1 : r;
    if (!isNumber(value) || value.im !== 0) return undefined;
    if (Number.isNaN(value.re)) noValue = true;
    else if (!Number.isFinite(value.re)) {
      const sign = Math.sign(value.re);
      if (infinity !== 0 && infinity !== sign) noValue = true;
      infinity = sign;
    } else {
      estimate += value.re;
      if (isFunction(r, 'Measurement')) error += r.op2.re;
    }
  }
  if (noValue) return ce.NaN;
  if (infinity !== 0)
    return infinity > 0 ? ce.PositiveInfinity : ce.NegativeInfinity;
  return measurementFromParts(ce, { estimate, error });
}

/**
 * The numeric value of a nested double integral, `∫_a^b (∫_c^d f dy) dx`,
 * when its integrand is singular at one or more points of the box (see
 * `integrateAroundSingularPoint`), or `undefined` in every other case.
 *
 * `fnExpr` is the integrand of the outer integral, a `Function` literal of
 * `variable`, and `lower` and `upper` are the bounds of the outer integral.
 * The body of `fnExpr` must be one `Integrate` with one limit, whose bounds
 * are pure and do not depend on either variable. LaTeX gives this form for
 * `\int_0^1\int_0^1 f\,dy\,dx`. The one-limit quadrature of the outer
 * integral evaluates the inner integral at each of its nodes, and it gives
 * `NaN` when the integrand is singular at a point: the inner integral is
 * infinite on the line through the point.
 */
function nestedSingularPointIntegral(
  ce: ComputeEngine,
  fnExpr: Expression,
  variable: string,
  lower: number,
  upper: number
): Expression | undefined {
  if (!isFunction(fnExpr, 'Function')) return undefined;
  const inner = liftIntegrand(fnExpr);
  if (!isFunction(inner, 'Integrate') || inner.nops !== 2) return undefined;
  const limit = inner.op2;
  if (!isFunction(limit, 'Limits')) return undefined;
  const innerVar = sym(limit.op1);
  if (!innerVar || innerVar === 'Nothing' || innerVar === variable)
    return undefined;
  const g = inner.op1;
  if (!isFunction(g, 'Function')) return undefined;
  const params = g.ops.slice(1).map((p) => functionLiteralParameterName(p));
  if (params.length !== 1 || params[0] !== innerVar) return undefined;
  // A bound that is not pure (`Random()`) must be evaluated only once, by
  // the route that integrates.
  const bounds = [limit.op2, limit.op3];
  if (bounds.some((b) => b.has([variable, innerVar]) || !isTransitivelyPure(b)))
    return undefined;
  const [c, d] = bounds.map((b) => b.N().re);
  const names = [variable, innerVar];
  return withValueShield(ce, names, () =>
    integrateAroundSingularPoint(
      ce,
      withAssignedValues(ce, liftIntegrand(g), names),
      [variable, innerVar],
      [
        [lower, upper],
        [c, d],
      ]
    )
  );
}

function nIntegrateMultiple(
  ce: ComputeEngine,
  f: Expression,
  limits: ReadonlyArray<Expression>,
  evaluatedBounds?: ReadonlyArray<ReadonlyArray<Expression>>,
  splitAtSingularPoint = true
): Expression | undefined {
  const vars: string[] = [];
  // The variables of the limits that name no variable and that the integrand
  // has no parameter for. The integrand does not depend on them.
  const constantVars = new Set<string>();
  for (const [d, l] of limits.entries()) {
    if (!isFunction(l)) return undefined;
    let v = sym(l.op1);
    // A limit that names no variable reads it from the parameters of the
    // integrand, as the exact route does (`implicitIntegrationVariable`).
    // When the integrand has no parameter for it, the integrand is constant
    // in that dimension, and the dimension gets a variable that the
    // integrand does not read.
    if (v === 'Nothing') {
      const implicit = implicitIntegrationVariable(f, limits, d);
      if (implicit === null) return undefined;
      v = implicit;
      if (v === undefined) {
        v = unusedVariableName([f, ...limits], constantVars);
        constantVars.add(v);
      }
    }
    if (!v) return undefined;
    vars.push(v);
  }

  // Each bound becomes a function of the OUTER integration values (in limit
  // order). A constant bound ignores them; a dependent one is wrapped in a
  // `Function` of the outer variables — the literal's parameter binding also
  // shields a same-named global assignment, as for the integrand itself.
  type BoundFn = (outer: ReadonlyArray<number>) => number;
  const mkBound = (
    b: Expression,
    d: number,
    value: Expression | undefined
  ): BoundFn | undefined => {
    const syms = b.symbols;
    if (syms.some((s) => vars.indexOf(s) >= d)) return undefined;
    if (syms.some((s) => vars.includes(s))) {
      const fn = ce.expr(['Function', b, ...vars.slice(0, d)]);
      const compiledB = implicitCompile(ce, fn, 'multiple-integral-bound');
      if (compiledB?.success) {
        const run = compiledB.run as (...args: number[]) => number;
        return (outer) => run(...outer);
      }
      const app = applicable(fn);
      return (outer) => app(outer.map((x) => ce.number(x)))?.re ?? NaN;
    }
    const c = (value ?? b.N()).re;
    if (isNaN(c)) return undefined;
    return () => c;
  };

  const boundFns: [BoundFn, BoundFn][] = [];
  for (let d = 0; d < limits.length; d++) {
    const l = limits[d];
    if (!isFunction(l)) return undefined;
    const values = evaluatedBounds?.[d];
    const lower = mkBound(l.op2, d, values?.[0]);
    const upper = mkBound(l.op3, d, values?.[1]);
    if (!lower || !upper) return undefined;
    boundFns.push([lower, upper]);
  }

  const fnExpr =
    f.operator === 'Function' ? f : ce.expr(['Function', f, ...vars]);

  // Map each integration variable to its parameter slot: a user-supplied
  // `Function` may list its parameters in a different order than the limits.
  // A variable with no parameter slot, a duplicated variable, or a spare
  // parameter (which would be left unbound) all decline. The variable of a
  // dimension in which the integrand is constant (`constantVars`) and that
  // is not a parameter gets a slot after the parameters: the integrand is
  // called with that argument too, and does not read it.
  const params = isFunction(fnExpr)
    ? fnExpr.ops.slice(1).map((p) => functionLiteralParameterName(p))
    : [];
  const extraVars = vars.filter(
    (v) => constantVars.has(v) && !params.includes(v)
  );
  const slots = vars.map((v) =>
    params.includes(v)
      ? params.indexOf(v)
      : extraVars.includes(v)
        ? params.length + extraVars.indexOf(v)
        : -1
  );
  if (
    params.length + extraVars.length !== vars.length ||
    slots.some((i) => i < 0) ||
    new Set(slots).size !== slots.length
  )
    return undefined;

  // A pole strictly inside a dimension whose bounds are CONSTANT diverges
  // the whole iterated integral, whatever the other variables do — and the
  // nested quadrature below would report a confident finite `Measurement`
  // for it, exactly as the single-limit path used to. `interiorPoleVerdict`
  // substitutes only the dimension's own variable, so with any other
  // integration variable left in the integrand its samples are not numbers
  // and it answers `undefined` (no claim): only a divergence the integrand
  // exhibits in that variable alone is reported. Two dimensions that each
  // diverge in different directions leave the integral without a value.
  // The values of assigned symbols other than the integration variables are
  // substituted, since the compiled integrand reads them (see
  // `withAssignedValues`).
  const body = withAssignedValues(
    ce,
    isFunction(fnExpr, 'Function') ? fnExpr.op1 : fnExpr,
    vars
  );
  //
  // The verdict of one dimension has the orientation of that dimension's
  // bounds only. Each other dimension with reversed bounds negates the
  // integral again: `∫₂⁰ ∫₀² (y − 1)⁻² dy dx` is `−∞`. A dimension whose
  // bounds depend on another integration variable has no single
  // orientation, so the direction of the divergence is then unknown.
  const dependsOnVars = (e: Expression) =>
    e.symbols.some((name) => vars.includes(name));
  const orientations = limits.map((l, d): number | undefined => {
    if (!isFunction(l) || dependsOnVars(l.op2) || dependsOnVars(l.op3))
      return undefined;
    return Math.sign(boundFns[d][1]([]) - boundFns[d][0]([]));
  });
  // The value of the integral from the verdicts of `check` for each
  // dimension, or `undefined` when no dimension has a verdict.
  // `interiorPoleVerdict` is checked before the quadrature;
  // `endpointPoleVerdict` (a pole AT a bound) only after the quadrature found
  // a divergence, since it cannot tell an integrable singularity of order
  // close to 1 from a pole.
  const poleValue = (
    check: typeof interiorPoleVerdict
  ): Expression | undefined => {
    let verdict: PoleVerdict | undefined;
    for (let d = 0; d < vars.length; d++) {
      const l = limits[d];
      if (!isFunction(l)) continue;
      if (orientations[d] === undefined) continue;
      let v = check(body, vars[d], l.op2, l.op3, ce);
      if (v === undefined) continue;
      if (v.sign === 'positive' || v.sign === 'negative') {
        let flip = 1;
        for (let e = 0; e < vars.length; e++) {
          if (e === d) continue;
          const o = orientations[e];
          // A dimension of zero length: the integral is over a set of zero
          // measure, as for structurally equal bounds, which give 0.
          if (o === 0) return ce.Zero;
          if (o === undefined || Number.isNaN(o)) flip = 0;
          else flip *= o;
        }
        if (flip === 0) v = { sign: 'unknown' };
        else if (flip === -1)
          v = { sign: v.sign === 'positive' ? 'negative' : 'positive' };
      }
      verdict =
        verdict === undefined || verdict.sign === v.sign
          ? v
          : { sign: 'mixed' };
    }
    if (verdict === undefined) return undefined;
    return verdict.sign === 'positive'
      ? ce.PositiveInfinity
      : verdict.sign === 'negative'
        ? ce.NegativeInfinity
        : ce.NaN;
  };
  const interior = poleValue(interiorPoleVerdict);
  if (interior !== undefined) return interior;

  // A double integral over a box whose integrand is singular at one or more
  // points, such as `((x − a)² + (y − b)²)^(−1/2)` at `(a, b)`: the box is
  // cut at the points and each part is integrated with at most one point,
  // at a corner (see
  // `integrateAroundSingularPoint`). The parts are integrated with this
  // function, with `splitAtSingularPoint` false, so that they are not cut
  // again.
  if (
    splitAtSingularPoint &&
    vars.length === 2 &&
    constantVars.size === 0 &&
    orientations.every((o) => o === 1 || o === -1)
  ) {
    const box = boundFns.map(
      ([lower, upper]) => [lower([]), upper([])] as const
    );
    const split = integrateAroundSingularPoint(
      ce,
      body,
      [vars[0], vars[1]],
      [box[0], box[1]]
    );
    if (split !== undefined) return split;
  }

  // A pole whose location depends on another integration variable:
  // `∫₀¹⁰ ∫₃⁴ (y − x)⁻² dx dy` has, for each `y` in `(3, 4)`, a pole at
  // `x = y`. `poleValue` cannot see it, because the samples of the integrand
  // in one variable are not numbers while the other variables are free. Here
  // the other variables are given the values of a grid of points of their
  // ranges (the centers of 32 equal cells for two dimensions, of 8 × 8 for
  // three), and the interior-pole check runs on the remaining variable at
  // each point. The scan runs only when every bound is constant and there are
  // at most three dimensions, which keeps its cost bounded; it is cheap when
  // the integrand has no denominator, since there is then no candidate site
  // to sample.
  //
  // The result is the number of points with a proven pole that is also at a
  // second point of their cell (see below), and the sign of all the points
  // with a proven pole, with the orientation of the other dimensions:
  // `mixed` when two points
  // disagree, or when the integrand changes sign across the pole at one
  // point (the inner integral then has no value).
  //
  // A dimension with an infinite bound is handled in two ways. As one of the
  // other variables, its grid is placed on `[0, 1)` and mapped onto the
  // range by the transform of the quadrature, `lo + s/(1 − s)` (see
  // `scanPoint`): for `Limits(y, 0, +∞)` the points go from `y = 0.016` to
  // `y = 63`. As the variable checked for a pole, its range is cut to a
  // finite one (see `finiteScanRange`): a pole proven inside the cut range
  // is inside the whole range, with the same orientation.
  const dependentPoleScan = ():
    { proven: number; sign: 'positive' | 'negative' | 'mixed' } | undefined => {
    if (vars.length < 2 || vars.length > 3) return undefined;
    if (orientations.some((o) => o === undefined || o === 0 || Number.isNaN(o)))
      return undefined;
    const perDimension = vars.length === 2 ? 32 : 8;
    let sign: 'positive' | 'negative' | 'mixed' | undefined;
    let proven = 0;
    for (let d = 0; d < vars.length; d++) {
      const l = limits[d];
      if (!isFunction(l)) continue;
      const others = vars.map((_, e) => e).filter((e) => e !== d);
      if (!others.some((e) => body.has(vars[e]))) continue;
      const flip = others.reduce((product, e) => product * orientations[e]!, 1);
      const count = perDimension ** others.length;
      const [lower, upper] = finiteScanRange(
        boundFns[d][0]([]),
        boundFns[d][1]([])
      );
      // The values of the other variables at the grid point `k`, moved by
      // `shifts[j]` (a fraction of a cell) from the center of the cell in
      // the `j`-th other dimension.
      const pointValues = (
        k: number,
        shifts: readonly number[]
      ): Record<string, Expression> => {
        const values: Record<string, Expression> = {};
        let rest = k;
        others.forEach((e, j) => {
          const i = rest % perDimension;
          rest = Math.floor(rest / perDimension);
          values[vars[e]] = ce.number(
            scanPoint(
              boundFns[e][0]([]),
              boundFns[e][1]([]),
              (i + 0.5 + shifts[j]) / perDimension
            )
          );
        });
        return values;
      };
      for (let k = 0; k < count; k++) {
        const v = interiorPoleVerdict(
          body.subs(pointValues(k, [0, 0])),
          vars[d],
          lower,
          upper,
          ce
        );
        if (v === undefined) continue;
        // A pole at the center of a cell may be a pole only on a set of zero
        // measure that passes through that point:
        // `((x − 1/64)² + (y − 1/64)²)^(−3/4)` has its only singular point
        // at the center of the first cell of each dimension, and its double
        // integral is finite. Such a point is counted only when the pole is
        // also at a second point of the same cell, which a singular set of
        // zero measure does not reach. The second point is moved by a
        // different fraction in each dimension: moved by the same fraction,
        // it stays on a diagonal singular set such as `y = z`, and
        // `((x − ½)² + (y − z)²)^(−3/4)`, whose triple integral is finite,
        // was reported divergent.
        const moved = interiorPoleVerdict(
          body.subs(pointValues(k, [0.3183, 0.2071])),
          vars[d],
          lower,
          upper,
          ce
        );
        if (moved !== undefined) proven += 1;
        const oriented =
          v.sign !== 'positive' && v.sign !== 'negative'
            ? 'mixed'
            : flip > 0
              ? v.sign
              : v.sign === 'positive'
                ? 'negative'
                : 'positive';
        sign = sign === undefined || sign === oriented ? oriented : 'mixed';
      }
    }
    if (sign === undefined) return undefined;
    return { proven, sign };
  };
  const dependentPoles = dependentPoleScan();
  // Two or more points with a proven pole (each also at a second point of
  // its cell) are taken as a set of positive measure of the other variables
  // on which the inner integral diverges, so the integral diverges with
  // their common sign, or has no value when the signs differ. A single
  // point, or poles only at the centers of cells, may be a coincidence of
  // the grid (a pole only on a set of zero measure): they are used only when
  // the quadrature does not converge (see below).
  if (dependentPoles !== undefined && dependentPoles.proven >= 2)
    return dependentPoles.sign === 'positive'
      ? ce.PositiveInfinity
      : dependentPoles.sign === 'negative'
        ? ce.NegativeInfinity
        : ce.NaN;

  const compiled = implicitCompile(ce, fnExpr, 'multiple-integral');
  let raw: (...args: number[]) => unknown;
  if (compiled?.success)
    raw = withLogSpaceFallback(
      ce,
      fnExpr,
      compiled.run as (...args: number[]) => unknown
    );
  else {
    const app = applicable(fnExpr);
    // Only the arguments of the parameters are passed: the arguments after
    // them are the variables of the dimensions in which the integrand is
    // constant.
    raw = (...args: number[]) =>
      app(args.slice(0, params.length).map((x) => ce.number(x)));
  }
  const integrand = numericIntegrandParts(raw);
  // The part being integrated: the real part first, then — only when a
  // sample showed a non-zero imaginary part — the imaginary part.
  let jsf: (...args: number[]) => number = integrand.re;

  // Nested adaptive Gauss–Kronrod, one level per limit; a level that fails to
  // converge falls back to 1-D Monte Carlo (as the single-limit path does).
  // `argv` (integrand arguments, by parameter slot) and `outerVals` (current
  // integration values, in limit order, consumed by dependent bounds) are
  // shared across levels — the recursion is strictly sequential.
  const argv = new Array<number>(vars.length).fill(NaN);
  const outerVals = new Array<number>(vars.length).fill(NaN);
  const last = limits.length - 1;

  // ONE sub-stream for the whole iterated integral, allocated here rather than
  // per level: a level allocating its own would make the number of sub-streams
  // depend on the integrand's dimension, and the inner levels re-run once per
  // outer quadrature node — so per-level allocation would also make the tag
  // depend on how many nodes the outer level happened to use.
  const draw = ce._substream(mixTags(f.hash, ...limits.map((l) => l.hash)));
  // The number of Monte Carlo estimates that are running now. While one runs,
  // the integrand is read at points that come from random draws: the points
  // of that level, and the quadrature nodes of the inner levels, which move
  // with each random outer value. The second pass (the imaginary part) does
  // not visit these points again, because it continues the same stream and
  // gets new draws. So a cache lookup of such a point can only miss, and the
  // points would also fill the bounded cache, after which the quadrature
  // nodes of the first pass are no longer kept for the second pass. Read the
  // integrand without the cache while this count is not zero.
  let sampling = 0;
  // Whether a level found that its integral diverges (see `integrateDim`).
  let divergent = false;
  // Whether a level did not converge and kept its quadrature result or fell
  // back to Monte Carlo (see `integrateDim`).
  let unconverged = false;
  // When the grid scan found a pole (`dependentPoles`), the first pass ends
  // in `NaN` as soon as a level diverges or does not converge, unless the
  // check for a pole at a bound gives a value (see the end of this
  // function). That check reads only the integrand and the limits, so it is
  // made when the first level fails, and if it gives no value the
  // quadrature stops there: the rest of the work cannot change the result.
  // For `((x − 1/64)² + (y − 1/64)²)^(−1/2)` on the unit square, the first
  // inner level diverged after about 2·10⁴ evaluations of the integrand, and
  // the nested quadrature then ran to 1.7·10⁸ evaluations (about 60 s)
  // before it returned `NaN`. The second pass (the imaginary part) is never
  // stopped: a failure there does not give `NaN` (see the end).
  let stopOnFailure = dependentPoles !== undefined;
  // Whether the first pass (the real part) runs. A level that is
  // `undecided` stops it (see `integrateDim`).
  let firstPass = true;
  const firstPassStopped = Symbol('first pass stopped');
  let endpointValue: Expression | undefined | null = null;
  const levelFailed = () => {
    if (!stopOnFailure) return;
    endpointValue ??= poleValue(endpointPoleVerdict);
    if (endpointValue === undefined) throw firstPassStopped;
  };
  const integrateDim = (dim: number): { estimate: number; error: number } => {
    // Inner-level error accumulated over this level-invocation's quadrature
    // nodes (the recursion is strictly sequential, so plain locals suffice).
    let innerErrSum = 0;
    let innerErrN = 0;
    // The sum of the magnitudes of the inner estimates at the same nodes, and
    // whether they took both signs (see `inflate`).
    let innerAbsSum = 0;
    let innerPositive = false;
    let innerNegative = false;
    const g = (t: number): number => {
      argv[slots[dim]] = t;
      outerVals[dim] = t;
      if (dim === last)
        return sampling > 0 ? integrand.uncached(jsf)(...argv) : jsf(...argv);
      const r = integrateDim(dim + 1);
      if (Number.isFinite(r.error) && Number.isFinite(r.estimate)) {
        innerErrSum += r.error;
        innerErrN++;
        innerAbsSum += Math.abs(r.estimate);
        if (r.estimate > 0) innerPositive = true;
        if (r.estimate < 0) innerNegative = true;
      }
      return r.estimate;
    };
    const outer = outerVals.slice(0, dim);
    const lower = boundFns[dim][0](outer);
    const upper = boundFns[dim][1](outer);
    if (isNaN(lower) || isNaN(upper)) return { estimate: NaN, error: NaN };
    // This level's own estimator sees a node-VARYING inner error as integrand
    // noise, but a node-INDEPENDENT one is invisible to it: the same biased
    // inner value returns at every node, the integrand looks perfectly smooth
    // and the reported error collapses to ~0 while the true error is the inner
    // bound times this level's range. Add that systematic component explicitly.
    // Each level inflates before returning to its caller, so it compounds.
    //
    // The added term estimates the integral of the inner error over this
    // level's range. When the inner estimates keep one sign, it is the ratio
    // of the summed inner errors to the summed inner magnitudes, times the
    // magnitude of this level's estimate (which is then the integral of the
    // magnitudes). The ratio does not depend on where the nodes are: the
    // nodes of a level with a singularity at a bound (`∫₀¹ ∫₀² y^(−0.999) dx
    // dy`) are packed next to it, where the inner values and errors are
    // huge, and a plain mean of the errors over the nodes then multiplied by
    // the range gave an error of 10²⁸⁹ for an integral of 2000. When the
    // inner estimates take both signs, their magnitudes are not the
    // integral, and the term is the mean inner error times the range. That
    // range factor is only meaningful on a finite interval: over an infinite
    // one it is vacuous (∞ · any inner bound), and would report ±∞ on an
    // otherwise good answer, so such a level propagates nothing extra.
    const span = Math.abs(upper - lower);
    const inflate = (r: {
      estimate: number;
      error: number;
    }): { estimate: number; error: number } => {
      let extra = 0;
      if (innerErrN > 0) {
        if (!(innerPositive && innerNegative) && innerAbsSum > 0) {
          if (Number.isFinite(r.estimate))
            extra = (innerErrSum / innerAbsSum) * Math.abs(r.estimate);
        } else if (Number.isFinite(span))
          extra = (innerErrSum / innerErrN) * span;
      }
      return { estimate: r.estimate, error: r.error + extra };
    };
    // The starting-panel floor multiplies across levels — one full quadrature
    // runs per outer node — so a per-level 16 would cost 16^dimensions. Reduce
    // it so the floor applies to the whole iterated integral, not each level.
    const gk = adaptiveQuadrature(g, lower, upper, {
      initialPanels: initialPanelsForDimensions(limits.length),
      // Every level of an iterated integral checks the span deadline (per
      // panel) and throws the timeout when it expires: one full inner
      // quadrature runs per outer node, so an unchecked level made the whole
      // nest unboundable by any JS-side budget.
      deadline: ce._deadlineFrame,
      // A level with a slowly integrable singularity at a bound is resolved
      // by extrapolating its endpoint shells, as for a one-limit integral
      // (`integrateRealPart`): an accepted extrapolation is a result.
      singularEndpoints: true,
    });
    if (
      (gk.converged || gk.extrapolated === true) &&
      Number.isFinite(gk.estimate)
    )
      return inflate(gk);
    // A level diagnosed as divergent has no finite value: propagate NaN rather
    // than sample it, which would only launder the divergence into a
    // plausible-looking number (and make every outer node pay for it).
    // A level that oscillates without a value has no sign (see
    // `integrateRealPart`): it is not marked `divergent`, so no pole sign is
    // looked for. Neither is a level whose quadrature could not tell a
    // divergence from a convergence (`undecided`, see `integrateRealPart`):
    // `∫₀¹ ∫₀^½ dt/(t·(−ln t)^1.001) dx = 1000.37` was `+∞`. Such a level
    // gives the whole integral no value: the integral over that slice may be
    // infinite. So the first pass stops at once, and the result is `NaN`.
    // Each such level used its whole panel budget, and without the stop the
    // outer levels computed it again at each of their nodes: 6.3 s for that
    // integral. The second pass (the imaginary part) is not stopped (see
    // `stopOnFailure`).
    if (gk.divergent && gk.undecided === true) {
      if (firstPass) throw firstPassStopped;
      return { estimate: NaN, error: NaN };
    }
    if (gk.divergent) {
      if (gk.oscillates !== true) {
        divergent = true;
        levelFailed();
      }
      return { estimate: NaN, error: NaN };
    }
    // The integrand of this level is `NaN` on a set that is not some isolated
    // points: the level has no value, and sampling it would also give `NaN`
    // (see `integrateRealPart`).
    if (gk.nanRegion === true) return { estimate: NaN, error: NaN };
    // A stalled level whose error bound already beats the sampler keeps its
    // quadrature result: sampling it would be both less accurate and, since
    // every inner level re-runs per outer node, far more expensive.
    unconverged = true;
    levelFailed();
    // Its error estimate can be far too small (see `integrateRealPart`), so
    // the error is at least the standard error of the Monte-Carlo estimate it
    // replaces, `|estimate|/√1e4`.
    // So does a level next to a singular corner that the quadrature could
    // not resolve (`singularCorner`, see `integrateRealPart`).
    if (
      (gk.singularCorner === true && Number.isFinite(gk.estimate)) ||
      quadratureBeatsMonteCarlo(gk, 1e4)
    )
      return inflate({
        estimate: gk.estimate,
        error: Math.max(gk.error, Math.abs(gk.estimate) / Math.sqrt(1e4)),
      });
    sampling++;
    try {
      return inflate(
        monteCarloEstimate(g, lower, upper, 1e4, ce._deadlineFrame, draw)
      );
    } finally {
      sampling--;
    }
  };

  // The reported uncertainty is the outermost level's error estimate, inflated
  // by the propagated inner-level error (see `inflate` above).
  let r: { estimate: number; error: number };
  try {
    r = integrateDim(0);
  } catch (err) {
    if (err === firstPassStopped) return ce.NaN;
    throw err;
  } finally {
    stopOnFailure = false;
    firstPass = false;
  }
  // A level found a divergence: a pole AT a bound of a dimension gives its
  // sign (`∫₀² ∫₀¹ t⁻² dt dx` is `+∞`).
  if (divergent && Number.isNaN(r.estimate)) {
    // Made already when a level failed with a pole found by the scan.
    const endpoint = endpointValue ?? poleValue(endpointPoleVerdict);
    if (endpoint !== undefined) return endpoint;
  }
  // A level did not converge or diverged, and one point of the grid of
  // `dependentPoleScan` has a proven pole: the integral may diverge, and the
  // quadrature result is not a value for it.
  if ((divergent || unconverged) && dependentPoles !== undefined) return ce.NaN;
  if (Number.isNaN(r.estimate) && !integrand.sawNumeric())
    return integrand.sawOnlyUndefinedValues() ? ce.NaN : undefined;
  if (!integrand.sawImaginary()) return measurementFromParts(ce, r);
  jsf = integrand.im;
  return measurementFromParts(ce, r, integrateDim(0));
}

/**
 * The free symbols of `expr`, INCLUDING those reachable only through the
 * bodies of the user-defined functions it calls.
 *
 * `expr.unknowns` is a SURFACE property: for `n(x)` where `n = x ↦ q + x` it
 * reports nothing, because `q` occurs in `n`'s body, not in the integrand as
 * written. The numeric integration path still needs a value for `q`, so the
 * surface set is the wrong question to ask before numericizing (Tycho item
 * 131: the compiled body emitted a `_.q` vars-object lookup that has no `_`
 * in scope, and the raw `ReferenceError` escaped out of `.N()`).
 *
 * **A name means something different on each side of a definition boundary**,
 * so `bound` is never carried across one. `bound` — the caller's binders, an
 * integration variable — applies to the SURFACE expression only. Crossing into
 * a user function's body re-establishes it from that callee's OWN parameter
 * names; crossing into an assigned value clears it entirely (a value has no
 * parameters, and its free variables answer to the scope it was assigned in).
 *
 * Filtering the flattened result by the caller's binders instead would discard
 * a callee's capture that merely SHARES a binder's spelling: for
 * `n = t ↦ x + t` with `x` unassigned, `∫ n(x) dx` would drop `n`'s free `x`
 * as if it were the integration variable, numericize, and return `NaN` where
 * the honest answer is symbolic.
 *
 * `seen` (shared across the whole walk, keyed on the definition) terminates
 * recursive definitions and self-referential bindings.
 *
 * The absence symbols `Missing` and `Nothing` are not reported: `unknowns`
 * lists them, as they have no value, but they are values here, not free
 * variables waiting for one. Arithmetic with `Missing` is `Missing`, an
 * integrand value with no number, so `∫₀¹ t·Missing dt` is `NaN` under
 * `.N()`, as an integrand with no value is (`sawOnlyUndefinedValues`).
 */
function transitiveUnknowns(
  expr: Expression,
  bound: ReadonlySet<string>
): string[] {
  const out = new Set<string>();
  const seen = new Set<object>();
  const collect = (root: Expression, names: ReadonlySet<string>): void => {
    for (const s of root.unknowns)
      if (!names.has(s) && s !== 'Missing' && s !== 'Nothing') out.add(s);
    const visit = (node: Expression): void => {
      // An ASSIGNED value can itself hold a free symbol (`c` in `b = c + 1`):
      // `b` is known, so neither `unknowns` nor the compiler's fold reports
      // `c`, yet the folded code still references it.
      if (isSymbol(node)) {
        const valueDef = node.valueDefinition;
        const value = valueDef?.value;
        if (value !== undefined && !seen.has(valueDef as object)) {
          seen.add(valueDef as object);
          collect(value, NO_BOUND_NAMES);
        }
        return;
      }
      if (!isFunction(node)) return;
      const opDef = node.operatorDefinition;
      const lambda = opDef?.lambda;
      if (lambda !== undefined && !seen.has(opDef as object)) {
        seen.add(opDef as object);
        collect(lambda.body, new Set(lambda.parameters.map((p) => p.name)));
      }
      for (const op of node.ops) visit(op);
    };
    visit(root);
  };
  collect(expr, bound);
  return [...out];
}

/** No names are bound: used at a definition boundary that binds none. */
const NO_BOUND_NAMES: ReadonlySet<string> = new Set<string>();

/**
 * `body` with each of the `variables` that a called user function captures
 * renamed to a fresh name, or `undefined` when no variable is captured.
 *
 * `body` is the integrand of an `Integrate` or the body of a `Limit`, lifted
 * out of its function literal (`liftIntegrand()`), and `variables` are the
 * names that the operator binds. A variable is captured when the body of a
 * user function called in `body` reads a free symbol with the same name
 * (`namesReadByCalledFunctions()`). These operators inline the body of the
 * called function and then select the variable by its name, so the symbol
 * of the body became the variable. With `k := 2` and `g := a ↦ a·k·x`,
 * `∫₀¹ g(k) dk` was `x/3` and `lim_{k→1} g(k)` was `x`. A variable never
 * reads a symbol inside a called function, whether or not the symbol has a
 * value (`docs/SCOPING-MODEL.md`, decision of 2026-09-21), so the answers
 * are those of `∫₀¹ g(t) dt` and `lim_{t→1} g(t)`: `x` and `2x`. In the
 * renamed body, `g(k_1)`, the variable and the symbol of `g` have different
 * names.
 *
 * The fresh name is not a name of `body` or of `operands` (all the operands
 * of the operator: the bounds of the integral, the point and the direction
 * of the limit), nor a name that a called function reads, so the renamed
 * body captures nothing and a bound that names a symbol `k_1` keeps that
 * symbol. It is also not a name that is declared in a scope that is visible
 * here, with or without a value: a fresh name that is the name of a symbol
 * of the user would merge the variable with that symbol in a result that
 * keeps the fresh name. An occurrence of a variable that a binder inside
 * `body` binds again keeps its name.
 *
 * Each fresh variable is declared in `scope`, with the type of the variable
 * that it replaces (read from `bindings`, the bindings of the operator or of
 * its function literal), and the renamed occurrences are the binding
 * symbols of this scope. The caller builds the renamed operator on `scope`,
 * from boxed operands, so that every other symbol keeps its binding.
 */
function renameCapturedVariables(
  ce: ComputeEngine,
  body: Expression,
  variables: ReadonlyArray<string>,
  operands: ReadonlyArray<Expression>,
  bindings: ReadonlyMap<string, BoxedValueDefinition | null> | undefined,
  scope: Scope
):
  | {
      body: Expression;
      renamed: ReadonlyMap<string, string>;
      fresh: ReadonlyMap<string, Expression>;
    }
  | undefined {
  // A body that `liftIntegrand()` could not lift is still a function literal,
  // which binds the variables itself: its occurrences cannot be renamed here.
  if (isFunction(body, 'Function')) return undefined;
  const read = namesReadByCalledFunctions(body);
  const captured = variables.filter((v) => read.has(v));
  if (captured.length === 0) return undefined;
  const used = new Set<string>([
    ...read,
    ...variables,
    ...body.symbols,
    ...collectBinderNames(body),
  ]);
  for (const op of operands) {
    for (const name of op.symbols) used.add(name);
    for (const name of collectBinderNames(op)) used.add(name);
  }
  const renamed = new Map<string, string>();
  const fresh = new Map<string, Expression>();
  for (const name of captured) {
    let i = 1;
    while (
      used.has(`${name}_${i}`) ||
      ce.lookupDefinition(`${name}_${i}`) !== undefined
    )
      i += 1;
    const id = `${name}_${i}`;
    used.add(id);
    const binding = bindings?.get(name) ?? undefined;
    ce._inScope(scope, () =>
      ce.declare(id, {
        type: binding?.type ?? 'unknown',
        inferred: binding?.inferredType ?? true,
      })
    );
    const symbol = ce._bindingSymbol(id, scope);
    if (symbol === undefined) return undefined;
    renamed.set(name, id);
    fresh.set(name, symbol);
  }
  return {
    body: rewriteWithBinders(body, (s, shadowed) =>
      fresh.has(s.symbol) && !shadowed?.has(s.symbol) ? fresh.get(s.symbol)! : s
    ),
    renamed,
    fresh,
  };
}

/**
 * The block of several statements that is the body of the integrand `f`, or
 * `undefined`. The value of such a block is not the value of its first
 * statement, so `liftIntegrand()` does not lift it.
 */
function severalStatementsBody(f: Expression): Expression | undefined {
  const body = isFunction(f, 'Function') ? f.op1 : f;
  return isFunction(body, 'Block') && body.nops > 1 ? body : undefined;
}

/**
 * The value of `block`, the body of the integrand `f`, as one expression bound
 * in the scope of the caller, as `liftIntegrand()` gives for a block of one
 * statement. The value of `Block(c := 2, c·x)` is `2x`.
 *
 * Return `undefined` when `block` is not a sequence of local assignments
 * followed by a value (`blockValue()`), or when the parameters of `f` are not
 * the variables of `limits`, in order: the value would no longer say which of
 * its symbols the limit binds.
 */
function blockIntegrandValue(
  f: Expression,
  block: Expression,
  limits: ReadonlyArray<Expression>
): Expression | undefined {
  const variables = limits.map((l) => (isFunction(l) ? sym(l.op1) : undefined));
  const parameters = isFunction(f, 'Function')
    ? f.ops.slice(1).map((p) => functionLiteralParameterName(p))
    : variables;
  if (
    parameters.length !== variables.length ||
    parameters.some((p, i) => !p || p === 'Nothing' || p !== variables[i])
  )
    return undefined;
  const value = blockValue(f.engine, block, undefined, parameters as string[]);
  if (value === undefined || !block.localScope) return value;
  return rebindEscaping(value, block.localScope);
}

/**
 * Find the calls in `expr` of a user function that has the name of a library
 * function (`Sin`, `Exp`, `Ln`, …): a call that is not bound to the library
 * operator (`shadowsLibraryOperator()`). The test reads the definition of
 * the call, so it is correct for a call made in another scope than the
 * current one. Inside a function literal, its parameters with a library name
 * are local names, and inside an expression with a local scope (a function
 * body, a block), the library names that the bindings of this scope shadow
 * are local names (`libraryNamesShadowedIn()`).
 *
 * A call bound to the library operator, of a name that a call head built in
 * the current scope reads as a user function (a library `Sin(x)` boxed
 * before a user `Sin` was declared; `libraryRuleBlocked()`, which skips a
 * user value such as `Gamma := 1.4` because a call head does), is also a
 * call of a local name. The library rules build their result by name
 * in the current scope, so the result would be bound to the user function.
 * The body of the user function cannot replace the call either: the call is
 * not a call of it.
 *
 * Return `'local'` when a call is of a local name, `'call'` when the calls
 * are all of user functions of the scope chain, and `'none'` when there is
 * no such call. For `'local'`, a contour integral stays unevaluated, and an
 * `Integrate` stays unevaluated under `evaluate()`.
 */
function shadowedCallsIn(
  ce: ComputeEngine,
  expr: Expression
): 'none' | 'call' | 'local' {
  const system = ce.contextStack[0]?.lexicalScope;
  let result: 'none' | 'call' | 'local' = 'none';
  const scan = (x: Expression, local: ReadonlySet<string>): void => {
    if (result === 'local' || !isFunction(x)) return;
    if (isOperatorDef(system?.bindings.get(x.operator))) {
      if (local.has(x.operator)) result = 'local';
      else if (shadowsLibraryOperator(x)) result = 'call';
      else if (libraryRuleBlocked(x, isApplicableDef)) result = 'local';
    }
    let inner = local;
    const add = (name: string) => {
      if (inner.has(name) || system?.bindings.get(name) === undefined) return;
      inner = new Set([...inner, name]);
    };
    // Every name a parameter binds, read through its wrappers (`Typed`,
    // `Optional`, a destructuring pattern).
    if (x.operator === 'Function')
      for (const p of x.ops.slice(1))
        for (const name of functionLiteralParameterNames(p)) add(name);
    if (x.localScope !== undefined)
      for (const name of libraryNamesShadowedIn(ce, x.localScope)) add(name);
    for (const op of x.ops) scan(op, inner);
  };
  scan(expr, NO_BOUND_NAMES);
  return result;
}

/**
 * The integrand `integrand` of an `Integrate` (a lifted integrand, see
 * `liftIntegrand()`), with each call of a user function that has the name
 * of a library function replaced by the body of the user function.
 *
 * The antiderivative, the integration rules and the residue method select
 * a function by its NAME. With a user definition `Sin := t ↦ t + 1`, the
 * library rule `∫ sin x dx = −cos x` is false for a call of `Sin`. When the
 * body of the user function replaces the call, the integral is the integral
 * of the body, and these methods give its closed form, as `D` does when it
 * differentiates the body of a user function.
 *
 * The caller has found such a call (`shadowedCallsIn()` is `'call'`).
 * Return `undefined` when a call cannot be replaced, and the integral must
 * stay unevaluated:
 * - the user function is not a function literal (an `evaluate` handler);
 * - the evaluated body still has a call of a shadowed name (a recursive
 *   function), or is not valid;
 * - the body has a free symbol with the name of an integration variable in
 *   `bound`. The integral binds this name, so the body would read the
 *   integration variable instead of the symbol of the user function.
 */
function inlineShadowedCalls(
  ce: ComputeEngine,
  integrand: Expression,
  bound: ReadonlyArray<string>
): Expression | undefined {
  // A function literal that `liftIntegrand()` did not unwrap would be
  // canonicalized again when its body changes, which wraps the body again.
  if (integrand.operator === 'Function') return undefined;

  const bodyOf = (call: Expression): Expression | undefined => {
    if (!isFunction(call)) return undefined;
    const def = ce.lookupDefinition(call.operator);
    const isLiteral = isOperatorDef(def)
      ? def.operator.lambda !== undefined
      : isValueDef(def) && isFunction(def.value.value, 'Function');
    if (!isLiteral) return undefined;
    // The body of the user function, with wildcard parameters, then with
    // the arguments of the call.
    const wildcards =
      call.nops === 1
        ? [ce.symbol('_')]
        : call.ops.map((_, i) => ce.symbol(`_${i + 1}`));
    let body: Expression;
    try {
      body = ce.function(call.operator, wildcards).evaluate();
    } catch (e) {
      if (e instanceof Error && e.name === 'CancellationError') throw e;
      return undefined;
    }
    if (!body.isValid || shadowedCallsIn(ce, body) !== 'none') return undefined;
    const parameters = wildcards.map((w) => sym(w)!);
    if (body.symbols.some((s) => !parameters.includes(s) && bound.includes(s)))
      return undefined;
    const substitution: Record<string, Expression> = {};
    parameters.forEach((p, i) => (substitution[p] = call.ops[i]));
    return body.subs(substitution);
  };

  let failed = false;
  const result = integrand.map((x) => {
    if (failed || !isFunction(x) || !shadowsLibraryOperator(x)) return x;
    // The body is that of the function the call was made with, not of a
    // declaration of the same name in a scope pushed later: `bodyOf()` reads
    // the function by name (`withCallableBinding()`).
    const body = withCallableBinding(x, () => bodyOf(x));
    if (body === undefined) failed = true;
    return body ?? x;
  });
  return failed ? undefined : result;
}

/**
 * The integrand of a contour integral (`ContourIntegrate`,
 * `CircularIntegrate`) over the variable `variable`, to give to the residue
 * method. The residue method selects a function by its NAME: it takes `Sin`,
 * `Exp`, … to be entire. With a user definition `Sin := z ↦ 1/z`, a call of
 * `Sin` has a pole at 0 that the residue method does not see. So each call
 * of a user function that has the name of a library function is replaced by
 * the body of the user function (`inlineShadowedCalls()`).
 *
 * Return `undefined` when a call cannot be replaced (a name that a local
 * scope of the integrand shadows, or one of the cases of
 * `inlineShadowedCalls()`): the integral then stays unevaluated. This also
 * applies under `N()`, because the residue method is the only method of a
 * contour integral.
 */
function contourIntegrand(
  ce: ComputeEngine,
  f: Expression,
  variable: string
): Expression | undefined {
  const calls = shadowedCallsIn(ce, f.canonical);
  if (calls === 'none') return liftIntegrand(f);
  if (calls === 'local') return undefined;
  return inlineShadowedCalls(ce, liftIntegrand(f.canonical), [variable]);
}

/**
 * The shape gate `list<any>` that `JacobianMatrix`'s type handler asks its
 * operand: "does this denote a SYSTEM of functions?". Asked with the
 * absence-admitting top so that a list whose element type carries an
 * absence marker still matches. Built once at module load.
 */
const JACOBIAN_LIST_SHAPE_TYPE: Type = Object.freeze({
  kind: 'list',
  elements: 'any',
}) as Type;

/**
 * The type a SYMBOL operand's held value has, or `undefined` when the
 * operand is not a symbol, holds nothing, or holds another symbol.
 *
 * A held value is a pure source, and it carries what a wide declaration
 * does not: a head declared as a bare `function` and only then assigned a
 * lambda keeps `function` as its contract, while the lambda itself has a
 * signature whose codomain `Derivative` wants. The definition is looked up
 * by name, which is the binding the operand itself resolves through.
 */
function heldValueTypeOf(
  d: OperandDescriptor,
  engine: PureEngineView
): Type | undefined {
  const structure = d.structureOf?.();
  if (structure?.kind !== 'symbol') return undefined;
  const held = engine.lookupDefinition(structure.name)?.value?.value;
  if (held === undefined || isSymbol(held)) return undefined;
  return held.type.type;
}

/**
 * Collect the dependent-function symbol name(s) from the second argument of
 * `DSolve`/`NDSolve` (a symbol or a `List` of symbols).
 */
function dependentSymbolNames(dependent: Expression): Set<string> {
  const names = new Set<string>();
  if (isSymbol(dependent)) names.add(dependent.symbol);
  else if (isFunction(dependent, 'List'))
    for (const op of dependent.ops) if (isSymbol(op)) names.add(op.symbol);
  return names;
}

/**
 * Repair a differential equation parsed from LaTeX on a *fresh* engine where
 * the dependent function `y` is not yet declared as a function. In that state,
 * `y(x)` parses as an invisible product `InvisibleOperator(y, Delimiter(x))`
 * instead of the function application `y(x)`, leaving `DSolve` inert. The
 * `DSolve`/`NDSolve` canonical handlers know the dependent name(s) (the second
 * argument), so we can locally rewrite `InvisibleOperator(y, Delimiter(args))`
 * → `y(args)` for those names — including nested occurrences inside `List`
 * conditions — without perturbing global parser inference. A second parse on
 * the same engine parses `y(x)` correctly (once `y` is known to be a function),
 * so this only affects the first-parse form.
 */
function repairDependentApplications(
  expr: Expression,
  names: Set<string>
): Expression {
  if (names.size === 0 || !isFunction(expr)) return expr;
  const ce = expr.engine;

  if (expr.operator === 'InvisibleOperator') {
    const ops = expr.ops;
    const newOps: Expression[] = [];
    for (let i = 0; i < ops.length; i++) {
      const cur = ops[i];
      const next = ops[i + 1];
      if (
        isSymbol(cur) &&
        names.has(cur.symbol) &&
        next &&
        isFunction(next, 'Delimiter')
      ) {
        const inner = next.op1;
        const args =
          inner && isFunction(inner, 'Sequence')
            ? inner.ops
            : inner
              ? [inner]
              : [];
        newOps.push(ce.function(cur.symbol, args));
        i += 1; // consume the delimiter
      } else newOps.push(repairDependentApplications(cur, names));
    }
    if (newOps.length === 1) return newOps[0];
    return ce.function('InvisibleOperator', newOps);
  }

  let changed = false;
  const newOps = expr.ops.map((op) => {
    const repaired = repairDependentApplications(op, names);
    if (repaired !== op) changed = true;
    return repaired;
  });
  if (!changed) return expr;
  return ce.function(expr.operator, newOps);
}

/**
 * If `expr` is a bare reference to a user-defined function (`F`, not `F(…)`),
 * return its parameter names (the natural differentiation variables, in
 * declared order) and its body. `undefined` otherwise.
 *
 * The parameter *order* is why this beats free-variable inference: the map's
 * own signature fixes the column order of the Jacobian, with no lexicographic
 * guess.
 */
function lambdaFromLiteral(
  literal: Expression
): { params: string[]; body: Expression } | undefined {
  if (!isFunction(literal, 'Function')) return undefined;

  const params = literal.ops
    .slice(1)
    .map((p) => functionLiteralParameterName(p));
  if (params.length === 0 || params.some((n) => !n)) return undefined;

  // Canonicalization wraps a lambda body in a `Block`; a single-statement
  // block is just its statement (a multi-statement body is not a plain system
  // and is declined).
  let body = literal.op1;
  if (isFunction(body, 'Block')) {
    if (body.nops !== 1) return undefined;
    // Lifting the body out of its Block takes it out of the scope that binds
    // the parameters, so occurrences of `x` in the returned body would still
    // point at the lambda's (now unreachable) parameter binding. Re-bind them
    // to the caller's symbols — which is what "the Jacobian is taken with
    // respect to the parameters, in declared order" means, and what makes the
    // bare form agree with the applied form.
    const scope = body.localScope;
    body = body.op1;
    if (scope) body = rebindEscaping(body, scope);
  }
  return { params: params as string[], body };
}

function bareFunctionLambda(
  expr: Expression,
  seen: Set<string> = new Set()
): { params: string[]; body: Expression } | undefined {
  // A `Function` literal directly (e.g. the value a pipe resolves `F` to).
  if (isFunction(expr, 'Function')) return lambdaFromLiteral(expr);

  if (!isSymbol(expr) || seen.has(expr.symbol)) return undefined;
  seen.add(expr.symbol);
  const def = expr.engine.lookupDefinition(expr.symbol);

  // A named function: its operator definition holds the lambda literal.
  const opDef = (def as { operator?: unknown } | undefined)?.operator as
    { _isLambda?: boolean; _lambdaLiteral?: Expression } | undefined;
  if (opDef?._isLambda && opDef._lambdaLiteral)
    return lambdaFromLiteral(opDef._lambdaLiteral);

  // A value binding. `F |> JacobianMatrix` reaches the handler with `F` bound
  // as a VALUE whose content is the `Function` literal (or, one level up, the
  // symbol `F`); a direct call sees the operator definition instead. Follow
  // either so the pipe and direct forms agree.
  const value = (def as { value?: { value?: Expression } } | undefined)?.value
    ?.value;
  if (value !== undefined) return bareFunctionLambda(value, seen);
  return undefined;
}

function bareFunctionSystem(
  list: Expression
): { params: string[]; bodies: Expression[] } | undefined {
  // `[a, b, c] |> JacobianMatrix` — a List whose elements are all bare
  // function references. Resolve only when EVERY element is such a reference
  // and all parameter lists agree exactly, in names and order; the shared
  // parameters are then the default differentiation variables. A mixed list,
  // or lambdas with differing parameters, would need a guessed variable
  // correspondence — decline instead.
  if (!isFunction(list, 'List') || list.nops === 0) return undefined;
  const lambdas: { params: string[]; body: Expression }[] = [];
  for (const op of list.ops) {
    const lambda = bareFunctionLambda(op);
    if (lambda === undefined) return undefined;
    lambdas.push(lambda);
  }
  const params = lambdas[0].params;
  for (const l of lambdas)
    if (
      l.params.length !== params.length ||
      l.params.some((p, i) => p !== params[i])
    )
      return undefined;
  return { params, bodies: lambdas.map((l) => l.body) };
}

/** The heads whose presence in a result means "no closed form was found". */
const DERIVATIVE_HEADS = ['D', 'Derivative', 'ND'] as const;

/**
 * Fold the raw output of the symbolic differentiator into the form the `D`
 * operator answers with.
 *
 * The fold is a plain `evaluate()`, skipped when the result carries a symbolic
 * transcendental (`ln(2)`) so the exactness contract keeps that symbolic.
 *
 * A piecewise result is folded ARM BY ARM instead. `Which` and `If` are
 * selectors: a condition that cannot be decided (the usual case for a
 * derivative, whose variable is free) leaves the node evaluating to itself
 * with its held arms untouched. A single `evaluate()` on the whole node
 * therefore leaves each arm exactly as the differentiation rules wrote it — a
 * `2·ln(e)·e^(-2x)` where the same derivative written without a condition
 * reads `2·e^(-2x)`. The conditions are boolean operands, not values, so they
 * are carried over unchanged.
 */
function foldDerivativeResult(f: Expression): Expression {
  if (isFunction(f)) {
    // `Which` operands are strictly paired `(condition, value)`, so a value
    // arm sits at every odd position; an `If` has one condition followed by
    // its branches. An odd `Which` operand count is a malformed call — leave
    // it to the ordinary fold rather than guessing how to pair it.
    const isWhich = f.operator === 'Which' && f.nops % 2 === 0;
    if (isWhich || f.operator === 'If')
      return f.engine.function(
        f.operator,
        f.ops.map((op, i) =>
          (isWhich ? i % 2 === 1 : i > 0) ? foldDerivativeResult(op) : op
        )
      );
  }
  return hasSymbolicTranscendental(f) ? f : f.evaluate();
}

/**
 * The record of the differentiation of a `D` node, in the state of the
 * engine that the stamps describe:
 * - `value`: the closed form that the differentiation gave, before it is
 *   re-bound to the scope of the evaluation
 *   (`rebindEscapingBinderResult()`), or `undefined` when the node has no
 *   closed form (the evaluate handler declined);
 * - `worldVersion`: the `world` axis (`ce._worldVersion`), which advances
 *   for an assumption, a redefinition, an inference and a configuration
 *   change;
 * - `factsHidden`: the side of a fact-suppression window
 *   (`ce._factsHidden()`);
 * - `deps`: for each symbol that the node reads, directly or through the
 *   body of a user function it calls or the value of a symbol it reads, the
 *   binding it resolves to and the `_writeVersion` of that binding
 *   (`snapshotMemoDeps()`). A value write, a type write and a new
 *   declaration that shadows the name each invalidate it;
 * - `variables`: for each differentiation variable of the node, its
 *   definition and its type. The variables are bound by the node itself, so
 *   `snapshotMemoDeps()` leaves them out, but the rules read their types:
 *   `D(|x|, x)` declines for an `x` typed as a tuple and is `sgn(x)` for a
 *   real `x`, and a type write to such a definition does not advance the
 *   `world` axis. The `_writeVersion` of the definition cannot be used: the
 *   value shield of each evaluation of the node writes the definition;
 * - `objectDeps`: the versions of the mutable objects whose fields the
 *   attempt read.
 */
type DerivativeRecord = {
  value: Expression | undefined;
  worldVersion: number;
  factsHidden: boolean;
  deps: MemoDeps;
  variables: VariableStamp[];
  objectDeps: ObjectDeps | undefined;
};

/** A differentiation variable of a `D` node, the definition it is bound to
 * and its type, as a string, and its type before the differentiation
 * (`withDerivativeMemo()`). */
type VariableStamp = [
  node: Expression,
  def: object | undefined,
  type: string,
  typeBefore?: string,
];

/** The stamps of the differentiation variables of the `D` node `expr`. */
function variableStamps(expr: Expression): VariableStamp[] {
  if (!isFunction(expr)) return [];
  return expr.ops
    .slice(1)
    .filter((op) => isSymbol(op))
    .map((op) => [op, op.valueDefinition, op.type.toString()]);
}

/** The stamps `after`, each with the type of the same variable in `before`
 * when it has the same definition there. */
function withTypesBefore(
  after: VariableStamp[],
  before: VariableStamp[]
): VariableStamp[] {
  return after.map((stamp, i) =>
    before[i]?.[1] === stamp[1]
      ? [stamp[0], stamp[1], stamp[2], before[i][2]]
      : stamp
  );
}

/** Is each variable still bound to the definition it was bound to, with
 * the same type, or with its type before the differentiation? */
function variableStampsValid(stamps: VariableStamp[]): boolean {
  return stamps.every(([node, def, type, typeBefore]) => {
    if (node.valueDefinition !== def) return false;
    const now = node.type.toString();
    return now === type || now === typeBefore;
  });
}

/**
 * A differentiation variable of `D`, with a subscript `Subscript(x, 1)`
 * whose index is an integer literal replaced by the symbol `x_1`, the
 * canonical form of that subscript. Any other variable is returned as it
 * is.
 *
 * The parser reads `x_k` in the body of `\sum_{k=1}^{2}` as
 * `Subscript(x, k)`, also in the variable of a derivative, so that each term
 * of `\sum_{k=1}^{2}\frac{\partial}{\partial x_k} x_k^2` differentiates with
 * respect to its own variable (`_subscriptBoundIndexes()` in
 * `latex-syntax/parse.ts`). The sum puts the value of the index in each
 * term, but the variables of `D` are held, so they are not made canonical
 * with the rest of the term. Once the variable is a symbol, `D` binds it as
 * any other variable, also for a substitution: `x_1` in
 * `D(x_1^2, x_1)` is not replaced. A symbol index (`Subscript(x, k)`) is
 * not read by value, and the derivative stays unevaluated.
 */
function subscriptVariableAsSymbol(variable: Expression): Expression {
  if (!isFunction(variable, 'Subscript') || !isSymbol(variable.op1))
    return variable;
  const index = isFunction(variable.op2, 'Delimiter')
    ? variable.op2.op1
    : variable.op2;
  if (!isNumber(index) || index.isInteger !== true) return variable;
  const joined = variable.engine.box([
    'Subscript',
    variable.op1.symbol,
    index.json,
  ]);
  return isSymbol(joined) ? joined : variable;
}

/** The records of the differentiations of `D` nodes, one slot for
 * `evaluate()` and one for a numeric approximation. Weakly held: the record
 * goes with the node. */
const DERIVATIVE_RECORDS = new WeakMap<
  Expression,
  [DerivativeRecord | undefined, DerivativeRecord | undefined]
>();

/**
 * The result of an earlier differentiation of this same `D` node, when
 * nothing it depends on changed since then (see {@link DerivativeRecord}):
 * the closed form, before it is re-bound to the scope of the evaluation, or
 * `expression` itself when the differentiation declined. Otherwise
 * `undefined`. A hit hands the object dependencies of the record to the
 * enclosing cache-backed computations, as the other value memos do.
 */
function recordedDerivative(
  expression: Expression | undefined,
  numeric: boolean
): Expression | undefined {
  if (expression === undefined) return undefined;
  const entry = DERIVATIVE_RECORDS.get(expression)?.[numeric ? 1 : 0];
  if (entry === undefined) return undefined;
  const ce = expression.engine;
  if (
    ce._atTransientConfiguration ||
    entry.worldVersion !== ce._worldVersion ||
    entry.factsHidden !== ce._factsHidden() ||
    !memoDepsStillValid(expression, entry.deps) ||
    !variableStampsValid(entry.variables) ||
    !objectDepsValid(entry.objectDeps)
  )
    return undefined;
  mergeObjectDeps(entry.objectDeps);
  return entry.value ?? expression;
}

/**
 * Run `attempt`, the differentiation of the `D` node `expression`, and
 * record its result, a closed form or a decline (`attempt` returns
 * `undefined`), so that the next evaluation of the same node does not work
 * it out again ({@link recordedDerivative}). A recorded decline returns
 * `expression` itself, not `undefined`: the evaluation driver then gives the
 * node as its value, and does not box a new `D` node with an empty record.
 * That is what makes the record reach a later evaluation of the value, such
 * as the read of a function parameter that holds the derivative.
 *
 * A differentiation costs a full attempt each time: a `D` of a call of a
 * user function expands its body, and the size limit of the differentiator
 * can be reached only after a large result was built. Without the record, a
 * value that holds such a `D` paid that cost again at each evaluation, and a
 * function that reads its parameter `n` times paid it about `n + 2` times
 * (Tycho ledger row 424: 0.6 s for each attempt, 5 s for nine reads). The
 * closed form of the derivative of a path of 29 pieces cost about 0.1 s to
 * 0.5 s at each evaluation of the same node.
 *
 * A result is not recorded when it may be provisional or when the record
 * could not be validated later, the same rules as the memo of a stored value
 * (`BoxedSymbol._memoizedStoredValue()`):
 * - inside a transient precision or angular-unit window;
 * - when the store guard refuses it (`store-guard.ts`): the attempt ran
 *   host code that does not state its purity, or met a provisional answer
 *   (a reference cycle, a stopped sequence read, a walk that missed
 *   elements);
 * - when the attempt re-pointed a binding;
 * - when the attempt used the `derivative` key of an operator definition
 *   (`derivativeKeyUseCount()`): a function literal of the key reads its
 *   free symbols, and a handler can read any state, which the dependencies
 *   of the node do not record;
 * - when the node is not transitively pure (it can read a random number),
 *   holds a mutable object, or has a dependency that cannot be recorded
 *   (an unbound name);
 * - when the node or the closed form holds an error;
 * - when the attempt runs inside another differentiation (a `D` nested in
 *   the operand of a `D`): it shares the size budget of the enclosing
 *   differentiation (`isDifferentiating()`), so it can decline because of
 *   the nodes that the enclosing one built.
 * A result that is not recorded is returned as it is: a closed form, or
 * `undefined` for a decline.
 *
 * The recorded closed form is the value before the re-binding to the scope
 * of the evaluation (`rebindEscapingBinderResult()`), which the caller does
 * at each evaluation: in `x ↦ D(x^2, x)`, the record holds `2x`, and each
 * call puts the value of its own parameter `x` in it.
 */
function withDerivativeMemo(
  expression: Expression | undefined,
  numeric: boolean,
  attempt: () => Expression | undefined
): Expression | undefined {
  // A node that holds an error (`D(If(x), x)`, where `If(x)` lacks its then
  // branch) is not recorded: the evaluation driver gives the error as the
  // value of a decline, which it does not for the node itself.
  if (
    expression === undefined ||
    !expression.isCanonical ||
    !expression.isValid ||
    expression.engine._atTransientConfiguration ||
    isDifferentiating()
  )
    return attempt();
  const ce = expression.engine;
  const guard = beginStoreGuard();
  const rewritesBefore = ownBindingRewriteCount();
  const keyUsesBefore = derivativeKeyUseCount();
  // The attempt writes the
  // requirements on the variables in the environment of the operation. A
  // later check in the same operation reads the types that the attempt left,
  // and a check in the next operation, whose environment does not have these
  // writes, reads the types that the attempt started from: the record keeps
  // both (`variableStampsValid()`).
  const variablesBefore = variableStamps(expression);
  beginObjectDeps();
  let objectDeps: ObjectDeps | undefined;
  let result: Expression | undefined;
  try {
    result = attempt();
  } finally {
    objectDeps = endObjectDeps();
  }
  // The record reads its dependencies after the attempt, as it reads the
  // types of the variables (`variablesBefore` above): an entry of the
  // environment of the operation that the attempt wrote is the state that
  // the attempt leaves.
  stampObjectDepsAtEnd(objectDeps);
  if (
    (result !== undefined && !result.isValid) ||
    !guard.allowsStore() ||
    ownBindingRewriteCount() !== rewritesBefore ||
    derivativeKeyUseCount() !== keyUsesBefore ||
    !isTransitivelyPure(expression) ||
    containsObject(expression)
  )
    return result;
  // The dependencies are read AFTER the attempt: an inference that the
  // attempt made (a symbol narrowed by a use) is then part of the state the
  // record describes.
  const deps = snapshotMemoDeps(expression);
  if (deps === undefined) return result;
  const slots = DERIVATIVE_RECORDS.get(expression) ?? [undefined, undefined];
  slots[numeric ? 1 : 0] = {
    value: result,
    worldVersion: ce._worldVersion,
    factsHidden: ce._factsHidden(),
    deps,
    variables: withTypesBefore(variableStamps(expression), variablesBefore),
    objectDeps,
  };
  DERIVATIVE_RECORDS.set(expression, slots);
  return result ?? expression;
}

/**
 * Target-agnostic compile lowering for the derivative heads (`D`,
 * `Derivative`, `ND`): the differentiation itself is a symbolic operation with
 * no runtime counterpart on any target, but its *result* is an ordinary
 * expression the normal compiler already handles. So obtain the closed form
 * and compile that instead.
 *
 * `.evaluate()`, never `.simplify()`: evaluate is what produces the closed
 * form here, and `.simplify()` inside a compile path invites the recursion
 * hazards documented in ARCHITECTURE.md.
 *
 * Only a PURE derivative node is evaluated: evaluating happens at COMPILE
 * time, so an impure body (`ND(Function(Random(), x), 1.5)` runs the numerical
 * stencil during compilation) would consume its random draws once and freeze
 * the sampled result into the emitted code. Decline instead, so the draw
 * timing and the run-time semantics are left intact.
 *
 * Purity is not enough, though: canonicalizing and evaluating can also
 * DECLARE. `devolveUnappliedOperator` (`boxed-expression/validate.ts`) turns a
 * single-uppercase-letter builtin used as a bare operand into a variable by
 * shadowing the builtin — `D` in `D(D·x², x)` is a legitimate free variable —
 * and that shadow persists in whatever scope is current. Left to the caller's
 * scope it would replace the engine's `D` *operator* definition for the
 * engine's lifetime, so every later derivative compilation would report
 * ``Unknown operator `D` ``. Compiling must not mutate the engine, so the
 * whole closed-form computation runs in a throwaway child scope; any
 * declaration it makes dies with the scope.
 *
 * The node is BUILT inside that scope, not merely evaluated there: the scope a
 * binder's `localScope` descends from is fixed when the node is canonicalized,
 * and evaluating a binder re-enters that parent (`rebindEscapingCurrentScope`).
 * A node canonicalized outside would declare outside, whatever scope is
 * current at `.evaluate()`.
 *
 * Declines (returns `undefined`, never throws) when no closed form is
 * available — the result is unchanged, or still carries a derivative head
 * (an opaque user function differentiates to `Apply(Derivative(f,1), x)`;
 * `ND` at a symbolic point stays put). Declining lets the standard
 * `noLoweringMessage` report it, and leaves the door open for a custom target
 * that does map the head — a thrown error here would pre-empt it, since a
 * per-operator handler is consulted BEFORE the target's function table.
 */
function compileDerivative(
  operator: (typeof DERIVATIVE_HEADS)[number],
  args: ReadonlyArray<Expression>,
  compile: (expr: Expression) => string,
  context?: { readonly language: string }
): string | undefined {
  if (args.length === 0) return undefined;

  // The numeric fallback for the no-closed-form declines below (item 177).
  // NOT used for the impure decline: an impure body's stencil would re-draw
  // its random values at every stencil point, and the interpreted route
  // declines it too — the two routes must fail (or fall back) together.
  const fallback = (): string | undefined =>
    compileNumericDerivativeFallback(operator, args, compile, context);

  const ce = args[0].engine;
  let node: Expression;
  let value: Expression;
  // Isolation scope — see the note above. A child of the caller's scope, so
  // every declaration the caller made is still visible; only what this
  // evaluation declares is confined, and discarded on the way out. The closed
  // form outlives the scope: `compile()` below resolves its free symbols by
  // name against the target's bindings, not against this scope.
  ce.pushScope();
  try {
    node = ce.function(operator, args as Expression[]);
    // An impure node (`ND` of a body drawing random values, say) must not be
    // evaluated here: that would happen at compile time and bake one sample
    // into the emitted code.
    if (!node.isPure) return undefined;
    value = node.evaluate();
  } catch (e) {
    // A caller's timeout, an abort or an iteration limit propagates; only
    // an ordinary evaluation error falls back.
    throwIfCallerCancellation(e, ce._deadlineFrame);
    return fallback();
  } finally {
    ce.popScope();
  }
  if (!value.isValid) return fallback();
  // Re-entry guard: an unchanged result would compile straight back into this
  // handler. This is also where the differentiation growth budget surfaces:
  // `differentiate()` declines past `MAX_DERIVATIVE_NODES` (a deeply-nested
  // body whose derivative's term count grows exponentially), the evaluate
  // handler then returns the node unchanged, and the numeric fallback takes
  // over — instead of the compilation failing closed (Tycho item 177).
  if (value.isSame(node)) return fallback();
  // No closed form: a derivative head survived the evaluation. Head-aware:
  // `has()` would also match a plain symbol named `D`, which is a legitimate
  // free variable in a closed form.
  if (DERIVATIVE_HEADS.some((h) => value.getSubexpressions(h).length > 0))
    return fallback();

  try {
    // The closed form is a FRESH expression in the engine's angular
    // convention (`d/dx sin x = (π/180)·cos x` in degree mode) — it never went
    // through the entry-point rewrite, which skips the derivative heads
    // precisely so that differentiation runs in that convention. Rewrite it
    // here, or the radian-based `Math.cos` the target emits would disagree
    // with `evaluate()`. Same reason `prepareUserFunctionBody` rewrites an
    // emitted function-literal body.
    // In parentheses: the caller writes this text as an operand, and a closed
    // form that is a sum would otherwise regroup with the parent's operator
    // (`1 / D(x^3 + x, x)` as `1 / 3 * (x * x) + 1`).
    const code = compile(rewriteAngularUnit(value));
    return code ? `(${code})` : undefined;
  } catch (e) {
    throwIfCallerCancellation(e, ce._deadlineFrame);
    // The closed form contains a head this target cannot lower (`Digamma` on
    // glsl, say). Decline rather than let the inner error escape: a
    // per-operator handler runs BEFORE the target's function table, so
    // throwing would pre-empt a custom target that does map that head. The
    // trade-off is deliberate — the inner message names the offending head and
    // is more informative than the generic decline the fallthrough produces,
    // but contract-correctness wins. Do not "restore" the throw.
    return fallback();
  }
}

/**
 * Emit a NUMERIC differentiation when the symbolic closed form is
 * unavailable — the shared-budget fallback of Tycho item 177 (user-ruled
 * 2026-08-14): within the differentiation growth budget both routes use the
 * exact closed form; past it, the compiled target and the interpreter's
 * `N()` both fall back to the SAME stencil (`centeredDiffHigherOrder`,
 * numerics/numeric.ts — injected into emitted code as `_SYS.nd`), so
 * compiled-vs-interpreted parity holds by construction. Plain `evaluate()`
 * keeps its exactness contract: it returns the node symbolically unchanged
 * rather than a stencil float (see `numericDerivativeOfApply`).
 *
 * javascript target only: the other targets keep today's decline (each
 * would need its own `nd` runtime; add per-target when asked). Univariate,
 * single-order, PURE bodies only — mixed partials and impure bodies decline
 * on both routes alike.
 */
function compileNumericDerivativeFallback(
  operator: (typeof DERIVATIVE_HEADS)[number],
  args: ReadonlyArray<Expression>,
  compile: (expr: Expression) => string,
  context?: { readonly language: string }
): string | undefined {
  if (context?.language !== 'javascript') return undefined;
  if (args.length === 0) return undefined;
  const ce = args[0].engine;
  try {
    if (operator === 'D') {
      // `D(body, v)` is EXPRESSION-valued: emit the stencil function applied
      // at the (free) variable. Multi-variable / repeated-variable partials
      // keep the symbolic-only behavior.
      if (args.length !== 2) return undefined;
      const v = args[1];
      if (!isSymbol(v)) return undefined;
      const body = args[0];
      if (!body.isPure) return undefined;
      const fn = ce.function('Function', [body, v]);
      return `_SYS.nd(${compile(rewriteAngularUnit(fn))}, 1${shapeArgument(
        fn
      )})(${compile(v)})`;
    }

    // `Derivative(f, order?)` is FUNCTION-valued; `ND(f, x)` is a value at a
    // point. Both need `f` as a compilable univariate function literal
    // (resolving a symbol callee through its binding). The literal is
    // rewritten for the angular convention explicitly — as an operand of a
    // derivative head it was skipped by the entry-point rewrite (see the
    // closed-form branch above); the interpreted fallback gets the same
    // rewrite implicitly because `implicitCompile` runs the full compile
    // entry on the literal.
    const lit = resolveDerivativeFunctionLiteral(args[0]);
    if (lit === undefined) return undefined;

    if (operator === 'Derivative') {
      if (args.length > 2) return undefined;
      const order = args[1] === undefined ? 1 : Math.floor(args[1].N().re);
      if (!Number.isFinite(order) || order < 1) return undefined;
      return `_SYS.nd(${compile(rewriteAngularUnit(lit))}, ${order}${shapeArgument(
        lit
      )})`;
    }

    // `ND` — previously compilable only when the point was numeric at
    // compile time (the evaluate handler ran the stencil then); a runtime
    // point now lowers to the same stencil evaluated at run time.
    if (args.length !== 2) return undefined;
    return `_SYS.nd(${compile(rewriteAngularUnit(lit))}, 1${shapeArgument(
      lit
    )})(${compile(args[1])})`;
  } catch (e) {
    throwIfCallerCancellation(e, ce._deadlineFrame);
    // The body contains a head the target cannot lower — same contract as
    // the closed-form branch: decline, never let the inner error escape.
    return undefined;
  }
}

/**
 * The third argument of the emitted `_SYS.nd(f, order, shape)`: the shape
 * of the function's value read from its result type
 * (`derivativeValueShape`), so the helper runs the scalar or the vector
 * stencil without probing the function; nothing when the type says
 * nothing, and the helper probes once at run time.
 */
function shapeArgument(lit: Expression): string {
  const shape = derivativeValueShape(functionResult(lit.type.type));
  return shape === undefined ? '' : `, '${shape}'`;
}

/**
 * The INTERPRETED half of the item-177 numeric-derivative fallback: given an
 * `Apply(Derivative(f, order?), x)` that stayed symbolic because no closed
 * form was found (the differentiation growth budget, or an unresolvable
 * head), compute the same stencil the compiled target emits
 * (`centeredDiffHigherOrder` — one shared function, so the two routes agree
 * bit-for-bit). Returns `undefined` — leaving the expression symbolic — when
 * the shape is not the univariate pure single-point case, mirroring
 * `compileNumericDerivativeFallback`'s gates.
 *
 * A function whose value is a POINT or a LIST of numbers — a space curve
 * `t ↦ (x(t), y(t), z(t))` — is differentiated component by component, each
 * component through the same stencil, exactly as the compiled `_SYS.nd`
 * does; the result has the kind of the function's value (a point for a
 * point-valued function, a list otherwise).
 *
 * Called ONLY from `Apply`'s evaluate handler under `numericApproximation`
 * (library/core.ts): plain `evaluate()` keeps the exactness contract and
 * returns the symbolic expression untouched.
 */
export function numericDerivativeOfApply(
  expr: Expression
): Expression | undefined {
  if (!isFunction(expr, 'Apply')) return undefined;
  if (expr.ops.length !== 2) return undefined;
  const callee = expr.op1;
  if (!isFunction(callee, 'Derivative')) return undefined;
  if (callee.ops.length > 2) return undefined;
  if (!callee.isPure) return undefined;

  const ce = expr.engine;
  const order = callee.ops.length === 2 ? Math.floor(callee.ops[1].N().re) : 1;
  if (!Number.isFinite(order) || order < 1) return undefined;

  const lit = resolveDerivativeFunctionLiteral(callee.op1);
  if (lit === undefined) return undefined;

  const x = expr.ops[1].N().re;
  if (Number.isNaN(x)) return undefined;

  return stencilDerivativeAt(ce, lit, x, order);
}

/**
 * The numeric `order`-th derivative of the univariate function literal
 * `lit` at `x`, through the stencil `centeredDiffHigherOrder` — the SAME
 * function the compiled JavaScript target's `_SYS.nd` runs, so the two
 * routes agree bit-for-bit. A scalar function answers a machine number; a
 * point- or list-valued function is differentiated component by component
 * through the vector form of the stencil (`centeredDiffHigherOrderVector`,
 * one evaluation per sample) and answers a point (`Tuple`) when the
 * literal's result type is a point, a `List` otherwise, a component that
 * the stencil cannot compute being `NaN` in place — the value the compiled
 * route emits. `undefined` — the expression stays symbolic — when a scalar
 * stencil answers NaN, or when the function does not answer a vector of one
 * length at every sample.
 *
 * Which stencil runs is decided from the literal's result type
 * (`derivativeValueShape`); only a function whose type says nothing is
 * probed at `x` once, so the common typed scalar case costs no extra
 * evaluation. The evaluation vehicle is the compiled literal where JIT is
 * available and the interpreted application otherwise (`numericApplier`).
 * The values are machine arithmetic throughout, so they are boxed as machine
 * numbers rather than wrapped in a `BigDecimal` at a higher engine
 * precision.
 */
function stencilDerivativeAt(
  ce: ComputeEngine,
  lit: Expression,
  x: number,
  order: number
): Expression | undefined {
  const result = functionResult(lit.type.type);
  const shape = derivativeValueShape(result);
  const fn = numericApplier(ce, lit);
  const vector =
    shape === 'vector' || (shape === undefined && Array.isArray(fn(x)));
  if (!vector) {
    const v = centeredDiffHigherOrder(
      (t) => {
        const value = fn(t);
        return typeof value === 'number' ? value : NaN;
      },
      x,
      order
    );
    if (Number.isNaN(v)) return undefined;
    // A numeric derivative is a float, even when its value is an integer
    // (`ND(x^2, 1)` is `2.0`). `+ 0` turns a -0 into 0.
    return ce.number(ce._inexactNumericValue(v + 0));
  }
  const components = centeredDiffHigherOrderVector(
    (t) => {
      const value = fn(t);
      return Array.isArray(value) ? value : undefined;
    },
    x,
    order
  );
  if (components === undefined) return undefined;
  const boxed = components.map((c) =>
    ce.number(ce._inexactNumericValue(c + 0))
  );
  return ce.function(isPointElementType(result) ? 'Tuple' : 'List', boxed);
}

/**
 * The shape of the value of a function whose result type is `result`, for
 * the numeric derivative: `'vector'` for a point or a list of numbers,
 * `'scalar'` for a number, `undefined` when the type says nothing (`any`,
 * `unknown`, or absent) — the stencil then probes the function once.
 */
export function derivativeValueShape(
  result: Type | undefined
): 'vector' | 'scalar' | undefined {
  if (result === undefined || result === 'any' || result === 'unknown')
    return undefined;
  if (isPointElementType(result) || isSubtype(result, 'list<number>'))
    return 'vector';
  if (isSubtype(result, 'number')) return 'scalar';
  return undefined;
}

/**
 * Whether `o` is the order pair of a higher-order `D`: Mathematica's
 * `{x, n}` (a `Set`), or the same pair written as a list, `[x, n]`, which is
 * a variable and a number and so cannot be a list of variables.
 */
function isOrderSpec(
  o: Expression
): o is Expression & import('../global-types.js').FunctionInterface {
  if (isFunction(o, 'Set')) return true;
  return (
    isFunction(o, 'List') &&
    o.nops === 2 &&
    isSymbol(o.op1) &&
    isNumber(o.op2.canonical)
  );
}

/**
 * Does `e` hold an application of the `D` operator anywhere below it? The
 * symbolic differentiator leaves a `D(body, v)` where it has no rule
 * (`symbolic/derivative.ts`), so one inside a closed form marks it
 * incomplete. A user function that happens to be NAMED `D` is read the same
 * way; the cost of that misreading is the stencil where a closed form
 * existed, never a wrong value.
 */
function holdsUnresolvedD(e: Expression): boolean {
  if (!isFunction(e)) return false;
  if (e.operator === 'D') return true;
  return e.ops.some(holdsUnresolvedD);
}

/**
 * A machine-number applier for a univariate function literal: the compiled
 * literal where JIT is available, the interpreted application otherwise. A
 * point- or list-valued function answers an array of its components, a
 * scalar one a number.
 */
function numericApplier(
  ce: ComputeEngine,
  lit: Expression
): (x: number) => number | number[] {
  // The application is NUMERICIZED (`N()`), not merely evaluated: an exact
  // constant inside the value — `sin(1)` in `t ↦ [sin(1), t]` — would
  // otherwise stay symbolic at every sample and read as NaN.
  const interpreted = (x: number): number | number[] => {
    const value = ce.function('Apply', [lit, ce.number(x)]).N();
    if (isNumber(value)) return realPart(value);
    // `each` is absent on a collection whose elements cannot be enumerated.
    if (value.isCollection && typeof value.each === 'function')
      return [...value.each()].map((c) => (isNumber(c) ? realPart(c) : NaN));
    return NaN;
  };
  const run = implicitCompile(ce, lit, 'nd')?.run as
    ((x: number) => unknown) | undefined;
  if (run === undefined) return interpreted;
  return (x) => {
    const value = run(x);
    // A compiled SYMBOL (a function name the caller did not resolve to its
    // literal) answers `undefined` for a positional argument; the
    // interpreted application still answers it.
    if (value === undefined) return interpreted(x);
    return Array.isArray(value) ? value.map(machineReal) : machineReal(value);
  };
}

/**
 * A number literal as a machine real: its real part when its imaginary
 * part is zero, `NaN` otherwise — the same test the compiled route's
 * `realFn` applies, so a complex sample is rejected on both routes rather
 * than silently read as its real part.
 */
function realPart(n: Expression): number {
  return isNumber(n) && !n.isComplex ? n.re : NaN;
}

/**
 * A value the compiled literal answered, as a machine real: a number as it
 * is, a complex result object with a zero imaginary part as its real part,
 * anything else `NaN` (the test of the compiled route's `realFn`).
 */
function machineReal(value: unknown): number {
  if (typeof value === 'number') return value;
  if (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as { re?: unknown }).re === 'number' &&
    (value as { im?: unknown }).im === 0
  )
    return (value as { re: number }).re;
  return NaN;
}

/**
 * The `Function` literal a user-defined function symbol is bound to, or
 * `undefined`. A function defined by a lambda (`g(x, y) := x^2 y`, or
 * `Assign(g, Function(…))`) is installed as an OPERATOR definition that keeps
 * the literal on its `_lambdaLiteral` slot; the declare-then-assign idiom
 * (`ce.declare('g', 'function')` then `ce.assign`) keeps it as the symbol's
 * VALUE. `op.value` answers neither reliably — for the operator route it is
 * the operator wrapper, not the literal.
 */
function functionLiteralOf(
  ce: ComputeEngine,
  id: string
): Expression | undefined {
  const def = ce.lookupDefinition(id);
  if (def !== undefined && isOperatorDef(def)) {
    const literal = (def.operator as { _lambdaLiteral?: Expression })
      ._lambdaLiteral;
    return isFunction(literal, 'Function') ? literal : undefined;
  }
  const value = ce._getSymbolValue(id);
  return isFunction(value, 'Function') ? value : undefined;
}

/**
 * The function literal of the first operand of the implicit form of `Limit`
 * and `NLimit`: `Limit(expr, point)` and `Limit(expr, point, direction)`,
 * where the variable is not written. `NIntegrate(expr, a, b)` and
 * `ND(expr, point)` read their first operand the same way: the variable of
 * `NIntegrate(√x, 0, 1)` is `x`, also after `x := 4`, so the value is 2/3,
 * the value of `Integrate(√x, Limits(Nothing, 0, 1))`.
 *
 * The variable is a bound variable. It never takes the value assigned to a
 * symbol of the same name, and the order of boxing and assignment does not
 * change it. The shared `canonicalFunctionLiteral()` makes the parameters
 * from the unknowns of the body, that is the symbols with no value: after
 * `x := 4`, the body `√x` had no parameter, and `Limit(√x, a)` was the limit
 * of the constant 2. When `x` had no value at boxing, it was the limit as
 * x → a. Here the variable comes from the symbols written in the body,
 * assigned or not: the first of them in sorted order (code-unit order, so an
 * uppercase letter comes before a lowercase one: `y` for `y·z`, `a` for
 * `a·x`). When nothing is assigned, this is the first unknown, the variable
 * that `canonicalFunctionLiteral()` gives. A constant (`Pi`, `ExponentialE`),
 * a symbol of a library, a symbol that names a function and a symbol bound
 * inside the body (the index of a `Sum`) are not candidates.
 *
 * A parenthesized operand `(√x)` is the expression it holds, as in
 * `canonicalFunctionLiteral()`. When the body has no candidate, the result
 * is that of `canonicalFunctionLiteral()`. A `Function` literal and a body
 * with anonymous slots (`_`) keep that result too, because they name their
 * own parameters. A bare symbol keeps it because it names a function
 * (`Limit(Sin, 0)`). A parenthesized sequence of several expressions
 * (`(a; b)`, which becomes a `Block`) also keeps it.
 */
function canonicalImplicitLimitFunction(
  ce: ComputeEngine,
  f: Expression | undefined
): Expression | undefined {
  // A parenthesized operand is the expression it holds. A sequence of one
  // expression is that expression.
  while (isFunction(f, 'Delimiter')) {
    let inner: Expression | undefined = f.op1;
    if (isFunction(inner, 'Sequence')) {
      if (inner.nops !== 1) break;
      inner = inner.op1;
    }
    if (inner === undefined) break;
    f = inner;
  }
  // The variable of the limit is a bound variable, also when the operand is
  // the literal `Function(body, x)` that the parser makes from
  // `\lim_{x \to a}`: `x(1+a)` in the body is a product.
  const fn = canonicalFunctionLiteral(f, { liftedBody: true });
  if (
    f === undefined ||
    isSymbol(f) ||
    isFunction(f, 'Function') ||
    isFunction(f, 'Delimiter') ||
    !isFunction(fn, 'Function')
  )
    return fn;
  const params = fn.ops.slice(1).map((p) => functionLiteralParameterName(p));
  if (params.some((p) => ANONYMOUS_SLOT_NAMES.has(p))) return fn;

  // The candidates: the unknowns of the body, and the user symbols that the
  // body reads and that have a value (`implicitVariableCandidates`).
  const candidates = implicitVariableCandidates(fn.op1);
  if (candidates.length === 0)
    return canonicalFunctionLiteralArguments(ce, [f], { liftedBody: true }) ?? fn;
  const v = candidates[0];
  // The literal has the variable as its one parameter. The other symbols are
  // free: a literal `Function(y·z, y, z)` would make `z` a parameter that the
  // limit never binds, and compiled code read it as an unbound parameter
  // (NaN) where the interpreter reads the free symbol `z`.
  if (params.length === 1 && params[0] === v) return fn;
  return (
    canonicalFunctionLiteralArguments(
      ce,
      [f, ce.symbol(v, { canonical: false })],
      { liftedBody: true }
    ) ?? fn
  );
}

/**
 * The function literal of the integrand of `Integrate` when no limit names
 * a variable (`Integrate(√x, Limits(Nothing, 0, 1))`), or `undefined` to
 * keep `fn`, the literal that `canonicalFunctionLiteral()` made from the
 * unknowns of `integrand`.
 *
 * The parameters are the implicit variables: the first symbols of the body
 * in sorted order (`implicitVariableCandidates`), one for each limit that
 * names no variable. A symbol with an assigned value is a candidate, so the
 * order of boxing and assignment does not change the variables: after
 * `x := 4`, the parameter of `√x` is `x`, and the integral is 2/3. When
 * nothing has a value and there is one symbol for each limit, the
 * parameters are those of `fn`. The other symbols are free, as in the
 * implicit form of `Limit`: with `Function(x·y, x, y)` and one limit, `y`
 * was a parameter that the integral never binds, and compiled code read the
 * value of `y` where the interpreter kept the symbol `y`.
 *
 * A bare-symbol integrand, a `Function` literal and a literal with
 * anonymous slots (`_`) keep `fn`, because they name their own parameters
 * or are not a literal.
 */
function implicitLiteralParameters(
  ce: ComputeEngine,
  integrand: Expression,
  fn: Expression,
  limits: ReadonlyArray<Expression>
): Expression | undefined {
  if (
    isSymbol(integrand) ||
    isFunction(integrand, 'Function') ||
    !isFunction(fn, 'Function')
  )
    return undefined;
  const params = fn.ops.slice(1).map((p) => functionLiteralParameterName(p));
  if (params.some((p) => p === '' || ANONYMOUS_SLOT_NAMES.has(p)))
    return undefined;
  const count = limits.filter(
    (l) => isFunction(l, 'Limits') && sym(l.op1) === 'Nothing'
  ).length;
  if (count === 0) return undefined;
  const chosen = implicitVariableCandidates(fn.op1).slice(0, count);
  if (
    chosen.length === params.length &&
    chosen.every((v, i) => v === params[i])
  )
    return undefined;
  // No candidate (every symbol of the body cannot hold a number, as `L` in
  // `Length(L)` with `L: list<integer>`): the literal has no parameter, and
  // its symbols keep their values. `canonicalFunctionLiteral()` reads an
  // empty parameter list as "infer the parameters", and would bind `L`.
  if (chosen.length === 0)
    return canonicalFunctionLiteralArguments(ce, [integrand]);
  return canonicalFunctionLiteral(integrand, {
    params: chosen.map((v) => ce.symbol(v, { canonical: false })),
  });
}

/**
 * The numeric limit of the function literal `f` at the point `x`, by
 * Richardson extrapolation, as a float. `undefined` when the point has no
 * numeric value; `NaN` when the samples do not converge.
 *
 * A function with no non-real constant is sampled as a real function, with
 * compiled machine arithmetic when the body compiles. A function with a
 * non-real constant (`t ↦ Gamma(i·t)`) can take complex values: the
 * extrapolation works on real samples, so the real part and the imaginary
 * part are extrapolated separately, and the limit exists when both
 * converge. Its samples come from the interpreter, because a compiled
 * function answers `NaN` for some functions of a complex argument (`Gamma`).
 */
function numericLimitValue(
  engine: ComputeEngine,
  f: Expression,
  x: Expression,
  dir: Expression | undefined
): Expression | undefined {
  const point = x.N();
  let target = point.re;
  if (Number.isNaN(target)) return undefined;
  // The extrapolation samples the function at real arguments only. At a
  // point that is not real it would sample near the real part of the point
  // and answer a wrong value: `lim_{x→i} 1/(x² + 1)` gave `1`, the value at
  // 0. A limit at such a point is declined.
  if (point.im !== 0 && !Number.isNaN(point.im)) return undefined;
  const direction = dir ? dir.re : 1;

  // The extrapolation reaches an infinite point through positive arguments
  // only. A limit at `−∞` is the limit of `t ↦ f(−t)` at `+∞`.
  const mirrored = target === -Infinity;
  if (mirrored) target = Infinity;
  const at = (t: number): number => (mirrored ? -t : t);

  if (!hasNonRealConstant(f)) {
    // The iteration budget keeps a single sample on the extrapolation
    // ladder interruptible: an unbudgeted compiled Sum/Product with a
    // variable-dependent bound runs an arbitrarily long loop that no
    // deadline check can reach (see LIMIT_PROBE_ITERATION_BUDGET).
    const compiled = implicitCompile(engine, f, 'nlimit', {
      iterationBudget: LIMIT_PROBE_ITERATION_BUDGET,
    });
    const run = compiled?.run as ((x: number) => number) | undefined;
    // A compiled `Loop` throws over the budget, where a `Sum` gives `NaN`. Both
    // read as `NaN` here, the signal the ladder stops at. The host did not set
    // this budget, so the throw does not reach it. An interpreted sample
    // (`applicableN1`) keeps its own limit and its own error.
    const fn =
      run === undefined
        ? applicableN1(f)
        : (x: number): number => {
            try {
              return run(x);
            } catch (e) {
              if (isIterationLimitCancellation(e)) return NaN;
              throw e;
            }
          };
    // A numeric limit is a float, even when its value is an integer
    return engine.number(
      engine._inexactNumericValue(
        limit((t) => fn(at(t)), target, direction, engine._deadline) + 0
      )
    );
  }

  // Each sample is evaluated once and read twice (real part, imaginary part).
  const apply = applicable(f);
  const samples = new Map<number, [re: number, im: number]>();
  const sample = (t: number): [re: number, im: number] => {
    let v = samples.get(t);
    if (v === undefined) {
      const y = apply([engine.number(at(t))])?.N();
      v = y === undefined || !isNumber(y) ? [NaN, NaN] : [y.re, y.im];
      samples.set(t, v);
    }
    return v;
  };
  const re = limit((t) => sample(t)[0], target, direction, engine._deadline);
  const im = Number.isNaN(re)
    ? NaN
    : limit((t) => sample(t)[1], target, direction, engine._deadline);
  if (Number.isNaN(re) || Number.isNaN(im)) return engine.NaN;
  // A numeric limit is a float, even when both parts are integers.
  return engine.number(
    engine._inexactNumericValue(im === 0 ? re + 0 : { re, im })
  );
}

export const CALCULUS_LIBRARY: SymbolDefinitions[] = [
  {
    /* @todo
    ## Definite Integral
`\int f dx` -> ["Integrate", "f", "x"]

`\int\int f dxdy` -> ["Integrate", "f", "x", "y"]

Note: `["Integrate", ["Integrate", "f" , "x"], "y"]` is equivalent to
`["Integrate", "f" , "x", "y"]`


`\int_{a}^{b} f dx` -> ["Integrate", f, [x, a, b]]
`\int_{c}^{d} \int_{a}^{b} f dxdy` -> ["Integrate", "f", ["Triple", "x", "a",
"b"], ["Triple", "y", "c", "d"]]

`\int_{a}^{b}\frac{dx}{f}` -> ["Integrate", ["Power", "f", -1], ["Triple", "x",
"a", "b"]]

`\int_{a}^{b}dx f` -> ["Integrate", "f", ["Triple", "x", "a", "b"]]

If `[a, b]` are numeric, numeric methods are used to approximate the integral.

## Domain Integral

`\int_{x\in D}` -> ["Integrate", f, ["In", x, D]]

### Contour Integral

`\oint f dx` -> `["ContourIntegral", "f", "x"]`

`\varointclockwise f dx` -> `["ClockwiseContourIntegral", "f", "x"]`

`\ointctrclockwise f dx` -> `["CounterclockwiseContourIntegral", "f", "x"]`

`\oiint f ds` -> `["DoubleCountourIntegral", "f", "s"]` : integral over closed
surfaces

`\oiiint` f dv -> `["TripleCountourIntegral", "f", "v"]` : integral over closed
volumes

`\intclockwise`

`\intctrclockwise`

`\iint`

`\iiint`
*/

    // @todo: review the following
    // - https://index.scala-lang.org/cascala/galileo
    // - https://symbolics.juliasymbolics.org/stable/
    // - https://github.com/symengine/SymEngine.jl

    //
    // Functions
    //

    //
    // **Derivative**
    //
    // Returns a function that represents the derivative of the
    // given function.
    //
    // In contrast to the `D` function, the `Derivative` function
    // returns a function that represents the derivative of the given
    // function, rather than the result of evaluating the derivative
    // at a given point.

    // `['Derivative', f]` < = > `["D", ["Apply", f, "x"], "x"]`
    //
    //
    // ["Derivative", "Sin"]
    //    -> "Cos"
    //
    // ["Derivative", ["Function", ["Square", "x"], "x"], 2]
    //    -> "2"
    //
    // The argument "2" of the `Derivative` function indicates the order
    // of the derivative.
    //
    //
    // @todo: consider Fractional Calculus, i.e. Louiville-Riemann derivative
    // https://en.wikipedia.org/wiki/Fractional_calculus
    // with values of the order that can be either fractional or negative
    //
    Derivative: {
      description: 'Derivative operator that returns a derivative function.',
      keywords: ['differentiate'],
      broadcastable: false,

      lazy: true,
      // The order argument is a multi-index: one differentiation order per
      // argument of the function. A single order is the ordinary (univariate)
      // n-th derivative; `Derivative(f, 1, 0)` is ∂f/∂arg₁ of a bivariate f.
      signature: '(function, order:number*) -> function',
      type: ([fn], { engine }) => {
        // A derivative function has the same signature as the function it
        // derives (same parameters and codomain). Preserving it lets an
        // application — `Apply(Derivative(f, 1), x)`, the parse of `f'(x)` —
        // type as the function's return type instead of `any`.
        const t = fn?.type;
        const result = t !== undefined ? functionResult(t) : undefined;
        if (result !== undefined && result !== 'any' && result !== 'unknown')
          return BoxedType.forResult(engine.type(t!), engine._typeResolver);
        // A function declared with parameters and the codomain `any`
        // (`(real) -> any`) says that its value can be anything, a matrix
        // included: its derivative keeps that codomain, so that a product
        // with the derivative keeps the order of its factors. A bare
        // `function` has the variadic signature `(any*) -> any`, which says
        // nothing and takes the number-valued fallback below.
        if (
          result === 'any' &&
          t !== undefined &&
          typeof t !== 'string' &&
          t.kind === 'signature' &&
          t.variadicArg === undefined
        )
          return BoxedType.forResult(engine.type(t), engine._typeResolver);
        // The DECLARED type is uninformative, but the symbol may nevertheless
        // hold a function literal whose codomain is known: a head declared as
        // a bare `function` and only then assigned `(t) ↦ (cos t, sin 2t, t)`
        // keeps the declared `function` as its contract, so the branch above
        // sees `unknown` while the assigned lambda types
        // `(unknown) -> tuple<…>`. Reading the value's own type here is what
        // stops the fallback below from committing a SCALAR result the
        // evaluation then contradicts — `f'(0.25)` typed `number` while `.N()`
        // returned a 3-tuple, and every type-strict consumer (`Cross`, `Dot`)
        // rejected the call with `incompatible-type` (Tycho item 210).
        const valueType =
          fn !== undefined ? heldValueTypeOf(fn, engine) : undefined;
        if (
          valueType !== undefined &&
          typeof valueType !== 'string' &&
          valueType.kind === 'signature'
        ) {
          const valueResult = functionResult(valueType);
          if (
            valueResult !== undefined &&
            valueResult !== 'any' &&
            valueResult !== 'unknown'
          )
            return BoxedType.forResult(
              engine.type(valueType),
              engine._typeResolver
            );
        }
        // Neither the declaration nor a held value says what the function
        // returns (e.g. a symbol declared plain `function` and never
        // assigned, whose type is `(any*) -> any`). Its derivative is still
        // scalar-valued in the overwhelmingly common case, so report a
        // number-valued function — the same compromise as the `D` type
        // handler below — rather than passing the `any` through, which would
        // type applications as `any`.
        return BoxedType.forResult(
          engine.type('(any*) -> number'),
          engine._typeResolver
        );
      },
      canonical: (ops, { engine }) => {
        // The function operand is required: a missing one is the standard
        // `Error("missing")` operand, as `checkArity` pads it, not a crash.
        if (ops.length === 0)
          return engine._fn('Derivative', [engine.error('missing')]);
        const fn = canonicalFunctionLiteral(ops[0].canonical);
        if (!fn) return null;
        // A bare symbol here is being used as a function (e.g. `y` in
        // `Apply(Derivative(y, 2), x)` from parsing `y''(x)`): infer its type
        // so later uses in the same expression — like the `y(x)` term of an
        // ODE, parsed as an invisible product while `y` was still unknown —
        // canonicalize to a function application, exactly as an
        // operator-position use (`["y", "x"]`) would have inferred it.
        if (isSymbol(fn)) fn._infer(() => 'function');
        const orders = ops.slice(1).map((o) => {
          const order = o.canonical;
          // A symbolic order — `f^{(n)}`, documented as `Derivative(f, n)` —
          // is a free variable used as a number: infer it, as the function
          // symbol above is inferred, instead of rejecting its still-`unknown`
          // type with `incompatible-type`.
          // Fact-blind: the guard reads the order's EFFECTIVE type, and an
          // assumption that gives it a tier must not decide whether this
          // narrowing — a contract that outlives the assumption — is stored.
          engine._withoutFacts(() => {
            if (isSymbol(order) && order.type.isUnknown)
              order._infer(() => 'number');
          });
          return checkType(engine, order, 'number');
        });
        return engine._fn('Derivative', [fn, ...orders]);
      },
      evaluate: (ops, { engine: ce }) => {
        const op = ops[0].evaluate();
        let orders = ops.slice(1).map((o) => o.N().re);
        // An order that is not a number yet (`Derivative(f, n)` with `n`
        // unassigned) has no closed form: stay inert. Reading it as 1 silently
        // made `f^{(n)}` the FIRST derivative.
        // A negative or fractional order is not an order of differentiation
        // (fractional calculus and antiderivatives are not implemented), so
        // the node stays inert too, as `D(f, {x, n})` does for such an `n`.
        // Rounding the order down gave a derivative of the wrong order:
        // `Derivative(Power, -1, 1)` was read as `Derivative(Power, 0, 1)`
        // and `Derivative(g, 1.5)` as `Derivative(g, 1)`.
        if (orders.some((n) => !Number.isInteger(n) || n < 0)) return undefined;
        // Each unit of order is one differentiation pass, and each pass keeps
        // its result (the iterates of `derivative()`, the nested `D` tree of
        // the multi-index arm). The work and the memory thus scale with the
        // VALUE of the orders: `Derivative(Power, 1000000000, 0)` used up the
        // heap before any deadline check ran. Above the cap that
        // `D(f, {x, n})` also uses, the node stays inert.
        if (orders.reduce((sum, n) => sum + n, 0) > MAX_DERIVATIVE_ORDER)
          return undefined;

        // The number of orders must agree with the number of parameters of
        // the function: the parameters of the function literal that `op` is,
        // or that it is bound to, or else the fixed number of arguments of
        // the signature of the operator `op` names (an operator with optional
        // or variadic arguments, such as `Log` or `Add`, has no fixed number
        // and is not checked). More orders than parameters name no partial
        // derivative: the node stays inert. Before, the operator branch below
        // applied the function to one fresh symbol for each order and the
        // application threw ("Too many arguments") for
        // `Derivative(h, 1, 0, 0)` with `h(x, y)`.
        //
        // Fewer orders than parameters are padded with order 0, the same
        // convention that `differentiate()` uses for
        // `Apply(Derivative(f, α), …)`: `g'(x, y)` parses to
        // `Apply(Derivative(g, 1), x, y)`, the partial in the first
        // argument. A bare `Derivative(g)` is order 1 in the first argument.
        // For a symbol bound to a literal of several parameters, the
        // univariate arm applied the symbol to one hole and gave a wrong
        // closed form: `(x) => x^2` for `h(x, y) := x^2 y`. For an operator
        // of several arguments (`Arctan2`, `Power`, an operator with a
        // `derivative` key for each of two parameters), the univariate arm
        // has no derivative and the node stayed inert, while
        // `Derivative(Arctan2, 1, 0)` evaluated. An inline literal with one
        // order already differentiates in its first parameter in the
        // univariate arm, so it is not padded.
        const keyed =
          isSymbol(op) && op.operatorDefinition?.derivative !== undefined;
        const literal = isSymbol(op) ? functionLiteralOf(ce, op.symbol) : op;
        let arity: number | undefined;
        if (isFunction(literal, 'Function')) arity = literal.nops - 1;
        else if (isSymbol(op)) {
          const sig = op.operatorDefinition?.signature.type;
          if (
            sig !== undefined &&
            typeof sig !== 'string' &&
            sig.kind === 'signature' &&
            sig.optArgs === undefined &&
            sig.variadicArg === undefined
          )
            arity = sig.args?.length ?? 0;
        }
        if (arity !== undefined && orders.length > arity) return undefined;
        // Differentiating zero times in every position is the function
        // itself — univariate `Derivative(g, 0)` and multi-index
        // `Derivative(g, 0, 0)` alike. Left to the lifting below, a head that
        // is not already a `Function` literal (a bare symbol, or an
        // operator-defined name such as `Sin`) came back as the constant
        // function returning that head (`Derivative(g, 0)` → `(x) ↦ g`): the
        // order-0 "derivative" is the head itself, which the univariate arm
        // then re-parameterized over its value's parameters. This check
        // comes after the arity check above: `Derivative(Sin, 0, 0)` has
        // more orders than `Sin` has arguments and stays inert, it is not
        // `Sin`.
        if (orders.length >= 1 && orders.every((n) => n === 0)) return op;
        let padded = false;
        if (
          arity !== undefined &&
          arity >= 2 &&
          orders.length < arity &&
          (orders.length >= 2 || isSymbol(op))
        ) {
          const given = orders.length === 0 ? [1] : orders;
          orders = [...given, ...new Array(arity - given.length).fill(0)];
          padded = true;
        }

        // Univariate (bare or single order): ordinary n-th derivative.
        //
        // The closed-form result is lifted into a *named-parameter* `Function`
        // literal (P1-19c): a bare hole-form (`cos(_)`) typed `number`,
        // so a stored `let g = Derivative(f)` was not callable. The historical
        // blockers are addressed by construction:
        // - a result that holds a `Derivative` of the same function stays
        //   inert — as a literal, its body would evaluate this node again at
        //   each application. A result that holds the `Derivative` of
        //   another function is lifted like any other closed form;
        // - the hole is renamed to a real parameter, so no `_` reaches the
        //   serializers (the `()\mapsto…` mis-rendering) or the
        //   `denotesFunction` wildcard gate.
        //
        // The whole arm is memoized: lifting the closed form into a literal
        // declares its parameter, and that declaration makes the cache of
        // `derivative()` miss on the next request (see
        // `memoizedDerivativeResult`).
        //
        // The hole `_` that `derivative()` applies an operator symbol to, and
        // the parameter that replaces it, are declared in a scope that is
        // discarded afterwards. Without that scope, `derivative()` and
        // `ce.symbol()` declared them in the caller's scope, with the type
        // that the operator inferred (`number` for the argument of `Sin`).
        // That type then applied to every later use of `x` and `_`: after
        // `Derivative(Sin)` was evaluated, `x && True` was an error.
        //
        // The parameters of the function literal are bound by the literal:
        // a variable of the same name that has a value where the derivative
        // is evaluated (a global `a := [1, 2]`, or the parameter `a` of the
        // function whose body holds `Derivative(a ↦ a^2)`) is another
        // variable. But an occurrence of a parameter read outside a call of
        // the literal reads that value by name, and the arithmetic that
        // builds the derivative reads it too: `2·a` became `[2, 4]`, so the
        // derivative of `a ↦ a^2` was the constant function `a ↦ [2, 4]`.
        // The parameters are shielded from such a value while the body is
        // differentiated (`withValueShield`).
        //
        // A called function can read a free name equal to a parameter
        // (`a ↦ h(a)` with `h := x ↦ a·x`). The shield cannot separate the
        // two, because it works by name, so that body is differentiated in
        // terms of holes (`literalBodyOverHoles()`).
        const boundParams = isFunction(literal, 'Function')
          ? literal.ops
              .slice(1)
              .map((p) => functionLiteralParameterName(p))
              .filter((name) => name !== '')
          : [];
        if (orders.length <= 1) {
          const order = orders[0] ?? 1;
          return memoizedDerivativeResult(op, order, () => {
            const params = isFunction(op, 'Function') ? op.ops.slice(1) : [];
            const holes = parameterHoles(params.length);
            ce.pushScope();
            let r: Expression | undefined;
            let bodyOverHoles: Expression | undefined;
            try {
              for (const hole of holes) ce.declare(hole, 'unknown');
              r = withValueShield(ce, boundParams, () => {
                const found = literalBodyOverHoles(op, holes);
                if (found === 'decline') return undefined;
                bodyOverHoles = found;
                return derivative(op, order, bodyOverHoles);
              });
            } finally {
              ce.popScope();
            }
            if (r === undefined) return undefined;
            // Order 0 (or an already-lifted result) is the function itself.
            // A function literal that holds a hole is not lifted yet.
            if (isFunction(r, 'Function') && !bodyOverHoles) return r;
            // An INCOMPLETE closed form — a `D` the symbolic differentiator
            // could not resolve is left inside the body, such as the
            // derivative of the norm of a point-valued function inside the
            // quotient rule for `t ↦ f'(t)/|f'(t)|` — is no closed form: the
            // node stays inert, so an application of it stays an `Apply` and
            // `N()` answers it through the stencil fallback
            // (`numericDerivativeOfApply`), as the compiled JavaScript target
            // already does for the same application. Returned bare or lifted
            // into a function literal instead, the residue reached every
            // consumer as a symbolic `D(…)` that no route could numericize.
            // (Checked before the `Derivative`-carrying case below: such a
            // body may hold a legitimate `Apply(Derivative(f, 2), t)` beside
            // the unresolved `D`.)
            if (holdsUnresolvedD(r)) return undefined;
            if (r.operator === 'Derivative') return r;
            // A closed form that holds a `Derivative` of the function itself
            // (`Apply(Derivative(f, 1), _)` for a recursive `f`) stays
            // inert. As a function literal, its body would evaluate this
            // node again at each application, without end.
            if (
              r
                .getSubexpressions('Derivative')
                .some((d) => isFunction(d) && d.op1.isSame(op))
            )
              return undefined;
            // A closed form that holds the `Derivative` of another function
            // (`x·g′(x) + g(x)` for `h(x) := x·g(x)` with `g` not defined) is
            // made a function literal below, as a complete closed form is.
            // Its body evaluates that other `Derivative` when the literal is
            // applied.

            if (bodyOverHoles)
              return literalWithParameters(ce, r, holes, params);

            // A named-parameter function literal: the derivative was taken with
            // respect to its own (first) parameter, so the body is already in
            // terms of the named parameters — preserve the signature.
            if (isFunction(op, 'Function')) {
              if (
                params.length > 0 &&
                params.every((p) => functionLiteralParameterName(p) !== '')
              )
                // `ce.function()` (not `_fn`): the canonical handler wraps the
                // body in the scoped Block that `makeLambda` requires.
                return ce.function('Function', [r, ...params]);
            }

            // Otherwise the body is in terms of the hole `_` (an operator
            // symbol such as `Sin`): rename the hole to a fresh parameter that
            // collides with no free variable or binder name of the body.
            let name = 'x';
            if (r.has(name) || collectBinderNames(r).has(name)) {
              let i = 1;
              while (r.has(`x_${i}`) || collectBinderNames(r).has(`x_${i}`))
                i += 1;
              name = `x_${i}`;
            }
            return functionLiteralOverHoles(ce, r, ['_'], [name]);
          });
        }

        // Multi-index: mixed partial of a multivariate function. For a known
        // function literal, differentiate the body the requested number of
        // times with respect to each parameter; otherwise stay symbolic.
        // A symbol bound to a function literal is differentiated through
        // that literal, as the univariate arm does inside `derivative()`;
        // the literal is what carries the named parameters the multi-index
        // refers to. Without this, `Derivative(g, 1, 0)` stayed inert for an
        // assigned bivariate `g` while `Derivative(g, 1)` evaluated.
        // An operator whose definition has a `derivative` key is handled by
        // the next block: the key has precedence over its function literal.
        // The arm is memoized per function and order vector, as the
        // univariate arm is (see `memoizedPartialDerivative`).
        const partial = memoizedPartialDerivative(
          op,
          keyed ? undefined : literal,
          orders,
          () => {
            // The literal can be stored in a non-canonical form: an
            // `evaluate` handler given as MathJSON is boxed raw. Canonicalize
            // it (in its captured scope, as the `lambda` getter of an
            // operator definition does) before differentiating its body:
            // `differentiate()` builds products and sums, which take only
            // canonical operands. The raw literal stays the key of the memo
            // above, because it is the object that the definition keeps.
            const canonical =
              !keyed && isFunction(literal, 'Function')
                ? literal.canonical
                : undefined;
            if (isFunction(canonical, 'Function')) {
              const params = canonical.ops
                .slice(1)
                .map((p) => functionLiteralParameterName(p));
              if (params.length === orders.length && params.every((p) => !!p)) {
                let body: Expression | undefined = canonical.op1;
                const holes = parameterHoles(params.length);
                let overHoles = false as boolean;
                ce.pushScope();
                try {
                  for (const hole of holes) ce.declare(hole, 'unknown');
                  withValueShield(ce, boundParams, () => {
                    const found = literalBodyOverHoles(canonical, holes);
                    if (found === 'decline') {
                      body = undefined;
                      return;
                    }
                    overHoles = found !== undefined;
                    body = found ?? body;
                    const variables = overHoles ? holes : params;
                    for (let i = 0; i < orders.length && body; i++)
                      for (let d = 0; d < orders[i] && body; d++)
                        body = differentiate(body, variables[i]!);
                  });
                } finally {
                  ce.popScope();
                }
                // A body that holds a `D` the symbolic differentiator could
                // not resolve (the partial of `Round(x, y)` in `y`) is no
                // closed form: the node stays inert, as in the univariate arm
                // and the operator branch below. Made a function literal, the
                // `D` kept its variable free: an application substituted the
                // other arguments and lost the one of the differentiation
                // variable (`D(Round(1.5, y), y)` for the arguments 1.5, 2).
                if (body && holdsUnresolvedD(body)) return undefined;
                if (body && overHoles)
                  return literalWithParameters(
                    ce,
                    body,
                    holes,
                    canonical.ops.slice(1)
                  );
                // `ce.function()` (not `_fn`): the canonical handler wraps the
                // body in the scoped Block that `makeLambda` requires — a bare
                // `_fn` literal throws on application.
                if (body)
                  return ce.function('Function', [
                    body,
                    ...canonical.ops.slice(1),
                  ]);
              }
            }

            // Any other operator: a library operator (`Log`, `Power`, `Mod`,
            // `Arctan2`, …), or an operator whose definition has a `derivative`
            // key (see `OperatorDerivative`, types-definitions.ts). Apply the
            // operator to one fresh symbol for each argument, differentiate the
            // application with `D` (which uses the rules of `differentiate()` for
            // the library operators, and the key when there is one) the requested
            // number of times in each symbol, then make the result a function
            // literal of fresh parameters. This is the n-argument form of the
            // univariate arm above, which differentiates the application `f(_)`.
            //
            // When a partial derivative does not close (the result still holds a
            // `Derivative`, such as the derivative of `BesselJ` in its order, or
            // an unresolved `D`), or the operator does not take this number of
            // arguments, the node stays inert. A lazy operator holds its operands
            // (they are conditions, bodies or bound indexes, not arguments), so
            // it has no partial derivatives and stays inert too. `Add` and
            // `Multiply` are the exceptions: they are lazy only so that they
            // canonicalize their own operands, which are ordinary values, and
            // `differentiate()` has the sum and product rules for them.
            //
            // The fresh symbols are declared in scopes that are discarded
            // afterwards: the scope of each `D`, and the scope pushed below.
            // Without these scopes, they were declared in the caller's
            // scope, with the type that the first operator applied to them
            // inferred (`real` for the arguments of `Arctan2`). That type then
            // applied to every later use of these names.
            const opDef = isSymbol(op) ? op.operatorDefinition : undefined;
            if (
              isSymbol(op) &&
              opDef !== undefined &&
              (!opDef.lazy ||
                op.symbol === 'Add' ||
                op.symbol === 'Multiply') &&
              orders.reduce((sum, n) => sum + n, 0) <= MAX_NESTED_PARTIAL_ORDER
            ) {
              const names = orders.map((_, i) => `_${i + 1}`);
              let body: Expression | undefined;
              // The partial derivative is computed as the nested `D` expression
              // `D(…D(D(f(_1, …, _n), _1), _1)…, _n)`, one `D` for each
              // differentiation, the first symbol innermost. It is boxed from
              // MathJSON, so each `D` declares its variable in its own scope, and
              // the free symbols of the inner application refer to those
              // declarations. The result is then the same as for the nested `D`
              // that a user writes, and the cost is the same too. Each `D`
              // evaluates its result before the next `D` differentiates it.
              //
              // A chain of `differentiate()` calls on symbols declared in the
              // scope below gives the same closed form at about 2 to 2.5 times
              // the cost (`Derivative(Arctan2, 3, 3)`): the
              // time went to deriving the types of the new intermediate
              // expressions (union-type reductions and subtype tests), not to the
              // differentiation rules.
              let nested: MathJsonExpression = [op.symbol, ...names];
              for (let i = 0; i < orders.length; i++)
                for (let d = 0; d < orders[i]; d++)
                  nested = ['D', nested, names[i]];
              ce.pushScope();
              try {
                const node = ce.box(nested);
                if (node.isValid) body = node.evaluate();
              } finally {
                ce.popScope();
              }
              if (
                body &&
                body.isValid &&
                !holdsUnresolvedD(body) &&
                !body.has('Derivative')
              ) {
                const binders = collectBinderNames(body);
                const used = (name: string) =>
                  body!.has(name) || binders.has(name);
                const params: string[] = [];
                let k = 1;
                for (let i = 0; i < names.length; i++) {
                  while (used(`x_${k}`)) k += 1;
                  params.push(`x_${k}`);
                  k += 1;
                }
                const literal = functionLiteralOverHoles(
                  ce,
                  body,
                  names,
                  params
                );
                if (literal !== undefined) return literal;
              }
            }
            return undefined;
          }
        );
        if (partial !== undefined) return partial;

        // A padded order vector is not written back: the node stays as given.
        if (padded) return undefined;
        return ce._fn('Derivative', [op, ...orders.map((n) => ce.number(n))]);
      },
      compile: (args, compile, context) =>
        compileDerivative('Derivative', args, compile, context),
    },

    //
    // **D: Partial derivative**
    //
    // Returns the partial derivative of a function with respect to a
    // variable.
    //
    // ["D", "Sin", "x"]
    //    -> ["Cos", "x"]
    //
    // This is equivalent to `["Apply", ["Derivative", "Sin"], "x"]`

    D: {
      description:
        'Symbolic partial derivative with respect to one or more variables.',
      keywords: ['differentiate'],
      broadcastable: false,

      // The differentiation variables are operands 1..n. They used to be bound
      // wherever the CALLER had them — this operator's scope was minted and
      // never populated — so the parse route (raw) and the `ce.function` route
      // (the caller's binding) disagreed about the same derivative. The
      // `withValueShield` at evaluate is unaffected and stays (stage 14).
      operands: operandRolesFrom([RAW_ROLE], BOUND_ROLE),
      lazy: true,
      signature: '(expression, variables:symbol*) -> expression',
      type: ([body], { engine }) => {
        if (!body) return undefined;
        // The derivative of a numeric expression is numeric — preserve the
        // numeric tier (e.g. `number` for `D(Sin(x),x)`), without the range
        // of the body: `Abs(x)` is `real<0..>`, and its derivative is `-1`
        // for a negative `x`.
        const t = stripNumericRanges(body.type);
        if (isSubtype(t, 'number'))
          return BoxedType.forResult(t, engine._typeResolver);
        // A numeric TUPLE or COLLECTION body differentiates component-wise and
        // the result keeps that shape: `D((cos t, sin 2t, t), t)` evaluates to
        // `(-sin t, 2cos 2t, 1)`, and `D([cos t, sin t], t)` to a list. The
        // scalar fallback below claimed `number` for both, so the declared
        // type contradicted the value the same handler produced, and a
        // type-strict consumer (`Cross`, `Dot`) rejected the derivative of a
        // parametric curve outright (Tycho item 210). Echoing the body's type
        // follows the same tier convention as the numeric branch above.
        if (typeCouldBeNumericTuple(t) || typeCouldBeNumericCollection(t))
          return BoxedType.forResult(t, engine._typeResolver);
        // A derivative is otherwise scalar-valued: report `number` rather than
        // the signature's `expression`. This covers the derivative of an
        // application of an undeclared function (`y(x)` has type `any`), a
        // nested `D` (`D(D(y(x),x),x)` has type `expression`), and a function
        // literal with an unknown codomain (`\dot{x}` → `D((t)↦x, t)`, type
        // `(unknown) -> unknown`). Without this, such a `D(…)` term inside
        // `Add`/`Multiply` is rejected and rewritten to an `Error` node,
        // corrupting parsed input like `y''(x) + y(x) = 0` before `DSolve`
        // ever runs — and leaving inconsistent trees (a bare application
        // `y(x)` already reports `any` and composes fine there).
        return BoxedType.forResult(engine.type('number'), engine._typeResolver);
      },
      canonical: (ops, { engine: ce, scope }) => {
        // Guard against a malformed `D` with no operand. This can arise when
        // upstream parsing drops the argument (e.g. `D\left[1\right]` from a
        // Desmos list-index expression collapses to `["D"]`). Without an
        // expression to differentiate there is nothing to canonicalize;
        // return null so the caller produces a non-canonical fallback rather
        // than throwing a `Cannot read properties of undefined` error on
        // `ops[0].canonical` below.
        if (!ops[0]) return null;

        // A `Return` in an operand has no function to end (ROADMAP CE-96).
        const returnError = canonicalWithEscapingReturn(ce, 'D', ops);
        if (returnError) return returnError;

        // Mathematica-style higher-order spec: `D(f, {x, n})`, or
        // `D(f, [x, n])` (`isOrderSpec()`) → the n-th derivative with respect
        // to `x` (`D(f, x, x, …, x)`, n repetitions).
        // POSITIONAL — only a raw held `{symbol, integer}` pair in the
        // variable slot is read; any other `Set` shape is left untouched.
        // - An order of 0 is no differentiation in `x`: the pair is removed,
        //   and when no variable is left the result is `f` itself
        //   (`D(f, {x, 0})` is `f`, as in Mathematica).
        // - A negative order is an error.
        // - A symbolic order, a non-integer order, and an order above the
        //   maximum leave the pair as it is: the derivative stays inert (see
        //   below).
        // The order must be a number LITERAL, and its integer and zero status
        // is decided exactly on that literal. A symbol is never replaced by
        // its assigned value here: canonicalization would then remove the
        // pair for good, and a later assignment to the symbol could not bring
        // it back. A double approximation of the order is not used either:
        // it underflows an exact nonzero order such as `1/10^400` to `0`.
        if (ops.length > 1 && ops.slice(1).some(isOrderSpec)) {
          const expanded: Expression[] = [ops[0]];
          for (const o of ops.slice(1)) {
            if (isOrderSpec(o) && o.nops === 2 && isSymbol(o.op1)) {
              const order = o.op2.canonical;
              if (isNumber(order) && order.isInteger === true) {
                if (order.isSame(0)) continue;
                const n = order.re;
                if (order.isNegative === true) {
                  expanded.push(
                    ce.error('expected-positive-integer', o.op2.toString())
                  );
                  continue;
                }
                // The expansion, and the differentiation it asks for, scale
                // with the VALUE of `n`; past the cap the pair is left as it
                // is, so the derivative stays inert rather than unbounded.
                if (n <= MAX_DERIVATIVE_ORDER) {
                  for (let k = 0; k < n; k++) expanded.push(o.op1);
                  continue;
                }
              }
            }
            expanded.push(o);
          }
          if (expanded.length === 1) return ops[0].canonical;
          ops = expanded;
        }

        // A variable `Subscript(x, 1)` is the symbol `x_1`
        // (`subscriptVariableAsSymbol()`).
        if (ops.slice(1).some((v) => isFunction(v, 'Subscript')))
          ops = [ops[0], ...ops.slice(1).map(subscriptVariableAsSymbol)];

        // A function literal of the differentiation variable, `D(x ↦ body, x)`,
        // is the derivative of its body: `evaluate` differentiates the body
        // and ignores the parameter, so `D(Function(Block(a+b), x), x)` and
        // `D(a+b, x)` have the same value. Both are written
        // `\frac{\mathrm{d}(a+b)}{\mathrm{d}x}`, which parses back as the
        // second, so the first is rewritten to it here, and the round trip
        // keeps the tree (Tycho ledger row 391). A body of one statement is
        // that statement; a block with locals stays a `Block`. A body that is
        // a single symbol keeps the function literal: that is the canonical
        // form of `\frac{\mathrm{d}f}{\mathrm{d}x}` itself (see
        // `canonicalFunctionLiteralArguments` below).
        if (
          ops.length >= 2 &&
          isFunction(ops[0], 'Function') &&
          ops[0].nops === 2 &&
          isSymbol(ops[0].op2) &&
          isSymbol(ops[1]) &&
          ops[0].op2.symbol === ops[1].symbol
        ) {
          let body = ops[0].op1;
          if (
            isFunction(body, 'Block') &&
            body.nops === 1 &&
            body.op1.operator !== 'Declare' &&
            body.op1.operator !== 'Assign'
          )
            body = body.op1;
          // A body that is itself a function literal (a curried function)
          // is a function value: unwrapping the outer literal would let the
          // inner parameter out of its binder when `evaluate` unwraps the
          // inner one.
          if (!isSymbol(body) && !isFunction(body, 'Function'))
            ops = [body, ...ops.slice(1)];
        }

        // The differentiation variable may be omitted (`D(expr)`, e.g. from
        // `expr |> D`): default to the expression's single symbol, or to `x`
        // when there are several and one of them is `x`. A symbol with an
        // assigned value is a candidate too, so the variable does not depend
        // on whether the value was assigned before or after boxing
        // (`defaultImplicitVariable`). The variable becomes the parameter of
        // the function literal below, which hides the assigned value. The
        // candidates are read from the CANONICAL operand, as for `Series` and
        // `Limit`: in the held operand, an integral with no variable,
        // `Integrate(x·y, Limits(0, 1))`, is not yet in the form that tells
        // which symbol it binds, and `x` was read as free. A function symbol
        // (`D(f)`) is excluded — it is handled by the function-symbol branch
        // below, and must not have the inferred variable fed into its
        // argument list.
        //
        // A function symbol is a symbol with an operator definition
        // (`f(x) := 2x`) or a symbol whose DECLARED type is a function
        // (`ce.declare('f', 'function')`, with or without a value): the
        // second has a value definition, not an operator definition
        // (`isFunctionSymbolName()`). The LaTeX serializer uses the same
        // test to choose the spelling of `D(x ↦ f, x)`.
        const operand = ops[0];
        const isFunctionSymbol =
          isSymbol(operand) &&
          (operand.canonical.operatorDefinition !== undefined ||
            isFunctionSymbolName(ce, operand.symbol));
        if (ops.length === 1 && !isFunctionSymbol) {
          const v = defaultImplicitVariable(ops[0].canonical);
          if (v !== undefined) ops = [ops[0], ce.symbol(v)];
        }

        // An order pair that is left (a symbolic order, or an order above
        // the maximum) or an error in place of a variable keeps the
        // derivative inert, with the operand as it is. The branches below
        // need a symbol for each variable: a function symbol `f` was made a
        // function literal with the pair as a parameter, an
        // `expected-a-symbol` error.
        if (ops.slice(1).some((o) => isOrderSpec(o) || o.operator === 'Error'))
          return ce._fn('D', [ops[0].canonical, ...ops.slice(1)], { scope });

        // If the first argument is a function symbol (e.g., f where f(x):=2x),
        // apply it to the differentiation variables to produce a function call.
        // e.g., ['D', 'f', 'x'] → ['D', ['f', 'x'], 'x']
        if (isFunctionSymbol && isSymbol(ops[0])) {
          const vars = ops.slice(1);
          const fCall = ce.function(ops[0].symbol, vars);
          return ce._fn('D', [fCall, ...vars], { scope });
        }

        // If the first argument is already a function call (e.g., f'(x)
        // parsed as ['D', ['f', 'x'], 'x']), use it directly rather than
        // wrapping in Function(Block(...)).
        const op0 = ops[0].canonical;
        if (isFunction(op0) && op0.operator) {
          return ce._fn('D', [op0, ...ops.slice(1)], { scope });
        }

        // A function literal holds only symbols as parameters, so a body
        // with a variable `Subscript(x, k)` whose index is a symbol (`x_k` in
        // the body of `\sum_{k=1}^{2}`) stays as it is. The sum puts the
        // value of the index in each term, and the variable of the term is
        // then the symbol `x_1`. Until then, `evaluate` leaves the
        // derivative unevaluated, because the variable is not a symbol.
        if (ops.slice(1).some((v) => isFunction(v, 'Subscript')))
          return ce._fn('D', [op0, ...ops.slice(1)], { scope });

        const f = canonicalFunctionLiteralArguments(ce, ops);
        if (!f) return null;

        return ce._fn('D', [f, ...ops!.slice(1)], { scope });
      },
      evaluate: (ops, { engine: ce, expression, numericApproximation }) => {
        // Guard against a malformed `D` with no operand (see the canonical
        // handler above): there is nothing to differentiate, so leave it
        // unevaluated rather than crashing on `ops[0].canonical`.
        if (!ops[0]) return undefined;

        // A call whose head was declared as a data symbol after the call was
        // boxed: the derivative is the `expected-function` error that the
        // same expression boxed after the declaration gives, not
        // `Apply(Derivative(g, 1), x)` (`dataSymbolCallError()`).
        const refused = dataSymbolCallError(ce, expression);
        if (refused !== undefined) return refused;

        // A function that holds a residue class is not differentiated: a
        // class is not a real number, and the rules of differentiation do
        // not apply to it. The derivative stays unevaluated.
        if (holdsKindValue(ops[0].canonical)) return undefined;

        // The differentiation variable(s) are bound by `D`: a same-named global
        // assignment (`x := 5`) must not substitute into the result. Shield
        // them across the whole evaluation — the final `.evaluate()` of the
        // symbolic derivative would otherwise resolve the variable's value
        // (`D(x², x)` → `2x`, then `10`). Other free symbols still resolve
        // normally: with `a := 3`, `D(a·x², x)` → `6x`.
        const diffVars: string[] = [];
        for (const p of ops.slice(1)) {
          const n = sym(p);
          if (n) diffVars.push(n);
        }

        // A derivative is not worked out again while nothing it depends on
        // changed (see `withDerivativeMemo`): a derivative with no closed
        // form is its own node, and a closed form is the recorded one,
        // re-bound below as a new result is.
        const recorded = recordedDerivative(
          expression,
          numericApproximation === true
        );
        // A handler called with no `expression` has no record: `recorded`
        // is then `undefined`, and so is `expression`.
        if (recorded !== undefined && recorded === expression) return recorded;

        const result =
          recorded ??
          withDerivativeMemo(expression, numericApproximation === true, () => {
            // A parameter of the running call whose value does not vary
            // with a differentiation variable but holds a symbol with its
            // name is shielded too: its value is put in by the call, after
            // the derivative (`independentParameterNames`).
            const independent = independentParameterNames(
              ce,
              isFunction(ops[0].canonical, 'Function')
                ? ops[0].canonical.op1
                : ops[0].canonical,
              diffVars
            );
            return withValueShield(ce, [...diffVars, ...independent], () => {
              let f: Expression | undefined = ops[0].canonical;

              // Unwrap Function literals to get the body for differentiation.
              // For non-Function expressions (e.g., ['f', 'x']), do NOT call
              // .evaluate() before differentiating — that would prematurely
              // substitute variable values (e.g., x=5) and lose structural info.
              if (isFunction(f, 'Function')) {
                f = f.op1;
              }

              // A parameter of the running function call that holds an
              // expression of a differentiation variable is not constant in
              // that variable: in `g(f) = D(f, x)`, the call `g(x^2)` gives
              // `f` the value `x^2`, which `differentiate()` would not see
              // through the bare symbol and would take as 0 (CE-157).
              // A call of a parameter that holds a function is a call of
              // its value (`callOfFunctionParameter`).
              const replaced = new Set<string>();
              f = rewriteWithBinders(
                f,
                (s, shadowed) => {
                  if (shadowed?.has(s.symbol) || diffVars.includes(s.symbol))
                    return s;
                  const v = parameterActivationValue(ce, s);
                  return v !== undefined &&
                    diffVars.some((n) => parameterValueVariesWith(ce, v, n))
                    ? v
                    : s;
                },
                undefined,
                false,
                undefined,
                (app, appOps, shadowed) =>
                  callOfFunctionParameter(ce, app, appOps, shadowed, replaced)
              );

              return withOperandBindings(ce, f, replaced, () => {
                const params = ops.slice(1);
                if (params.length === 0) f = undefined;
                for (const param of params) {
                  const paramSym = sym(param);
                  if (!paramSym) {
                    f = undefined;
                    break;
                  }
                  f = differentiate(f!, paramSym);
                  if (f === undefined) break;
                }
                f = f?.canonical;
                // Avoid recursive evaluation
                if (f?.operator === 'D') return f;
                // Avoid evaluating symbolic derivative applications like Digamma'(x)
                // which would incorrectly evaluate to 0
                if (
                  f?.operator === 'Apply' &&
                  isFunction(f) &&
                  f.op1?.operator === 'Derivative'
                )
                  return f;
                // Fold the raw rule output: a plain `evaluate()`, except that a
                // result carrying symbolic transcendentals (like `ln(2)`) is
                // returned as it stands to preserve the symbolic form, and a
                // piecewise result is folded arm by arm.
                return f === undefined ? undefined : foldDerivativeResult(f);
              });
            });
          });
        // The memo recorded the decline: the node is its value.
        if (result === expression) return result;

        // A derivative is an OPEN expression in the differentiation variable,
        // which this node now binds in its own scope (the `bound` role of
        // operands 1..n).
        // Without this, `d/dx sin(x)` leaves the frame still referencing the
        // dying binding and compares unequal to a separately parsed `-sin(x)` —
        // the repair `Series` (stage 1) and `Integrate` (stage 5) both needed.
        return result === undefined
          ? undefined
          : rebindEscapingBinderResult(
              ce,
              result,
              diffVars,
              numericApproximation,
              expression
            );
      },
      compile: (args, compile, context) =>
        compileDerivative('D', args, compile, context),
    },

    // Evaluate a numerical approximation of a derivative at point x
    ND: {
      description: 'Numerical derivative evaluated at a point.',
      broadcastable: false,
      lazy: true,
      signature: '(function, at:number) -> number | tuple | list<number>',
      // The value has the kind of the function's value: a number for a
      // scalar function, a point for a point-valued one (a space curve),
      // a list for a list-valued one. `number` when the literal's result
      // type says nothing, the overwhelmingly common case.
      type: ([fn], { engine }) => {
        const informative = (t: Type | undefined): Type | undefined =>
          t === undefined || t === 'any' || t === 'unknown' ? undefined : t;
        // The declared signature first; then, as the `Derivative` type
        // handler does, the literal a symbol declared plain `function`
        // holds, whose codomain is known where the declaration's is not.
        let result =
          fn !== undefined ? informative(functionResult(fn.type)) : undefined;
        if (result === undefined && fn !== undefined) {
          const held = heldValueTypeOf(fn, engine);
          if (held !== undefined) result = informative(functionResult(held));
        }
        const type =
          result !== undefined && derivativeValueShape(result) === 'vector'
            ? result
            : 'number';
        return BoxedType.forResult(engine.type(type), engine._typeResolver);
      },
      canonical: (ops, { engine }) => {
        // A `Return` in an operand has no function to end (ROADMAP CE-96).
        const returnError = canonicalWithEscapingReturn(engine, 'ND', ops);
        if (returnError) return returnError;
        // The variable is not written: it is chosen as for the implicit form
        // of `Limit`, from the symbols of the body with or without a value.
        const fn = canonicalImplicitLimitFunction(engine, ops[0]);
        if (!fn) return null;
        const x = checkOperandType(engine, ops[1]?.canonical, 'number');
        return engine._fn('ND', [fn, x]);
      },
      evaluate: ([body, x], { engine }) => {
        // The same stencil as `Apply(Derivative(f), x).N()` and as the
        // compiled `_SYS.nd`, component by component for a point- or
        // list-valued function (`stencilDerivativeAt`).
        const xValue = x.N().re;
        if (isNaN(xValue)) return undefined;
        // A function NAME is resolved to the literal it is bound to, so the
        // stencil runs the compiled literal — the same code the compiled
        // JavaScript route runs — rather than an interpreted application.
        const lit = resolveDerivativeFunctionLiteral(body) ?? body;
        return stencilDerivativeAt(engine, lit, xValue, 1);
      },
      compile: (args, compile, context) =>
        compileDerivative('ND', args, compile, context),
    },

    JacobianMatrix: {
      description: [
        'JacobianMatrix(fs, vars): the matrix of partial derivatives',
        '∂fᵢ/∂xⱼ, one row per function and one column per variable.',
        '`fs` is a list of expressions. A single (non-list) expression is the',
        'gradient case: the result is the flat vector [∂f/∂x₁, …, ∂f/∂xₙ].',
        '`vars` is a list of symbols and may be omitted, in which case the',
        'free variables of `fs` are used, in lexicographic order.',
        'Example: JacobianMatrix([x^2 y, x + z], [x, y, z]).',
      ],
      keywords: ['jacobian', 'gradient', 'derivative', 'partial derivative'],
      broadcastable: false,

      // Hold the operands. The variable list must NOT be evaluated: a symbol
      // carrying a value (`x := 5`) would be replaced by that value, leaving
      // nothing to differentiate with respect to. Held operands arrive
      // unbound, so each is canonicalized below before use.
      lazy: true,
      signature: '(any, any?) -> value',

      // A system of functions yields a matrix; a single function yields the
      // gradient vector. Reported from the operand's *shape*, which is
      // available before evaluation; the element type is left to the value.
      //
      // "System or gradient?" is a question about what the operand DENOTES,
      // not about its syntax: a user function `F` that returns a list is a
      // system, so `Determinant(JacobianMatrix(F(x, y, z)))` must type-check.
      // The expressions-shape handler answered it by canonicalizing the
      // operand and reducing it to a `List`, which a type derivation may not
      // do — canonicalizing writes engine state. The two channels below
      // answer the same question without it: a literal list, or a function
      // literal whose body is one, is a system by STRUCTURE; otherwise the
      // type of what the operand denotes decides — a list makes it a system,
      // a scalar number the gradient case. What neither decides keeps the
      // declared `value`, where the old handler guessed `vector`.
      type: ([fs], context) => {
        if (!fs) return undefined;
        const structure = fs.structureOf?.();
        if (
          structure?.kind === 'list-literal' ||
          (structure?.kind === 'function-literal' &&
            structure.body.kind === 'list-literal')
        )
          return BoxedType.forResult('matrix', context.engine._typeResolver);
        const denoted = heldDenotedType(context, fs);
        if (isSubtype(denoted, JACOBIAN_LIST_SHAPE_TYPE))
          return BoxedType.forResult('matrix', context.engine._typeResolver);
        if (isSubtype(denoted, 'number'))
          return BoxedType.forResult('vector', context.engine._typeResolver);
        return BoxedType.forResult('value', context.engine._typeResolver);
      },

      evaluate: (ops, { engine: ce }) => {
        let target = ops[0]?.canonical;
        if (target === undefined || !target.isValid) return undefined;

        // `JacobianMatrix(F)` / `JacobianMatrix(F, vars)` — a bare function
        // reference. Its body is the system and its parameters are the default
        // differentiation variables, in declared order. When explicit `vars`
        // are also given, rename: substitute the parameters by the given
        // symbols (an arity mismatch declines).
        const lambda = bareFunctionLambda(target);
        let paramDefault: string[] | undefined;
        if (lambda) {
          target = lambda.body;
          paramDefault = lambda.params;
        } else {
          // `[a, b, c]` — a list of bare function references (each element a
          // named scalar component). Their common parameters are the default
          // differentiation variables, as for a single bare function.
          const system = bareFunctionSystem(target);
          if (system) {
            target = ce._fn('List', system.bodies);
            paramDefault = system.params;
          }
        }

        // "System or gradient?" must be decided on what the operand *denotes*,
        // not on its syntax. `JacobianMatrix(F(x,y,z), …)` for a user-defined
        // `F` returning a list is a system; a purely syntactic `List` check
        // took the gradient path and produced the TRANSPOSE — invisible to a
        // determinant test, since det A = det Aᵀ. A `let`-bound list went
        // inert for the same reason.
        if (!isFunction(target, 'List')) {
          // Resolve to a `List` WITHOUT substituting scalar values — the
          // differentiation variables must survive (see `resolveToList`). A
          // syntactic `List` check alone typed `JacobianMatrix(F(x,y,z), …)`
          // for a list-returning `F` as the TRANSPOSE — invisible to a
          // determinant test, since det A = det Aᵀ.
          const reduced = resolveToList(target);
          if (isFunction(reduced, 'List')) target = reduced;
        }

        // A `List` operand is a system of functions; anything else is a single
        // scalar function (the gradient case).
        const isSystem = isFunction(target, 'List');
        let fs = isFunction(target, 'List') ? [...target.ops] : [target];
        if (fs.length === 0) return undefined;

        // Runtime gate (the static type cannot refute these): every entry must
        // be a scalar expression, not a nested collection.
        if (fs.some((f) => !f.isValid || f.isCollection === true))
          return undefined;

        // Variables: the explicit list; else a bare function's parameters (in
        // declared order); else the free variables of `fs`, lexicographically.
        let names: string[];
        const varsOp = ops[1]?.canonical;
        if (varsOp !== undefined) {
          const items = isFunction(varsOp, 'List') ? varsOp.ops : [varsOp];
          const syms = items.map((v) => sym(v));
          if (syms.some((n) => n === undefined)) return undefined;
          names = syms as string[];
          // Rename a bare function's parameters to the given variables.
          if (paramDefault) {
            if (paramDefault.length !== names.length) return undefined;
            const rename = Object.fromEntries(
              paramDefault.map((p, i) => [p, ce.symbol(names[i])])
            );
            // `subs` replaces only the free occurrences of a parameter, and it
            // renames an inner binder that would capture a symbol of a
            // replacement (with vars `[k]`, the body `Sum(x·k, k, 1, 3)` of
            // `x ↦ …` becomes `Sum(k·k_1, k_1, 1, 3)`), except in the
            // cases that `subsIfCaptureFree()`
            // (`boxed-expression/subs-capture-mode.ts`) lists. This test is
            // stricter: it declines (leaves `JacobianMatrix` symbolic) when
            // an inner binder binds a parameter or a target name, also when
            // `subs` gives the correct body.
            for (const f of fs) {
              const binders = collectBinderNames(f);
              if (binders.size === 0) continue;
              for (let i = 0; i < paramDefault.length; i++)
                if (binders.has(paramDefault[i]) || binders.has(names[i]))
                  return undefined;
            }
            fs = fs.map((f) => f.subs(rename));
          }
        } else if (paramDefault) {
          names = paramDefault;
        } else {
          const free = new Set<string>();
          for (const f of fs) for (const n of f.unknowns) free.add(n);
          // Lexicographic, so the column order is predictable and stable.
          names = [...free].sort();
        }
        if (names.length === 0) return undefined;

        // A differentiation variable that ALSO carries a global value (`x := 5`
        // then differentiate w.r.t. `x`) is a bound variable: evaluating
        // `D(x²y, x)` must differentiate, not substitute `5`. Shield the
        // differentiation variables' values for the whole computation (the
        // shared binder helper), leaving the result symbolic in them.
        const row = (f: Expression): Expression[] =>
          names.map((n) => ce.function('D', [f, ce.symbol(n)]).evaluate());

        return withValueShield(ce, names, () => {
          // Gradient: a flat vector, directly usable as one. A system: a
          // matrix, which `Determinant` accepts when it is square.
          if (!isSystem) return ce.function('List', row(fs[0]));
          return ce.function(
            'List',
            fs.map((f) => ce.function('List', row(f)))
          );
        });
      },
    },

    CircularIntegrate: {
      description:
        'Closed-path integral. Evaluates supported explicit contours by the residue theorem.',
      keywords: ['contour integral', 'closed integral', 'line integral'],
      broadcastable: false,

      lazy: true,
      // The variable of the limits is bound by the integral, as in
      // `Integrate`: it is declared in the integral's own scope, not in the
      // scope of the caller.
      operands: operandRolesFrom([RAW_ROLE], CLAUSE_ROLE),
      signature: '(function, limits+) -> number',

      // The integrand is left as the bare application it was parsed as (not
      // wrapped in a `Function` literal the way `Integrate` does), so it
      // round-trips to the same LaTeX. The canonical handler rewrites the
      // limits that `parseIntegral` builds as `Tuple`s into `Limits`
      // expressions, so a limits-consuming caller sees the same shape as
      // `Integrate` (the `Tuple` uses the symbol `Nothing` as a positional
      // placeholder for an absent index or bound). A single lower limit can
      // name a contour (`\oint_{|z|=2}`): the evaluate handler then applies
      // the residue theorem. Any other limits leave the integral inert.
      canonical: (ops, { engine: ce }) => {
        if (!ops[0]) return null;
        const limits = canonicalLimitsSequence(ops.slice(1), { engine: ce });
        return ce._fn('CircularIntegrate', [ops[0].canonical, ...limits]);
      },
      evaluate: (ops, { engine: ce, numericApproximation }) => {
        if (ops.length !== 2 || !isFunction(ops[1], 'Limits')) return undefined;
        const [variable, contour, upper] = ops[1].ops;
        if (
          !isSymbol(variable) ||
          !contour ||
          (upper && sym(upper) !== 'Nothing')
        )
          return undefined;
        // The box route can deliver the integrand as a `Function` literal,
        // the shape that `Integrate` uses: `contourIntegrand()` reads its
        // body.
        const integrand = contourIntegrand(ce, ops[0], variable.symbol);
        if (integrand === undefined) return undefined;
        const r = ce.contourIntegrate(integrand, variable.symbol, contour);
        const value =
          r.status === 'pole-on-contour' ? singularPathValue(ce, r) : r.value;
        return numericApproximation ? value?.N() : value;
      },
    },

    CircleContour: {
      description:
        'Closed circle: center, positive radius, optional orientation (+1 or -1).',
      signature:
        '(center:complex, radius:real, orientation:integer?) -> expression',
    },
    RealLineContour: {
      description:
        'The real axis from minus infinity to infinity. Pass True to explicitly request a Cauchy principal value.',
      signature: '(principalValue:boolean?) -> expression',
    },
    PolygonContour: {
      description:
        'Simple closed polygon: a list of complex vertices in traversal order, with optional orientation override (+1 or -1).',
      signature: '(vertices:list<complex>, orientation:integer?) -> expression',
    },
    RectangleContour: {
      description:
        'Closed rectangle: lower-left and upper-right complex corners, optional orientation (+1 or -1).',
      signature:
        '(lowerLeft:complex, upperRight:complex, orientation:integer?) -> expression',
    },
    ContourIntegrate: {
      description:
        'Symbolic integral over an explicit closed contour or the real line (`RealLineContour`), using the residue theorem.',
      keywords: ['residue theorem', 'contour integral'],
      broadcastable: false,
      lazy: true,
      // The variable (operand 1) is bound by the integral.
      operands: operandRolesFrom([RAW_ROLE, BOUND_ROLE], RAW_ROLE),
      signature: '(expression, variable:symbol, contour:expression) -> number',
      canonical: (ops, { engine: ce }) => {
        if (ops.length !== 3 || !isSymbol(ops[1])) return null;
        return ce._fn(
          'ContourIntegrate',
          ops.map((op) => op.canonical)
        );
      },
      evaluate: ([f, x, contour], { engine: ce, numericApproximation }) => {
        const variable = sym(x);
        if (!variable) return undefined;
        const integrand = contourIntegrand(ce, f, variable);
        if (integrand === undefined) return undefined;
        const r = ce.contourIntegrate(integrand, variable, contour);
        const value =
          r.status === 'pole-on-contour' ? singularPathValue(ce, r) : r.value;
        return numericApproximation ? value?.N() : value;
      },
    },

    Integrate: {
      description: 'Symbolic integral with optional bounds.',
      keywords: [
        'antiderivative',
        'primitive',
        'integral',
        'definite integral',
      ],
      wikidata: 'Q80091',
      broadcastable: false,
      // Its Monte-Carlo fallback samples through a derived sub-stream, so it
      // READS the ambient `WithRandomSeed` frame while consuming none of its
      // indices. Not `drawsRandom` (that would shift every sibling draw), but
      // the pending gate must still keep the frame around an estimate that
      // could not finish — otherwise deferring it converts a seeded estimate
      // to a live one. See `docs/RANDOMNESS-MODEL.md` §6.
      readsRandomFrame: true,

      lazy: true,
      // The integration variable(s) live in the `Limits` operands, which
      // `canonicalLimits` used to pass through untouched — leaving the index
      // raw on the parse route and carrying the CALLER's binding on the
      // `ce.function` route (the `Series` defect, stage 5 of
      // `docs/SCOPING-MODEL.md`). The integrand's
      // own variable stays owned by its `Function` literal.
      operands: operandRolesFrom([RAW_ROLE], CLAUSE_ROLE),
      // A list integrand of any rank gives a tensor of the same shape
      // (`integralTypeOf`): `tensor` admits a vector and a matrix of
      // integrals alike, where `list<number>` admits a vector only.
      signature: '(function, limits+) -> number | tensor | tuple | list<tuple>',
      // An integral where a lower or upper bound is a LIST
      // (`∫_{-∞}^{G} f(Z) dZ` with `G = [-1, 0, 1]`) is one integral per
      // element, and its value is the list of those integrals. This applies
      // to a single limit and to several limits alike: with several limits,
      // each element of the list gives one complete multiple integral, and
      // when more than one bound is a list, the lists are paired element by
      // element. Both evaluate paths return a `List` for these shapes (the
      // numeric path in `evaluate` below, the symbolic path through
      // `EvaluateAt`). Type it as a list so the type agrees with the value.
      // The lengths of the lists are not known here: when two list bounds
      // have different lengths, `evaluate()` and `N()` give an
      // `incompatible-dimensions` error, although the type is still
      // `list<number>`.
      // An integrand whose value is a list is also one integral per element
      // (`integrateListIntegrand`), so the integral has the shape of the
      // integrand's list type, with number elements. A tuple integrand is
      // integrated coordinate by coordinate, and gives a tuple, or a list of
      // tuples when a bound is a list (`integrateTupleIntegrand`). The
      // signature's `tuple` and `list<tuple>` admit these results.
      type: (ops, context) => {
        const { engine } = context;
        // The integrand is a function literal: its result type is the type
        // of the integrand's value. Its parameters are the integration
        // variables, which are real numbers, so the result is derived from
        // the body with each parameter of unknown type read as `real`: the
        // signature alone types the body `[x, 2x]` of `∫₀¹ [x, 2x] dx` as a
        // `list<unknown>`, since a parameter with no annotation can receive
        // any value, and the shape `vector<2>` of the integrand would be
        // lost. An annotated or narrowed parameter keeps its type.
        const integrand = ops[0];
        const declared = functionResult(integrand?.type);
        const sig = integrand?.type;
        const parameters =
          typeof sig === 'object' && sig.kind === 'signature'
            ? (sig.args ?? []).map((arg) =>
                describeType(arg.type === 'unknown' ? 'real' : arg.type)
              )
            : [];
        const derived =
          integrand !== undefined && declared !== undefined
            ? appliedLiteralResultType(
                integrand,
                parameters,
                declared,
                context.derive
              )
            : undefined;
        // A result type that is a union of a list and scalars or absence
        // markers (`integer | vector<2>` for `Which(c, [y, 2y], True, 0)`;
        // a restriction `If(c, [y, 2y])` is typed `vector<2>`) is read arm
        // by arm, as `integrateListIntegrand` reads it: each list arm gives a
        // list of integrals, a scalar arm gives a number, and an absence arm
        // gives nothing.
        const integrandType = derived ?? declared;
        const shape = listIntegrandShape(integrandType);
        const listTypes: Type[] = shape
          ? [
              ...shape.lists.map((t) => integralTypeOf(t)),
              ...(shape.scalar ? ['number' as Type] : []),
            ]
          : [integralTypeOf(integrandType)];
        const hasListBound = ops.slice(1).some((op) => {
          const limit = op.structureOf?.();
          return (
            limit?.kind === 'application' &&
            limit.head === 'Limits' &&
            limit.children
              .slice(1)
              .some((bound) => isSubtype(bound.type, LIST_OF_ANY_TYPE))
          );
        });
        // A tuple integrand with a list bound is one tuple per element of
        // the bound (`integrateTupleIntegrand`). A list integrand pairs its
        // elements with the elements of the bound and keeps its own type.
        const results = listTypes.map((listType): Type => {
          if (typeof listType === 'object' && listType.kind === 'tuple')
            return hasListBound
              ? { kind: 'list', elements: listType }
              : listType;
          if (listType !== 'number') return listType;
          return hasListBound ? { kind: 'list', elements: 'number' } : 'number';
        });
        return BoxedType.forResult(
          results.length === 1 ? results[0] : widen(...results),
          engine._typeResolver
        );
      },
      canonical: (ops, { engine: ce }) => {
        if (!ops[0]) return null;

        // A `Return` in an operand has no function to end (ROADMAP CE-96).
        // The integrand is read before it becomes the body of a function
        // literal below, where it would look like the `Return` of that
        // function.
        const returnError = canonicalWithEscapingReturn(ce, 'Integrate', ops);
        if (returnError) return returnError;

        const limits = canonicalLimitsSequence(ops.slice(1), { engine: ce });

        // Bind only the integration variable(s) from the limits, not every
        // free symbol of the integrand: a free coefficient (e.g. `a` in
        // `∫ a·sin(x) dx`, or the wrongly-inferred `F` in `∫ (G−F) dt`) must
        // not become an integrand parameter. The (de-duplicated) integration
        // variables are passed to `canonicalFunctionLiteral` as the intended
        // parameter list, so a shorthand integrand's body canonicalizes with
        // exactly those parameters declared. (Deriving the literal by
        // unknowns-inference and swapping its parameter list afterwards left
        // the body's occurrences bound to the discarded inferred parameters
        // — Tycho item 178(a): the parsed `∫_{-x}^{x} cos(x) dn` compared
        // `isSame` false against `ce.box()` of its own `.json`, because the
        // body's `x` stayed bound to a discarded parameter while the bounds'
        // `x` bound the engine's.) An explicit `Function` integrand keeps its
        // user-supplied parameters; a bare-symbol integrand stays bare.
        const seen = new Set<string>();
        const vars: Expression[] = [];
        for (const l of limits) {
          const v = isFunction(l) ? l.op1 : undefined;
          if (
            v &&
            isSymbol(v) &&
            v.symbol !== 'Nothing' &&
            !seen.has(v.symbol)
          ) {
            seen.add(v.symbol);
            vars.push(v);
          }
        }

        // A parenthesized list of several expressions, `\int_0^1 (x, 2x)\,dx`,
        // is a tuple, as the same `(x, 2x)` is outside an integral (and as
        // the summand of `Sum` is). Canonicalize it as such before it becomes
        // the body of the function literal: `canonicalFunctionLiteral` reads
        // a `Delimiter` of several expressions as a `Block` of statements,
        // whose value is the last expression only.
        let integrand = ops[0];
        if (
          isFunction(integrand, 'Delimiter') &&
          isFunction(integrand.op1, 'Sequence') &&
          integrand.op1.nops > 1
        )
          integrand = integrand.canonical;

        // A bare-symbol integrand stays bare, and the integration reads it as
        // a value (a constant integrand). A bare `N` or `D` is then a
        // variable, not the library operator. Any other bare symbol is left
        // as it is (`devolveValueElements` canonicalizes only a name that
        // resolves to the library operator).
        if (isSymbol(integrand))
          integrand = devolveValueElements(ce, [integrand])[0];

        let f = canonicalFunctionLiteral(
          integrand,
          vars.length > 0 ? { params: vars } : undefined
        );
        if (!f) return null;

        // When no limit names a variable (`\int_0^1 \sqrt{x}`, with no
        // `dx`), the parameters of the literal are the implicit variables:
        // the first symbols of the integrand in sorted order, one for each
        // limit. A symbol with an assigned value is a candidate too
        // (`implicitVariableCandidates`), and as a parameter it is a bound
        // variable that hides the value. So after `x := 4`, `∫₀¹ √x` is
        // 2/3, as it is when `x` gets its value after boxing. The other
        // symbols of the integrand stay free: a parameter that no limit
        // binds would be read as a constant by compiled code and as a
        // symbol by the interpreter.
        if (vars.length === 0) {
          const implicit = implicitLiteralParameters(ce, integrand, f, limits);
          if (implicit) f = implicit;
        }

        return ce._fn('Integrate', [f, ...limits]);
      },

      evaluate: (ops, { engine: ce, numericApproximation, expression }) => {
        // A limit with only one bound (`\int^2 f\,dy`, `\int_0 f\,dy`,
        // `Limits(y, Nothing, 2)`): the integral is neither indefinite nor
        // definite, and no default is chosen for the missing bound. The
        // integral stays unevaluated, under `evaluate()` and `N()` alike.
        // Without this, the symbolic route read the antiderivative at the
        // missing bound as 1 (`\int^2 y^2\,dy` was 7/3).
        for (const l of ops.slice(1)) {
          if (!isFunction(l, 'Limits')) continue;
          if ((sym(l.op2) === 'Nothing') !== (sym(l.op3) === 'Nothing'))
            return undefined;
        }

        // A limit that names no variable takes it from the parameters of the
        // integrand (`implicitIntegrationVariable`). The integral stays
        // unevaluated, under `evaluate()` and `N()` alike, when that
        // variable cannot be read (a destructuring parameter, a bare-symbol
        // integrand whose value is a function), and for an indefinite limit
        // with no variable for an integrand with no parameter
        // (`Integrate(2, Nothing)`): its antiderivative was taken with
        // respect to the symbol `Nothing`.
        for (const [i, l] of ops.slice(1).entries()) {
          if (!isFunction(l, 'Limits') || sym(l.op1) !== 'Nothing') continue;
          const implicit = implicitIntegrationVariable(ops[0], ops.slice(1), i);
          if (implicit === null) return undefined;
          if (
            implicit === undefined &&
            sym(l.op2) === 'Nothing' &&
            sym(l.op3) === 'Nothing'
          )
            return undefined;
        }

        // The integrand lifted out of its function literal
        // (`liftIntegrand()`), computed once. The lift rebuilds the body in
        // canonical form, and several tests below read it. Each of them runs
        // in the scope of this call, where the lift gives the same
        // expression every time. Inside the value shield (`withValueShield`)
        // the names bind to other definitions, so the code there lifts the
        // integrand again and does not read this value.
        let liftedIntegrand: Expression | undefined;
        const liftedHere = (): Expression =>
          (liftedIntegrand ??= liftIntegrand(ops[0]));

        // A block of several statements that only assigns local variables
        // before its value (`Block(c := 2, c·x)`) has the integral of that
        // value, under `evaluate()` and `N()` alike. Any other block
        // declines below.
        const statements = severalStatementsBody(ops[0]);
        if (statements !== undefined) {
          const value = blockIntegrandValue(ops[0], statements, ops.slice(1));
          if (value !== undefined)
            return rebindIntegralResult(
              ce,
              ce
                .function('Integrate', [value, ...ops.slice(1)])
                .evaluate({ numericApproximation }),
              expression,
              numericApproximation
            );
        }

        // A bare-symbol integrand that is the variable of a limit that names
        // no variable (`x` in `\int_0^1 x`): the integral is the one with the
        // variable named, `\int_0^1 x\,dx`. That form binds `x` in the scope
        // of the integral. Without it, the evaluation made the held symbol
        // canonical, which declared `x` in the enclosing scope.
        if (isSymbol(ops[0])) {
          const name = ops[0].symbol;
          const limits = ops.slice(1);
          const named = limits.map((l, i) =>
            isFunction(l, 'Limits') &&
            sym(l.op1) === 'Nothing' &&
            implicitIntegrationVariable(ops[0], limits, i) === name
              ? ce.function('Limits', [ops[0], l.op2, l.op3], { form: 'raw' })
              : l
          );
          if (named.some((l, i) => l !== limits[i]))
            return rebindIntegralResult(
              ce,
              ce
                .function('Integrate', [ops[0], ...named])
                .evaluate({ numericApproximation }),
              expression,
              numericApproximation
            );
        }

        // A parameter of the running function call that holds an expression
        // of an integration variable is not constant in that variable: in
        // `g(f) = ∫ f dx`, the call `g(x^2)` gives `f` the value `x^2`, which
        // the integration would take for a constant (`x·x^2`) through the bare
        // symbol. Integrate the integrand with the value in its place
        // (CE-157).
        {
          const names = ops.slice(1).flatMap((l) => {
            const v = isFunction(l) ? sym(l.op1) : undefined;
            return v !== undefined && v !== 'Nothing' ? [v] : [];
          });
          const lifted = liftedHere();
          // The integrand that a substitution produced and that is being
          // integrated now takes no second substitution: a value can mention
          // a symbol with the name of a parameter (`g(f + x)` gives `f` the
          // value `f + x`), and substituting that symbol again would
          // replace it by its value without end.
          const substituted = substitutedIntegrands.some((e) =>
            e.isSame(lifted)
          );
          // A call of a parameter that holds a function is a call of its
          // value (`callOfFunctionParameter`). The integration has no rule
          // for an application of a function literal, so the application
          // is evaluated: `Apply(t ↦ t^2, x)` is `x^2`. An application of a
          // literal written in the integrand is evaluated too: the integral
          // of `Apply(t ↦ t^2, x)` stayed unevaluated.
          const replaced = new Set<string>();
          const withValues = substituted
            ? lifted
            : rewriteWithBinders(
                lifted,
                (s, shadowed) => {
                  if (shadowed?.has(s.symbol) || names.includes(s.symbol))
                    return s;
                  const v = parameterActivationValue(ce, s);
                  return v !== undefined &&
                    names.some((n) => parameterValueVariesWith(ce, v, n))
                    ? v
                    : s;
                },
                undefined,
                false,
                undefined,
                (app, appOps, shadowed) =>
                  callOfFunctionParameter(
                    ce,
                    app,
                    appOps,
                    shadowed,
                    replaced
                  )?.evaluate() ?? appliedFunctionLiteral(ce, app, appOps)
              );
          if (withValues !== lifted) {
            substitutedIntegrands.push(withValues);
            try {
              return rebindIntegralResult(
                ce,
                withOperandBindings(ce, withValues, replaced, () =>
                  ce
                    .function('Integrate', [withValues, ...ops.slice(1)])
                    .evaluate({ numericApproximation })
                ),
                expression,
                numericApproximation
              );
            } finally {
              substitutedIntegrands.pop();
            }
          }
        }

        // A user function called in the integrand reads a symbol with the
        // name of an integration variable: `∫₀¹ g(k) dk` with
        // `g := a ↦ a·k·x`. The integral of the integrand with this variable
        // renamed is computed instead (see `renameCapturedVariables`). The
        // bounds of the limit of a variable, and of the limits before it, are
        // outside the scope of the variable and keep their symbols:
        // `Σ_{k=1}^{2} ∫₀^k g(k) dk` integrates up to the index of the sum.
        // The bounds of a later limit are in the scope of the variable
        // (`Integrate(f, Limits(k, 0, 1), Limits(y, 0, k))`), and the
        // variable is renamed in them too.
        //
        // An indefinite integral gives a function of the fresh name, which is
        // renamed back when the result has no other symbol with the name of
        // the variable: with `k := 2`, `∫ g(k) dk` is `x·k²`. When the result
        // has such a symbol (`k` with no value: `½·k·x·k_1²`), the fresh name
        // stays. That result is correct: the `k` of `g` and the variable are
        // different symbols, and with one name they could not be told apart.
        // The variable of a definite integral is not in its value, and is
        // never renamed back.
        {
          const variables = [
            ...new Set(
              ops.slice(1).flatMap((l) => {
                const v = isFunction(l) ? sym(l.op1) : undefined;
                return v !== undefined && v !== 'Nothing' ? [v] : [];
              })
            ),
          ];
          // The canonical integrand is a function literal whose parameters
          // are the integration variables. A literal with other parameters
          // binds names of its own and is not renamed.
          const params = isFunction(ops[0], 'Function')
            ? ops[0].ops.slice(1).map((p) => sym(p))
            : undefined;
          // The renamed integral is built on a new scope whose parent is the
          // parent of the scope of this integral, so that the names that it
          // reads from an enclosing binder resolve as they did.
          const bindings =
            expression !== undefined
              ? boundVariableBindings(expression)
              : undefined;
          const scope: Scope = {
            parent: expression?.localScope?.parent ?? ce.context.lexicalScope,
            bindings: new Map(),
          };
          const r =
            params === undefined ||
            (params.length === variables.length &&
              params.every((p, i) => p === variables[i]))
              ? renameCapturedVariables(
                  ce,
                  liftedHere(),
                  variables,
                  ops.slice(1),
                  bindings,
                  scope
                )
              : undefined;
          if (r !== undefined) {
            // The symbol that `name` denotes in the scope that encloses the
            // integral: the binding of an enclosing binder (the index of a
            // `Sum`, the parameter of a function), or a global.
            const enclosing = (name: string): Expression => {
              // Truthiness, not `!== null`: the root scope's parent is
              // `undefined`, and a name bound nowhere reaches it.
              for (let s = scope.parent; s; s = s.parent) {
                if (!s.bindings.has(name)) continue;
                const symbol = ce._bindingSymbol(name, s);
                if (symbol !== undefined) return symbol;
                break;
              }
              return ce._inScope(scope.parent ?? undefined, () =>
                ce.symbol(name)
              );
            };
            // The variables of the limits before limit `j` are in scope in
            // the bounds of limit `j`: their occurrences are renamed. The
            // canonical form binds an occurrence of the variable of limit `j`
            // or of a later limit in these bounds to that variable too, but
            // it denotes the symbol of the enclosing scope
            // (`Σ_{k=1}^{2} ∫₀^k g(k) dk`), and it is bound to that symbol.
            // Only an occurrence bound to the variable (or not bound yet) is
            // changed; a symbol with the same name and another binding keeps
            // its binding.
            const renameIn = (
              e: Expression,
              outer: ReadonlySet<string>
            ): Expression =>
              rewriteWithBinders(e, (s, shadowed) => {
                if (!r.fresh.has(s.symbol) || shadowed?.has(s.symbol)) return s;
                const def = s.valueDefinition;
                if (
                  def !== undefined &&
                  !sameBindingDef(def, bindings?.get(s.symbol) ?? undefined)
                )
                  return s;
                return outer.has(s.symbol)
                  ? r.fresh.get(s.symbol)!
                  : enclosing(s.symbol);
              });
            const outer = new Set<string>();
            const limits = ops.slice(1).map((l) => {
              if (!isFunction(l)) return l;
              const v = sym(l.op1);
              const variable = v !== undefined ? r.fresh.get(v) : undefined;
              const bounds = l.ops.slice(1).map((b) => renameIn(b, outer));
              if (variable !== undefined) outer.add(v!);
              if (
                variable === undefined &&
                bounds.every((b, i) => b === l.ops[i + 1])
              )
                return l;
              return ce.function(l.operator, [variable ?? l.op1, ...bounds]);
            });
            const integral = ce.function('Integrate', [r.body, ...limits], {
              scope,
            });
            let value = numericApproximation
              ? integral.N()
              : integral.evaluate();
            if (isFunction(value, 'Integrate')) return undefined;
            // Only the variable of an indefinite limit (no bounds) can be in
            // the value. It is renamed back unless the value also reads the
            // name of the variable, directly or through a call that is not
            // inlined (`m(k_1)` where the body of `m` reads `k`).
            for (const [name, fresh] of r.renamed) {
              const indefinite = ops
                .slice(1)
                .some(
                  (l) =>
                    isFunction(l) &&
                    sym(l.op1) === name &&
                    sym(l.op2) === 'Nothing' &&
                    sym(l.op3) === 'Nothing'
                );
              if (
                indefinite &&
                value.has(fresh) &&
                !value.has(name) &&
                !namesReadByCalledFunctions(value).has(name)
              )
                value = value.subs({ [fresh]: ce.symbol(name) });
            }
            // `ce.symbol(name)` above is made while the frame of this
            // integral is on top, so it is bound to the variable of this
            // integral, and so is a fresh name that the value keeps (`k_1`).
            // Else `∫ g(k) dk` with `g := a ↦ a·k·x` and `k := 2` gives an
            // `x·k²` whose `k` is not the global `k`.
            return rebindIntegralResult(
              ce,
              value,
              expression,
              numericApproximation
            );
          }
        }

        // An integrand that is the `NaN` literal: the
        // integral has no value, on the exact and the numeric route alike,
        // with or without bounds. `Integrate` is lazy, so the NaN-policy
        // step of evaluation does not run for it. The answer is `NaN`.
        // A held integrand can be the raw symbol `NaN`: `.canonical` makes
        // it the number literal (and does not substitute assigned values).
        // The body of a function literal can be a `Block` of one expression.
        let body = (isFunction(ops[0], 'Function') ? ops[0].op1 : ops[0])
          .canonical;
        while (isFunction(body, 'Block') && body.nops === 1) body = body.op1;
        // An integrand that holds a residue class is not integrated: a class
        // is not a real number, and the bounds are real numbers, not
        // elements of its ring (`1/2` is not the class `2⁻¹`). The integral
        // stays unevaluated, under `evaluate()` and `N()` alike.
        if (holdsKindValue(body)) return undefined;
        if (isNumber(body) && body.isNaN === true) {
          // A list bound gives one integral per element (see the `type`
          // handler), so the answer is a list of the same length, and two
          // list bounds of different lengths are an error, as for any other
          // integrand. The value of each bound is computed once.
          const hasListBound = ops
            .slice(1)
            .some(
              (l) =>
                isFunction(l, 'Limits') &&
                (isSubtype(l.op2.type.type, 'list<any>') ||
                  isSubtype(l.op3.type.type, 'list<any>'))
            );
          if (!hasListBound) return ce.NaN;
          const limitValues = ops
            .slice(1)
            .map((l) =>
              isFunction(l, 'Limits')
                ? [l.op2, l.op3].map((b) =>
                    numericApproximation ? b.N() : b.evaluate()
                  )
                : []
            );
          // The lengths are compared in the order of the numeric route
          // below (the last limit first, the lower bound before the upper),
          // so that the error names them in the same order.
          let count: number | undefined;
          for (const bounds of [...limitValues].reverse()) {
            for (const b of bounds) {
              if (!isFunction(b, 'List')) continue;
              if (count !== undefined && count !== b.nops)
                return ce.error(
                  'incompatible-dimensions',
                  `${count} vs ${b.nops}`
                );
              count = b.nops;
            }
          }
          // A bound typed as a list whose value is not a list: no answer.
          if (count === undefined) return undefined;
          const results: Expression[] = [];
          for (let i = 0; i < count; i++) {
            results.push(ce.NaN);
          }
          return ce.function('List', results);
        }

        // A list-valued integrand: one integral per element.
        const perElement = integrateListIntegrand(
          ce,
          ops[0],
          ops.slice(1),
          numericApproximation ?? false
        );
        if (perElement !== undefined)
          return rebindIntegralResult(
            ce,
            perElement,
            expression,
            numericApproximation
          );

        // The integration variable(s) are bound by `Integrate`: a same-named
        // global assignment (`x := 5`) must not substitute into the
        // antiderivative computation or its result. Shield them for the whole
        // symbolic pass so `∫ x² dx` stays `x³/3` (not `125/3`) and
        // `∫₀¹ x² dx` is `1/3` (not `0`). The names come from the limits and,
        // as a fallback, the integrand function-literal's parameters.
        //
        // The numeric route below needs the same shield. Outside a call, a
        // function literal's parameter reads the value of a same-named
        // assigned symbol, so compiling `x ↦ |x| cos x` with `x := 5` saw a
        // positive `x`, dropped the `Abs`, and `∫_{−π}^{π} |x| cos x dx`
        // numericized to `0` instead of `−4`.
        // A limit that names no variable binds the variable that
        // `implicitIntegrationVariable` gives it, and a typed parameter
        // (`Typed(x, 'real')`) binds its name.
        const intVarNames: string[] = [];
        for (const [i, l] of ops.slice(1).entries())
          if (isFunction(l)) {
            const v = sym(l.op1);
            if (v && v !== 'Nothing') intVarNames.push(v);
            if (v === 'Nothing') {
              const implicit = implicitIntegrationVariable(
                ops[0],
                ops.slice(1),
                i
              );
              if (implicit) intVarNames.push(implicit);
            }
          }
        if (isFunction(ops[0]))
          for (const p of ops[0].ops.slice(1)) {
            const n = functionLiteralParameterName(p);
            if (n) intVarNames.push(n);
          }

        // Over structurally equal bounds (`∫_a^a`, `∫_1^1`) the integral is
        // zero. This is decided before the numeric route too, which cannot
        // evaluate a symbolic bound and would keep the integral unevaluated.
        // Only the structural test is used here: deciding the sign of
        // `hi − lo` would evaluate each bound once more, and a bound with an
        // effect (`∫_0^{Random()}`) must be evaluated exactly once, by the
        // route that consumes it. The symbolic route below still decides a
        // zero difference for bounds that are equal in value but not in form.
        for (const l of ops.slice(1)) {
          if (!isFunction(l, 'Limits')) continue;
          const [lo, hi] = [l.op2, l.op3];
          if (sym(lo) === 'Nothing' || sym(hi) === 'Nothing') continue;
          if (lo.isSame(hi)) return ce.Zero;
        }

        // A call of a user function that has the name of a library function
        // (`Sin := t ↦ t + 1`): the residue method and the symbolic route
        // below select a function by its name and would integrate the
        // library function. Under `evaluate()`, the integral of the body of
        // the user function is computed instead. When the body cannot
        // replace the call (a name that a local scope of the integrand
        // shadows, a user function that is not a function literal), the
        // integral stays unevaluated. The numeric route compiles the user
        // function and is correct, so under `N()` only the residue method is
        // not used.
        const shadowedCalls = shadowedCallsIn(ce, ops[0].canonical);
        if (shadowedCalls !== 'none' && !numericApproximation) {
          const inlined =
            shadowedCalls === 'call'
              ? inlineShadowedCalls(
                  ce,
                  liftIntegrand(ops[0].canonical),
                  intVarNames
                )
              : undefined;
          if (inlined === undefined) return undefined;
          return rebindIntegralResult(
            ce,
            ce.function('Integrate', [inlined, ...ops.slice(1)]).evaluate(),
            expression,
            numericApproximation
          );
        }

        // Use the exact residue result for both `evaluate()` and `.N()`, after
        // the real-line driver has verified the closing arc and all poles.
        if (
          shadowedCalls === 'none' &&
          statements === undefined &&
          ops.length === 2 &&
          isFunction(ops[1], 'Limits')
        ) {
          const [x, lo, hi] = ops[1].ops;
          const variable = sym(x);
          if (
            variable &&
            lo?.isInfinity === true &&
            hi?.isInfinity === true &&
            ((lo.sgn === 'negative' && hi.sgn === 'positive') ||
              (lo.sgn === 'positive' && hi.sgn === 'negative'))
          ) {
            const r = ce.contourIntegrate(liftedHere(), variable, {
              kind: 'real-line',
            });
            // A pole on the real axis: the integral is +∞ or −∞ when the
            // integrand keeps one sign next to every such pole, and has no
            // value when it changes sign. When neither could be decided, the
            // other methods below are tried.
            const divergent =
              r.status === 'pole-on-contour'
                ? divergentIntegralValue(
                    ce,
                    r.divergence,
                    lo.sgn === 'negative'
                  )
                : undefined;
            if (divergent)
              return numericApproximation ? divergent.N() : divergent;
            if (r.value) {
              const value = lo.sgn === 'negative' ? r.value : r.value.neg();
              return numericApproximation ? value.N() : value;
            }
          }
          // An indefinite integral has the bounds `Nothing`, for which the
          // residue method has no answer (it applies over `[0, ∞)`, `[0, π]`
          // and `[0, 2π]`): it is not called, and the integrand is not lifted
          // for it.
          if (
            variable &&
            lo &&
            hi &&
            sym(lo) !== 'Nothing' &&
            sym(hi) !== 'Nothing'
          ) {
            const value = definiteIntegralByResidues(
              liftedHere(),
              variable,
              lo,
              hi
            );
            if (value) return numericApproximation ? value.N() : value;
          }
        }

        // An indefinite integral (every limit has no bounds) has no numeric
        // value to compute by quadrature: the numeric route below read the
        // `Nothing` bounds as `NaN` and kept the integral unevaluated, so
        // `Apply(x ↦ ∫sin(x) dx, 1).N()` was `∫sin(x) dx` while `.evaluate()`
        // gave `−cos(1)`. Its antiderivative is computed exactly, by the
        // symbolic route below, and the numeric request applies to the
        // result (`rebindEscapingBinderResult()`, which puts the values of
        // the parameters of a running call in place of the variable).
        const indefinite =
          ops.length > 1 &&
          ops
            .slice(1)
            .every(
              (l) =>
                isFunction(l, 'Limits') &&
                sym(l.op2) === 'Nothing' &&
                sym(l.op3) === 'Nothing'
            );
        // A block that the reduction at the start of this handler did not
        // reduce has no closed form here: its statements can branch, or change
        // a variable outside the block. Only the quadrature, which runs the
        // block at each sample, gives its integral. With no variable at all
        // (`Integrate(Function(Block(1, 2)), Limits(Nothing, 0, 2))`), the
        // integrand is a constant and the route below applies it.
        if (
          statements !== undefined &&
          intVarNames.length > 0 &&
          (!numericApproximation || indefinite)
        )
          return undefined;
        // A call whose head was defined as a data symbol after the call was
        // boxed (`g(x)`, then `ce.declare('g', 'real')`) is an error once the
        // integrand is boxed again, as `liftIntegrand` does. The samples of the
        // numeric route below are errors, which are not numbers, so it would
        // keep the integral unevaluated, while `evaluate()` reports the error.
        // `N()` reports that error too. The exact value decides, because an
        // invalid integrand can still have a value: the call in
        // `If(x > 2, g(x), x^x)` is not reached over `[0, 1]`, and the numeric
        // route below integrates the other branch.
        if (numericApproximation && !indefinite && !liftedHere().isValid) {
          const exact = expression?.evaluate();
          if (isFunction(exact, 'Error')) return exact;
        }

        if (numericApproximation && !indefinite) {
          // If a numeric approximation is requested, equivalent to NIntegrate
          let f = ops[0];

          // A free symbol in the integrand — a parameter with no value, e.g.
          // `a` in `∫₀¹ a·sin(x) dx` or an unassigned slider in `∫ n(x,q) dx`
          // — leaves nothing to integrate numerically, so stay symbolic. Not
          // merely a quality guard: without it the integrand is handed to
          // `implicitCompile`, whose generated body reads the free symbol from
          // a scope slot that the numeric caller never supplies, and the raw
          // `ReferenceError: _ is not defined` escapes out of generated code
          // to the caller of `.N()`.
          const boundVars = new Set<string>();
          for (const [k, l] of ops.slice(1).entries()) {
            const v = isFunction(l) ? sym(l.op1) : undefined;
            if (v) boundVars.add(v);
            // A limit that names no variable binds the symbol of a
            // bare-symbol integrand (`\int_0^1 x`).
            const implicit =
              v === 'Nothing'
                ? implicitIntegrationVariable(f, ops.slice(1), k)
                : undefined;
            if (implicit) boundVars.add(implicit);
          }
          // `unknowns` is a SURFACE property: for `∫ n(x) dx` where
          // `n = x ↦ q + x`, it reports nothing, because `q` lives in `n`'s
          // body. Look through user-defined operator heads (Tycho item 131 —
          // the shape that actually reached the `ReferenceError` the comment
          // above describes, since the surface guard never fired on it).
          // `boundVars` is passed IN rather than used to filter the result: it
          // binds the surface only, so a callee's capture that happens to share
          // an integration variable's name is not mistaken for it.
          // A free symbol can be the variable of a held operator whose value
          // does not read it: in `∫₀¹ D(y·z², y) dz`, `y` is free (the
          // derivative is taken at `y`), but the value of the `D` is `z²`.
          // The scalar route evaluates such an operator before it integrates
          // (`evaluateInnerIntegrals`), so `.evaluate()` gives 1/3. Evaluate
          // it here too, under the same shield of the integration variables,
          // and integrate the value when it has no free symbol left. When a
          // free symbol is left, stay symbolic as above. An integrand with
          // no free symbol is integrated as it is, so this changes nothing
          // for it. The integrand is a `Function` literal of the variables:
          // its body is lifted out (`liftIntegrand`) and evaluated, and the
          // value replaces the literal. The quadrature below wraps a bare
          // integrand in a literal of the variables of the limits, so the
          // value replaces the literal only when its parameters are these
          // variables, in the order of the limits. A literal with other
          // parameters, or a limit that names no variable, stays symbolic.
          // The inner operators are evaluated only when the evaluation can
          // remove every free symbol: the integrand is transitively pure (an
          // effect in the value of a symbol counts), and no free
          // symbol is outside the operators that `evaluateInnerIntegrals`
          // replaces (`withoutEvaluatedFirst`). In
          // `∫₀¹ a·(Σ_{k=1}^{3} k·z) dz` the free `a` stays, so the sum is
          // not evaluated for a value that is then discarded; in
          // `∫₀¹ (a + Σ Random()) dz` no effect runs. The inner integrals
          // are evaluated knowing the ranges of this integral and of the
          // enclosing ones, as on the exact route below.
          if (transitiveUnknowns(f, boundVars).length > 0) {
            const limitVars = ops
              .slice(1)
              .map((l) => (isFunction(l) ? sym(l.op1) : undefined));
            const params = isFunction(f, 'Function')
              ? f.ops.slice(1).map((p) => functionLiteralParameterName(p))
              : limitVars;
            const lifted = liftedHere();
            if (
              (isFunction(f, 'Function') && lifted === f) ||
              params.length !== limitVars.length ||
              params.some(
                (p, k) =>
                  p === undefined || p === 'Nothing' || p !== limitVars[k]
              )
            )
              return undefined;
            if (
              !isTransitivelyPure(lifted) ||
              transitiveUnknowns(withoutEvaluatedFirst(lifted), boundVars)
                .length > 0
            )
              return undefined;
            const ranges = [
              ...outerRanges(ops.slice(1)),
              ...enclosingRanges(ce),
            ];
            const variables = [...boundVars, ...ranges.map((r) => r.name)];
            const g = withValueShield(ce, intVarNames, () =>
              withEnclosingRanges(ce, ranges, () =>
                evaluateInnerIntegrals(lifted, variables)
              )
            );
            if (g === lifted || transitiveUnknowns(g, boundVars).length > 0)
              return undefined;
            f = g;
          }

          // A LIST bound (`∫_{-∞}^{G} f(Z) dZ` with `G = [-1, 0, 1]`): one
          // integral per element. This covers a single limit and several
          // limits: with several limits, element `i` gives the complete
          // multiple integral in which each list bound is replaced by its
          // element `i`. When more than one bound is a list, the lists are
          // paired element by element, and they must have the same length;
          // if they do not, the answer is the `incompatible-dimensions` error,
          // as under `evaluate()`. Without this the bound's `.re`
          // read `NaN` and the integral stayed inert under `.N()`, while the
          // symbolic path (through `EvaluateAt`) already answered a list. The
          // `type` handler above reports `list<number>` for the same shapes.
          const limitValues: Expression[][] = [];
          let count: number | undefined;
          for (const l of ops.slice(1)) {
            if (!isFunction(l, 'Limits')) {
              limitValues.push([]);
              continue;
            }
            limitValues.push([l.op2.N(), l.op3.N()]);
          }
          // The lengths are compared in the order the symbolic route reads
          // the bounds (the last limit first, the lower bound before the
          // upper), so that both routes name the lengths in one order in
          // the `incompatible-dimensions` error.
          for (const bounds of [...limitValues].reverse()) {
            for (const b of bounds) {
              if (!isFunction(b, 'List')) continue;
              if (count !== undefined && count !== b.nops)
                return ce.error(
                  'incompatible-dimensions',
                  `${count} vs ${b.nops}`
                );
              count = b.nops;
            }
          }
          if (count !== undefined) {
            const results: Expression[] = [];
            for (let i = 0; i < count; i++) {
              const limits = ops.slice(1).map((l, k) => {
                if (!isFunction(l, 'Limits')) return l;
                const [lo, hi] = limitValues[k].map((b) =>
                  isFunction(b, 'List') ? b.ops[i] : b
                );
                return ce.function('Limits', [l.op1, lo, hi]);
              });
              results.push(ce.function('Integrate', [f, ...limits]).N());
            }
            return ce.function('List', results);
          }

          // Multiple limits (`Integrate(f, Limits(x,…), Limits(y,…))`):
          // iterated quadrature over every limit. The single-limit path below
          // reads only `ops[1]` and would silently drop the other dimensions.
          // The bound values computed above are passed on, so that a bound
          // is not evaluated a second time.
          if (ops.length > 2)
            return withValueShield(ce, intVarNames, () =>
              nIntegrateMultiple(ce, f, ops.slice(1), limitValues)
            );

          const firstLimit = ops[1];
          if (!isFunction(firstLimit) || limitValues[0].length !== 2)
            return undefined;

          const [lowerValue, upperValue] = limitValues[0];
          const [lower, upper] = [lowerValue.re, upperValue.re];
          if (isNaN(lower) || isNaN(upper)) return undefined;

          // Get the integration variable from the limits. A limit that names
          // no variable reads it from the parameters of the integrand, as
          // the exact route does (`implicitIntegrationVariable`). When the
          // integrand has no parameter for it, the integrand is a constant
          // (see below), so `∫₀¹ 2` is `2` here too. The cases that
          // `implicitIntegrationVariable` declines were refused at the start
          // of the evaluation.
          let variable = sym(firstLimit.op1) ?? 'x';
          if (variable === 'Nothing') {
            const implicit = implicitIntegrationVariable(f, ops.slice(1), 0);
            // A constant integrand: its integral is
            // `integrand·(upper − lower)`, as on the exact route, with no
            // quadrature (`constantIntegral`). Quadrature gave this value
            // only when it recognized the constant tail of an infinite
            // interval.
            if (implicit === undefined)
              return constantIntegral(
                ce,
                liftIntegrand(f),
                lowerValue,
                upperValue,
                true
              );
            variable = implicit ?? variable;
          }

          // Compile the integrand as a function.
          // If it's already a Function expression, compile directly.
          // Otherwise wrap it in a Function to compile correctly for numerical eval.
          // This converts e.g. 'x' to ['Function', 'x', 'x'] -> (x) => x
          const fnExpr =
            f.operator === 'Function' ? f : ce.expr(['Function', f, variable]);

          // A user-supplied `Function` literal may declare parameters the
          // single limit does not supply — `Integrate(Function(x+q, x, q),
          // Limits(x,0,1))`. Those are FORMAL parameters, so `f.unknowns` is
          // empty and the free-symbol guard above passes; the literal then
          // compiles two-arity, is invoked unary, and quadrature reads `NaN`.
          // Mirror the parameter/variable agreement check `nIntegrateMultiple`
          // already performs, and stay symbolic instead.
          // A literal with no parameter is a constant function, and is
          // integrated as one when its body does not read a symbol with the
          // name of the variable. With `x := 4`, the literal `() ↦ √x` with
          // the limit `Limits(x, 0, 1)` reads `x`, which the limit binds:
          // the exact route integrates it with respect to `x`, so it is not
          // integrated as a constant here.
          if (isFunction(fnExpr, 'Function')) {
            const params = fnExpr.ops
              .slice(1)
              .map((p) => functionLiteralParameterName(p));
            const constant =
              params.length === 0 && !fnExpr.op1.symbols.includes(variable);
            if (!constant && (params.length !== 1 || params[0] !== variable))
              return undefined;
          }

          // A pole strictly inside the bounds: the integral diverges, and no
          // quadrature can say otherwise — the adaptive Gauss–Kronrod below
          // would report a finite `Measurement` with a confident error bar
          // (`∫₀² sec t dt` → `8.316585 ± 0.000016`), since its error estimate
          // is blind to a singularity it happens to straddle. Answer what the
          // integral actually is: `+∞`/`−∞` when the integrand keeps one sign
          // across every pole, `NaN` when it changes sign (no value, not even
          // an infinite one). Placed AFTER the parameter-agreement guard above,
          // so the body examined binds nothing but the integration variable
          // (a spare formal parameter could otherwise read a same-named
          // global). The iterated form runs the same check per dimension in
          // `nIntegrateMultiple`. The values of the other assigned symbols are
          // substituted first: the compiled integrand reads them, so the check
          // must examine the same function (see `withAssignedValues`).
          const pole = withValueShield(ce, intVarNames, () =>
            interiorPoleVerdict(
              withAssignedValues(
                ce,
                isFunction(fnExpr, 'Function') ? fnExpr.op1 : fnExpr,
                [variable]
              ),
              variable,
              lower,
              upper,
              ce
            )
          );
          if (pole !== undefined) return poleVerdictValue(ce, pole);

          // An integrand that does not depend on the variable and whose value
          // is infinite — typically the inner integral of a nested integral
          // that diverges (`∫₀² ∫₀² (y − 1)⁻² dy dx`, whose inner integral
          // is `+∞`) — gives that infinity, negated for reversed bounds.
          // Quadrature cannot answer it: every sample is infinite and the
          // weighted sum is `NaN`. The integrand is evaluated here only when
          // it is pure, so that an effect (`Random()`) is not run once more.
          const infinite = infiniteConstantIntegral(
            ce,
            isFunction(fnExpr, 'Function') ? fnExpr.op1 : fnExpr,
            variable,
            Math.sign(upper - lower)
          );
          if (infinite !== undefined) return infinite;

          // A nested double integral whose integrand is singular at one
          // point of the box, `∫₀¹ ∫₀¹ ((x − a)² + (y − b)²)^(−1/2) dy dx`.
          const aroundPoint = nestedSingularPointIntegral(
            ce,
            fnExpr,
            variable,
            lower,
            upper
          );
          if (aroundPoint !== undefined) return aroundPoint;

          const shield = <T>(run: () => T): T =>
            withValueShield(ce, intVarNames, run);
          const { integrand, compiled } = integrandPartsOf(ce, fnExpr, shield);
          const halves = endpointHalves(
            ce,
            fnExpr,
            {
              lowerBound: firstLimit.op2,
              upperBound: firstLimit.op3,
              lower,
              upper,
            },
            { compiled },
            shield
          );

          // ONE sub-stream for both passes: the imaginary pass continues where
          // the real pass stopped. Re-deriving the stream per pass would give
          // both passes the same draws, while `measurementFromParts` combines
          // their errors as independent (see `nIntegrateMultiple`, which
          // shares its stream across levels for the same reason).
          const draw = ce._substream(mixTags(f.hash, firstLimit.hash));

          const nested = {
            holdsIntegral: fnExpr.has(['Integrate', 'NIntegrate']),
          };
          // Integrate ONE real-valued part of the integrand over the interval.
          const integrateReal = (part: 're' | 'im') =>
            integrateRealPart(ce, integrand[part], lower, upper, {
              compiled,
              uncached: integrand.uncached,
              // An effect of the integrand must not run a second time at a
              // point (see `withLogSpaceFallback`).
              replayed: isTransitivelyPure(fnExpr)
                ? integrand.replayed
                : undefined,
              draw,
              nested,
              halves: () => halves(part),
            });

          const re = integrateReal('re');
          // A real integrand that diverges on an infinite tail with one sign
          // (`∫₀^∞ x dx`, `∫₀^∞ eˣ dx`) is `+∞` or `−∞`, as on the exact route.
          if (re.infinite !== undefined && !integrand.sawImaginary())
            return re.infinite > 0 ? ce.PositiveInfinity : ce.NegativeInfinity;
          // The quadrature found a divergence, which has no sign. A pole AT
          // a bound (`∫₀¹ t⁻² dt`) gives the sign: the integral diverges with
          // the sign of the integrand next to that bound, inside the
          // interval, as on the exact route (see `endpointPoleVerdict`). Not
          // when the quadrature could not tell a divergence from a
          // convergence (`undecided`): the convergent
          // `∫₀^½ dt/(t·(−ln t)^1.001) = 1000.37` also has a pole at 0 by
          // that test, and it was `+∞`.
          if (re.divergent && re.undecided !== true) {
            const endpoint = withValueShield(ce, intVarNames, () =>
              endpointPoleVerdict(
                withAssignedValues(
                  ce,
                  isFunction(fnExpr, 'Function') ? fnExpr.op1 : fnExpr,
                  [variable]
                ),
                variable,
                lower,
                upper,
                ce
              )
            );
            if (endpoint !== undefined) return poleVerdictValue(ce, endpoint);
          }
          // A divergence or an overflow with no sign: the exact route decides
          // it when it can (`exactDivergenceValue`), as compiled code does
          // with the closed form: `∫₀^∞ (x − 1) dx` is `+∞`. The bounds are
          // passed as values, so that they are not evaluated again.
          if ((re.divergent || re.overflow) && !integrand.sawImaginary()) {
            const exact = exactDivergenceValue(
              ce,
              fnExpr,
              lowerValue,
              upperValue
            );
            if (exact !== undefined) return exact;
          }
          // A divergence that only the halves of the interval found, and
          // that nothing above confirmed: the result without the halves
          // (`unconfirmed`, see `integrateRealPart`).
          const value = re.unconfirmed ?? re;
          // No sample was a number: nothing was integrated. Stay symbolic
          // (the closed form, when there is one, is then still reachable),
          // unless every sample was the undefined value: the integral is
          // then `NaN` (`sawOnlyUndefinedValues`).
          if (Number.isNaN(value.estimate) && !integrand.sawNumeric())
            return integrand.sawOnlyUndefinedValues() ? ce.NaN : undefined;
          if (!integrand.sawImaginary()) return measurementFromParts(ce, value);
          const im = integrateReal('im');
          return measurementFromParts(ce, value, im.unconfirmed ?? im);
        }

        // A bound can read a symbol that has the name of an integration
        // variable but another binding: the upper bound of `∫₀ᵏ k dk` is the
        // `k` of the enclosing scope, since the bounds of a limit are
        // outside the scope of its variable. The shield below hides the
        // value of every symbol with the name of a variable, so with
        // `k := 2` the bound read no value and the integral was `k²/2`
        // instead of `2`. Such a bound is evaluated here, before the shield.
        // A bound that reads a variable of this integral (the bound `x` of
        // `Integrate(f, Limits(y, 0, x), Limits(x, 0, 1))`) is not.
        const ownBindings =
          expression !== undefined
            ? boundVariableBindings(expression)
            : undefined;
        const readsOuterNamesake = (b: Expression): boolean =>
          b.symbols.some((name) => intVarNames.includes(name)) &&
          rewriteWithBinders(b, (s, shadowed) => {
            if (!intVarNames.includes(s.symbol) || shadowed?.has(s.symbol))
              return s;
            const def = s.valueDefinition;
            if (
              def === undefined ||
              sameBindingDef(def, ownBindings?.get(s.symbol) ?? undefined)
            )
              return s;
            return ce.Nothing;
          }) !== b;
        const limitsSequence = ops.slice(1).map((l) => {
          if (!isFunction(l, 'Limits') || ownBindings === undefined) return l;
          const bounds = l.ops
            .slice(1)
            .map((b) => (readsOuterNamesake(b) ? b.evaluate() : b));
          return bounds.every((b, i) => b === l.ops[i + 1])
            ? l
            : ce.function('Limits', [l.op1, ...bounds]);
        });

        // Indefinite integral?
        if (limitsSequence.length === 0) {
          return undefined;
        }

        // A parameter of the running call whose value does not vary with an
        // integration variable but holds a symbol with its name is shielded
        // too: its value is put in by the call, after the integration
        // (`independentParameterNames`).
        const shielded = [
          ...intVarNames,
          ...independentParameterNames(ce, liftedHere(), intVarNames),
        ];
        const result = withValueShield(ce, shielded, () => {
          let expr = ops[0];
          const argNames = isFunction(expr)
            ? expr.ops.slice(1).map((x) => sym(x))
            : [];

          let isIndefinite = true;
          for (let i = limitsSequence.length - 1; i >= 0; i--) {
            // An inner integral with a list bound gives a LIST integrand for
            // the remaining (outer) limits: one integral per element, paired
            // with the elements of an outer list bound.
            if (isFunction(expr, 'List')) {
              const remaining = limitsSequence.slice(0, i + 1);
              return (
                integrateListIntegrand(ce, expr, remaining, false) ??
                ce.function('Integrate', [expr, ...remaining])
              );
            }
            if (!isFunction(limitsSequence[i])) continue;
            const limitFn = limitsSequence[i] as Expression &
              import('../global-types.js').FunctionInterface;
            const [varExpr, lower, upper] = limitFn.ops;
            let variable = sym(varExpr);

            // A limit that names no variable reads it from the parameters of
            // the integrand (`implicitIntegrationVariable`). When the
            // integrand has no parameter for it, `variable` stays `Nothing`
            // and the integrand is a constant (see below). The cases that
            // `implicitIntegrationVariable` declines (`null`) were refused at
            // the start of the evaluation.
            if (variable === 'Nothing')
              variable =
                implicitIntegrationVariable(ops[0], limitsSequence, i) ??
                variable;
            // Default variable name if missing
            if (!variable && i < argNames.length) variable = argNames[i];
            if (!variable) variable = 'x';

            // Consult the opt-in provider before the built-in antiderivative.
            // Bounded definite reductions follow unusable primitive results.
            let antideriv: Expression | null = null;
            let providerEndpoint: Expression | undefined;
            let pole: ReturnType<typeof interiorPoleVerdict>;
            // Work on the LIFTED integrand: both paths below unwrap the
            // `Function`/`Block` scaffolding anyway, and lifting it here
            // re-binds its symbols to the caller's, so they agree with the
            // occurrences these paths mint themselves (`liftIntegrand`).
            // The integrand of an iterated integral written as nested
            // integrals (`\int\int |x-y|\,dx\,dy` on the parse route) is,
            // or contains, an unevaluated inner `Integrate`
            // (`∫_0^1 x ∫_{−1}^{1} |x| dx dx`). Evaluate each inner integral
            // first, so that the split at the kinks and the antiderivative
            // below see its closed form (see `evaluateInnerIntegrals`).
            // The inner integrals are evaluated knowing the range of this
            // integral and of the enclosing ones (see `enclosingRangesOf`).
            const isDefinite =
              sym(lower) !== 'Nothing' && sym(upper) !== 'Nothing';
            const ranges = [
              ...outerRanges(limitsSequence.slice(0, i)),
              ...enclosingRanges(ce),
            ];
            const integrand = withEnclosingRanges(
              ce,
              isDefinite
                ? [{ name: variable, lower, upper }, ...ranges]
                : ranges,
              () =>
                evaluateInnerIntegrals(liftIntegrand(expr), [
                  variable,
                  ...intVarNames,
                  ...ranges.map((r) => r.name),
                ])
            );
            // A definite integral whose integrand has `Abs(u)` or `Sign(u)`
            // with `u` linear in the variable is integrated piece by piece
            // between the points where `u` changes sign. The whole-interval
            // antiderivative can have a jump at those points, and the
            // fundamental theorem of calculus would add the jump to the
            // result (see `integrateAcrossKinks`).
            // Over proven-equal bounds (`∫_1^1`, `∫_a^a`) the integral is
            // zero. This is decided first: the split below declines an empty
            // interval, and the whole-interval antiderivative can have a
            // `Sign(u)` term, which leaves the integral unevaluated.
            if (
              isDefinite &&
              (lower.isSame(upper) ||
                decidedSign(ce.function('Subtract', [upper, lower])) === 0)
            ) {
              isIndefinite = false;
              expr = ce.Zero;
              continue;
            }
            // An infinite constant integrand — typically the value of a
            // divergent inner integral (`∫₀² ∫₀² (y − 1)⁻² dy dx`) — over an
            // interval of nonzero length is that infinity, negated for
            // reversed bounds. The antiderivative `+∞·x` cannot be
            // differenced at the bounds (`+∞·2 − +∞·0` has no value), so
            // this is decided before it. A held integrand can be the raw
            // symbol `PositiveInfinity`: `.canonical` makes it the number.
            const infinite = isDefinite ? integrand.canonical : undefined;
            if (isNumber(infinite) && infinite.isInfinity === true) {
              const orientation = decidedSign(
                ce.function('Subtract', [upper, lower])
              );
              isIndefinite = false;
              expr =
                orientation === 1
                  ? infinite
                  : orientation === -1
                    ? infinite.neg()
                    : ce.function('Integrate', [
                        expr,
                        ce.function('Limits', [
                          ce.symbol(variable),
                          lower,
                          upper,
                        ]),
                      ]);
              continue;
            }
            // A limit that names no variable, for an integrand with no
            // parameter for it: the integrand does not depend on the
            // variable, and the integral is `integrand·(upper − lower)`.
            // Without this, the integrand was integrated with respect to the
            // symbol `Nothing`, and `\int_0^1 2` was `0`. See
            // `constantIntegral` for the zero, `NaN` and equal-bound cases.
            if (variable === 'Nothing' && isDefinite) {
              isIndefinite = false;
              expr =
                constantIntegral(
                  ce,
                  integrand,
                  lower,
                  upper,
                  numericApproximation ?? false
                ) ??
                ce.function('Integrate', [
                  expr,
                  ce.function('Limits', [ce.Nothing, lower, upper]),
                ]);
              continue;
            }
            // Read before the antiderivative search: see the arm below that
            // keeps a definite integral inert when the count changes.
            const unstableBefore = unstableClosedForms.count;
            // Expensive exact reductions are fallbacks, not a new default path.
            // Check the original integrand before accepting a transformed answer.
            const definiteFallback = (): Expression | undefined => {
              if (isElementaryIntegrationFunction(integrand, variable, false))
                return undefined;
              // The symmetry reductions of `integrateDefiniteElementary` come
              // first: they are cheap and give the simplest form. The
              // composition search after them evaluates a nested integral,
              // which a registered provider (Rubi) can answer in a form with
              // complex terms that cancel: with Rubi loaded,
              // `∫₁²⁰¹¹ √x/(√(2012−x)+√x) dx` was
              // `1005 − 1006 artanh(√2011/2011) − 503 ln 1005 +
              // 503 ln(−1005) + 1006 artanh(√2011)`, where the reflection
              // identity gives `1005`.
              const candidate =
                integrateDefiniteElementary(
                  integrand,
                  variable,
                  lower,
                  upper
                ) ??
                logarithmicParameterDifference(
                  integrand,
                  variable,
                  lower,
                  upper
                ) ??
                integrateReciprocalRational(
                  integrand,
                  variable,
                  lower,
                  upper
                ) ??
                integrateComposition(
                  integrand,
                  variable,
                  (body, name, bounds) =>
                    ce
                      .function('Integrate', [
                        body,
                        ce.function('Limits', [ce.symbol(name), ...bounds!]),
                      ])
                      .evaluate(),
                  [lower, upper]
                ) ??
                integrateBySubstitution(integrand, variable, lower, upper, [
                  generalizedBeta,
                  betaLogMoment,
                  logarithmicParameter,
                  logarithmicSeriesMoment,
                  integratedPowerSeries,
                  telescopingProduct,
                  infiniteTelescopingProduct,
                ])?.value ??
                integrateBetaMoment(integrand, variable, lower, upper) ??
                integrateTrigPolynomial(integrand, variable, lower, upper) ??
                integrateRationalTrig(integrand, variable, lower, upper)
                  ?.value ??
                integrateDiscreteMoments(integrand, variable, lower, upper) ??
                integrateDiscreteAlgebra(integrand, variable, lower, upper) ??
                integrateDiscreteReciprocal(
                  integrand,
                  variable,
                  lower,
                  upper
                ) ??
                integrateWeightedDiscrete(integrand, variable, lower, upper) ??
                integrateDefiniteSeries(integrand, variable, lower, upper) ??
                integratePolynomialSeries(integrand, variable, lower, upper) ??
                integrateProductDerivative(integrand, variable, lower, upper) ??
                integrateBoseMoment(integrand, variable, lower, upper);
              if (candidate === undefined) return undefined;
              const original = withAssignedValues(ce, integrand, [variable]);
              const verdict =
                interiorPoleVerdict(original, variable, lower, upper, ce) ??
                constantFactorPoleVerdict(ce, original, variable, lower, upper);
              if (verdict) {
                if (verdict.sign === 'mixed') return ce.NaN;
                if (verdict.sign === 'positive') return ce.PositiveInfinity;
                if (verdict.sign === 'negative') return ce.NegativeInfinity;
                return undefined;
              }
              // Each reduction proves its parameter and interval conditions.
              // The speculative symbolic-pole scan used for generic primitives
              // cannot override those proofs: it treats a bound product index
              // as a free parameter, e.g. k>=1 in (1+x/(k+1))/(1+x/k).
              return candidate;
            };
            if (isDefinite) {
              // Splitting discontinuities precedes endpoint subtraction: a local
              // primitive can jump at a kink or a symbolic-exponent zero.
              const split =
                (hasLargeIntegrationPower(integrand, variable)
                  ? generalizedBeta(integrand, variable, lower, upper)?.value
                  : undefined) ??
                (hasHighDegreeReciprocalDenominator(integrand, variable)
                  ? integrateReciprocalRational(
                      integrand,
                      variable,
                      lower,
                      upper
                    )
                  : undefined) ??
                integratePiecewise(ce, integrand, variable, lower, upper) ??
                (!polygammaDomainKnown(integrand, variable, lower, upper)
                  ? 'inert'
                  : undefined) ??
                integrateAcrossKinks(
                  ce,
                  integrand,
                  variable,
                  lower,
                  upper,
                  numericApproximation ?? false
                ) ??
                integrateAtSymbolicExponentZeros(
                  ce,
                  integrand,
                  variable,
                  lower,
                  upper,
                  numericApproximation ?? false
                );
              if (split !== undefined) {
                isIndefinite = false;
                expr =
                  split === 'inert'
                    ? (definiteFallback() ??
                      ce.function('Integrate', [
                        expr,
                        ce.function('Limits', [
                          ce.symbol(variable),
                          lower,
                          upper,
                        ]),
                      ]))
                    : split;
                continue;
              }
            }
            if (ce._integrationProvider) {
              try {
                // The provider's rules are the radian ones, as the built-in
                // antiderivative's are: in another angular unit it runs on
                // the integrand rewritten to the radian convention
                // (`withRadianConvention`).
                const provider = ce._integrationProvider;
                antideriv = withRadianConvention(integrand, variable, (f) =>
                  provider(f, variable)
                );
              } catch (e) {
                // A cancellation (deadline/interrupt) thrown inside the provider
                // must propagate — swallowing it would turn a timeout into a
                // silent fall-through to the built-in antiderivative.
                // The name is checked instead of `instanceof`: a provider from
                // a plugin bundle (the Rubi integration rules) throws its own
                // copy of the `CancellationError` class.
                if (e instanceof Error && e.name === 'CancellationError')
                  throw e;
                antideriv = null;
              }
            }
            // A closed provider primitive need not have usable endpoint values
            // (or may contain a variable Sign). Prefer a closed built-in
            // alternative in that case; it still passes all pole, branch and
            // endpoint checks below. Do not temporarily unregister the provider:
            // nested evaluations must retain their engine configuration.
            if (
              antideriv &&
              !antideriv.has('Integrate') &&
              antideriv.isPure &&
              isDefinite &&
              integrand.isPure &&
              lower.isPure &&
              upper.isPure
            ) {
              const candidate = ce
                .expr([
                  'EvaluateAt',
                  ['Function', antideriv, variable],
                  lower,
                  upper,
                ])
                .evaluate({ numericApproximation });
              providerEndpoint = candidate;
              const lostExactness =
                !numericApproximation &&
                exactExpression(integrand) &&
                exactExpression(lower) &&
                exactExpression(upper) &&
                !exactExpression(candidate);
              // A provider endpoint difference with an imaginary part, for an
              // integrand proven real on the interval, is not the value (see
              // the refusal after the endpoint evaluation below): try the
              // built-in primitive first, which may give the real value.
              const nonReal = () =>
                hasImaginaryPart(candidate) &&
                provenRealOnInterval(
                  withAssignedValues(ce, integrand, [variable]),
                  variable,
                  lower,
                  upper
                );
              if (
                lostExactness ||
                hasVariableSign(antideriv, variable) ||
                !candidate.isValid ||
                candidate.isNaN === true ||
                candidate.isInfinity === true ||
                candidate.has(['EvaluateAt', 'Limit', 'Integrate']) ||
                nonReal()
              ) {
                const alternative = antiderivative(integrand, variable);
                if (
                  alternative.isValid &&
                  alternative.isNaN !== true &&
                  !alternative.has('Integrate') &&
                  !hasVariableSign(alternative, variable) &&
                  (!lostExactness || exactExpression(alternative))
                ) {
                  antideriv = alternative;
                  providerEndpoint = undefined;
                }
              } else if (hasNonRealTerms(candidate)) {
                // A real value written with terms that are not real, whose
                // imaginary parts cancel: with Rubi loaded,
                // `∫₂^∞ 1/(x²−1) dx` was `iπ/2 + artanh(2)`, which is
                // `ln(3)/2`. Use the built-in primitive when its value at the
                // bounds is the same number with real terms only.
                const alternative = antiderivative(integrand, variable);
                let value =
                  alternative.isValid &&
                  !alternative.has('Integrate') &&
                  !hasVariableSign(alternative, variable)
                    ? ce
                        .expr([
                          'EvaluateAt',
                          ['Function', alternative, variable],
                          lower,
                          upper,
                        ])
                        .evaluate({ numericApproximation })
                    : undefined;
                // An indeterminate form at an infinite bound (`∞ − ∞`) is
                // resolved as a limit, as the endpoint evaluation below does.
                if (value?.isNaN === true)
                  value = improperEndpointValue(
                    alternative,
                    variable,
                    lower,
                    upper,
                    ce,
                    numericApproximation ?? false
                  );
                if (
                  value !== undefined &&
                  value.isValid &&
                  value.isNaN !== true &&
                  value.isFinite === true &&
                  !value.has(['EvaluateAt', 'Limit', 'Integrate']) &&
                  !hasImaginaryPart(value) &&
                  !hasNonRealTerms(value) &&
                  exactExpression(value) === exactExpression(candidate) &&
                  sameNumericValue(value, candidate)
                ) {
                  antideriv = alternative;
                  providerEndpoint = value;
                }
              }
            }
            if (!antideriv || antideriv.has('Integrate'))
              antideriv = antiderivative(integrand, variable);

            if (sym(lower) === 'Nothing' && sym(upper) === 'Nothing') {
              // Indefinite integral: keep the antiderivative, whether it was
              // resolved (a closed form) or left inert (an `Integrate` node, or
              // an `Add` such as `5x + Integrate(g, x)` when only some terms
              // integrate).
              expr = antideriv;
            } else if (
              antideriv.has('Integrate') ||
              hasVariableSign(antideriv, variable)
            ) {
              // The antiderivative could NOT be fully found — the result is
              // either an inert `Integrate` (e.g. an unknown integrand, or
              // `√(1−x²)/(1+x²)`) or an `Add` that still contains one (e.g.
              // `∫ (g(x) + 5) dx → 5x + Integrate(g, x)`). Keep the definite
              // integral inert; do NOT wrap it in `EvaluateAt`. Beta-reducing
              // the integrand at the bounds would capture the integration
              // variable and silently collapse the integral to a wrong finite
              // value (∫₋₁¹ √(1−x²)/(1+x²) dx → 0, the `+5` case → 10, etc.).
              // The `.N()` path (NIntegrate quadrature) still gives the value.
              // See CORRECTNESS_FINDINGS P0-1.
              //
              // The same applies when the antiderivative has a `Sign(u)` term
              // with `u` depending on the variable, and the integral could not
              // be split where `u` changes sign (the bounds are symbolic, as
              // in `∫_{−a}^{a} |x| cos x dx`). That term jumps where `u`
              // changes sign, and if that point is between the bounds,
              // `F(b) − F(a)` includes the jump and is wrong.
              isIndefinite = false;
              expr =
                definiteFallback() ??
                ce.function('Integrate', [
                  expr,
                  ce.function('Limits', [ce.symbol(variable), lower, upper]),
                ]);
            } else if (
              (pole =
                interiorPoleVerdict(
                  // The bounds are differenced with the values of the
                  // assigned symbols, so the check must see those values
                  // too: with `q := 1`, `∫₀² (y − q)⁻² dy` has its pole at
                  // `y = 1`.
                  withAssignedValues(ce, integrand, [variable]),
                  variable,
                  lower,
                  upper,
                  ce
                ) ??
                // A free symbol in a constant factor (`1/(a·t)`): see
                // `constantFactorPoleVerdict`.
                constantFactorPoleVerdict(
                  ce,
                  withAssignedValues(ce, integrand, [variable]),
                  variable,
                  lower,
                  upper
                ))
            ) {
              // The integrand is unbounded at a point STRICTLY INSIDE the
              // bounds, so the fundamental theorem of calculus does not apply
              // and the integral diverges. Differencing the antiderivative
              // anyway would report a finite value for a divergent integral
              // (∫₋₁¹ dt/t → 0, ∫₋₁¹ dt/t² → −2). When the integrand keeps one
              // sign on both sides of every pole the integral diverges to that
              // infinity (∫₋₁¹ dt/t² → +∞, as ∫₀¹ dt/t → +∞ already does).
              // When it changes sign (`mixed`) the integral has no value, not
              // even an infinite one: `NaN`. When the direction of the
              // divergence is not established (`unknown`) the integral stays
              // inert, as the "antiderivative not fully found" arm above
              // does. `interiorPoleVerdict` only answers for a proven pole,
              // so a correct closed form is never lost this way.
              isIndefinite = false;
              expr =
                pole.sign === 'positive'
                  ? ce.PositiveInfinity
                  : pole.sign === 'negative'
                    ? ce.NegativeInfinity
                    : pole.sign === 'mixed'
                      ? ce.NaN
                      : ce.function('Integrate', [
                          expr,
                          ce.function('Limits', [
                            ce.symbol(variable),
                            lower,
                            upper,
                          ]),
                        ]);
            } else if (
              symbolicPoleMayBeInside(
                withAssignedValues(ce, integrand, [variable]),
                variable,
                lower,
                upper,
                ce,
                ranges
              )
            ) {
              // The integrand may have a pole between the bounds, at a point
              // whose position depends on a symbol with no value: `(y − a)⁻²`
              // over `[0, 4]` has its pole inside for `0 ≤ a ≤ 4`, where the
              // integral is `+∞`, but the antiderivative difference
              // `−1/a − 1/(4 − a)` is finite. The integral stays
              // unevaluated, unless the declared type of the symbol or an
              // assumption proves the pole outside the bounds (`a > 4`). The
              // integration variable of an enclosing integral is examined
              // over its range: the inner integral of
              // `∫₀¹⁰ ∫₃⁴ (y − x)⁻² dx dy` stays unevaluated (the pole `x = y`
              // is in `[3, 4]` for some `y`), so the outer one does too, while
              // `∫₅¹⁰ ∫₃⁴ (y − x)⁻² dx dy` is evaluated.
              isIndefinite = false;
              expr = ce.function('Integrate', [
                expr,
                ce.function('Limits', [ce.symbol(variable), lower, upper]),
              ]);
            } else if (
              unstableClosedForms.count !== unstableBefore &&
              ![lower, upper].every(
                (bound) =>
                  (isNumber(bound) && bound.isSame(0)) ||
                  bound.isInfinity === true
              )
            ) {
              // The closed form of a polynomial of degree above 8 times exp,
              // sin or cos (`unstableClosedForms`) is exact, but its terms at
              // a bound other than 0 or ±∞ reach about `n!/|a|ⁿ⁺¹` and cancel
              // under `.N()`: `∫₀²⁰ x¹⁰⁰·e⁻ˣ dx` gave 0 for about 6.43e120
              // (CE-1311). Keep the integral inert, as before the closed form
              // existed; `.N()` takes the quadrature. The count also changes
              // when a closed form is computed and then not kept (a provider
              // alternative, an attempt inside `antiderivative()`): the
              // integral is then inert too, which gives no wrong value. The
              // pole arms above come first: they do not use the closed form.
              isIndefinite = false;
              expr = ce.function('Integrate', [
                expr,
                ce.function('Limits', [ce.symbol(variable), lower, upper]),
              ]);
            } else {
              // The antiderivative was found in closed form. Apply the bounds
              // via `EvaluateAt`, which also supports symbolic bounds
              // (∫₀^a x dx → a²/2; see commit 9b818ec8).
              isIndefinite = false;
              const F = ce.expr(['Function', antideriv, variable]);
              const at = ce.expr(['EvaluateAt', F, lower, upper]);
              // Resolve any parameter-dependent endpoint indeterminate left by
              // FTC at a limit-point bound (0, ±∞): emit a convergence-guarded
              // restriction, or keep the integral inert (fail closed) rather than leak
              // an indeterminate form (`0^…`, `∞^…`).
              let raw =
                providerEndpoint ?? at.evaluate({ numericApproximation });
              // An antiderivative with no value at a bound can evaluate to
              // an error rather than `NaN` (`cos(1/t)` at `0` is `cos(~∞)`,
              // an incompatible-type error): it is no value either, and is
              // read as `NaN` so that the integral stays unevaluated below
              // instead of returning the error.
              if (!raw.isValid) raw = ce.NaN;
              // FTC at an infinite bound can leave a `poly(var)·e^{−c·var}`-type
              // `∞·0` product that naive substitution collapses to NaN, and so
              // can a finite bound (`t·ln t − t` at `0`). Re-resolve each such
              // endpoint as a genuine limit of the antiderivative (see
              // `improperEndpointValue`).
              let viaLimit: Expression | undefined;
              if (raw.isNaN === true) {
                viaLimit = improperEndpointValue(
                  antideriv,
                  variable,
                  lower,
                  upper,
                  ce,
                  numericApproximation ?? false
                );
                if (viaLimit !== undefined) raw = viaLimit;
              }
              // A pole AT a finite bound: the antiderivative is not finite
              // there (`−1/t` at `0` gives `~∞`), so the difference has no
              // sign. The integral is the one-sided limit from inside the
              // interval, which diverges with the sign of the integrand next
              // to the bound (`∫₀¹ t⁻² dt` is `+∞`). Poles at both bounds with
              // different signs give an integral with no value, `NaN`, as
              // for an interior pole that changes sign. The check runs only when the antiderivative difference is not finite:
              // it alone cannot tell an integrable singularity of order
              // close to 1 (`t^(−0.95)`) from a pole (see
              // `endpointPoleVerdict`).
              let noValue: Expression | undefined;
              if (raw.isNaN === true || raw.isInfinity === true) {
                const integrandValue = withAssignedValues(ce, integrand, [
                  variable,
                ]);
                const endpoint =
                  endpointPoleVerdict(
                    integrandValue,
                    variable,
                    lower,
                    upper,
                    ce
                  ) ??
                  halfLinePoleVerdict(
                    ce,
                    integrandValue,
                    antideriv,
                    variable,
                    lower,
                    upper
                  );
                if (endpoint?.sign === 'mixed') noValue = ce.NaN;
                else if (endpoint !== undefined)
                  raw = poleVerdictValue(ce, endpoint);
                // A complex infinity (`~∞`) is not the value of the integral
                // of a real integrand over a real interval: that integral is
                // a real number, `+∞`, `−∞`, or has no value. Without a
                // verdict, the integral stays unevaluated (`NaN` makes it
                // inert below).
                else if (
                  raw.isSame(ce.ComplexInfinity) &&
                  isRealOnInterval(integrandValue, variable, lower, upper, ce)
                )
                  raw = ce.NaN;
              }
              // The integral of an integrand that is real on a real interval
              // is real. An antiderivative that is singular, or crosses a
              // branch cut, inside the interval can give a difference of
              // endpoint values with an imaginary part. With Rubi loaded,
              // `∫₁²⁰¹¹ √x/(√(2012−x)+√x) dx` gave
              // `1005 − 503 ln(−1005) + 503 ln(1005)`, which is
              // `1005 − 1580.2i`: the primitive's `ln(x − 1006)` and `artanh`
              // terms are singular at `x = 1006`. Such a value is refused, as
              // `NaN`: a bounded definite reduction (`definiteFallback`) can
              // still give the value, and otherwise the integral stays
              // unevaluated. A value is refused only when the integrand is
              // proven real on the interval (`provenRealOnInterval`), so a
              // correct complex value (`∫₋₁³ √x dx`) is kept.
              if (
                noValue === undefined &&
                raw.isNaN !== true &&
                hasImaginaryPart(raw) &&
                provenRealOnInterval(
                  withAssignedValues(ce, integrand, [variable]),
                  variable,
                  lower,
                  upper
                )
              )
                raw = ce.NaN;
              // A NaN result is an unresolved indeterminate, not a leak-free
              // value — fail closed (inert) rather than leak the NaN.
              const resolved =
                raw.isNaN === true ? null : resolveEndpointLeaks(raw, ce);
              const lostExactness =
                !numericApproximation &&
                exactExpression(integrand) &&
                exactExpression(lower) &&
                exactExpression(upper) &&
                !exactExpression(raw);
              const fallback =
                noValue === undefined &&
                (resolved === null ||
                  raw.has(['Integrate', 'Limit', 'EvaluateAt']) ||
                  lostExactness)
                  ? definiteFallback()
                  : undefined;
              if (noValue !== undefined) expr = noValue;
              else if (fallback !== undefined) expr = fallback;
              else if (resolved !== null && isSymbol(resolved.guard, 'True')) {
                // Leak-free: keep the original evaluation path's RESULT. `raw`
                // IS `at.evaluate({numericApproximation})`, so returning it is
                // value-identical to re-evaluating `at` — but skips a second
                // full FTC endpoint pass (measured ~35–40% of the whole
                // definite-Gaussian evaluation; the tail's `expr.evaluate()`
                // on an already-evaluated value is an idempotent cheap walk).
                // When a limit re-resolved an improper endpoint, `raw` holds
                // that limit value already (and `at` itself would still
                // collapse to NaN), so `raw` covers both cases.
                //
                // A closed form from the power rule with a symbolic exponent
                // is the value only when the exponent is not `−1`
                // (`∫₁² t^(−n) dt` is `ln 2` at `n = 1`): the condition is
                // carried as a guard (see `powerRuleParameterGuard`). When
                // the exponent IS `−1` (an assumption `n = 1`), the closed
                // form is not the value and the integral stays unevaluated.
                const parameterGuard = powerRuleParameterGuard(
                  ce,
                  integrand,
                  variable
                );
                expr =
                  parameterGuard === undefined
                    ? raw
                    : (conditionalValue(ce, raw, parameterGuard) ??
                      ce.function('Integrate', [
                        expr,
                        ce.function('Limits', [
                          ce.symbol(variable),
                          lower,
                          upper,
                        ]),
                      ]));
              } else {
                // The resolved value is `raw` with each leak replaced by its
                // limit, which can leave like terms uncollected
                // (`½√(π/a) + ½√(π/a)` for `∫_{−∞}^{∞} e^{−az²} dz`): evaluate
                // it once more before it is wrapped.
                const guarded =
                  resolved === null
                    ? null
                    : conditionalValue(
                        ce,
                        resolved.value.evaluate({ numericApproximation }),
                        resolved.guard
                      );
                expr =
                  guarded ??
                  ce.function('Integrate', [
                    expr,
                    ce.function('Limits', [ce.symbol(variable), lower, upper]),
                  ]);
              }
            }
          }
          if (expr.operator !== 'Integrate') {
            // For indefinite integrals with symbolic transcendental constants
            // (like ln(2)), don't call evaluate/simplify as it would convert
            // them to numeric values. Otherwise, simplify for cleaner output.
            if (isIndefinite) {
              if (hasSymbolicTranscendental(expr)) return expr;
              return expr.simplify();
            }
            return expr.evaluate({ numericApproximation });
          }
          return expr;
        });

        // An INDEFINITE integral's result is an OPEN expression in the
        // integration variable, which this node now binds in its own scope
        // (the `clause` role of operands 1..n). Without this the antiderivative
        // leaves the frame still referencing the dying binding and compares
        // unequal to the same expression written in the ambient scope — the
        // repair `Series` needed for exactly the same reason (stage 1).
        return rebindIntegralResult(
          ce,
          result,
          expression,
          numericApproximation
        );
      },
    },

    NIntegrate: {
      description: 'Numerical approximation of a definite integral.',
      broadcastable: false,
      // Its Monte-Carlo fallback samples through a derived sub-stream, so it
      // READS the ambient `WithRandomSeed` frame while consuming none of its
      // indices. Not `drawsRandom` (that would shift every sibling draw), but
      // the pending gate must still keep the frame around an estimate that
      // could not finish — otherwise deferring it converts a seeded estimate
      // to a live one. See `docs/RANDOMNESS-MODEL.md` §6.
      readsRandomFrame: true,
      lazy: true,
      signature: '(function, lower:number, upper:number) -> number',
      canonical: (ops, { engine }) => {
        // A `Return` in an operand has no function to end (ROADMAP CE-96).
        const returnError = canonicalWithEscapingReturn(
          engine,
          'NIntegrate',
          ops
        );
        if (returnError) return returnError;
        const [body, lower, upper] = ops;
        // The variable is not written: it is chosen as for the implicit form
        // of `Limit`, from the symbols of the body with or without a value.
        const fn = canonicalImplicitLimitFunction(engine, body);
        if (!fn) return null;
        // The two bounds are numbers. A `Tuple` of bounds
        // (`NIntegrate(f, (0, 2))`) or a missing bound is an error operand,
        // not an expression that stays unevaluated. A multiple integral is
        // written `Integrate(f, Limits(x, …), Limits(y, …)).N()`.
        return engine._fn('NIntegrate', [
          fn,
          checkOperandType(engine, lower, 'number'),
          checkOperandType(engine, upper, 'number'),
        ]);
      },
      evaluate: ([f, a, b], { engine, expression }) => {
        // A call whose head was declared as a data symbol after the call was
        // boxed: the integral is the `expected-function` error that the same
        // expression boxed after the declaration gives, not `NaN`
        // (`dataSymbolCallError()`).
        const refused = dataSymbolCallError(engine, expression);
        if (refused !== undefined) return refused;

        // Uses compiled JS functions (machine arithmetic). The bounds are
        // evaluated once: their values are passed on to the exact route below
        // (`exactDivergenceValue`), so that a bound with an effect
        // (`Random()`) is not evaluated again.
        const [aValue, bValue] = [a.N(), b.N()];
        const [lower, upper] = [aValue.re, bValue.re];
        if (isNaN(lower) || isNaN(upper)) return undefined;

        // A pole strictly inside the bounds: the integral diverges, and the
        // error estimate of the quadrature below cannot see a singularity
        // that falls between its sample points, so the quadrature would
        // report a finite value. `Integrate(…).N()` makes the same check,
        // also before it compiles the integrand.
        const pole = nIntegratePoleVerdict(engine, f, lower, upper);
        if (pole !== undefined) return poleVerdictValue(engine, pole);

        // A function given by its name (`Sin`) is wrapped in a one-parameter
        // `Function` literal: compiled alone, the symbol compiles to a
        // function that RETURNS the function, so every sample read `NaN`.
        const name = isFunction(f, 'Function') ? undefined : sym(f);
        const fn = name
          ? engine.expr([
              'Function',
              [name, NINTEGRATE_VARIABLE],
              NINTEGRATE_VARIABLE,
            ])
          : f;
        // The integrand may be complex-valued: integrate its real part, and
        // its imaginary part too when a sample carried one (see
        // `numericIntegrandParts` and the `Integrate` numeric path).
        const shield = <T>(run: () => T): T => run();
        const { integrand, compiled } = integrandPartsOf(engine, fn, shield);
        const halves = endpointHalves(
          engine,
          fn,
          { lowerBound: a, upperBound: b, lower, upper },
          { compiled },
          shield
        );
        // One stream for both passes (see the `Integrate` numeric path).
        const draw = engine._substream(mixTags(f.hash, a.hash, b.hash));

        // The same methods, in the same order, as `Integrate(…).N()`: the
        // oscillatory quadrature on a semi-infinite interval, then adaptive
        // Gauss–Kronrod, `NaN` for a divergent integral, and Monte Carlo only
        // when the quadrature does not converge. The result is a plain number:
        // the error estimate is dropped.
        const nested = { holdsIntegral: fn.has(['Integrate', 'NIntegrate']) };
        const integrate = (part: 're' | 'im') =>
          integrateRealPart(engine, integrand[part], lower, upper, {
            compiled,
            uncached: integrand.uncached,
            // The result of `NIntegrate` has no error, but an enclosing
            // quadrature collects the error of this one when this integral
            // is in its integrand.
            replayed: isTransitivelyPure(fn) ? integrand.replayed : undefined,
            draw,
            nested,
            halves: () => halves(part),
          });

        const re = integrate('re');
        // A real integrand that diverges on an infinite tail with one sign
        // is `+∞` or `−∞` (see the `Integrate` numeric path).
        if (re.infinite !== undefined && !integrand.sawImaginary())
          return re.infinite > 0
            ? engine.PositiveInfinity
            : engine.NegativeInfinity;
        // A divergence found by the quadrature, with a pole AT a bound: the
        // sign of the integrand next to that bound gives the sign of the
        // divergence (see the `Integrate` numeric path). Not when the
        // quadrature could not tell a divergence from a convergence
        // (`undecided`).
        if (re.divergent && re.undecided !== true) {
          const endpoint = nIntegratePoleVerdict(
            engine,
            f,
            lower,
            upper,
            endpointPoleVerdict
          );
          if (endpoint !== undefined) return poleVerdictValue(engine, endpoint);
        }
        // A divergence or an overflow with no sign: the exact route decides
        // it when it can (see the `Integrate` numeric path).
        if ((re.divergent || re.overflow) && !integrand.sawImaginary()) {
          const exact = exactDivergenceValue(engine, fn, aValue, bValue);
          if (exact !== undefined) return exact;
        }
        // A divergence that only the halves of the interval found, and that
        // nothing above confirmed: the result without the halves (see the
        // `Integrate` numeric path).
        const value = re.unconfirmed ?? re;
        // A numeric estimate is a float, even when its value is an integer
        // (`NIntegrate(1, 0, 2)` is `2.0`). `+ 0` turns a -0 into 0.
        if (!integrand.sawImaginary())
          return engine.number(engine._inexactNumericValue(value.estimate + 0));
        const im = integrate('im');
        return engine.number(
          engine._inexactNumericValue({
            re: value.estimate + 0,
            im: (im.unconfirmed ?? im).estimate + 0,
          })
        );
      },
    },

    DSolve: {
      description: 'Symbolic differential equation solver.',
      broadcastable: false,
      lazy: true,
      signature: '(expression, symbol, symbol) -> expression',
      canonical: (ops, { engine }) => {
        if (ops.length === 0)
          return engine._fn('DSolve', [
            engine.error('missing'),
            engine.error('missing'),
            engine.error('missing'),
          ]);
        if (ops.length === 1)
          return engine._fn('DSolve', [
            ops[0],
            engine.error('missing'),
            engine.error('missing'),
          ]);
        const dependent = symbolOrListArg(engine, ops[1]);
        const equation = repairDependentApplications(
          ops[0],
          dependentSymbolNames(dependent)
        );
        if (ops.length === 2)
          return engine._fn('DSolve', [
            equation,
            dependent,
            engine.error('missing'),
          ]);

        return engine._fn('DSolve', [
          equation,
          dependent,
          symbolArg(engine, ops[2]),
        ]);
      },
      evaluate: ([equation, dependent, independent]) =>
        dSolve(equation, dependent, independent),
    },

    RSolve: {
      description: 'Symbolic recurrence equation solver.',
      broadcastable: false,
      lazy: true,
      signature: '(expression, symbol, symbol) -> expression',
      canonical: (ops, { engine }) => {
        if (ops.length === 0)
          return engine._fn('RSolve', [
            engine.error('missing'),
            engine.error('missing'),
            engine.error('missing'),
          ]);
        if (ops.length === 1)
          return engine._fn('RSolve', [
            ops[0],
            engine.error('missing'),
            engine.error('missing'),
          ]);
        if (ops.length === 2)
          return engine._fn('RSolve', [
            ops[0],
            symbolArg(engine, ops[1]),
            engine.error('missing'),
          ]);

        return engine._fn('RSolve', [
          ops[0],
          symbolArg(engine, ops[1]),
          symbolArg(engine, ops[2]),
        ]);
      },
      evaluate: ([equation, dependent, index]) =>
        rSolve(equation, dependent, index),
    },

    NDSolve: {
      description: 'Numerical differential equation solver.',
      broadcastable: false,
      lazy: true,
      signature:
        '(expression, symbol, limits:(tuple|symbol), number, number?) -> list',
      canonical: (ops, { engine }) => {
        const missing = engine.error('missing');
        const limits =
          ops[2] && isFunction(ops[2])
            ? canonicalLimits(ops[2].ops, { engine })
            : canonicalLimits(ops[2] ? [ops[2]] : [], { engine });

        const dependent = symbolOrListArg(engine, ops[1]);
        const equation = ops[0]
          ? repairDependentApplications(ops[0], dependentSymbolNames(dependent))
          : missing;

        return engine._fn('NDSolve', [
          equation,
          dependent,
          limits ?? missing,
          ops[3]?.canonical ?? missing,
          ...(ops[4] ? [ops[4].canonical] : []),
        ]);
      },
      evaluate: ([equation, dependent, limits, initialValue, steps]) =>
        nDSolve(equation, dependent, limits, initialValue, steps),
    },

    NDSolveFunction: {
      description:
        'Numerically solve an ordinary differential equation and return ' +
        'the solution as an applicable function (a `Function` literal ' +
        'wrapping an `InterpolatingFunction`), usable at any point of the ' +
        'integration interval. Same arguments as `NDSolve`, without the ' +
        'sample count.',
      broadcastable: false,
      lazy: true,
      // The ODE's independent variable is this operator's BOUND variable, and
      // it is carried by the `Limits` operand (operand 2) — a position the
      // evaluate path used to read out by hand, leaving the variable bound
      // wherever the caller happened to have it.
      operands: operandRolesFrom([RAW_ROLE, RAW_ROLE, CLAUSE_ROLE], RAW_ROLE),
      signature:
        '(expression, symbol, limits:(tuple|symbol), number) -> function',
      canonical: (ops, { engine }) => {
        const missing = engine.error('missing');
        const limits =
          ops[2] && isFunction(ops[2])
            ? canonicalLimits(ops[2].ops, { engine })
            : canonicalLimits(ops[2] ? [ops[2]] : [], { engine });

        const dependent = symbolOrListArg(engine, ops[1]);
        const equation = ops[0]
          ? repairDependentApplications(ops[0], dependentSymbolNames(dependent))
          : missing;

        return engine._fn('NDSolveFunction', [
          equation,
          dependent,
          limits ?? missing,
          ops[3]?.canonical ?? missing,
        ]);
      },
      evaluate: ([equation, dependent, limits, initialValue]) =>
        nDSolveFunction(equation, dependent, limits, initialValue),
    },

    InterpolatingFunction: {
      description:
        'Piecewise-quartic dense-output interpolant of a numeric ODE ' +
        'solution (produced by `NDSolveFunction`). The first operand is the ' +
        'per-step coefficient table; applied to a number, it evaluates the ' +
        'solution there (clamping to the covered interval outside it). ' +
        'Stays symbolic for a non-numeric argument.',
      broadcastable: false,
      lazy: true,
      signature: '(list<any>, number?) -> number',
      evaluate: ([data, x], { engine }) => {
        if (x === undefined) return undefined;
        const xv = x.N().re;
        if (!Number.isFinite(xv)) return undefined;
        const rows = interpolatingFunctionRows(data);
        if (!rows) return undefined;
        const value = evalDenseRows(rows, xv);
        // An interpolated value is a float, even when it is an integer
        return Number.isFinite(value)
          ? engine.number(engine._inexactNumericValue(value + 0))
          : undefined;
      },
      compile: (args, compile, { language }) => {
        if (language !== 'javascript') return undefined;
        if (args.length !== 2) return undefined;
        const rows = interpolatingFunctionRows(args[0]);
        if (!rows) return undefined;
        // Embed the dense table and interpolate inline: binary search for
        // the step interval, then the nested (Horner-like) quartic.
        const table = JSON.stringify(rows);
        return (
          `((_x)=>{const _D=${table};` +
          `let _lo=0,_hi=_D.length-1;` +
          `const _dir=_D[_hi][0]+_D[_hi][1]>=_D[0][0]?1:-1;` +
          `while(_lo<_hi){const _m=(_lo+_hi)>>1;` +
          `if(_dir*(_x-_D[_m][0]-_D[_m][1])>0)_lo=_m+1;else _hi=_m;}` +
          `const _s=_D[_lo],_h=_s[1];` +
          `let _t=_h===0?0:(_x-_s[0])/_h;` +
          `_t=Math.min(1,Math.max(0,_t));const _u=1-_t;` +
          `return _s[2]+_t*(_s[3]+_u*(_s[4]+_t*(_s[5]+_u*_s[6])));` +
          `})(${compile(args[1])})`
        );
      },
    },

    // This is used to represent the indexing set/limits (i.e.
    // an index, lower and upper bounds) of a function
    // (not to be confused with Limit, which calculates the limit of a
    // function at a point)
    // It is a convenient function that prevents the first argument (the index)
    // from being canonicalized
    Limits: {
      description: 'Limits of a function',
      complexity: 5000,
      broadcastable: false,

      lazy: true,
      signature: '(index:symbol, lower:value, upper:value) -> tuple',
      canonical: (ops, { engine }) => canonicalLimits(ops, { engine }) ?? null,
    },
  },

  {
    // Limits
    Limit: {
      description: [
        'Limit of a function.',
        'Limit(f, x, a) is the limit of f as x approaches a.',
        'Limit(f, a) does not write the variable: it is the first, in sorted',
        'order (an uppercase letter before a lowercase one), of the symbols',
        'that the expression f reads from outside: not a constant, a library',
        'name, a function, or a symbol bound inside f such as the index of a',
        'Sum. A symbol with an assigned value is a candidate too, so an',
        'assignment does not change the variable. A bare symbol f names a',
        'function: Limit(Sin, a) is the limit of sin(t) as t approaches a.',
        'The variable is bound: it never takes the value assigned to a',
        'symbol of the same name.',
        'Example: Limit(Sqrt(x), 3) is sqrt(3), also after x := 4.',
      ],
      complexity: 5000,
      broadcastable: false,

      lazy: true,
      signature: '(function, point:number, direction:number?) -> number',
      canonical: (ops, { engine }) => {
        // A `Return` in an operand has no function to end (ROADMAP CE-96).
        const returnError = canonicalWithEscapingReturn(engine, 'Limit', ops);
        if (returnError) return returnError;

        // Rule-arrow form `Limit(expr, x -> x0)`: the second operand is a held
        // (raw) `To(var, point)`. Rewrite to the Wolfram-style form
        // `Limit(expr, var, point[, direction])` handled below. A `^+`/`^-`
        // direction marker on the point parses as `PseudoInverse(point)` /
        // `Superminus(point)` (generic superscript postfix); in the
        // limit-point position those shapes are direction markers, matching
        // the `\lim_{x \to 0^+}` parser: unwrap them to the direction operand
        // (1 = from above, -1 = from below).
        if (
          ops.length === 2 &&
          isFunction(ops[1], 'To') &&
          isSymbol(ops[1].op1)
        ) {
          let point = ops[1].op2;
          let direction: Expression | undefined = undefined;
          if (isFunction(point, 'PseudoInverse') && point.nops === 1) {
            direction = engine.number(1);
            point = point.op1;
          } else if (isFunction(point, 'Superminus') && point.nops === 1) {
            direction = engine.number(-1);
            point = point.op1;
          }
          ops = direction
            ? [ops[0], ops[1].op1, point, direction]
            : [ops[0], ops[1].op1, point];
        }
        const [f, x, dir] = ops;
        // Wolfram-style form `Limit(expr, var, point[, direction])`: when the
        // middle operand is a symbol that is a free variable of the
        // expression, bind it explicitly as the expansion variable and treat
        // the third operand as the point. This canonicalizes to the same
        // internal representation as the 2-arg form `Limit(expr, point)`
        // (which infers the variable). A first operand that is already a
        // `Function` literal is NOT this form: its variable is bound in the
        // literal, so a symbol in second position is a (symbolic) limit
        // point — e.g. `Limit(Function(1/(x-a), x), a, 1)` from
        // `\lim_{x \to a^+}` — not the expansion variable.
        if (
          (ops.length === 3 || ops.length === 4) &&
          f &&
          isSymbol(x) &&
          !isFunction(f, 'Function')
        ) {
          // Syntactic occurrence (`.has`), not `.unknowns`: the middle operand
          // is the bound expansion variable, so it counts even when it also
          // carries a global value (`x := 5`), which drops it from `.unknowns`.
          if (f.canonical.has(x.symbol)) {
            const fn = canonicalFunctionLiteralArguments(engine, [f, x], {
              liftedBody: true,
            });
            if (!fn) return null;
            return engine._fn('Limit', [
              fn,
              ops[2].canonical,
              ...(ops.length === 4 ? [ops[3].canonical] : []),
            ]);
          }
        }
        const fn = canonicalImplicitLimitFunction(engine, f);
        if (!fn || !x) return null;
        if (dir === undefined) return engine._fn('Limit', [fn, x.canonical]);
        return engine._fn('Limit', [fn, x.canonical, dir.canonical]);
      },
      evaluate: ([f, x, dir], { engine, expression, numericApproximation }) => {
        // A call whose head was declared as a data symbol after the call was
        // boxed: the limit is the `expected-function` error that the same
        // expression boxed after the declaration gives, not `NaN`
        // (`dataSymbolCallError()`).
        const refused = dataSymbolCallError(engine, expression);
        if (refused !== undefined) return refused;

        // A user function called in the body reads a symbol with the name of
        // the limit variable: `lim_{k→1} g(k)` with `g := a ↦ a·k·x`. The
        // limit of the body with this variable renamed is computed instead
        // (see `renameCapturedVariables`). The limit point and the direction
        // are outside the scope of the variable and keep their symbols. The
        // renamed function literal is built from the boxed body: its
        // parameter is declared in a scope that is discarded, and the
        // literal binds it in the scope of its own body.
        if (isFunction(f, 'Function') && f.nops === 2) {
          const varName = sym(f.op2);
          const scope: Scope = {
            parent: engine.context.lexicalScope,
            bindings: new Map(),
          };
          const r =
            varName !== undefined
              ? renameCapturedVariables(
                  engine,
                  liftIntegrand(f),
                  [varName],
                  dir !== undefined ? [x, dir] : [x],
                  boundVariableBindings(f.op1),
                  scope
                )
              : undefined;
          const fresh =
            varName !== undefined ? r?.fresh.get(varName) : undefined;
          if (r !== undefined && fresh !== undefined) {
            const fn = engine.function('Function', [r.body, fresh]);
            const limit = engine.function(
              'Limit',
              dir !== undefined ? [fn, x, dir] : [fn, x]
            );
            const value = numericApproximation ? limit.N() : limit.evaluate();
            return isFunction(value, 'Limit') ? undefined : value;
          }
        }

        // Symbolic path first: it produces an exact closed form (`sin x/x → 1`,
        // `(3ˣ+5ˣ)^{1/x} → 5`) and is the only path under a non-numeric
        // `evaluate()`. It returns `undefined` when it can't determine the
        // limit, so the numeric machinery below still covers everything it did.
        if (isFunction(f)) {
          const varName = sym(f.op2);
          if (varName) {
            const direction =
              dir && Number.isFinite(dir.re) ? dir.re : undefined;
            const symbolic = symbolicLimit(
              f.op1,
              varName,
              x,
              direction,
              engine
            );
            if (symbolic !== undefined)
              return numericApproximation ? symbolic.N() : symbolic;
          }
        }

        // Numeric fallback: compiled JS functions (machine arithmetic).
        // The iteration budget keeps a single sample on the extrapolation
        // ladder interruptible: an unbudgeted compiled Sum/Product with a
        // variable-dependent bound runs an arbitrarily long loop that no
        // deadline check can reach (see LIMIT_PROBE_ITERATION_BUDGET).
        if (numericApproximation) {
          return numericLimitValue(engine, f, x, dir);
        }
        return undefined;
      },
    },
    Residue: {
      description:
        'Residue of a function at a point (the coefficient of (x-a)⁻¹ in its Laurent expansion)',
      complexity: 5000,
      broadcastable: false,

      lazy: true,
      signature: '(expression, variable:symbol, point:value) -> number',
      canonical: ([f, x, a], { engine }) => {
        if (!f || !x || !a || !isSymbol(x)) return null;
        return engine._fn('Residue', [f.canonical, x, a.canonical]);
      },
      evaluate: ([f, x, a], { engine, numericApproximation }) => {
        const varName = sym(x);
        if (!varName) return undefined;
        const r = residue(f, varName, a, engine);
        if (r === undefined) return undefined;
        return numericApproximation ? r.N() : r;
      },
    },
    NLimit: {
      description: [
        'Numerical approximation of the limit of a function.',
        'NLimit(f, a) finds its variable with the same rule as Limit(f, a):',
        'the first of the symbols written in the expression f, in sorted',
        'order, also when it has an assigned value. A bare symbol f names a',
        'function.',
      ],
      complexity: 5000,
      broadcastable: false,

      lazy: true,
      signature: '(function, point:number, direction:number?) -> number',
      canonical: (ops, { engine }) => {
        // A `Return` in an operand has no function to end (ROADMAP CE-96).
        const returnError = canonicalWithEscapingReturn(engine, 'NLimit', ops);
        if (returnError) return returnError;
        const [f, x, dir] = ops;
        const fn = canonicalImplicitLimitFunction(engine, f);
        if (!fn || !x) return null;
        if (dir === undefined) return engine._fn('NLimit', [fn, x.canonical]);
        return engine._fn('NLimit', [fn, x.canonical, dir.canonical]);
      },
      evaluate: ([f, x, dir], { engine }) => {
        // Uses compiled JS functions (machine arithmetic). Budgeted for the
        // same reason as Limit's numeric fallback above.
        return numericLimitValue(engine, f, x, dir);
      },
    },
  },

  {
    //
    // **Series**: Taylor (or asymptotic, at ±∞) series expansion.
    //
    // `["Series", f, x]`            → about x0 = 0, order 5
    // `["Series", f, x, x0]`        → order 5
    // `["Series", f, x, x0, n]`     → n is the highest retained power
    //
    // The result is a plain expression: the truncated sum plus an inert
    // `BigO` remainder head (e.g. `Sin(x)` → `x − x³/6 + x⁵/120 + O(x⁷)`).
    // At a pole the result is a Laurent expansion (e.g. `Cot(x)` →
    // `1/x − x/3 − …`), via the Laurent engine in symbolic/series.ts. That
    // engine also produces **Puiseux** expansions with fractional powers
    // (`√(sin x)` → `√x − x^{5/2}/12 + …`) and **log-aware** expansions
    // (`ln(sin x)` → `ln x − x²/6 − …`, `x^x` → `1 + x ln x + …`). Only an
    // essential singularity (`e^{1/x}`), an irrational/symbolic exponent
    // (`x^π`), a nested/reciprocal logarithm (`ln(ln x)`, `1/ln x`), or a
    // non-differentiable operand leaves `Series(...)` unevaluated (never a
    // partial/wrong expansion).
    //
    Series: {
      description:
        'Taylor series expansion of an expression about a point (or an ' +
        'asymptotic expansion at ±∞), including Laurent, Puiseux ' +
        '(fractional-power), and log-aware expansions at poles and branch ' +
        'points. Only essential singularities, irrational exponents, and ' +
        'nested/reciprocal logarithms are left unevaluated. ' +
        'Example: Series(\\sin x, x) → x - x^3/6 + x^5/120 + O(x^7)',
      broadcastable: false,
      lazy: true,
      // The expansion variable is this operator's BOUND variable: operand 1.
      // The framework declares it in this node's own scope before the handler
      // canonicalizes the body against it, and rebinds it afterwards — so the
      // parse route (which leaves a binding-site symbol raw) and the function
      // route (whose caller passes a symbol carrying the CALLER's binding)
      // agree about the same expression.
      operands: operandRolesFrom([RAW_ROLE, BOUND_ROLE], RAW_ROLE),
      signature:
        '(expression, variable:symbol?, point:value?, order:number?) -> number',
      canonical: (ops, { engine: ce }) => {
        const f = ops[0]?.canonical;
        if (!f) return null;
        const x = ops[1];
        // The expansion variable may be omitted (`Series(expr)`, e.g. from
        // `expr |> Series`): default to the expression's single symbol, or
        // to `x` when there are several and one of them is `x`. A symbol
        // with an assigned value is a candidate too, so the variable does
        // not depend on whether the value was assigned before or after
        // boxing (`defaultImplicitVariable`). The expression is then boxed
        // again with the variable written, so that the framework binds the
        // variable in the scope of this node and the body reads the bound
        // variable, not the assigned value. The result is the same as the
        // form with the variable written.
        if (x === undefined) {
          const v = defaultImplicitVariable(f);
          if (v === undefined) return null;
          return ce.function('Series', [
            ops[0],
            ce.symbol(v, { canonical: false }),
          ]);
        }
        if (!x || !isSymbol(x)) return null;
        const x0 = ops[2] ? ops[2].canonical : ce.Zero;
        const n = ops[3] ? ops[3].canonical : ce.number(5);
        return ce._fn('Series', [f, x, x0, n]);
      },
      evaluate: (ops, { engine: ce, expression, numericApproximation }) => {
        const [f, xSym, x0, nExpr] = ops;
        const x = sym(xSym);
        if (!x || !x0) return undefined;
        let n = Math.floor(nExpr?.N().re ?? 5);
        if (!Number.isFinite(n)) n = 5;
        // A call of a parameter that holds a function is a call of its
        // value (`callOfFunctionParameter`).
        const replaced = new Set<string>();
        const operand = rewriteWithBinders(
          f,
          (s) => s,
          undefined,
          false,
          undefined,
          (app, appOps, shadowed) =>
            callOfFunctionParameter(ce, app, appOps, shadowed, replaced)
        );
        // Inject the limit resolver: series.ts cannot import symbolicLimit
        // (limit.ts imports its laurentData — the 7c pole wiring), so the
        // ±∞ coefficient limits are resolved through this parameter.
        const result = withOperandBindings(ce, operand, replaced, () =>
          computeSeries(operand, x, x0, n, ce, symbolicLimit)
        );
        // No result: leave `Series(...)` unevaluated (deferred singular case).
        if (!result) return undefined;
        // The expansion is an OPEN expression in the expansion variable, which
        // this node binds in its own scope: re-bind it so the result denotes
        // the ambient variable rather than a binding of the frame being popped.
        return rebindEscapingBinderResult(
          ce,
          numericApproximation ? result.N() : result,
          [x],
          numericApproximation,
          expression
        );
      },
    },

    //
    // **BigO**: the inert Landau remainder term.
    //
    // Inert under `evaluate`, `simplify` and `.N()`: it has no evaluate
    // handler, so only its operand is evaluated. Under `.N()` a series keeps
    // its remainder and its other terms are approximated, as Mathematica's
    // `N` does for a series: `Series(sin x).N()` is
    // `x - 0.1666…x^3 + 0.008333…x^5 + BigO(x^7)`. The sum stays a sum,
    // because `Add` does not fold a `BigO` term with a number. `compile()`
    // has no target for it (fails gracefully). Strip it with `Normal`.
    //
    BigO: {
      description:
        'Landau big-O remainder term. Inert; a numeric approximation ' +
        '(.N()) keeps the term and approximates its operand. Strip it ' +
        'with Normal.',
      broadcastable: false,
      signature: '(value) -> number',
    },

    //
    // **Normal**: strip every `BigO` remainder from a series, yielding the
    // compilable/plottable truncated polynomial (Mathematica-compatible name).
    // Idempotent; a passthrough on `BigO`-free input.
    //
    Normal: {
      description:
        'Strip Big-O remainder terms from a series, yielding the truncated ' +
        'polynomial. Example: Normal(Series(\\sin x, x)) → x - x^3/6 + x^5/120',
      broadcastable: false,
      signature: '(value) -> value',
      // `Normal` is a passthrough that strips `BigO` remainder terms, so the
      // result's honest type is the operand's own type: a truncated series
      // stays numeric, and a non-numeric value (which `normalStrip` returns
      // unchanged) keeps its own type instead of a false `number` claim.
      type: ([x], context) =>
        BoxedType.forResult(x?.type ?? 'value', context.engine._typeResolver),
      // Lazy: the operand is evaluated EXACTLY here, the remainder is
      // stripped, and only then the numeric request is applied, so the
      // truncated polynomial is approximated from its exact coefficients.
      // The held operand is unbound, so it is canonicalized first (see
      // "lazy operators" in `ARCHITECTURE.md`).
      lazy: true,
      evaluate: ([x], { numericApproximation }) => {
        if (!x) return x;
        const stripped = normalStrip(x.canonical.evaluate());
        return numericApproximation ? stripped.N() : stripped;
      },
      // The same on the asynchronous route: the operand is awaited exactly
      // (the numeric request is withheld from it), the remainder is
      // stripped, and the numeric request applies to what is left.
      evaluateAsync: async ([x], options) => {
        if (!x) return x;
        const value = await x.canonical.evaluateAsync(
          awaitedOperandOptions(options, { numericApproximation: false })
        );
        const stripped = normalStrip(value);
        return options.numericApproximation ? stripped.N() : stripped;
      },
    },
  },
];
