import { assertDeclarationName } from '../engine-declarations.js';
import { withEarlierConstantDeclarations } from '../boxed-expression/parameter-defaults.js';
import { scopeActivation } from '../boxed-expression/ambient-chain.js';
import {
  carryLazyViewContexts,
  inLazyViewContext,
} from '../boxed-expression/lazy-view-context.js';
import {
  markCallableHome,
  sameBindingDef,
} from '../boxed-expression/binders.js';
import {
  canonicalValueOperand,
  isUntypedAtCollectionSlot,
} from '../boxed-expression/validate.js';
import { BoxedType } from '../../common/type/boxed-type.js';
import {
  applicable,
  evaluateStatements,
  evaluateStatementsAsync,
  resolveEscapingLambda,
} from '../function-utils.js';
import type { CallbackSupply } from '../boxed-expression/callback-arity.js';
import { canonicalCallbackOperand } from './collections.js';
import { MACHINE_PRECISION } from '../numerics/numeric.js';
import {
  canonicalBranch,
  canonicalStatement,
  enterBody,
  enterFunctionBody,
  exitBody,
  exitFunctionBody,
  isInBodyOrBranch,
  withPairedFunctionNames,
  withProgramStatement,
  nextProgramBatchId,
  withProgramInitializerOuters,
  noteProgramDeclarationPrevious,
} from '../statement-position.js';
import {
  CLAUSE_ROLE,
  everyOperand,
  operandRolesFrom,
  RAW_ROLE,
  STATEMENT_ROLE,
  VALUE_ROLE,
} from './operand-roles.js';
import {
  runWithEvaluationEffects,
  withEvaluationEffects,
} from '../effects-registry.js';
import { checkConditions } from '../boxed-expression/rules.js';
import { rangeElementIndexType } from '../boxed-expression/binding-sites.js';
import {
  collectTuplePattern,
  tuplePatternNames,
  typedStatement,
} from '../boxed-expression/tuple-pattern.js';
import {
  broadcastCellType,
  broadcastElementType,
  collectionElementType,
  declaredTypeNamesMissing,
  functionResult,
  resolveTypeAlias,
  resolveTypeForCompilation,
  openDepthScalarArms,
  widen,
  stripMissingFromType,
  stripNumericRanges,
} from '../../common/type/utils.js';
import {
  broadcastLengthMismatch,
  hasTupleOrStringArm,
  isBroadcastableCollection,
  isEnumerableSource,
  isFiniteBroadcastParticipant,
  isUnresolvedCollectionOperand,
  isTuple,
  isTupleShapedType,
  isTupleOrTupleUnionShapedType,
  typeCouldBeCollection,
  typeCouldBeUnkeyedCollection,
  isCollectionShaped,
  isWalkableFiniteCollection,
  mayCarryDimensions,
  nanPoint,
  pointArity,
  unmatchedCellKind,
} from '../collection-utils.js';
import { parseType } from '../../common/type/parse.js';
import {
  COLLECTION_SHAPE_TYPE,
  INDEXED_COLLECTION_SHAPE_TYPE,
  isValidType,
} from '../../common/type/primitive.js';
import { reduceType } from '../../common/type/reduce.js';
import { computedEffectsInclude } from '../../common/type/effects.js';
import {
  effectsOf,
  noteBlockStatements,
} from '../boxed-expression/effects-of.js';
import {
  cannotHoldAList,
  isSubtype,
  provablyDisjoint,
} from '../../common/type/subtype.js';
import type { Type } from '../../common/type/types.js';
import { isPolymorphicType } from '../../common/type/instantiate.js';
import {
  functionLiteralDeclaredSignature,
  functionLiteralParameterName,
  functionLiteralParameterType,
  functionLiteralReturnType,
  isDestructuringParameter,
  restParameterIndex,
  requiredParameterCount,
  restParameterSignatureTail,
} from '../boxed-expression/function-literal.js';
import { isGenericTarget } from '../multi-clause.js';
import { canonInstallSkipped } from '../clause-identity.js';
import {
  CancellationError,
  checkDeadline,
  run,
  runAsync,
} from '../../common/interruptible.js';
import type {
  Expression,
  OperandDescriptor,
  OperandStructure,
  TypeHandlerContext,
  SymbolDefinitions,
  OperatorDefinition,
  EvaluateOptions,
  IComputeEngine as ComputeEngine,
  Scope,
  CollectionHandlers,
  BoxedValueDefinition,
  BoxedDefinition,
} from '../global-types.js';
import {
  errorValue,
  surplusOperandError,
} from '../boxed-expression/error-value.js';
import {
  isErrorTypedOperand,
  isErrorTypedWithoutErrorValue,
} from '../boxed-expression/error-typed-operand.js';
import { noteFailedWalk } from '../boxed-expression/incomplete-walks.js';
import {
  runOperandSteps,
  runOperandStepsAsync,
  type OperandSteps,
} from './operand-steps.js';
import { beginParallelLoop, parallelPassFrame } from '../numerics/random.js';
import { unknownCallMayBeRecursive } from '../boxed-expression/declared-parameter-result.js';
import {
  resolvesToSystemBinding,
  deriveApplicationOf,
  describeBoundSymbol,
} from '../boxed-expression/operand-descriptor.js';
import {
  isAbsentSymbol,
  isDictionary,
  isFunction,
  isNumber,
  isSymbol,
  isString,
  sym,
  hasInferredType,
} from '../boxed-expression/type-guards.js';
import {
  FLAT_MASK_TYPE,
  isListCondition,
  isStatementArm,
} from '../boxed-expression/conditional-value.js';
import { isValueDef } from '../boxed-expression/utils.js';
import { widenAssignedType, widenLocalType } from '../boxed-expression/boxed-value-definition.js';
import {
  elementMemoFillTo,
  ELEMENT_MEMO_CAP,
  elementMemoCanKeep,
  validElementMemo,
} from '../boxed-expression/collection-element-memo.js';
import {
  buildCaseClosure,
  evaluateMatch,
  getMatchPlan,
} from '../boxed-expression/match-dispatch.js';
import { isTransitivelyPure } from '../boxed-expression/transitive-purity.js';
import {
  evaluateChainForCondition,
  isNearTiePair,
} from './relational-operator.js';
import { isExactConstantExpression } from '../boxed-expression/compare.js';
import {
  assignLoopIndex,
  bindIndexAuthoritatively,
  substituteBinderValues,
} from './utils.js';
import {
  coarsenEvidenceType,
  isInEvidenceSession,
  markDeclaredLocal,
  registerEvidenceSite,
  withEvidenceSession,
} from './assignment-evidence.js';

/**
 * The supertype a restriction condition is checked against to be typed as a
 * MASK (one boolean per cell of the value). `evaluateRestriction()` zips a
 * condition whose value is a finite collection of boolean cells, whatever
 * kind of collection it is: a list, a set, a tuple, an indexed collection. So
 * the test is against the `collection<boolean>` family, which admits all of
 * them, and not against `list<boolean>` or `indexed_collection<boolean>`: a
 * `set<boolean>` condition was typed as a scalar condition while its value
 * was a list of cells. A string condition is not a mask: its elements are
 * characters, not booleans. A `missing` cell is not admitted: such a cell
 * does not activate the zip at runtime, so the condition keeps the scalar
 * typing.
 */
const BOOLEAN_MASK_TYPE = parseType('collection<boolean>')!;

/**
 * The collection types whose values are always FINITE: a list (and a
 * dimensioned `vector`, `matrix` or tensor, which are lists), a dictionary, a
 * record, and a `range`. A `Range` whose length is not known to be finite
 * (`Range(1, ∞)`, `Range(1, n)`) is typed `indexed_collection<integer>`, not
 * `range`. A `set` is not in this family: `Integers` is a `set<integer>` and
 * has no end.
 */
const FINITE_COLLECTION_TYPE = parseType(
  'list<any> | dictionary<any> | range'
)!;

/**
 * Whether a restriction carrier of type `type` is an ORDERED collection that
 * a mask condition zips element by element: a list, a vector, a matrix, a
 * range or any other `indexed_collection<T>`, finite or not. A type with a
 * tuple arm (a point) or a string arm is excluded, also when that arm is one
 * arm of a union such as `tuple<number, number> | list<tuple<number,
 * number>>`: such types are indexed collections, but a value of the tuple
 * or string arm is one value under a restriction, never zipped. A `set`, a
 * dictionary and a record are not indexed and are excluded too.
 *
 * A mask condition of length `k` pairs such a carrier with the mask over the
 * MASK's length: cell `i` is element `i` of the carrier where the mask is
 * true, and the absence marker of that element where it is false. The
 * carrier is read at the first `k` positions only, so an infinite carrier
 * such as `Range(1, ∞)` is never materialized (user decision 2026-09-29).
 *
 * `evaluateRestriction()` and `restrictionCollectionHandlers()` both
 * call this predicate with the static type of the carrier OPERAND as written
 * (a symbol's declared type, not the type of the value it holds), so the held
 * form and the evaluated form decide the same way.
 */
function isOrderedCarrierType(type: Type): boolean {
  return (
    isSubtype(type, INDEXED_COLLECTION_SHAPE_TYPE) && !hasTupleOrStringArm(type)
  );
}

/**
 * Whether the value `value` held by a restriction carrier whose operand has
 * the static type `carrierType` is ONE value that a list of conditions never
 * splits into its elements. A string is always one value. A tuple (a point)
 * is one value, except when the carrier's static type is ordered
 * (`isOrderedCarrierType`): a symbol declared `indexed_collection<number>`
 * that holds `(1, 2)` is a collection of numbers by its declaration, so the
 * tuple is zipped with the mask. The compiled `_SYS.restrict` agrees: it
 * aligns an array with the mask and masks any other value whole, and a
 * string is not an array at run time.
 */
function isAtomicCarrierValue(carrierType: Type, value: Expression): boolean {
  if (isString(value)) return true;
  return isTuple(value) && !isOrderedCarrierType(carrierType);
}

/**
 * The first `k` elements of the ORDERED carrier `value`, read with ONE
 * iterator that stops after `k` elements, so an infinite or very long
 * carrier is never materialized and a lazy view (a `Filter`, a `Map`) calls
 * its function once per element read.
 *
 * - When the iterator ends before `k` elements, the carrier is SHORTER than
 *   the mask, and the elements read are returned: the restriction is
 *   truncated to the carrier's length, as for a finite carrier.
 * - When the elements cannot be read, the result is `undefined` and the
 *   restriction is held whole. This is the case for a carrier that cannot be
 *   enumerated (a valueless symbol, a range with a free or infinite lower
 *   bound), and for a walk that stops at the iteration limit (a `Filter`
 *   whose predicate rejects too many elements in a row): that stop is not a
 *   proof that the carrier has no more elements. The same rule decides a
 *   missed element read (`isProvablyOutOfRange`, `library/collections.ts`):
 *   a miss is decided only when it is proven.
 */
function orderedCarrierPrefix(
  value: Expression,
  k: number
): Expression[] | undefined {
  if (!isEnumerableSource(value)) return undefined;
  const elems: Expression[] = [];
  if (k <= 0) return elems;
  try {
    for (const elem of value.each()) {
      if (elem === undefined) return undefined;
      elems.push(elem);
      if (elems.length >= k) break;
    }
  } catch (e) {
    if (
      e instanceof CancellationError &&
      e.cause === 'iteration-limit-exceeded'
    )
      return undefined;
    throw e;
  }
  return elems;
}

/**
 * The definition of `Block`. It belongs to the `core` library (`CORE_LIBRARY`,
 * `core.ts` lists it), not to `control-structures`: `Function` is in `core`
 * and canonicalizing a function literal needs `Block`, so an engine built
 * with `core` but without `control-structures` must still have it. The
 * handlers stay in this file because they share their statement-position
 * helpers with `Loop` and the other control structures.
 */
export const BLOCK_DEFINITION: OperatorDefinition = {
  description:
    'Evaluate a sequence of expressions in a local scope, **sequentially**. ' +
    'Each operand is evaluated in order; later operands observe side effects ' +
    "(`Assign`, `Declare`) of earlier operands. The block's value is the " +
    'value of the last expression. Short-circuiting heads (`Return`, ' +
    '`Break`, `Continue`) terminate the sequence early.\n\n' +
    'IMPORTANT — consumers translating *simultaneous* action tuples (e.g. ' +
    'Desmos `(a → 1, b → a + 1)` where `b` reads the *pre-action* `a`) must ' +
    'rewrite to a snapshot-then-commit Block: bind each RHS to a fresh temp ' +
    'first, then assign the temps to the LHS symbols. See ' +
    'https://cortexjs.io/compute-engine/reference/control-structures/ for the ' +
    'canonical recipe.',
  lazy: true,
  // Every operand is a statement: an assignment there is valid. The
  // statements are canonicalized by `canonicalBlock()`, where a first
  // assignment declares a local of the block.
  operands: everyOperand(STATEMENT_ROLE),
  scoped: true,
  signature: '(unknown*) -> unknown',
  // A SEQUENCER that RETURNS its last value: a statement is evaluated, a
  // bare function value is not auto-applied, so no position ever applies a
  // function-valued operand. Statement APPLICATIONS are untouched — their
  // effects reach the block through the `effectsOf` recursion into the
  // operand's own effects, not through the latent term this suppresses, so
  // `Block(Assign(x, 1), Random())` is still `{random, scope}`.
  //
  // The only term that changes is the latent half of a build-and-return
  // block, where the two channels DISAGREED: `Block(() ↦ Random())`
  // reported `{random}` at runtime while `(() ↦ Block(() ↦ Random()))`
  // already typed a PURE outer arrow — the inference treats `Block` as
  // non-projecting through its `acceptsCallable` gate. Annotating aligns
  // the runtime channel with the inference, matches the store/select/return
  // precedent (`List`, `If`, `Which`, `Assign`, `Declare`), and releases a
  // seed frame that a surviving build-and-return block owes no draws to.
  invokes: false,
  type: (args, context) => {
    if (args.length === 0)
      return BoxedType.forResult('nothing', context.engine._typeResolver);
    // An assignment or a declaration is a statement with no value: a block
    // whose last statement is one has the value `Nothing`
    // (`statementListValue()`, `function-utils.ts`).
    const last = args[args.length - 1];
    let structure = last.structureOf?.();
    if (structure?.kind === 'application' && structure.head === 'Typed')
      structure = structure.children[0]?.structureOf?.();
    if (
      structure?.kind === 'application' &&
      (structure.head === 'Assign' || structure.head === 'Declare')
    )
      return BoxedType.forResult('nothing', context.engine._typeResolver);
    return BoxedType.forResult(last.type, context.engine._typeResolver);
  },
  canonical: canonicalBlock,
  evaluate: evaluateBlock,
  evaluateAsync: evaluateBlockAsync,
};

/** A caller-scope statement sequence, with independent statement failures. */
export const PROGRAM_DEFINITION: OperatorDefinition = {
  ...BLOCK_DEFINITION,
  description: 'Evaluate a program in the caller scope, continuing after statement errors.',
  inspectsErrors: true,
  scoped: false,
  canonical: canonicalProgram,
  evaluate: (ops, options) => {
    const ce = options.engine;
    const saved = ce._epsilBatchId;
    const frame = ce._deadlineFrame;
    ce._epsilBatchId = PROGRAM_BATCHES.get(ops[0]) ?? saved ?? nextProgramBatchId();
    ce._liftDefaultIterationLimit();
    try { return evaluateStatements(ce, ops, options.numericApproximation ? { numericApproximation: true } : undefined, true); }
    finally { ce._epsilBatchId = saved; ce._deadlineFrame = frame; }
  },
  evaluateAsync: async (ops, options) => {
    const ce = options.engine;
    const saved = ce._epsilBatchId;
    const frame = ce._deadlineFrame;
    ce._epsilBatchId = PROGRAM_BATCHES.get(ops[0]) ?? saved ?? nextProgramBatchId();
    ce._liftDefaultIterationLimit();
    try { return await evaluateStatementsAsync(ce, ops, options.signal, options._effects, options._contextStack, options.numericApproximation ? true : undefined, options._precisionWindow, true); }
    finally {
      ce._epsilBatchId = saved;
      ce.withEvaluationContext(options, () => { ce._deadlineFrame = frame; });
    }
  },
};

/**
 * True when the branch of a conditional is typed `unknown` because its value
 * can be of any type, not because it reaches a function whose result is
 * still being derived. Such a branch is:
 *
 * - an untyped symbol;
 * - a call of a function that is not a library operator and whose result
 *   type is not being computed now: a call `g(1)` of a function `g` that is
 *   not defined yet, or of a function whose result type is settled as
 *   `unknown`. With `q: real`, `If(q < 2, g(1), 0)` was typed `integer`,
 *   and after `g := x ↦ x / 2` and `q = 1` its value is `1/2` (CE-836);
 * - an application of a library operator whose `unknown` operands are such
 *   branches too, or that has none (`At(s, 1)` with `s` a parameter typed
 *   `indexed_collection<any>`). With `f := (n, s) ↦ If(n = 0, s[1], [1,
 *   2])`, `f(0, [7])` is `7`, and the conditional was typed
 *   `vector<integer^2>`, by its other branch alone (CE-447).
 *
 * Such a branch makes the result of the conditional `unknown`.
 *
 * These branches are excluded:
 *
 * - a call that can be a recursive call: a call of a function whose result
 *   type is being computed now (`unknownCallMayBeRecursive()`). A recursive
 *   call is typed `unknown` while the result type of its function is
 *   derived from the type of the body, and that derivation needs the join
 *   of the other branches, so that `r := n ↦ If(n = 0, 1, r(n − 1))` is
 *   typed `(n: unknown) -> integer` by its base case.
 * - a call through a callee descriptor (`callee` of the structure), whose
 *   own contract is not read here;
 * - a `Return`, `Break` or `Continue`, which gives no value in place;
 * - a `Block` and a nested conditional, since their last statement or
 *   branch can be a recursive call.
 *
 * The walk stops at a depth of 8.
 */
function untypedArm(
  branch: OperandDescriptor,
  engine: TypeHandlerContext['engine'],
  depth = 0
): boolean {
  if (branch.type !== 'unknown') return false;
  const s = branch.structureOf?.();
  if (s?.kind === 'symbol') return true;
  if (s?.kind !== 'application' || s.callee !== undefined || depth >= 8)
    return false;
  if (NOT_A_VALUE_IN_PLACE.has(s.head)) return false;
  // A function that is not a library operator: its `unknown` result is a
  // value of any type, unless the call can be a recursive one.
  if (!resolvesToSystemBinding(engine, s.head))
    return !unknownCallMayBeRecursive(engine, s.head);
  return s.children.every(
    (c) => c.type !== 'unknown' || untypedArm(c, engine, depth + 1)
  );
}

/** The heads whose `unknown` type `untypedArm` does not read as the type
 * of a value given in place. */
const NOT_A_VALUE_IN_PLACE = new Set([
  'Return',
  'Break',
  'Continue',
  'Block',
  'If',
  'Which',
]);

export const CONTROL_STRUCTURES_LIBRARY: SymbolDefinitions[] = [
  {
    // A condition expression tests for one or more conditions of an expression.
    // Two forms:
    //   ['Condition', value, "positive"]  — tests value against named condition(s)
    //   ['Condition', predicate]          — set-builder predicate (e.g. x > 0)
    Condition: {
      description: 'Test whether a value satisfies one or more conditions.',
      lazy: true,
      signature: '(expression, symbol?) -> boolean',
      evaluate: ([value, conds], { engine }) => {
        let conditions: string[] = [];
        if (isSymbol(conds)) {
          conditions = [conds.symbol];
        } else if (isFunction(conds, 'And')) {
          conditions = conds.ops.map((op) => sym(op) ?? '');
        }
        if (checkConditions(value, conditions)) return engine.True;
        return engine.False;
      },
    },

    If: {
      description:
        '`If(c, e1, e2)` evaluates to `e1` when `c` is `True` and to `e2` otherwise; without `e2` it is the absent value of the domain of `e1` when `c` is `False`: `NaN` for a number, `Missing` otherwise, as for a restriction `e1\\{c\\}`, which parses to `If(c, e1)`. Only the selected expression is evaluated.\n' +
        'When `c` is a flat list of booleans (`L < 3` with `L` a list), the selection is made at each position and the value is a list: `If([True, False, True], 1, 0)` is `[1, 0, 1]`, and with `L = [1, 3, 5]`, `If(L < 3, L, 0)` is `[1, 0, 0]`. `If(c, e1, e2)` is `Which(c, e1, True, e2)`: see `Which` for the rules of element-wise selection. A condition that is a scalar selects an arm whole, also when the arm is a list.',
      lazy: true,
      // The condition is a value, the branches are statements.
      operands: (ops) =>
        ops.map((_, i) => (i === 0 ? VALUE_ROLE : STATEMENT_ROLE)),
      // Selects among its operands, so an error in an operand it does not
      // choose does not bubble (`docs/ERROR-MODEL.md` §3).
      selectsOperands: true,
      signature: '(expression, expression, expression?) -> any',
      // A SELECTOR: the condition is tested and one branch is evaluated and
      // RETURNED — no position ever applies a function-valued operand. So
      // `If(c, randomF, pureF)` has no `random`: the draw fires at whatever
      // invokes the selected result. The branches are held may-evaluate
      // positions, so their own (production) effects still contribute
      // unchanged — `If(c, Random(), 0)` is still `{random}`.
      invokes: false,
      // The else branch is optional: `If(cond, expr)` evaluates to the
      // absent value of the domain of `expr` when the condition is false
      // (`maskedValue`): `NaN` for a number, otherwise `Missing`, the
      // position-preserving absent datum, never `Nothing`, whose splicing
      // erasure must not answer a failed selection (ERROR-MODEL §1). This is
      // the value of a restriction `expr\{cond\}`, which the parser reads as
      // `If(cond, expr)` (user decision 2026-11-02,
      // `docs/plans/2026-11-02-restriction-binding.md`).
      // The handler reads only the operands' TYPES, so it is declared on the
      // descriptor shape and cannot touch engine state while deriving.
      type: ([cond, ifTrue, ifFalse], context) => {
        // A type read must never crash, whatever the application looks like.
        // The parse and box routes both admit a malformed `If` with no
        // branch at all, which reaches this handler with `ifTrue`
        // undefined; it answers `unknown` rather than dereferencing a
        // missing operand.
        if (ifTrue === undefined)
          return BoxedType.forResult('unknown', context.engine._typeResolver);
        // A condition that is provably a mask (a collection of condition
        // values) selects element-wise (see `evaluateElementwiseSelection`):
        // the result is a list of the types of the elements of the branches.
        const shape = elementwiseConditionShape([cond?.type]);
        const armOperands = [ifTrue, ifFalse].filter((x) => x !== undefined);
        const armList = armOperands.map((x) => x.type);
        // Without an else branch, `If(c, e)` is the restriction `e\{c\}`
        // (`evaluateRestriction()`): a list value is zipped with the mask,
        // to the shorter of the two lengths. So a mask condition over a
        // collection value that is not a point or a string is typed by
        // `restrictionType()`. A scalar value is masked whole in each cell,
        // as the element-wise selection below types it.
        if (
          shape &&
          ifFalse === undefined &&
          isSubtype(ifTrue.type, COLLECTION_SHAPE_TYPE) &&
          !isTupleShapedType(ifTrue.type) &&
          !isSubtype(ifTrue.type, 'string')
        )
          return restrictionType([ifTrue, cond], context);
        if (shape)
          return BoxedType.forResult(
            elementwiseResultType(
              armOperands,
              shape,
              // The else branch IS the default clause: without one, unselected
              // positions are the no-match cell (`noMatchCell`).
              ifFalse !== undefined,
              context.engine
            ),
            context.engine._typeResolver
          );
        // A condition that is only POSSIBLY a boolean collection selects
        // element-wise for some of its runtime values and picks a single arm
        // for the others, so the result is `broadcastable` of the element-wise
        // cell type, joined with each arm that this type does not admit
        // (`possiblyElementwiseResultType`). Without an else branch the scalar
        // outcome is `Missing`, which `broadcastable` does not cover, so keep
        // that arm.
        if (possiblyElementwiseCondition([cond?.type])) {
          const broadcast = possiblyElementwiseResultType(
            armList,
            ifFalse !== undefined
          );
          return BoxedType.forResult(
            ifFalse !== undefined
              ? broadcast
              : reduceType({ kind: 'union', types: [broadcast, 'missing'] }),
            context.engine._typeResolver
          );
        }
        // Without an else branch a false condition yields the absent value
        // of the arm's domain (`maskedValue`: `NaN` for a number, `Missing`
        // otherwise), as a restriction does. The type is the type of the
        // arm with no `missing` arm (`restrictionType()`): the absent value
        // `Missing` is implicit in every signature, so a restricted value is
        // accepted where its arm is (`n: number` assigned `If(0 < t, 3)`).
        // A numeric arm gets no `nan` arm either: `If(0 < t, 3)` is
        // `integer`.
        // Decision of 2026-11-02, `docs/plans/2026-11-02-restriction-binding.md`.
        const scalar: Type =
          ifFalse === undefined
            ? restrictionType([ifTrue, cond], context).type
            : untypedArm(ifTrue, context.engine) ||
                untypedArm(ifFalse, context.engine)
              ? 'unknown'
              : widen(ifTrue.type, ifFalse.type);
        // A condition that is a scalar or a mask (`boolean | list<boolean>`,
        // `scalarOrMaskConditionShape`) gives the scalar result or the
        // element-wise result of its masks: with `c := [True, False]`,
        // `If(c, 1, 0)` is `[1, 0]`.
        const mixed = scalarOrMaskConditionShape([cond?.type]);
        if (mixed)
          return BoxedType.forResult(
            reduceType({
              kind: 'union',
              types: [
                scalar,
                elementwiseResultType(
                  armOperands,
                  mixed,
                  ifFalse !== undefined,
                  context.engine
                ),
              ],
            }),
            context.engine._typeResolver
          );
        // A condition whose type cannot be read and that may hold a list (an
        // operand of type `unknown`) can be a mask at run time: with
        // `c := [True, False]`, `If(c, 1, 0)` is `[1, 0]`. The result is the
        // scalar result or the element-wise result for a mask whose type
        // does not settle that it is flat.
        if (cond !== undefined && unreadableConditionMayBeMask(cond.type))
          return BoxedType.forResult(
            reduceType({
              kind: 'union',
              types: [
                scalar,
                elementwiseResultType(
                  armOperands,
                  {},
                  ifFalse !== undefined,
                  context.engine
                ),
              ],
            }),
            context.engine._typeResolver
          );
        return BoxedType.forResult(scalar, context.engine._typeResolver);
      },
      canonical: (ops, { engine }) => {
        // The condition (op 0) is an ordinary expression, checked for a
        // provably non-boolean type (`conditionOperand`); the then/else
        // branches (ops 1+) are statement positions, so reject a bare
        // `Break`/`Continue` symbol there.
        const xs = ops.map((op, i) =>
          i === 0
            ? conditionOperand(engine, op.canonical)
            : canonicalArm(engine, op)
        );
        // The condition and the then branch are required. A missing one is
        // an `Error("missing")` operand in its place, as `checkArity()` does
        // for other operators: the expression is invalid, and its evaluate
        // handler is never called with an absent operand.
        while (xs.length < 2) xs.push(engine.error('missing'));
        // A condition that is a flat list of booleans selects element-wise,
        // and its arms must be numbers or points (a boolean and a statement
        // are also accepted): an arm that is not is a static error, and the
        // whole `If` is that error (`selectionArmError`).
        if (isListCondition(xs[0])) {
          const armError = selectionArmError(engine, [xs[0]], xs.slice(1));
          if (armError !== undefined) return armError;
        }
        return engine._fn('If', xs);
      },
      // A surplus operand after the else branch is refused, as for any
      // built-in operator: the whole call is the `unexpected-argument` error
      // (`surplusOperandError`), whatever the condition.
      evaluate: (ops, options) =>
        surplusOperandError(options.engine, 'If', ops, options.expression, 3) ??
        whileGuardResult(
          options.engine,
          options.expression,
          evaluateIf(ops, options)
        ),
      evaluateAsync: async (ops, options) =>
        surplusOperandError(options.engine, 'If', ops, options.expression, 3) ??
        evaluateIfAsync(ops, options),
      // A held single-branch `If(c, L)` over a collection `L` (the restriction
      // `L\{c\}` with an undecided condition) presents as the collection of
      // its restricted cells `If(c, elem)`, so `isCollection`, `count` and
      // `each()` agree with its type. Every other `If` is not a collection.
      collection: restrictionCollectionHandlers(),
    },

    Loop: {
      description:
        'Imperative loop, evaluated **for effect**. `Loop(body)` repeatedly ' +
        'evaluates `body` until it yields a `Break` or `Return`. ' +
        '`Loop(body, Element(x, coll), …)` iterates `body` in nested ' +
        'iteration over the Element clauses (later clauses see earlier ' +
        'bindings; independent clauses produce a Cartesian product). The loop ' +
        'value is `Nothing`, or the value carried by a `Break`/`Return`. For a ' +
        'value-producing comprehension use `Comprehension` or `Map`.',
      lazy: true,
      // The body is a statement. The index of each `Element` clause (from
      // operand 1) is this operator's BOUND variable: the framework declares
      // it in the loop's own scope before the clauses and body are
      // canonicalized against it, and the clauses are kept as written for
      // the `canonical` handler.
      operands: operandRolesFrom([STATEMENT_ROLE], CLAUSE_ROLE),
      signature: '(body:expression, iterators:expression*) -> any',
      // The handler reads the body's inert STRUCTURE (does it contain a
      // value-carrying `Return`/`Break`?), never the body expression, so it is
      // declared on the descriptor shape.
      type: ([body], context) => {
        if (!body)
          return BoxedType.forResult('nothing', context.engine._typeResolver);
        // A `Loop` is evaluated for effect: its value is `Nothing` unless the
        // body can short-circuit with a value (`Break v` / `Return`).
        return BoxedType.forResult(
          loopBodyYieldsValue(body.structureOf?.()) ? 'unknown' : 'nothing',
          context.engine._typeResolver
        );
      },
      canonical: (ops, options) => canonicalLoopLike('Loop', ops, options),
      evaluate: (ops, { engine: ce }) =>
        run(
          runLoop(ops[0], ops.slice(1), ce),
          ce._timeRemaining,
          ce._deadlineFrame
        ),
      evaluateAsync: async (
        ops,
        { engine: ce, signal, effects, _contextStack, _precisionWindow }
      ) =>
        runAsync(
          // The loop body is evaluated synchronously, and `runAsync`
          // suspends this handler between time slices: every step must run
          // with the host capability registry and the context stack (the
          // scope of the loop index) this evaluation captured.
          withEvaluationEffects(
            ce,
            effects,
            runLoop(ops[0], ops.slice(1), ce),
            _contextStack,
            _precisionWindow
          ),
          ce._timeRemaining,
          signal,
          ce._deadlineFrame
        ),
    },

    Comprehension: {
      description:
        'Value-producing comprehension: evaluate `body` in nested iteration ' +
        'over one or more `Element` clauses and collect the results into a ' +
        'list. Later clauses see earlier bindings; ' +
        'independent clauses produce a Cartesian product. A clause with a ' +
        'third operand, `Element(x, xs, cond)`, is a guard: only the ' +
        'elements for which `cond` evaluates to `True` are visited.',
      lazy: true,
      // See `Loop`: each `Element` clause's index is a bound variable of this
      // node. The body is kept as written for the `canonical` handler.
      operands: operandRolesFrom([RAW_ROLE], CLAUSE_ROLE),
      signature: '(body:expression, iterators:expression+) -> list',
      // The handler reads the body operand's type, and the type of the index
      // of each `Element` clause.
      type: ([body, ...clauses], context) => {
        if (!body)
          return BoxedType.forResult('nothing', context.engine._typeResolver);
        // Result is a list of body.type values (`list<T>` since 2026-09-29;
        // it was `indexed_collection<T>`, which a symbol declared `list`
        // refused). The body's type may itself be parametric (e.g. a tuple):
        // wrap it in list<...>. The type says nothing about the length: a
        // comprehension over an unbounded source is a lazy list, as a `Map`
        // over it is.
        //
        // The index of a clause over a range with integer literal bounds has
        // a ranged type (`integer<1..16>`, see `indexingSetSite` in
        // `binding-sites.ts` and `canonicalLoopLike`). That type is there for
        // the body: it proves the sign of `√((k − 0.5)/16)`, so the body
        // types `real` and compiles without the complex lane. It is not a
        // statement about the list: the element type is the type of the
        // body with each such index typed `integer`
        // (`bodyTypeWithoutIndexRanges`), so `[k for k in 1..16]` is
        // `list<integer>`, not `list<integer<1..16>>`.
        const elements = bodyTypeWithoutIndexRanges(body, clauses, context);
        return BoxedType.forResult(
          { kind: 'list', elements },
          context.engine._typeResolver
        );
      },
      canonical: (ops, options) =>
        canonicalLoopLike('Comprehension', ops, options),
      // A `Comprehension` is a LAZY indexed collection, like `Range`/`Map`: it
      // has no `evaluate` handler, so `evaluate()` returns the comprehension
      // itself. Its `.count`/`.type`/collection-ness are answered without
      // walking elements (see the `collection` handler below); elements are
      // materialized only when actually indexed or iterated. Binding an unread
      // comprehension is therefore O(1), rather than materializing its whole
      // domain up front.
      collection: comprehensionCollectionHandlers(),
    },

    ParallelLoop: {
      description:
        'Parallel loop, evaluated **for effect**: ' +
        '`ParallelLoop(body, Element(x, coll))` evaluates `body` once for ' +
        'each element of `coll` (a pass), and the passes can run in any ' +
        'order. The body can change a variable declared outside the loop ' +
        'only with `AddTo` (an accumulator). A read of an accumulator in a ' +
        'pass gives an unspecified value. ' +
        'Inside a `WithRandomSeed` frame, the loop consumes one draw index ' +
        'and each pass draws from its own frame (`docs/RANDOMNESS-MODEL.md`). ' +
        'The value is `Nothing`.',
      lazy: true,
      // The same operand roles as `Loop`: a statement body and `Element`
      // clauses whose indices this node binds.
      operands: operandRolesFrom([STATEMENT_ROLE], CLAUSE_ROLE),
      // `random`: inside a `WithRandomSeed` frame, the loop consumes one
      // draw index of the frame, also when its body draws nothing, so the
      // node is not pure, and a function that holds it is not folded or
      // removed (`docs/RANDOMNESS-MODEL.md` §3, "Pass frames").
      signature: '(body:expression, iterators:expression+) random -> any',
      type: (_ops, context) =>
        BoxedType.forResult('nothing', context.engine._typeResolver),
      canonical: (ops, options) =>
        canonicalLoopLike('ParallelLoop', ops, options),
      // The interpreter runs the passes in order, as `Loop` does, each in
      // its own random frame. There is no `evaluateAsync`: a pass frame is
      // installed in the engine's frame slot while the pass runs, and an
      // asynchronous run could let another evaluation see it, so the loop
      // runs synchronously, as `WithRandomSeed` does.
      //
      // A read of an accumulator in a pass gives an unspecified value. The
      // interpreter does not check such a read: it gives the value that the
      // passes, run in order, give, and the compiled JavaScript does the
      // same. The static check reports a read written by name in the pass
      // (`src/epsil/parallel-checks.ts`), and a target that runs the passes
      // in parallel declines a pass that reads an accumulator.
      evaluate: (ops, { engine: ce }) =>
        run(
          runLoop(ops[0], ops.slice(1), ce, true),
          ce._timeRemaining,
          ce._deadlineFrame
        ),
    },

    ParallelComprehension: {
      description:
        'Parallel comprehension: `ParallelComprehension(body, Element(x, ' +
        'xs), …)` is the list that `Comprehension` with the same operands ' +
        'gives, but the passes of the first clause can run in any order. ' +
        'The other clauses run in order inside each pass. The body changes ' +
        'no variable declared outside it. Inside a `WithRandomSeed` frame, ' +
        'the comprehension consumes one draw index and each pass draws from ' +
        'its own frame (`docs/RANDOMNESS-MODEL.md`). Unlike `Comprehension`, ' +
        'it is evaluated at once to a `List`.',
      lazy: true,
      operands: operandRolesFrom([RAW_ROLE], CLAUSE_ROLE),
      // `random`, as for `ParallelLoop`: the comprehension consumes one draw
      // index of an enclosing frame.
      signature: '(body:expression, iterators:expression+) random -> list',
      type: ([body, ...clauses], context) => {
        if (!body)
          return BoxedType.forResult('nothing', context.engine._typeResolver);
        const elements = bodyTypeWithoutIndexRanges(body, clauses, context);
        return BoxedType.forResult(
          { kind: 'list', elements },
          context.engine._typeResolver
        );
      },
      canonical: (ops, options) =>
        canonicalLoopLike('ParallelComprehension', ops, options),
      // Evaluated at once (not a lazy view as `Comprehension` is): the
      // comprehension consumes its draw index when it is evaluated, and the
      // pass frames exist only while the passes run. As for `ParallelLoop`,
      // there is no `evaluateAsync`.
      evaluate: (_ops, { engine: ce, expression, numericApproximation }) => {
        if (expression === undefined) return undefined;
        const state: LoopState = {
          stopped: false,
          count: 0,
          parallel: true,
        };
        // The numeric request of `N()` is applied to each element while the
        // frame of its pass is still installed (`parallelPassValues()`
        // installs the next frame only when the walk resumes). An element
        // that is a lazy view (a nested comprehension, a `Map`) stays a
        // view: its draws are not specified (`docs/RANDOMNESS-MODEL.md` §3,
        // "Pass frames of a parallel loop").
        const elements: Expression[] = [];
        for (const value of comprehensionStream(expression, state))
          elements.push(numericApproximation ? value.N() : value);
        if (state.domainError !== undefined) return state.domainError;
        // A domain that is not a collection is not known to be empty: the
        // comprehension stays unevaluated, as the count of a `Comprehension`
        // is not known in that case. Its first clause then holds the value
        // of its domain, evaluated once: `Block(Random(), xs)` with `xs` a
        // list with no value stays `xs`, and does not draw again when the
        // comprehension is evaluated again.
        if (state.unresolvedDomain === true)
          return residualParallelComprehension(expression, state.firstDomain);
        return ce.function('List', elements);
      },
    },

    AddTo: {
      description:
        'Compound assignment: `AddTo(s, e)` is `Assign(s, Add(s, e))`, and ' +
        '`AddTo(At(L, i, …), e)` is `Assign(L, ReplaceAt(L, i, …, ' +
        'Add(At(L, i, …), e)))`, with each position evaluated once, before ' +
        '`e`. In the body of a `ParallelLoop`, it adds a contribution to an ' +
        'accumulator, a variable declared outside the loop.',
      lazy: true,
      // A write that outlives the application, as `Assign` is.
      signature: '(expression, any) scope -> any',
      invokes: false,
      canonical: (ops, { engine: ce }) => {
        if (ops.length !== 2) return null;
        const [target, value] = ops;
        // The target is a symbol, or an `At` whose list operand is a symbol.
        // `At` is not canonicalized as a whole: its canonical form could
        // change the shape (a literal position folded into another head).
        // The equivalent assignment is canonicalized before the target: the
        // canonical symbol declares a name that no scope declares, and the
        // assignment must see that name undeclared to report an assignment
        // to an undeclared variable (`equivalentAssign()`).
        //
        // For the same reason, the target is checked on the raw target
        // before the positions and the value are canonicalized, as the
        // canonical `Assign` checks its target before its value: `t` in
        // `AddTo(t, t)`, or `L` in `AddTo(At(L, Length(L)), 1)`, would
        // otherwise be declared by the canonical value or position, and the
        // check would not see it.
        const name = isSymbol(target)
          ? target.symbol
          : isFunction(target, 'At') && isSymbol(target.op1)
            ? target.op1.symbol
            : undefined;
        if (
          name !== undefined &&
          name !== 'Nothing' &&
          isInBodyOrBranch() &&
          !isDeclaredForAssignment(ce, name) &&
          !ce._isShadowedParameter(name)
        )
          return ce.error(['assignment-to-undeclared-variable', name]);
        if (isFunction(target, 'At') && isSymbol(target.op1)) {
          const positions = target.ops.slice(1).map((x) => x.canonical);
          const v = value.canonical;
          const assign = equivalentAssign(ce, target.op1, positions, v);
          if (!assign.isValid) return assign;
          return ce._fn('AddTo', [
            ce._fn('At', [target.op1.canonical, ...positions]),
            v,
          ]);
        }
        if (isSymbol(target)) {
          const v = value.canonical;
          const assign = equivalentAssign(ce, target, undefined, v);
          if (!assign.isValid) return assign;
          return ce._fn('AddTo', [target.canonical, v]);
        }
        return null;
      },
      evaluate: (ops, { engine: ce }) => evaluateAddTo(ce, ops[0], ops[1]),
      // The same steps, with each operand evaluated by `evaluateAsync()`, so
      // that `s += f(x)` awaits an operator that has only an asynchronous
      // handler, as `s = s + f(x)` does.
      evaluateAsync: (ops, options) =>
        runOperandStepsAsync(
          addToSteps(options.engine, ops[0], ops[1]),
          options
        ),
    },

    // Engine-internal: the domain of the first clause of a parallel loop or
    // comprehension, after the JavaScript target lowered
    // `ParallelLoop(body, Element(x, xs))` to `Loop(body, Element(x,
    // ParallelDomain(xs)))` (`lowerParallelHeads()`,
    // `compilation/parallel-lowering.ts`). The compiled code iterates it with
    // the pass frames (`_SYS.parallelPasses()`). Its value is its operand.
    ParallelDomain: {
      description:
        'The domain of the passes of a parallel loop (engine-internal).',
      // `random`: inside a frame, the loop consumes one draw index of it, so
      // the node is not pure, and constant folding keeps it (a folded domain
      // would lose the pass frames).
      signature: '(collection:any) random -> any',
      // The type of the operand, except for a string: the compiled domain of
      // a string is the list of its grapheme clusters (`_SYS.chars`), each a
      // `character` as in the interpreter, so the loop iterates it as a
      // list, not as a string.
      type: ([xs], { engine }) =>
        BoxedType.forResult(
          xs !== undefined &&
            xs.type !== 'never' &&
            isSubtype(xs.type, 'string')
            ? 'list<character>'
            : (xs?.type ?? 'unknown'),
          engine._typeResolver
        ),
      evaluate: ([xs]) => xs,
    },

    // `Break`/`Continue` are inert: they have no `evaluate` handler, so they
    // evaluate to themselves (with their operands evaluated) and are
    // intercepted structurally by `Loop`/`Block`. They are NOT `lazy`: the
    // optional `Break` value must be evaluated in the loop context so a value
    // referencing the loop variable is concrete (mirrors `Return`).
    Break: {
      description:
        'Exit the enclosing loop immediately, optionally with a value ' +
        '(`Break(v)`) that becomes the loop value.',
      signature: '(value:any?) -> nothing',
    },

    Continue: {
      description: 'Skip to the next iteration of the enclosing loop.',
      signature: '() -> nothing',
    },

    Which: {
      description:
        '`Which(c1, e1, c2, e2, …)` evaluates to the value of the first `e` whose condition `c` is `True`, and to `Missing` when no condition is `True`. A last clause with the condition `True` is the default. Only the selected expression is evaluated.\n' +
        'Element-wise selection: when a condition is a flat list of booleans (`L < 3` with `L` a list), the selection is made at each position, as `numpy.select` does, and the value is a list. At each position, the first clause whose condition is `True` there gives the value: an expression that is a list gives its element at that position, any other expression gives its own value. With `L = [1, 3, 5]`, `Which(L < 2, 10, L < 4, L, True, 0)` is `[10, 3, 0]`. A selected expression whose type is a list and whose elements cannot be read yet (`foo(L)` with `foo` undeclared) keeps the `Which` symbolic.\n' +
        '  - A condition that is not a list applies to every position.\n' +
        '  - Every expression is a number, a point, or a flat list of numbers or of points with the length of the condition, and all have one kind. A nested list, a list of another length, a string and a list of strings are static errors, as is a condition that is a nested list or holds a `Missing` cell. A relation (a boolean) is accepted.\n' +
        '  - A position that no clause selects holds `NaN` for a number, a point whose coordinates are `NaN` for a point, and `Missing` for a boolean.',
      keywords: ['piecewise'],
      lazy: true,
      // The conditions (even positions) are values, the values of the
      // clauses (odd positions) are statements.
      operands: (ops) =>
        ops.map((_, i) => (i % 2 === 0 ? VALUE_ROLE : STATEMENT_ROLE)),
      // Selects among its operands, so an error in an operand it does not
      // choose does not bubble (`docs/ERROR-MODEL.md` §3).
      selectsOperands: true,
      signature: '(expression+) -> unknown',
      // A SELECTOR, like `If`: conditions are tested, the first matching arm is
      // evaluated and RETURNED, and no position applies a function-valued
      // operand. Held-position (production) effects are unaffected.
      invokes: false,
      // The handler reads the operands' types plus one structural fact — a
      // literal `True` condition names the default clause — so it is declared
      // on the descriptor shape and cannot touch engine state.
      type: (args, context) => {
        // The operands are strictly PAIRED, so an odd count is a malformed
        // call, and the `canonical` handler below turns such a call into an
        // `Error`. An odd list still reaches this handler on the structural
        // route, which skips canonicalization — but that expression
        // canonicalizes when it is evaluated, so its VALUE is that same
        // `Error`. The one route that reads an odd list as a working
        // selection is `ce._fn('Which', …)`, which tags the node canonical
        // without running the handler; that is internal engine construction,
        // not something user input reaches. Report what every user-reachable
        // route produces.
        if (args.length % 2 !== 0)
          return BoxedType.forResult('error', context.engine._typeResolver);
        let arms = args.filter((_, i) => i % 2 === 1);
        let conds = args.filter((_, i) => i % 2 === 0);
        // Only the REACHABLE clauses contribute: a literal `True` condition is
        // the default clause, and evaluation never looks past it. The walk must
        // stop there too, or `Which(True, 1, [True, False], 2)` — which
        // evaluates to the scalar `1` — would be typed element-wise by a
        // condition that is never even evaluated.
        const dflt = conds.findIndex((c) => {
          const st = c?.structureOf?.();
          return st?.kind === 'symbol' && st.name === 'True';
        });
        if (dflt >= 0) {
          conds = conds.slice(0, dflt + 1);
          arms = arms.slice(0, dflt + 1);
        }
        // A condition that is provably a mask (a collection of condition
        // values) selects element-wise (see `evaluateElementwiseSelection`):
        // the result is a list of the types of the elements of the arms.
        const shape = elementwiseConditionShape(conds.map((c) => c?.type));
        if (shape) {
          const elementwise = elementwiseResultType(
            arms,
            shape,
            // A literal `True` condition is the default clause: it matches
            // every position, so the `NaN` no-match cell is unreachable.
            dflt >= 0,
            context.engine
          );
          // A clause before the first mask whose condition is a scalar
          // `True` at run time selects its arm WHOLE (`evaluateWhich`), so
          // the result is that arm or the element-wise list: with
          // `x := 1`, `Which(x > 0, 5, [True, False], 1, True, 0)` is `5`.
          // An untyped symbol arm makes that outcome unknown, as for the
          // scalar typing (`untypedSymbolArm`).
          const whole = arms
            .slice(0, shape.firstMask)
            .map((x): Type =>
              untypedArm(x, context.engine) ? 'unknown' : x.type
            );
          return BoxedType.forResult(
            whole.length === 0
              ? elementwise
              : reduceType({ kind: 'union', types: [elementwise, ...whole] }),
            context.engine._typeResolver
          );
        }
        // A condition that is only POSSIBLY a boolean collection selects
        // element-wise for some of its runtime values and picks a single arm
        // for the others: `broadcastable` of the element-wise cell type,
        // joined with each arm that this type does not admit
        // (`possiblyElementwiseResultType`), covers both.
        // Without a literal-`True` default clause no arm may be selected and
        // the value is `Missing` — keep that arm in the type, as the
        // else-less `If` does, and outside `widen` (which joins toward a
        // common supertype and would dissolve the absence marker). The
        // possibly-element-wise branch carries the arm too: such a condition
        // may resolve to a scalar `False` at runtime, and the `Which` then
        // answers the scalar `Missing`.
        if (possiblyElementwiseCondition(conds.map((c) => c?.type))) {
          const broadcast = possiblyElementwiseResultType(
            arms.map((x) => x.type),
            dflt >= 0
          );
          return BoxedType.forResult(
            dflt >= 0
              ? broadcast
              : reduceType({ kind: 'union', types: [broadcast, 'missing'] }),
            context.engine._typeResolver
          );
        }
        if (arms.length === 0)
          return BoxedType.forResult('missing', context.engine._typeResolver);
        // An untyped symbol among the values makes the result unknown, as
        // for `If` (`untypedSymbolArm`).
        const armType = arms.some((x) => untypedArm(x, context.engine))
          ? 'unknown'
          : widen(...arms.map((x) => x.type));
        const scalar: Type =
          dflt >= 0
            ? armType
            : reduceType({ kind: 'union', types: [armType, 'missing'] });
        // When the only condition that is not a scalar is a scalar or a mask
        // (`boolean | list<boolean>`, `scalarOrMaskConditionShape`), the
        // result is the scalar result or the element-wise result of its
        // masks, which reads every reachable arm as the evaluation does.
        // When another condition is not a scalar either, the scalar typing
        // above is kept.
        const mixed = scalarOrMaskConditionShape(conds.map((c) => c?.type));
        // Otherwise, when a condition that is not a scalar cannot be read
        // and may hold a list (two conditions of type `boolean |
        // list<boolean>`, an operand of type `unknown`), it can be a mask at
        // run time, and the element-wise result for a mask whose type does
        // not settle that it is flat is added to the scalar result.
        const shapeOfMasks =
          mixed ??
          (conds.some(
            (c) => c !== undefined && unreadableConditionMayBeMask(c.type)
          )
            ? {}
            : undefined);
        if (shapeOfMasks)
          return BoxedType.forResult(
            reduceType({
              kind: 'union',
              types: [
                scalar,
                elementwiseResultType(
                  arms,
                  shapeOfMasks,
                  dflt >= 0,
                  context.engine
                ),
              ],
            }),
            context.engine._typeResolver
          );
        return BoxedType.forResult(scalar, context.engine._typeResolver);
      },
      canonical: (args, options) => {
        // The operands are strictly PAIRED `(condition, value)`, so the
        // count must be even. An unconditional default clause is written as
        // a literal `True` condition — that is what the LaTeX `cases` parser
        // emits for a row that carries no condition
        // (`\begin{cases} x & x>0 \\ -x \end{cases}` boxes as
        // `Which(0 < x, x, "True", -x)`), and what the `type` handler above
        // reads to decide that no clause after it is reachable. There is no
        // trailing-default form, so an odd operand count is a malformed
        // call. Report it: answering `Nothing` turned a malformed call into
        // an ordinary value, which hid the mistake — `Which(True, 1, 2)` and
        // `Which(False, 1, 2)` both came back `Nothing`.
        if (args.length % 2 !== 0)
          return options.engine.error(
            '`Which` takes alternating condition and value operands, so it ' +
              'needs an even number of operands. Write an unconditional ' +
              'default clause as a `True` condition: `Which(cond, a, True, b)`'
          );
        // The even positions are conditions, checked for a provably
        // non-boolean type (`conditionOperand`); the odd positions are the
        // values, canonicalized as written. When a condition is a flat list
        // of booleans, the selection is element-wise, and every arm must be
        // a number or a point; a boolean and a statement are also accepted
        // (`selectionArmError`).
        const ops = args.map((x, i) =>
          i % 2 === 0
            ? conditionOperand(options.engine, x.canonical)
            : canonicalArm(options.engine, x, false)
        );
        if (ops.some((x, i) => i % 2 === 0 && isListCondition(x))) {
          const armError = selectionArmError(
            options.engine,
            ops.filter((_, i) => i % 2 === 0),
            ops.filter((_, i) => i % 2 === 1)
          );
          if (armError !== undefined) return armError;
        }
        return options.engine._fn('Which', ops);
      },
      evaluate: (ops, options) => evaluateWhich(ops, options),
      evaluateAsync: (ops, options) => evaluateWhichAsync(ops, options),
    },

    // Structural pattern matching (Epsil `match`). See
    // `docs/LANGUAGE-MODEL.md` and
    // `boxed-expression/match-dispatch.ts`.
    Match: {
      description:
        'Structural pattern match. `Match(subject, MatchCase(pattern, body), …)` ' +
        'evaluates `subject` once, then selects the first case whose pattern ' +
        'matches (structurally, `isSame`-like) and whose guard holds, applying ' +
        'its body to the captured values. Unlike `Which`, `Match` always ' +
        'decides: a symbolic subject that is not structurally a case still ' +
        'falls through to a wildcard case. No matching case yields ' +
        '`Error("match-no-case", subject)`.',
      lazy: true,
      // `Match` is the rescue construct (error-propagation design §2, rung 1):
      // it decides on an ERROR subject instead of freezing with it, restoring
      // the pinned "always decides" totality. The subject is matched
      // structurally on whatever it evaluated to, so an error fails every
      // literal/shape case and falls through to `_`, a binding, or `...`.
      inspectsErrors: true,
      signature: '(expression, expression+) -> unknown',
      // The handler reads each case's inert structure (its head and the type
      // of its last child), never an operand expression.
      type: (ops, context) => {
        // Result is the widened type of the case bodies (the last operand of
        // each `MatchCase`), mirroring `If`/`Which`. Bodies reference capture
        // names free at this scope, so most resolve to `unknown` — widen is a
        // best-effort hint.
        const bodyTypes: Type[] = [];
        for (const c of ops.slice(1)) {
          const st = c?.structureOf?.();
          if (st?.kind !== 'application' || st.head !== 'MatchCase') continue;
          if (st.children.length < 2) continue;
          bodyTypes.push(st.children[st.children.length - 1].type);
        }
        if (bodyTypes.length === 0)
          return BoxedType.forResult('nothing', context.engine._typeResolver);
        return BoxedType.forResult(
          widen(...bodyTypes),
          context.engine._typeResolver
        );
      },
      canonical: (ops, { engine: ce }) => {
        if (ops.length === 0) return ce.Nothing;
        // Canonicalize the subject (op 0); keep each case's pattern/guard/body
        // raw (via the `MatchCase` canonical handler) so wildcards are not
        // mangled by canonicalization before matching.
        const ops2 = [
          ops[0].canonical,
          ...ops.slice(1).map((c) => c.canonical),
        ];
        // A case of a `Match` is a branch, as a branch of an `If` is, in a
        // block and at the top level: an assignment in it to a name that no
        // scope declares is a static error
        // (`assignment-to-undeclared-variable`). The case bodies stay raw,
        // so the check reads their structure (`firstAssignmentInCase()`).
        for (const cc of getMatchPlan(ce, ops2).segments.flatMap(
          (seg) => seg.cases
        )) {
          const captures = new Set(cc.captureNames);
          for (const part of [cc.guard, cc.body]) {
            const name =
              part === undefined
                ? undefined
                : firstAssignmentInCase(ce, part, captures);
            if (name !== undefined)
              return ce.error(['assignment-to-undeclared-variable', name]);
          }
        }
        // An assignment in a case body to a local of the enclosing block is
        // an assignment of that local, and the static type of the local
        // must admit its value. The case bodies stay raw, so canonicalize
        // each closure once now, in the scope of the block, only for the
        // assignment evidence that its `Assign` records
        // (`joinAssignmentEvidence`, `library/core.ts`). The closure is
        // discarded: the evaluation builds its own (`buildCaseClosure`).
        // Without this, `let xs = [1, 2, 3]; while let [h, ...] = xs
        // { xs = Rest(xs) }; xs` was typed `vector<integer^3>` and
        // evaluated to `[]`.
        if (isInEvidenceSession(ce)) {
          for (const cc of getMatchPlan(ce, ops2).segments.flatMap(
            (seg) => seg.cases
          )) {
            for (const part of [cc.guard, cc.body]) {
              if (part === undefined || !containsAssignment(part)) continue;
              // A value of another type than the local is a static error
              // of the `Match`, as in a branch of an `If`
              // (`assignment-type-mismatch`).
              const mismatch = assignmentTypeMismatchIn(
                buildCaseClosure(ce, part, cc.captureNames)
              );
              if (mismatch !== undefined) return mismatch;
            }
          }
        }
        return ce._fn('Match', ops2);
      },
      evaluate: (ops, options) => evaluateMatch(ops, options),
    },

    // A single match case: `MatchCase(pattern, body)` or
    // `MatchCase(pattern, guard, body)`. Inert data (`holdAll`): the operands
    // are kept raw — the pattern holds engine wildcards (`_x`, `__x`, …) as-is,
    // and the guard/body are lowered to `Function` closures at match time.
    MatchCase: {
      description:
        'A case of a `Match`: `MatchCase(pattern, body)` or ' +
        '`MatchCase(pattern, guard, body)`. The pattern holds engine ' +
        'wildcards; the body references the bound capture names.',
      lazy: true,
      // The body, the last operand, is a statement: `Match` runs it. The
      // pattern and the guard are kept as written.
      operands: (ops) =>
        ops.map((_, i) =>
          (ops.length === 2 || ops.length === 3) && i === ops.length - 1
            ? STATEMENT_ROLE
            : RAW_ROLE
        ),
      signature: '(expression, expression, expression?) -> nothing',
      // Keep the operands raw (do not canonicalize the pattern): return a
      // canonical-tagged node whose operands are preserved verbatim.
      canonical: (ops, { engine: ce }) =>
        ce._fn('MatchCase', ops, { canonical: true }),
    },

    // Marker for a pinned computed expression inside a pattern: `Pin(expr)`
    // matches the *value* of `expr` (evaluated in the enclosing lexical scope
    // at match time), not its structure. Inert (resolved by `Match`).
    Pin: {
      description:
        'Inside a `Match` pattern, `Pin(expr)` matches the value of `expr` ' +
        '(evaluated at match time) rather than its structure.',
      lazy: true,
      signature: '(expression) -> nothing',
    },

    // Marker for top-level or-alternatives in a `MatchCase` pattern:
    // `Alternatives(p1, p2, …)`. Binding-free by contract. Inert (expanded by
    // `Match` into consecutive virtual cases sharing the guard and body).
    Alternatives: {
      description:
        'Inside a `Match` pattern, `Alternatives(p1, p2, …)` matches if any ' +
        'alternative matches. Alternatives must be binding-free.',
      lazy: true,
      signature: '(expression+) -> nothing',
      canonical: (ops, { engine: ce }) =>
        ce._fn('Alternatives', ops, { canonical: true }),
    },

    FixedPoint: {
      examples: [
        'FixedPoint(x => (x + 2 / x) / 2, 1.0)',
        'FixedPoint(Cos, 1.0)',
      ],
      description: [
        'Apply a function repeatedly, starting from an initial value, until two successive values are the same: `FixedPoint(f, x)` is the first of `f(x)`, `f(f(x))`, … that `f` maps to itself.',
        'Two values are the same when they are structurally identical, or when they are numbers, one of them a float, that agree to the working precision (their difference is at most a few units of the last digit, relative to their size), or when they are lists or tuples of the same length whose elements are the same. A sequence of exact values stops only when two of them are identical.',
        'Without a maximum, the call stays unevaluated when the iteration cannot converge: when a value contains the previous one (`FixedPoint(Cos, 1)`: `Cos(1)` is exact, and `Cos(Cos(1))` nests it), or when an exact number gains digits at each step. Start from a float (`FixedPoint(Cos, 1.0)`), or evaluate with `N`, for a numeric fixed point.',
        'The optional third argument is the maximum number of applications, a positive integer. It defaults to the engine iteration limit, and then the call stays unevaluated if the iteration has not converged by that limit (raise `ce.iterationLimit` for a slower one). An Epsil program has no iteration limit unless the host sets one, so there an iteration that does not converge stops only at a maximum or at a time limit. When an explicit maximum is reached, the last value is returned.',
      ],
      complexity: 8200,
      // The callback slot is the bare `function` primitive, as for `Iterate`:
      // the result type of the function is the type of the result, which the
      // signature grammar cannot relate to the initial value. The type
      // handler reads it instead.
      signature: '(function, initial: any, maxIterations: integer?) -> unknown',
      // The result is a value of the function (the loop applies it at least
      // once), so its type is the function's result type. A function whose
      // result type is not known gives the declared `unknown`. `widen` is
      // not used: it drops an `unknown` operand, which would type the result
      // as the initial value.
      type: ([f], { engine }) => {
        const result = functionResult(f?.type);
        if (result === undefined || result === 'unknown') return undefined;
        return BoxedType.forResult(result, engine._typeResolver);
      },
      canonical: (ops, { engine: ce }) => {
        // Each problem is reported in the slot of the operand, as the
        // boxing validation does (`checkArity`): a missing operand is
        // `Error("missing")`, an extra one `Error("unexpected-argument")`.
        // The callback is checked as for the other callback operators
        // (`canonicalCallbackOperand`): a value that is not a function (`3`,
        // a string) and a function that cannot take one argument are
        // errors, and an explicit function of no parameter (`() => 42`) is
        // accepted, as it ignores its arguments.
        const fnOp = ops[0];
        const fn =
          fnOp === undefined
            ? ce.error('missing')
            : (canonicalCallbackOperand(fnOp, {
                operator: 'FixedPoint',
                supply: FIXED_POINT_SUPPLY,
              }) ?? ce.typeError('function', fnOp.canonical.type.type, fnOp));
        return ce._fn('FixedPoint', [
          fn,
          ops[1]?.canonical ?? ce.error('missing'),
          ...ops.slice(2, 3).map((x) => x.canonical),
          ...ops
            .slice(3)
            .map((x) => ce.error('unexpected-argument', x.toString())),
        ]);
      },
      evaluate: (ops, { engine: ce, numericApproximation }) => {
        const [fn, initial, maxOp] = ops;
        if (fn === undefined || initial === undefined) return undefined;
        let limit = ce.iterationLimit;
        if (maxOp !== undefined) {
          // A maximum that is not a number yet (a symbol with no value)
          // leaves the call unevaluated.
          if (!isNumber(maxOp)) return undefined;
          if (!maxOp.isInteger || maxOp.re < 1)
            return ce.error('expected-positive-integer', maxOp.toString());
          limit = maxOp.re;
        }
        const f = applicable(fn);
        let x = numericApproximation ? initial.N() : initial;
        // Without a maximum, an iteration that cannot converge leaves the
        // call unevaluated (`isDivergingFixedPointStep`): `Cos(1)` stays
        // exact, so the values nest (`Cos(Cos(1))`, …), and Newton's
        // iteration on exact rationals doubles its digits at each step.
        // Either one would run to the iteration limit on values whose cost
        // grows at each step. With a maximum, the caller bounds the work, and
        // the last value is returned as the description says.
        const sizeBound =
          maxOp === undefined
            ? Math.max(FIXED_POINT_MIN_SIZE_BOUND, 8 * x.toString().length)
            : undefined;
        const epsilon = fixedPointEpsilon(ce.precision);
        for (let i = 0; i < limit; i++) {
          checkDeadline(ce._deadlineFrame);
          let y = f([x]);
          // A function that cannot be applied leaves the call unevaluated.
          if (y === undefined) return undefined;
          if (numericApproximation) y = y.N();
          if (y.operator === 'Error') return y;
          if (isSameFixedPointValue(x, y, epsilon)) return y;
          if (
            sizeBound !== undefined &&
            isDivergingFixedPointStep(x, y, sizeBound)
          )
            return undefined;
          x = y;
        }
        // The default limit is a budget, not a bound the caller asked for: a
        // value that has not converged is not a fixed point (`x ↦ 1 - x`
        // from 0.3 cycles forever), so the call stays unevaluated, as
        // `Any` does over an unbounded source. An explicit maximum returns
        // the last value.
        return maxOp === undefined ? undefined : x;
      },
    },
  },
];

/**
 * The type of the restriction `e\{c\}`, the single-branch `If(c, e)` whose
 * arm is a value, from the descriptors of `e` and `c`, so that the type and
 * the value of `evaluateRestriction()` agree.
 */
function restrictionType(
  [expr, cond]: ReadonlyArray<OperandDescriptor | undefined>,
  context: TypeHandlerContext
): BoxedType {
  // A list/vector-of-booleans condition broadcasts: the result is a
  // list whose element type is `expr`'s type (see the broadcast branch
  // of `evaluateRestriction()`), but only when the condition's
  // *declared* type is a list/vector of booleans. A scalar or unknown
  // boolean condition keeps `expr`'s type.
  if (expr === undefined)
    return BoxedType.forResult('unknown', context.engine._typeResolver);
  // The mask test accepts any collection of booleans, not only a
  // `list` (see `BOOLEAN_MASK_TYPE`): the `evaluate` handler zips every
  // finite collection of boolean cells, so a condition typed
  // `set<boolean>` or `indexed_collection<boolean>` is a mask as much
  // as a `list<boolean>` is.
  // A mask whose type does not settle that it is flat (`tensor<boolean>`)
  // is checked on its value: a flat value restricts as below, and a value
  // that is not flat is the `incompatible-type` error. The result has the
  // type of an element-wise selection by such a mask.
  const shape =
    cond === undefined ? undefined : elementwiseConditionShape([cond.type]);
  if (shape !== undefined && shape.rank !== 1)
    return BoxedType.forResult(
      elementwiseResultType([expr], shape, false, context.engine),
      context.engine._typeResolver
    );
  if (cond !== undefined && isSubtype(cond.type, BOOLEAN_MASK_TYPE)) {
    // Built structurally, not from a type STRING: a literal element
    // type (`If([c1, c2], 1)` types `list<1 | missing>`) has no
    // string spelling the parser accepts inside a union.
    //
    // A list-valued `expr` is zipped with the mask, cell by cell (see
    // the broadcast branch in `evaluate`), so the cells of the result
    // are the CELLS of `expr`, not `expr` itself:
    // `[10,20,30]{[1,2,3] > 2}` is `[Missing, Missing, 30]`, a
    // `list<integer | missing>`. A scalar `expr` is masked whole in
    // every cell.
    //
    // The `evaluate` handler zips a finite collection value that is
    // not a tuple (a point is one value) and not a string (atomic
    // under restriction), and it zips an ORDERED carrier
    // (`isOrderedCarrierType`) whatever its length, reading only the
    // elements the mask needs. When the elements of an ordered
    // carrier cannot be read (a valueless symbol, a range with a free
    // bound), the restriction is held whole, so its value is typed by
    // this handler. Otherwise each cell is the WHOLE value. A type
    // with a tuple or a string arm (`tuple<number, number> |
    // list<tuple<number, number>>`) is not ordered: it takes the join
    // branch below, because its value can be one point. The type
    // follows the same rule:
    // - a carrier that is finite by type (`FINITE_COLLECTION_TYPE`: a
    //   `list<T>`, a `vector`, a `matrix`, a `dictionary`, a `record`,
    //   a `range`) or ordered by type (`indexed_collection<T>`, which
    //   can be infinite, such as `Range(1, ∞)`) is always zipped, so
    //   each cell has its ELEMENT type `T`. `If([True, False],
    //   Range(1, ∞))` evaluates to `[1, NaN]` (a masked number is
    //   `NaN`);
    // - a carrier of an UNORDERED collection type that is not finite
    //   by type (`collection<T>`, `set<T>`) can hold an infinite set,
    //   such as `Integers`, which has no first element and is not
    //   zipped: each cell is then the whole value. So a cell can be
    //   either an element (a finite set is zipped) or the whole value,
    //   and its type is the JOIN of the element type and the carrier
    //   type. `If([True, False], Integers)` evaluates to
    //   `[Integers, Missing]`, which the element type `integer` alone
    //   does not admit;
    // - a tuple, a string or a scalar value is never zipped, so each
    //   cell has the type of the whole value.
    // The result is a `list` whatever the carrier is, because the
    // value the `evaluate` handler builds is a `List`.
    const zippable =
      isSubtype(expr.type, COLLECTION_SHAPE_TYPE) &&
      !isTupleShapedType(expr.type) &&
      !isSubtype(expr.type, 'string');
    const element = zippable
      ? (collectionElementType(expr.type) ?? 'unknown')
      : undefined;
    const cell: Type =
      element === undefined
        ? expr.type
        : isSubtype(expr.type, FINITE_COLLECTION_TYPE) ||
            // An ordered type that admits a STRING value
            // (`indexed_collection<character>`) takes the join branch:
            // a string is one value under a restriction, never zipped
            // (`isAtomicCarrierValue`), so a cell can be the whole
            // string, which the element type `character` does not
            // admit.
            (isOrderedCarrierType(expr.type) && !isSubtype('string', expr.type))
          ? element
          : reduceType({
              kind: 'union',
              // A masked numeric element of a zipped finite set is
              // `NaN`, so a numeric element arm is `number`, the type
              // that admits `NaN`, as the zipped branch above answers
              // `list<number>`: `If([True, False], {1, 2})` is
              // `[1, NaN]`.
              types: [
                isNumericValueType(element) ? 'number' : element,
                expr.type,
              ],
            });
    // A masked NUMERIC cell is `NaN` (`maskedValue`), so the cells are
    // numbers, `list<number>`: the materialized list the mask answers
    // (`[NaN, NaN, 30]`) is typed by the `List` handler, which joins a
    // `NaN` cell and an integer cell to `number`. A masked point cell is a
    // `NaN` point (`unmatchedCell()`), so a point cell joins in a point of
    // `number` coordinates. Any other cell keeps its `missing` arm.
    return BoxedType.forResult(
      {
        kind: 'list',
        elements: isNumericValueType(cell)
          ? 'number'
          : withUnmatchedCellType(cell),
      },
      context.engine._typeResolver
    );
  }
  // A scalar condition keeps the type of the value, with no `nan` or
  // `missing` arm: the `NaN` or `Missing` that a false condition gives
  // sits outside the declared type, as `NaN` sits outside `real`
  // (decision 2026-11-02, `docs/plans/2026-11-02-restriction-binding.md`).
  // A boolean value is the exception: a false condition gives `False`
  // (`maskedValue()`), a value of the type `boolean`, so the type admits
  // it. `If(c, Equal(1, 1))` is typed `boolean`, not `true`: with the type
  // `true`, a compiled condition `If(If(c, 1 = 1), 1, 2)` was dropped as
  // always true, and gave 1 where `c` is false.
  if (unmatchedCellKind(expr.type) === 'boolean')
    return BoxedType.forResult(
      widen(expr.type, 'boolean'),
      context.engine._typeResolver
    );
  return BoxedType.forResult(expr.type, context.engine._typeResolver);
}

/** The smallest bound, in characters of the printed value, on the size of
 * an exact number of `FixedPoint` (see `isDivergingFixedPointStep`). */
const FIXED_POINT_MIN_SIZE_BOUND = 512;

/** `FixedPoint` applies its function to the previous value alone. */
const FIXED_POINT_SUPPLY: CallbackSupply = {
  count: 1,
  describes: 'the previous value',
};

/**
 * The relative difference under which two floats of `FixedPoint` are the
 * same, for the engine precision `precision` (in decimal digits).
 *
 * At machine precision, the last 7 bits of the two floats may differ (as for
 * the `SameQ` of Mathematica): `2^-46`, about `1.4e-14`. At a higher
 * precision, the last 2 decimal digits may differ: `10^-(precision - 2)`.
 * The test is relative: the absolute engine tolerance (`1e-10`) stopped the
 * iteration for √(1e-24) at five times the root, and returned a value with
 * only 10 correct digits of the 21 printed.
 */
function fixedPointEpsilon(precision: number): number {
  return precision <= MACHINE_PRECISION ? 2 ** -46 : 10 ** -(precision - 2);
}

/**
 * Whether two successive values of `FixedPoint` are the same, which ends the
 * iteration:
 *
 * - they are structurally identical (`isSame`);
 * - they are number literals, one of them a float, whose difference is at
 *   most `epsilon` times the larger magnitude (`fixedPointEpsilon`). Two
 *   exact numbers must be identical: a sequence of exact rationals that
 *   converges never has two equal terms;
 * - they are lists or tuples of the same length whose elements are the same
 *   by these rules, so a vector iteration stops as a scalar one does.
 */
function isSameFixedPointValue(
  a: Expression,
  b: Expression,
  epsilon: number
): boolean {
  if (a.isSame(b)) return true;
  if (isNumber(a) && isNumber(b)) {
    if (a.isExact && b.isExact) return false;
    const d = b.sub(a);
    if (!isNumber(d)) return false;
    // A `NaN` or an infinite difference compares false.
    return (
      Math.hypot(d.re, d.im) <=
      epsilon * Math.max(Math.hypot(a.re, a.im), Math.hypot(b.re, b.im))
    );
  }
  if (
    isFunction(a) &&
    isFunction(b) &&
    a.operator === b.operator &&
    (a.operator === 'List' || a.operator === 'Tuple') &&
    a.nops === b.nops
  )
    return a.ops.every((x, i) => isSameFixedPointValue(x, b.ops[i], epsilon));
  return false;
}

/**
 * Whether the step from `x` to `y` shows that the iteration of `FixedPoint`
 * cannot converge, so that the call stays unevaluated:
 *
 * - `y` contains `x` as a proper part: the function did not evaluate to a
 *   new value, but wrapped the previous one (`Cos(1)` from `1`,
 *   `Sqrt(1 + Sqrt(2))` from `Sqrt(2)`), and each step nests it again;
 * - `y` is an exact number whose printed form is longer than `sizeBound`
 *   characters: the terms of an exact iteration that converges to an
 *   irrational number gain digits at each step.
 *
 * A float, a string and a collection of floats have a fixed size and are
 * never cut short.
 */
function isDivergingFixedPointStep(
  x: Expression,
  y: Expression,
  sizeBound: number
): boolean {
  if (isNumber(y)) return y.isExact && y.toString().length > sizeBound;
  if (!isFunction(y)) return false;
  return y.ops.some((op) => containsSubexpression(op, x));
}

/** Whether `e` is `part`, or has it as a part at any depth. */
function containsSubexpression(e: Expression, part: Expression): boolean {
  if (e.isSame(part)) return true;
  return isFunction(e) && e.ops.some((op) => containsSubexpression(op, part));
}

/**
 * Whether a value of type `t` masks to `NaN`: its type, less any `missing`
 * arm, is a number. A value that is not provably numeric masks to the
 * absent value of its own domain (`maskedValue()`): the point of `NaN`
 * coordinates for a point (`pointArity()`), `False` for a boolean, and
 * `Missing` otherwise (a list, a string, `unknown`). `absentScalarMarker`
 * (`boxed-expression/validate.ts`) reads the codomain of an application in
 * the same way for a number.
 */
function isNumericValueType(t: Type): boolean {
  const present = stripMissingFromType(t);
  return present !== 'never' && isSubtype(present, 'number');
}

/**
 * The value a false restriction answers for `expr`: the absence marker of
 * the value's own type, `NaN` for a number, a point of `NaN` coordinates
 * for a point (a tuple of numbers, `pointArity()`), and `Missing`
 * otherwise (user decisions 2026-09-25 and 2026-11-03). One rule for
 * absence, then: every operator answers the marker of its codomain for an
 * absent operand (`docs/ERROR-MODEL.md`, §2 rule 4), and a restriction
 * answers the marker of its value. Before, a restriction masked every value
 * to `Missing`, so a masked NUMBER read as `Missing` on the route that held
 * the restriction and as `NaN` on the route that evaluated it fresh
 * (`2·x{c}` versus `2·Missing`).
 *
 * A boolean value (a relation, a region of a plot) masks to `False`: the
 * logic is two-valued, so the absent boolean is `False`, as the cell of a
 * relation arm under a list of conditions is (`unmatchedCell()`), and
 * `If(c, x > 0)` in a condition reads as `c ∧ x > 0` (user decision
 * 2026-11-02, two-valued comparisons; corpus row neyret/xhlkk7k9aq, whose
 * condition is `If(c_2 < 1, 0 < If(c_1 < 1, 1))`).
 */
function maskedValue(ce: ComputeEngine, expr: Expression): Expression {
  if (isNumericValueType(expr.type.type)) return ce.NaN;
  // A point (a tuple of numbers) masks to the point of `NaN` coordinates of
  // its arity, the absent value of the domain of a point
  // (`docs/ERROR-MODEL.md`, "`Missing` is a result only", rule 2), as a
  // read out of range of a list of points gives.
  const n = pointArity(expr.type.type);
  if (n !== undefined) return nanPoint(ce, n);
  return unmatchedCellKind(expr.type.type) === 'boolean'
    ? ce.False
    : ce.Missing;
}

/** The type of a point of `n` coordinates that can be `NaN`. */
function nanPointType(n: number): Type {
  return {
    kind: 'tuple',
    elements: Array.from({ length: n }, () => ({ type: 'number' as Type })),
  };
}

/**
 * The value of a POSITION that an element-wise selection or a mask does not
 * select, from the type `t` of the value at that position: `NaN` for a
 * number, a point whose coordinates are all `NaN` for a point (a plotter
 * skips such a point, as Desmos skips an undefined element), `False` for a
 * boolean (a relation arm is a region of a plot, and the region is not
 * drawn there), the colour `Rgb(NaN, NaN, NaN)` for a colour (a plotter
 * reads a colour with a channel that is not finite as "no colour here"),
 * and `Missing` otherwise. A position is never `undefined` and never needs
 * `IsMissing` or `Coalesce` to be read (selection rule of 2026-11-02,
 * `docs/BROADCAST-MODEL.md`, which reverses the decision of 2026-10-18 that
 * a point cell with no match is absent; the boolean and colour cells are
 * from the two-valued comparisons of 2026-11-02, Tycho item 189 for the
 * colour). A scalar condition that is false selects no arm WHOLE, and gives
 * `maskedValue()` instead.
 */
function unmatchedCell(ce: ComputeEngine, t: Readonly<Type>): Expression {
  if (isNumericValueType(t as Type)) return ce.NaN;
  const n = pointArity(t);
  if (n !== undefined) return nanPoint(ce, n);
  const kind = unmatchedCellKind(t);
  if (kind === 'boolean') return ce.False;
  if (kind === 'color') return ce._fn('Rgb', [ce.NaN, ce.NaN, ce.NaN]);
  return ce.Missing;
}

/**
 * The cell at one position of a restriction by a list of conditions, from
 * the condition `c` at that position and the value `elem` there: the
 * `NaN` point, `False` or the `NaN` colour when `elem` is a point, a
 * boolean or a colour and `c` is `False` (`unmatchedCell()`), and
 * `If(c, elem)` otherwise (`If(c, elem, Rgb(NaN, NaN, NaN))` for a colour).
 * The value of
 * `If(c, elem)` when `c` is false is `NaN` for a number and the `NaN`
 * point for a point (`maskedValue()`), as `unmatchedCell()` gives.
 */
function maskCell(
  ce: ComputeEngine,
  c: Expression,
  elem: Expression
): Expression {
  if (
    sym(c) === 'False' &&
    (pointArity(elem.type.type) !== undefined ||
      unmatchedCellKind(elem.type.type) !== undefined)
  )
    return unmatchedCell(ce, elem.type.type);
  // A colour cell whose condition is not decided carries the no-colour value
  // as an explicit else branch: `If(c, elem)` with `c` false is `Missing`
  // for a colour (`maskedValue()`), but the unmatched colour cell is
  // `Rgb(NaN, NaN, NaN)` (`unmatchedCell()`). With the else branch, the cell
  // read before `c` is assigned and evaluated after `c = False` gives the
  // same value as the evaluation of the whole restriction. A relation cell
  // needs no else branch: `maskedValue()` already gives `False` for it.
  if (unmatchedCellKind(elem.type.type) === 'color')
    return ce._fn('If', [c, elem, unmatchedCell(ce, elem.type.type)]);
  return ce._fn('If', [c, elem]);
}

/** The type of a position of a list that can hold `unmatchedCell()` of a
 * value of type `t`, `t` joined with the type of that cell. */
function withUnmatchedCellType(t: Type): Type {
  if (isNumericValueType(t)) return widen(t, 'number');
  const n = pointArity(t);
  if (n !== undefined) return widen(t, nanPointType(n));
  const kind = unmatchedCellKind(t);
  if (kind !== undefined) return widen(t, kind);
  return reduceType({ kind: 'union', types: [t, 'missing'] });
}

/**
 * Lazy indexed-collection handlers for a held restriction, the single-branch
 * `If(c, value)` (Tycho item 66).
 *
 * A restriction over a collection is elementwise: `If(c, L)` presents as
 * `[If(c, L1), …, If(c, Ln)]`. Its evaluation keeps the `If` held over the
 * evaluated collection (it is never copied into a `List` of `If`s: the copy
 * forgot that its cells came from one restriction, user decision
 * 2026-09-25), and these handlers walk the wrapped value, re-wrapping each
 * element with the condition — so the held form is fully enumerable, and
 * `isCollection`/`count`/`each()` agree with `.type`.
 *
 * An `If` with a SCALAR arm, an `If` with an else branch, and an `If` with
 * any other number of operands are not collections: `isCollection` reports
 * `false` and every other handler reports scalar.
 *
 * A MASK condition — a collection of booleans, such as `[1,2,3] > 2` — is
 * zipped with the value cell by cell, exactly as `evaluateRestriction()`
 * zips it: cell `i` is `If(c_i, L_i)`, and the length is the shorter of the
 * two. A mask with no known length (a symbol with no value), or a condition
 * whose shape is not settled (a comparison typed `broadcastable<boolean>`),
 * cannot be zipped here, so the `If` does not present as a collection until
 * evaluation resolves it.
 */
function restrictionCollectionHandlers(): CollectionHandlers {
  // The value and the condition of the restriction `expr`, or `undefined`
  // when `expr` is not a two-operand `If`.
  const operands = (
    expr: Expression
  ): { value: Expression; cond: Expression } | undefined => {
    if (!isFunction(expr, 'If') || expr.nops !== 2) return undefined;
    return { value: expr.op2, cond: expr.op1 };
  };
  // The restricted cell of `elem` under the condition `c`.
  const cell = (ce: ComputeEngine, elem: Expression, c: Expression) =>
    ce._fn('If', [c, elem]);
  // The wrapped collection value, or `undefined` when the `If` restricts a
  // scalar. The predicate matches the distribution rule of
  // `evaluateRestriction()` exactly — in particular a `Tuple` (a point) is
  // NOT list-like here, so a restricted point presents as a scalar `If`
  // wrapping the point rather than as a 2-element collection.
  // Returns the wrapped collection, the number of restricted cells, and a
  // `restrict` closure that applies the condition to the element at 1-based
  // index `i` (the whole condition, or its cell `i` for a mask).
  const parts = (
    expr: Expression
  ):
    | {
        value: Expression;
        count: number | bigint | undefined;
        restrict: (elem: Expression, i: number) => Expression | undefined;
      }
    | undefined => {
    const restriction = operands(expr);
    if (restriction === undefined) return undefined;
    const v = restriction.value;
    // A string is excluded alongside a tuple: both are indexed collections
    // that stay ATOMIC under element-wise restriction, so `If(c, "ab")` is a
    // restricted string, not a collection of restricted characters. This must
    // agree with the distribution gate in `evaluateRestriction()`, which
    // excludes the same two kinds.
    // One exception, for a MASK condition only, again as
    // `evaluateRestriction()` decides: a TUPLE value held by a symbol declared with an
    // ORDERED collection type (`isOrderedCarrierType`) is zipped. The two
    // sites call the same predicates (`isOrderedCarrierType`,
    // `isAtomicCarrierValue`) with the same inputs: the static type of the
    // carrier operand as written, and the value it holds. For a symbol, that
    // value is the symbol's value, so a symbol declared `tuple<number,
    // number> | list<number>` that holds `(1, 2)` is one point here, as it
    // is when the restriction is evaluated.
    if (!v.isCollection) return undefined;
    const held = (isSymbol(v) ? v.value : undefined) ?? v;
    const atomic = isTuple(held) || isString(held);
    const cond = restriction.cond;
    const ce = expr.engine;
    if (isAtomicCarrierValue(v.type.type, held)) return undefined;
    if (possiblyElementwiseCondition([cond.type.type])) return undefined;
    if (!cond.type.matches('collection<any>')) {
      if (atomic) return undefined;
      return {
        value: v,
        // A `bigint` count (a finite count that is not a safe integer)
        // passes through: the walk reads the value's own walk.
        count: v.count,
        restrict: (elem) => cell(ce, elem, cond),
      };
    }
    // A mask: zip it with the value, to the shorter length. The mask (and
    // the value) can be an infinite collection, such as `Range(1, ∞)`, which
    // cannot be read in full. An in-order walk (the iterator) reads each
    // cell once, from one iterator of the mask, and keeps it. A request
    // that skips ahead of the cells read so far (a single `at(i)`) looks up
    // that one cell with `at()` instead of reading and keeping `i` cells.
    // A count can be a `bigint` (a finite count that is not a safe integer).
    // The shorter length uses `<`, which compares a `bigint` and a `number`
    // correctly (`Math.min()` throws for a `bigint`), and `restrict` only
    // compares a cell index with it.
    const vn = v.count;
    const cn = cond.count;
    if (vn === undefined || cn === undefined) return undefined;
    const n = cn < vn ? cn : vn;
    const mask: Expression[] = [];
    let cells: Iterator<Expression> | undefined;
    return {
      value: v,
      count: n,
      restrict: (elem, i) => {
        if (i < 1 || i > n) return undefined;
        let ci: Expression | undefined;
        if (i <= mask.length) ci = mask[i - 1];
        else if (i === mask.length + 1) {
          cells ??= cond.each()[Symbol.iterator]();
          const next = cells.next();
          if (!next.done) {
            mask.push(next.value);
            ci = next.value;
          }
        } else ci = cond.at(i);
        return ci === undefined ? undefined : maskCell(ce, ci, elem);
      },
    };
  };
  const value = (expr: Expression): Expression | undefined =>
    parts(expr)?.value;

  return {
    isCollection: (expr) => value(expr) !== undefined,

    isLazy: (expr) => value(expr) !== undefined,

    count: (expr) => parts(expr)?.count,

    isEmpty: (expr) => {
      const p = parts(expr);
      if (p === undefined) return undefined;
      if (p.count !== undefined) return p.count === 0;
      return p.value.isEmptyCollection;
    },

    isFinite: (expr) => value(expr)?.isFiniteCollection,

    isEnumerable: (expr) => value(expr)?.isEnumerableCollection,

    elttype: (expr) => {
      const v = value(expr);
      if (!v) return undefined;
      // The element type of the wrapped collection, with NO `missing` arm:
      // `integer` for `[1,2]{c}`, a `vector<integer^2>` row for a restricted
      // matrix. This handler must never answer wider than the collection's
      // own type (`typeSaturatedSubsetOf`, `collection-utils.ts` relies on
      // that), and that type, `vector<integer^2>`, says the cells are
      // integers whenever the collection is present. The cells the handlers
      // enumerate are restricted cells, `If(cond, elem)`: absent exactly
      // when the collection is, since they carry its condition.
      // Under a list of conditions, a cell that is not selected is `NaN` or
      // a `NaN` point (`unmatchedCell()`), which the type of the restriction
      // admits (`restrictionType()`: `list<number>`,
      // `list<tuple<number, number>>`), so the element type is read from
      // that type.
      if (operands(expr)?.cond.type.matches('collection<any>'))
        return collectionElementType(expr.type.type) ?? 'unknown';
      return collectionElementType(v.type.type) ?? 'unknown';
    },

    iterator: (expr) => {
      const p = parts(expr);
      if (!p) return undefined;
      const iter = p.value.each();
      let i = 0;
      return {
        next: () => {
          const result = iter.next();
          const cell = result.done ? undefined : p.restrict(result.value, ++i);
          if (cell === undefined)
            return { value: undefined, done: true as const };
          return { value: cell, done: false as const };
        },
      };
    },

    at: (expr, index) => {
      // Negative indexes are normalized by the caller; string keys (records)
      // do not apply to a restricted indexed collection.
      if (typeof index !== 'number') return undefined;
      const p = parts(expr);
      const elem = p?.value.at(index);
      return elem ? p!.restrict(elem, index) : undefined;
    },

    indexWhere: (expr, predicate) => {
      const p = parts(expr);
      if (p === undefined) return undefined;
      // The value's own walk does not pass the index, so count the cells here.
      let i = 0;
      return p.value.indexWhere((elem) => {
        const cell = p.restrict(elem, ++i);
        return cell !== undefined && predicate(cell);
      });
    },
  };
}

/**
 * The catchable error for a scalar condition that evaluated to the `Missing`
 * symbol (an absent guard). Distinct from an UNDECIDED condition, which leaves
 * the conditional inert: absence is a runtime DATA state that can never become
 * decidable, so branching on it is a genuine fault and yields an error
 * expression the host can render or catch.
 */
/**
 * The relational heads whose operands a branch condition compares.
 *
 * An undefined numeric operand (`NaN`) of a relation gives
 * the relation its IEEE 754 value, and a branch on it uses that value as it
 * uses any other: an ordered comparison (`Less`, `LessEqual`, `Greater`,
 * `GreaterEqual`) or an `Equal` is `False`, so the branch takes its next arm,
 * as in Desmos (user decision 2026-10-20, Tycho rows 411 and 413); a
 * `NotEqual` is `True`, so the branch takes its first arm (user decision
 * 2026-10-23; from 2026-09-03 to that date it took no arm).
 */
const BRANCH_RELATIONS: ReadonlySet<string> = new Set([
  'Less',
  'LessEqual',
  'Greater',
  'GreaterEqual',
  'Equal',
  'NotEqual',
]);

/**
 * The value of a branch condition, read two-valued: an absent value
 * (`Missing`) is `False`. The logic is two-valued: an absent
 * condition is not a third truth value, and the branch takes its next arm
 * (the else arm, or the absent value of the domain of the arm), as Desmos
 * does: `\{u<1:5,7\}` is 7 when `u` is undefined (user decision 2026-11-02,
 * two-valued comparisons, `docs/ERROR-MODEL.md`). Every other value is kept.
 */
function twoValued(value: Expression): Expression {
  const s = sym(value);
  return s === 'Missing' ? value.engine.False : value;
}

/**
 * Evaluate the condition of an `If`/`Which` for branch selection: exactly
 * what `cond.canonical.evaluate()` answers (errors, element-wise lists and
 * inert symbolic forms included), with an absent value read as `False`
 * (`twoValued`).
 *
 * A relation with an undefined operand (`NaN`, `Missing`)
 * is `False` (`True` for `≠`), and the branch uses that value as it uses
 * any other: `If(0/0 > 0, 1, 0)` is `0` and `If(0/0 ≠ 0, 1, 0)` is `1` (user
 * decisions 2026-10-20, Tycho rows 411 and 413, 2026-10-23 and 2026-11-02).
 * Compiled code takes the same arm for a present operand; over an absent
 * operand its value is unspecified (docs/COMPILATION-MODEL.md, "Caveats of
 * compiled code").
 *
 * The walk reproduces the ordinary evaluation of the condition:
 * - A relation evaluates its operands left to right and then itself over
 *   the values; an error in an operand propagates through the relation as
 *   it always did, and a collection-shaped operand gives the element-wise
 *   list the relation always gave (a NaN CELL then takes the else cell on
 *   both lanes, measured 2026-09-03 — `evaluateElementwiseSelection` owns
 *   that contract).
 * - `And`/`Or` keep their short-circuit contract (`evaluateShortCircuit`,
 *   `library/logic.ts`): operands are evaluated left to right and the walk
 *   stops at the first decider (`False` for `And`, `True` for `Or`) or the
 *   first error, so an operand a decided one guards is never evaluated. A
 *   survivor that is still symbolic (a relation with a free variable) keeps
 *   the whole connective inert; a collection-shaped survivor hands the
 *   connective to its ordinary element-wise evaluation. `Nand`, `Nor` and
 *   `Implies` are the same walk through their `And`/`Or` spelling, and `Not`
 *   negates the value of its operand.
 * - Anything else evaluates as before.
 *
 * `numericApproximation` is the numeric request of the `If`/`Which` that
 * holds the condition. It is forwarded to every evaluation of the walk, so
 * that the condition is decided as the same condition is decided at the top
 * level under `.N()`. This matters in the body of a user function under
 * `.N()`: a parameter is bound to the float of the argument, and only a
 * function that jumps (a comparison, `Floor`) evaluated with the numeric
 * request reads the exact argument again (`exactRealValueOf`,
 * `constraint-subject.ts`). Evaluated exactly, `x < 25` for
 * `x := (25! − 1)/24!` read the float `25` and was `False`.
 */
function evaluateCondition(
  cond: Expression,
  numericApproximation?: boolean
): Expression {
  const c = cond.canonical;
  const ce = c.engine;
  const options = numericApproximation
    ? { numericApproximation: true }
    : undefined;
  if (!isFunction(c)) return twoValued(c.evaluate(options));
  const op = c.operator;

  if (BRANCH_RELATIONS.has(op)) {
    // A chain of three or more operands is evaluated as the relation
    // evaluates it (`evaluateChainForCondition`): left to right, and an
    // operand after a pair that is `False` is not evaluated (no effect, no
    // error, no random draw), so `If(Less(x, 0.5, Random()), 1, 2)` at
    // `x = 5` takes the second arm with no draw.
    const chain = evaluateChainForCondition(
      ce,
      op,
      c.ops,
      numericApproximation
    );
    if (chain !== undefined && !Array.isArray(chain)) return twoValued(chain);
    const ops: Expression[] = [];
    if (chain !== undefined) ops.push(...chain);
    else
      for (const x of c.ops) {
        const v = x.evaluate(options);
        ops.push(v);
        // An error operand decides the relation (it propagates); the
        // remaining operands are not demanded.
        if (errorValue(v) !== undefined) break;
      }
    // Under the numeric request, the relation decides a near tie from its
    // operands AS WRITTEN: it evaluates them again exactly (a pure
    // expression, the recorded argument of a parameter) or compares an
    // exact constant such as `π` by its exact form
    // (`exactPairAtNearTie`, `relational-operator.ts`). The float of an
    // operand has lost that information: the float of `(25! − 1)/24!` is
    // `25`, and `25 < 25` is `False`. So an operand whose value is a float
    // is given to the relation as written when it can change the result:
    // its float is at a near tie with the value of an adjacent operand
    // (`isNearTiePair`), or it is an exact constant expression, whose float
    // can be wrong by much more than the tolerance when its terms cancel
    // (`√(10⁶⁰ + 10⁴⁰) − 10³⁰`). The relation then evaluates it again. Two
    // conditions keep this safe:
    // - Every operand of the relation must be pure (`isTransitivelyPure`).
    //   An operand with an effect is not run twice, and it can change what
    //   another operand as written reads: with `x := 0.5` and `r()` that
    //   assigns `x = 10` and returns 1, `x < r()` must compare `0.5 < 1`,
    //   not `10 < 1`.
    // - Far from a tie, the values already computed are compared. An
    //   operand is then evaluated once only: in a recursive function such
    //   as `g(n) := If(n < 1, 0, If(g(n − 1) > 5, 1, 2))`, a second
    //   evaluation of `g(n − 1)` at each level can make the cost
    //   exponential.
    let relationOps = ops;
    if (
      numericApproximation &&
      ops.length === c.nops &&
      c.ops.every((x) => isTransitivelyPure(x))
    ) {
      relationOps = ops.map((v, i) =>
        isInexactRealNumber(v) &&
        (isExactConstantExpression(c.ops[i]) ||
          (i > 0 && isNearTiePair(ops[i - 1], v)) ||
          (i + 1 < ops.length && isNearTiePair(v, ops[i + 1])))
          ? c.ops[i]
          : v
      );
    }
    const value = ce.function(op, relationOps).evaluate(options);
    return twoValued(value);
  }

  if (op === 'And' || op === 'Or')
    return evaluateConnective(c, op, c.ops, numericApproximation);
  if (op === 'Nand' && c.nops >= 1)
    return negateCondition(
      evaluateConnective(c, 'And', c.ops, numericApproximation)
    );
  if (op === 'Nor' && c.nops >= 1)
    return negateCondition(
      evaluateConnective(c, 'Or', c.ops, numericApproximation)
    );
  if (op === 'Implies' && c.nops === 2)
    return evaluateConnective(
      c,
      'Or',
      [ce.function('Not', [c.op1]), c.op2],
      numericApproximation
    );
  if (op === 'Not' && c.nops === 1)
    return negateCondition(evaluateCondition(c.op1, numericApproximation));

  return twoValued(c.evaluate(options));
}

/** True when `x` is a finite real number literal that is not exact (a
 *  float). */
function isInexactRealNumber(x: Expression): boolean {
  return isNumber(x) && !x.isExact && !x.isComplex && x.isFinite === true;
}

/** `Not` of an evaluated condition. An error is kept as it is. */
function negateCondition(inner: Expression): Expression {
  if (errorValue(inner) !== undefined) return inner;
  return inner.engine.function('Not', [inner]).evaluate();
}

/**
 * The short-circuiting walk of an `And`/`Or` branch condition — see
 * `evaluateCondition`. `node` is the connective as written; `ops` are the
 * operands to walk, which differ from `node.ops` only for the `Implies`
 * spelling. `numericApproximation` is the numeric request of the walk (see
 * `evaluateCondition`).
 */
function evaluateConnective(
  node: Expression,
  op: 'And' | 'Or',
  ops: ReadonlyArray<Expression>,
  numericApproximation?: boolean
): Expression {
  const ce = node.engine;
  const decider = op === 'And' ? 'False' : 'True';
  // An operand of collection shape makes the connective element-wise: a
  // scalar decider (an absent operand read as `False`) must not collapse
  // the list, as in the ordinary connective (`evaluateShortCircuit()` in
  // `library/logic.ts`): `If(And([True, False], Missing), 1, 0)` is
  // `[0, 0]`.
  const elementwise = ops.some(isCollectionShaped);
  const survivors: Expression[] = [];
  // The first failed operand. As in the ordinary connective
  // (`evaluateShortCircuit()` in `library/logic.ts`), a failed operand does
  // not end the walk: a later operand that decides the result (an absent
  // operand read as `False` for `And`) wins, so `If(And(1, Missing), 5, 7)`
  // is `7`, as `And(1, Missing)` is `False`. The error is returned only when
  // no later operand decides. An operand after a deciding one is not
  // evaluated, so `If(And(False, <error>), 5, 7)` is `7`.
  let failed: Expression | undefined = undefined;
  for (const x of ops) {
    const r = evaluateCondition(x, numericApproximation);
    if (errorValue(r) !== undefined) {
      if (elementwise) return r;
      failed ??= r;
      continue;
    }
    if (!elementwise && sym(r) === decider) return ce.symbol(decider);
    survivors.push(r);
  }
  if (failed) return failed;
  // A collection-shaped survivor: the element-wise contract of the
  // connective, over the evaluated values.
  if (survivors.some((r) => isCollectionShaped(r)))
    return ce
      .function(op, survivors)
      .evaluate(
        numericApproximation ? { numericApproximation: true } : undefined
      );
  // A symbolic survivor keeps the connective inert.
  if (survivors.some((r) => sym(r) !== 'True' && sym(r) !== 'False'))
    return ce.function(op, survivors);
  // Every survivor is the non-deciding value (`True` for `And`, `False`
  // for `Or`).
  return ce.symbol(op === 'And' ? 'True' : 'False');
}

/**
 * The canonical form of an `If`/`Which` condition: the condition itself, or
 * an `incompatible-type` error operand when its static type PROVES it is
 * not a boolean.
 *
 * A condition that is a number, a string, or a symbol declared with a type
 * disjoint from `boolean` (`If(10, a, b)`, `Which("banana", 1, True, 2)`,
 * `If(n, a, b)` for `n: integer`) can never select a branch, so the mistake
 * is reported at boxing, exactly as a wrong-typed argument to `Sin` is: the
 * condition becomes `Error(incompatible-type, boolean, <type>)`, which the
 * evaluate handlers then propagate as the condition's error, because the
 * condition is a demanded operand (`docs/ERROR-MODEL.md` §3 "Propagation").
 *
 * Everything that is NOT proven non-boolean is left alone, because it may
 * still resolve: a symbol of unknown type (an undeclared `Tru` is a free
 * variable that may be assigned later), a relation with free variables, a
 * `missing`-admitting type (an absent condition is a catchable runtime
 * error, not a boxing error), and a collection or possibly-collection type
 * whose cells could be condition values (a flat list of booleans selects
 * element-wise, `docs/BROADCAST-MODEL.md` §"The rule").
 *
 * The element-wise carrier is narrow — an indexed or broadcastable
 * collection whose cells are `True`/`False`/`Missing` (`conditionCells`) —
 * so a collection type is exempt only when its cell type could overlap
 * `boolean | missing`. A tuple (a point binds whole and never selects), a
 * set, a dictionary or a record, a string (its cells are characters), and an
 * indexed collection with provably non-boolean cells (`list<number>`,
 * `range`, `number | list<number>`) are refused like a scalar. A type that
 * is only a collection and is not an ordered collection of booleans
 * (`FLAT_MASK_TYPE`) is refused with that type as the expected type.
 */
function conditionOperand(ce: ComputeEngine, cond: Expression): Expression {
  const t = cond.type;
  if (!cond.isValid || t.isUnknown) return cond;
  // A condition that holds an error value (`w` after `w := Ln("a")`) is
  // kept: its evaluation gives that error, as an argument of an eager
  // operator does (`isErrorTypedOperand()`). The type `error` is disjoint
  // from `boolean`, so the refusals below would replace it with a new error.
  if (isErrorTypedOperand(cond)) return cond;
  // A condition of type `error` that does not hold an error value (a symbol
  // declared `error` with no value, or `g(2)` with `g: (number) -> error`)
  // is kept too, as a parameter typed `boolean` keeps it
  // (`overlapAdmission()` in `validate.ts`: the type `error` overlaps every
  // type). Its evaluation does not select a branch.
  if (isErrorTypedWithoutErrorValue(cond)) return cond;
  const type = t.type;
  const refuse = () => ce.typeError('boolean', t, cond);
  if (isSubtype(type, 'string') || isTupleShapedType(type)) return refuse();
  if (typeCouldBeCollection(type) || typeCouldBeUnkeyedCollection(type)) {
    const r = resolveTypeAlias(type);
    const kind = typeof r === 'string' ? r : r.kind;
    if (kind === 'set' || kind === 'dictionary' || kind === 'record')
      return refuse();
    // The cell type, every rank unwrapped and a union descended per arm; a
    // bare kind answers `unknown`, which nothing is disjoint from. An EMPTY
    // collection types its cells `never`, which is disjoint from everything,
    // yet it has no cell to contradict a condition and broadcasts to an
    // empty result, so it is not refused.
    const cell = broadcastCellType(type);
    if (
      cell !== 'never' &&
      provablyDisjoint(cell, 'boolean') &&
      provablyDisjoint(cell, 'missing')
    )
      return refuse();
    // A condition that is a collection is a flat list of booleans, and
    // nothing else (selection rule of 2026-11-02, `docs/BROADCAST-MODEL.md`).
    // A collection type that cannot be one is refused
    // (`isNeverFlatMaskType()`).
    if (isSubtype(type, COLLECTION_SHAPE_TYPE) && isNeverFlatMaskType(type))
      return ce.typeError(FLAT_MASK_TYPE, t, cond);
    // A flat list of booleans is finite. A type does not state that a list
    // is infinite: `Cycle([True, False])` is a `list<boolean>`, but it has no
    // end, so it is refused here too.
    if (cond.isFiniteCollection === false)
      return ce.typeError(FLAT_MASK_TYPE, t, cond);
    return cond;
  }
  if (isSubtype('missing', type)) return cond;
  if (!provablyDisjoint(type, 'boolean')) return cond;
  return refuse();
}

/**
 * True when no value of the collection type `t` is a flat list of
 * booleans, so that a condition of this type is a static error.
 *
 * Accepted: `list<boolean>`, `list<boolean^3>`, and
 * `indexed_collection<boolean>` (a comparison over a list of points that a
 * host types as an indexed collection).
 *
 * Refused: a nested list (`[[True], [False, True]]`, `list<list<boolean>>`),
 * a matrix or a tensor of two dimensions or more (`M < 3` over a matrix), a
 * list whose cells can be `Missing` (`[True, Missing]`), a collection with
 * no order (`collection<boolean>`, `set<boolean>`), and a collection whose
 * cells are not known to be booleans (`list`, `list<any>`,
 * `indexed_collection<any>`).
 *
 * Not refused: a type that does not settle the number of dimensions but
 * admits a flat list of booleans. `tensor<boolean>` (no dimensions given)
 * is the type of `x < L` when `x` is declared
 * `broadcastable<number | tuple>` (a scalar or a collection), and
 * `list<boolean | list<any>>` is the type of `L < f(u)` when the result type
 * of `f` is `unknown`. A host declares the parameters of a function this way
 * before it knows their type, and a value of these types is often a flat
 * list. Such a condition selects element-wise only when its value is a list
 * of booleans.
 */
function isNeverFlatMaskType(t: Readonly<Type>): boolean {
  if (isSubtype(t, FLAT_MASK_TYPE)) return false;
  const r = resolveTypeAlias(t as Type);
  if (typeof r !== 'string' && r.kind === 'union')
    return r.types.every((x) => isNeverFlatMaskType(x));
  if (!isSubtype(t, INDEXED_COLLECTION_SHAPE_TYPE)) return true;
  if (
    typeof r !== 'string' &&
    r.kind === 'list' &&
    r.dimensions !== undefined &&
    r.dimensions !== null &&
    r.dimensions.length >= 2
  )
    return true;
  const cell = collectionElementType(t as Type);
  if (cell === undefined || cell === 'any' || cell === 'unknown') return true;
  if (isSubtype('missing', cell)) return true;
  return provablyDisjoint(cell, 'boolean');
}

/**
 * The element kind of the arm `arm` of a selection whose condition is a
 * flat list of booleans: `number` or `point` (a tuple of numbers) for an arm
 * that is a scalar of that kind or a flat list of that kind; an `Error`
 * expression for an arm that the selection rule of 2026-11-02 refuses
 * (`docs/BROADCAST-MODEL.md`): a nested list, a string or a list of
 * strings (a string cell has no `NaN` for a position that is not selected),
 * or a value of another kind (a set); `undefined` when the static type
 * does not tell (an arm of type `unknown`, an absent value) and for an arm
 * that the rule does not constrain.
 *
 * Three kinds of arm are not constrained, and keep the value and the type
 * that they had before the rule. A boolean or a list of booleans (a relation:
 * `If(L < 3, x > 0)`, the region `1 > 0 where (x+2)^2 + y^2 <= (0..0.2..1.6)^2`
 * of a plot) gives `Missing` at a position that is not selected. A statement
 * (an `Assign`, a definition, a drawing head) is not a value. A scalar of
 * another kind that is not a string, such as a colour (the colour grid
 * `Which(L <= 1, Hsv(0, 0, v), True, Hsv(0, 0, 0.8))` of a plot, Tycho item
 * 189), gives `Missing` at a position that is not selected.
 */
function selectionArmKind(
  ce: ComputeEngine,
  arm: Expression
): 'number' | 'point' | Expression | undefined {
  if (!arm.isValid || isStatementArm(arm)) return undefined;
  const t = arm.type.type;
  if (arm.type.isUnknown || t === 'any' || t === 'never') return undefined;
  const refuse = () =>
    ce.typeError(parseType('number | tuple | list<number | tuple>')!, t, arm);
  let cell: Type = t;
  // A point is a tuple, or a union of tuples
  // (`tuple<nan, nan, integer> | tuple<real, real, real>`, the type of a
  // point whose coordinates can be `NaN`), not a list arm.
  if (
    isSubtype(t, COLLECTION_SHAPE_TYPE) &&
    !isTupleOrTupleUnionShapedType(t)
  ) {
    if (isSubtype(t, 'string')) return refuse();
    // An ordered collection is a list arm (`list<number>`, the
    // `indexed_collection<number>` of a carrier); a set or a dictionary has
    // no positions.
    if (!isSubtype(t, INDEXED_COLLECTION_SHAPE_TYPE)) return refuse();
    const element = collectionElementType(t);
    if (element === undefined) return undefined;
    if (
      isSubtype(element, COLLECTION_SHAPE_TYPE) &&
      !isTupleOrTupleUnionShapedType(element)
    )
      return refuse();
    cell = element;
  }
  const present = stripMissingFromType(cell);
  if (present === 'never' || present === 'nothing') return undefined;
  if (isSubtype(present, 'boolean')) return undefined;
  if (isSubtype(present, 'number')) return 'number';
  if (pointArity(present) !== undefined) return 'point';
  // A character is the cell of a string, and has no `NaN` either.
  if (isSubtype(present, 'character')) return refuse();
  return undefined;
}

/**
 * The error of the value `value` of the arm `arm` of a selection by a list
 * of conditions, or `undefined` when the value is accepted. The canonical
 * form refuses an arm whose static type is a list of lists or a string
 * (`selectionArmKind()`); an arm whose static type does not settle this
 * (`broadcastable<number>`, `unknown`) is checked here, on its value.
 */
function runtimeArmError(
  ce: ComputeEngine,
  arm: Expression,
  value: Expression
): Expression | undefined {
  if (isStatementArm(arm)) return undefined;
  const kind = selectionArmKind(ce, value);
  return kind !== undefined && typeof kind !== 'string' ? kind : undefined;
}

/** The length of a flat list type with one known dimension
 * (`list<boolean^3>`), or `undefined`. */
function staticListLength(t: Readonly<Type>): number | undefined {
  const r = resolveTypeAlias(t as Type);
  if (typeof r === 'string' || r.kind !== 'list') return undefined;
  const dims = r.dimensions;
  return dims?.length === 1 && dims[0] >= 0 ? dims[0] : undefined;
}

/**
 * The static error of a selection whose conditions `conds` include a flat
 * list of booleans, or `undefined` when its arms `arms` are accepted. Every
 * arm is a scalar or a flat list (`selectionArmKind()`), and all arms have
 * one element kind: an arm whose kind is a point where an earlier arm is a
 * number (or the reverse) is refused. A list condition and a list arm whose
 * lengths the types give must have one length: `If([True, False], [1, 2,
 * 3], 0)` is the `incompatible-dimensions` error `2 vs 3`, the error that
 * `[1, 2] + [1, 2, 3]` gives.
 */
function selectionArmError(
  ce: ComputeEngine,
  conds: ReadonlyArray<Expression>,
  arms: ReadonlyArray<Expression>
): Expression | undefined {
  let length: number | undefined;
  for (const c of conds) {
    if (!isListCondition(c)) continue;
    const n = staticListLength(c.type.type);
    if (n === undefined) continue;
    if (length !== undefined && n !== length)
      return ce.error('incompatible-dimensions', `${length} vs ${n}`);
    length = n;
  }
  let kind: 'number' | 'point' | undefined;
  for (const arm of arms) {
    const n =
      length === undefined || isTupleShapedType(arm.type.type)
        ? undefined
        : staticListLength(arm.type.type);
    if (n !== undefined && n !== length)
      return ce.error('incompatible-dimensions', `${length} vs ${n}`);
    const k = selectionArmKind(ce, arm);
    if (k === undefined) continue;
    if (typeof k !== 'string') return k;
    kind ??= k;
    if (k !== kind)
      return ce.typeError(
        parseType(
          kind === 'number' ? 'number | list<number>' : 'tuple | list<tuple>'
        )!,
        arm.type.type,
        arm
      );
  }
  return undefined;
}

/**
 * The supertype every element-wise-eligible condition is checked against.
 *
 * The cells admitted at RUNTIME (`conditionCells`) are `True`/`False`/`Missing`
 * — an absent cell is read as `False` — so the static gate must admit
 * `missing` cells too, or `Which(["True", "Missing"], …)` would
 * evaluate element-wise while typing scalar. It stays a strict supertype of
 * those cells: a condition typing `list<unknown>`, or plain `unknown`, does not
 * match and keeps the scalar typing.
 */
const BOOLEAN_COLLECTION_TYPE = parseType(
  'indexed_collection<boolean | missing>'
);

/**
 * The cell type of `BOOLEAN_COLLECTION_TYPE`, used to recognize a
 * `broadcastable<boolean>` condition — one that is a boolean collection only
 * for some of its possible runtime values (`possiblyElementwiseCondition`).
 */
const CONDITION_CELL_TYPE = parseType('boolean | missing');

/**
 * The value of a condition at one node of an element-wise selection: a
 * condition value (`True` or `False`; an absent cell is read as `False`),
 * or a list of such values (`MaskList`).
 */
type MaskCell = 'True' | 'False' | MaskList;

/**
 * A list-valued condition at one node of an element-wise selection: the
 * collection as evaluated (it is a participant of the length check, see
 * `broadcastLengthMismatch`) and its materialized elements.
 */
type MaskList = { value: Expression; cells: MaskCell[] };

/**
 * The materialized cells of a condition that activates the ELEMENT-WISE
 * selection path, or `undefined` when it does not.
 *
 * The gate (§3 of `docs/BROADCAST-MODEL.md`) is
 * deliberately narrow: an indexed collection (never a `Set`, never a tuple —
 * tuples are points, not lists) of statically known finite length whose cells
 * are ALL condition values (`True`, `False` or `Missing`; an
 * absent cell reads as `False`) or themselves such
 * collections. A nested mask is read here so that the selection can refuse
 * it (`evaluateElementwiseSelection()`): a condition is a boolean or a flat
 * list of booleans. A collection with a symbolic or non-boolean cell at any depth, or
 * one whose length is not yet known, does not activate it — the conditional
 * then keeps its existing behavior (inert, or the spell-check throw), so every
 * symbolic `Which` PRODUCER (Solve validity guards, the conditional-value
 * adopters) keeps round-tripping unreduced.
 */
function conditionCells(c: Expression): MaskList | undefined {
  if (!isBroadcastableCollection(c)) return undefined;
  if (!isWalkableFiniteCollection(c)) return undefined;
  const n = c.count;
  if (n === undefined || !Number.isFinite(n)) return undefined;
  const cells: MaskCell[] = [];
  for (const cell of Array.from(c.each()) as Expression[]) {
    const s = sym(cell);
    if (s === 'True' || s === 'False') {
      cells.push(s);
      continue;
    }
    // An absent cell is read as `False`: the logic is two-valued (user
    // decision 2026-11-02, two-valued comparisons).
    if (isAbsentSymbol(cell)) {
      cells.push('False');
      continue;
    }
    const nested = conditionCells(cell);
    if (nested === undefined) return undefined;
    cells.push(nested);
  }
  return { value: c, cells };
}

/**
 * Element-wise conditional selection: `np.select` semantics, ruled 2026-07-27
 * (`docs/BROADCAST-MODEL.md`).
 *
 * `clauses[0]`'s condition has already been evaluated and materialized by the
 * caller (that is what activated the gate) and arrives as `first`; it is never
 * drained twice. Per position `j` the selected clause is the first whose
 * condition is `True` at `j`; a scalar `True`/`False` condition lifts to every
 * position (R1). Arms are evaluated at most once, WHOLE, and only when
 * selection reaches them (R2); a list-valued arm is then indexed at `j`, a
 * scalar arm lifts. All list-valued participants — conditions and selected
 * arms — must share one length, checked with the same
 * `broadcastLengthMismatch` as `Add` (R3). A position no clause matches is
 * `NaN` for a number, a point whose coordinates are `NaN` for a point, and
 * `Missing` for any other value (R4, `noMatchCell`); a position whose condition cell is `Missing` is the same
 * catchable "condition is absent" error the scalar form produces (R4′).
 *
 * A condition is a boolean or a flat list of booleans. A condition whose
 * value is a list with a list cell (`M < 3` over a matrix `M`, or
 * `[[True], [False, True]]`) is the `incompatible-type` error, so the result
 * is always a flat `List`.
 *
 * The zip is EAGER — conditions are materialized once into plain arrays and
 * the selection is computed in a JS loop — never a stack of lazy broadcast
 * `Map`s. Each cell of a lazy broadcast `Map` is a function application: on a
 * minified production bundle, draining `n = 3` over 900 elements costs about
 * 3 µs per element, and the whole selection `Which(n = 3, 1, n = 2, S, True,
 * 0)` about 5.4 µs per element, which is close to the cost of draining its
 * two conditions. The loop itself adds little; most of the cost is the
 * computation of the cells of each condition, once.
 * (Measured 2026-11-07 at commit 3105a22eac761583374d0006b2bf9031f7ba9ba7.)
 *
 * Returns `undefined` when the expression must stay inert. `evaluatedArms`,
 * when given, then holds the value of each arm that was evaluated, at the index
 * of its clause in `clauses`: a caller puts these values in the held node, so
 * that an effect of an arm does not run again when the held node is evaluated.
 */
function evaluateElementwiseSelection(
  ce: ComputeEngine,
  clauses: ReadonlyArray<{ cond: Expression; arm: Expression }>,
  first: { cond: Expression; mask: MaskList },
  options: Partial<EvaluateOptions> & { engine: ComputeEngine },
  noMatchArmTypes?: ReadonlyArray<Type>,
  evaluatedArms?: Expression[]
): Expression | undefined {
  // 1/ Evaluate the conditions in clause order and materialize the
  // list-valued ones. Clauses after a lifted `True` are unreachable: their
  // conditions are not evaluated at all.
  const participants: Expression[] = [];
  // The value of each retained clause's condition at the top node: the
  // materialized mask of a list-valued condition, or `'True'` for a lifted
  // scalar `True`.
  const selectors: MaskCell[] = [];
  const arms: Expression[] = [];
  // The index in `clauses` of each retained clause.
  const clauseOfArm: number[] = [];
  for (let k = 0; k < clauses.length; k++) {
    const { cond, arm } = clauses[k];
    if (arm === undefined) return undefined;
    // The first clause's condition was evaluated and materialized by the
    // caller (it is what activated the gate): never drain it twice. The
    // numeric request of the selection is forwarded, as `evaluateCondition`
    // forwards it.
    const c =
      k === 0
        ? first.cond
        : cond.canonical.evaluate(
            options.numericApproximation
              ? { numericApproximation: true }
              : undefined
          );
    const s = sym(c);
    // An absent condition (`Missing`) is read as `False`: the
    // logic is two-valued (user decision 2026-11-02).
    if (s === 'False' || s === 'Missing') continue;
    if (s === 'True') {
      selectors.push('True');
      arms.push(arm);
      clauseOfArm.push(k);
      break;
    }
    const mask = k === 0 ? first.mask : conditionCells(c);
    if (mask === undefined) {
      // A condition of KNOWN infinite length is a genuine length mismatch
      // against the finite ones (R3: strict, lifted regime). Anything else —
      // a symbolic condition, a collection with a symbolic or non-boolean
      // cell, a collection whose length is not yet known — leaves the whole
      // expression inert (§3 gate), whatever its length: the gate must not
      // report a dimension error about a condition it never admitted.
      if (isBroadcastableCollection(c) && c.count === Infinity)
        return broadcastLengthMismatch(ce, [...participants, c]);
      return undefined;
    }
    // A condition whose static type does not settle its shape
    // (`tensor<boolean>`, `isNeverFlatMaskType()`) can have a nested list as
    // its value. A nested condition is refused, as the canonical form refuses
    // a condition whose type is a nested list (`conditionOperand()`).
    if (mask.cells.some((cell) => typeof cell !== 'string'))
      return ce.typeError(FLAT_MASK_TYPE, c.type, c);
    participants.push(c);
    selectors.push(mask);
    arms.push(arm);
    clauseOfArm.push(k);
  }

  const mismatch = broadcastLengthMismatch(ce, participants);
  if (mismatch) return mismatch;

  // 2/ Compute the selection: at each position, the index of the first
  // clause whose condition is `True` there, and `NO_MATCH` when no condition
  // is. A lifted scalar `True` is `True` at every position. Every list
  // condition is flat (checked above) and has the length of the first one,
  // the collection that activated the gate.
  const reached = new Set<number>();
  const n = first.mask.cells.length;
  const selection: number[] = [];
  for (let j = 0; j < n; j++) {
    let picked = NO_MATCH;
    for (let k = 0; k < selectors.length; k++) {
      const s = selectors[k];
      if ((typeof s === 'string' ? s : s.cells[j]) === 'True') {
        picked = k;
        reached.add(k);
        break;
      }
    }
    selection.push(picked);
  }

  // 3/ Evaluate each REACHED arm once, as a whole expression (R2).
  const values: (Expression | Expression[])[] = [];
  for (let k = 0; k < arms.length; k++) {
    if (!reached.has(k)) continue;
    const value = arms[k].canonical.evaluate(options);
    if (evaluatedArms !== undefined) evaluatedArms[clauseOfArm[k]] = value;
    // An arm whose static type does not settle its shape can have a value
    // that the canonical form refuses (`selectionArmError()`): a list whose
    // elements are lists, a string. That value is refused with the same
    // error.
    const refused = runtimeArmError(ce, arms[k], value);
    if (refused !== undefined) return refused;
    if (!isBroadcastableCollection(value)) {
      // A value that the static type gives as a list and that has no elements
      // to read (`foo(L)` with `foo` undeclared has the type of a list of the
      // length of `L`) is not a scalar: a copy at each position would give a
      // list in a cell, and N copies of a list of N elements. The selection
      // stays held, as for a list arm whose elements cannot be read
      // (`selectionArmCells()`).
      if (isOrderedCarrierType(value.type.type)) return undefined;
      values[k] = value;
      continue;
    }
    const cells = selectionArmCells(ce, participants, value);
    if (cells === undefined) return undefined;
    if (!Array.isArray(cells)) return cells;
    values[k] = cells;
  }

  // 4/ Assemble the result. A list arm gives its element at the position,
  // a scalar arm gives itself (it lifts). A position that no clause selects
  // holds the absence marker of the type of that position (`noMatchCell`):
  // `NaN` when every arm puts a number there, a `NaN` point when every arm
  // puts a point there, `Missing` otherwise, as a restriction masks a cell
  // by the type of its value. `noMatchArmTypes`, when given, replaces the
  // types of the arms of `clauses`: a `Which` whose first mask comes after
  // a scalar clause passes the types of all its reachable arms.
  const armTypes = noMatchArmTypes ?? clauses.map(({ arm }) => arm.type.type);
  let noMatch: Expression | undefined;
  const result = selection.map((k, j) => {
    if (k === NO_MATCH) return (noMatch ??= noMatchCell(ce, armTypes));
    const v = values[k];
    return Array.isArray(v) ? v[j] : v;
  });
  return ce._fn('List', result);
}

/** The selection at a position where no clause selects. */
const NO_MATCH = -1;

/**
 * The elements of `value`, the value of a selected arm of an element-wise
 * selection where `value` is a list and `conds` are the list-valued
 * conditions. The result is the materialized elements when the
 * arm has the length of the conditions, an `incompatible-dimensions` error
 * when it does not, and `undefined` when its elements cannot be read now (the
 * selection then stays inert).
 */
function selectionArmCells(
  ce: ComputeEngine,
  conds: ReadonlyArray<Expression>,
  value: Expression
): Expression[] | Expression | undefined {
  // A list-valued arm is a participant too: check its length before
  // materializing it, so an unbounded arm errors rather than hanging.
  const armMismatch = broadcastLengthMismatch(ce, [...conds, value]);
  if (armMismatch) return armMismatch;
  if (!isWalkableFiniteCollection(value)) return undefined;
  const cells = Array.from(value.each()) as Expression[];
  // The arm's length may only have become known by materializing it (a
  // `Filter` reports `count === undefined`): re-check through the shared
  // predicate so the diagnostic cannot drift.
  const sizeMismatch = broadcastLengthMismatch(ce, [
    ...conds,
    ce._fn('List', cells),
  ]);
  if (sizeMismatch) return sizeMismatch;
  return cells;
}

/**
 * What the TYPE of one condition of a conditional says about its shape:
 *
 * - `scalar`: a boolean or an absent condition (it lifts to every position
 *   of a mask), and a type that is never a mask (a tuple, which is refused
 *   at boxing, and `error`).
 * - `mask`: provably a mask. `rank` is 1 when the type settles a flat list
 *   of conditions, and `dimensions` gives its length when the type gives it
 *   (`list<boolean^3>`). A collection of condition values without dimensions
 *   (`list<boolean>`, `indexed_collection<boolean>`) is flat: a literal
 *   condition types `list<boolean^n>`, a declared or derived one
 *   `indexed_collection<boolean>`, and `indexed_collection<boolean>` is the
 *   supertype both are checked against. A type that does not settle the
 *   number of dimensions (`isPossiblyNestedBooleanMask`: `tensor<boolean>`,
 *   `list<boolean | list<any>>`) has no `rank`, and so has a union of masks
 *   of which one is not flat (`matrix<boolean^(2x2)> | list<boolean^3>`).
 *   Such a condition is checked on its value: a value that is not flat is
 *   the `incompatible-type` error (`evaluateElementwiseSelection()`).
 * - `possible`: a mask for some values and a scalar for others
 *   (`broadcastable<boolean>`).
 * - `unreadable`: any other type (`unknown`, `any`, a union with such an
 *   arm, and a union of a scalar and a mask such as `boolean | list<boolean>`).
 *   At run time such a condition can be a scalar or a mask.
 *
 * The depth cap stops a walk through a self-referential type.
 */
type ConditionShape =
  | { kind: 'scalar' }
  | { kind: 'mask'; rank?: 1; dimensions?: number[] }
  | { kind: 'possible' }
  | { kind: 'unreadable' };

function conditionShape(t: Readonly<Type>, depth = 0): ConditionShape {
  if (t === 'error' || isSubtype(t, CONDITION_CELL_TYPE))
    return { kind: 'scalar' };
  if (typeof t !== 'string') {
    if (
      t.kind === 'list' &&
      Array.isArray(t.dimensions) &&
      t.dimensions.length > 0 &&
      isSubtype(t.elements, CONDITION_CELL_TYPE)
    )
      // A type of two dimensions or more (`matrix<boolean^(2x2)>`) is refused
      // by the canonical form (`conditionOperand()`). It is read here only
      // when the condition was boxed before its type was known (a symbol
      // assigned a matrix later), and its evaluation is then the
      // `incompatible-type` error: it is a mask with no `rank`.
      return t.dimensions.length === 1
        ? { kind: 'mask', rank: 1, dimensions: t.dimensions }
        : { kind: 'mask' };
    // A tuple is a subtype of `indexed_collection`, but runtime lifts tuples
    // whole (tuple-atomic): a tuple-typed condition never activates the
    // element-wise path, so it must not flip the static shape either.
    if (t.kind === 'tuple') return { kind: 'scalar' };
    if (
      t.kind === 'broadcastable' &&
      isSubtype(t.elements, CONDITION_CELL_TYPE)
    )
      return { kind: 'possible' };
    if (t.kind === 'union' && depth < 8) {
      const shapes = t.types.map((x) => conditionShape(x, depth + 1));
      if (shapes.some((s) => s.kind === 'unreadable'))
        return { kind: 'unreadable' };
      const masks = shapes.filter((s) => s.kind === 'mask');
      if (masks.length === shapes.length) return mergeMaskShapes(masks);
      // A union of a scalar and a mask (`boolean | list<boolean>`) is a mask
      // for some values only. It is read as `unreadable`, not `possible`: on
      // its own it keeps the scalar typing, and beside a mask it makes the
      // mask not provably flat.
      if (masks.length > 0 || shapes.some((s) => s.kind === 'possible'))
        return { kind: 'unreadable' };
      return { kind: 'scalar' };
    }
  }
  if (isSubtype(t, BOOLEAN_COLLECTION_TYPE)) return { kind: 'mask', rank: 1 };
  if (isPossiblyNestedBooleanMask(t)) return { kind: 'mask' };
  return { kind: 'unreadable' };
}

/**
 * The shape of a set of masks: flat (`rank` 1) when every mask is flat, and
 * no `rank` otherwise; their common length (`dimensions`), `undefined` when
 * two masks have different lengths. A flat mask without dimensions does not
 * invalidate the length of another one: at run time both have the same
 * length or the selection is a dimension error.
 */
function mergeMaskShapes(
  masks: ReadonlyArray<{ rank?: 1; dimensions?: number[] }>
): { kind: 'mask'; rank?: 1; dimensions?: number[] } {
  let rank: 1 | undefined;
  let dimensions: number[] | undefined;
  let dimensionsDisagree = false;
  for (const m of masks) {
    if (m.rank === undefined) return { kind: 'mask' };
    rank = 1;
    const dims = m.dimensions;
    if (dims === undefined) continue;
    if (dimensions === undefined) dimensions = dims;
    else if (dimensions[0] !== dims[0]) dimensionsDisagree = true;
  }
  return {
    kind: 'mask',
    rank,
    dimensions: dimensionsDisagree ? undefined : dimensions,
  };
}

/**
 * 1 when some condition of an element-wise conditional whose conditions have
 * the types `conds` is provably a mask and every condition that may be a
 * mask is provably flat (`elementwiseConditionShape`), and `undefined`
 * otherwise. The compiler reads it to compile a restriction by a flat mask
 * as a restriction.
 */
export function elementwiseMaskRank(
  conds: ReadonlyArray<Type | undefined>
): 1 | undefined {
  return elementwiseConditionShape(conds)?.rank;
}

/**
 * The shape of an element-wise conditional, from the TYPES of its conditions
 * (`conditionShape`): `undefined` when no condition is provably a mask (the
 * scalar typing, or the typing of a condition that is only possibly a mask,
 * applies), otherwise:
 *
 * - `rank` and `dimensions`: the shape of the masks (`mergeMaskShapes`).
 *   There is no `rank` when a condition is only possibly a mask, or when the
 *   shape analysis cannot read a condition (a condition of type `unknown`):
 *   such a condition is checked on its value.
 * - `firstMask`: the index of the first condition that is provably a mask.
 *   A clause before it whose condition is `True` at run time selects its arm
 *   WHOLE, so the result type joins those arms.
 */
function elementwiseConditionShape(
  conds: ReadonlyArray<Type | undefined>
): { rank?: 1; dimensions?: number[]; firstMask: number } | undefined {
  const shapes = conds.map((t): ConditionShape =>
    t === undefined ? { kind: 'scalar' } : conditionShape(t)
  );
  const firstMask = shapes.findIndex((s) => s.kind === 'mask');
  if (firstMask < 0) return undefined;
  if (shapes.some((s) => s.kind === 'possible' || s.kind === 'unreadable'))
    return { firstMask };
  const { rank, dimensions } = mergeMaskShapes(
    shapes.filter((s) => s.kind === 'mask')
  );
  return { rank, dimensions, firstMask };
}

/**
 * True when `t` is a list whose leaves are conditions (`boolean` or
 * `missing`), at any depth, with lists of unknown contents allowed beside
 * them: `list<boolean | list<any>>`, `list<list<boolean^2> | list<boolean^1>>`
 * (a mask whose rows have different lengths), or `tensor<boolean>`. A
 * comparison over a collection whose elements may be lists (a bare
 * `indexed_collection`) is typed `list<boolean | list<any>>`, because the
 * comparison maps a nested element at its leaves.
 *
 * Such a mask selects element-wise when its value is flat, and its value
 * is the `incompatible-type` error otherwise. The selection is typed
 * `list<C | list<any>>` (`elementwiseResultType`).
 */
function isPossiblyNestedBooleanMask(t: Readonly<Type>): boolean {
  if (typeof t === 'string' || t.kind !== 'list') return false;
  return maskLeaves(t.elements, 0) === 'condition';
}

/**
 * What the leaves of a mask element are: `'condition'` when some leaf is a
 * condition and every other leaf is a list of unknown contents, `'list'` when
 * every leaf is a list of unknown contents, `'other'` otherwise. The depth cap
 * stops a walk through a self-referential alias.
 */
function maskLeaves(
  t: Readonly<Type>,
  depth: number
): 'condition' | 'list' | 'other' {
  if (depth > 8) return 'other';
  if (isSubtype(t, CONDITION_CELL_TYPE)) return 'condition';
  if (t === 'list') return 'list';
  if (typeof t === 'string') return 'other';
  if (t.kind === 'union') {
    let result: 'condition' | 'list' = 'list';
    for (const arm of t.types) {
      const leaves = maskLeaves(arm, depth + 1);
      if (leaves === 'other') return 'other';
      if (leaves === 'condition') result = 'condition';
    }
    return result;
  }
  if (t.kind !== 'list') return 'other';
  if (t.elements === 'any' || t.elements === 'unknown') return 'list';
  return maskLeaves(t.elements, depth + 1);
}

/**
 * The type an arm contributes to the element-wise result.
 *
 * Only arms that would actually be INDEXED at runtime contribute their element
 * type. Runtime lifts anything that is not an `isBroadcastableCollection`
 * WHOLE — a tuple in particular is one element, not a row (the tuple-atomic
 * convention) — so `broadcastElementType` must not be applied to it: it unwraps
 * tuples, sets, dictionaries and records, which would declare `list<T>` for a
 * `Which` that produces `list<tuple<…>>`.
 */
function armElementType(t: Readonly<Type>): Type {
  // The unparameterized ORDERED collection names are indexed at runtime like
  // their parameterized forms, so they contribute their element type too: a
  // `range` arm contributes `integer` (its members are indices), and a bare
  // `list` or `indexed_collection` contributes `unknown`. Returning the name
  // itself put the whole collection type where a cell type belongs
  // (`Which(P > 1, P, True, 0)` for `P: range` typed `list<integer | range>`).
  if (typeof t === 'string')
    return t === 'range' || t === 'list' || t === 'indexed_collection'
      ? broadcastElementType(t)
      : t;
  if (t.kind === 'union')
    return widen(...t.types.map((x) => armElementType(x)));
  // The selection indexes a list arm position by position, so a position
  // holds an ELEMENT of the arm: a row of a matrix, `U | tensor<U>` for a
  // tensor of unknown rank (`collectionElementType`). The broadcast cell
  // (`broadcastElementType`) is a leaf of a tensor, not its element. A list
  // arm whose elements are lists is refused before evaluation
  // (`selectionArmKind()`), so for a valid arm the element and the cell
  // differ only in a type that does not settle the depth (a tensor of
  // unknown rank, `broadcastable<…>`).
  if (t.kind === 'list' || t.kind === 'indexed_collection')
    return collectionElementType(t) ?? broadcastElementType(t);
  return t as Type;
}

/**
 * True when an arm of an element-wise selection can put a value of any type
 * at a position, so that the cell of the selection is `unknown`
 * (`elementwiseResultType`):
 *
 * - an arm of type `unknown` that gives a value in place (`untypedArm`): a
 *   symbol that is not declared, a call of a function that is not defined
 *   yet (`g(1)`: with `L = [1, 3, 5]`, `Which(L < 2, g(1), True, 0)` is a
 *   `list<unknown^3>`, and after `g := x ↦ x / 2` its value is
 *   `[1/2, 0, 0]`), or a library operator applied to one. A recursive call
 *   is not read this way, as in the scalar typing of `If` and `Which`: it is
 *   typed `unknown` while the result type of its function is derived from
 *   this selection, and that derivation needs the other arms.
 * - an arm whose type says that its elements are `unknown`
 *   (`typeHasUnknownCells`): `foo(L)` with `foo` not declared and `L` a
 *   list of three numbers is a `list<unknown^3>`. A recursive call over a
 *   list is typed this way too while the result type of its function is
 *   derived, so `r := n ↦ Which(L < 2, r(L), True, 0)` gives a
 *   `list<unknown^3>`: the type is less precise than the base case, and it
 *   holds every value.
 */
function armGivesUnknownCells(
  arm: OperandDescriptor,
  engine: TypeHandlerContext['engine']
): boolean {
  return arm.type === 'unknown'
    ? untypedArm(arm, engine)
    : typeHasUnknownCells(arm.type);
}

/**
 * True when a value of type `t`, used as an arm of an element-wise
 * selection, can put a value of any type at a position: `t` is a list or an
 * indexed collection whose element type (`armElementType`) is `unknown` or a
 * union with an `unknown` option (`missing | unknown`), or `t` is a union
 * with such an option or with the option `unknown` itself (`missing |
 * unknown`, the type of an index into a `list<unknown>`). The type
 * `unknown` alone is not decided here: `armGivesUnknownCells` reads the
 * structure of such an arm.
 */
function typeHasUnknownCells(t: Readonly<Type>, depth = 0): boolean {
  if (typeof t === 'string' || depth > 8) return false;
  if (t.kind === 'union')
    return t.types.some(
      (x) => x === 'unknown' || typeHasUnknownCells(x, depth + 1)
    );
  if (t.kind !== 'list' && t.kind !== 'indexed_collection') return false;
  const element = armElementType(t);
  if (typeof element === 'string') return element === 'unknown';
  return element.kind === 'union' && element.types.includes('unknown');
}

/**
 * The CELL type of an arm, for a selection whose condition is only possibly
 * a mask (`possiblyElementwiseResultType`): the rank of such a mask is not
 * known statically, so the result is a `broadcastable` of the cells of the
 * arms, and `broadcastable<T>` is defined only for a `T` that cannot hold a
 * list (`docs/TYPE-SYSTEM.md`, "Lists, tensors and `broadcastable`"). So a
 * `broadcastable<T>` arm contributes `T`, a tensor (`tensor<U>`, or a list
 * with dimensions) contributes its cells `U`, and any other list contributes
 * the cell type of its elements. A scalar or a tuple contributes itself
 * (`armElementType`). The depth cap stops a walk through a self-referential
 * type.
 */
function armCellType(t: Readonly<Type>, depth = 0): Type {
  if (depth > 8 || typeof t === 'string') return armElementType(t);
  if (t.kind === 'union')
    return widen(...t.types.map((x) => armCellType(x, depth + 1)));
  if (t.kind === 'broadcastable') return t.elements;
  if (t.kind === 'list' && t.dimensions !== undefined) return t.elements;
  const element = armElementType(t);
  return element === t ? element : armCellType(element, depth + 1);
}

/**
 * The type of the value that the arms of an element-wise selection put at a
 * position (`armElementType`), joined over the arms. The no-match cell there is the `unmatchedCell()` of this type: `NaN` when
 * every arm puts a number there, a `NaN` point when every arm puts a point
 * there, `Missing` otherwise.
 */
function noMatchPositionType(arms: ReadonlyArray<Type>): Type {
  return widen(...arms.map((t) => armElementType(t)));
}

/**
 * The type of ONE CELL of an element-wise selection: the join of the arms'
 * element types (a list-valued arm contributes its ELEMENT type, since it is
 * indexed position-wise; a scalar arm contributes its own type, since it
 * lifts). `contributions`, when given, replaces the types the arms
 * contribute (the possibly element-wise selection passes their cells,
 * `armCellType`); the no-match rule below still reads the elements of the
 * arms, as the evaluation does (`noMatchCell`).
 *
 * `hasDefault` — a clause whose condition is literally `True` (for `If`, an
 * else branch) — decides whether the no-match cell can occur. Without one, a
 * position no clause matches is `NaN` when every arm is numeric (R4,
 * `noMatchCell`), and `finite_*` types EXCLUDE NaN under the non-finite
 * typing convention: the element type must therefore join in `number`, the
 * narrowest type that admits NaN, or a consumer
 * dispatching on `.type.matches()` would be promised a `integer` cell
 * and handed a `NaN`. WITH a default clause the no-match cell is unreachable
 * and the exact join is kept — widening unconditionally would hand every
 * element-wise conditional an over-wide union, which breaks that same
 * dispatch.
 */
function elementwiseCellType(
  arms: ReadonlyArray<Type>,
  hasDefault: boolean,
  contributions: ReadonlyArray<Type> = arms.map((t) => armElementType(t))
): Type {
  if (hasDefault) return widen(...contributions);
  // The no-match cell is the `unmatchedCell()` of the type of the position
  // (`noMatchCell`): `NaN` when every arm is numeric, so the cell joins in
  // `number`, the narrowest type that admits `NaN`; a `NaN` point when every
  // arm is a point, so the cell joins in a point of `number` coordinates;
  // `False` or the `NaN` colour when every arm is a boolean or a colour
  // (`unmatchedCellKind`); `Missing` otherwise, so the cell keeps a
  // `missing` arm. The union is built explicitly: `widen` joins toward a
  // common supertype and would dissolve the absence marker.
  const joined = widen(...contributions);
  const position = noMatchPositionType(arms);
  if (isNumericValueType(position)) return widen(joined, 'number');
  const n = pointArity(position);
  if (n !== undefined) return widen(joined, nanPointType(n));
  const kind = unmatchedCellKind(position);
  if (kind !== undefined) return widen(joined, kind);
  return reduceType({ kind: 'union', types: [joined, 'missing'] });
}

/**
 * The result type of a selection whose condition is only POSSIBLY a boolean
 * collection (`possiblyElementwiseCondition`): `broadcastable` of the
 * element-wise cell type, joined with every arm that this type does not
 * already admit.
 *
 * At runtime such a condition can also be a scalar boolean, and the
 * selection then returns one arm WHOLE. A scalar arm, or a list arm whose
 * elements are in the cell type, is admitted by `broadcastable<cell>`. An
 * arm whose element type is `unknown` is not: `widen` treats `unknown` as
 * "no information" and drops it from the cell. With `u: list` and
 * `p: tuple<integer>`, `If(u[2] != 0, p, u)` was typed
 * `broadcastable<tuple<integer>>`, while for `u = [1, 0, 3]` it returns
 * `[1, 0, 3]` (issue #454).
 *
 * The cell type is the join of the CELLS of the arms (`armCellType`), so
 * that the result is never a `broadcastable` of a list type: with
 * `B: broadcastable<number>`, `If(B < 0, -B, B)` is a
 * `broadcastable<number>`, not a `broadcastable<broadcastable<number>>`.
 */
function possiblyElementwiseResultType(
  arms: ReadonlyArray<Type>,
  hasDefault: boolean
): Type {
  const broadcast: Type = {
    kind: 'broadcastable',
    elements: elementwiseCellType(
      arms,
      hasDefault,
      arms.map((t) => armCellType(t))
    ),
  };
  const missed = arms.filter((t) => !isSubtype(t, broadcast));
  // When an element of an arm can be a list (a tensor, a `broadcastable`, a
  // value of unknown type), the type also admits `list<cell | list<any>>`,
  // a list whose elements are cells or lists of any depth. No valid value
  // has that shape: an arm value whose elements are lists is refused when
  // the selection is evaluated (`runtimeArmError()`), for example an arm
  // declared `unknown` whose value is `[[1, 2], [3, 4]]`, which gives an
  // `incompatible-type` error. The option is kept so that this function
  // gives the same type as before nested selection was removed; narrowing
  // it to `list<cell>` changes a public type.
  if (arms.some((t) => !cannotHoldAList(armElementType(t))))
    missed.push({
      kind: 'list',
      elements: reduceType({
        kind: 'union',
        types: [broadcast.elements, { kind: 'list', elements: 'any' }],
      }),
    });
  if (missed.length === 0) return broadcast;
  return reduceType({ kind: 'union', types: [broadcast, ...missed] });
}

/**
 * The value of a position that no clause of an element-wise selection
 * selects, given the types of all the arms of the selection: the
 * `unmatchedCell()` of the type of the position, `NaN` when every arm puts
 * a number there, a point whose coordinates are `NaN` when every arm puts a
 * point there, and `Missing` otherwise (a boolean, a value that is not
 * provably numeric). A list arm puts its element there, a scalar or a point
 * arm puts itself (`armElementType`). This is the rule a restriction applies
 * to a cell it masks, so `Which([1, 5] < 3, (1, 2))` and
 * `If([1, 5] < 3, (1, 2))` are both `[(1, 2), (NaN, NaN)]`, and
 * `Which([1, 5] < 3, 7)` and `If([1, 5] < 3, 7)` are both `[7, NaN]`
 * (selection rule of 2026-11-02, `docs/BROADCAST-MODEL.md`). The rule reads the types of the arms and not
 * their values: an arm that no position reaches is not evaluated.
 */
function noMatchCell(ce: ComputeEngine, arms: ReadonlyArray<Type>): Expression {
  return unmatchedCell(ce, noMatchPositionType(arms));
}

/**
 * True when a condition is only POSSIBLY a boolean collection: its type is
 * `broadcastable<boolean>`, the union `boolean | list<boolean>`
 * the engine gives a comparison whose broadcast outcome it cannot settle
 * statically — `C = U_1` with `C` declared `indexed_collection` and `U_1`
 * top-typed is `[True,False,True]` when `U_1` turns out to be a scalar and the
 * single boolean of a whole-collection compare when it turns out to be a
 * collection (`library/relational-operator.ts`, `comparisonResultType`).
 *
 * Such a condition takes the element-wise selection path at runtime only in
 * the first case, so neither the element-wise list type nor the scalar join of
 * the arms is honest on its own: the result is `broadcastable` of the same
 * cell type the element-wise path would produce.
 *
 * The test reads the `kind` of the type (`conditionShape`), not a subtype
 * relation: `matches('broadcastable<boolean>')` would also accept a plain
 * scalar `boolean` condition, since a scalar is a member of the union that
 * `broadcastable<T>` abbreviates.
 */
function possiblyElementwiseCondition(
  conds: ReadonlyArray<Type | undefined>
): boolean {
  return conds.some(
    (t) => t !== undefined && conditionShape(t).kind === 'possible'
  );
}

/**
 * True when `t` is the open form `B | list<B | list<any>>`
 * (`openDepthScalarArms`) of a condition type `B`: the type of a comparison
 * over an operand of type `unknown` (`h(x) ≤ 1` with `h` undeclared). As a
 * cell of a materialized mask, such a comparison is one scalar relation, as
 * a cell typed `broadcastable<boolean>` is.
 */
function isOpenConditionCell(t: Type): boolean {
  const open = openDepthScalarArms(t);
  return open !== undefined && isSubtype(open, CONDITION_CELL_TYPE);
}

/**
 * True when a condition of type `t` cannot be read (`conditionShape` is
 * `unreadable`: `unknown`, `any`, a union of a scalar and a mask) and may
 * hold a list. At run time such a condition can be a scalar or a flat mask,
 * and with a flat mask the selection is element-wise; a nested value is an
 * `incompatible-type` error. A condition that cannot hold a list (a
 * number, which the canonical form refuses) is not read as a mask.
 */
function unreadableConditionMayBeMask(t: Type): boolean {
  return conditionShape(t).kind === 'unreadable' && !cannotHoldAList(t);
}

/**
 * The shape of the masks of a selection whose only condition that is not a
 * scalar has a union type whose options are each a scalar condition type or
 * a mask type, with at least one of each (`boolean | list<boolean>`), and
 * `undefined` otherwise. A union that has an option of unreadable type or a
 * `broadcastable` option is not read here.
 *
 * At run time such a condition is a scalar or a mask, so the result type is
 * the union of the scalar result type and of the element-wise result type of
 * this shape. Each option is typed on its own: a `broadcastable` result type
 * would also admit a scalar cell, which the selection cannot give when every
 * arm is a list.
 *
 * Only a selection where every other condition is a scalar is read, so that
 * the element-wise result has the rank of this condition's masks. Clauses
 * before this condition that select at run time give their arm whole, which
 * the scalar result type holds.
 */
function scalarOrMaskConditionShape(
  conds: ReadonlyArray<Type | undefined>
): { rank?: 1; dimensions?: number[] } | undefined {
  const shapes = conds.map((t): ConditionShape =>
    t === undefined ? { kind: 'scalar' } : conditionShape(t)
  );
  const others = shapes.filter((s) => s.kind !== 'scalar');
  if (others.length !== 1) return undefined;
  const t = conds[shapes.indexOf(others[0])];
  if (t === undefined || typeof t === 'string' || t.kind !== 'union')
    return undefined;
  const options = t.types.map((x) => conditionShape(x, 1));
  if (!options.every((s) => s.kind === 'scalar' || s.kind === 'mask'))
    return undefined;
  const masks = options.filter((s) => s.kind === 'mask');
  if (masks.length === 0 || masks.length === options.length) return undefined;
  const { rank, dimensions } = mergeMaskShapes(masks);
  return { rank, dimensions };
}

/**
 * The type of an element-wise selection, given the shape of its masks
 * (`elementwiseConditionShape`).
 *
 * - When the masks are flat (`rank` 1), the result is a list of
 *   `elementwiseCellType`: with its length when the masks have a known
 *   common length and the cell can carry it (`list<integer^2>`), and
 *   `list<C>` otherwise.
 * - When the type does not settle that the masks are flat, the result is
 *   `list<C | list<any>>`, a list whose elements are cells or lists of any
 *   depth, with `C` the cell type. This is the type
 *   `broadcastShapedResultType` (`common/type/utils.ts`) gives a broadcast
 *   of unknown depth.
 *
 * An arm that can put a value of any type at a position
 * (`armGivesUnknownCells`) adds the option `unknown` to the cell.
 * `elementwiseCellType` alone leaves such an arm out, because `widen` reads
 * an `unknown` operand as "no information". With `L = [1, 3, 5]` and `foo`
 * not declared, `Which(L < 2, foo(L), True, 0)` is a `list<unknown^3>`, not
 * the `vector<integer^3>` of its other arm: it is `[1/2, 0, 0]` when `foo`
 * is later defined as `x ↦ x / 2`. The reduced union keeps an absence that
 * the other arms or the no-match cell put in the cell, and nothing else:
 * `Which(L < 2, foo(L), True, Missing)` is a `list<missing | unknown>`.
 */
function elementwiseResultType(
  arms: ReadonlyArray<OperandDescriptor>,
  shape: { rank?: 1; dimensions?: number[] },
  hasDefault: boolean,
  engine: TypeHandlerContext['engine']
): Type {
  const known = elementwiseCellType(
    arms.map((x) => x.type),
    hasDefault
  );
  const elements: Type = arms.some((x) => armGivesUnknownCells(x, engine))
    ? reduceType({ kind: 'union', types: [known, 'unknown'] })
    : known;
  if (shape.rank === undefined)
    return {
      kind: 'list',
      elements: reduceType({
        kind: 'union',
        types: [elements, { kind: 'list', elements: 'any' }],
      }),
    };
  // The union-free clause (tensor-unification design §D3 rule 2): a
  // dimensioned `list` type IS the tensor claim (`isTensor` is exactly
  // `dimensions !== undefined`), and a heterogeneous cell population never
  // qualifies — the `List` shape analysis (`shapedListTypeD`,
  // `collections.ts`) declines the shape for it. Claiming a
  // dimension here for a union element type would promise a shape no
  // evaluated value can ever carry, breaking the value-vs-declared
  // assignability invariant (`evaluated.type.matches(declared)`) for the
  // no-default mixed case, whose no-match cell joins in `number`. A length
  // is written only for a cell that may carry a dimension
  // (`mayCarryDimensions`: a cell that cannot be a list), so a selection of
  // numbers, booleans or points keeps its length.
  const dimensions = shape.dimensions;
  const shaped =
    dimensions !== undefined &&
    dimensions.length === 1 &&
    (typeof elements === 'string' || elements.kind !== 'union') &&
    mayCarryDimensions(elements);
  if (shaped) return { kind: 'list', elements, dimensions: [...dimensions] };
  return { kind: 'list', elements };
}

/** Evaluate an `If` expression. */
function evaluateIf(
  ops: ReadonlyArray<Expression>,
  options: Partial<EvaluateOptions> & { engine: ComputeEngine }
): Expression | undefined {
  const [cond, ifTrue, ifFalse] = ops;
  const engine = options.engine;
  // The numeric request of the `If` is forwarded to the condition and to the
  // selected branch, so that a function that jumps in them (`Floor`, a
  // comparison) reads an exact operand exactly, as it does at the top level.
  // In the body of a user function under `.N()`, a parameter is bound to the
  // float of the argument, and only such a function evaluated with the
  // numeric request reads the exact argument again (`exactRealValueOf`,
  // `constraint-subject.ts`).
  const armOptions = options.numericApproximation
    ? { numericApproximation: true }
    : undefined;
  const evaluatedOnce = evaluateCondition(cond, options.numericApproximation);
  // A held conjunction in a restriction is evaluated once more, before the
  // verdict checks below, which keeps one copy of each condition: the
  // restriction of a group of restricted terms is `If(And(c, c), …)`
  // (`x\{c\} − x\{c\}`), and its held form is `If(c, …)`. A conjunction
  // that this step decides (`And(C, Not(C))` is `False`) then takes the
  // route of a condition that was decided from the start.
  const evaluated =
    ops.length === 2 &&
    ifTrue !== undefined &&
    !isStatementArm(ifTrue) &&
    isFunction(evaluatedOnce, 'And')
      ? evaluatedOnce.evaluate(armOptions)
      : evaluatedOnce;
  // The condition is the one operand `If` ALWAYS demands, so an error
  // in it propagates — the dual obligation of the demanded-operands
  // rule (`docs/ERROR-MODEL.md` §3), which this handler owns because a
  // lazy operator is not pre-absorbed. Answering here also keeps the
  // error a value: a lazy operator's handler faults are re-thrown
  // rather than converted to an `Error` expression, so an error condition
  // that reached the typo throw at the end of this handler would escape
  // as a host exception.
  const condError = errorValue(evaluated);
  if (condError !== undefined) return condError;
  const evaluatedCond = sym(evaluated);
  if (evaluatedCond === 'True')
    return ifTrue?.evaluate(armOptions) ?? engine.Missing;
  // With no else branch, a false condition gives the absent value of the
  // domain of the arm (`maskedValue`): `NaN` for a number, as a restriction
  // `e\{c\}` does. A statement arm (`If(k = 2, Assign(a, 5))`) has no
  // value, so the result is `Missing`. An absent condition (`Missing`) is
  // read as `False` by `evaluateCondition`: `If(Missing, 1, 2)` is `2`.
  if (evaluatedCond === 'False')
    return (
      ifFalse?.evaluate(armOptions) ??
      (ifTrue === undefined || isStatementArm(ifTrue)
        ? engine.Missing
        : maskedValue(engine, ifTrue))
    );
  // A single-branch `If(c, e)` whose arm is a value is the restriction
  // `e\{c\}`, which the parser reads as this `If` (`evaluateRestriction()`):
  // a list of conditions masks element by element (truncated to the shorter
  // of the mask and a list value), and an undecided condition is held.
  // Decision of 2026-11-02, `docs/plans/2026-11-02-restriction-binding.md`.
  if (ops.length === 2 && ifTrue !== undefined && !isStatementArm(ifTrue))
    return evaluateRestriction(engine, ifTrue, evaluated, options);
  // A LIST-VALUED condition selects element-wise: `If(c, a, b)` is the
  // two-clause `Which(c, a, True, b)` (see
  // `evaluateElementwiseSelection`). Without an else branch the
  // unselected positions are the no-match cell (`NaN` for a numeric arm,
  // `Missing` otherwise: `noMatchCell`), not `Nothing`:
  // an element-wise result preserves positions (R4).
  const mask = conditionCells(evaluated);
  if (mask !== undefined && ifTrue !== undefined) {
    const clauses = [{ cond, arm: ifTrue }];
    if (ifFalse !== undefined)
      clauses.push({ cond: engine.True, arm: ifFalse });
    const evaluatedArms: Expression[] = [];
    const selected = evaluateElementwiseSelection(
      engine,
      clauses,
      { cond: evaluated, mask },
      options,
      undefined,
      evaluatedArms
    );
    if (selected !== undefined) return selected;
    // A selection that cannot be made now (an arm whose elements cannot be
    // read) is held around the evaluated condition and the evaluated arms.
    if (evaluatedArms.length > 0)
      return engine._fn('If', [
        evaluated,
        ...ops.slice(1).map((x, k) => evaluatedArms[k] ?? x),
      ]);
  }
  // Every other condition leaves the `If` UNEVALUATED. That covers an
  // undecided boolean — a relation with free variables (`x = 4` stays
  // symbolic under evaluate()), a symbol with no value — and equally a
  // condition that is not a boolean at all (the number 10, a misspelled
  // symbol, a list of numbers). An undecidable conditional is a symbolic
  // expression, not a program defect: it may become decidable once its
  // variables are bound, and a host exception thrown from here escapes
  // past every caller that only asked for a value. (User ruling
  // 2026-08-31, shared with `evaluateWhich` so the two cannot diverge.)
  //
  // The node is rebuilt around the EVALUATED condition (the held arms
  // untouched): `If` is `lazy`, and a lazy handler that returns
  // `undefined` hands the framework the ORIGINAL node, discarding the
  // condition's evaluation — `If(C = U[1], …)` kept `U[1]` where its
  // condition had already read `10`, and inside a big operator's loop
  // the condition kept the INDEX symbol rather than the value the loop
  // had assigned (see `evaluateBigOpTerm`, `library/utils.ts`). The
  // `isSame` guard keeps this a fixpoint: an unchanged condition returns
  // `undefined` as before, so the rebuilt node evaluates to itself.
  // With two arms that are lists of one length, the held `If` is a list of
  // `If`s, one for each position (see `distributeOverListArms`).
  if (
    ifTrue !== undefined &&
    ifFalse !== undefined &&
    isScalarGuard(evaluated)
  ) {
    const list = distributeOverListArms(engine, [ifTrue, ifFalse], (arms) =>
      engine._fn('If', [evaluated, ...arms])
    );
    if (list !== undefined) return list;
  }
  return evaluated.isSame(cond)
    ? undefined
    : engine._fn('If', [evaluated, ...ops.slice(1)]);
}

/**
 * True if the type of the guard `g` is `boolean`, so that `g` cannot be a
 * list of booleans (a mask, which selects element-wise) when its value is
 * known. The value of `g` is not enough: a symbol of type `list<boolean>`
 * that has no value yet is not a collection, and a symbol of type `unknown`
 * can later be assigned a mask, so both are refused.
 */
function isScalarGuard(g: Expression): boolean {
  return isSubtype(g.type.type, 'boolean');
}

/**
 * The list of selections, one for each position, of a selection whose arms
 * are all lists of one length: with an undecided condition `c`,
 * `Which(c, [1, 2], True, [3, 4])` is `[Which(c, 1, True, 3), Which(c, 2,
 * True, 4)]`. The two forms have the same value for every value of `c`, but
 * the second one is a `List`, so that a caller that reads the elements of the
 * value finds them. This is the form that a list combined with a selection
 * gets: `[1, 2] + Which(c, 0, True, 1)` distributes the `Add` into the arms
 * (`threadConditional`, `boxed-function.ts`), which gives a selection of
 * lists, and this makes it a list of selections.
 *
 * `build` makes the selection at one position from the arms at that
 * position. An arm at a position that is itself a list of the same length
 * as the other arms at that position is distributed again, so a selection of
 * matrices is a matrix of selections. Returns `undefined` when an arm is not
 * a `List`, or when two arms have different lengths: the selection stays as
 * it is.
 *
 * The arms are not evaluated here: an arm of a selection is evaluated only
 * when its condition selects it, and the selection at each position keeps
 * that rule.
 */
function distributeOverListArms(
  ce: ComputeEngine,
  arms: ReadonlyArray<Expression>,
  build: (arms: ReadonlyArray<Expression>) => Expression
): Expression | undefined {
  const first = arms[0];
  if (!isFunction(first, 'List')) return undefined;
  const n = first.nops;
  const lists = arms.filter((x) => isFunction(x, 'List') && x.nops === n);
  if (lists.length !== arms.length) return undefined;
  const cells: Expression[] = [];
  for (let k = 0; k < n; k++) {
    const at = lists.map((x) => (isFunction(x) ? x.ops[k] : x));
    cells.push(distributeOverListArms(ce, at, build) ?? build(at));
  }
  return ce._fn('List', cells);
}

/**
 * The value of the restriction `expr\{c\}`, the single-branch `If(c, expr)`
 * whose arm is a value, for a condition `c` that is already evaluated and
 * that is not an error, not `True` and not `False` (`evaluateIf()` answers
 * these; an absent condition is read as `False` there).
 * A restriction that cannot be decided now is held, spelled `If(c, e)`.
 *
 * - A finite collection of conditions (a mask) restricts element by element.
 *   A mask with a list of conditions in it (`M < 0` over a matrix `M`) is
 *   the `incompatible-type` error (`evaluateElementwiseSelection()`): a
 *   condition is a boolean or a flat list of booleans. A flat mask zips a
 *   collection value with the mask, to the shorter of the two lengths, and restricts a scalar value whole at each position. A cell
 *   whose condition is `True` is the element, a cell whose condition is
 *   `False` is its absent value (`maskedValue`: `NaN` for a number,
 *   `Missing` otherwise), and any other cell is the held `If(c_i, elem_i)`.
 *   A tuple and a string are one value each and are never zipped. A carrier
 *   whose static type is ordered (`isOrderedCarrierType`) is zipped whatever
 *   its length, and only the first `k` elements are read
 *   (`orderedCarrierPrefix`), so an infinite carrier is never materialized
 *   (user decision 2026-09-29): `If([True, False], Range(1, ∞))` is
 *   `[1, NaN]`. When the elements of the carrier cannot be read (a valueless
 *   symbol declared `list<number>`, `Range(1, n)`), or a finite carrier has
 *   elements that cannot be computed (`QuotientRing(Integers, 5)`), the
 *   whole restriction is held.
 * - A condition that evaluates to `Missing` has no value, and gives the
 *   absent value of `expr`.
 * - Any other condition is undecided, and the restriction is held. Over a
 *   collection value that is not a tuple or a string, the collection is
 *   evaluated, and the held `If(c, L)` presents as the collection of its
 *   restricted cells (`restrictionCollectionHandlers()`, Tycho item 66). The
 *   cells are not copied into a `List` of `If`s (user decision 2026-09-25): a
 *   copy forgot that its cells came from one restriction. A condition that
 *   is collection-typed but has no value yet (a valueless `B:
 *   list<boolean>`) is a mask that cannot be read yet, and the collection is
 *   not evaluated (Tycho item 221).
 */
function evaluateRestriction(
  ce: ComputeEngine,
  expr: Expression,
  c: Expression,
  options: Partial<EvaluateOptions> & { engine: ComputeEngine }
): Expression {
  const held = (value: Expression) => ce._fn('If', [c, value]);
  if (c.isCollection && isWalkableFiniteCollection(c)) {
    const conds = Array.from(c.each()) as Expression[];
    // A cell is a boolean condition when it types `boolean`, or
    // `broadcastable<boolean>`, the type of a comparison whose broadcast
    // outcome is not statically settled (`h(x) ≤ 1` with `h` undeclared).
    const mask = conditionCells(c);
    if (
      mask !== undefined &&
      mask.cells.some((cell) => typeof cell !== 'string')
    )
      return (
        evaluateElementwiseSelection(
          ce,
          [{ cond: c, arm: expr }],
          { cond: c, mask },
          options
        ) ?? held(expr)
      );
    if (
      conds.every(
        (ci) =>
          ci.type.matches('boolean') ||
          possiblyElementwiseCondition([ci.type.type]) ||
          isOpenConditionCell(ci.type.type)
      )
    ) {
      const ev = expr.evaluate(options);
      // The value of the restricted expression is refused when the canonical
      // form refuses its type (`runtimeArmError()`).
      const refused = runtimeArmError(ce, expr, ev);
      if (refused !== undefined) return refused;
      const ordered = isOrderedCarrierType(expr.type.type);
      const atomic = isAtomicCarrierValue(expr.type.type, ev);
      let zip = false;
      let elems: Expression[] = [];
      if (ordered && !atomic) {
        const prefix = ev.isCollection
          ? orderedCarrierPrefix(ev, conds.length)
          : undefined;
        if (prefix === undefined) return held(expr);
        elems = prefix;
        zip = true;
      } else if (!atomic && ev.isCollection && isWalkableFiniteCollection(ev)) {
        elems = Array.from(ev.each()) as Expression[];
        zip = true;
      } else if (!atomic && ev.isCollection && ev.isFiniteCollection === true)
        return held(expr);
      const n = zip ? Math.min(conds.length, elems.length) : conds.length;
      const result: Expression[] = [];
      for (let i = 0; i < n; i++) {
        const ci = conds[i];
        const cis = sym(ci);
        const elem = zip ? elems[i] : ev;
        if (cis === 'True') result.push(elem);
        else if (cis === 'False')
          result.push(unmatchedCell(ce, elem.type.type));
        else result.push(maskCell(ce, ci, zip ? elems[i] : expr));
      }
      return ce._fn('List', result);
    }
  }

  if (
    expr.type.matches('collection<any>') &&
    !isTupleShapedType(expr.type.type) &&
    !expr.type.matches('string') &&
    !isUnresolvedCollectionOperand(c)
  ) {
    const ev = expr.evaluate(options);
    if (isFiniteBroadcastParticipant(ev)) return held(ev);
  }
  return held(expr);
}

/**
 * The asynchronous twin of `evaluateIf`. The condition is awaited through
 * the asynchronous route — where a relation awaits an asynchronous-only
 * operand of its own before it compares — and the selected arm is awaited
 * the same way, so an operator with only an `evaluateAsync` handler works in
 * either position. Everything else — the error, `NaN` and absent-condition
 * verdicts, the element-wise selection, the hold of an undecided condition —
 * is `evaluateIf` on the evaluated condition, so the two cannot diverge.
 */
async function evaluateIfAsync(
  ops: ReadonlyArray<Expression>,
  options: Partial<EvaluateOptions> & { engine: ComputeEngine }
): Promise<Expression | undefined> {
  const [cond, ifTrue, ifFalse] = ops;
  const engine = options.engine;
  const evalOptions = {
    numericApproximation: options.numericApproximation,
    materialization: options.materialization,
    signal: options.signal,
    _effects: options._effects,
    _contextStack: options._contextStack,
    _precisionWindow: options._precisionWindow,
  };
  const evaluated =
    cond === undefined ? undefined : await cond.evaluateAsync(evalOptions);
  // The synchronous fallbacks below run after the `await` above, so the
  // arms they evaluate must be given this evaluation's host capability
  // registry and context stack explicitly (`runWithEvaluationEffects`).
  const fallback = (ops: ReadonlyArray<Expression>) =>
    options._effects === undefined
      ? evaluateIf(ops, options)
      : runWithEvaluationEffects(
          engine,
          options._effects,
          () => evaluateIf(ops, options),
          options._contextStack,
          options._precisionWindow
        );
  if (evaluated === undefined) return fallback(ops);
  const value = evaluateCondition(evaluated);
  if (errorValue(value) === undefined) {
    const decided = sym(value);
    if (decided === 'True')
      return ifTrue === undefined
        ? engine.Missing
        : ifTrue.evaluateAsync(evalOptions);
    if (decided === 'False')
      return ifFalse === undefined
        ? ifTrue === undefined || isStatementArm(ifTrue)
          ? engine.Missing
          : maskedValue(engine, ifTrue)
        : ifFalse.evaluateAsync(evalOptions);
  }
  return fallback([evaluated, ...ops.slice(1)]);
}

/**
 * The asynchronous twin of `evaluateWhich`: each guard is awaited through the
 * asynchronous route, in order, and a selected arm is awaited the same way;
 * a guard that is not a plain `True`/`False` hands the remaining clauses to
 * `evaluateWhich` with the evaluated guard in place, which owns every other
 * verdict.
 */
async function evaluateWhichAsync(
  args: ReadonlyArray<Expression>,
  options: Partial<EvaluateOptions> & { engine: ComputeEngine }
): Promise<Expression | undefined> {
  const engine = options.engine;
  const evalOptions = {
    numericApproximation: options.numericApproximation,
    materialization: options.materialization,
    signal: options.signal,
    _effects: options._effects,
    _contextStack: options._contextStack,
    _precisionWindow: options._precisionWindow,
  };
  // The synchronous fallbacks below run after an `await`, so the arms they
  // evaluate must be given this evaluation's host capability registry and
  // context stack explicitly (`runWithEvaluationEffects`).
  const fallback = (args: ReadonlyArray<Expression>) =>
    options._effects === undefined
      ? evaluateWhich(args, options)
      : runWithEvaluationEffects(
          engine,
          options._effects,
          () => evaluateWhich(args, options),
          options._contextStack,
          options._precisionWindow
        );
  let i = 0;
  while (i < args.length - 1) {
    const evaluated = await args[i].evaluateAsync(evalOptions);
    const value = evaluateCondition(evaluated);
    if (errorValue(value) !== undefined)
      return fallback([...args.slice(0, i), evaluated, ...args.slice(i + 1)]);
    const guard = sym(value);
    if (guard === 'True') {
      if (!args[i + 1]) return engine.Missing;
      return args[i + 1].evaluateAsync(evalOptions);
    }
    if (guard !== 'False')
      return fallback([...args.slice(0, i), evaluated, ...args.slice(i + 1)]);
    i += 2;
  }
  return fallback(args);
}

function evaluateWhich(
  args: ReadonlyArray<Expression>,
  options: Partial<EvaluateOptions> & { engine: ComputeEngine }
): Expression | undefined {
  let i = 0;
  while (i < args.length - 1) {
    // The guard is evaluated with the numeric request of the `Which`, as the
    // selected arm is (see `evaluateIf`).
    const evaluated = evaluateCondition(args[i], options.numericApproximation);
    // A guard `Which` reaches is DEMANDED, so an error in it propagates —
    // the same obligation `If` discharges for its condition (see the comment
    // there): a lazy operator owns propagation for what it demands, and an
    // error left to reach the typo throw below would escape as a host
    // exception rather than as a value.
    const condError = errorValue(evaluated);
    if (condError !== undefined) return condError;
    const cond = sym(evaluated);
    if (cond === 'True') {
      // A selected clause with no arm has no value to answer: `Missing`, the
      // position-preserving absent datum (no-selection ruling 2026-08-27).
      if (!args[i + 1]) return options.engine.Missing;
      return args[i + 1].evaluate(options);
    } else if (cond !== 'False') {
      // An absent guard (`Missing`) never reaches this point:
      // `evaluateCondition` reads it as `False`, and the next clause is
      // tried (`Which(Missing, 1, True, 2)` is `2`).
      // A LIST-VALUED condition selects element-wise (§3 of
      // `docs/BROADCAST-MODEL.md`). Every earlier
      // clause fell through (its condition was a scalar `False`),
      // so it can never select and the remaining clauses carry the whole
      // selection.
      const mask = conditionCells(evaluated);
      if (mask !== undefined) {
        const clauses: { cond: Expression; arm: Expression }[] = [];
        for (let k = i; k < args.length - 1; k += 2)
          clauses.push({ cond: args[k], arm: args[k + 1] });
        // The no-match cell is read from the types of ALL the reachable arms
        // of the `Which`, the arms of the clauses before this one included,
        // up to and including the first clause whose condition is a literal
        // `True` (the default clause). The type handler of `Which` and the
        // compiled selection read the same arms, so the three agree: with
        // `x := -1`, `Which(x > 0, "s", [True, False], 1)` is
        // `[1, Missing]`, because the string arm is not numeric.
        const reachableArmTypes: Type[] = [];
        for (let k = 0; k < args.length - 1; k += 2) {
          reachableArmTypes.push(args[k + 1].type.type);
          if (sym(args[k]) === 'True') break;
        }
        const evaluatedArms: Expression[] = [];
        const result = evaluateElementwiseSelection(
          options.engine,
          clauses,
          { cond: evaluated, mask },
          options,
          reachableArmTypes,
          evaluatedArms
        );
        if (result) return result;
        // A selection that cannot be made now (an arm whose elements cannot
        // be read) is held around the evaluated condition and the evaluated
        // arms.
        if (evaluatedArms.length > 0)
          return options.engine._fn('Which', [
            ...args.slice(0, i),
            evaluated,
            ...args
              .slice(i + 1)
              .map((x, k) => (k % 2 === 0 ? (evaluatedArms[k / 2] ?? x) : x)),
          ]);
      }
      // Every other condition leaves the WHOLE `Which` unevaluated: an
      // undecided boolean (`x = 4` with a free `x`, which stays symbolic under
      // evaluate()), and equally a condition that is not a boolean at all (a
      // number, a misspelled symbol, a list of numbers). Picking a later
      // branch would be wrong once the condition becomes decidable, and an
      // undecidable conditional is a symbolic expression rather than a program
      // defect — never a host exception. (User ruling 2026-08-31, shared with
      // the `If` handler so the two cannot diverge.)
      //
      // Rebuilt around the EVALUATED condition, arms and later clauses
      // untouched — same reason as `If`: `Which` is `lazy`, and returning
      // `undefined` would hand back the ORIGINAL node with the condition's
      // evaluation discarded (`Which(C = U[1], …)` kept `U[1]` where the
      // condition had read `10`; in a big-op loop it kept the index symbol
      // in place of the assigned value). The earlier clauses (already decided
      // `False`) are carried over AS WRITTEN: the held node stays
      // a faithful copy of the original conditional, so nothing is lost if the
      // undecided condition later resolves. Fixpoint-guarded with `isSame`.
      //
      // When the `Which` has a default clause (a literal `True` condition)
      // and every arm up to and including it is a list of one length, the
      // held `Which` is a list of `Which`s, one for each position
      // (`distributeOverListArms`). The clauses after the default clause
      // are never read, so they are dropped. Without a default clause the
      // `Which` is held whole: when no condition holds its value is
      // `Missing`, and a list of `Missing` cells is not that value.
      if (isScalarGuard(evaluated)) {
        let dflt = -1;
        for (let k = i + 2; k < args.length - 1; k += 2)
          if (sym(args[k]) === 'True') {
            dflt = k;
            break;
          }
        // A later guard that is a list of booleans (a mask) selects
        // element-wise once the guards before it are `False`, and the
        // distributed form would then select a whole list arm at each
        // position: every reachable guard must be a scalar boolean.
        if (
          dflt >= 0 &&
          args
            .slice(i + 2, dflt)
            .every((g, k) => k % 2 === 1 || isScalarGuard(g.canonical))
        ) {
          const clauses = [
            ...args.slice(0, i),
            evaluated,
            ...args.slice(i + 1, dflt + 2),
          ];
          const armAt = clauses.filter((_, k) => k % 2 === 1);
          const list = distributeOverListArms(options.engine, armAt, (arms) =>
            options.engine._fn(
              'Which',
              clauses.map((x, k) => (k % 2 === 1 ? arms[(k - 1) / 2] : x))
            )
          );
          if (list !== undefined) return list;
        }
      }
      return evaluated.isSame(args[i])
        ? undefined
        : options.engine._fn('Which', [
            ...args.slice(0, i),
            evaluated,
            ...args.slice(i + 1),
          ]);
    }
    // `False` — or `Missing`, treated as not-True — falls
    // through to the next clause.
    i += 2;
  }

  // No clause selected: `Missing`, the position-preserving absent datum
  // (no-selection ruling 2026-08-27, shared with the else-less `If`).
  return options.engine.Missing;
}

/** Evaluate a Block expression. */
function evaluateBlock(
  ops: ReadonlyArray<Expression>,
  {
    engine: ce,
    numericApproximation,
  }: Partial<EvaluateOptions> & { engine: ComputeEngine }
): Expression {
  if (ops.length === 0) return ce.Nothing;

  return lazyResultOverLocalValues(
    ce,
    resolveEscapingLambda(
      ce,
      evaluateStatements(
        ce,
        ops,
        numericApproximation ? { numericApproximation: true } : undefined,
        false
      )
    )
  );
}

/** The depth of nested lazy collections that `lazyResultOverLocalValues`
 * walks. */
const MAX_LAZY_RESULT_DEPTH = 16;

/**
 * The value `result` of a block, with each source of a lazy collection that
 * is a local of the block replaced by the value the local holds.
 *
 * An element-wise operation on a collection of more than
 * `MAX_SIZE_EAGER_COLLECTION` elements gives a lazy `Map` whose sources are
 * the operands as they are written: `x + y` with two locals that hold 120
 * elements is `Map((_1, _2) ↦ _1 + _2, x, y)`. A local has no value after
 * its block, so a collection that names one has no element outside the
 * block. The result names the values instead, as `Map(f, x)` written in
 * the block does: `Map((_1, _2) ↦ _1 + _2, Range(1, 120), Range(1, 120))`.
 *
 * Only a source is replaced: a symbol operand of a lazy collection, or of a
 * lazy collection that is its source, that reads a binding of the scope of
 * the block and whose value is a collection. A function literal keeps its
 * names, as a closure does, and a result that is not a lazy collection is
 * returned as it is.
 *
 * Must be called while the scope of the block is the current lexical
 * scope.
 */
function lazyResultOverLocalValues(
  ce: ComputeEngine,
  result: Expression,
  depth = 0
): Expression {
  // The value of a `Return` leaves the block inside the `Return`, which the
  // call of the function unwraps after the block has ended.
  if (isFunction(result, 'Return') && result.nops === 1) {
    const value = lazyResultOverLocalValues(ce, result.op1, depth);
    return value === result.op1 ? result : ce._fn('Return', [value]);
  }
  if (!isFunction(result) || !result.isLazyCollection) return result;
  if (result.operator === 'Function' || depth > MAX_LAZY_RESULT_DEPTH)
    return result;
  const locals = ce.context.lexicalScope.bindings;
  let changed = false;
  const ops = result.ops.map((op) => {
    let next = op;
    if (isSymbol(op)) {
      // The occurrence must read the local itself: a global of the same
      // name, read by a function that the block calls, is another binding.
      const binding = locals.get(op.symbol);
      if (
        binding === undefined ||
        !('value' in binding) ||
        !sameBindingDef(binding.value, op.valueDefinition)
      )
        return op;
      // A collection made in a call keeps the activation of that call
      // (`lazy-view-context.ts`); the value is read there, so a collection
      // that a recursive call returns does not take the value of this run.
      const value = inLazyViewContext(result, () => op.evaluate());
      if (value === op || value.isCollection !== true) return op;
      next = lazyResultOverLocalValues(ce, value, depth + 1);
    } else next = lazyResultOverLocalValues(ce, op, depth + 1);
    if (next !== op) changed = true;
    return next;
  });
  if (!changed) return result;
  const rebuilt = ce.function(result.operator, ops);
  carryLazyViewContexts(result, rebuilt);
  return rebuilt;
}

/**
 * The asynchronous twin of `evaluateBlock`: the statements awaited in order
 * (`evaluateStatementsAsync`), so a statement holding an asynchronous-only
 * application is evaluated instead of staying inert in the block's value.
 */
async function evaluateBlockAsync(
  ops: ReadonlyArray<Expression>,
  options: Partial<EvaluateOptions> & { engine: ComputeEngine }
): Promise<Expression> {
  const ce = options.engine;
  if (ops.length === 0) return ce.Nothing;
  // Read before the first `await`: the counts of running evaluations that
  // the test reads change while the statements run.
  const program = false;
  const result = await evaluateStatementsAsync(
    ce,
    ops,
    options.signal,
    options._effects,
    options._contextStack,
    // The numeric request reaches the last statement only, as in
    // `evaluateBlock`.
    options.numericApproximation ? true : undefined,
    options._precisionWindow,
    program
  );
  // `resolveEscapingLambda` and `lazyResultOverLocalValues` read the block
  // scope as the current lexical scope. They run after an `await`, so the
  // context stack of this evaluation (which holds the block scope) must be
  // put in place explicitly.
  const leave = (): Expression =>
    lazyResultOverLocalValues(ce, resolveEscapingLambda(ce, result));
  return options._effects === undefined
    ? leave()
    : runWithEvaluationEffects(
        ce,
        options._effects,
        leave,
        options._contextStack,
        options._precisionWindow
      );
}

/**
 *
 *  Canonicalize a Block expression
 *
 * - Hoist the target of each `Declare` statement to the top of the block
 *
 */


export function closedLiteralType(
  ce: ComputeEngine,
  value: Expression
): Type | undefined {
  const closed = (e: Expression): boolean =>
    isNumber(e) ||
    isString(e) ||
    ((isFunction(e, 'List') || isFunction(e, 'Tuple')) && e.ops.every(closed));
  if (!closed(value)) return undefined;
  const t = value.canonical.type;
  // Widened through the same table an assignment uses (`widenAssignedType`):
  // the literal `1` has the singleton type `1`, and a binding typed that
  // precisely would let a loop condition such as `i <= 3` fold to a constant
  // on the compile route; the assignment tier `integer` is the evidence the
  // program gives. A collection literal keeps its type (`list<never>` for
  // `[]`), which a later assignment joins with the assigned type.
  return t.isUnknown ? undefined : widenAssignedType(ce, t.type);
}

/**
 * The names that the `Declare` statements of the statement list `ops`
 * introduce, read without canonicalizing the statements, with the type of
 * each one when the statement states it.
 *
 * - `declaredNames`: the target of each `Declare`, and each leaf of a
 *   destructuring pattern (`let (a, b) = v`), in statement order. A name
 *   declared twice is listed twice.
 * - `declaredTypes`: the static type of a target, read from a positional
 *   type operand, from the literal `type` entry of an attributes dictionary,
 *   or from an initial value that is a closed literal (`closedLiteralType()`).
 * - `explicitlyDeclared`: the names of `declaredTypes` whose type the
 *   statement declares, not read from an initial value.
 *
 * `ops` may be non-canonical (the held operands of a `Block`, or the raw
 * statements of an Epsil program boxed with `{ canonical: false }`).
 * `canonicalBlock()` hoists these names into the block scope, and the Epsil
 * runner (`executeEpsil()`) declares the names of the statements before a
 * `function` statement before it installs the function.
 */
export function staticDeclarations(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  program = false
): {
  declaredNames: string[];
  declaredTypes: Map<string, Type>;
  explicitlyDeclared: Set<string>;
  declaredConstants: Set<string>;
} {
  const declaredNames: string[] = [];
  // The statically-readable declared type of each `Declare(name, "type")`
  // statement, keyed by name. The binding that `canonicalBlock()` hoists
  // carries this type from the CANONICAL pass on: `Declare` only registers
  // its type at
  // evaluation time, so without it a read of the local later in the block —
  // `Length(d)` after `Declare(d, "list<number>")` — types against a bare
  // `unknown` binding, and a compilation of the block (which never evaluates
  // the `Declare`) fails its operand type gates on a local whose type the
  // program states outright (Tycho item 235). Only a positional string or
  // symbol type operand is read; a computed type (an attributes dictionary,
  // a `TypeFrom(…)` expression) stays evaluation-time-only and the binding
  // stays `unknown`, as before.
  const declaredTypes = new Map<string, Type>();
  // The names in `declaredTypes` whose type is DECLARED, not read from a
  // literal initial value (see `markDeclaredLocal`).
  const explicitlyDeclared = new Set<string>();
  const declaredConstants = new Set<string>();
  for (const statement of ops) {
    const op = typedStatement(statement);
    if (isFunction(op, 'Declare')) {
      const attributes = op.ops[op.ops.length - 1];
      const constant = isDictionary(attributes) ? isSymbol(attributes.get('constant'), 'True') : isFunction(attributes, 'Dictionary') && attributes.ops.some((pair) => isFunction(pair, 'KeyValuePair') && (isString(pair.op1) ? pair.op1.string : sym(pair.op1)) === 'constant' && isSymbol(pair.op2, 'True'));
      const nameExpr = op.ops[0];
      // A destructuring `Declare((a, b), …)` (`let (a, b) = v`) introduces
      // each leaf of its pattern as a block local, as `Declare(a, …)` does
      // for `a`: the leaves are hoisted into the block scope and shadow a
      // same-named constant. Without this a leaf named `i` read later in
      // the block folded to the imaginary unit (`let (i, x) = (2, 3)` then
      // `i + 1` gave `1 + i`), and the `Declare` canonical handler found no
      // binding in the current scope to record the leaf's type on. The
      // pattern carries no type, so nothing else is read here.
      if (nameExpr && isFunction(nameExpr, 'Tuple')) {
        for (const name of tuplePatternNames(nameExpr))
          if (name !== 'Nothing') { declaredNames.push(name); if (constant) declaredConstants.add(name); }
        continue;
      }
      if (nameExpr && isSymbol(nameExpr)) {
        declaredNames.push(nameExpr.symbol);
        if (constant) declaredConstants.add(nameExpr.symbol);
        // The type may be the positional operand (`Declare(d, "list<…>")`)
        // or a literal `type` entry of an attributes dictionary
        // (`Declare(d, {type: "list<…>", value: …})`). The dictionary is
        // read STRUCTURALLY, from its raw key/value pairs — canonicalizing
        // it here would bind its value expressions in the enclosing scope,
        // before the block's own locals are hoisted (measured: it broke
        // `let doc = {name: …}`, whose Dictionary operand is data the
        // evaluate handler will bind later).
        let typeOp: Expression | undefined = op.ops[1];
        // The initial value, when the statement has one: the positional
        // operand after the type (`Declare(d, "list", [])`), or the literal
        // `value` entry of the attributes dictionary (`let d = []` in Epsil
        // is `Declare(d, {value: []})`).
        let valueOp: Expression | undefined = op.ops[2];
        if (typeOp !== undefined && typeOp.operator === 'Dictionary') {
          let entry: Expression | undefined = undefined;
          if (isFunction(typeOp)) {
            for (const pair of typeOp.ops) {
              if (!isFunction(pair) || pair.ops.length !== 2) continue;
              const key = isString(pair.ops[0])
                ? pair.ops[0].string
                : sym(pair.ops[0]);
              if (key === 'type') entry = pair.ops[1];
              else if (key === 'value') valueOp = pair.ops[1];
            }
          }
          typeOp = entry;
        }
        // The type `"unknown"` (`Declare(k, "unknown", v)`, the form of a
        // `where` binding and of a first `\coloneq`) states no type: the
        // type of the local comes from its value, as when no type is given.
        const source =
          typeOp === undefined
            ? undefined
            : isString(typeOp)
              ? typeOp.string
              : sym(typeOp);
        if (source !== undefined && source !== 'unknown') {
          try {
            const parsed = parseType(source, ce._typeResolver);
            // A type that names `missing` cannot be declared: the `Declare`
            // reports it when it runs.
            if (isValidType(parsed) && !declaredTypeNamesMissing(parsed)) {
              declaredTypes.set(nameExpr.symbol, parsed);
              explicitlyDeclared.add(nameExpr.symbol);
            }
          } catch {
            // Not a type expression (e.g. a mistyped name): leave the
            // binding `unknown`; the `Declare` evaluate handler reports the
            // error on the routes that run it.
          }
        } else if (valueOp !== undefined) {
          // No declared type, but an initial value that is a CLOSED literal
          // (a number, a string, or a `List`/`Tuple` of such, nested): its
          // type is static evidence of the same standing as a declared type,
          // so it rides on the hoisted binding too. Without it the binding
          // stays `unknown` until the `Declare` runs, and the FIRST use of
          // the local in the block — `Length(queue)` in a loop condition,
          // `ListJoin(xs, [4])` behind the spread `[...xs, 4]` — infers the
          // callee's loose parameter type (`collection`, `collection<any>`)
          // onto it; the later `Assign` can only WIDEN that, so `let xs = []`
          // grown by a spread read as a `collection<any>` on the compile
          // route, which never runs the `Declare`, and the JavaScript
          // target's array-shape gate refused `Length(xs)` (Tycho item 332,
          // programs b and c). With the value's type hoisted (`list<nothing>`
          // for `[]`), the use narrows to the list and the assignment widens
          // its element type (`list<integer>`), so the compiled shape is the
          // one the program builds. Only a closed literal is read: an
          // expression that mentions a symbol would have to be bound here,
          // in the enclosing scope, before the block's own locals exist.
          const literalType = program && isFunction(valueOp, 'Function') ? 'function' : closedLiteralType(ce, valueOp);
          if (literalType !== undefined)
            declaredTypes.set(nameExpr.symbol, literalType);
        }
      }
    }
  }
  return { declaredNames, declaredTypes, explicitlyDeclared, declaredConstants };
}

function canonicalBlock(
  ops: ReadonlyArray<Expression>,
  options: { engine: ComputeEngine; scope: Scope | undefined }
): Expression | null {
  return canonicalSequence(ops, options, false);
}

/** Shared binding and canonicalization of Block and Program statements. */
export function canonicalProgram(ops: ReadonlyArray<Expression>, options: { engine: ComputeEngine; scope?: Scope }): Expression {
  const ce = options.engine;
  const saved = ce._epsilBatchId;
  const batch = saved ?? nextProgramBatchId();
  ce._epsilBatchId = batch;
  try {
    const result = canonicalSequence(ops, { ...options, scope: ce.context.lexicalScope }, true);
    if (isFunction(result)) for (const statement of result.ops) PROGRAM_BATCHES.set(statement, batch);
    return result;
  } finally { ce._epsilBatchId = saved; }
}

const PROGRAM_INTERRUPTS = new WeakMap<object, { statements: readonly Expression[]; order: readonly number[]; index: number }>();
export function programInterruption(error: unknown) {
  return error !== null && typeof error === 'object' ? PROGRAM_INTERRUPTS.get(error) : undefined;
}
const PROGRAM_BATCHES = new WeakMap<Expression, number>();
const DECLARATION_REFUSAL_SITES = new WeakMap<Expression, readonly [number, number]>();
export function declarationRefusalSite(error: Expression | undefined): readonly [number, number] | undefined {
  return error !== undefined && isFunction(error, 'Error') ? DECLARATION_REFUSAL_SITES.get(error.op1) : undefined;
}
const PROGRAM_WRITES = new WeakMap<Expression, ReadonlyMap<string, BoxedDefinition>>();
export function programStatementWrites(statement: Expression): ReadonlyMap<string, BoxedDefinition> {
  return PROGRAM_WRITES.get(statement) ?? new Map();
}
const PROGRAM_SOURCE_ORDER = new WeakMap<Expression, readonly number[]>();
export function programSourceOrder(program: Expression): readonly number[] {
  return PROGRAM_SOURCE_ORDER.get(program) ?? (isFunction(program) ? program.ops.map((_, i) => i) : []);
}

function canonicalSequence(
  source: ReadonlyArray<Expression>,
  options: { engine: ComputeEngine; scope: Scope | undefined },
  program: boolean
): Expression {
  const { engine: ce, scope } = options;
  const order = source.map((_, i) => i);
  const functions = new Set(source.map((x) => typedStatement(x)).filter((x) => isFunctionDeclarationStatement(ce, x)).map((x) => isFunction(x) ? sym(x.op1)! : ''));
  const rank = (i: number): number => {
    const op = typedStatement(source[i]);
    if (['DeclareType', 'DeclareSumType', 'DeclareProtocol'].includes(op.operator)) return 0;
    if (isFunctionDeclarationStatement(ce, op)) return 2;
    if (isFunction(op, 'Declare') && functions.has(sym(op.op1) ?? '') && !declareHasValue(op.ops)) return 1;
    return 3;
  };
  if (program) order.sort((a, b) => rank(a) - rank(b) || a - b);
  const ops = order.map((i) => source[i]);
  const head = program ? 'Program' : 'Block';
  const previousBindings = new Map<string, BoxedDefinition>();
  const sourceIndex = new Map(source.map((statement, i) => [statement, i]));
  const constantIndexes = new Map<string, number>();
  let constantDeclarations: ReadonlySet<string> = new Set();
  const completed = new Map<Expression, Expression>();
  const early = new Map<Expression, Expression>();
  const canonicalizeStatement = (op: Expression): Expression => {
    const canonicalize = () => program && isFunction(op) && !op.isCanonical
      ? ce.function(op.operator, op.ops, { metadata: { sourceOffsets: op.sourceOffsets } })
      : canonicalStatement(ce, op);
  let statement: Expression;
  const savedRoute = ce._epsilDeclarationRoute;
  try {
    if (program) {
      checkDeadline(ce._deadlineFrame);
      ce._epsilDeclarationRoute = ['DeclareType', 'DeclareSumType', 'DeclareProtocol', 'DeclareConformance', 'DefineFunction'].includes(typedStatement(op).operator);
      const earlier = new Set([...constantIndexes].filter(([, index]) => index < (sourceIndex.get(op) ?? 0)).map(([name]) => name));
      statement = withEarlierConstantDeclarations(ce, constantDeclarations, earlier, () => withProgramInitializerOuters(previousBindings, () => withProgramStatement(() => withPairedFunctionNames(functions, canonicalize))));
    } else statement = canonicalize();
  } catch (error) {
    if (!program || error instanceof CancellationError) {
      if (program && error instanceof CancellationError) {
        const prefixOrder = order.filter((i) => completed.has(source[i]) || early.has(source[i]));
        PROGRAM_INTERRUPTS.set(error, { statements: prefixOrder.map((i) => completed.get(source[i]) ?? early.get(source[i])!), order: prefixOrder, index: source.indexOf(op) });
      }
      throw error;
    }
    statement = ce.error(error instanceof Error ? error.message : String(error));
  } finally { ce._epsilDeclarationRoute = savedRoute; }
    return statement;
  };
  if (program) for (const i of order) {
    if (rank(i) !== 0) break;
    early.set(source[i], canonicalizeStatement(source[i]));
  }
  // An empty block is canonical as it is: its type handler answers `nothing`
  // and its evaluate handler answers `Nothing`. Declining here (`null`) left
  // the node non-canonical and unbound, so neither handler ever ran and
  // `If(True, Block())` evaluated to the inert `Block()` itself, printed
  // `{}`, where the language documents `Nothing` as an empty block's value.
  if (ops.length === 0) return ce._fn(head, [], program ? undefined : { scope });
  // The text of the block, which the effects of a literal that calls one of
  // its locals read (`blockLocalLiteral()`, `effects-inference.ts`).
  if (!program && scope !== undefined) noteBlockStatements(scope, ops);

  // A `Declare(name, …)` introduces a block-local `name` that shadows any
  // same-named constant (`i`, `e`, `Pi`, …) for the rest of the block. Push
  // those names onto the engine's shadowed-parameter stack — the same
  // mechanism used for function-literal parameters — so that e.g.
  // `Add(i, 1)` after `Declare(i, …)` keeps `i` as an ordinary variable
  // instead of folding to the imaginary unit `1 + i`. The shadow is scoped to
  // this block: it is popped once the statements are canonicalized, so an `i`
  // outside the block is the imaginary unit again.

  // SAME-SCOPE RE-DECLARATION (ruled 2026-09-05): a `Declare` may not
  // re-declare a name this scope already binds — an earlier `Declare` of this
  // block, a parameter of the function literal whose body this block is, or
  // an index of the loop, comprehension or big operator whose body this block
  // is. Such a statement is a mistake in practice (a second `let` where an
  // assignment was meant), and the runtime cannot tell it from a re-run of
  // the same statement (a loop body on its second turn), so it silently
  // overwrote the binding. The statement canonicalizes to an error value
  // instead: the Epsil static pass reports it before the program runs, and
  // the compiler refuses the invalid block. Shadowing a name bound in an
  // OUTER scope — a nested block, a closure body, an `if` inside a loop body
  // — is ordinary lexical scoping and stays allowed.
  //
  // A function literal's parameters are known through the shadowed-parameter
  // stack: the literal pushes them before its body is canonicalized, with
  // the scope the literal is written in as the boundary, so this block is
  // the literal's own body exactly when its parent scope is that boundary. A
  // framework binder (`canonicalizeBinder`, `boxed-expression/box.ts`)
  // records its names on its own scope, which is the parent of its body
  // block's scope. A statement is accepted or refused WHOLE: a destructuring
  // `Declare((a, b), …)` with one colliding leaf declares nothing, so its
  // other leaves stay free for a later `Declare`. Only the names of accepted
  // statements are hoisted and shadowed below, so a read of a refused name
  // later in the block still reaches the binder's variable — while a name
  // whose FIRST declaration was accepted keeps its hoist even when a later
  // duplicate of it is refused.
  const refused = new Map<Expression, Expression>();
  const accepted = new Set<string>();
  const acceptedFunctions = new Set<string>();
  const acceptedDeclarations = new Set<string>();
  const pairedSignatures = new Set<string>();
  const firstDeclarations = new Map<string, Expression>();
  const accept = (name: string, statement: Expression): void => {
    accepted.add(name);
    if (!firstDeclarations.has(name)) firstDeclarations.set(name, statement);
  };
  const duplicate = (statement: Expression, name: string): void => {
    const error = ce.error(['variable-redeclaration', name]);
    const span = firstDeclarations.get(name)?.sourceOffsets;
    if (span !== undefined && isFunction(error, 'Error')) DECLARATION_REFUSAL_SITES.set(error.op1, span);
    refused.set(statement, error);
  };
  {
    const parentBinderNames = program ? undefined : scope?.parent?.binderNames;
    const redeclares = (name: string): boolean =>
      accepted.has(name) ||
      (!program && ce._isFunctionLiteralParameter(name) &&
        scope !== undefined &&
        ce._shadowedParameterBoundary(name) === scope.parent) ||
      parentBinderNames?.has(name) === true;
    // A function statement declares a local too (`localFunctionName()`).
    for (const statement of program ? source : ops) {
      const op = typedStatement(statement);
      const local = localFunctionName(ce, op);
      if (local !== undefined && program) {
        if (accepted.has(local) && !acceptedFunctions.has(local) && !pairedSignatures.has(local))
          duplicate(statement, local);
        else { accept(local, statement); acceptedFunctions.add(local); }
        continue;
      }
      if (local !== undefined) {
        if (redeclares(local))
          duplicate(statement, local);
        else accept(local, statement);
        continue;
      }
      if (!isFunction(op, 'Declare')) continue;
      const target = op.ops[0];
      const names = (
        isSymbol(target)
          ? [target.symbol]
          : isFunction(target, 'Tuple')
            ? tuplePatternNames(target)
            : []
      ).filter((name) => name !== 'Nothing');
      if (program && scope !== undefined) {
        try { for (const name of names) assertDeclarationName(ce, name, scope); }
        catch (error) {
          refused.set(statement, ce.error(error instanceof Error ? error.message : String(error)));
          continue;
        }
      }
      const pairsFunction = (name: string): boolean =>
        program && functions.has(name) && !declareHasValue(op.ops) &&
        acceptedFunctions.has(name) && !acceptedDeclarations.has(name);
      const collision = names.find((name) => redeclares(name) && !pairsFunction(name));
      if (collision !== undefined)
        duplicate(statement, collision);
      else for (const name of names) {
        accept(name, statement);
        acceptedDeclarations.add(name);
        if (program && functions.has(name) && !declareHasValue(op.ops)) pairedSignatures.add(name);
      }
    }
  }
  // Source-first admission decides which names are function statements;
  // a refused later function must not promote an earlier value declaration.
  if (program) {
    functions.clear();
    for (const name of acceptedFunctions) functions.add(name);
  }
  // Only accepted statements contribute declaration metadata. A refused
  // second declaration cannot change the first binding's type or constness.
  const acceptedStatements = ops.filter((statement) => !refused.has(statement));
  const { declaredNames, declaredTypes, explicitlyDeclared, declaredConstants } =
    staticDeclarations(ce, acceptedStatements, program);
  constantDeclarations = declaredConstants;
  if (program) for (const statement of acceptedStatements) {
    const op = typedStatement(statement);
    if (!isFunction(op, 'Declare')) continue;
    const target = op.op1;
    const names = isSymbol(target) ? [target.symbol] : isFunction(target, 'Tuple') ? tuplePatternNames(target) : [];
    for (const name of names)
      if (declaredConstants.has(name)) constantIndexes.set(name, sourceIndex.get(statement)!);
  }
  const hoistedNames = declaredNames.filter((name) => (program ? acceptedDeclarations : accepted).has(name));

  // Hoist the block's own locals into the block scope BEFORE canonicalizing
  // the statements. `Declare` only registers its symbol at *evaluation*
  // time, so without this a reference to a block-local from a
  // nested scope (an inner `Block`, an `If` branch inside a `Loop` body, …)
  // finds no binding during canonicalization and auto-declares a valueless
  // shadow in the *inner* scope — which then permanently hides the enclosing
  // block's runtime binding (the canonicalization-scope-vs-runtime-scope
  // defect: `Block(Declare(k), Assign(k, 7), Block(k))` evaluated to `k`).
  //
  // Only a `Declare` statement of the block introduces a block-local. An
  // `Assign` writes the binding that is in scope, and an `Assign` to a name
  // that no scope declares is an error (`isInBodyOrBranch()`).
  //
  // The hoisted binding is the static definition of the local: each run of
  // the block writes its value in the activation of the run. A
  // statically-readable declared type is the declared type of the binding;
  // it is what lets reads of the local later in the block, and the
  // compiler's operand type gates, see the type the program declared.
  // A name that cannot be bound (`UNBINDABLE_NAMES`: `Nothing`, `Missing`,
  // `Module`) is not hoisted: its `Declare` defines nothing, and a local of
  // that name would capture the later reads of the absence marker (a
  // `Missing` operand read as a local of the declared type) or the head of a
  // qualified name.
  const hoistDeclared = (scope: Scope, name: string): void => {
    if (UNBINDABLE_NAMES.has(name)) return;
    const existing = scope.bindings.get(name);
    if (existing !== undefined && !program) {
      markCallableHome(existing, scope);
      return;
    }
    if (program && existing !== undefined) previousBindings.set(name, existing);
    const knownType = declaredTypes.get(name);
    const persistentType = program && knownType !== undefined && !explicitlyDeclared.has(name) && !declaredConstants.has(name)
      ? widenLocalType(ce, knownType) : knownType;
    const hoisted = ce._declareSymbolValue(
      name,
      {
        type: persistentType ?? 'unknown',
        isConstant: program && declaredConstants.has(name),
        inferred: program && typeof knownType === 'string' && knownType !== 'unknown' ? false : !explicitlyDeclared.has(name),
      },
      scope
    );
    // A block local, not a free symbol: see `_blockLocal`.
    if (isValueDef(hoisted)) {
      hoisted.value._blockLocal = !program || !functions.has(name);
      if (program && !functions.has(name)) hoisted.value._programVariable = true;
      if (program && functions.has(name))
        (hoisted as typeof hoisted & { _declaredByStatement?: boolean })._declaredByStatement = true;
      markCallableHome(hoisted, scope);
      if (explicitlyDeclared.has(name)) markDeclaredLocal(hoisted.value);
    }
  };
  if (scope) {
    for (const name of hoistedNames)
      if (program || !scope.bindings.has(name)) hoistDeclared(scope, name);
    // A function statement of a block (`localFunctionName()`) makes a
    // local, as a `Declare` does: a variable whose type is the signature
    // that the statement writes (`writtenSignatureOf()`) and whose value, in
    // a run of the block, is the function value that the statement makes
    // when it runs.
    for (const statement of program ? [] : ops) {
      const name = localFunctionName(ce, typedStatement(statement));
      if (name === undefined || scope.bindings.has(name)) continue;
      if (refused.has(statement)) continue;
      const hoisted = ce._declareSymbolValue(
        name,
        {
          type: writtenSignatureOf(typedStatement(statement)),
          inferred: false,
        },
        scope
      );
      if (isValueDef(hoisted)) {
        hoisted.value._blockLocal = true;
        markCallableHome(hoisted, scope);
      }
    }
  }

  // The scope that encloses the block: the boundary of the shadow of its
  // names (`_shadowedParameterBoundary()`).
  ce._pushShadowedParameters(
    [...(program ? hoistedNames : accepted)].filter((name) => !UNBINDABLE_NAMES.has(name))
  );
  if (program && scope !== undefined) for (const name of hoistedNames) {
    const binding = scope.bindings.get(name);
    if (binding !== undefined) ce._setShadowedParameterDef(name, binding);
  }
  let statements: Expression[];
  enterBody();
  try {
    // We canonicalize the statements in the local scope. A refused
    // re-declaration stands as its error value.
    // The evidence session re-reads the value type of every assignment
    // canonicalized in this block (nested blocks included) once all of them
    // are canonicalized, so that a read in a loop body sees the widening a
    // later assignment of the same loop records (`withEvidenceSession`).
    statements = withEvidenceSession(ce, () =>
      ce._inScope(scope, () =>
        ops.map((op) => {
          const refusal = refused.get(op);
          if (refusal !== undefined && isFunction(refusal)) {
            const result = ce._fn(refusal.operator, refusal.ops, { metadata: { sourceOffsets: op.sourceOffsets } });
            completed.set(op, result);
            return result;
          }
          // A bare `N` or `D` statement is a value: when it still names the
          // library operator (no local of the block or parameter of the
          // literal binds it), it is a variable, as in `x + N`.
          // The repair runs here, once the scope of the block and its locals
          // exist, so that a local `N` stays the local.
          const statement = early.get(op) ?? canonicalizeStatement(op);
          if (program && (isFunction(statement, 'Declare') || isFunction(statement, 'Assign'))) {
            const names = isFunction(statement.op1, 'Tuple') ? tuplePatternNames(statement.op1) : isSymbol(statement.op1) ? [statement.op1.symbol] : [];
            const writes = new Map<string, BoxedDefinition>();
            for (const name of names) {
              const binding = ce.lookupDefinition(name);
              if (binding !== undefined) writes.set(name, binding);
            }
            PROGRAM_WRITES.set(statement, writes);
            if (isFunction(statement, 'Declare'))
              noteProgramDeclarationPrevious(statement.op1,
                new Map([...previousBindings].filter(([name]) => writes.has(name))));
          }
          const result = isSymbol(statement) ? canonicalValueOperand(ce, statement) : statement;
          completed.set(op, result);
          return result;
        })
      )
    );
  } finally {
    exitBody();
    ce._popShadowedParameters();
  }

  if (scope !== undefined)
    statements = withUseBeforeDeclarationErrors(ce, ops, statements, program);

  if (program) {
    for (const name of hoistedNames) {
      const binding = scope?.bindings.get(name);
      if (binding !== undefined && isValueDef(binding) && binding.value._programVariable) {
        if (!explicitlyDeclared.has(name) && !binding.value.isConstant && !binding.value.type.matches('function')) {
          const widened = widenLocalType(ce, binding.value.type.type);
          binding.value._setType(() => ce.type(widened));
        }
        binding.value.inferredType = false;
      }
    }
  }
  const result = ce._fn(head, statements, program ? undefined : { scope });
  if (program) PROGRAM_SOURCE_ORDER.set(result, order);
  return result;
}

/**
 * True when the operands `args` of a `Declare` (not canonical) give the
 * declared name a value: a positional value operand, which is not a
 * dictionary (`Declare(x, "integer", 5)`), or a `value` entry of an
 * attributes dictionary (`Declare(x, Dictionary(KeyValuePair("value", 5)))`,
 * the Epsil `let x = 5`). A dictionary that is not boxed yet is read from
 * its raw key and value pairs, without canonicalization; a boxed dictionary
 * (the MathJSON `{dict: {value: 5}}`) is read from its keys.
 */
export function declareHasValue(args: ReadonlyArray<Expression>): boolean {
  const hasValueEntry = (op: Expression): boolean => {
    if (isDictionary(op)) return op.get('value') !== undefined;
    return (
      isFunction(op, 'Dictionary') &&
      op.ops.some((pair) => {
        if (!isFunction(pair) || pair.ops.length !== 2) return false;
        const key = pair.ops[0];
        return isString(key) ? key.string === 'value' : sym(key) === 'value';
      })
    );
  };
  if (args.length >= 4) return true;
  if (args.length === 3)
    return (
      !(isFunction(args[2], 'Dictionary') || isDictionary(args[2])) ||
      hasValueEntry(args[2])
    );
  if (args.length === 2) return hasValueEntry(args[1]);
  return false;
}

/**
 * The name of the local that the statement `op` of a block declares when it
 * is a function statement (`isFunctionDeclarationStatement()`), or
 * `undefined`. The definition of the constructor of a declared type, or of
 * a function of the same name as an alias type, is not a local: types are
 * engine-global, and the definition reaches the binding of the type.
 */
function localFunctionName(
  ce: ComputeEngine,
  op: Expression
): string | undefined {
  if (!isFunction(op) || !isFunctionDeclarationStatement(ce, op))
    return undefined;
  const name = sym(op.ops[0])!;
  return ce._typeRegistry[name]?.def === undefined ? name : undefined;
}

/**
 * The type of the local that the function statement `op` declares: the
 * signature that its literal writes, when it writes a type. An unannotated
 * parameter is `unknown`, and so is an absent result type; nothing is read
 * from the body. A literal that writes no type, or that has a destructuring
 * parameter, which a signature does not state, gives `function`.
 */
function writtenSignatureOf(op: Expression): Type {
  const literal = isFunction(op) ? op.ops[1] : undefined;
  if (literal === undefined || !isFunction(literal, 'Function'))
    return 'function';
  const declared = functionLiteralDeclaredSignature(literal);
  if (declared !== undefined) return declared;
  const params = literal.ops.slice(1);
  const result = functionLiteralReturnType(literal);
  const types = params.map(functionLiteralParameterType);
  if (result === undefined && types.every((t) => t === undefined))
    return 'function';
  if (params.some(isDestructuringParameter)) return 'function';
  const rest = restParameterIndex(params);
  const fixed = rest < 0 ? params : params.slice(0, rest);
  const slots = fixed.map((p, i) => ({
    name: functionLiteralParameterName(p),
    type: types[i] ?? ('unknown' as Type),
  }));
  const required = requiredParameterCount(fixed);
  return {
    kind: 'signature',
    ...(required > 0 ? { args: slots.slice(0, required) } : {}),
    ...(required < slots.length ? { optArgs: slots.slice(required) } : {}),
    ...restParameterSignatureTail(params),
    result: result ?? 'unknown',
  };
}

/**
 * The canonical statements `statements` of the block with the scope
 * `scope`, where each statement that uses a local of the block before the
 * statement that declares it is replaced by the static error
 * `["Error", ["ErrorCode", "read-before-declaration", name]]`. `ops` are the
 * statements as they were before canonicalization, in the same order.
 *
 * A local of the block is a name that a `Declare` statement or a function
 * statement (`localFunctionName()`) declares. A use
 * is a read of the name, or an assignment to it, that runs when the
 * statement runs, in a statement before the declaration
 * (`do { a = k; let k = 2 }`). The value of a `Declare` reads the binding of
 * an enclosing scope (`let t = t * 2`), so it is not a use.
 *
 * A use in a function literal is not counted: it runs when the function is
 * called, which can be after the declaration. A use in a nested scope that
 * binds the same name (a nested block that declares it, a loop index) is a
 * use of that binding. The error carries the source range of the use, when
 * it has one, on its `ErrorCode` operand.
 *
 * This replaces the error value at run time: every local has its value
 * from the statement that declares it, so a program that passes this check
 * never reads a local with no value, except through a function that is
 * called before the declaration runs.
 */
function withUseBeforeDeclarationErrors(
  ce: ComputeEngine,
  ops: ReadonlyArray<Expression>,
  statements: Expression[],
  program = false
): Expression[] {
  // A block built again from statements that are canonical already (a
  // rebuild of a part of a canonical expression) was checked when the
  // statements were first canonicalized, in their own scope chain.
  if (ops.every((op) => op.isCanonical)) return statements;
  // The index of the statement that declares each local of the block.
  const declaredAt = new Map<string, number>();
  ops.forEach((raw, i) => {
    const op = typedStatement(raw);
    if (program && !isFunction(statements[i], 'Declare')) return;
    const local = localFunctionName(ce, op);
    if (!program && local !== undefined && !declaredAt.has(local)) declaredAt.set(local, i);
    if (!isFunction(op, 'Declare')) return;
    const names = isFunction(op.ops[0], 'Tuple')
      ? tuplePatternNames(op.ops[0])
      : [sym(op.ops[0])].filter((n): n is string => n !== undefined);
    for (const name of names)
      if (name !== 'Nothing' && !declaredAt.has(name)) declaredAt.set(name, i);
  });
  if (declaredAt.size === 0) return statements;
  const check = useBeforeDeclarationCheck(ce, declaredAt);
  return statements.map((statement, i) => {
    const error = check(statement, i);
    return error === undefined || !isFunction(error) ? statement : ce._fn(error.operator, error.ops, { metadata: { sourceOffsets: ops[i].sourceOffsets } });
  });
}


export function useBeforeDeclarationCheck(
  ce: ComputeEngine,
  declaredAt: ReadonlyMap<string, number>
): (statement: Expression, i: number) => Expression | undefined {
  // The nodes that `findUse()` walked with no use found, for each value of
  // `limit` and of `shadowed`. Such a node is not walked again: a value
  // built by sharing a node at each level (`Beta(t, t)`) has few distinct
  // nodes but a number of paths exponential in its depth.
  const walked = new Map<Expression, Set<string>>();
  const shadowKeys = new WeakMap<ReadonlySet<string>, string>();
  const shadowKey = (shadowed: ReadonlySet<string>): string => {
    let key = shadowKeys.get(shadowed);
    if (key === undefined) {
      key = [...shadowed].sort().join(',');
      shadowKeys.set(shadowed, key);
    }
    return key;
  };
  // The first use, in the canonical expression `e`, of a local whose
  // declaration is at an index greater than `limit`, or `undefined`.
  const findUse = (
    e: Expression,
    limit: number,
    shadowed: ReadonlySet<string>
  ): { name: string; site: [number, number] | undefined } | undefined => {
    if (isSymbol(e)) {
      const at = declaredAt.get(e.symbol);
      if (at !== undefined && at > limit && !shadowed.has(e.symbol))
        return { name: e.symbol, site: e.sourceOffsets };
      return undefined;
    }
    if (isDictionary(e)) {
      for (const value of e.values) {
        const found = findUse(value, limit, shadowed);
        if (found !== undefined) return found;
      }
      return undefined;
    }
    // The operand of `Hold` is quoted: it is not evaluated, so a symbol in
    // it is not a read of the local.
    if (!isFunction(e) || e.operator === 'Function' || e.operator === 'Hold')
      return undefined;
    const visitKey = `${limit}|${shadowKey(shadowed)}`;
    let visits = walked.get(e);
    if (visits?.has(visitKey)) return undefined;
    // A call of a local (`h(1)`) is a use of the local.
    const calledAt = declaredAt.get(e.operator);
    if (calledAt !== undefined && calledAt > limit && !shadowed.has(e.operator))
      return { name: e.operator, site: e.sourceOffsets };
    let inner = shadowed;
    const bindings = e.localScope?.bindings;
    if (bindings !== undefined) {
      const names = [...declaredAt.keys()].filter((n) => bindings.has(n));
      if (names.length > 0) inner = new Set([...shadowed, ...names]);
    }
    for (const op of e.ops) {
      const found = findUse(op, limit, inner);
      if (found !== undefined) return found;
    }
    if (visits === undefined) walked.set(e, (visits = new Set()));
    visits.add(visitKey);
    return undefined;
  };

  const none: ReadonlySet<string> = new Set();
  return (statement, i) => {
    if (!statement.isValid) return undefined;
    const found = findUse(statement, i, none);
    if (found === undefined) return undefined;
    const code = ce.function(
      'ErrorCode',
      [ce.string('read-before-declaration'), ce.string(found.name)],
      found.site === undefined
        ? undefined
        : { metadata: { sourceOffsets: found.site } }
    );
    return ce.function('Error', [code]);
  };
}

/**
 * The first name that the raw guard or body `part` of a case of a `Match`
 * assigns and that no scope declares, or `undefined`.
 *
 * Such an assignment is an assignment to an undeclared variable, which is a
 * static error. A name is declared when a scope of the scope chain declares it,
 * when it is a parameter of an enclosing function literal, when it is a
 * capture of the pattern of the case (`captures`), or when a `Declare` in
 * `part` declares it (a `let` local of the case). The body of a function
 * literal in `part` is not read: the boxing of that body checks its own
 * assignments.
 */
function firstAssignmentInCase(
  ce: ComputeEngine,
  part: Expression,
  captures: ReadonlySet<string>
): string | undefined {
  const declared = new Set<string>();
  const assigned: string[] = [];
  const targetNames = (target: Expression): string[] =>
    isFunction(target, 'Tuple')
      ? tuplePatternNames(target)
      : isSymbol(target)
        ? [target.symbol]
        : [];
  const walk = (e: Expression): void => {
    if (!isFunction(e) || e.operator === 'Function') return;
    if (e.operator === 'Declare' && e.nops > 0)
      for (const name of targetNames(e.ops[0])) declared.add(name);
    if (e.operator === 'Assign' && e.nops > 0)
      assigned.push(...targetNames(e.ops[0]));
    for (const op of e.ops) walk(op);
  };
  walk(part);
  return assigned.find(
    (name) =>
      name !== 'Nothing' &&
      name !== '_' &&
      !captures.has(name) &&
      !declared.has(name) &&
      !isDeclaredForAssignment(ce, name) &&
      !ce._isShadowedParameter(name)
  );
}

/**
 * True when `name` has a binding that an assignment writes: a binding that
 * `lookupDefinition()` finds.
 */
export function isDeclaredForAssignment(
  ce: ComputeEngine,
  name: string
): boolean {
  return ce.lookupDefinition(name) !== undefined;
}

/**
 * The first `assignment-type-mismatch` error in the canonical expression
 * `e` (`localAssignmentMismatch()`, `library/core.ts`), or `undefined`.
 */
function assignmentTypeMismatchIn(
  e: Expression | undefined
): Expression | undefined {
  if (e === undefined || !isFunction(e)) return undefined;
  if (e.operator === 'Error') {
    const code = e.op1;
    return isFunction(code, 'ErrorCode') &&
      isString(code.op1) &&
      code.op1.string === 'assignment-type-mismatch'
      ? e
      : undefined;
  }
  for (const op of e.ops) {
    const found = assignmentTypeMismatchIn(op);
    if (found !== undefined) return found;
  }
  return undefined;
}

/** Whether the raw expression `e` has an `Assign` at any depth. */
function containsAssignment(e: Expression): boolean {
  if (!isFunction(e)) return false;
  return e.operator === 'Assign' || e.ops.some(containsAssignment);
}

/**
 * The names that cannot be bound: a definition of one of them installs
 * nothing and evaluates to the `absence-marker-binding` error (`Nothing`,
 * `Missing`) or the `module-binding` error (`Module`). The same names as
 * `ABSENCE_MARKERS` and `MODULE_OPERATOR` in `library/core.ts`, which imports
 * this file and so cannot be imported here.
 */
const UNBINDABLE_NAMES: ReadonlySet<string> = new Set([
  'Nothing',
  'Missing',
  'Module',
]);

/**
 * True when the statement `statement` is a function declaration of its
 * statement list: a `DefineFunction(name, Function(…))` (the Epsil
 * `function g(k) { … }` and `g(k) = …`), where
 *
 * - `name` is a symbol and is not an absence marker (`Nothing`, `Missing`)
 *   or `Module`, whose definition installs nothing;
 * - the second operand is a `Function` literal, the only clause that the
 *   `DefineFunction` canonical handler installs;
 * - `name` is not the constructor of a declared nominal type: such a
 *   definition is a smart-constructor definition, an assignment to the
 *   constructor of the type (`defineFunctionClause()`, `multi-clause.ts`),
 *   and takes effect when it runs. The same-name function of an ALIAS type
 *   is an ordinary function and is accepted.
 *
 * An assignment of a function literal (`g = (k) => …`) is not a function
 * declaration: it takes effect when it runs.
 *
 * A generic definition is a function declaration in this sense. The
 * compiler moves it to the front of the statement list as it moves the
 * others (`withDefineFunctionDeclares()`, `base-compiler.ts`), and the hoist
 * of function names in `canonicalBlock()` makes its name a local of the
 * block. But the interpreter installs it only when its statement runs
 * (`isHoistedFunctionDefinition()`).
 *
 * The statement is read structurally, so it may be non-canonical (the held
 * operands of a `Block`, a raw Epsil statement boxed with
 * `{ canonical: false }`).
 */
export function isFunctionDeclarationStatement(
  ce: ComputeEngine,
  statement: Expression
): boolean {
  if (!isFunction(statement, 'DefineFunction')) return false;
  const name = sym(statement.ops[0]);
  if (name === undefined || UNBINDABLE_NAMES.has(name)) return false;
  if (!isFunction(statement.ops[1], 'Function')) return false;
  const type = ce._typeRegistry[name];
  return type?.def === undefined || type.alias === true;
}


export function isHoistedFunctionDefinition(
  ce: ComputeEngine,
  statement: Expression
): boolean {
  return (
    isFunctionDeclarationStatement(ce, statement) &&
    isFunction(statement, 'DefineFunction') &&
    !isGenericDefinition(ce, sym(statement.ops[0])!, statement.ops[1])
  );
}

/**
 * True when the definition of `name` by the `Function` literal `literal`
 * is one that the `DefineFunction` canonical handler (`library/core.ts`)
 * does not install at canonicalization, for the same three reasons, read
 * here without canonicalizing the literal:
 *
 * - the literal states its own generic signature (a return marker whose
 *   signature has a `where` clause, `function f<T>(x: T) -> T { x }`), which
 *   the handler reads as `isGenericClauseLiteral()` on the canonical
 *   literal;
 * - the definition that `name` resolves to is generic, or declares a generic
 *   signature (`isGenericTarget()`, `multi-clause.ts`);
 * - the handler skipped an earlier clause of that definition
 *   (`canonInstallSkipped()`, `clause-identity.ts`), and so skips the other
 *   clauses too.
 */
function isGenericDefinition(
  ce: ComputeEngine,
  name: string,
  literal: Expression
): boolean {
  const declared = functionLiteralDeclaredSignature(literal);
  if (declared !== undefined && isPolymorphicType(declared)) return true;
  const target = ce.lookupDefinition(name);
  return isGenericTarget(target) || canonInstallSkipped(target);
}

/**
 * The canonical form of `op`, a branch of an `If` or a value of a `Which`,
 * canonicalized as a branch (`canonicalBranch()`). The value of the branch
 * is the value of the conditional, so a bare `N` or `D` that still names the
 * library operator is a variable there, as in `x + N`
 * (`canonicalValueOperand()`). With `statement` false, a bare `Break` is not
 * refused, as for `canonicalBranch()`.
 */
function canonicalArm(
  ce: ComputeEngine,
  op: Expression,
  statement = true
): Expression {
  const arm = canonicalBranch(ce, op, statement);
  return isSymbol(arm) ? canonicalValueOperand(ce, arm) : arm;
}

/**
 * True when a `Loop` body can short-circuit with a value — it structurally
 * contains a `Return`, or a `Break` carrying an operand. Used by the `Loop`
 * type handler: a for-effect loop is otherwise `nothing`.
 */
function loopBodyYieldsValue(structure: OperandStructure | undefined): boolean {
  if (structure === undefined) return false;
  switch (structure.kind) {
    case 'application':
      if (structure.head === 'Return') return true;
      if (structure.head === 'Break' && structure.children.length > 0)
        return true;
      return structure.children.some((c) =>
        loopBodyYieldsValue(c.structureOf?.())
      );
    // A `Tuple` and a `List` literal are applications of `Tuple`/`List` in
    // the expression tree, so their elements are searched too — neither head
    // is a short-circuit, only their contents can be.
    case 'tuple':
    case 'list-literal':
      return structure.elements.some((c) =>
        loopBodyYieldsValue(c.structureOf?.())
      );
    // A nested function literal's parameters are bare symbols, so only its
    // body can carry a short-circuit.
    case 'function-literal':
      return loopBodyYieldsValue(structure.body);
    default:
      return false;
  }
}

/**
 * The type of the body of a `Comprehension` as the element type of the list
 * it returns, without the bounds that a ranged index (`integer<1..16>`)
 * gives it: `[k² for k in 1..5]` is `list<integer<0..>>`, the type of the
 * square of an integer, not `list<integer<1..25>>`, and
 * `[√((k − 0.5)/16) for k in 1..16]` is `list<real>`.
 *
 * Two types are computed: the body type with its numeric ranges removed
 * (`stripNumericRanges`), and the body type derived again with each ranged
 * index typed without its range (`integer`). The second is used when it is
 * a subtype of the first, the first otherwise.
 *
 * Each node of the body that reads such an index is derived again from its
 * operands, through the type handler of its operator (`context.derive`).
 * When a node cannot be derived again (an operator with no type handler and
 * no signature), the numeric ranges are removed from the body type
 * instead (`stripNumericRanges`).
 *
 * A symbol is typed again only where it names the index of this
 * comprehension. A nested binder can bind the same name: in
 * `[[k for k in [0.5, 1.5]] for k in 1..16]` the inner `k` is a real, and
 * typing it `integer` would give `list<list<integer>>`. So the names that a
 * nested binder binds are removed from the substitution in the operands
 * where its binding is visible (see {@link LOOP_LIKE_BINDERS}).
 *
 * The derived descriptor of each node is kept for each set of names that
 * are still substituted. The body is a graph: `List(t, t)` holds the same
 * operand twice, and a body built from 24 such levels has 25 nodes but
 * 2^24 paths from the root. Without the memo, the derivation would visit
 * each path.
 */
function bodyTypeWithoutIndexRanges(
  body: OperandDescriptor,
  clauses: ReadonlyArray<OperandDescriptor>,
  context: TypeHandlerContext
): Type {
  const unranged = new Map<string, Type>();
  for (const clause of clauses) {
    const structure = clause.structureOf?.();
    if (structure?.kind !== 'application' || structure.head !== 'Element')
      continue;
    const index = structure.children[0];
    const indexStructure = index?.structureOf?.();
    if (indexStructure?.kind !== 'symbol') continue;
    const stripped = stripNumericRanges(index.type);
    if (stripped !== index.type) unranged.set(indexStructure.name, stripped);
  }
  if (unranged.size === 0) return body.type;
  let failed = false;

  // The names that are still substituted, with the key of that set of
  // names. A name is only ever removed from the substitution, and its type
  // is the same in every substitution, so the names alone identify it.
  type Substitution = {
    readonly types: ReadonlyMap<string, Type>;
    readonly key: string;
  };
  const substitutions = new Map<string, Substitution>();
  const substitutionOf = (types: ReadonlyMap<string, Type>): Substitution => {
    const key = [...types.keys()].sort().join('\u0000');
    let s = substitutions.get(key);
    if (s === undefined) {
      s = { types, key };
      substitutions.set(key, s);
    }
    return s;
  };
  const without = (
    s: Substitution,
    names: ReadonlySet<string>
  ): Substitution => {
    let types: Map<string, Type> | undefined;
    for (const name of names) {
      if (!s.types.has(name)) continue;
      types ??= new Map(s.types);
      types.delete(name);
    }
    return types === undefined ? s : substitutionOf(types);
  };

  // One memo for each substitution, keyed by the input descriptor.
  const memo = new Map<string, Map<OperandDescriptor, OperandDescriptor>>();
  const derive = (d: OperandDescriptor, s: Substitution): OperandDescriptor => {
    if (failed || s.types.size === 0) return d;
    let derivedIn = memo.get(s.key);
    if (derivedIn === undefined) {
      derivedIn = new Map();
      memo.set(s.key, derivedIn);
    }
    const cached = derivedIn.get(d);
    if (cached !== undefined) return cached;
    const result = deriveNode(d, s);
    derivedIn.set(d, result);
    return result;
  };

  const deriveNode = (
    d: OperandDescriptor,
    s: Substitution
  ): OperandDescriptor => {
    const structure = d.structureOf?.();
    if (structure === undefined) return d;
    if (structure.kind === 'symbol') {
      const t = s.types.get(structure.name);
      return t === undefined ? d : describeBoundSymbol(t, structure.name);
    }
    const operands = operandsOf(structure);
    if (operands === undefined) return d;
    const head = headOf(structure);
    if (LOOP_LIKE_BINDERS.has(head))
      return rebuild(d, structure, operands, deriveBinderOperands(operands, s));
    // Any other operator that binds names (a `Block`, a quantifier,
    // `NDSolveFunction`) is not typed again: the names it binds are not
    // read from its operand descriptors here, and a substitution into its
    // operands could replace a symbol that it binds.
    if (context.engine.lookupDefinition(head)?.operator?.scoped === true)
      return d;
    return rebuild(
      d,
      structure,
      operands,
      operands.map((x) => derive(x, s))
    );
  };

  // The operands of a binder in `LOOP_LIKE_BINDERS`. Operand 0 is the body,
  // which is inside every clause: each name that a clause binds is removed
  // from the substitution there. A clause sees the names of the clauses
  // BEFORE it ("later clauses see earlier bindings"), not its own: in
  // `Element(k, Range(1, k))`, the `k` of the range is the enclosing `k`.
  // Its index position is not substituted.
  const deriveBinderOperands = (
    operands: ReadonlyArray<OperandDescriptor>,
    s: Substitution
  ): OperandDescriptor[] => {
    const bound = operands.map((x, i) =>
      i === 0 ? new Set<string>() : clauseBoundNames(x)
    );
    const all = new Set<string>();
    for (const names of bound) for (const name of names) all.add(name);
    const result: OperandDescriptor[] = [derive(operands[0], without(s, all))];
    const before = new Set<string>();
    for (let i = 1; i < operands.length; i++) {
      const visible = without(s, before);
      result.push(
        deriveClause(operands[i], visible, without(visible, bound[i]))
      );
      for (const name of bound[i]) before.add(name);
    }
    return result;
  };

  // A clause: its first operand (the index, or the index pattern) is
  // derived with `own`, which does not substitute the names the clause
  // binds, and its other operands (the collection, the bounds) with
  // `visible`.
  const deriveClause = (
    d: OperandDescriptor,
    visible: Substitution,
    own: Substitution
  ): OperandDescriptor => {
    const structure = d.structureOf?.();
    const operands =
      structure === undefined ? undefined : operandsOf(structure);
    if (
      structure === undefined ||
      operands === undefined ||
      operands.length === 0
    )
      return derive(d, own);
    return rebuild(
      d,
      structure,
      operands,
      operands.map((x, i) => derive(x, i === 0 ? own : visible))
    );
  };

  const rebuild = (
    d: OperandDescriptor,
    structure: OperandStructure,
    operands: ReadonlyArray<OperandDescriptor>,
    derived: ReadonlyArray<OperandDescriptor>
  ): OperandDescriptor => {
    if (derived.every((x, i) => x === operands[i])) return d;
    const head = headOf(structure);
    const t = deriveApplicationOf(
      {
        head,
        callee: structure.kind === 'application' ? structure.callee : undefined,
      },
      derived,
      context
    );
    if (t === undefined) {
      failed = true;
      return d;
    }
    let rebuilt: OperandStructure | undefined;
    return {
      type: t,
      facts: describeBoundSymbol(t).facts,
      structureOf: () =>
        (rebuilt ??=
          structure.kind === 'application'
            ? { ...structure, children: derived }
            : structure.kind === 'tuple'
              ? { kind: 'tuple', arity: derived.length, elements: derived }
              : structure.kind === 'list-literal'
                ? { ...structure, elements: derived }
                : structure),
    };
  };

  const stripped = stripNumericRanges(body.type);
  const result = derive(body, substitutionOf(unranged));
  // Both types contain every value of the body. The derived one is kept
  // when it is the narrower: it has the sign of `k²`, which the stripped
  // type does not. The stripped one is kept otherwise: `√((k − 0.5)/16)`
  // derived over a plain `integer` index is `complex`, while the body,
  // over its ranged index, is `real`.
  if (failed || !isSubtype(result.type, stripped)) return stripped;
  return result.type;
}

/**
 * The operators whose operand 0 is a body and whose other operands are
 * clauses that can bind names: an `Element`, `Limits`, `Tuple`, `Triple`,
 * `Pair`, `Single` or `Set` clause binds the symbol (or the symbols of the
 * tuple pattern) in its first operand, and a bare symbol operand
 * (`Sum(body, n, 1, 10)`, `D(f, x)`) binds that symbol. These are the
 * operators whose `operands` handler gives the operands after the body the
 * role `clause` or `bound` (`operandRoleSites()`,
 * `boxed-expression/binding-sites.ts`).
 *
 * The names read here can include more than the operator binds: a symbol
 * bound of the flat spelling (`b` in `Integrate(f, x, 0, b)`), or the second
 * operand of `Series`. Such a name is then not typed again in the body, and
 * keeps its ranged type there. That type is narrower, but it is correct.
 */
const LOOP_LIKE_BINDERS: ReadonlySet<string> = new Set([
  'Comprehension',
  'Loop',
  'ParallelComprehension',
  'ParallelLoop',
  'Sum',
  'Product',
  'Integrate',
  'CircularIntegrate',
  'ContourIntegrate',
  'D',
  'Series',
]);

/** The clauses that carry their index in their first operand. */
const INDEX_CLAUSE_HEADS: ReadonlySet<string> = new Set([
  'Element',
  'Limits',
  'Tuple',
  'Triple',
  'Pair',
  'Single',
  'Set',
]);

/** The head a structure is derived with by `context.derive`. */
function headOf(structure: OperandStructure): string {
  if (structure.kind === 'application') return structure.head;
  if (structure.kind === 'tuple') return 'Tuple';
  return 'List';
}

/** The operands of a structure that `context.derive` can derive again, or
 * `undefined` for a leaf or a function literal. */
function operandsOf(
  structure: OperandStructure
): ReadonlyArray<OperandDescriptor> | undefined {
  if (structure.kind === 'application') return structure.children;
  if (structure.kind === 'tuple' || structure.kind === 'list-literal')
    return structure.elements;
  return undefined;
}

/** The names that a clause of a binder in `LOOP_LIKE_BINDERS` binds. */
function clauseBoundNames(clause: OperandDescriptor): Set<string> {
  const names = new Set<string>();
  const structure = clause.structureOf?.();
  if (structure === undefined) return names;
  if (structure.kind === 'symbol' || isHoldStructure(structure)) {
    patternBoundNames(clause, names);
    return names;
  }
  if (INDEX_CLAUSE_HEADS.has(headOf(structure))) {
    const index = operandsOf(structure)?.[0];
    if (index !== undefined) patternBoundNames(index, names);
  }
  return names;
}

function isHoldStructure(structure: OperandStructure): boolean {
  return (
    structure.kind === 'application' &&
    structure.head === 'Hold' &&
    structure.children.length === 1
  );
}

/** The symbols of an index: a symbol, a held symbol, or the leaves of a
 * tuple pattern (`Element(Tuple(p, q), pairs)`). */
function patternBoundNames(d: OperandDescriptor, names: Set<string>): void {
  const structure = d.structureOf?.();
  if (structure === undefined) return;
  if (structure.kind === 'symbol') names.add(structure.name);
  else if (structure.kind === 'tuple')
    for (const x of structure.elements) patternBoundNames(x, names);
  else if (isHoldStructure(structure) && structure.kind === 'application')
    patternBoundNames(structure.children[0], names);
}

/**
 * Canonicalize a `Loop` or `Comprehension` expression. Both share the same
 * variadic `Element`-clause scope hygiene:
 *
 * - Push a fresh scope with `noAutoDeclare = true`, declare each Element's
 *   index variable in that scope, and canonicalize each clause + body inside
 *   the scope. Mirrors `canonicalBigop` so that free variables in the body
 *   and collection expressions are auto-declared in the enclosing scope, not
 *   leaking the iteration variable names.
 *
 * - A `Loop(body)` with no clauses is a valid bare (infinite) imperative loop;
 *   a `Comprehension(body)` with no clauses is invalid (`null`).
 *
 * - An iterator operand that is not an `Element` clause is not silently passed
 *   through (it would otherwise be ignored at runtime, producing a spurious
 *   infinite loop): it is replaced with an error expression so the whole
 *   expression is visibly invalid.
 */
function canonicalLoopLike(
  head: 'Loop' | 'Comprehension' | 'ParallelLoop' | 'ParallelComprehension',
  ops: ReadonlyArray<Expression>,
  options: { engine: ComputeEngine; scope: Scope | undefined }
): Expression | null {
  const { engine: ce, scope } = options;
  if (ops.length === 0) return null;

  const body = ops[0];
  const iterators = ops.slice(1);

  if (iterators.length === 0) {
    // Bare form. `Loop(body)` is a valid infinite imperative loop;
    // `Comprehension(body)` needs at least one Element clause.
    // The parallel heads need a clause too: their passes are the elements
    // of the first clause.
    if (head !== 'Loop') return null;
    return ce._fn('Loop', [canonicalBranch(ce, body)]);
  }

  // Variadic Element form: bound names must not leak. The scope, its
  // `noAutoDeclare` flag, the push/pop around this handler and the declaration
  // of each Element index come from the binder hook in `box.ts` (the
  // `clause` role of operands 1..n) — this used to be an independent copy of
  // `canonicalBigop`'s prologue. A defensive fallback for a caller that did
  // not come through the hook.
  const loopScope: Scope = scope ?? {
    parent: ce.context.lexicalScope,
    bindings: new Map(),
  };

  // Canonicalize each Element clause in order. Earlier clauses declare their
  // index in `loopScope` before later clauses are canonicalized — so a later
  // collection expression referencing an earlier name binds to the loop-scoped
  // symbol rather than triggering auto-declaration in the enclosing scope.
  const canonicalIterators: Expression[] = iterators.map((it) => {
    if (!isFunction(it, 'Element')) {
      // Not an Element clause — flag as invalid rather than passing it
      // through (which would be ignored at runtime → infinite loop).
      return ce.error('unexpected-argument', it.toString());
    }
    const indexExpr = it.ops[0];
    const collExpr = it.ops[1];
    if (!indexExpr || !collExpr) {
      return ce._fn('Element', [
        (indexExpr ?? ce.error('missing')).canonical,
        (collExpr ?? ce.error('missing')).canonical,
      ]);
    }
    if (isSymbol(indexExpr) && indexExpr.symbol !== 'Nothing') {
      if (!ce.context.lexicalScope.bindings.has(indexExpr.symbol))
        ce.declare(indexExpr.symbol, 'unknown');
    }
    // A DESTRUCTURING loop variable — `for (p, q) in pairs { … }` — declares
    // one binding per pattern leaf, so the body's occurrences bind to this
    // loop's scope rather than auto-declaring in the enclosing one.
    if (isFunction(indexExpr, 'Tuple')) {
      for (const name of tuplePatternNames(indexExpr))
        if (!ce.context.lexicalScope.bindings.has(name))
          ce.declare(name, 'unknown');
    }
    const collCanonical = collExpr.canonical;
    // These clauses are rebuilt with `_fn`, which bypasses the `Element`
    // canonical handler — so nothing narrows the iterated operand. Yet
    // iterating over a not-yet-typed symbol is collection evidence in the same
    // way `Length(x)` or `x[i]` is: narrow it, so a function parameter whose
    // only use is `for c in cs` types as a collection (and the lambda
    // auto-broadcast then binds a collection argument whole instead of mapping
    // over it).
    // The guard reads an EFFECTIVE type, so it runs fact-blind together with
    // the write it gates: an assumption that gives the operand a type would
    // otherwise decide whether this contract-bearing narrowing happens at all.
    ce._withoutFacts(() => {
      if (
        isSymbol(collCanonical) &&
        hasInferredType(collCanonical) &&
        isUntypedAtCollectionSlot(collCanonical)
      )
        collCanonical._infer(() => 'collection', 'narrow');
    });
    // …and nothing typed the INDEX, either (the same bypass): the binder
    // hook declares each index `unknown`, and the body's arithmetic use
    // then widened it to `number` — so `for i in 1..3` typed `10 * i` as
    // `number`, wide enough to falsely refuse an `integer`-declared
    // protocol-property write. Narrow the fresh binding to the collection's
    // ELEMENT type when it is known, BEFORE the body canonicalizes against
    // it (the `Element` canonical handler's own inference, sets.ts, which
    // this `_fn` rebuild bypasses). `._infer()` accepts an explicit-`unknown`
    // binding and carries the machinery a raw `def.type` write skips (the
    // resolve-only guard, the inference state event, the same-type no-op
    // that preserves `BoxedType` identity). The collection type is resolved
    // first so an ALIAS (`type ints = list<integer>`) contributes its
    // element type too.
    // A destructuring pattern stays RAW, exactly as the `Declare`/`Assign`
    // destructuring targets do: canonicalizing it would fold a single-letter
    // leaf into the library constant of that name (`i` → `ImaginaryUnit`).
    //
    // A plain index is the binding THIS scope holds for the name. A clause
    // that is already canonical (a loop rebuilt from its canonical operands)
    // keeps its index bound to the ORIGINAL loop's scope: narrowing that
    // symbol left this scope's index `unknown`, so the body typed `10i` as
    // `number`, and the clause and the body denoted two different bindings
    // of one index (`canonicalIndexingSet`, `library/utils.ts`, does the same
    // for a `Sum`).
    const canonicalIndex = isFunction(indexExpr, 'Tuple')
      ? indexExpr
      : indexExpr.canonical;
    const idxCanonical = isSymbol(canonicalIndex)
      ? (ce._bindingSymbol(canonicalIndex.symbol, ce.context.lexicalScope) ??
        canonicalIndex)
      : canonicalIndex;
    // The element type is read fact-blind: the collection's EFFECTIVE type can
    // be narrowed by an assumption, and the index binding this write creates is
    // a contract that must not carry a fact the next statement can retract.
    let patternError: Expression | undefined;
    // The index of a `Loop` over a range with integer literal bounds
    // (`Element(j, Range(1, 100))`) is typed `integer<1..100>`, not the bare
    // `integer` element type of the range, as the index of a `Sum` over
    // `Limits(j, 1, 100)` is. The bounded type lets a compiled `Mod(j, 3)` in
    // the body use the plain `%` operator instead of the checked helper.
    // The index of a `Comprehension` is typed the same way: the ranged type
    // proves the sign of a body such as `√((k − 0.5)/16)`, so the compiled
    // body stays on the real lane. The `Comprehension` type handler removes
    // the numeric ranges from the element type of the list it returns, so
    // `[k for k in 1..100]` is `list<integer>`, not `list<integer<1..100>>`.
    const rangeIndex = rangeElementIndexType(idxCanonical, collCanonical, ops);
    const currentElementType = (): Type | undefined =>
      rangeIndex !== undefined
        ? parseType(rangeIndex)
        : collectionElementType(
            resolveTypeForCompilation(collCanonical.type.type)
          );
    // Bind the index (or each leaf of a destructuring pattern) from the
    // element type `elt` through `bindOne`. The leaves are looked up in the
    // scope current NOW, since the second read (below) runs outside it.
    const bindScope = ce.context.lexicalScope;
    const bindFromElement = (
      elt: Type | undefined,
      bindOne: (binding: Expression, type: Type) => void
    ): void => {
      if (elt === undefined || elt === 'any' || elt === 'unknown') return;
      if (isSymbol(idxCanonical)) {
        bindOne(idxCanonical, elt);
        return;
      }
      // A destructuring pattern (`for (p, q) in pairs`) binds each leaf to
      // the matching component of the element's TUPLE type — the only
      // element type the runtime destructuring accepts (`collectTuplePattern`
      // refuses anything but a `Tuple` value) — recursively for a nested
      // pattern. A leaf whose component type is not known, an element type
      // that is not a tuple, and the wildcard `_` are left as declared,
      // `unknown`, to be typed by use. A tuple type whose arity the pattern
      // does not match, and a name the pattern binds twice, are errors here:
      // the first would fail on every value at run time (the same check
      // `collectTuplePattern` makes), the second would write two
      // authoritative types onto one binding.
      //
      // An element type that is a UNION is read arm by arm: each arm that is
      // a tuple of the pattern's shape gives a type for each leaf, and a
      // leaf's type is the join of its types from those arms. An arm of
      // another shape is skipped, since a value of that arm fails the
      // destructuring at run time and binds nothing. A leaf that one of the
      // read arms leaves untyped stays untyped. When no arm fits, nothing is
      // bound and there is no error (as for any other element type that is
      // not a tuple), unless every arm that has the pattern's arity reports
      // an error, in which case the first arm's error stands.
      //
      // `readPattern` returns the leaf types and adds each name it meets to
      // `bound`; the bindings are written once the whole pattern is read.
      const readPattern = (
        pattern: Expression,
        elementType: Type,
        bound: Set<string>
      ): Map<string, Type> => {
        const leaves = new Map<string, Type>();
        if (patternError !== undefined) return leaves;
        // A component may be an alias or a nominal type of a tuple
        // (`list<tuple<integer, pt>>`): resolve it before reading its shape,
        // as the collection type itself was resolved above.
        const type = resolveTypeForCompilation(elementType);
        if (!isFunction(pattern, 'Tuple')) return leaves;
        if (typeof type !== 'string' && type.kind === 'union') {
          const arms = type.types
            .map((arm) => resolveTypeForCompilation(arm))
            .filter(
              (arm) =>
                typeof arm !== 'string' &&
                arm.kind === 'tuple' &&
                arm.elements.length === pattern.nops
            );
          const armLeaves: Map<string, Type>[] = [];
          let firstError: Expression | undefined;
          const armBound = new Set<string>();
          for (const arm of arms) {
            const b = new Set(bound);
            const read = readPattern(pattern, arm, b);
            if (patternError !== undefined) {
              firstError ??= patternError;
              patternError = undefined;
              continue;
            }
            armLeaves.push(read);
            for (const name of b) armBound.add(name);
          }
          if (armLeaves.length === 0) {
            patternError = firstError;
            return leaves;
          }
          for (const name of armBound) bound.add(name);
          for (const name of armLeaves[0].keys()) {
            const types = armLeaves.map((read) => read.get(name));
            if (types.some((t) => t === undefined)) continue;
            const joined = reduceType({
              kind: 'union',
              types: types as Type[],
            });
            if (joined !== undefined) leaves.set(name, joined);
          }
          return leaves;
        }
        if (typeof type === 'string' || type.kind !== 'tuple') return leaves;
        if (pattern.nops !== type.elements.length) {
          patternError = ce.typeError(
            parseType(
              `tuple<${Array(pattern.nops).fill('unknown').join(', ')}>`
            ),
            type,
            pattern
          );
          return leaves;
        }
        pattern.ops.forEach((leaf, i) => {
          if (patternError !== undefined) return;
          const component = type.elements[i].type;
          if (isFunction(leaf, 'Tuple')) {
            for (const [name, t] of readPattern(leaf, component, bound))
              leaves.set(name, t);
            return;
          }
          const name = sym(leaf);
          if (name === undefined || name === '_') return;
          if (bound.has(name)) {
            patternError = ce.error(
              'unexpected-argument',
              `duplicate name in destructuring pattern: ${name}`
            );
            return;
          }
          bound.add(name);
          if (component === 'any' || component === 'unknown') return;
          leaves.set(name, component);
        });
        return leaves;
      };
      const leaves = readPattern(idxCanonical, elt, new Set());
      if (patternError !== undefined) return;
      for (const [name, type] of leaves) {
        const binding = ce._bindingSymbol(name, bindScope);
        if (binding !== undefined) bindOne(binding, type);
      }
    };
    // The binding site is AUTHORITATIVE for the index's type: the element
    // type is evidence from the collection, not a guess. The helper also
    // takes the binding out of the fresh-inference set, so a body use that
    // contradicts the element type is an error (`bindIndexAuthoritatively`,
    // `library/utils.ts`).
    ce._withoutFacts(() =>
      bindFromElement(currentElementType(), (binding, type) =>
        bindIndexAuthoritatively(ce, binding, type)
      )
    );
    // The collection's type is read NOW, but it may read a local that a later
    // statement of an enclosing loop widens: `for t in [p, q, r]` where `p`
    // later holds a tuple of `number` elements. The index then claimed the
    // narrower element type, and the compiled complex lane read a `{re, im}`
    // element as a JavaScript number. So the enclosing block reads the
    // element type again after all its statements are canonicalized, and
    // widens the index to it (`withEvidenceSession`,
    // `library/assignment-evidence.ts`). A pattern error found on that
    // second read is ignored: the loop is already built. But when a later
    // read gives no type for an index (or a leaf) that the first read typed
    // — the element type became `unknown` or `any`, or is no longer a tuple
    // of the pattern's arity — the first, narrower type may no longer hold
    // for what the loop visits, so that index is widened to `unknown` (the
    // same write as `reset`) and the site reports a change. After that the
    // site writes nothing more for the rest of the session: `unknown` is
    // already the widest type.
    const indexBindings: Expression[] = [];
    ce._withoutFacts(() =>
      bindFromElement(currentElementType(), (binding) =>
        indexBindings.push(binding)
      )
    );
    if (patternError === undefined && indexBindings.length > 0) {
      const lost = new Set<string>();
      registerEvidenceSite(ce, {
        rejoin: (coarse) => {
          let changed = false;
          const saved = patternError;
          const typed = new Set<string>();
          ce._withoutFacts(() =>
            bindFromElement(currentElementType(), (binding, type) => {
              const name = sym(binding);
              if (name === undefined || lost.has(name)) return;
              typed.add(name);
              const before = binding.type.type;
              if (isSubtype(type, before)) return;
              binding._infer(
                () => (coarse ? coarsenEvidenceType(type) : type),
                'widen'
              );
              if (binding.type.type !== before) changed = true;
            })
          );
          patternError = saved;
          for (const binding of indexBindings) {
            const name = sym(binding);
            if (name === undefined || typed.has(name) || lost.has(name))
              continue;
            lost.add(name);
            if (binding.type.isUnknown) continue;
            binding._infer(() => 'unknown', 'replace');
            changed = true;
          }
          return changed;
        },
        reset: () => {
          for (const binding of indexBindings)
            binding._infer(() => 'unknown', 'replace');
        },
      });
    }
    // An optional GUARD, `Element(x, xs, cond)` — the three-operand indexing
    // set `Sum` and `Product` also take. It is canonicalized here, after the
    // index is declared, so its occurrences of the index bind to this loop's
    // scope, as the body's do. At run time an element is visited only when
    // the guard evaluates to `True` (`runNested`).
    const guard = it.ops[2];
    const guardCanonical =
      guard === undefined || sym(guard) === 'Nothing'
        ? undefined
        : guard.canonical;
    if (patternError !== undefined)
      return ce._fn('Element', [patternError, collCanonical]);
    return ce._fn(
      'Element',
      guardCanonical === undefined
        ? [idxCanonical, collCanonical]
        : [idxCanonical, collCanonical, guardCanonical]
    );
  });
  // The body of a `Loop` is a branch: a `Declare` there is a static error.
  // The term of a `Comprehension` is a value: a block there declares its own
  // locals for each element.
  // The count of branches starts again at zero for the term, so a block in
  // the term declares its locals also when the `Comprehension` is in a
  // branch, as for the body of a function literal (`enterFunctionBody()`).
  let canonicalBody: Expression;
  if (head === 'Loop' || head === 'ParallelLoop')
    canonicalBody = canonicalBranch(ce, body);
  else {
    enterFunctionBody();
    try {
      canonicalBody = canonicalStatement(ce, body);
    } finally {
      exitFunctionBody();
    }
  }

  return ce._fn(head, [canonicalBody, ...canonicalIterators], {
    scope: loopScope,
  });
}

/**
 * The `ParallelComprehension` `expression` with the domain of its first
 * clause replaced by `domain`, its value evaluated once, or `expression`
 * when there is no such value. The local scope of the comprehension is kept,
 * so its body and clauses keep their bindings.
 */
function residualParallelComprehension(
  expression: Expression,
  domain: Expression | undefined
): Expression {
  if (domain === undefined || !isFunction(expression)) return expression;
  const [body, first, ...rest] = expression.ops;
  if (!isFunction(first, 'Element') || first.ops[1] === domain)
    return expression;
  const ce = expression.engine;
  const clause = ce._fn('Element', [
    first.ops[0],
    domain,
    ...first.ops.slice(2),
  ]);
  return ce._fn('ParallelComprehension', [body, clause, ...rest], {
    scope: expression.localScope,
  });
}

/** Mutable state shared across the nested-iteration walker. */
interface LoopState {
  stopped: boolean;
  value?: Expression;
  count: number;
  /** The error value of a clause domain that stopped the walk (`runNested`).
   * It is not an element: a `Loop` takes it as its value, and a
   * `Comprehension` records a failed walk with it (`noteFailedWalk()`), so
   * that the error is the value of the whole comprehension. */
  domainError?: Expression;
  /** For a `ParallelLoop` or a `ParallelComprehension`: the elements of the
   * first clause are passes, each with its own random frame
   * (`parallelPassValues()`). */
  parallel?: boolean;
  /** True when the domain of a clause did not evaluate to a collection (a
   * symbol of type `list` with no value, `Range(1, n)` with `n` unknown):
   * the walk had no element for that clause, but the domain is not known to
   * be empty. A `ParallelComprehension` then stays unevaluated. */
  unresolvedDomain?: boolean;
  /** For a `ParallelComprehension`: the value of the domain of its first
   * clause, which the walk evaluated once. When the comprehension stays
   * unevaluated, its first clause holds this value, so that a draw or a
   * write in the domain is not made a second time when the comprehension
   * is evaluated again. */
  firstDomain?: Expression;
}

/**
 * The elements of the domain of the first clause of a parallel loop or
 * comprehension, with the frame of pass `k` (from 1) installed while the
 * consumer handles element `k`: its guard, its inner clauses and the body
 * (`docs/RANDOMNESS-MODEL.md` §3, "Pass frames", and §5).
 *
 * The domain is walked to the end before the first pass, so a domain whose
 * elements are computed as they are read (a `Map`, a `Comprehension`) is read
 * before any pass changes the variables that it reads. A domain whose elements
 * draw as they are made has then drawn all of them. With no `WithRandomSeed`
 * frame active, the draws of the passes are live, as every unframed draw is.
 * Inside a frame, the loop then consumes its one index `b` of the frame. The
 * compiled code does the same (`_SYS.parallelPasses()`), so the two consume
 * the same indices.
 *
 * The frame of a pass applies to the direct draws of the pass (a `Random()`
 * that the pass evaluates). The draws of a lazy view in the body (a
 * comprehension that draws, held in the body, in a `let` or in a function
 * literal) are not specified: the passes evaluate the same boxed body, and
 * the caches of a view are per instance, so a pass can read the draws that
 * the view made in another pass (`docs/RANDOMNESS-MODEL.md` §6, "One
 * instance, one draw set").
 *
 * The enclosing frame is installed again when the walk ends or stops early
 * (`return()` of this generator, from the `for … of` of the consumer).
 */
function* parallelPassValues(
  ce: ComputeEngine,
  values: Iterable<Expression>
): Generator<Expression> {
  const enclosing = ce._randomFrame;
  const elements: Expression[] = [];
  for (const value of values) {
    elements.push(value);
    if (elements.length > ce.iterationLimit)
      throw new CancellationError({ cause: 'iteration-limit-exceeded' });
  }
  const base =
    enclosing === undefined ? undefined : beginParallelLoop(enclosing);
  try {
    for (let k = 1; k <= elements.length; k++) {
      if (base !== undefined) ce._randomFrame = parallelPassFrame(base, k);
      yield elements[k - 1];
    }
  } finally {
    ce._randomFrame = enclosing;
  }
}

/** The guards of the `while` loops that `runLoop` is running
 * (`whileGuard`), each with the number of runs of its loop that have not
 * ended: a loop in a recursive function runs inside itself. */
const WHILE_GUARDS = new WeakMap<Expression, number>();

/**
 * The guard `If(g, Break)` of `body` when a bare `Loop` with this body is a
 * `while` loop: the body is `Block(If(g, Break), b)`, the form that the Epsil
 * parser gives to `while c { b }` (`g` is `Not(c)`, or its canonical form).
 * Otherwise `undefined`.
 */
function whileGuard(body: Expression): Expression | undefined {
  if (!isFunction(body, 'Block') || body.nops !== 2) return undefined;
  const guard = body.op1;
  if (!isFunction(guard, 'If') || guard.nops !== 2) return undefined;
  const control = guard.op2;
  return isFunction(control, 'Break') && control.nops === 0 ? guard : undefined;
}

/**
 * The value of the `If` `expr`, of value `result`. When `expr` is the guard
 * of a `while` loop and its condition is neither `True` nor `False` (a
 * comparison with a name that has no value), the value is the
 * `incompatible-type` error, which ends the loop: the `If` would be held,
 * and the loop would never end. Any other `If` is not changed.
 */
function whileGuardResult(
  ce: ComputeEngine,
  expr: Expression | undefined,
  result: Expression | undefined
): Expression | undefined {
  if (!isFunction(expr, 'If') || !WHILE_GUARDS.has(expr)) return result;
  // The condition was `True` (`Break`), `False` (`Missing`: an `If` with a
  // statement arm and no else branch), or an error.
  if (
    result !== undefined &&
    (isFunction(result, 'Break') ||
      result.operator === 'Error' ||
      sym(result) === 'Missing')
  )
    return result;
  const g = expr.op1;
  return ce.typeError(
    'boolean',
    undefined,
    isFunction(g, 'Not') ? g.op1 : ce._fn('Not', [g])
  );
}

/**
 * Imperative `Loop`, evaluated **for effect**.
 *
 * - `Loop(body)` — infinite loop: repeatedly evaluate `body` until it yields a
 *   `Break` (loop value = its operand, else `Nothing`) or a `Return`
 *   (propagated unchanged). Any other result (including `Continue`) just
 *   continues.
 * - `Loop(body, Element(x, coll), …)` — nested for-each for effect. No results
 *   are accumulated; normal completion returns `Nothing`.
 */
function* runLoop(
  body: Expression,
  elements: ReadonlyArray<Expression>,
  ce: ComputeEngine,
  /** For a `ParallelLoop`: the elements of the first clause are passes. */
  parallel?: boolean
): Generator<Expression> {
  body ??= ce.Nothing;
  // A parallel loop with an empty body still walks its domain and consumes
  // its index of the random frame (`parallelPassValues()`), as the compiled
  // code does, so the draws after the loop are the same.
  if (sym(body) === 'Nothing' && parallel !== true) return ce.Nothing;

  if (elements.length === 0) {
    // Bare infinite imperative loop.
    // The guard of a `while` is marked while this loop runs, and only then.
    // The `finally` runs when the loop ends, returns or throws, and when the
    // driver closes the generator before its end (`run`, `runAsync` and
    // `withEvaluationEffects` close it in a `finally`). A generator that a
    // consumer drops without closing keeps the mark until it is collected.
    const guard = whileGuard(body);
    if (guard !== undefined)
      WHILE_GUARDS.set(guard, (WHILE_GUARDS.get(guard) ?? 0) + 1);
    try {
      let i = 0;
      while (true) {
        const result = body.evaluate();
        if (isFunction(result, 'Break'))
          return result.ops.length > 0 ? result.op1 : ce.Nothing;
        if (result.operator === 'Return') return result;
        // An `Error` value — the body's statement list short-circuited on a
        // fault (see `evaluateStatements`). Stop and surface it as the loop's
        // value rather than iterating past it forever.
        if (result.operator === 'Error') return result;
        i += 1;
        yield result;
        if (i > ce.iterationLimit)
          throw new CancellationError({ cause: 'iteration-limit-exceeded' });
      }
    } finally {
      if (guard !== undefined) {
        const n = (WHILE_GUARDS.get(guard) ?? 1) - 1;
        if (n > 0) WHILE_GUARDS.set(guard, n);
        else WHILE_GUARDS.delete(guard);
      }
    }
  }

  const state: LoopState = {
    stopped: false,
    count: 0,
    parallel,
  };
  yield* runNestedElements(body, elements, ce, state, (result) => {
    if (isFunction(result, 'Break')) {
      state.stopped = true;
      // The break value is already evaluated in-context (Break is eager), so a
      // value referencing the loop variable is concrete.
      if (result.ops.length > 0) state.value = result.op1;
      return;
    }
    if (result.operator === 'Return') {
      // Return propagation: forward the Return expression unchanged.
      state.stopped = true;
      state.value = result;
      return;
    }
    if (result.operator === 'Error') {
      // A fault the body's statement list short-circuited on (see
      // `evaluateStatements`): stop, and the error is the loop's value —
      // iterating on would silently repeat (or compound) the fault.
      state.stopped = true;
      state.value = result;
      return;
    }
    // Any other result (including Continue) simply continues.
  });

  // A domain that evaluates to an error value (a local read before it has a
  // value, `for i in t { … }; t = [1]` in a function body) stopped the walk,
  // and the error is the value of the loop, as an error of the body is.
  if (state.domainError !== undefined) return state.domainError;
  if (state.stopped && state.value !== undefined) return state.value;
  return ce.Nothing;
}

/**
 * The canonical form of the assignment that `AddTo` stands for:
 * `Assign(s, Add(s, v))` for a variable `s`, and
 * `Assign(L, ReplaceAt(L, p…, Add(At(L, p…), v)))` for an element of `L`.
 *
 * The canonical `AddTo` keeps its operands and does not run the canonical
 * handlers of `Add`, `At`, `ReplaceAt` or `Assign`. The equivalent assignment
 * is canonicalized once, for two reasons:
 *
 * - The target receives the type information of its use: the inference that
 *   the operator signatures write on the symbols, and the assignment evidence
 *   that the canonical `Assign` records on the target
 *   (`joinAssignmentEvidence()`, `library/core.ts`). Without it, an untyped
 *   parameter `L` of `function step(L, n) { for k in 1..n { L[k] += 1 }; L }`
 *   stayed `unknown`, and a call with a list argument was applied to each
 *   element of the list.
 * - The caller gets the static errors of the long form. When the result is
 *   not valid, the canonical `AddTo` is that result, so `t += e` has the
 *   errors of `t = t + e`: an assignment of an undeclared `t`
 *   (`assignment-to-undeclared-variable`), a value whose type
 *   the local does not accept, and an invalid sum (`s += "a"` with `s` a
 *   number).
 *
 * `target` is the symbol as it was written, not canonical. The value of the
 * assignment is built without canonicalization, so the canonical `Assign`
 * runs its checks of the target first, as for `t = t + e`: a canonical
 * symbol would declare a name that no scope declares, and the first
 * assignment would not be reported. The positions and `value` are already
 * canonical, so nothing is canonicalized a second time.
 */
function equivalentAssign(
  ce: ComputeEngine,
  target: Expression,
  positions: ReadonlyArray<Expression> | undefined,
  value: Expression
): Expression {
  const raw = (h: string, ops: Expression[]): Expression =>
    ce._fn(h, ops, { canonical: false });
  if (positions === undefined)
    return ce.function('Assign', [target, raw('Add', [target, value])]);
  return ce.function('Assign', [
    target,
    raw('ReplaceAt', [
      target,
      ...positions,
      raw('Add', [raw('At', [target, ...positions]), value]),
    ]),
  ]);
}

/**
 * Evaluate `AddTo(target, value)`. The positions of an `At` target are
 * evaluated once, then the current value of the target (`s`, or the element
 * `At(L, p…)`) is read, then the value is evaluated, as in `s = s + v`, where
 * `s` is read before `v`: so `s += do { s = 10; 2 }` with `s = 1` gives 3, as
 * the compiled form does (`parallel-lowering.ts`). Then the assignment
 * `Assign(s, Add(s₀, v))` or `Assign(L, ReplaceAt(L, p…, Add(e₀, v)))`, with
 * `s₀` and `e₀` the values read before `v`, is evaluated with those values.
 * So a position with an effect (`L[random(1..9)] += 1`) is evaluated once,
 * and the write is the one that the `Assign` form makes: a write that cannot
 * give a list keeps the value of the variable (`elementRebindingFailure()`,
 * in this file).
 */
function evaluateAddTo(
  ce: ComputeEngine,
  target: Expression | undefined,
  value: Expression | undefined
): Expression | undefined {
  return runOperandSteps(addToSteps(ce, target, value));
}

/**
 * The steps of `evaluateAddTo()`, as a generator that yields each expression
 * to evaluate (`operand-steps.ts`). The synchronous handler evaluates them
 * with `evaluate()`, and the asynchronous handler with `evaluateAsync()`, in
 * the same order.
 */
function* addToSteps(
  ce: ComputeEngine,
  target: Expression | undefined,
  value: Expression | undefined
): OperandSteps<Expression | undefined> {
  if (target === undefined || value === undefined) return undefined;
  if (isFunction(target, 'At') && isSymbol(target.op1)) {
    const list = target.op1;
    const positions: Expression[] = [];
    for (const p of target.ops.slice(1)) {
      const v = yield p;
      if (v.operator === 'Error') return v;
      positions.push(v);
    }
    const element = yield ce._fn('At', [list, ...positions]);
    // An increment that can write a binding or an object (its effects
    // include `scope` or `state`, or are not known) can assign the list
    // itself: `L[1] += do { L = [10, 20]; 2 }`. The new list is then built
    // from the value of the list read before the increment, as in
    // `L = replaceAt(L, 1, L[1] + …)`, where the operand `L` of `replaceAt`
    // is read before its last operand. A write that cannot give a list is
    // refused as the assignment refuses it, and the variable keeps the value
    // that the increment gave it. Otherwise the list stays a symbol in
    // `ReplaceAt`, and the assignment updates it in place.
    const effects = effectsOf(value);
    if (
      computedEffectsInclude(effects, 'scope') ||
      computedEffectsInclude(effects, 'state')
    ) {
      const before = yield list;
      const increment = yield value;
      if (increment.operator === 'Error') return increment;
      const replaced = yield ce._fn('ReplaceAt', [
        before,
        ...positions,
        ce._fn('Add', [element, increment]),
      ]);
      const failed = elementRebindingFailure(ce, list.symbol, replaced);
      if (failed !== undefined) return failed;
      return yield ce._fn('Assign', [list, replaced]);
    }
    const increment = yield value;
    if (increment.operator === 'Error') return increment;
    return yield ce._fn('Assign', [
      list,
      ce._fn('ReplaceAt', [
        list,
        ...positions,
        ce._fn('Add', [element, increment]),
      ]),
    ]);
  }
  if (!isSymbol(target)) return undefined;
  const current = yield target;
  const increment = yield value;
  if (increment.operator === 'Error') return increment;
  return yield ce._fn('Assign', [target, ce._fn('Add', [current, increment])]);
}

/**
 * True when `value` is a collection that a rebinding can write into: an
 * indexed collection (a `List`, a `Range`, the lazy view that `ReplaceAt`
 * gives for a long list, a string, a tuple). The rebinding follows the result
 * that `ReplaceAt` documents: `s[1] := "z"` with `s = "abc"` gives the list of
 * characters `["z", "b", "c"]`, and a tuple gives a list. A number, a
 * dictionary and a symbol with no value are not.
 */
function isIndexedValue(value: Expression): boolean {
  return value.isIndexedCollection;
}

/**
 * The error of the rebinding `name := ReplaceAt(name, …)`
 * (`isElementRebinding()` in `library/core.ts`) whose evaluated value is
 * `value`, or `undefined` when the value is stored. The value is read after
 * the evaluation, so each
 * position and each operand of the write is evaluated once, by `ReplaceAt`.
 *
 * - An error is returned, and the variable keeps its value.
 * - A collection is stored.
 * - A `ReplaceAt` that is still unevaluated has evaluated operands. In a
 *   chain, its collection operand is the value of the inner `ReplaceAt`.
 *   - A collection operand with no positions (a number, a symbol with no
 *     value) is the error `assignment-to-list-element`.
 *   - With positions that are all numbers, the positions are followed in the
 *     collection, while the count of each level is known: a position that is
 *     zero, not an integer, or past the end is the error `out-of-range` (the
 *     length of a string is its number of characters), and a level that is
 *     not an indexed collection (a number in `xs[1, 1] := 9`, with `xs` a
 *     flat list) is the error `assignment-to-list-element`. When every
 *     position is valid, the value is the lazy view that `ReplaceAt` gives
 *     for a long list, and it is stored.
 *   - Otherwise (a position that is not a number, as in `xs[k] := 1` with
 *     `k` unknown, or a level whose count is not known), the unevaluated
 *     `ReplaceAt` is stored, as `ReplaceAt` documents.
 *
 * In both error cases the variable keeps its value.
 */
export function elementRebindingFailure(
  ce: ComputeEngine,
  name: string,
  value: Expression
): Expression | undefined {
  if (!value.isValid) return value;
  if (!isFunction(value, 'ReplaceAt') || value.nops < 3) return undefined;
  const notIndexed = (what: string): Expression =>
    ce.error([
      'assignment-to-list-element',
      `${what} "${name}" is not an indexed collection`,
    ]);
  let level: Expression | undefined = value.op1;
  if (!isIndexedValue(level)) return notIndexed('the value of');
  const positions = value.ops.slice(1, -1);
  if (!positions.every((p) => isNumber(p))) return undefined;
  for (const [i, position] of positions.entries()) {
    if (level === undefined || !isIndexedValue(level))
      return notIndexed('an element of');
    const count = level.count;
    if (count === undefined) return undefined;
    const n = Number(count);
    const k = position.re;
    if (!Number.isInteger(k) || k === 0 || Math.abs(k) > n)
      return ce.error([
        'out-of-range',
        n === 0
          ? 'an index of a non-empty list'
          : `an index in 1..${n} or -${n}..-1`,
        position.toString(),
      ]);
    if (i < positions.length - 1) level = level.at(k > 0 ? k : n + k + 1);
  }
  return undefined;
}

/** The index variable names of a comprehension's `Element` clauses, in order
 * (the wildcard `Nothing` is skipped — it binds nothing; a destructuring
 * pattern contributes each of its leaves). */
function comprehensionIndexNames(
  elements: ReadonlyArray<Expression>
): string[] {
  const names: string[] = [];
  for (const el of elements) {
    if (!isFunction(el, 'Element')) continue;
    const idx = el.ops[0];
    if (idx && isSymbol(idx) && idx.symbol !== 'Nothing')
      names.push(idx.symbol);
    else if (isFunction(idx, 'Tuple')) names.push(...tuplePatternNames(idx));
  }
  return names;
}

/**
 * The index values of one walk of a `Comprehension`.
 *
 * Each synchronous advance of a walk runs in an activation of the
 * comprehension's scope, pushed for that advance only, which starts with no
 * value for the indexes. Walks interleave (paused `each()` generators, a
 * dependent `.count` read mid-iteration), so a walk keeps its own index
 * values here: before an advance it writes them in the new activation
 * (`install()`), and after the advance it reads them back (`capture()`).
 */
class ComprehensionIndexFrame {
  private ce: ComputeEngine;
  private defs: (BoxedValueDefinition | undefined)[];
  /** This walk's current index values, persisted across advances. */
  private mine: (Expression | undefined)[];

  constructor(ce: ComputeEngine, scope: Scope | undefined, names: string[]) {
    this.ce = ce;
    this.defs = names.map((name) => {
      const def = scope?.bindings.get(name);
      return def !== undefined && isValueDef(def) && !def.value.isConstant
        ? def.value
        : undefined;
    });
    this.mine = names.map(() => undefined);
  }

  /** Write this walk's index values in the activation of the advance. */
  install(): void {
    // Ephemeral index writes: bump `_anyVersion` and the per-def
    // `_writeVersion`, not `_semanticVersion` — installing a walk's indices
    // is not a semantic mutation of the document.
    this.ce._ephemeralWriteDepth += 1;
    try {
      this.defs.forEach((d, i) => {
        // Skip no-op writes: the `value` setter bumps `ce._anyVersion`, and a
        // gratuitous bump invalidates generation-keyed caches engine-wide.
        if (d && d.value !== this.mine[i]) d.value = this.mine[i];
      });
    } finally {
      this.ce._ephemeralWriteDepth -= 1;
    }
  }

  /** Read the (possibly advanced) index values. Call in a `finally` paired
   * with `install()`, before the activation is popped. */
  capture(): void {
    this.mine = this.defs.map((d) => d?.value);
  }

  /** This walk's current index values as a substitution map (C2), or
   * `undefined` if no index has a value yet. */
  subs(names: string[]): Record<string, Expression> | undefined {
    let subs: Record<string, Expression> | undefined;
    this.mine.forEach((v, i) => {
      if (v !== undefined) (subs ??= {})[names[i]] = v;
    });
    return subs;
  }
}

/**
 * Stream a `Comprehension`'s body values one at a time.
 *
 * An activation of the comprehension's scope, which holds this walk's index
 * values (see `ComprehensionIndexFrame`), is pushed ONLY around each
 * synchronous `inner.next()` advance: the step that assigns the next index
 * and evaluates the body. It is popped BEFORE the value is yielded. So the
 * eval-context stack is never held across a `yield`: a consumer that stops early or abandons the iterator
 * leaves nothing pushed to leak (this is safe even though `each()` does not
 * forward `.return()` to us), and interleaved walks of the same comprehension
 * cannot observe each other's indices. Because each element is produced on
 * demand, iterating an infinite domain and taking only a prefix (e.g. `Take`,
 * `First`) works without hitting the iteration limit; a full drive of an
 * infinite domain still terminates via the iteration-limit
 * `CancellationError` from `runNested`.
 */
function* comprehensionStream(
  expr: Expression,
  /** The state of the walk, when the caller reads it after the walk (a
   * `ParallelComprehension`, which also sets its `parallel` field). */
  walkState?: LoopState
): Generator<Expression, undefined, any> {
  if (!isFunction(expr)) return;
  const ce = expr.engine;
  const body = expr.ops[0] ?? ce.Nothing;
  const elements = expr.ops.slice(1);

  const scope = isFunction(expr) && expr.isScoped ? expr.localScope : undefined;
  const indexNames = comprehensionIndexNames(elements);
  // The index values are written in the activation of the comprehension's
  // scope that each advance pushes (see ComprehensionIndexFrame).
  const frame = new ComprehensionIndexFrame(ce, scope, indexNames);
  const state: LoopState = walkState ?? { stopped: false, count: 0 };
  const inner = runNestedElements(body, elements, ce, state, () => {});
  // The walk is advanced by hand, so it is closed here when this stream
  // ends or is closed by its consumer (`return()`, or a throw in the
  // `for … of` of the consumer): a parallel walk then runs its `finally`
  // and installs again the enclosing random frame (`parallelPassValues()`).
  try {
    while (true) {
      let r: IteratorResult<Expression>;
      // Capture this iteration's index values BY VALUE while they are still
      // installed (C2): a materialized body that is a function literal captures
      // its free variables by reference against the scope active at apply time,
      // so without the substitution below every element of
      // `[x ↦ x + i for i in 1..3]` would share one `i` (resolving to its
      // final value, or to nothing once the walk completes) instead of closing
      // over 1, 2, 3. Substituting the index values into the element is a
      // no-op for a body that already resolved them.
      //
      // The substitution reaches only the occurrences that DENOTE this
      // comprehension's index (`substituteBinderValues`, ruled 2026-09-21).
      // An occurrence of the same name that denotes a global keeps the global:
      // with `w` valueless and `W := x ↦ [w x, x]`,
      // `[W(w)[1] for w in [1, 2, 3]]` answers `[w, 2w, 3w]`, exactly what the
      // spelling `[W(k)[1] for k in [1, 2, 3]]` answers. Substituting by name
      // gave `[1, 4, 9]`. The comprehension's own scope is passed because it
      // has left the ambient chain by this point.
      let subs: Record<string, Expression> | undefined;
      if (scope)
        ce._pushEvalContext(scopeActivation(ce.context.lexicalScope, scope));
      frame.install();
      try {
        r = inner.next();
      } finally {
        frame.capture();
        if (scope) ce._popEvalContext();
      }
      if (r.done) {
        // A clause domain that is an error value makes the error the value of
        // the whole comprehension, also after some elements were given: the
        // walk records that it failed, in the pull of its consumer that met
        // the error (`noteFailedWalk()`). A consumer that reads the walk
        // (`Length`, `Count`, `Sum`, a materialization) then answers the
        // error, and the element memo does not keep the walk.
        if (state.domainError !== undefined && walkState === undefined)
          noteFailedWalk(state.domainError);
        return;
      }
      if (indexNames.length > 0) subs = frame.subs(indexNames);
      const value =
        subs !== undefined && r.value.has(indexNames)
          ? substituteBinderValues(r.value, subs, () => scope)
          : r.value;
      yield value;
    }
  } finally {
    inner.return(undefined);
  }
}

/**
 * A comprehension is DEPENDENT when a later clause's collection references an
 * index bound by an earlier clause (e.g. `Element(j, Range(1, i))` after
 * `Element(i, …)`). This is a purely structural test — it does NOT evaluate the
 * clauses, so it is immune to any stale index binding a previous iteration may
 * have left in the persistent loop scope (which would otherwise make a
 * re-evaluated dependent range report a bogus finite count).
 */
function comprehensionIsDependent(clauses: ReadonlyArray<Expression>): boolean {
  const seen: string[] = [];
  for (const clause of clauses) {
    if (!isFunction(clause, 'Element')) return true;
    const coll = clause.ops[1];
    // `has(seen)` is true iff the collection references ANY earlier index.
    if (coll && seen.length > 0 && coll.has(seen)) return true;
    const idx = clause.ops[0];
    if (idx && isSymbol(idx) && idx.symbol !== 'Nothing') seen.push(idx.symbol);
    // A destructuring index (`for (p, q) in pairs`) binds each pattern leaf,
    // so a later clause's domain mentioning any leaf makes it dependent.
    else if (isFunction(idx, 'Tuple')) seen.push(...tuplePatternNames(idx));
  }
  return false;
}

/**
 * Count the elements of a dependent comprehension by traversing its iterator
 * DOMAINS only — the nested iteration is driven with a trivial (`Nothing`) body,
 * so this count never evaluates (or re-runs the side effects of) the real
 * comprehension body. A comprehension whose domain or guard is not pure is
 * counted here only when its count cannot be read from the elements that its
 * element memo keeps (see `comprehensionCount()`). Returns `undefined` if the domain is unbounded (the
 * iteration-limit cancellation); a genuine time-budget cancellation propagates.
 */
function comprehensionEnumeratedCount(
  expr: Expression,
  unguarded = false
): number | undefined {
  if (!isFunction(expr)) return undefined;
  const ce = expr.engine;
  // With `unguarded`, the guards (the third operand of an `Element` clause)
  // are removed and are not evaluated. A guard only removes elements, so
  // that count is an upper bound of the count.
  const elements = expr.ops
    .slice(1)
    .map((clause) =>
      unguarded && isFunction(clause, 'Element') && clause.nops > 2
        ? ce._fn('Element', clause.ops.slice(0, 2))
        : clause
    );
  // The count drive binds the indices in an activation of the scope of its
  // own (where dependent clause domains resolve them), so reading `.count`
  // while another walk is paused does not touch that walk's indices.
  const scope = expr.isScoped ? expr.localScope : undefined;
  if (scope)
    ce._pushEvalContext(scopeActivation(ce.context.lexicalScope, scope));
  try {
    let n = 0;
    const state: LoopState = { stopped: false, count: 0 };
    // Synchronous full drive under one push/pop — no external yield, so the
    // scope is balanced; the `Nothing` body makes each leaf side-effect-free.
    for (const _ of runNestedElements(
      ce.Nothing,
      elements,
      ce,
      state,
      () => {}
    ))
      n += 1;
    // A clause domain that is an error value: the count is not known, and
    // the error is the value of the comprehension (see `comprehensionStream`).
    if (state.domainError !== undefined) {
      noteFailedWalk(state.domainError);
      return undefined;
    }
    return n;
  } catch (e) {
    if (
      e instanceof CancellationError &&
      e.cause === 'iteration-limit-exceeded'
    )
      return undefined;
    throw e;
  } finally {
    if (scope) ce._popEvalContext();
  }
}

/** The independent-clause tally: whether any clause is empty / unknown-count /
 * infinite, and the product of the finite clause counts. `undefined` if a
 * clause is not a collection. Every clause is examined (order-independent),
 * and an empty clause is recorded even when it appears after an unknown or
 * infinite one.
 *
 * A clause with a guard or a destructuring pattern can FAIL for an element:
 * the walk then yields one error cell for that element and does not visit
 * the later clauses (`runNested`). So the cells of a comprehension are not
 * always the product of the clause counts. The tally also records:
 * - `failsBeforeEmpty`: a clause before the first empty clause can fail, so
 *   the comprehension can have error cells although a clause is empty;
 * - `finiteBeforeEmpty`: every clause before the first empty clause has a
 *   known finite count;
 * - `patternBeforeInfinite`: a destructuring clause comes before the first
 *   infinite clause, so the infinite clause is possibly never reached;
 * - `patternBeforeLast`: a destructuring clause is not the last clause, so
 *   an element that does not match gives one cell, not the product of the
 *   later counts. */
function scanIndependentClauses(expr: Expression):
  | {
      empty: boolean;
      unknown: boolean;
      infinite: boolean;
      product: number;
      failsBeforeEmpty: boolean;
      finiteBeforeEmpty: boolean;
      patternBeforeInfinite: boolean;
      patternBeforeLast: boolean;
    }
  | undefined {
  if (!isFunction(expr)) return undefined;
  const ce = expr.engine;
  const clauses = expr.ops.slice(1);
  const scoped = expr.isScoped && expr.localScope !== undefined;
  if (scoped)
    ce._pushEvalContext(
      scopeActivation(ce.context.lexicalScope, expr.localScope!)
    );
  try {
    let empty = false;
    let unknown = false;
    let infinite = false;
    let product = 1;
    let failsBeforeEmpty = false;
    let finiteBeforeEmpty = true;
    let patternBeforeInfinite = false;
    let patternBeforeLast = false;
    // Whether an earlier clause can fail, and whether an earlier clause is a
    // destructuring pattern.
    let fails = false;
    let pattern = false;
    for (const [i, clause] of clauses.entries()) {
      if (!isFunction(clause, 'Element')) return undefined;
      const coll = clause.ops[1]?.evaluate();
      // A domain that is an error value: the error is the value of the
      // comprehension (see `comprehensionStream`).
      if (coll?.operator === 'Error') {
        noteFailedWalk(coll);
        return undefined;
      }
      if (!coll?.isCollection) return undefined;
      // A count that is not a safe integer (a `bigint`) is read as unknown:
      // `Number.isFinite()` below would read it as infinite.
      // The emptiness is read only when the count is not known: each read
      // can walk the domain, and a walk of `filter(1..3, keep)` calls `keep`
      // again when the memo of the domain has expired (`keep` changes a
      // symbol). A known count (a `bigint` included) gives the emptiness; a
      // count that is `NaN` is read as not known.
      const n = coll.count;
      const c = typeof n === 'bigint' ? undefined : n;
      const countKnown =
        typeof n === 'bigint' || (typeof n === 'number' && !Number.isNaN(n));
      if (n === 0 || (!countKnown && coll.isEmptyCollection === true)) {
        if (!empty) failsBeforeEmpty = fails;
        empty = true;
      } else if (c === undefined) unknown = true;
      else if (!Number.isFinite(c)) {
        if (!infinite) patternBeforeInfinite = pattern;
        infinite = true;
      } else product *= c;
      if (!empty && (c === undefined || !Number.isFinite(c)))
        finiteBeforeEmpty = false;
      const isPattern = isFunction(clause.ops[0], 'Tuple');
      if (isPattern && i < clauses.length - 1) patternBeforeLast = true;
      pattern ||= isPattern;
      fails ||= isPattern || comprehensionHasGuard([clause]);
    }
    return {
      empty,
      unknown,
      infinite,
      product,
      failsBeforeEmpty,
      finiteBeforeEmpty,
      patternBeforeInfinite,
      patternBeforeLast,
    };
  } finally {
    if (scoped) ce._popEvalContext();
  }
}

/**
 * Element count of a `Comprehension`. An INDEPENDENT comprehension gets a cheap
 * product of its clause counts WITHOUT materializing. Precedence (independent of
 * clause order): an empty clause ⇒ 0; else an unknown-count clause ⇒ undefined;
 * else an infinite clause ⇒ Infinity; else the product. A DEPENDENT
 * comprehension has no closed form, so it is counted by a domain-only traversal.
 * A comprehension whose domain or guard is not pure is counted from the
 * elements that its element memo keeps, when the memo can keep them
 * (`comprehensionCountFromElements()`): that count evaluates the body of the
 * comprehension.
 */
function comprehensionCount(expr: Expression): number | undefined {
  if (!isFunction(expr)) return undefined;
  const clauses = expr.ops.slice(1);
  if (clauses.length === 0) return undefined;
  // A comprehension whose domain or guard is not pure is counted from the
  // elements that its element memo keeps, so that the count and the
  // elements come from one evaluation of the domains and the guards
  // (`comprehensionCountFromElements()`).
  if (comprehensionClausesAreImpure(clauses)) {
    const kept = validElementMemo(expr);
    if (kept?.complete) return kept.elements.length;
    // In a transient precision window (the window of `N(x, p)`) the memo is
    // neither served nor kept, so the next read of the elements outside the
    // window evaluates them again, and no count can agree with it.
    if (expr.engine._atTransientConfiguration) return undefined;
    // The walk of the elements is made only when the memo can keep it, and
    // when the form of the comprehension shows that each domain can be
    // walked now and that the walk ends (these two tests run no user code).
    // Otherwise the count below is used: a walk that the memo does not keep
    // gives nothing that the count below does not give, and it evaluates
    // the body too; a domain that cannot be walked now (`Linspace(a, 1, 3)`
    // with `a` unknown) gives no element, and the walk would count 0; and
    // a walk of a comprehension that is not known to be finite evaluates the
    // body up to the iteration limit.
    if (
      elementMemoCanKeep(expr) &&
      independentDomainsAreEnumerable(clauses) &&
      comprehensionIsFinite(expr) === true
    )
      return comprehensionCountFromElements(expr);
  }
  if (comprehensionIsDependent(clauses))
    return comprehensionEnumeratedCount(expr);

  const s = scanIndependentClauses(expr);
  if (s === undefined) return undefined;
  // An empty clause gives no cell at its prefixes. But an earlier clause
  // that fails for an element (a guard that gives an error, an element that
  // does not match a destructuring pattern) gives one error cell, and the
  // walk does not visit the empty clause for that element:
  // `[j for i in 1..3 if bad(i), j in []]` has 3 error cells when `bad`
  // gives an error. Then the count is the domain-only traversal, which
  // counts these cells, when the clauses before the empty one are finite.
  if (s.empty) {
    if (!s.failsBeforeEmpty) return 0;
    return s.finiteBeforeEmpty ? comprehensionEnumeratedCount(expr) : undefined;
  }
  if (s.unknown) return undefined;
  // A GUARDED clause (`Element(x, xs, cond)`) keeps only the elements its
  // guard accepts, so the product of the domain counts is an upper bound,
  // not the count. Over finite domains the count is the domain-only
  // traversal, which applies the guard; over an infinite domain nothing
  // decides how many elements the guard keeps. A destructuring clause that
  // is not the last clause is counted by the traversal too: an element that
  // does not match gives one cell, not the product of the later counts. If
  // such a clause comes before an infinite clause, and no element matches,
  // the infinite clause is never reached, so the count is not known.
  const guarded = comprehensionHasGuard(clauses);
  if (s.infinite)
    return guarded || s.patternBeforeInfinite ? undefined : Infinity;
  return guarded || s.patternBeforeLast
    ? comprehensionEnumeratedCount(expr)
    : s.product;
}

/**
 * Whether the domain or the guard of a clause is not transitively pure: it
 * can draw a random number (`Random()`) or run another side effect, so two
 * evaluations of it can give two different results.
 */
function comprehensionClausesAreImpure(
  clauses: ReadonlyArray<Expression>
): boolean {
  return clauses.some(
    (clause) =>
      isFunction(clause, 'Element') &&
      clause.ops
        .slice(1, 3)
        .some((op) => sym(op) !== 'Nothing' && !isTransitivelyPure(op))
  );
}

/**
 * Whether each clause domain that reads no earlier index can be walked now
 * (`isEnumerableCollection`, read from its form, with no user code run).
 * `Linspace(a, 1, 3)` with `a` unknown has 3 elements by its form, but gives
 * none now. A domain that reads an earlier index is not tested here:
 * `comprehensionIsFinite()` accepts an impure one only for a form that can
 * be walked when the indices have values (`dependentDomainShape()`).
 */
function independentDomainsAreEnumerable(
  clauses: ReadonlyArray<Expression>
): boolean {
  const bound: string[] = [];
  for (const clause of clauses) {
    if (!isFunction(clause, 'Element')) return false;
    const domain = clause.ops[1];
    if (domain === undefined) return false;
    const dependent = bound.length > 0 && domain.has(bound);
    if (!dependent && domain.isEnumerableCollection !== true) return false;
    const idx = clause.ops[0];
    if (idx && isSymbol(idx) && idx.symbol !== 'Nothing')
      bound.push(idx.symbol);
    else if (isFunction(idx, 'Tuple')) bound.push(...tuplePatternNames(idx));
  }
  return true;
}

/**
 * The count of a comprehension whose domain or guard is not pure, read from
 * one complete walk of its elements, which the element memo of the instance
 * keeps.
 *
 * The other counts evaluate the domains (`scanIndependentClauses()`) and
 * the guards (`comprehensionEnumeratedCount()`) in a walk of their own, and
 * do not keep the elements. When a domain or a guard draws, that walk uses
 * other draws than the walk that gives the elements, so the count and the
 * elements do not agree: `[j for j in 1..10 if Random() < 0.5]` could have
 * the length 4 and five elements. A walk with `each()` keeps its elements in
 * the element memo (`docs/RANDOMNESS-MODEL.md` §6, "One instance, one draw
 * set"), and a later read of the elements gets the same elements.
 *
 * This walk evaluates the body of the comprehension for each element, and
 * runs its side effects, which the other counts do not do. When the memo
 * keeps the walk, these are the effects of the first read of the elements:
 * the later reads are served by the memo.
 *
 * The caller makes this walk only when the memo can keep it
 * (`elementMemoCanKeep()`), and when the form of the comprehension shows
 * that its domains can be walked now and that it is finite. The memo can still refuse the walk for its content:
 * more than `ELEMENT_MEMO_CAP` elements, an element that holds a mutable
 * object, or a store guard that moved (host code that is not stated pure, a
 * stopped read of a sequence term). Then the next read of the elements
 * evaluates them again, and the count is not known. A walk that missed
 * elements or failed (a domain that is an error value), or that stopped at
 * the iteration limit, gives no count either.
 */
function comprehensionCountFromElements(expr: Expression): number | undefined {
  try {
    let n = 0;
    // A walk of more elements than the memo keeps stops here: it gives no
    // count, and a partial walk of an impure instance is not kept.
    for (const _ of expr.each()) if (++n > ELEMENT_MEMO_CAP) break;
    // The memo does not keep a walk that missed elements or failed
    // (`commitRecordedWalk()`), so such a walk gives no count.
    const kept = validElementMemo(expr);
    return kept?.complete ? kept.elements.length : undefined;
  } catch (e) {
    if (
      e instanceof CancellationError &&
      e.cause === 'iteration-limit-exceeded'
    )
      return undefined;
    throw e;
  }
}

/** Whether any clause carries a guard, a third `Element` operand. */
function comprehensionHasGuard(clauses: ReadonlyArray<Expression>): boolean {
  return clauses.some(
    (clause) =>
      isFunction(clause, 'Element') &&
      clause.nops >= 3 &&
      sym(clause.ops[2]) !== 'Nothing'
  );
}

/**
 * Finiteness of a `Comprehension`, read from the clause domains without a
 * walk of the elements, so that a finite-but-astronomically-large
 * comprehension whose count would overflow a JS number is still correctly
 * reported finite.
 *
 * The test does not run user code: callers of `isWalkableFiniteCollection`
 * read this flag before they decide to walk, and a domain such as
 * `filter(1..i, keep)` calls `keep` for each element that a walk reads. So
 * the guards are not evaluated, and the count or the emptiness of a domain
 * is read only when the domain is transitively pure (a count of a lazy
 * `Filter` walks its source and calls the predicate). The finiteness of a
 * domain (`isFiniteCollection`) is read from its form.
 *
 * - An INDEPENDENT domain (one that reads no earlier index) is evaluated,
 *   as the walk evaluates it, and its finiteness is read, when it is
 *   transitively pure. An impure independent domain is not evaluated: its
 *   finiteness is read from its form, as for a dependent domain.
 * - A DEPENDENT domain is finite for each value of the earlier indices when
 *   its form says so (`dependentDomainShape`): `1..i` with `i` from a
 *   collection of finite real numbers is finite.
 * - A dependent domain whose form decides nothing is walked with no guards
 *   (a guard only removes elements, so the comprehension is finite when
 *   that walk is finite), but only when every domain is transitively pure.
 *   Otherwise the finiteness is not known.
 *
 * An empty clause makes the comprehension finite when no earlier clause can
 * fail, or when every earlier clause is finite: a clause that fails for an
 * element gives an error cell in place of the later clauses.
 */
function comprehensionIsFinite(expr: Expression): boolean | undefined {
  if (!isFunction(expr)) return undefined;
  const clauses = expr.ops.slice(1);
  if (clauses.length === 0) return undefined;
  const ce = expr.engine;
  const scoped = expr.isScoped && expr.localScope !== undefined;
  if (scoped)
    ce._pushEvalContext(
      scopeActivation(ce.context.lexicalScope, expr.localScope!)
    );
  let walk = false;
  let infinite = false;
  let unknown = false;
  try {
    // The index names bound by the earlier clauses, and those whose values
    // are finite real numbers.
    const bound: string[] = [];
    const finiteValued = new Set<string>();
    // Whether every earlier clause is finite, an earlier clause can fail,
    // and an earlier clause is a destructuring pattern.
    let finiteSoFar = true;
    let allNonEmpty = true;
    let fails = false;
    let pattern = false;
    // Whether every domain is transitively pure, so that a walk of the
    // domains runs no user side effect.
    let pure = true;
    for (const clause of clauses) {
      if (!isFunction(clause, 'Element')) return undefined;
      const domain = clause.ops[1];
      if (domain === undefined) return undefined;
      let finite: boolean | undefined;
      let empty = false;
      let nonEmpty = false;
      let valuesFinite = false;
      // Whether the form of this dependent domain decides nothing, so that
      // only a walk can tell.
      let needsWalk = false;
      if (bound.length > 0 && domain.has(bound)) {
        if (!isTransitivelyPure(domain)) pure = false;
        const shape = dependentDomainShape(domain, bound, finiteValued);
        if (shape === undefined) needsWalk = walk = true;
        else {
          finite = true;
          valuesFinite = shape.valuesFinite;
        }
      } else if (!isTransitivelyPure(domain)) {
        // An independent domain that runs user code (`mk()` with `mk`
        // declared impure) is not evaluated: the walk evaluates it, and an
        // evaluation here would run that code one more time. Its finiteness
        // is read from its form, as for a dependent domain, and is not known
        // when the form decides nothing.
        pure = false;
        const shape = dependentDomainShape(domain, [], finiteValued);
        if (shape !== undefined) {
          finite = true;
          valuesFinite = shape.valuesFinite;
        }
      } else {
        const coll = domain.evaluate();
        // A domain that is an error value: the error is the value of the
        // comprehension (see `comprehensionStream`).
        if (coll.operator === 'Error') {
          noteFailedWalk(coll);
          return undefined;
        }
        if (!coll.isCollection) return undefined;
        finite = coll.isFiniteCollection;
        valuesFinite = finite === true && collectionHoldsFiniteReals(coll);
        if (isTransitivelyPure(domain) && isTransitivelyPure(coll)) {
          // The emptiness is read only when the count is not known (a count
          // that is `NaN` is not known), so the domain is walked at most once
          // here. The domain is pure, so a second walk could not be seen from
          // outside: this only saves work.
          const n = coll.count;
          const countKnown =
            typeof n === 'bigint' ||
            (typeof n === 'number' && !Number.isNaN(n));
          empty = n === 0 || (!countKnown && coll.isEmptyCollection === true);
          nonEmpty = !empty && typeof n === 'number' && !Number.isNaN(n);
        } else pure = false;
      }
      if (empty && (!fails || finiteSoFar)) return true;
      if (finite === false) {
        // A destructuring clause before the infinite clause can stop the
        // walk from reaching it: then the result is not known.
        if (!infinite && pattern) unknown = true;
        infinite = true;
      } else if (finite === undefined && !needsWalk) unknown = true;
      if (!nonEmpty && finite !== false) allNonEmpty = false;
      if (finite !== true) finiteSoFar = false;
      const idx = clause.ops[0];
      if (isFunction(idx, 'Tuple')) {
        bound.push(...tuplePatternNames(idx));
        pattern = true;
        fails = true;
      } else if (isSymbol(idx) && idx.symbol !== 'Nothing') {
        bound.push(idx.symbol);
        if (valuesFinite) finiteValued.add(idx.symbol);
      }
      if (comprehensionHasGuard([clause])) fails = true;
    }
    if (unknown) return undefined;
    // An infinite clause gives an infinite comprehension when the walk
    // reaches it and every other clause has at least one element. A guard
    // may keep finitely many elements or infinitely many; nothing here can
    // tell.
    if (infinite)
      return allNonEmpty && !comprehensionHasGuard(clauses) ? false : undefined;
    if (!walk) return true;
    if (!pure) return undefined;
  } finally {
    if (scoped) ce._popEvalContext();
  }
  // The walk pushes the scope of the comprehension itself.
  const c = comprehensionEnumeratedCount(expr, true);
  return c === undefined ? undefined : Number.isFinite(c);
}

/** Whether every element of the finite collection `coll` is a finite real
 * number, read from its type. */
function collectionHoldsFiniteReals(coll: Expression): boolean {
  const element = collectionElementType(coll.type.type);
  return element !== undefined && isSubtype(element, 'real');
}

/**
 * The form of a dependent clause domain `domain`, which reads the earlier
 * indices `bound`, when the form proves that the domain is finite for each
 * value of these indices. `finiteValued` holds the earlier indices whose
 * values are finite real numbers. `valuesFinite` tells whether the elements
 * of the domain are finite real numbers too. `undefined` when the form
 * decides nothing. Nothing in the domain is evaluated, except a part that
 * reads no earlier index and is transitively pure.
 *
 * - `Range(a, b)` and `Range(a, b, step)`: finite when `a` and `b` are
 *   finite for finite indices (`isFiniteForFiniteIndices`) and the step reads
 *   no index and is a nonzero finite real number.
 * - A `List` literal: finite, whatever its elements are.
 * - `Filter(source, predicate)`: a subset of `source`, so it has the form of
 *   `source`. The predicate is not evaluated.
 */
function dependentDomainShape(
  domain: Expression,
  bound: ReadonlyArray<string>,
  finiteValued: ReadonlySet<string>
): { valuesFinite: boolean } | undefined {
  if (!isFunction(domain)) return undefined;
  if (domain.operator === 'Range') {
    const [a, b, step] = domain.ops;
    if (a === undefined || b === undefined || domain.nops > 3) return undefined;
    if (!isFiniteForFiniteIndices(a, bound, finiteValued)) return undefined;
    if (!isFiniteForFiniteIndices(b, bound, finiteValued)) return undefined;
    if (step !== undefined) {
      if (step.has([...bound]) || !isTransitivelyPure(step)) return undefined;
      const s = step.evaluate();
      if (!isNumber(s) || s.isSame(0) || !isSubtype(s.type.type, 'real'))
        return undefined;
    }
    return { valuesFinite: true };
  }
  if (domain.operator === 'List' && !domain.isLazyCollection)
    return {
      valuesFinite: domain.ops.every((x) =>
        isFiniteForFiniteIndices(x, bound, finiteValued)
      ),
    };
  if (domain.operator === 'Filter' && domain.nops === 2) {
    const source = domain.ops[0];
    if (source.has([...bound]))
      return dependentDomainShape(source, bound, finiteValued);
    if (!isTransitivelyPure(source)) return undefined;
    const coll = source.evaluate();
    if (coll.isFiniteCollection !== true) return undefined;
    return { valuesFinite: collectionHoldsFiniteReals(coll) };
  }
  return undefined;
}

/**
 * Whether `x` is a finite real number for each value of the earlier indices
 * `bound`, given that the indices of `finiteValued` hold finite real
 * numbers. `x` is built with `Add`, `Subtract`, `Negate`, `Multiply`, `Abs`,
 * `Floor`, `Ceil`, `Round`, `Min`, `Max` and `Power` with a nonnegative
 * integer exponent from such indices and from parts that read no index, are
 * transitively pure and evaluate to a finite real number. A division is not
 * accepted: `1/i` is infinite for `i = 0`.
 */
function isFiniteForFiniteIndices(
  x: Expression,
  bound: ReadonlyArray<string>,
  finiteValued: ReadonlySet<string>
): boolean {
  if (!x.has([...bound])) {
    if (!isTransitivelyPure(x)) return false;
    const v = x.evaluate();
    return isNumber(v) && isSubtype(v.type.type, 'real');
  }
  if (isSymbol(x)) return finiteValued.has(x.symbol);
  if (!isFunction(x)) return false;
  if (x.operator === 'Power') {
    const [base, exp] = x.ops;
    return (
      base !== undefined &&
      isFiniteForFiniteIndices(base, bound, finiteValued) &&
      isNumber(exp) &&
      exp.isInteger === true &&
      exp.isNonNegative === true
    );
  }
  if (
    ![
      'Add',
      'Subtract',
      'Negate',
      'Multiply',
      'Abs',
      'Floor',
      'Ceil',
      'Round',
      'Min',
      'Max',
    ].includes(x.operator)
  )
    return false;
  return x.ops.every((op) => isFiniteForFiniteIndices(op, bound, finiteValued));
}

/**
 * Lazy indexed-collection handlers for `Comprehension`. `count`/`isEmpty`/
 * `isFinite` are answered from the (independent) clause counts without walking
 * elements; iteration STREAMS one element at a time and a positive `at(n)`
 * fills the shared element-memo prefix up to `n`. A negative index needs the
 * length, so it materializes — but only once the comprehension is known
 * finite. An unread comprehension touches none of these, so binding it is
 * O(1).
 *
 * Element memoization (Tycho items 23.1/38, generalized in item 126) is NOT
 * implemented here: the `elementMemo` flag opts into the shared per-instance
 * memo applied at the `BoxedFunction.each()`/`at()` seam
 * (`boxed-expression/collection-element-memo.ts`) — two-axis invalidation,
 * transitive dependencies, impure-body draw-set coherence. Only the
 * fill-to-n prefix path is invoked directly, because a comprehension has no
 * random access of its own (`at(i)` for i = 1…n without a prefix cache is
 * O(n²), the original item-23 regression).
 */
/**
 * Whether a `Comprehension` can produce its elements: every clause domain the
 * stream walks must be enumerable.
 *
 * A DEPENDENT clause — one naming an index bound by an earlier clause — cannot
 * be judged here: its index is declared-but-unassigned in the local scope, so
 * `Range(1, i)` reads as symbolic-bound though it enumerates fine once the walk
 * binds `i` per iteration. Such a clause contributes `undefined`, not `false`,
 * so a walkable comprehension is never declared inert.
 *
 * The clauses BEFORE the first dependent one are still judged, and that is what
 * catches the shape a whole-comprehension `undefined` used to miss:
 * `[x + y for x in xs for y in 1..x]` over a valueless `xs` walks to nothing,
 * evaluates to `[]`, and had `Any(…)` answering `False` — the caller's
 * evaluate-fallback sees a collection-shaped result and cannot tell. The
 * leading `x in xs` clause is independent, so a `false` from it decides the
 * whole comprehension.
 */
function comprehensionIsEnumerable(expr: Expression): boolean | undefined {
  if (!isFunction(expr)) return undefined;
  const clauses = expr.ops.slice(1);
  if (clauses.length === 0) return undefined;

  // Index names bound so far; a clause whose domain mentions one of them is
  // dependent (same test `comprehensionIsDependent` applies, per clause).
  const bound: string[] = [];
  let unknown = false;
  for (const clause of clauses) {
    if (!isFunction(clause, 'Element')) return undefined;
    const coll = clause.ops[1];
    if (coll === undefined) return undefined;

    if (bound.length > 0 && coll.has(bound)) {
      // Dependent domain: unjudgeable, but a LATER clause cannot rescue an
      // earlier `false`, so keep scanning rather than bailing out.
      unknown = true;
    } else {
      const e = coll.isEnumerableCollection;
      if (e === false) return false;
      if (e === undefined) unknown = true;
    }

    const idx = clause.ops[0];
    if (idx && isSymbol(idx) && idx.symbol !== 'Nothing')
      bound.push(idx.symbol);
    // A destructuring index (`for (p, q) in pairs`) binds each pattern leaf,
    // so a later clause's domain mentioning any leaf is a dependent domain.
    else if (isFunction(idx, 'Tuple')) bound.push(...tuplePatternNames(idx));
  }
  return unknown ? undefined : true;
}

function comprehensionCollectionHandlers(): CollectionHandlers {
  return {
    isLazy: () => true,
    elementMemo: true,

    count: (expr) => comprehensionCount(expr),

    isEmpty: (expr) => {
      const c = comprehensionCount(expr);
      if (c !== undefined) return c === 0;
      // A GUARDED comprehension over an infinite (or unknown-count) domain
      // has no count, but its emptiness is decided by the first element the
      // guard accepts, as `Filter` decides it: walk until one element is
      // produced. The walk stops at the iteration limit — a guard that never
      // accepts leaves emptiness unknown rather than looping — and a domain
      // that cannot be enumerated is not probed at all (the walk would find
      // nothing and report a definite `true`). Without this, `Take(c, 3)` over
      // such a comprehension stayed symbolic: materialization declines a view
      // whose emptiness is unknown.
      if (!isFunction(expr)) return undefined;
      const clauses = expr.ops.slice(1);
      if (!comprehensionHasGuard(clauses)) return undefined;
      if (comprehensionIsEnumerable(expr) !== true) return undefined;
      try {
        for (const _ of expr.each()) return false;
        return true;
      } catch (e) {
        if (
          e instanceof CancellationError &&
          e.cause === 'iteration-limit-exceeded'
        )
          return undefined;
        throw e;
      }
    },

    isFinite: (expr) => comprehensionIsFinite(expr),

    isEnumerable: (expr) => comprehensionIsEnumerable(expr),

    iterator: (expr) => comprehensionStream(expr),

    at: (expr, index) => {
      if (typeof index !== 'number' || !Number.isInteger(index) || index === 0)
        return undefined;
      if (index > 0) {
        // Beyond the cache cap: stream directly rather than pinning a huge
        // prefix in memory.
        if (index > ELEMENT_MEMO_CAP) {
          let i = 0;
          const iter = comprehensionStream(expr);
          try {
            let r = iter.next();
            while (!r.done) {
              if (++i === index) return r.value;
              r = iter.next();
            }
            return undefined;
          } finally {
            // Close the stream (and its nested source iterators) when the
            // element was found before exhaustion.
            if (i === index) iter.return?.(undefined);
          }
        }
        const elements = elementMemoFillTo(expr, index, () =>
          comprehensionStream(expr)
        );
        return elements[index - 1];
      }
      // Negative index (from the end) needs the length: decline unless the
      // comprehension is provably finite, so we never try to materialize an
      // infinite domain just to index from the end. `each()` serves (and, on
      // a full drain, commits) the shared element memo.
      if (comprehensionIsFinite(expr) !== true) return undefined;
      const all = [...expr.each()];
      const target = all.length + index;
      return target >= 0 ? all[target] : undefined;
    },
  };
}

/**
 * Set up the fresh loop scope (index vars pre-declared) and drive the nested
 * iteration. Shared by `runLoop`, `comprehensionStream`, and
 * `comprehensionEnumeratedCount`; the per-result behaviour is supplied via
 * `onLeaf` (and each result is also yielded).
 */
function* runNestedElements(
  body: Expression,
  elements: ReadonlyArray<Expression>,
  ce: ComputeEngine,
  state: LoopState,
  onLeaf: (result: Expression) => void
): Generator<Expression> {
  // Iterate in the loop's OWN lexical scope — the current eval context. The
  // scoped `Loop`/`Comprehension` pushed this scope before its evaluate handler
  // ran, and `canonicalLoopLike` already declared the Element index names in
  // it. We must NOT push a shadowing child scope here: a `Block` body resolves
  // its free variables against its *lexical* parent (this loop scope), not the
  // dynamic runtime context. A child scope would capture `ce.assign(name,
  // value)` below while the body kept reading the (unset) lexical binding,
  // leaving the loop variable symbolic in a `Loop(Block(…), Element…)`. The
  // index names are popped with the loop scope, so they don't leak.
  // Declare-if-absent keeps a non-canonical direct call working.
  for (const elem of elements) {
    if (!isFunction(elem, 'Element')) continue;
    const idx = elem.ops[0];
    if (idx && isSymbol(idx) && idx.symbol !== 'Nothing') {
      if (!ce.context.lexicalScope.bindings.has(idx.symbol))
        ce.declare(idx.symbol, 'unknown');
    }
    // A destructuring loop variable declares one binding per pattern leaf.
    if (isFunction(idx, 'Tuple'))
      for (const name of tuplePatternNames(idx))
        if (!ce.context.lexicalScope.bindings.has(name))
          ce.declare(name, 'unknown');
  }
  yield* runNested(body, elements, 0, ce, state, onLeaf);
}

/**
 * Recursive nested iteration over Element clauses. At each leaf, the body is
 * evaluated and handed to `onLeaf`, which may stop the walk by setting
 * `state.stopped`. `yield`s once per body evaluation for interruptibility.
 */
function* runNested(
  body: Expression,
  elements: ReadonlyArray<Expression>,
  index: number,
  ce: ComputeEngine,
  state: LoopState,
  onLeaf: (result: Expression) => void
): Generator<Expression> {
  if (state.stopped) return;

  if (index === elements.length) {
    const result = body.evaluate();
    state.count += 1;
    if (state.count > ce.iterationLimit)
      throw new CancellationError({ cause: 'iteration-limit-exceeded' });
    onLeaf(result);
    yield result;
    return;
  }

  const elem = elements[index];
  if (!isFunction(elem, 'Element')) {
    // Malformed Element — skip (canonicalization should have handled this).
    return;
  }
  const indexExpr = elem.ops[0];
  const collExpr = elem.ops[1];

  const pattern = isFunction(indexExpr, 'Tuple') ? indexExpr : undefined;
  if (
    !indexExpr ||
    (!isSymbol(indexExpr) && pattern === undefined) ||
    !collExpr
  )
    return;
  const name = isSymbol(indexExpr) ? indexExpr.symbol : '';

  // Re-evaluate the collection on each entry so that dependent bindings
  // (e.g. `Element(y, Range(1, x))`) see the current value of `x`.
  const collection = collExpr.evaluate();
  if (index === 0 && state.parallel === true) state.firstDomain = collection;
  // The Epsil interpreter's hook (see `evaluateStatements`,
  // `function-utils.ts`) also receives the value of a loop or comprehension
  // header written in the source. No statement holds that value, so a failed
  // cell in it (`for x in [1, g("a"), 3]`) would otherwise not be reported
  // when the body does not use the index.
  if (
    ce._epsilStatementResultHook !== undefined &&
    collExpr.sourceOffsets !== undefined
  )
    ce._epsilStatementResultHook(collExpr, collection);
  // A collection that evaluates to an error value (a local read before it
  // has a value, `for i in t { … }; t = [1]` in a function body) stops the
  // walk. The error is not given as an element: the caller decides what it
  // is the value of (`LoopState.domainError`). Without this, the error was
  // not a collection, so the walk had no iteration and the error was lost.
  if (collection?.operator === 'Error') {
    state.stopped = true;
    state.domainError = collection;
    return;
  }
  // A collection head keeps a failed operand in place instead of becoming the
  // error: `1..t` with `t` read before it has a value evaluates to
  // `Range(1, <error>)`, which is not a collection. The error in it is the
  // value of the domain.
  if (collection !== undefined && !collection.isCollection) {
    const embedded = errorValue(collection);
    if (embedded !== undefined) {
      state.stopped = true;
      state.domainError = embedded;
      return;
    }
  }
  if (!collection?.isCollection) {
    // Not a collection — nothing to iterate.
    state.unresolvedDomain = true;
    return;
  }

  // Skip assigning to the wildcard `Nothing`. canonicalLoopLike already
  // filters these out of the pre-declaration pass, so without this guard a
  // stray non-canonical `Loop(body, Element('Nothing', coll))` would walk to
  // the parent scope looking for a binding to assign into.
  const skipAssign = name === 'Nothing';
  // Whether the domain gave an element (see the test after the loop).
  let walked = false;
  // The passes of a parallel loop are the elements of its FIRST clause.
  const passes = index === 0 && state.parallel === true;
  for (const value of passes
    ? parallelPassValues(ce, collection.each())
    : collection.each()) {
    walked = true;
    if (pattern !== undefined) {
      // A DESTRUCTURING loop variable (`for (p, q) in pairs { … }`): match the
      // element against the pattern and bind one leaf at a time. An element
      // that is not a tuple of the pattern's arity is the same shape-mismatch
      // error value `let (p, q) = v` produces. It takes the place of the
      // body value for this element, as the error of a guard does: a loop
      // stops on it and it becomes the loop's value (`onLeaf`, matching how
      // `evaluateStatements` treats a fault), and a comprehension keeps it as
      // the failed cell of this element and goes on with the next element,
      // as `Map` does with a destructuring callback
      // (`[p + q for (p, q) in [(1, 2), 5, (3, 4)]]` is `[3, <error>, 7]`).
      const pairs: [name: string, value: Expression][] = [];
      const err = collectTuplePattern(pattern, value.evaluate(), pairs);
      if (err) {
        state.count += 1;
        if (state.count > ce.iterationLimit)
          throw new CancellationError({ cause: 'iteration-limit-exceeded' });
        onLeaf(err);
        yield err;
        if (state.stopped) return;
        continue;
      }
      // Ephemeral index write, as in the single-name branch below.
      for (const [leaf, v] of pairs) assignLoopIndex(ce, leaf, v);
    } else if (!skipAssign) {
      // Ephemeral index write: bumps `_anyVersion` and the index def's
      // `_writeVersion`, not `_semanticVersion` (see `assignLoopIndex`).
      assignLoopIndex(ce, name, value);
    }
    // A guarded clause, `Element(x, xs, cond)`: the element is visited only
    // when the guard evaluates to `True` with the index bound to it. A
    // `False` guard skips the element; so does one that stays undecided (a
    // symbolic comparison) or is not a boolean at all — a comprehension is a
    // value, and an element it cannot decide to keep is not in it.
    const guard = elem.ops[2];
    if (guard !== undefined && sym(guard) !== 'Nothing') {
      const verdict = guard.evaluate();
      // A guard that evaluates to an error (the index holds a failed cell of
      // the domain, `[x for x in [1, <error>] if x > 0]`) neither keeps nor
      // skips the element: the error takes the place of the body value, as a
      // `Filter` keeps the error of its predicate in place. A loop then stops
      // on it, as on an error of its body.
      const guardError = errorValue(verdict);
      if (guardError !== undefined) {
        state.count += 1;
        if (state.count > ce.iterationLimit)
          throw new CancellationError({ cause: 'iteration-limit-exceeded' });
        onLeaf(guardError);
        yield guardError;
        if (state.stopped) return;
        continue;
      }
      if (sym(verdict) !== 'True') {
        // A rejected element is an iteration too: it counts against the
        // iteration limit, or a guard that never accepts over an infinite
        // domain (`[x for x in 1..oo if x < 0]`) would never reach the body,
        // whose evaluation is where the limit is otherwise enforced, and the
        // walk would never end.
        state.count += 1;
        if (state.count > ce.iterationLimit)
          throw new CancellationError({ cause: 'iteration-limit-exceeded' });
        continue;
      }
    }
    yield* runNested(body, elements, index + 1, ce, state, onLeaf);
    if (state.stopped) return;
  }
  // A walk that gives no element proves that the domain is empty only when
  // the domain is known to be empty (a count of 0, an empty literal). Other
  // domains with no element are not resolved: `Range(1, n)` with `n` unknown
  // has no count, and `Linspace(a, 1, 3)` with `a` unknown has a count of 3
  // but its elements cannot be computed.
  if (
    !walked &&
    collection.isEmptyCollection !== true &&
    collection.count !== 0
  )
    state.unresolvedDomain = true;
}
