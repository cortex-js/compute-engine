import type { Complex } from 'complex.js';
import type { OneOf } from '../common/one-of.js';
import type {
  MathJsonExpression,
  MathJsonNumberObject,
  MathJsonStringObject,
  MathJsonSymbolObject,
  MathJsonFunctionObject,
  MathJsonSymbol,
  MathJsonDictionaryObject,
} from '../math-json.js';
import type {
  EffectLabel,
  EffectSet,
  ParameterDefault,
  Type,
  TypeString,
} from '../common/type/types.js';
import type { ComputedEffects } from '../common/type/effects.js';
import type { EffectHandlers } from './types-effects.js';
import type { BoxedType } from '../common/type/boxed-type.js';
import type { NumericValue } from './numeric-value/types.js';
import type { BigNum } from './numerics/types.js';

import type {
  JsonSerializationOptions,
  PatternMatchOptions,
  ReplaceOptions,
  Substitution,
  BoxedSubstitution,
  CanonicalOptions,
  ParseDiagnostic,
} from './types-kernel-serialization.js';

export type { ParseDiagnostic };
import type {
  EvaluateOptions as KernelEvaluateOptions,
  BoxedRule as KernelBoxedRule,
  Rule as KernelRule,
  BoxedRuleSet as KernelBoxedRuleSet,
  Scope as KernelScope,
  ExplainOperation,
  ExplainVerbosity,
  Explanation as KernelExplanation,
} from './types-kernel-evaluation.js';

/**
 * Compute engine surface used by the expression and definition types.
 *
 * This interface is empty here and augmented by `types-engine.ts` with the
 * members of `IComputeEngine`. The expression types cannot import
 * `IComputeEngine` directly: `types-engine.ts` imports this file, and the
 * repository allows no import cycle, not even between type-only modules.
 * `types-definitions.ts` imports this interface from here for the same
 * reason. The package entry points export their own `ComputeEngine` type
 * (`IComputeEngine`), which takes precedence over this one; the two are
 * structurally identical.
 *
 * @category Compute Engine
 */
// eslint-disable-next-line @typescript-eslint/no-empty-object-type
export interface ComputeEngine {}

type Sign =
  | 'zero'
  | 'positive'
  | 'negative'
  | 'non-negative'
  | 'non-positive'
  | 'not-zero'
  | 'unsigned';

type BaseDefinition = {
  description: string | string[];
  examples: string | string[];
  url: string;
  wikidata: string;
  readonly isConstant?: boolean;
};

interface BaseCollectionHandlers {
  iterator: (
    collection: Expression
  ) => Iterator<Expression, undefined> | undefined;
  count: (collection: Expression) => number | bigint | undefined;
  isEmpty?: (collection: Expression) => boolean | undefined;
  isFinite?: (collection: Expression) => boolean | undefined;
  /** Whether `iterator()` will actually produce this collection's elements —
   * the cheap way to tell an empty collection from one that merely cannot be
   * walked. Absent, it defaults to `true`. Mirror of the handler documented in
   * `types-definitions.ts`. */
  isEnumerable?: (collection: Expression) => boolean | undefined;
  /** Whether this instance is a collection at all, for operators whose
   * collection-ness depends on their operands (e.g. a restriction). Absent, it
   * defaults to `true`. Mirror of the handler documented in
   * `types-definitions.ts`. */
  isCollection?: (collection: Expression) => boolean;
  isLazy?: (collection: Expression) => boolean;
  /** Opt-in to per-instance element memoization (mirror of the flag in
   * `types-definitions.ts`, where it is documented). */
  elementMemo?: boolean;
  /** Set on a lazy operator that calls a function operand when it is read
   * (mirror of the flag in `types-definitions.ts`, where it is documented). */
  callsCallbackOnRead?: boolean;
  contains?: (
    collection: Expression,
    target: Expression
  ) => boolean | undefined;
  /** The number of elements that are the same as `target`, with no walk.
   * Mirror of the handler documented in `types-definitions.ts`. */
  countOf?: (
    collection: Expression,
    target: Expression
  ) => number | bigint | undefined;
  subsetOf?: (
    collection: Expression,
    other: Expression,
    strict: boolean
  ) => boolean | undefined;
  eltsgn?: (collection: Expression) => Sign | undefined;
  elttype?: (collection: Expression) => Type | undefined;
}

interface IndexedCollectionHandlers {
  at: (
    collection: Expression,
    index: number | string
  ) => undefined | Expression;
  indexWhere: (
    collection: Expression,
    predicate: (element: Expression) => boolean
  ) => number | undefined;
  /** The element at a positive 1-based `bigint` position. Mirror of the
   * handler documented in `types-definitions.ts`. */
  atBigint?: (collection: Expression, index: bigint) => undefined | Expression;
  /** The position of the first element that is the same as `target`, with
   * no walk. Mirror of the handler documented in `types-definitions.ts`. */
  indexOf?: (
    collection: Expression,
    target: Expression
  ) => number | bigint | undefined;
}

type CollectionHandlers = BaseCollectionHandlers &
  Partial<IndexedCollectionHandlers>;

interface BoxedBaseDefinition extends Partial<BaseDefinition> {
  examples?: string[];
  collection?: CollectionHandlers;
}

/** Structural mirror of `TypeProvenanceEntry` (`types-definitions.ts`) —
 * one recorded write to a definition's type. Kept field-for-field identical;
 * the canonical documentation lives on the original. */
type TypeProvenanceEntryMirror = {
  type: BoxedType;
  kind: 'declared' | 'auto-declared' | 'inferred' | 'value-derived';
  axis: 'type' | 'effects';
  cause?: Expression;
  span?: { start: number; end: number };
};

interface BoxedValueDefinition extends BoxedBaseDefinition {
  /** Release resources owned by this definition when its scope is disposed. */
  dispose(): void;

  /** True once `dispose()` has run — mirror of the member documented in
   * `types-definitions.ts`.
   * @internal */
  disposed: boolean;

  /** Bumped on every semantic change to this definition (value write, type
   * change, disposal). Used to validate per-dependency caches.
   * @internal */
  _writeVersion: number;

  /** The raw body of a macro definition — mirror of the member documented in
   * `types-definitions.ts`. */
  readonly macro?: MathJsonExpression;

  /** Declared placeholder skeleton for bare-constructor declarations —
   * mirror of the member documented in `types-definitions.ts`.
   * @internal */
  _placeholderSkeleton: Type | undefined;

  /** Declared signature skeleton for a signature with `unknown` slots —
   * mirror of the member documented in `types-definitions.ts`.
   * @internal */
  _signatureSkeleton: Type | undefined;

  /** Element-refinement write that preserves `_placeholderSkeleton` —
   * mirror of the member documented in `types-definitions.ts`.
   * @internal */
  _setElementRefinement(t: BoxedType): void;

  /** Fact-blind declared-type write — mirror of the member documented in
   * `types-definitions.ts`.
   * @internal */
  _setType(thunk: () => Type | TypeString | BoxedType): void;

  /** Opaque snapshot/restore of the coupled type/value slots — mirror of
   * the members documented in `types-definitions.ts`.
   * @internal */
  _typeSlotSnapshot(): unknown;
  /** @internal */
  _restoreTypeSlots(snapshot: unknown): void;

  /** Opaque snapshot/restore of EVERY mutable field, for `ce.withValues()`
   * — mirror of the members documented in `types-definitions.ts`.
   * @internal */
  _fieldSnapshot(): unknown;
  /** @internal */
  _restoreFieldSnapshot(snapshot: unknown): void;

  holdUntil: 'never' | 'evaluate' | 'N';
  value: Expression | undefined;
  /** The value stored on the definition, with no assumed value overlaid —
   * mirror of the member documented in `types-definitions.ts`.
   * @internal */
  readonly storedValue: Expression | undefined;
  readonly isSelfReferential: boolean;
  eq?: (a: Expression) => boolean | undefined;
  neq?: (a: Expression) => boolean | undefined;
  cmp?: (a: Expression) => '=' | '>' | '<' | undefined;
  inferredType: boolean;
  /** See `types-definitions.ts`. @internal */
  _typeWithFacts(declared: BoxedType, memoize: boolean): BoxedType;
  /** A hoisted block local (see `types-definitions.ts`). @internal */
  _blockLocal: boolean;
  _programVariable: boolean;
  /** History of writes to this definition's type. Structural mirror of
   * `TypeProvenanceEntry[]` — the full type lives in `types-definitions.ts`,
   * which imports this file, so it cannot be named from here (same
   * containment as `bindingSites` on the operator mirror below).
   * @internal */
  _typeProvenance: TypeProvenanceEntryMirror[] | undefined;
  /** True when the declaration STATED the arrow's effects (a non-empty
   * specifier, or the `pure` keyword) rather than leaving them on the inferred
   * track. See `types-definitions.ts`. */
  effectsDeclared: boolean;
  type: BoxedType;
  /** The declared type, with nothing an assumption proves merged in —
   * mirror of the member documented in `types-definitions.ts`.
   * @internal */
  readonly declaredType: BoxedType;
  subscriptEvaluate?: (
    subscript: Expression,
    options: {
      engine: ComputeEngine;
      numericApproximation?: boolean;
    }
  ) => Expression | undefined;
}

/** The kinds of `OperandRole` (types-definitions.ts), which imports this
 * file, so the type cannot be named from here. */
type OperandRoleKindMirror =
  'value' | 'held' | 'statement' | 'raw' | 'opaque' | 'bound' | 'clause';

type OperatorDefinitionFlags = {
  lazy: boolean;
  /** The role of each operand of an application. See
   * `types-definitions.ts`. */
  operands?: (
    ops: ReadonlyArray<Expression>
  ) => ReadonlyArray<
    | { kind: Exclude<OperandRoleKindMirror, 'bound' | 'clause'> }
    | { kind: 'bound' | 'clause'; type?: string }
  >;
  scoped: boolean;
  broadcastable: boolean;
  /** Operand/result shapes whose broadcast handling the operator's own
   * handlers provide, exempting them from the generic broadcast machinery.
   * See `types-definitions.ts` for the meaning of each label. */
  broadcastExemptions: ReadonlyArray<
    | 'tensors'
    | 'tuples'
    | 'collection-result'
    | 'evaluated-operands'
    | 'whole-collection-compare'
    | 'single-collection-join'
    | 'surplus-operands'
  >;
  /** Whether a conditional value (a restriction, `Which`) in an operand moves out
   * of the application: `true` for every position, or the 0-based
   * positions. See `types-definitions.ts`. */
  threadsConditionals: boolean | number[];
  inspectsErrors: boolean;
  /** True when this operator decides at evaluation which of its held operands
   * to evaluate, so an error in an operand it does not choose is dead code.
   * Only valid on a `lazy` operator. See `types-definitions.ts`. */
  selectsOperands: boolean;
  /** True when this lazy operator's handler only evaluates its held operands,
   * so the asynchronous route may evaluate them for it. Only valid on a
   * `lazy` operator. See `types-definitions.ts`. */
  evaluatesOperands: boolean;
  /** True when every argument must be written with its parameter's name (an
   * object-type constructor). See `types-definitions.ts`. */
  namedArgumentsRequired: boolean;
  missingBehavior?: 'reject' | 'propagate' | 'handle';
  missingStrip: 'all' | number[];
  /** Per-parameter NaN policy of Contract B (`docs/ERROR-MODEL.md` §4). A
   * single value applies to every slot; an array is per-slot. See
   * `types-definitions.ts`. */
  nanBehavior?:
    | 'reject'
    | 'propagate'
    | 'handle'
    | ReadonlyArray<'reject' | 'propagate' | 'handle' | undefined>;
  /** Contract B partiality claim; omitted means `'may-marker'`. See
   * `types-definitions.ts`. */
  partiality?: 'total' | 'may-marker';
  /** Named mathematical domain condition (false → the codomain marker). See
   * `types-definitions.ts`. */
  definedWhen?: (ops: ReadonlyArray<Expression>) => boolean | undefined;
  /** Contract precondition (false → `Error`). See `types-definitions.ts`. */
  requires?: (ops: ReadonlyArray<Expression>) => boolean | undefined;
  associative: boolean;
  commutative: boolean;
  /** Permutation matching without the canonical sort `commutative` implies.
   * See `types-definitions.ts`. */
  commutativeMatch: boolean;
  commutativeOrder: ((a: Expression, b: Expression) => number) | undefined;
  idempotent: boolean;
  involution: boolean;
  pure: boolean;
  effects: EffectSet | undefined;
  /** True when the author DECLARED the effect set (an effect-bearing signature
   * specifier or the `effects:` field) rather than the body inference having
   * produced it. See `types-definitions.ts`. */
  effectsDeclared: boolean;
  frameProtocol: 'seed' | undefined;
  /** Which operand positions may INVOKE a function-valued operand: a uniform
   * boolean, or a map from 0-based operand index to a boolean whose missing
   * indices default to `true`. Read it through `invokesAt`/`invokesNone`. See
   * `types-definitions.ts`. */
  invokes: boolean | { readonly [operandIndex: number]: boolean };
  /** Per operand position (0-based index), the effects this operator ABSORBS
   * rather than re-emits. See `types-definitions.ts`. */
  discharges:
    { readonly [operandIndex: number]: readonly EffectLabel[] } | undefined;
  /** How a HELD operand position is treated by the projection rule:
   * `'evaluate'` (may-evaluate, the default), `'quote'` (`Hold` — never
   * evaluated, contribution ∅) or `'release'` (`ReleaseHold` — forces a quote,
   * so the projection recurses into the content). See `types-definitions.ts`. */
  holdClass: 'evaluate' | 'quote' | 'release';
  drawsRandom: boolean;
  readsRandomFrame: boolean;
};

type LambdaDefinition = {
  parameters: ReadonlyArray<{
    name: string;
    type: Type | undefined;
    optional?: boolean;
    default?: ParameterDefault;
  }>;
  body: Expression;
};

/** Structural mirrors of the operand-descriptor types
 * (`OperandDescriptor` and friends in `types-definitions.ts`, which imports
 * this file and so cannot be named from here). Keep the two spellings in
 * sync member for member — the interfaces must stay mutually assignable. */
type OperandFactsMirror = {
  readonly finite: boolean | undefined;
  readonly sgn?: Sign;
  readonly closed: boolean | undefined;
  readonly collection: boolean | undefined;
  readonly finiteCollection: boolean | undefined;
  readonly indexed: boolean | undefined;
  readonly shape?: readonly number[];
  readonly elementType?: Type;
};

type OperandStructureMirror =
  /** `local`: the symbol is a block-local binding a `Block` hoisted for a
   * `let` or a block-introducing assignment, still waiting for the statement
   * that gives it a value. Present only when true. `free`: the symbol is free (no
   * value, not a constant, not a wildcard, not a function-literal
   * parameter, a block local or a binder variable). Present only when true.
   * The list-literal type handler reads an unknown symbol as a number cell
   * only when it is present. `captured`: the body of a function literal reads
   * the symbol, which has no value and is not a parameter of the literal or
   * a `let` local of the body. Present only when true. */
  | {
      kind: 'symbol';
      name: string;
      system?: boolean;
      inferred?: boolean;
      local?: boolean;
      free?: true;
      captured?: true;
    }
  | { kind: 'string'; text: string }
  | {
      kind: 'number';
      tier: Type;
      literal?: 0 | 1;
      rational?: readonly [bigint, bigint];
    }
  | {
      kind: 'application';
      head: string;
      callee?: OperandDescriptorMirror;
      children: ReadonlyArray<OperandDescriptorMirror>;
    }
  | {
      kind: 'function-literal';
      /** One entry per parameter operand, in order. `rest` marks the REST
       * parameter (`(a, ...rest) => …`): it is always the last entry, it
       * takes no annotation, and it binds a tuple of every argument from its
       * own position onwards rather than occupying one positional slot. A
       * consumer reading arity must therefore treat the entries before it as
       * the required count and admit any number after. `optional` marks a
       * parameter with a default value (`(x, k = 2) => x * k`), and
       * `default` is that value: a call may leave the parameter out, and
       * the parameter then receives its default. The parameters with a
       * default come after the required ones. */
      parameters: ReadonlyArray<{
        name: string;
        annotated?: Type;
        rest?: boolean;
        optional?: boolean;
        default?: ParameterDefault;
      }>;
      body: OperandStructureMirror;
    }
  | {
      kind: 'tuple';
      arity: number;
      elements: ReadonlyArray<OperandDescriptorMirror>;
    }
  | {
      kind: 'list-literal';
      shape: readonly number[];
      elements: ReadonlyArray<OperandDescriptorMirror>;
    };

type OperandDescriptorMirror = {
  readonly type: Type;
  readonly facts: OperandFactsMirror;
  readonly structureOf?: () => OperandStructureMirror | undefined;
};

/** Mirror of `PureEngineView` (types-definitions.ts). The definition view
 * returned by `lookupDefinition` is shallow-readonly, mirroring
 * `ReadonlyDefinitionView`. */
interface PureEngineViewMirror {
  type(type: Type | TypeString | BoxedType): BoxedType;
  readonly _typeResolver: import('../common/type/types.js').TypeResolver;
  readonly tolerance: number;
  readonly strict: boolean;
  readonly _protocolRegistry: Readonly<Record<string, object>>;
  lookupDefinition(id: string):
    | {
        readonly value?: Readonly<BoxedValueDefinition>;
        readonly operator?: Readonly<BoxedOperatorDefinition>;
      }
    | undefined;
}

/** Mirror of the exported `BoxedOperatorDefinition` (types-definitions.ts).
 * A field is declared in four places that must change together: the input
 * `OperatorDefinition` and the runtime `BoxedOperatorDefinition` in
 * `types-definitions.ts`, this copy, and the class in
 * `boxed-expression/boxed-operator-definition.ts`. */
interface BoxedOperatorDefinition
  extends BoxedBaseDefinition, OperatorDefinitionFlags {
  complexity: number;
  inferredSignature: boolean;
  /** History of writes to this definition's signature — see the mirror note
   * on `BoxedValueDefinition._typeProvenance` above.
   * @internal */
  _typeProvenance: TypeProvenanceEntryMirror[] | undefined;
  /** See `OperatorDefinition._derivedSignature` (types-definitions.ts): the
   * pinned signature was derived from an annotated function literal at assign
   * time, not declared by the author. @internal */
  _derivedSignature: boolean;
  /** See `OperatorDefinition._validationSignature` (types-definitions.ts):
   * the signature a call's arguments are validated against, when it differs
   * from `signature`. @internal */
  _validationSignature: Type | undefined;
  /** Declared signature skeleton of a lambda assigned under a signature with
   * `unknown` slots — mirror of the member documented in
   * `types-definitions.ts`. @internal */
  _signatureSkeleton: Type | undefined;
  signature: BoxedType;
  /** Fact-blind signature write — mirror of the member documented in
   * `types-definitions.ts`.
   * @internal */
  _setSignature(thunk: () => BoxedType): void;
  /** The in-place change counter — mirror of the member documented in
   * `types-definitions.ts`.
   * @internal */
  _writeVersion: number;
  /** Whether the definition stated its effects — mirror of the member
   * documented in `types-definitions.ts`.
   * @internal */
  _purityStated: boolean;
  /** Whether a standard library made this definition — mirror of the
   * member documented in `types-definitions.ts`.
   * @internal */
  readonly _standardLibrary: boolean;
  /** The binding sites that the `bound` and `clause` operand roles of a
   * binder declare — `undefined` for an operator that is not a binder.
   * Narrowed to the operand PATH here: `BindingSiteSelector` lives in
   * `boxed-expression/binding-sites.ts`, which imports this file, so the full
   * type is not named here. `readonly BindingSite[]` is assignable to the
   * element shape below. */
  bindingSites?: (
    ops: ReadonlyArray<Expression>,
    phase: 'pre' | 'post'
  ) => readonly {
    readonly path: readonly number[];
    readonly clauseLocal?: boolean;
  }[];
  readonly resolvedMissingBehavior:
    'reject' | 'propagate' | 'handle' | 'pass-through';
  stripsMissingAt(i: number): boolean;

  /** The declared type of parameter position `i` (0-based), or `undefined`
   * for an overload set or a position past a non-variadic signature. */
  declaredParameterTypeAt(i: number): Type | undefined;

  /** True when an absent scalar operand (`Missing`) at position
   * `i` is refused at evaluation with an `incompatible-type` error naming the
   * parameter's type (user decision P2, 2026-10-21). */
  refusesAbsentOperandAt(i: number): boolean;
  /** True for a function literal whose parameter annotations are enforced at
   * a call. See `types-definitions.ts`. */
  readonly enforcesParameterAnnotations: boolean;
  /** True if a conditional value in operand position `i` moves out of the
   * application at evaluation. See `types-definitions.ts`. */
  threadsConditionalsAt(i: number): boolean;
  /** The kind of the role of each operand of `ops`, with the default role
   * for a position that the `operands` handler leaves out, or `undefined`
   * when the definition has no `operands` handler. See
   * `types-definitions.ts`. */
  operandRoles(
    ops: ReadonlyArray<Expression>
  ): ReadonlyArray<OperandRoleKindMirror> | undefined;
  /** The resolved Contract B NaN policy for parameter position `i`. See
   * `types-definitions.ts`. */
  resolvedNanBehaviorAt(
    i: number,
    armSignature?: Type
  ): 'reject' | 'propagate' | 'handle' | 'inert';
  /** The resolved Contract B partiality of the declaration. See
   * `types-definitions.ts`. */
  readonly resolvedPartiality: 'total' | 'may-marker' | 'defined-when';
  /** True for a user-defined callable (lambda, unscoped strict
   * multi-clause) — the Contract B opt-out class. See
   * `types-definitions.ts`. */
  readonly isUserFunctionDefinition: boolean;
  /** The Contract B adjustment to a derived application result type for
   * these arguments. See `types-definitions.ts`. */
  contractBResultAdjustment(
    ops: ReadonlyArray<Expression>,
    armSignature?: Type
  ):
    | 'none'
    | 'is-nan'
    | 'widen-nan'
    | 'widen-nan-cells'
    | 'widen-marker'
    | 'is-marker';
  /** True if operand position `i` may INVOKE a function-valued operand.
   * See `types-definitions.ts`. */
  invokesAt(i: number): boolean;
  /** True when NO operand position invokes — the operator-level pre-gate.
   * See `types-definitions.ts`. */
  readonly invokesNone: boolean;
  readonly lambda: LambdaDefinition | undefined;
  type?: (
    operands: ReadonlyArray<OperandDescriptorMirror>,
    context: {
      engine: PureEngineViewMirror;
      derive: (
        operator: string,
        operands: ReadonlyArray<OperandDescriptorMirror>
      ) => Type | undefined;
    }
  ) => BoxedType | undefined;
  sgn?: (
    ops: ReadonlyArray<Expression>,
    options: { engine: ComputeEngine }
  ) => Sign | undefined;
  /** See `OperatorDefinition.eq` (types-definitions.ts) for `prover`. */
  eq?: (a: Expression, b: Expression, prover?: boolean) => boolean | undefined;
  neq?: (a: Expression, b: Expression) => boolean | undefined;
  /** For an operator that returns a collection but has no `collection`
   * handlers: the element at the 1-based position `index` of the
   * collection that `evaluate()` would produce, built from the operands
   * with no evaluation, or `undefined` when it is not cheaply known. Mirror
   * of the member documented on `OperatorDefinition.elementAt`
   * (types-definitions.ts), which states the contract. */
  elementAt?: (expr: Expression, index: number) => Expression | undefined;
  canonical?: (
    ops: ReadonlyArray<Expression>,
    options: { engine: ComputeEngine; scope: Scope | undefined }
  ) => Expression | null;
  /** The options are `EvaluateHandlerOptions` — spelled out here because that
   * alias lives in `types-definitions.ts`, which imports this file, and
   * because the engine member is narrowed to `ComputeEngine`. Keep
   * the two in sync; `EvaluateHandlerOptions` documents the fields. */
  evaluate?: (
    ops: ReadonlyArray<Expression>,
    options: Partial<EvaluateOptions> & {
      engine: ComputeEngine;
      expression?: Expression;
      precision?: number;
      effects: EffectHandlers;
    }
  ) => Expression | undefined;
  evaluateAsync?: (
    ops: ReadonlyArray<Expression>,
    options: Partial<EvaluateOptions> & {
      engine: ComputeEngine;
      expression?: Expression;
      precision?: number;
      effects: EffectHandlers;
    }
  ) => Promise<Expression | undefined>;
  evalDimension?: (
    ops: ReadonlyArray<Expression>,
    options: Partial<EvaluateOptions> & { engine: ComputeEngine }
  ) => Expression;
  /** The partial derivatives of the operator. Mirror of
   * `OperatorDerivative` (types-definitions.ts, which imports this file, so
   * the alias cannot be named here); that type documents the two forms. */
  derivative?:
    | ReadonlyArray<ExpressionInput | Expression>
    | ((
        ops: ReadonlyArray<Expression>,
        options: { engine: ComputeEngine; argument: number }
      ) => Expression | undefined);
  compile?: OperatorCompileHandler;
  _update(def: unknown): void;
  /** Re-attach the definition's effect set to its signature after the
   * signature object was replaced by type inference. @internal */
  _resyncEffects(): void;
  /** A lazily-evaluated override of this definition's effect set (protocol
   * dispatchers and the lambdas that consult them) — mirror of the member
   * documented in `types-definitions.ts`. @internal */
  _deriveEffects: (() => EffectSet | undefined) | undefined;
  /** The stored function literal a lambda-backed definition was installed
   * from — mirror of the member documented in `types-definitions.ts`.
   * @internal */
  _lambdaLiteral?: Expression;
  /** Opaque snapshot/restore of the fields a provisional re-derivation can
   * mutate — mirror of the members documented in `types-definitions.ts`.
   * @internal */
  _rederivationSnapshot(): unknown;
  /** @internal */
  _restoreRederivationSnapshot(snapshot: unknown): void;
}

type BoxedDefinition =
  { value: BoxedValueDefinition } | { operator: BoxedOperatorDefinition };

type Scope = KernelScope<BoxedDefinition>;
type EvaluateOptions = KernelEvaluateOptions;
type Rule = KernelRule<Expression, ExpressionInput, ComputeEngine>;
type BoxedRule = KernelBoxedRule<Expression, ComputeEngine>;
type BoxedRuleSet = KernelBoxedRuleSet<Expression, ComputeEngine>;

type SimplifyOptions = {
  rules?: null | Rule | ReadonlyArray<BoxedRule | Rule> | BoxedRuleSet;
  costFunction?: (expr: Expression) => number;
  strategy?: 'default' | 'fu' | 'trig';
};

type ExplainOptions = SimplifyOptions & {
  verbosity?: ExplainVerbosity;
  variable?: string | string[];
  order?: number;
};

type Explanation = KernelExplanation<Expression>;

//
// ── Tensor & Compilation Types ──────────────────────────────────────────
//

/** @category Compiling */
export type CompiledType = boolean | number | string | object;

/** @category Compiling */
export type JSSource = string;

/** @category Compiling */
export type CompiledExpression = {
  evaluate?: (scope: { [symbol: string]: Expression }) => number | Expression;
};

/**
 * The context passed to a custom operator {@link OperatorCompileHandler}. A
 * curated, stable subset of the internal compilation target: enough to emit
 * target-specific source without exposing the full internal machinery.
 *
 * @category Compiling
 */
export type OperatorCompileContext = {
  /** The target language, e.g. `"javascript"`, `"glsl"`.
   * Branch on this to emit target-specific source. */
  readonly language: string;
  /** The operand type including facts established by this compilation's local
   * bindings. The expression's type remains the target-independent contract. */
  readonly typeOf?: (expr: Expression) => Type;
};

/**
 * A custom compilation handler for an operator, set on an
 * `OperatorDefinition`. It mirrors a built-in compiled-function handler:
 * it receives the (canonical) operands, a `compile` callback to lower a
 * sub-expression to target source, and the compilation `context` (branch on
 * `context.language`). It returns target source, or `undefined` (or
 * an empty string) to fall back to the target's default compilation of this
 * operator (a `null` returned from untyped JavaScript is tolerated and
 * treated the same).
 *
 * Takes precedence over the target's built-in operator/function mapping and
 * broadcast lowering, so it can override how a built-in operator compiles
 * (e.g. a custom-tolerance `GCD`, or a re-mapped `Add`/`Multiply`/`Power`/
 * relational operator). It does NOT override the structural / control-flow
 * heads (`Sequence`, `Sum`, `Product`, `Function`, `Declare`, `Assign`,
 * `Return`, `Break`, `Continue`, `Loop`, `Comprehension`, `If`, `Which`,
 * `Match`, `Block`), which have their own bespoke lowering; a handler
 * declared on one of those heads is ignored.
 *
 * ```ts
 * ce.declare('MyGcd', {
 *   signature: '(number, number) -> number',
 *   compile: (args, compile, { language }) =>
 *     language === 'javascript'
 *       ? `_gcd(${compile(args[0])}, ${compile(args[1])})`
 *       : undefined,
 * });
 * ```
 *
 * @category Compiling
 */
export type OperatorCompileHandler = (
  args: ReadonlyArray<Expression>,
  compile: (expr: Expression) => string,
  context: OperatorCompileContext
) => string | undefined;

/**
 * Map of `TensorDataType` to JavaScript type.
 *
 * @category Tensors */
export type DataTypeMap = {
  float64: number;
  float32: number;
  int32: number;
  uint8: number;
  complex128: Complex;
  complex64: Complex;
  bool: boolean;
  // string: string;
  expression: Expression;
};

/**
 * The type of the cells in a tensor.
 * @category Tensors */
export type TensorDataType = keyof DataTypeMap;

/** @internal */
export type NestedArray<T> = NestedArray_<T>[];
/** @internal */
export type NestedArray_<T> = T | NestedArray_<T>[];

/**
 * A record representing the type, shape and data of a tensor.
 * @category Tensors */
export interface TensorData<DT extends TensorDataType> {
  dtype: DT;
  shape: number[]; // dimension of each axis
  rank?: number; // number of dimensions
  data: DataTypeMap[DT][]; // flattened data, stored in row-major order
  /**
   * Is the tensor a float tensor? `true` when an entry of the matrix the
   * tensor was packed from is a float (a number literal that is not exact,
   * such as `1.5` or `2.0`), or when the tensor was computed from a float
   * tensor. Every cell of a float tensor is read back as a float, even when
   * its value is an integer: the determinant of `[[1.5, 0], [0, 2]]` is the
   * float `3`, not the exact `3`. Only the numeric dtypes (`float64`,
   * `complex128`, …) use it: a cell of the `expression` dtype keeps its own
   * exactness.
   */
  holdsFloat?: boolean;
}

/** @category Tensors */
export interface TensorField<
  T extends number | Complex | Expression | boolean | string = number,
> {
  readonly one: T;
  readonly zero: T;
  readonly nan: T;

  cast(x: T, dtype: 'float64'): undefined | number;
  cast(x: T, dtype: 'float32'): undefined | number;
  cast(x: T, dtype: 'int32'): undefined | number;
  cast(x: T, dtype: 'uint8'): undefined | number;
  cast(x: T, dtype: 'complex128'): undefined | Complex;
  cast(x: T, dtype: 'complex64'): undefined | Complex;
  cast(x: T, dtype: 'bool'): undefined | boolean;
  // cast(x: T, dtype: 'string'): undefined | string;
  cast(x: T, dtype: 'expression'): undefined | Expression;
  cast(x: T[], dtype: 'float64'): undefined | number[];
  cast(x: T[], dtype: 'float32'): undefined | number[];
  cast(x: T[], dtype: 'int32'): undefined | number[];
  cast(x: T[], dtype: 'uint8'): undefined | number[];
  cast(x: T[], dtype: 'complex128'): undefined | Complex[];
  cast(x: T[], dtype: 'complex64'): undefined | Complex[];
  cast(x: T[], dtype: 'bool'): undefined | boolean[];
  // cast(x: T[], dtype: 'string'): undefined | string[];
  cast(x: T[], dtype: 'expression'): undefined | Expression[];
  cast(
    x: T | T[],
    dtype: TensorDataType
  ):
    | undefined
    | Complex
    | number
    | boolean
    // | string
    | Expression
    | Complex[]
    | number[]
    | boolean[]
    // | string[]
    | Expression[];

  // Synonym for `cast(x, 'expression')`
  expression(x: T): Expression;

  isZero(x: T): boolean;
  isOne(x: T): boolean;

  equals(lhs: T, rhs: T): boolean;

  add(lhs: T, rhs: T): T;
  addn(...xs: T[]): T;
  neg(x: T): T;
  sub(lhs: T, rhs: T): T;
  mul(lhs: T, rhs: T): T;
  muln(...xs: T[]): T;
  div(lhs: T, rhs: T): T;
  pow(rhs: T, n: number): T;
  conjugate(x: T): T;
}

/**
 * @category Tensors
 */

export interface Tensor<DT extends TensorDataType> extends TensorData<DT> {
  dtype: DT;
  shape: number[];
  rank: number;
  data: DataTypeMap[DT][];

  readonly field: TensorField<DataTypeMap[DT]>;
  readonly expression: Expression;
  readonly array: NestedArray<DataTypeMap[DT]>;
  readonly isSquare: boolean;
  readonly isSymmetric: boolean;
  readonly isSkewSymmetric: boolean;
  readonly isDiagonal: boolean;
  readonly isUpperTriangular: boolean;
  readonly isLowerTriangular: boolean;
  readonly isTriangular: boolean;
  readonly isIdentity: boolean;
  readonly isZero: boolean;

  at(...indices: number[]): DataTypeMap[DT] | undefined;
  diagonal(axis1?: number, axis2?: number): undefined | DataTypeMap[DT][];
  trace(
    axis1?: number,
    axis2?: number
  ): undefined | DataTypeMap[DT] | Tensor<DT>;
  reshape(...shape: number[]): Tensor<DT>;
  slice(index: number): Tensor<DT>;
  flatten(): DataTypeMap[DT][];
  upcast<DT extends TensorDataType>(dtype: DT): Tensor<DT>;
  transpose(axis1?: number, axis2?: number): undefined | Tensor<DT>;
  conjugateTranspose(axis1?: number, axis2?: number): undefined | Tensor<DT>;
  determinant(): undefined | DataTypeMap[DT];
  inverse(): undefined | Tensor<DT>;
  pseudoInverse(): undefined | Tensor<DT>;
  adjugateMatrix(): undefined | Tensor<DT>;
  minor(axis1: number, axis2: number): undefined | DataTypeMap[DT];
  map1(
    fn: (lhs: DataTypeMap[DT], rhs: DataTypeMap[DT]) => DataTypeMap[DT],
    scalar: DataTypeMap[DT]
  ): Tensor<DT>;
  map2(
    fn: (lhs: DataTypeMap[DT], rhs: DataTypeMap[DT]) => DataTypeMap[DT],
    rhs: Tensor<DT>
  ): Tensor<DT>;

  add(other: Tensor<DT> | DataTypeMap[DT]): Tensor<DT>;
  subtract(other: Tensor<DT> | DataTypeMap[DT]): Tensor<DT>;
  multiply(other: Tensor<DT> | DataTypeMap[DT]): Tensor<DT>; // Hadamard product
  divide(other: Tensor<DT> | DataTypeMap[DT]): Tensor<DT>;
  power(other: Tensor<DT> | DataTypeMap[DT]): Tensor<DT>;

  equals(other: Tensor<DT>): boolean;
}

//
// ── Expression ─────────────────────────────────────────────────────
//

/**
 * :::info[THEORY OF OPERATIONS]
 *
 * The `Expression` interface includes the methods and properties
 * applicable to all kinds of expression. For example it includes `expr.symbol`
 * which only applies to symbols or `expr.ops` which only applies to
 * function expressions.
 *
 * When a property is not applicable to this `Expression` its value is
 * `undefined`. For example `expr.symbol` for a `BoxedNumber` is `undefined`.
 *
 * This convention makes it convenient to manipulate expressions without
 * having to check what kind of instance they are before manipulating them.
 * :::
 *
 * :::info[THEORY OF OPERATIONS]
 * A boxed expression can represent a canonical or a non-canonical
 * expression. A non-canonical expression is a "raw" form of the
 * expression. For example, the non-canonical representation of `\frac{10}{20}`
 * is `["Divide", 10, 20]`. The canonical representation of the same
 * expression is the boxed number `1/2`.
 *
 * The canonical representation of symbols and function expressions are
 * bound to a definition. The definition contains metadata about the symbol
 * or function operator, such as its type, its signature, and other attributes.
 * The value of symbols are tracked in a separate table for each
 * evaluation context.
 *
 * The binding only occurs when the expression is constructed, if it is created
 * as a canonical expression. If the expression is constructed as a
 * non-canonical expression, no binding is done.
 *
 * <!--
 * Rules:
 * - nothing should cause the binding to occur outside of the constructor
 * - if an operation require a canonical expression (e.g. evaluate()),
 *  it should return undefined or throw an error if the expression is not
 *   canonical
 * -->
 *
 *
 * :::
 *
 * :::info[THEORY OF OPERATIONS]
 * The **value** of an expression is a number, a string, a boolean or a tensor.
 *
 * The value of number literals and strings are themselves.
 *
 * A symbol can have a value associated with it, in which case the value
 * of the symbol is the value associated with it.
 *
 * Some symbols (unknowns) are purely symbolic and have no value associated
 * with them.
 *
 * Function expressions do not have a value associated with them.
 * For example, `["Add", 2, 3]` has no value associated with it, it is a
 * symbolic expression.
 *
 * Some properties of a Boxed Expression are only applicable if the expression
 * has a value associated with it. For example, `expr.isNumber` is only
 * applicable if the value of the expression is a number, that is if the
 * expression is a number literal or a symbol with a numeric value.
 *
 * The following properties are applicable to expressions with a value:
 * - `expr.isNumber`
 * :::
 *
 * To create a boxed expression:
 *
 * ### `ce.expr()` and `ce.parse()`
 *
 * Use `ce.expr()` or `ce.parse()`.
 *
 * Use `ce.parse()` to get a boxed expression from a LaTeX string.
 * Use `ce.expr()` to get a boxed expression from a MathJSON expression.
 *
 * By default, the result of these methods is a canonical expression. For
 * example, if it is a rational literal, it is reduced to its canonical form.
 * If it is a function expression:
 *    - the arguments are put in canonical form
 *    - the arguments of commutative functions are sorted
 *    - invisible operators are made explicit
 *    - a limited number of core simplifications are applied,
 *      for example rationals are reduced
 *    - sequences are flattened: `["Add", 1, ["Sequence", 2, 3]]` is
 *      transformed to `["Add", 1, 2, 3]`
 *    - associative functions are flattened: `["Add", 1, ["Add", 2, 3]]` is
 *      transformed to `["Add", 1, 2, 3]`
 *    - symbols are **not** replaced with their values (unless they have
 *       a `holdUntil` flag set to `never`).
 *
 * ### `ce.function()`
 *
 * This is a specialized version of `ce.expr()` for creating a new function
 * expression.
 *
 * The canonical handler of the operator is called.
 *
 *
 * ### Algebraic methods (`expr.add()`, `expr.mul()`, etc...)
 *
 * The boxed expression have some algebraic methods, i.e. `add()`, `mul()`,
 * `div()`, `pow()`, etc. These methods are suitable for
 * internal calculations, although they may be used as part of the public
 * API as well.
 *
 *    - a runtime error is thrown if the expression is not canonical
 *    - the arguments are not evaluated
 *    - the canonical handler (of the corresponding operation) is not called
 *    - some additional simplifications over canonicalization are applied.
 *      For example number literals are combined.
 *      However, the result is exact, and no approximation is made. Use `.N()`
 *      to get an approximate value.
 *      This is equivalent to calling `simplify()` on the expression (but
 *      without simplifying the arguments).
 *    - sequences were already flattened as part of the canonicalization process
 *
 * For 'add()' and 'mul()', which take multiple arguments, separate functions
 * are provided that take an array of arguments. They are equivalent
 * to calling the boxed algebraic method, i.e. `ce.Zero.add(1, 2, 3)` and
 * `add(1, 2, 3)` are equivalent.
 *
 * These methods are not equivalent to calling `expr.evaluate()` on the
 * expression: evaluate will replace symbols with their values, and
 * evaluate the expression.
 *
 * For algebraic functions (`add()`, `mul()`, etc..), use the corresponding
 * canonicalization function, i.e. `canonicalAdd(a, b)` instead of
 * `ce.function('Add', [a, b])`.
 *
 * Another option is to use the algebraic methods directly, i.e. `a.add(b)`
 * instead of `ce.function('Add', [a, b])`. However, the algebraic methods will
 * apply further simplifications which may or may not be desirable. For
 * example, number literals will be combined.
 *
 * ### `ce._fn()`
 *
 * This method is a low level method to create a new function expression which
 * is typically invoked in the canonical handler of an operator definition.
 *
 * The arguments are not modified. The expression is not put in canonical
 * form. The canonical handler is *not* called.
 *
 * A canonical flag can be set when calling this method, but it only
 * asserts that the function expression is canonical. The caller is responsible
 * for ensuring that is the case.
 *
 *
 *
 * ### Canonical Handlers
 *
 * Canonical handlers are responsible for:
 *    - validating the signature: this can involve checking the
 *      number of arguments. It is recommended to avoid checking the
 *      type of non-literal arguments, since the type of symbols or
 *      function expressions may change. Similarly, the canonicalization
 *      process should not rely on the value of or assumptions about non-literal
 *      arguments.
 *    - flattening sequences
 *    - flattening arguments if the function is associative
 *    - sort the arguments (if the function is commutative)
 *    - calling `ce._fn()` to create a new function expression
 *
 * When the canonical handler is invoked, the arguments have been put in
 * canonical form unless the `lazy` flag is set to `true`.
 *
 * Note that the result of a canonical handler should be a canonical expression,
 * but not all arguments need to be canonical. For example, the arguments of
 * `["Declare", "x", 2]` are not canonical, since `x` refers to the name
 * of the symbol, not its value.
 *
 * @category Boxed Expression
 *
 */

/**
 * Lower and upper bounds for a symbol extracted from a domain restriction.
 *
 * `lowerStrict`/`upperStrict` are `true` for strict (`<`, `>`) bounds and
 * `false` (or `undefined`) for non-strict (`≤`, `≥`) bounds.
 *
 * @category Boxed Expression
 */
export type IntervalBounds = {
  lower?: Expression;
  lowerStrict?: boolean;
  upper?: Expression;
  upperStrict?: boolean;
};

/**
 * The collection shape that an expression promises before it is evaluated.
 * See `Expression.staticShape`.
 *
 * @category Boxed Expression
 */
export type StaticShape = {
  /** True when the shape is an indexed collection (a list, vector, matrix, tuple, range or string), false for a set or a keyed collection. */
  readonly indexed: boolean;
  /** The number of elements the shape names (`vector<T^3>`, a tuple, the count of a collection value), or `undefined`. */
  readonly count: number | bigint | undefined;
  /** The element type, or `undefined` when the shape does not name one. */
  readonly elementType: Type | undefined;
};

export interface Expression {
  /** @internal */
  readonly _kind: string;

  /**
   * The handler-visible type of a number literal, or `undefined` for every
   * other expression (including a symbol whose *value* is a literal: a
   * symbol's type is its declared or inferred type).
   *
   * Type handlers read their operands' types through this channel (see
   * `handlerTypeOf()` in `library/type-handlers.ts`): for a literal it
   * carries the value itself (`21`, `0.5` as value types, an exact
   * machine-representable rational as a singleton range such as
   * `rational<0.5..0.5>`); when no machine number holds the value
   * exactly it carries a compact outward enclosure on the literal's tier
   * (`real<1.4..1.5>` for `√2`), falling back to a sign range
   * (`integer<0..> & !0` for `10⁴⁰⁰`) when the magnitude is
   * outside the double range. Since ruling O9's second half (2026-08-23)
   * the PUBLIC `.type` of a number literal is this literal type too;
   * every handler result is still widened back to ordinary types before
   * it is stored (`widenValueTypes`, `common/type/widen-value.ts`).
   *
   * Ruling O9 (first half), 2026-08-22:
   * `docs/plans/2026-08-22-type-handlers-on-types.md` §4.3 and §6.
   * @internal */
  readonly _literalType: Type | undefined;

  /**
   * A structural hash of this expression, suitable as an **in-memory**
   * bucketing or cache key with a deep compare on hit.
   *
   * The contract:
   *
   * - **Invariant**: if `a.isSame(b)` is `true`, then `a.hash === b.hash`.
   *   The hash is the structural tier's companion — a pure function of the
   *   canonical tree. A symbol's assigned value never affects it.
   *
   * - **Stability**: deterministic within a release — the same canonical
   *   tree yields the same hash across engine instances and processes, as
   *   it is computed from structure and strings only, with no engine state.
   *   **Not stable across releases**: the hash function may change in any
   *   release, so a cache keyed on it must not outlive the engine build.
   *   Never persist it.
   *
   * - **Collisions**: a 32-bit-class, bucketing-grade hash. Distinct
   *   expressions may share a hash; always verify a hash hit with
   *   `isSame()` (or another structural compare) before treating two
   *   expressions as identical.
   *
   * - **Bound variables**: folds bound-variable _names_ (binding-identity,
   *   not alpha-equivalence), matching `isSame()`: `Sum(i, i in 1..n)` and
   *   `Sum(j, j in 1..n)` hash differently, just as they are not `isSame()`.
   *   This clause co-evolves with `isSame()` semantics.
   *
   * - **Ranges and lists**: a finite `Range` whose bounds and step are
   *   integer literals and that has at most 10,000 elements is `isSame()` to
   *   the `List` of its integers, so it has the hash of that list:
   *   `Range(1, 3)` and `[1, 2, 3]` have the same hash. A character and a
   *   one-cluster string with the same content also have the same hash.
   */
  readonly hash: number;

  /**
   * A 128-bit digest of this expression's **serialized structure** — the
   * MathJSON `.json` writes — as 32 hexadecimal characters: an **in-memory
   * cache key** that needs no compare on hit, computed without writing the
   * MathJSON out.
   *
   * It replaces `JSON.stringify(expr.json)` as a key, and keys the same
   * way: two expressions digest alike exactly when their MathJSON is the
   * same tree (a collision between two distinct trees is not expected in
   * practice — 128 bits from a non-cryptographic mixer, on the engine's own
   * serializations), with two deliberate exceptions where the digest is
   * coarser than the text — a dictionary's entry order does not enter it,
   * and a character digests like the one-cluster string with the same
   * content, as the two are the same value.
   *
   * It is therefore **not an `isSame` key**, in both directions, and
   * `hash` remains the `isSame` companion:
   * - two symbols of the same name digest alike whatever they are bound to
   *   (a symbol serializes as its name), even when `isSame` — which reads
   *   binding identity — says they differ;
   * - the exact rational `1/2` and the float `0.5` are `isSame` but
   *   serialize apart, and digest apart.
   *
   * - **Cost**: memoized per node, so it is linear in the DISTINCT nodes of
   *   the expression — except at and above a mutable object, whose record
   *   snapshot is read fresh like `.json`, so a store to it is seen by every
   *   node that contains it. `JSON.stringify(expr.json)` is
   *   linear in the PATHS, which on a value that shares its sub-expressions
   *   is exponential in the depth.
   * - **Stability**: deterministic within a release, across engine
   *   instances and processes. **Not stable across releases** and not
   *   cryptographic: never persist it, never use it to authenticate.
   * - **Bound variables**: folds bound-variable names, as the MathJSON does.
   */
  readonly digest: string;

  /**
   * The Compute Engine instance associated with this expression provides
   * a context in which to interpret it, such as definition of symbols
   * and functions.
   */
  readonly engine: ComputeEngine;

  /**
   *
   * Return a JavaScript primitive value for the expression, based on
   * `Object.valueOf()`.
   *
   * This method is intended to make it easier to work with JavaScript
   * primitives, for example when mixing JavaScript computations with
   * symbolic computations from the Compute Engine.
   *
   * If the expression is a **machine number**, a **bignum**, or a **rational**
   * that can be converted to a machine number, return a JavaScript `number`.
   * This conversion may result in a loss of precision.
   *
   * If the expression is the **symbol `"True"`** or the **symbol `"False"`**,
   * return `true` or `false`, respectively.
   *
   * If the expression is a **symbol with a numeric value**, return the numeric
   * value of the symbol.
   *
   * If the expression is a **string literal**, return the string value.
   *
   * If the expression is a **tensor** (list of number or multidimensional
   * array or matrix), return an array of numbers, or an array of
   * arrays of numbers, or an array of arrays of arrays of numbers.
   *
   * If the expression is a function expression return a string representation
   * of the expression.
   *
   * @category Primitive Methods
   */
  valueOf(): number | number[] | number[][] | number[][][] | string | boolean;

  /** Similar to`expr.valueOf()` but includes a hint.
   *
   * @category Primitive Methods
   */
  [Symbol.toPrimitive](
    hint: 'number' | 'string' | 'default'
  ): number | string | null;

  /**
   * Return an ASCIIMath representation of the expression. This string is
   * suitable to be output to the console for debugging, for example.
   *
   * Based on `Object.toString()`.
   *
   * To get a LaTeX representation of the expression, use `expr.latex`.
   *
   * Note that lazy collections are eagerly evaluated.
   *
   * Used when coercing a `Expression` to a `String`.
   *
   * For arbitrary-precision numbers (`BigNumericValue`), the output is
   * rounded to `BigDecimal.precision` significant digits. Digits beyond the
   * working precision are noise from precision-bounded operations (division,
   * transcendentals) and are not displayed. Machine-precision numbers use
   * their native `Number.toString()`.
   *
   * @category Primitive Methods
   */
  toString(): string;

  /** Used by `JSON.stringify()` to serialize this object to JSON.
   *
   * Method version of `expr.json`.
   *
   * Based on `Object.toJSON()`.
   *
   * Note that lazy collections are *not* eagerly evaluated.
   *
   * The output preserves the full raw `BigDecimal` value with no rounding,
   * ensuring lossless round-tripping via `ce.expr(expr.json)`. Digits beyond
   * `ce.precision` may be present but are not guaranteed to be accurate.
   * Use `toMathJson({ digits: 'auto' })` for precision-rounded
   * MathJSON output.
   *
   * @category Primitive Methods
   */
  toJSON(): MathJsonExpression;

  /**
   * Serialize to a MathJSON expression with specified options.
   *
   * Use `{ digits: 'auto' }` to round arbitrary-precision
   * numbers to `ce.precision` significant digits. The default
   * (`'max'`) emits all available digits with no rounding.
   */
  toMathJson(
    options?: Readonly<Partial<JsonSerializationOptions>>
  ): MathJsonExpression;

  /** MathJSON representation of this expression.
   *
   * This representation always use shorthands when possible. Metadata is not
   * included.
   *
   * Numbers are converted to JavaScript numbers and may lose precision.
   *
   * The expression is represented exactly and no sugaring is applied. For
   * example, `["Power", "x", 2]` is not represented as `["Square", "x"]`.
   *
   * For more control over the serialization, use `expr.toMathJson()`.
   *
   * Note that lazy collections are *not* eagerly evaluated.
   *
   * For arbitrary-precision numbers, the full raw `BigDecimal` value is
   * emitted with no rounding (same as `toJSON()`). This preserves data
   * fidelity for round-tripping but may include trailing digits beyond
   * `ce.precision` that are not meaningful. Use
   * `toMathJson({ digits: 'auto' })` for rounded output.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   *
   */
  readonly json: MathJsonExpression;

  /**
   * Return a LaTeX representation of this expression.
   *
   * This is a convenience getter that delegates to the standalone
   * `serialize()` function from the `latex-syntax` module.
   *
   * Numeric values are rounded to `ce.precision` significant digits.
   * Noise digits from precision-bounded operations (division,
   * transcendentals) are not displayed.
   */
  readonly latex: string;

  /**
   * Return a LaTeX representation of this expression with custom
   * serialization options.
   *
   * Numeric values are rounded to `ce.precision` significant digits.
   */
  // oxlint-disable-next-line typescript/no-explicit-any -- existing serializer options compatibility
  toLatex(options?: Record<string, any>): string;

  /**
   * Output to the console a string representation of the expression.
   *
   * Note that lazy collections are eagerly evaluated when printed.
   *
   */
  print(): void;

  /** If the expression was constructed from a LaTeX string, the verbatim LaTeX
   *  string it was parsed from.
   */
  verbatimLatex?: string;

  /** Source offsets in the original source string, when available. */
  sourceOffsets?: [start: number, end: number];

  /**
   * Parse-time diagnostics collected when the expression was produced by
   * `ce.parse(latex, { diagnostics: true })`.
   *
   * This property is present (as a possibly-empty, frozen array) **only** on
   * the top-level expression returned by a `diagnostics: true` parse; it is
   * `undefined` everywhere else (sub-expressions, and any expression parsed
   * without the flag). Diagnostics are purely additive metadata: enabling them
   * never changes the parse output.
   *
   * See {@link ParseDiagnostic} for the code enumeration and span conventions.
   *
   * @category Latex Parsing and Serialization
   */
  parseDiagnostics?: ReadonlyArray<ParseDiagnostic>;

  /** If `true`, this expression is in a canonical form. */
  get isCanonical(): boolean;

  /** For internal use only, set when a canonical expression is created.
   * @internal
   */
  set isCanonical(val: boolean);

  /** If `true`, this expression is in a structural form.
   *
   * The structural form of an expression is used when applying rules to
   * an expression. For example, a rational number is represented as a
   * function expression instead of a `Expression` object.
   *
   */
  get isStructural(): boolean;

  /**
   * Return the canonical form of this expression.
   *
   * If a function expression or symbol, they are first bound with a definition
   * in the current scope.
   *
   * When determining the canonical form the following operator definition
   * flags are applied:
   * - `associative`: \\( f(a, f(b), c) \longrightarrow f(a, b, c) \\)
   * - `idempotent`: \\( f(f(a)) \longrightarrow f(a) \\)
   * - `involution`: \\( f(f(a)) \longrightarrow a \\)
   * - `commutative`: sort the arguments.
   *
   * If this expression is already canonical, the value of canonical is
   * `this`.
   *
   * The arguments of a canonical function expression may not all be
   * canonical, for example in the `["Declare", "i", 2]` expression,
   * `i` is not canonical since it is used only as the name of a symbol, not
   * as a (potentially) existing symbol.
   *
   * :::info[Note]
   * Partially canonical expressions, such as those produced through
   * `CanonicalForm`, also yield an expression which is marked as `canonical`.
   * This means that, likewise for partially canonical expressions, the
   * `canonical` property will return the self-same expression (and
   * 'isCanonical' will also be true).
   * :::
   *
   */
  get canonical(): Expression;

  /**
   * Return the structural form of this expression.
   *
   * Some expressions, such as rational numbers, are represented with
   * a `Expression` object. In some cases, for example when doing a
   * structural comparison of two expressions, it is useful to have a
   * structural representation of the expression where the rational numbers
   * is represented by a function expression instead.
   *
   * If there is a structural representation of the expression, return it,
   * otherwise return `this`.
   *
   */
  get structural(): Expression;

  /** `false` if this expression or any of its subexpressions is an `["Error"]`
   * expression.
   *
   * The check is **deep**: an `["Error"]` anywhere in the expression tree
   * invalidates the whole expression. This includes the *elements* of a list,
   * vector or matrix — `(1,2) + [3,4]` broadcasts to a list of
   * `incompatible-type` errors, and that list is invalid — and operands held
   * unevaluated, such as the body of a `["Hold"]`.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions. For
   * non-canonical expression, this may indicate a syntax error while parsing
   * LaTeX. For canonical expression, this may indicate argument type
   * mismatch, or missing or unexpected arguments.
   * :::
   *
   * This is a check for **well-formedness, not for meaningfulness**: it
   * answers "is this expression free of errors?", not "will it evaluate to a
   * useful value?". An expression is still valid when it contains free
   * symbols (`x + 1`), calls an undeclared function, or evaluates to `NaN` or
   * `±∞` (`0/0` and `1/0` are both valid). Conversely, a valid expression may
   * still fail to evaluate for reasons this property does not report.
   *
   * Use it as an **admission gate** — check `isValid` before compiling,
   * plotting, or otherwise consuming an expression built from untrusted or
   * user-supplied input, since malformed input surfaces as an `["Error"]`
   * expression rather than as a thrown exception. To find out *what* is
   * wrong, walk the expression for `["Error"]` subexpressions; each carries
   * an error code and the offending operand.
   *
   */
  readonly isValid: boolean;

  /** If *true*, evaluating this expression has no side-effects (does not
   * change the state of the Compute Engine).
   *
   * If *false*, evaluating this expression may change the state of the
   * Compute Engine or it may return a different value each time it is
   * evaluated, even if the state of the Compute Engine is the same.
   *
   * As an example, the `["Add", 2, 3]` function expression is pure, but
   * the `["Random"]` function expression is not pure.
   *
   * For a function expression to be pure, the function itself (its operator)
   * must be pure, and all of its arguments must be pure too.
   *
   * A pure function expression may return a different value each time it is
   * evaluated if its arguments are not constant. For example, the
   * `["Add", "x", 1]` function expression is pure, but it is not
   * constant, because `x` is not constant.
   *
   * :::info[Note]
   * Applicable to canonical expressions only
   * :::
   *
   * Since Stage 2 of the effects model this is a **view** of the runtime
   * effect channel: "no impurity label in `effectsOf(expr)`" (see
   * `boxed-expression/effects-of.ts`).
   */
  readonly isPure: boolean;

  /**
   * The effects of **evaluating** this expression: `undefined` when there are
   * none (the expression is pure), `'any'` when the effects are not known, or
   * the effect labels in alphabetical order.
   *
   * This is the set `isPure` summarizes — `isPure` is "no impurity label in
   * here" — but it says *which* effects, so a consumer can act on them: a
   * `scope` write invalidates a memo, `random` means the value will differ on
   * re-evaluation, `network` means evaluating may be slow or may fail.
   *
   * It reports what evaluating this expression **does**, not what the value it
   * produces **can do** if you later invoke it. A symbol bound to a drawing
   * function has no effects — evaluating it just yields the function — while
   * its *type* carries the draw:
   *
   * ```ts
   * ce.assign('rf', ce.box(['Function', ['Random'], 'x']));
   * ce.box('rf').effects;           // ➔ undefined  (producing the value)
   * ce.box('rf').isPure;            // ➔ true
   * ce.box('rf').type.effects;      // ➔ ['random'] (invoking it)
   * ce.box(['Map', xs, 'rf']).effects; // ➔ ['random'] (Map invokes it)
   * ```
   *
   * Numbers, strings, symbols and dictionaries have no effects. See
   * `docs/EFFECTS-MODEL.md` ("Projection and discharge") for how an
   * application's effects are computed from its operator and operands.
   */
  readonly effects: ReadonlyArray<EffectLabel> | 'any' | undefined;

  /**
   * The memoized runtime effect channel of a function expression — the
   * projection rule of `docs/EFFECTS-MODEL.md` ("Projection and discharge"),
   * cached with a generation guard. Present only on function expressions; use
   * `effectsOf()` (`boxed-expression/effects-of.ts`) rather than calling it.
   *
   * @internal
   */
  _effectsOf?(): ComputedEffects;

  /**
   * The effects on the arrow of a function literal (an expression whose
   * operator is `Function`), in canonical form: the effect slot of its
   * signature type, computed without the rest of the type when the type is
   * not in its cache. Present only on function expressions.
   *
   * @internal
   */
  _literalArrowEffects?(): EffectSet | undefined;

  /**
   * `True` if evaluating this expression always returns the same value.
   *
   * If *true* and a function expression, implies that it is *pure* and
   * that all of its arguments are constant.
   *
   * Number literals, symbols with constant values, and pure numeric functions
   * with constant arguments are all *constant*, i.e.:
   * - `42` is constant
   * - `Pi` is constant
   * - `["Divide", "Pi", 2]` is constant
   * - `x` is not constant, unless declared with a constant flag.
   * - `["Add", "x", 2]` is either constant only if `x` is constant.
   */
  readonly isConstant: boolean;

  /** All the `["Error"]` subexpressions.
   *
   * If an expression includes an error, the expression is also an error.
   * In that case, the `this.isValid` property is `false`.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   *
   */
  readonly errors: ReadonlyArray<Expression>;

  /** All the subexpressions matching the named operator, recursively.
   *
   * Example:
   *
   * ```js
   * const expr = ce.parse('a + b * c + d');
   * const subexpressions = expr.getSubexpressions('Add');
   * // -> `[['Add', 'a', 'b'], ['Add', 'c', 'd']]`
   * ```
   *
   * The walk continues into the values of a dictionary. A function
   * expression or a dictionary that occurs several times as the SAME object
   * (a shared subexpression) is listed once.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   *
   */
  getSubexpressions(operator: string): ReadonlyArray<Expression>;

  /** All the subexpressions in this expression, recursively
   *
   * Example:
   *
   * ```js
   * const expr = ce.parse('a + b * c + d');
   * const subexpressions = expr.subexpressions;
   * // -> `[['Add', 'a', 'b'], ['Add', 'c', 'd'], 'a', 'b', 'c', 'd']`
   * ```
   *
   * The walk continues into the values of a dictionary. A function
   * expression or a dictionary that occurs several times as the SAME object
   * (a shared subexpression) is listed once.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   *
   */
  readonly subexpressions: ReadonlyArray<Expression>;

  /**
   * All the symbols in the expression, recursively, including
   * bound variables (e.g., summation/product index variables).
   *
   * Use {@link unknowns} or {@link freeVariables} to get only the
   * symbols that are free (not bound by a scoping construct).
   *
   * ```js
   * const expr = ce.parse('a + b * c + d');
   * const symbols = expr.symbols;
   * // -> ['a', 'b', 'c', 'd']
   * ```
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   *
   */
  readonly symbols: ReadonlyArray<string>;

  /**
   * All the symbols used in the expression that do not have a value
   * associated with them, i.e. they are declared but not defined.
   */
  readonly unknowns: ReadonlyArray<string>;

  /**
   * The free variables of the expression: symbols that are not constants,
   * not operators, not bound to a value, and not locally scoped (e.g.,
   * summation/product index variables are excluded).
   *
   * This is an alias for {@link unknowns}.
   */
  readonly freeVariables: ReadonlyArray<string>;

  /**
   * The symbols **defined** by this expression: the target of a top-level
   * `["Assign", …]` or `["Declare", …]` (e.g. `a` in `a := 3`, `f` in
   * `f(x) := …`), recursing through `["Block", …]` sequences. A
   * destructuring target defines each name of its pattern: `a` and `b` in
   * `(a, b) := (1, 2)`. Empty for expressions that define nothing.
   *
   * Complements {@link freeVariables} (the symbols an expression
   * *references*). A tool that builds a dependency graph keyed on cells —
   * e.g. a notebook — can use `defines` for the out-edges and
   * {@link references} for the in-edges.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   */
  readonly defines: ReadonlyArray<string>;

  /**
   * The user functions **applied** in this expression: the operator head of
   * a function application when that head is a user-definable symbol — `f` in
   * `f(x)`, `g` in `g(x) := f(x) + 1`. A user function is listed whether it
   * is undefined, declared, or already defined (`f(x) := …`,
   * `ce.assign("f", …)`). The operators of a library (`Add`, `Sin`, …: the
   * standard library, a library given to the constructor, or one loaded with
   * `ce.loadLibrary()`), constants, and names bound by an enclosing scope of
   * the expression (function parameters, summation indices, `Block` locals) are
   * excluded.
   *
   * Operator heads are not symbols of the expression, so they appear in
   * neither {@link symbols} nor {@link freeVariables}. This accessor recovers
   * the function-call dependency edges those views miss.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   */
  readonly referencedFunctions: ReadonlyArray<string>;

  /**
   * The symbols this expression **references** but does not itself define:
   * every user name it reads, as a value or as an applied function
   * ({@link referencedFunctions}), minus {@link defines}. A name is listed
   * whether or not it already has a value or a definition: after
   * `a := 5`, `g(x) := x + a` still references `a`. This is the difference
   * with {@link freeVariables}, which lists only the symbols that have no
   * value. The names of a library (`Pi`, `Sin`, …: the standard library, a
   * library given to the constructor, or one loaded with
   * `ce.loadLibrary()`), constants, and names bound by the expression itself (parameters, indices, `Block`
   * locals) are excluded.
   *
   * This is the complete in-edge set for a dependency graph keyed on cells
   * (e.g. a notebook): pair it with {@link defines} for the out-edges.
   * Subtracting `defines` drops self-references, so a recursive
   * `g(x) := g(x - 1)` reports no dependency on itself.
   *
   * ```js
   * const cell = ce.parse('g(x) := f(x) + a', { canonical: false });
   * cell.defines;    // -> ['g']
   * cell.references; // -> ['a', 'f']
   * ```
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   */
  readonly references: ReadonlyArray<string>;

  /**
   * Attempt to factor a numeric coefficient `c` and a `rest` out of a
   * canonical expression such that `rest.mul(c)` is equal to `this`.
   *
   * Attempts to make `rest` a positive value (i.e. pulls out negative sign).
   *
   *```json
   * ['Multiply', 2, 'x', 3, 'a']
   *    -> [NumericValue(6), ['Multiply', 'x', 'a']]
   *
   * ['Divide', ['Multiply', 2, 'x'], ['Multiply', 3, 'y', 'a']]
   *    -> [NumericValue({rational: [2, 3]}), ['Divide', 'x', ['Multiply, 'y', 'a']]]
   * ```
   */

  toNumericValue(): [NumericValue, Expression];

  /**
   * If the value of this expression is not an **integer** return `undefined`.
   *
   * @category Numeric Expression
   */
  readonly isEven: boolean | undefined;

  /**
   * If the value of this expression is not an **integer** return `undefined`.
   *
   * @category Numeric Expression
   */
  readonly isOdd: boolean | undefined;

  /**
   * Return the real part of the value of this expression, if a number.
   *
   * Otherwise, return `NaN` (not a number).
   *
   * @category Numeric Expression
   */
  readonly re: number;

  /**
   * If value of this expression is a number, return the imaginary part of the
   * value. If the value is a real number, the imaginary part is 0.
   *
   * Otherwise, return `NaN` (not a number).
   *
   * @category Numeric Expression
   */
  readonly im: number;

  /**
   * If the value of this expression is a number, return the real part of the
   * value as a `BigNum`.
   *
   * If the value is not available as a bignum return `undefined`. That is,
   * the value is not upconverted to a bignum.
   *
   * To get the real value either as a bignum or a number, use
   * `expr.bignumRe ?? expr.re`.
   *
   * When using this pattern, the value is returned as a bignum if available,
   * otherwise as a number or `NaN` if the value is not a number.
   *
   * @category Numeric Expression
   *
   */
  readonly bignumRe: BigNum | undefined;

  /**
   * If the value of this expression is a number, return the imaginary part as
   * a `BigNum`.
   *
   * It may be 0 if the number is real.
   *
   * If the value of the expression is not a number or the value is not
   * available as a bignum return `undefined`. That is, the value is not
   * upconverted to a bignum.
   *
   * To get the imaginary value either as a bignum or a number, use
   * `expr.bignumIm ?? expr.im`.
   *
   * When using this pattern, the value is returned as a bignum if available, otherwise as a number or `NaN` if the value is not a number.
   *
   * @category Numeric Expression
   */
  readonly bignumIm: BigNum | undefined;

  /**
   * Return the sign of the expression.
   *
   * Note that complex numbers have no natural ordering, so if the value is an
   * imaginary number (a complex number with a non-zero imaginary part),
   * `this.sgn` will return `unsigned`.
   *
   * If a symbol, this does take assumptions into account, that is `this.sgn`
   * will return `positive` if the symbol is assumed to be positive
   * using `ce.assume()`.
   *
   * Non-canonical expressions return `undefined`.
   *
   * @category Numeric Expression
   *
   */
  readonly sgn: Sign | undefined;

  /** The value of this expression is > 0, same as `isGreaterEqual(0)`
   *
   * @category Numeric Expression
   */
  readonly isPositive: boolean | undefined;

  /** The value of this expression is >= 0, same as `isGreaterEqual(0)`
   *
   * @category Numeric Expression
   */
  readonly isNonNegative: boolean | undefined;

  /** The value of this expression is &lt; 0, same as `isLess(0)`
   *
   * @category Numeric Expression
   */
  readonly isNegative: boolean | undefined;

  /** The  value of this expression is &lt;= 0, same as `isLessEqual(0)`
   *
   * @category Numeric Expression
   */
  readonly isNonPositive: boolean | undefined;

  /*
   * Algebraic operations
   *
   */
  /** Negate (additive inverse) */
  neg(): Expression;
  /** Inverse (multiplicative inverse) */
  inv(): Expression;
  /** Absolute value */
  abs(): Expression;
  /** Addition */
  add(rhs: number | Expression): Expression;
  /** Subtraction */
  sub(rhs: Expression): Expression;
  /** Multiplication */
  mul(rhs: NumericValue | number | Expression): Expression;
  /** Division */
  div(rhs: number | Expression): Expression;
  /** Power */
  pow(exp: number | Expression): Expression;
  /** Exponentiation */
  root(exp: number | Expression): Expression;
  /** Square root */
  sqrt(): Expression;
  /** Logarithm (natural by default) */
  ln(base?: number | Expression): Expression;
  // exp(): Expression;

  /**
   * Return this expression expressed as a numerator.
   */
  get numerator(): Expression;

  /**
   * Return this expression expressed as a denominator.
   */
  get denominator(): Expression;

  /**
   * Return this expression expressed as a numerator and denominator.
   */
  get numeratorDenominator(): [Expression, Expression];

  /**
   * Return the value of this expression as a pair of integer numerator and
   * denominator, or `null` if the expression is not a rational number.
   *
   * - For a `BoxedNumber` with an exact rational value, extracts from the
   *   numeric representation.
   * - For an integer, returns `[n, 1]`.
   * - For a `Divide` or `Rational` function with integer operands, returns
   *   `[num, den]`.
   * - For everything else, returns `null`.
   *
   * The returned rational is always in lowest terms.
   *
   * ```typescript
   * ce.parse('\\frac{6}{4}').toRational()  // [3, 2]
   * ce.parse('7').toRational()              // [7, 1]
   * ce.parse('x + 1').toRational()          // null
   * ce.number(1.5).toRational()             // null (machine float)
   * ```
   */
  toRational(): [number, number] | null;

  /**
   * Return the multiplicative factors of this expression as a flat array.
   *
   * This is a structural decomposition — it does not perform algebraic
   * factoring (use `ce.function('Factor', [expr])` for that).
   *
   * - `Multiply(a, b, c)` returns `[a, b, c]`
   * - `Negate(x)` returns `[-1, ...x.factors()]`
   * - Anything else returns `[expr]`
   *
   * ```typescript
   * ce.parse('2xyz').factors()     // [2, x, y, z]
   * ce.parse('-3x').factors()      // [-1, 3, x]
   * ce.parse('x + 1').factors()    // [x + 1]
   * ```
   */
  factors(): ReadonlyArray<Expression>;

  /**
   * Return the coefficients of this expression as a polynomial in `variable`,
   * in descending order of degree. Returns `undefined` if the expression is
   * not a polynomial in the given variable.
   *
   * If `variable` is omitted, auto-detects when the expression has exactly
   * one unknown. Returns `undefined` if there are zero or multiple unknowns.
   *
   * ```typescript
   * ce.parse('x^2 + 2x + 1').polynomialCoefficients('x')  // [1, 2, 1]
   * ce.parse('x^3 + 2x + 1').polynomialCoefficients('x')  // [1, 0, 2, 1]
   * ce.parse('sin(x)').polynomialCoefficients('x')          // undefined
   * ce.parse('x^2 + 5').polynomialCoefficients()            // [1, 0, 5]
   * ```
   *
   * Subsumes `isPolynomial`:
   * ```typescript
   * const isPolynomial = expr.polynomialCoefficients('x') !== undefined;
   * ```
   *
   * Subsumes `polynomialDegree`:
   * ```typescript
   * const degree = expr.polynomialCoefficients('x')?.length - 1;
   * ```
   *
   * When `variable` is an array, the expression must be polynomial in ALL
   * listed variables. Coefficients are decomposed by the first variable;
   * remaining variables appear as symbolic coefficients.
   *
   * ```typescript
   * ce.parse('x^2*y + 3x + y^2').polynomialCoefficients(['x', 'y'])
   * // → [y, 3, y²]  (coefficients of x², x¹, x⁰)
   * ```
   */
  polynomialCoefficients(
    variable?: string | string[]
  ): ReadonlyArray<Expression> | undefined;

  /**
   * Return the roots of this expression treated as a polynomial in `variable`.
   * Returns `undefined` if the expression is not a polynomial in the given
   * variable. Returns an empty array if no roots can be found.
   *
   * If `variable` is omitted, auto-detects when the expression has exactly
   * one unknown.
   *
   * ```typescript
   * ce.parse('x^2 - 5x + 6').polynomialRoots('x')  // [2, 3]
   * ce.parse('x^2 + 1').polynomialRoots('x')         // [] (no real roots)
   * ce.parse('sin(x)').polynomialRoots('x')           // undefined
   * ```
   */
  polynomialRoots(variable?: string): ReadonlyArray<Expression> | undefined;

  /**
   * The name of the operator of the expression.
   *
   * For example, the name of the operator of `["Add", 2, 3]` is `"Add"`.
   *
   * A string literal has a `"String"` operator.
   *
   * A symbol has a `"Symbol"` operator.
   *
   * A number has a `"Number"`, `"Real"`, `"Rational"` or `"Integer"` operator; amongst some others.
   * Practically speaking, for fully canonical and valid expressions, all of these are likely to
   * collapse to `"Number"`.
   *
   * @category Function Expression
   */
  readonly operator: string;

  /** If true, the expression has its own local scope that can be used
   * for local variables and arguments. Only true if the expression is a
   * function expression.
   */
  readonly isScoped: boolean;

  /** If this expression has a local scope, return it. */
  get localScope(): Scope | undefined;

  /**
   * Replace all the FREE occurrences of the symbols in the expression as
   * indicated.
   *
   * The occurrences replaced are exactly those that `freeVariables` reports
   * as free. A name bound by a binder is not replaced where the binder binds
   * it: the index of a `Sum`, `Product` or `Comprehension`, the parameter of
   * a `Function` literal, the variable of a definite `Integrate`, a local of
   * a `Block`. So `["Sum", "j", ["Limits", "j", 1, 3]]` is unchanged by
   * `subs({j: 5})`, and in `["Add", "j", ["Sum", "j", ["Limits", "j", 1, 3]]]`
   * only the first `j` is replaced. The bounds of a `Limits` clause of a
   * `Sum`, `Product` or `Integrate` read the enclosing binding, so they are
   * replaced: `["Sum", "j", ["Limits", "j", 1, "j"]]` with `j` replaced by
   * `4` is `["Sum", "j", ["Limits", "j", 1, 4]]`.
   *
   * The variable of `D`, the expansion variable of `Series` and the variable
   * of an indefinite `Integrate` are free: the value of the expression is a
   * function of them. When such a variable is replaced, the expression keeps
   * its variable, and the result is the value of the expression at the
   * point: `["D", ["Power", "x", 2], "x"]` with `x` replaced by `3` is
   * `["EvaluateAt", ["Function", ["D", ["Power", "x", 2], "x"], "x"], 3]`,
   * written `\left.\left(\frac{\mathrm{d}x^2}{\mathrm{d}x}\right)\right|_{x=3}`,
   * which evaluates to `6`. Only the variable itself is applied at a
   * point. The replacement of another name is put in the derivative, the
   * series or the integral before it is computed: `["D", ["Multiply", "y",
   * ["Power", "x", 2]], "x"]` with `y` replaced by `3` is `["D",
   * ["Multiply", 3, ["Power", "x", 2]], "x"]`, and `["D", ["Multiply", "x",
   * "y"], "x"]` with `y` replaced by `x` is `["D", ["Multiply", "x", "x"],
   * "x"]`, which evaluates to `2x`. When more than one such variable is
   * replaced, the `Function` literal has one parameter per variable, the
   * point is a `Tuple`, and all the variables are replaced at the same time:
   * `\left.\left(…\right)\right|_{x=3, y=5}`. A replacement can contain the
   * variable: with `x` replaced by `x + 1`, the `D` above evaluates to
   * `2(x + 1)`, where the `x` of `x + 1` is the `x` of the enclosing scope.
   * When the value has no
   * closed form (`Series(e^{1/x}, x, 0, 3)`), the `EvaluateAt` stays
   * unevaluated. The value of a `Series` at a point keeps its remainder:
   * `Series(sin x, x, 0, 3)` with `x` replaced by `1/2` evaluates to
   * `23/48 + BigO(1/32)`, and with `x` replaced by `0` to `BigO(0)`. Under
   * `.N()` the remainder stays a `BigO` term and the other terms are
   * approximated: the first value is `0.479… + BigO(0.03125)`. Wrap the
   * series in `Normal` to drop the remainder, before or after the
   * substitution. `Normal(Series(sin x, x, 0, 3))` with `x` replaced by
   * `0.5` evaluates to `0.479…` under `.N()`.
   *
   * A `Block` that assigns a variable of an enclosing scope, and can read it
   * before the first assignment, reads its value from outside the block, so
   * the variable is free. A replacement of each occurrence would give an
   * invalid assignment, so the block keeps its occurrences and gets a first
   * statement that assigns the replacement: with `a` declared outside the
   * block, `["Block", ["Assign", "a", ["Add", "a", 1]], "a"]` with `a`
   * replaced by `2` is `["Block", ["Assign", "a", 2], ["Assign", "a", ["Add",
   * "a", 1]], "a"]`, which evaluates to `3`. When it is evaluated, the block
   * writes the variable of the enclosing scope, as the block it replaces
   * does. With several such variables, the first statement assigns them all
   * at the same time: `["Assign", ["Tuple", "a", "b"], ["Tuple", "b",
   * "a"]]` for `a` replaced by `b` and `b` replaced by `a`. A replacement of
   * another name that reads such a variable (`x` replaced by `a` with `a`
   * replaced by `3`) is inserted as it is, and reads the value that the
   * first statement assigns.
   *
   * The substitution avoids variable capture. When a replacement contains a
   * free name that a binder binds, and the substitution replaces an
   * occurrence in the scope of that name, the binder renames the name to a
   * fresh name first: `k` becomes `k_1`, or `k_2` when `k_1` is used in the
   * binder or in a replacement.
   * `["Sum", ["Add", "j", "k"], ["Limits", "k", 1, 3]]` with `j` replaced by
   * `k` is `["Sum", ["Add", "k", "k_1"], ["Limits", "k_1", 1, 3]]`, which
   * evaluates to `3k + 6`, and `["Function", ["Power", "y", "x"], "x"]` with
   * `y` replaced by `x` is the function `x_1 ↦ x^(x_1)`. A named argument of a
   * call of such a renamed function uses the new name of the parameter. A
   * binder with no such name is not renamed and keeps its identity.
   *
   * In two cases a bound name cannot be renamed before the block runs, and
   * the replacement is inserted as it is, so the held block captures the
   * name:
   * - the target of an `Assign` in a `Block` that is not canonical (a held
   *   block), when no `Declare` of the block declares it. The `Assign` makes
   *   a local only when the name is not declared where the block is released.
   *   With `s` declared, `["Hold", ["Block", ["Assign", "s", 3], ["Add", "y",
   *   "s"]]]` with `y` replaced by `s` is `["Hold", ["Block", ["Assign", "s",
   *   3], ["Add", "s", "s"]]]`, and its released value is `6`;
   * - a `Declare` or an `Assign` in an operand of a statement of a held
   *   block (a branch of an `If`): the later reads denote the local only when
   *   that branch runs.
   *
   * The replacement is also inserted as it is in a few other rare cases
   * where a correct rename cannot be decided before the expression runs.
   *
   * `this.replace()` can give a similar result, and it can replace more
   * than symbols, but `this.subs()` is more efficient and simpler. A
   * recursive `replace()` does not skip bound variables and does not rename
   * a binder: it rewrites the structure of the expression. A rule whose
   * match is the symbol `j` replaces the `j` of
   * `["Sum", ["Add", "j", "k"], ["Limits", "k", 1, 3]]` by `k` with no
   * rename, and its result evaluates to `12`. The values of the wildcards of
   * a rule are inserted in its replacement the same way: a binder that the
   * replacement writes binds the names in them.
   *
   * The free symbols of the result are bound in the CURRENT scope, not in the
   * scope the receiver was built in. A node that owns a local scope keeps
   * that scope, so a binder's bound variables go on denoting the binder's own
   * bindings — including for a binder nested inside another one, whose scope
   * chain would otherwise no longer reach the outer binder's index.
   *
   * If `options.canonical` is not set, the result is canonical if `this`
   * is canonical.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   *
   * If this is a function, an empty substitution is given, and the computed value of `canonical`
   * does not differ from that of this expr.: then a call this method is analagous to requesting a
   * *clone*.
   * :::
   *
   */
  subs(
    sub: Substitution<ExpressionInput>,
    options?: { canonical?: CanonicalOptions }
  ): Expression;

  /**
   * Recursively replace all the subexpressions in the expression as indicated.
   *
   * To remove a subexpression, return an empty `["Sequence"]` expression.
   *
   * The `canonical` option is applied to each function subexpression after
   * the substitution is applied.
   *
   * If no `options.canonical` is set, the result is canonical if `this`
   * is canonical.
   *
   * **Default**: `{ canonical: this.isCanonical, recursive: true }`
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   */
  map(
    fn: (expr: Expression) => Expression,
    options?: { canonical: CanonicalOptions; recursive?: boolean }
  ): Expression;

  /**
   * Transform the expression by applying one or more replacement rules:
   *
   * - If the expression matches the `match` pattern and the `condition`
   *  predicate is true, replace it with the `replace` pattern.
   *
   * - If no rules apply, return `null`.
   *
   * The `form` option controls the form of *replacements*. The deprecated
   * `canonical` option is also accepted for backward compatibility; only one
   * of the two may be specified.
   *
   * When neither `form` nor `canonical` is specified, the form of each
   * replacement is determined as follows:
   * 1. the form of the replacement produced by the rule, if it has a
   *    non-`'raw'` form;
   * 2. otherwise, the form of the expression being replaced;
   * 3. otherwise, the replacement is left in its raw form.
   *
   * While the form applies directly to replaced sub-expressions only, a
   * non-`'raw'` form also propagates 'opportunistically' up the expression
   * tree: an expression whose operands all share a form after replacement
   * assumes that form as well. (Specifying `form: 'raw'` disables this
   * propagation.)
   *
   * :::info[Note]
   * Applicable to input expressions of any form.
   *
   * To match a specific symbol (not a wildcard pattern), the `match` must be
   * a `Expression` (e.g., `{ match: ce.expr('x'), replace: ... }`).
   *
   * For simple symbol substitution, consider using `subs()` instead.
   * :::
   */
  replace(
    rules: BoxedRuleSet | Rule | Rule[],
    options?: Partial<ReplaceOptions>
  ): null | Expression;

  /**
   * True if the expression includes a symbol `v` or a function operator `v`.
   *
   * When `v` is an array, true if the expression includes any of the names
   * in `v`.
   *
   * A dictionary is a node with the operator `Dictionary`, and the test
   * looks at the values of its entries. A key is a string, not a symbol, so
   * a key never matches: for `{"a" -> u}`, `has("u")` and
   * `has("Dictionary")` are `true` and `has("a")` is `false`. To test
   * whether a dictionary has a key, use `hasKey()` of
   * `DictionaryInterface`.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   */
  has(v: string | string[]): boolean;

  /** Fast exact structural/symbolic equality check.
   *
   * Returns `true` if the expression is structurally identical to `rhs`.
   * The value of a symbol is never followed: if `one` is assigned `1`,
   * `ce.symbol('one').isSame(1)` is `false`.
   *
   * Two symbols, or two calls, with the same name are the same only when
   * they denote the same binding. A call of the library `Sqrt`, boxed before
   * a user function `Sqrt` is declared in a scope, and a call `Sqrt(y)`
   * boxed in that scope are not the same: they are calls of two different
   * functions. Two calls of the library function are the same, also when
   * they come from two engines. A raw call (boxed with `form: 'raw'`, or
   * held by `Hold`) has no binding: two raw calls are compared by their
   * names, and a raw call is not the same as a canonical call.
   *
   * The elements of a set literal are not ordered, so two sets with the same
   * elements in a different order are the same:
   * `ce.box(['Set', 2, 1]).isSame(ce.box(['Set', 1, 2]))` is `true`. A
   * set-builder (`Set(body, Element(k, S))`) compares its two operands by
   * position.
   *
   * A finite `Range` whose bounds and step are integer literals and that has
   * at most 10,000 elements is the same as the `List` of its integers, and
   * has the same `hash`: `ce.box(['Range', 1, 3]).isSame(ce.box(['List', 1,
   * 2, 3]))` is `true`. A larger range is compared by its operands only.
   * The range and the list are the same only when both are calls of the
   * library functions, or both are raw calls: a raw `Range(1, 3)` is not the
   * same as a canonical `[1, 2, 3]`, and a call of a user function named
   * `Range` is not the same as a list.
   *
   * A character and a one-cluster string with the same content are the same,
   * although their types are different: `ce.string('a')` is the same as
   * `ce.character('a')`.
   *
   * Accepts JavaScript primitives: `number`, `bigint`, `boolean`, `string`.
   *
   * Does **not** evaluate expressions — purely structural.
   *
   * `ce.parse('1+x', {form: 'raw'}).isSame(ce.parse('x+1', {form: 'raw'}))` is `false`.
   *
   * See `expr.is()` for a smart check with numeric evaluation fallback,
   * `expr.isEqual()` for value equality, and `expr.isIdenticallyEqual()` to
   * prove an identity in the free variables.
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   *
   * @category Relational Operator
   */
  isSame(rhs: Expression | number | bigint | boolean | string): boolean;

  /**
   * Smart equality check: structural first, then numeric evaluation fallback.
   * Symmetric: `a.is(b)` always equals `b.is(a)`.
   *
   * First tries an exact structural check (same as `isSame()`). If that fails
   * and the expression is constant (no free variables), evaluates numerically
   * and compares within `engine.tolerance`.
   *
   * For literal numbers compared to primitives (`number`, `bigint`), behaves
   * identically to `isSame()` — no tolerance is applied. Tolerance only
   * applies to expressions that require evaluation (e.g., `\\sin(\\pi)`).
   *
   * ```typescript
   * ce.parse('\\cos(\\frac{\\pi}{2})').is(0)  // true — evaluates, within tolerance
   * ce.number(1e-17).is(0)                     // false — literal, no tolerance
   * ce.parse('x + 1').is(1)                    // false — has free variables
   * ce.parse('\\pi').is(3.14, 0.01)            // true — within custom tolerance
   * ```
   *
   * After the structural check, attempts to expand both sides (distributing
   * products, applying the multinomial theorem, etc.) and re-checks
   * structural equality. This catches equivalences like `(x+1)^2` vs
   * `x^2+2x+1` even when the expression has free variables.
   *
   * When one side is a value of a value kind (a value made by a head
   * declared with an `arithmetic` field), the result is the result of
   * `Equal` for the two sides when the kind type declares `compare` (the
   * `compare` hook orders the two values within the tolerance: `tolerance`,
   * else `engine.tolerance`, also for two exact values), and of `isSame()`
   * otherwise.
   *
   * @param tolerance - If provided, overrides `engine.tolerance` for the
   * numeric comparison. Has no effect when the comparison is structural
   * (i.e., when `isSame()` succeeds or the expression has free variables).
   * When one side is a value of a value kind, it is given to the `compare`
   * hook of the kind (`ArithmeticContext.tolerance`).
   *
   * @category Primitive Methods
   */
  is(
    other: Expression | number | bigint | boolean | string,
    tolerance?: number
  ): boolean;

  /**
   * If this expression matches `pattern`, return a substitution that makes
   * `pattern` equal to `this`. Otherwise return `null`.
   *
   * If `pattern` includes wildcards (symbols that start
   * with `_`), the substitution will include a prop for each matching named
   * wildcard.
   *
   * If this expression matches `pattern` but there are no named wildcards,
   * return the empty substitution, `{}`.
   *
   * `pattern` can be:
   * - A **string** (LaTeX): single-character symbols are auto-converted to
   *   wildcards (e.g., `'ax^2+bx+c'` treats `a`, `b`, `c` as wildcards).
   *   Results use unprefixed keys (`{a: 3}` not `{_a: 3}`) and self-matches
   *   are filtered out. `useVariations` and `matchMissingTerms` default to
   *   `true`. Unprefixed keys are accepted in `substitution`.
   * - A **MathJSON array** (e.g., `['Add', '_a', '_b']`): boxed automatically.
   * - An **Expression**: used directly.
   *
   * Read more about [**patterns and rules**](/compute-engine/guides/patterns-and-rules/).
   *
   * :::info[Note]
   * Applicable to canonical and non-canonical expressions.
   * :::
   *
   */
  match(
    pattern: string | ExpressionInput,
    options?: PatternMatchOptions<Expression>
  ): BoxedSubstitution<Expression> | null;

  /**
   *
   * The **shape** describes the **axes** of the expression, where each axis
   * represent a way to index the elements of the expression.
   *
   * When the expression is a scalar (number), the shape is `[]`.
   *
   * When the expression is a vector of length `n`, the shape is `[n]`.
   *
   * When the expression is a `n` by `m` matrix, the shape is `[n, m]`.
   *
   *
   * @category Tensor Expression
   *
   */
  readonly shape: number[];

  /**
   * The **rank** refers to the number of dimensions (or axes) of the
   * expression.
   *
   * Return 0 for a scalar, 1 for a vector, 2 for a matrix, > 2 for
   * a multidimensional matrix.
   *
   * The rank is equivalent to the length of `expr.shape`
   *
   * :::info[Note]
   * There are several definitions of rank in the literature.
   * For example, the row rank of a matrix is the number of linearly
   * independent rows. The rank can also refer to the number of non-zero
   * singular values of a matrix.
   * :::
   *
   * @category Tensor Expression
   * */
  readonly rank: number;

  /**
   *
   * The value of both expressions are compared.
   *
   * If the expressions cannot be compared, return `undefined`
   *
   * @category Relational Operator
   */
  isLess(other: number | Expression): boolean | undefined;

  /**
   * The value of both expressions are compared.
   *
   * If the expressions cannot be compared, return `undefined`
   * @category Relational Operator
   */
  isLessEqual(other: number | Expression): boolean | undefined;

  /**
   * The value of both expressions are compared.
   *
   * If the expressions cannot be compared, return `undefined`
   * @category Relational Operator
   */
  isGreater(other: number | Expression): boolean | undefined;

  /**
   * The value of both expressions are compared.
   *
   * If the expressions cannot be compared, return `undefined`
   * @category Relational Operator
   */
  isGreaterEqual(other: number | Expression): boolean | undefined;

  /**
   * If true, the value of this expression is a number with no value: either
   * `NaN`.
   *
   * `NaN` ("Not a Number", from the floating point format standard IEEE-754)
   * is the result of a computation with no value, such as `0.0/0.0` or
   * `0/0`, and the marker of an absent numeric operand.
   *
   * Note that if `isNaN` is true, `isNumber` is also true (yes, `NaN` is a
   * number).
   *
   * @category Numeric Expression
   *
   */
  readonly isNaN: boolean | undefined;

  /**
   * The numeric value of this expression is `±Infinity` or ComplexInfinity.
   *
   * @category Numeric Expression
   */
  readonly isInfinity: boolean | undefined;

  /** This expression is a number, but not `±Infinity`, `ComplexInfinity` or
   *  `NaN`
   *
   * @category Numeric Expression
   */
  readonly isFinite: boolean | undefined;

  /**
   * Wikidata identifier.
   *
   * If not a canonical expression, return `undefined`.
   *
   */
  readonly wikidata: string | undefined;

  /** An optional short description if a symbol or function expression.
   *
   * May include markdown. Each string is a paragraph.
   *
   * If not a canonical expression, return `undefined`.
   *
   */
  readonly description: undefined | string[];

  /** An optional URL pointing to more information about the symbol or
   *  function operator.
   *
   * If not a canonical expression, return `undefined`.
   *
   */
  readonly url: string | undefined;

  /** Expressions with a higher complexity score are sorted
   * first in commutative functions
   *
   * If not a canonical expression, return `undefined`.
   */
  readonly complexity: number | undefined;

  /**
   * For symbols and functions, a definition associated with the
   * expression. `this.baseDefinition` is the base class of symbol and function
   * definition.
   *
   * If not a canonical expression, return `undefined`.
   *
   */
  readonly baseDefinition: BoxedBaseDefinition | undefined;

  /**
   * For function expressions, the definition of the operator associated with
   * the expression. For symbols, the definition of the symbol if it is an
   * operator, for example `"Sin"`.
   *
   * If not a canonical expression or not a function expression,
   * its value is `undefined`.
   *
   */
  readonly operatorDefinition: BoxedOperatorDefinition | undefined;

  /**
   * For symbols, a definition associated with the expression, if it is
   * not an operator.
   *
   * If not a canonical expression, or not a value, its value is `undefined`.
   *
   */
  readonly valueDefinition: BoxedValueDefinition | undefined;

  /**
   *
   * Infer the type of this expression.
   *
   * For symbols, inference may take place for undeclared symbols,
   * symbols with an `unknown` type, or symbols with an inferred type.
   *
   * Constant symbols always have a defined type, and will return `false`.
   *
   * For functions, inference only takes place if it has an *inferred
   * signature*.
   *
   *
   * For a successful inference, *narrows* the type for symbols,
   * and for functions, narrows the *(return) type*.
   *
   * Subsequent inferences can be made and will refine previous ones if valid.
   *
   * If the given type is incompatible with the declared or previously inferred
   * type, return `false`.
   *
   * The type is passed as a THUNK, and the implementation calls it inside the
   * write's fact-blind bracket: an inferred type is stored on a definition and
   * outlives the assumptions in force when it was computed, so neither the
   * type nor the narrow/widen decision made from it may see a fact
   * (`docs/plans/2026-08-29-assumptions-as-facts-type.md` §2.4). Put the
   * computation inside the thunk rather than in a variable computed before the
   * call.
   *
   * @internal
   */
  _infer(
    t: () => Type,
    inferenceMode?: 'narrow' | 'widen' | 'replace'
  ): boolean;

  /**
   * Update the definition associated with this expression, using the
   * current scope (`ce.context`).
   *
   * @internal
   */
  _bind(): void;

  /**
   *
   * Reset the cached value associated with this expression.
   *
   * Use when the environment, for example the precision, has changed to
   * force the expression to be re-evaluated.
   *
   * @internal
   */
  _reset(): void;

  /**
   * Return a simpler form of this expression.
   *
   * A series of rewriting rules are applied repeatedly, until no more rules
   * apply.
   *
   * The values assigned to symbols and the assumptions about symbols may be
   * used, for example `expr.isInteger` or `expr.isPositive`.
   *
   * No calculations involving decimal numbers (numbers that are not
   * integers) are performed but exact calculations may be performed,
   * for example:
   *
   * $$ \sin(\frac{\pi}{4}) \longrightarrow \frac{\sqrt{2}}{2} $$.
   *
   * The result is canonical.
   *
   * To manipulate symbolically non-canonical expressions, use `expr.replace()`.
   *
   */
  simplify(options?: Partial<SimplifyOptions>): Expression;

  /**
   * Return a structured, step-by-step explanation of an operation applied
   * to this expression: the textbook chain *expression → step (with a
   * reason) → … → result*.
   *
   * The `operation` defaults to `'simplify'`. The explanation runs the same
   * engine code as the plain method: `explain('simplify').result` is the
   * same value `simplify()` returns.
   *
   * For `'solve'`, the receiver is a univariate equation (or an expression
   * `f`, read as `f = 0`); the unknown is inferred or passed via
   * `options.variable`. Step values are *equations* — the state after each
   * phase (`2x+1=5` → `2x-4=0` → `x=2`), including candidate roots and
   * rejected extraneous candidates — and `result` is a `List` of the same
   * roots `solve()` returns. Systems of equations are not supported yet.
   *
   * For `'D'`, steps are whole-expression states in traversal order: each
   * textbook rule (sum, product, quotient, power, chain, …) first appears
   * with its unresolved sub-derivatives as inert `D(…)` terms, which
   * resolve step by step. The variable is inferred when unambiguous, or
   * passed via `options.variable`; `result` matches evaluating
   * `D(expr, variable)`.
   *
   * Each step carries the expression state after the step, a stable machine
   * `id` (the key for localization and custom copy) and a default English
   * `description`. The `initial` property is the canonical form of this
   * expression — canonicalization happens before the first step is recorded
   * and is not traced.
   *
   * By default the step chain is curated: internal bookkeeping steps are
   * filtered out. Pass `verbosity: 'all'` to get the raw chain (for
   * debugging and rule authoring).
   */
  explain(operation?: ExplainOperation, options?: ExplainOptions): Explanation;

  /**
   * For a relation expression (`Equal`, `Less`, `Greater`, `LessEqual`,
   * `GreaterEqual`, `NotEqual`), return the "signed function" form
   * useful for implicit-surface rendering and region classification:
   *
   * - `Equal(a, b)` → `a - b` (zero on the surface)
   * - `Less(a, b)` / `LessEqual(a, b)` → `a - b` (negative when relation holds)
   * - `Greater(a, b)` / `GreaterEqual(a, b)` → `b - a` (negative when relation holds)
   * - `NotEqual(a, b)` → `a - b` (caller checks ≠ 0)
   *
   * For non-relation expressions, returns `undefined`.
   *
   * Strictness (strict vs non-strict inequality) and direction (less vs
   * greater) are encoded in the original `expr.operator`, not in the
   * returned expression. Callers handling 3D implicit rendering use
   * `expr.operator` for the boundary policy and the signed function for
   * the interior/exterior classification.
   *
   * Notes:
   * - CE canonical form normalizes `GreaterEqual(a, b)` to `LessEqual(b, a)`
   *   (and similarly `Greater` to `Less`). Callers using `toSignedFunction()`
   *   on canonicalized parsed expressions will see `LessEqual`/`Less` rather
   *   than `GreaterEqual`/`Greater`. The signed-function semantics are
   *   preserved through the normalization. The `GreaterEqual`/`Greater`
   *   branches handle non-canonical expressions constructed via
   *   `ce.expr(['GreaterEqual', ...])`.
   * - For chained relations with more than two operands (e.g.
   *   `Less(a, b, c)` from `a < b < c`), only the first pair is used.
   *   The result is the signed function for the first sub-relation only;
   *   3D implicit rendering rarely uses chained relations, but if it
   *   does, callers should decompose first.
   */
  toSignedFunction(): Expression | undefined;

  /**
   * For an expression representing a domain restriction (a restriction whose
   * condition is a comparison or `And` of comparisons over `symbol`, or
   * a bare comparison expression), return the lower/upper bounds for
   * `symbol`. Returns `undefined` if no bounds can be extracted.
   *
   * Supported shapes:
   * - Bare comparisons: `a < x`, `x < b`, etc.
   * - Chained comparisons: `a < x < b` (parsed as `Less(a, x, b)`)
   * - `And(c1, c2, ...)` where each `ci` is a supported shape
   * - `If(cond, e)` — operates on `cond`
   * - `Multiply(f, If(...), ...)` — the Desmos parse shape for
   *   `f(x)\{a < x < b\}`; bounds from each restriction factor are merged
   *
   * `lowerStrict`/`upperStrict` are `true` for strict (`<`, `>`) bounds
   * and `false` for non-strict (`≤`, `≥`).
   *
   * Returns `undefined` for unsupported shapes (e.g. equations, non-linear
   * constraints, comparisons over multiple symbols, disjunctions).
   */
  getInterval(symbol: string): IntervalBounds | undefined;

  /**
   * Return the value of the canonical form of this expression.
   *
   * A pure expression always returns the same value (provided that it
   * remains constant / values of sub-expressions or symbols do not change),
   * and has no side effects.
   *
   * Evaluating an impure expression may return a varying value, and may have
   * some side effects such as adjusting symbol assumptions.
   *
   * To perform approximate calculations, use `expr.N()` instead,
   * or call with `options.numericApproximation` to `true`.
   *
   * It is possible that the result of `expr.evaluate()` may be the same as
   * `expr.simplify()`.
   *
   * The result is in canonical form.
   *
   * **Time and recursion limits**: if the evaluation runs inside an enclosing
   * {@linkcode IComputeEngine.withTimeLimit | ComputeEngine.withTimeLimit}
   * span and exceeds its deadline, spends an enclosing
   * {@linkcode IComputeEngine.withStepBudget | ComputeEngine.withStepBudget}
   * budget, or exceeds the recursion limit, a `CancellationError` is thrown
   * (its `cause` is `'timeout'`, `'step-budget'` or
   * `'recursion-depth-exceeded'`). Catch it to distinguish
   * an interrupted evaluation from a symbolic (inert) result.
   *
   */
  evaluate(options?: Partial<EvaluateOptions>): Expression;

  /** Asynchronous version of `evaluate()`.
   *
   * The `options` argument can include a `signal` property, which is an
   * `AbortSignal` object. If the signal is aborted, a `CancellationError` is thrown.
   *
   * A call made inside a
   * {@linkcode IComputeEngine.withTimeLimit | ComputeEngine.withTimeLimit}
   * (or `withStepBudget`) span keeps the span's limit for the whole
   * evaluation, the parts that run after an `await` included: the limit is
   * read when `evaluateAsync()` is called, not when the span closes. A
   * limit that expires is reported as it is by `evaluate()`.
   * A span around a nested `evaluateAsync(options)` call (from an
   * asynchronous handler, with the options it received) applies to that
   * call until it ends, when it ends sooner than the limit of the
   * evaluation or adds a step budget; the other parts of the evaluation
   * keep their own limit. Nested limits combine: the earlier time limit
   * applies, and a step counts against every step budget in force.
   *
   */
  evaluateAsync(options?: Partial<EvaluateOptions>): Promise<Expression>;

  /** Return a numeric approximation of the canonical form of this expression.
   *
   * Any necessary calculations, including on decimal numbers (non-integers),
   * are performed.
   *
   * The calculations are performed according to the
   * `precision` property of the `ComputeEngine`.
   *
   * To only perform exact calculations, use `this.evaluate()` instead.
   *
   * If the function is not numeric, the result of `this.N()` is the same as
   * `this.evaluate()`.
   *
   * The result is in canonical form.
   *
   * Note on typing (SYMBOLIC P2-24, by design): `N()` produces a float
   * literal, so its `type` can widen relative to the exact input's — e.g.
   * `1/3` has type `rational` while `(1/3).N()` has type
   * `real`. The result type reflects the representation produced,
   * not the mathematical value's tightest type.
   */
  N(): Expression;

  /**
   * If this is an equation, solve the equation for the variables in vars.
   * Otherwise, solve the equation `this = 0` for the variables in vars.
   *
   * For univariate equations, returns an array of solutions (roots). For a
   * trigonometric equation, the array holds the principal roots: one root of
   * each family of roots in one period, with no free parameter
   * (`sin(x) = 1/2` gives `[π/6, 5π/6]`). This is different from the `Solve`
   * operator, which gives the families themselves with a fresh integer
   * parameter `t` (`[π/6 + 2πt, 5π/6 + 2πt]`), so that its list holds every
   * root. Returns `null` when the solver
   * cannot solve the equation, and also when it can find only a part of the
   * roots: when the unknown is in a function that the solver cannot invert
   * and that is not periodic (`(x - 1)·BesselJ(0, x) = 0`), or in a factor of
   * a product that gives no root and is not shown to have none
   * (`(x - 2)(x + e^x) = 0`).
   * For systems of linear equations (List of Equal expressions), returns
   * an object mapping variable names to their values.
   * For non-linear polynomial systems (like xy=6, x+y=5), returns an array
   * of solution objects (multiple solutions possible).
   *
   * ```javascript
   * // Univariate equation
   * const expr = ce.parse("x^2 + 2*x + 1 = 0");
   * console.log(expr.solve("x")); // Returns array of roots
   *
   * // System of linear equations
   * const system = ce.parse("\\begin{cases}x+y=70\\\\2x-4y=80\\end{cases}");
   * console.log(system.solve(["x", "y"])); // Returns { x: 60, y: 10 }
   *
   * // Non-linear polynomial system (product + sum)
   * const nonlinear = ce.parse("\\begin{cases}xy=6\\\\x+y=5\\end{cases}");
   * console.log(nonlinear.solve(["x", "y"])); // Returns [{ x: 2, y: 3 }, { x: 3, y: 2 }]
   * ```
   */
  solve(
    vars?: Iterable<string> | string | Expression | Iterable<Expression>
  ):
    | null
    | ReadonlyArray<Expression>
    | Record<string, Expression>
    | Array<Record<string, Expression>>;

  /**
   * If this expression is a number literal, a string literal or a function
   *  literal, return the expression.
   *
   * If the expression is a symbol, return the value of the symbol.
   *
   * Otherwise, the expression is a symbolic expression, including an unknown
   * symbol, i.e. a symbol with no value, return `undefined`.
   *
   */
  get value(): Expression | undefined;

  /**
   * If this expression is constant (see `isConstant`), return its value,
   * otherwise `undefined`.
   *
   * @category Value Properties
   */
  readonly constantValue: number | boolean | string | object | undefined;

  /**
   * If the expression is a symbol, set the value of the symbol.
   *
   * Will throw a runtime error if either not a symbol, or a symbol with the
   * `constant` flag set to `true`.
   *
   * Setting the value of a symbol results in the forgetting of all assumptions
   * about it in the current scope.
   *
   */
  set value(
    value:
      | boolean
      | string
      | BigNum
      | OneOf<
          [
            { re: number; im: number },
            { num: number; denom: number },
            Expression,
          ]
        >
      | number[]
      | number
      | ExpressionInput
      | undefined
  );

  /**
   *
   * The type of the value of this expression.
   *
   * If a symbol the type of the value of the symbol.
   *
   * If a function expression, the type of the value of the function
   * (the result type).
   *
   * If a symbol with a `"function"` type (a function literal), returns the
   * signature.
   *
   * If not valid, return `"error"`.
   *
   * If the type is not known, return `"unknown"`.
   *
   * @category Type Properties
   */
  get type(): BoxedType;

  set type(type: Type | TypeString | BoxedType);

  /** `true` if the value of this expression is a number.
   *
   *
   * Note that in a fateful twist of cosmic irony, `NaN` ("Not a Number")
   * **is** a number.
   *
   * If `isNumber` is `true`, this indicates that evaluating the expression
   * will return a number.
   *
   * This does not indicate that the expression is a number literal. To check
   * if the expression is a number literal, use `expr.isNumberLiteral`.
   *
   * For example, the expression `["Add", 1, "x"]` is a number if "x" is a
   * number and `expr.isNumber` is `true`, but `isNumberLiteral` is `false`.
   *
   * @category Type Properties
   */
  readonly isNumber: boolean | undefined;

  /**
   *
   * The value of this expression is an element of the set ℤ: ...,-2, -1, 0, 1, 2...
   *
   * Note that ±∞ and NaN are not integers.
   *
   * @category Type Properties
   *
   */
  readonly isInteger: boolean | undefined;

  /** The value of this expression is an element of the set ℚ, p/q with p ∈ ℕ, q ∈ ℤ ⃰  q >= 1
   *
   * Note that every integer is also a rational.
   *
   * This is equivalent to `this.type === "rational" || this.type === "integer"`
   *
   * Note that ±∞ and NaN are not rationals.
   *
   * @category Type Properties
   *
   */
  readonly isRational: boolean | undefined;

  /**
   * The value of this expression is on the **extended real line**: a finite
   * real number, or one of the two signed infinities `+∞` and `-∞`.
   *
   * The unsigned complex infinity `~∞` is **not** on the extended real line,
   * and neither is `NaN`; both answer `false`. A number with a non-zero
   * imaginary part answers `false`.
   *
   * Use this predicate for a gate that must also hold at `±∞` — sign
   * reasoning, the `1/±∞ = 0` fold, a claim that a result is a signed
   * infinity. For a **finite** real, test `this.type.matches("real")`
   * instead: the bare type name `real` denotes the finite reals.
   *
   * @category Type Properties
   */
  readonly isExtendedReal: boolean | undefined;

  /**
   * The value of this expression is a function.
   *
   * This is equivalent to `this.type.matches("function")`, that is, the
   * expression evaluates to a function (for example a symbol bound to a
   * function literal, or a function literal itself).
   *
   * This is distinct from `isFunctionExpression`, which is a *structural*
   * property (`true` when the expression is a function application node such
   * as `["Add", 1, 2]`).
   *
   * @category Type Properties
   */
  readonly isFunction: boolean | undefined;

  /** Mathematical equality (strong equality), that is the value
   * of this expression and the value of `other` are numerically equal.
   *
   * An expression without free variables is evaluated numerically, and the
   * two values are compared. Numbers whose difference is less than
   * `engine.tolerance` are considered equal. This tolerance is set when the
   * `engine.precision` is changed to be such that the last two digits are
   * ignored.
   *
   * Evaluating the expressions may be expensive. Other options to consider
   * to compare two expressions include:
   * - `expr.isSame(other)` for a fast exact structural comparison (no evaluation)
   * - `expr.is(other)` for a smart check that tries structural first, then
   *   numeric evaluation fallback for constant expressions
   * - `expr.isIdenticallyEqual(other)` to prove an identity in the free
   *   variables, such as `(x+1)^2` vs `x^2+2x+1`
   *
   * **Examples**
   *
   * ```js
   * let expr = ce.parse('2 + 2');
   * console.log(expr.isEqual(4)); // true
   * console.log(expr.isSame(4)); // false (structural only)
   * console.log(expr.is(4)); // true (evaluates, within tolerance)
   *
   * expr = ce.parse('4');
   * console.log(expr.isEqual(4)); // true
   * console.log(expr.isSame(4)); // true
   * console.log(expr.is(4)); // true
   *
   * ```
   *
   * **Free variables — "truth under constraints" semantics.** When either
   * expression has free variables, equality means "could these be equal
   * under the current (and possible) constraints?". The result is `true`
   * when the two canonical forms are structurally the same (`x+1` vs `1+x`),
   * and a fact in the assumptions database (`ce.assume(...)`) can decide it
   * either way: after `ce.assume(ce.parse('x = 4'))`, `x+1` vs `5` is
   * `true` and `x` vs `3` is `false`. Anything else is `undefined`, never a
   * definitive `false` — including `x` vs `2`, which an assumption could
   * make true.
   *
   * No identity proof is attempted: `(x+1)^2` vs `x^2+2x+1`, and even
   * `x+x` vs `2x`, are `undefined`. Use `expr.isIdenticallyEqual()` to prove
   * that two expressions are equal for every value of their free variables.
   *
   * @category Relational Operator
   */
  isEqual(other: number | Expression): boolean | undefined;

  /**
   * Identity of this expression and `other` in **all** their free variables,
   * that is `sin(x)^2 + cos(x)^2 ≡ 1`. This is the deepest — and most
   * expensive — of the three equality tiers:
   *
   * | Method | Semantics |
   * | --- | --- |
   * | `expr.isSame(other)` | **Structural**: syntactic equality of the canonical forms. Always decidable, no evaluation. |
   * | `expr.isEqual(other)` | **Arithmetic**: the values are equal (within `engine.tolerance`). |
   * | `expr.isIdenticallyEqual(other)` | **Identity**: the two expressions are equal for every value of their free variables. |
   *
   * Three-valued: `true` when identity could be established, `false` when the
   * expressions are provably different, and `undefined` when neither could be
   * determined. In particular, expressions that merely *disagree* at sampled
   * points (`x+1` vs `x+2`) are `undefined`, not `false`: an assumption could
   * still constrain them equal.
   *
   * Identity is established by stochastic sampling (evaluating both
   * expressions at random points), falling back to a symbolic
   * expand-and-simplify proof. A `true` obtained from sampling alone is
   * therefore a very strong indication, but not a formal proof
   * ([Richardson's theorem](https://en.wikipedia.org/wiki/Richardson%27s_theorem)
   * makes a complete decision procedure impossible).
   *
   * This is the API counterpart of the `IdenticallyEqual` operator (`\equiv`
   * in LaTeX).
   *
   * @category Relational Operator
   */
  isIdenticallyEqual(other: number | Expression): boolean | undefined;

  /**
   * Is `true` if the expression is a collection.
   *
   * When `isCollection` is `true`, the expression:
   *
   * - has an `each()` method that returns a generator over the elements
   *   of the collection.
   * - has a `size` property that returns the number of elements in the
   *   collection.
   * - has a `contains(other)` method that returns `true` if the `other`
   *   expression is in the collection.
   *
   * ## `isCollection` is a CAPABILITY, `type.matches('collection<any>')` is a SHAPE
   *
   * This is the single most common source of collection-handling bugs in the
   * engine, so it is worth stating precisely. The two predicates answer
   * different questions and neither implies the other:
   *
   * - `isCollection` — "can I enumerate this **now**?" It is `false` for a
   *   symbol declared `list<number>`/`vector<2>` that has not been assigned
   *   yet, and for an application whose head returns a collection (`L(1)`
   *   under `L: (number) -> vector<2>`): both are collection-shaped, but
   *   there is nothing to walk. To ask what shape an expression promises
   *   before evaluation (`L(1)` promises an indexed collection of 2
   *   elements), read `staticShape`.
   * - `type.matches('collection<any>')` — "is this operand
   *   collection-**shaped**?" It is `true` for those valueless cases, and
   *   `false` for a materialized collection whose type is top
   *   (`unknown`/`any`), which `isCollection` reports `true`.
   *
   * A shape test should spell the `<any>` FAMILY TOP rather than the bare
   * name. Since 0.160.0 the bare `collection` also matches `list<any>`,
   * `list<nothing>` and `list<integer|missing>`, but the explicit top does
   * not depend on how the bare name is read.
   * (`COLLECTION_SHAPE_TYPE` and friends in `common/type/primitive.ts` are
   * the same tops as `Type` constants, for `isSubtype` call sites.)
   *
   * Pick by the question you are actually asking:
   *
   * - About to call `each()`, `contains()`, `at()`, or read `count` — that is
   *   a capability question. Use `isCollection`.
   * - Deciding whether an operand takes the SCALAR path or the
   *   collection/broadcast path — that is a shape question. Test
   *   `isCollection || type.matches('collection<any>')`, or the operand class
   *   alone with `isValuelessCollectionTyped()` (`collection-utils.ts`).
   *
   * Getting this wrong has a characteristic signature: the operator takes its
   * scalar path for an operand that is not a scalar and commits an answer that
   * the SAME expression contradicts once the symbol is assigned. A 2026-08-15
   * audit of all 95 `isCollection` sites found seven operator families doing
   * exactly that — `Sum(L)` answering `L`, `Union(L, Set(1))` collapsing `L`
   * into a single element, `SetMinus` INVERTING a membership answer,
   * `Mean(L)` committing `NaN`, `Which` throwing on a `list<boolean>`
   * condition. Pinned in
   * `test/compute-engine/valueless-collection-typed-operand.test.ts`, which is
   * the place to add a case if you touch this.
   *
   * A third predicate covers a distinct case: `isPossiblyCollectionTyped()`
   * (`collection-utils.ts`) is for an operand that MIGHT become a collection
   * at runtime — a top-typed application, or a `broadcastable<T>` — where the
   * honest answer is that the shape is not statically visible at all.
   *
   * One more operand class answers a confident `false` to BOTH `isCollection`
   * and `type.matches('collection<any>')` while still being able to hold a
   * collection: a union of a scalar branch and a collection branch — a
   * valueless `u: number | list<number>`, and the `2u` lifted over it, since a
   * broadcast over such an operand carries the union through rather than
   * claiming a definite list. The scalar branch defeats the match, so a gate
   * that must decline for a MAYBE-collection has to ask one of the two
   * union predicates in `collection-utils.ts` as well:
   * `unionMayHoldACollection()` for an ENUMERATION gate (a big op folding its
   * body — tuple, string and fixed-shape branches enumerate too), or
   * `scalarOrCollectionUnionBranches()` for a BROADCAST gate.
   */
  isCollection: boolean;

  /**
   * The collection shape that this expression promises, or `undefined` when
   * it promises no collection.
   *
   * It does not evaluate an application or a symbol. For a collection value
   * it reads the collection facets, and the `count` of a lazy view over an
   * eager source (`Join(f(1), [4])`, a `Filter`) evaluates that source: it
   * calls `f`, or runs the filter's function once per element.
   *
   * `staticShape` answers the SHAPE question: "what does this expression
   * promise to be?". `isCollection` answers the CAPABILITY question: "is a
   * collection value present that I can walk now?". The two differ for an
   * expression that has no value yet:
   *
   * ```js
   * ce.assign('f', ce.parse('n \\mapsto [n, n+1, n+2, n/2]'));
   * const e = ce.box(['f', 3]);
   * e.isCollection;  // false: nothing to walk before evaluation
   * e.count;         // undefined
   * e.staticShape;   // { indexed: true, count: 4, elementType: 'rational' }
   * ```
   *
   * The answer comes from:
   *
   * - the collection facets, when `isCollection` is `true` (a list, a
   *   string, a dictionary, a symbol that holds a collection);
   * - the declared type of a symbol with no collection value
   *   (`L: vector<2>` gives a count of 2). A type that the engine inferred
   *   from the uses of an undeclared name is not a promise;
   * - the static type of an application whose head is bound: a library
   *   operator, a function literal assigned to a name, or a declared
   *   signature. A call of an undeclared name (`foo([1, 2])`) promises
   *   nothing, although its type lifts over the collection argument. A
   *   broadcast (`x + 1`) promises a collection only when one of its
   *   operands promises one. A `missing` or `nothing` arm of the type is an
   *   absence of the whole value and is set aside; a type with a scalar arm
   *   or a string type promises nothing;
   * - the arms of a selection (`If(c, a, b)`, `Which`), when every arm
   *   promises a collection and no arm is a point or a string.
   *
   * `each()` and `at()` give the elements of the VALUE. When the value
   * does not have the declared type, `each()` can give another number of
   * elements than `staticShape.count`; the host must supply values of the
   * declared types.
   */
  readonly staticShape: StaticShape | undefined;

  /**
   * The elements of a `List` as plain machine numbers, or `undefined`.
   *
   * Defined for a `List` whose every element is a machine number: an
   * integer, a finite double, an infinity or `NaN`. A list built by
   * `ce.list()` answers its own frozen array without boxing an element; an
   * ordinary list answers a frozen array computed once from its elements.
   * An element that is not a machine number — an exact rational such as
   * `1/3`, a radical, a bignum with more digits than a double holds, a
   * complex number, a symbol, a nested list — makes the answer `undefined`:
   * the value is never approximated. Evaluate with `.N()` first to get the
   * floats of an exact list.
   *
   * The array is frozen. It may be passed as is into a compiled function's
   * argument bag.
   *
   * :category: Collections
   */
  readonly array: readonly number[] | undefined;

  /**
   * Does `array` reproduce this expression, exactness included?
   *
   * For a `List`: `true` when `array` is defined and `ce.list(expr.array)`
   * is this list element for element, as the interpreter computes with it.
   * A list built by `ce.list()` answers `true` in constant time. An
   * ordinary list answers `true` when every element is a float with a
   * fraction part or an exact integer a double holds. It answers `false`
   * when some element is a float with an integer value, such as `2.0`:
   * `ce.list()` boxes the double `2` as the exact integer `2`. It answers
   * `false` too when some element is an exact non-integer such as the
   * rational `1/2`: `array` admits it, since a
   * double holds `0.5` with no rounding, but re-boxing `0.5` gives a float,
   * which computes as one (`0.5 / 3` is `0.1666…` where `1/2 ÷ 3` is
   * `1/6`). A consumer that must keep exact values exact takes `array` only
   * when this is `true`.
   *
   * For a number: `true` when the number is a float with a fraction part
   * or past the safe integers, an exact integer a double holds, `NaN` or an
   * infinity; `false` for a float with a safe-integer value (`2.0`), an
   * exact non-integer, a radical or a complex number.
   *
   * `false` for every other expression.
   *
   * :category: Collections
   */
  readonly isMachineNumeric: boolean;

  /**
   * Is `true` if this is an indexed collection, such as a list, a vector,
   * a matrix, a tuple, etc...
   *
   * The elements of an indexed collection can be accessed by a one-based
   * index.
   *
   * When `isIndexedCollection` is `true`, the expression:
   * - has an `each()`, `size()` and `contains(rhs)` methods
   *    as for a collection.
   * - has an `at(index: number)` method that returns the element at the
   *    specified index.
   * - has an `indexWhere(predicate: (element: Expression) => boolean)`
   *    method that returns the index of the first element that matches the
   *    predicate.
   */
  isIndexedCollection: boolean;

  /**
   * False if not a collection, or if the elements of the collection
   * are not computed lazily.
   *
   * The elements of a lazy collection are computed on demand, when
   * iterating over the collection using `each()`.
   *
   * Use `ListFrom` and related functions to create eager collections from
   * lazy collections.
   *
   */
  isLazyCollection: boolean;

  /**
   * If this is a collection, return an iterator over the elements of the
   * collection.
   *
   * ```js
   * const expr = ce.parse('[1, 2, 3, 4]');
   * for (const e of expr.each()) {
   *  console.log(e);
   * }
   * ```
   *
   * `each()` gives the elements of the value, and `staticShape.count` gives
   * the number of elements that the expression promises before evaluation.
   * The two can differ when the value does not have the declared type: a
   * call of a function declared `(integer) -> vector<3>` whose body gives
   * two elements has a `staticShape.count` of 3, but its value gives two
   * elements. The host must supply values of the declared types. Read
   * `staticShape` for the promised shape and `each()` for the elements.
   */
  each(): Generator<Expression>;

  /**
   * If this is a collection, return true if the `rhs` expression is in the
   * collection.
   *
   * Return `undefined` if the membership cannot be determined without
   * iterating over the collection.
   */
  contains(rhs: Expression): boolean | undefined;

  /**
   * Check if this collection is a subset of another collection, i.e.
   * `this` ⊆ `other`.
   *
   * Returns `undefined` when the relation cannot be determined — including
   * when this expression is not (yet) a collection.
   *
   * @param other The other collection to check against.
   * @param strict If true, the subset relation is strict (i.e., proper subset).
   */
  subsetOf(other: Expression, strict: boolean): boolean | undefined;

  /**
   * If this is a collection, return the number of elements in the collection.
   *
   * Only top-level elements are counted: for a nested collection (e.g. a
   * matrix represented as a list of lists), this is the number of immediate
   * elements (the rows), not the total number of scalar entries. For example
   * the count of `[[2, 3, 4], [6, 7, 9]]` is 2, not 6. This is consistent
   * with `each()` and `at()`, which iterate over and index the same elements.
   *
   * If the collection is infinite, return `Infinity`.
   *
   * If the number of elements cannot be determined, return `undefined`, for
   * example, if the collection is lazy and not finite and the size cannot
   * be determined without iterating over the collection.
   *
   * For the length that an expression with no value yet promises (a call of
   * a function that returns a list), read `staticShape.count`.
   *
   * The count is a `bigint` only when it is finite and is not a safe integer
   * (larger than `Number.MAX_SAFE_INTEGER`), for example the count of
   * `QuotientRing(Integers, 2^61 - 1)`. A count that is a safe integer is
   * always a `number`, and an infinite count is `Infinity`. Do not mix the
   * count with a `number` in arithmetic before you check its type:
   * JavaScript throws a `TypeError` for `count + 1` when `count` is a
   * `bigint`. A comparison (`count > 10`) is valid for both types.
   *
   */
  get count(): number | bigint | undefined;

  /** If this is a finite collection, return true. */
  isFiniteCollection: boolean | undefined;

  /** If this is an empty collection, return true.
   *
   * An empty collection has a size of 0.
   */
  isEmptyCollection: boolean | undefined;

  /**
   * Whether `each()` yields this collection's actual elements.
   *
   * This is the cheap predicate that separates the two reasons `each()` can
   * produce nothing:
   *
   * - `true`: the elements are enumerable, so a walk that yields nothing
   *   means the collection is **empty**.
   * - `false`: the elements cannot be produced in the current state, so a
   *   walk that yields nothing means **nothing at all**. For example
   *   `Range(a, b)` with free variables, `Repeat(3, n)` with a symbolic
   *   count, or a wrapper over such a source (`Take(Range(a, b), 2)`).
   * - `undefined`: undecidable without evaluating — an *eager* collection
   *   operator (`Characters(s)`, `UnicodeScalars(s)`) has no collection
   *   handlers until it is evaluated, yet `each()` walks it through the
   *   materialize-then-iterate path.
   *
   * An arithmetic **broadcast** (`x + [1, 2]`, `Sin(1..99)` — a
   * `broadcastable` operator whose collection-ness is a lift over its
   * operands) answers from its participants: `true` when they agree on a
   * length, evaluation is draw-free, and every collection-typed participant
   * is itself enumerable; `false` when a participant is definitively
   * unwalkable (a valueless symbol, an application of an UNBOUND head —
   * `x + Total([1, 2])` with `Total` undeclared binds vacuously and can
   * never produce elements); `undefined` when the lengths disagree or an
   * impure participant (`RandomShuffle(xs) + 1`) makes per-index reads
   * unable to promise draw coherence — there `each()` still walks, but
   * `at()` declines. Impurity confined to a *scalar* (lifted) operand does
   * not demote the answer: `[1, 2] + RandomInteger(1, 10)` is `true` — its
   * evaluation distributes structurally without consuming randomness, and
   * both `each()` and `at()` serve the unevaluated elements.
   *
   * Independent of `count`: a collection can know its size and still not be
   * enumerable (`Linspace(a, 1, 3)` has a count of 3 and no computable
   * elements), and an enumerable collection can have an unknown size.
   *
   * Answered structurally, without evaluating: O(1) for a leaf, O(depth) for
   * a chain of wrappers.
   */
  isEnumerableCollection: boolean | undefined;

  /** If this is an indexed collection, return the element at the specified
   *  index. The first element is at index 1.
   *
   * If the index is negative, return the element at index `size() + index + 1`.
   *
   * The last element is at index -1.
   *
   */
  at(index: number): Expression | undefined;

  /** If this is a keyed collection (map, record, tuple), return the value of
   * the corresponding key.
   *
   * If `key` is a `Expression`, it should be a string.
   *
   */
  get(key: string | Expression): Expression | undefined;

  /**
   * If this is an indexed collection, return the index of the first element
   * that matches the predicate.
   *
   */
  indexWhere(predicate: (element: Expression) => boolean): number | undefined;
}

//
// ── Role Interfaces ─────────────────────────────────────────────────────
//
// These interfaces narrow `Expression` to expression-kind-specific
// members.  Use the corresponding type guard (`isNumber`, etc.) to
// narrow an expression, then access these members without `undefined`.
//

/**
 * Narrowed interface for number literal expressions.
 *
 * Obtained via `isNumber()`.
 *
 * @category Boxed Expression
 */
export interface NumberLiteralInterface {
  readonly numericValue: number | NumericValue;
  readonly isExact: boolean;
  /** True if the imaginary part of this number is not zero.
   *
   * Unlike a test of `im !== 0`, this is `true` for an imaginary part too
   * small or too large for a double (the exact `10^{-800}·i`), because it is
   * read from the numeric value itself, not from its double projection
   * `im`. */
  readonly isComplex: boolean;
  readonly isNumberLiteral: true;
}

/**
 * Narrowed interface for symbol expressions.
 *
 * Obtained via `isSymbol()`.
 *
 * @category Boxed Expression
 */
export interface SymbolInterface {
  readonly symbol: string;
}

/**
 * Narrowed interface for function expressions.
 *
 * Obtained via `isFunction()`.
 *
 * @category Boxed Expression
 */
export interface FunctionInterface {
  readonly isFunctionExpression: true;
  readonly ops: ReadonlyArray<Expression>;
  readonly nops: number;
  /**
   * Internal. The numeric store of a `List` built by `ce.list()`: its
   * elements as frozen machine numbers, from which the operands are boxed on
   * the first read of `ops`. `undefined` for every other function
   * expression. A walker that only looks for symbols or effects skips a node
   * with a store instead of reading `ops`, which would box every element.
   * The public view is `array`.
   */
  readonly _numericStore: readonly number[] | undefined;
  /**
   * Internal. Are the integer-valued elements of the numeric store floats?
   * `true` when a float computation produced the store (`2·L` with the
   * element `0.5` holds the float `1`): the operand at that position is
   * then a float, not `engine.number(store[i])`. `false` for `ce.list()`
   * and when there is no store.
   */
  readonly _numericStoreFloats: boolean;
  /**
   * Internal. The exactness of the integer-valued elements of a `List` of
   * machine numbers: `false` exact, `true` floats, `undefined` when the
   * list is not a list of machine numbers or mixes both kinds. See
   * `BoxedFunction._machineFloats`.
   */
  readonly _machineFloats: boolean | undefined;
  /**
   * Internal. Is this node written-out DATA: a canonical `List` or `Tuple`
   * bound to the standard library whose every element is a number literal,
   * a failed cell, or such a `List` or `Tuple` in turn? A failed cell is an
   * `Error` node with no symbol in it, and is data too. Such a node holds no
   * symbol and evaluates to itself. The answer is computed once per node.
   */
  _isLiteralData(): boolean;
  readonly op1: Expression;
  readonly op2: Expression;
  readonly op3: Expression;
}

/**
 * Narrowed interface for string expressions.
 *
 * Obtained via `isString()`.
 *
 * @category Boxed Expression
 */
export interface StringInterface {
  readonly string: string;

  /** The UTF-8 encoding of the string, as a byte buffer. */
  readonly buffer: Uint8Array;

  /** The Unicode scalar values (code points) of the string. */
  readonly unicodeScalars: number[];
}

/**
 * Narrowed interface for a character expression — one NFC-normalized grapheme
 * cluster (UAX #29).
 *
 * Obtained via `isCharacter()`.
 *
 * `string` holds the cluster's content and is deliberately spelled the same as
 * `StringInterface.string`, so a consumer that only needs the text (the
 * `String` interpolation join, `StringJoin`) can read either kind through one
 * property without first deciding which it has.
 *
 * @category Boxed Expression
 */
export interface CharacterInterface {
  /** The content of the character: exactly one grapheme cluster. */
  readonly string: string;

  /** The Unicode scalar values (code points) of the cluster. */
  readonly unicodeScalars: number[];
}

/**
 * Narrowed interface for tensor expressions.
 *
 * Obtained via `isTensor()`.
 *
 * @category Boxed Expression
 */
export interface TensorInterface {
  readonly shape: number[];
  readonly rank: number;
}

/**
 * Narrowed interface for collection expressions.
 *
 * Obtained via `isCollection()`.
 *
 * @category Boxed Expression
 */
export interface CollectionInterface {
  readonly isCollection: true;
  each(): Generator<Expression>;
  contains(rhs: Expression): boolean | undefined;
  subsetOf(other: Expression, strict: boolean): boolean | undefined;
  readonly count: number | bigint | undefined;
  readonly isFiniteCollection: boolean | undefined;
  readonly isEmptyCollection: boolean | undefined;
  readonly isEnumerableCollection: boolean | undefined;
}

/**
 * Narrowed interface for indexed collection expressions (lists, vectors,
 * matrices, tuples).
 *
 * Obtained via `isIndexedCollection()`.
 *
 * @category Boxed Expression
 */
export interface IndexedCollectionInterface extends CollectionInterface {
  readonly isIndexedCollection: true;
  at(index: number): Expression | undefined;
  indexWhere(predicate: (element: Expression) => boolean): number | undefined;
}

/** An expression input is a MathJSON expression which can include some
 * engine expression terms.
 *
 * This is convenient when creating new expressions from portions
 * of an existing `Expression` while avoiding unboxing and reboxing.
 *
 * @category Boxed Expression
 */
export type ExpressionInput =
  | number
  | bigint
  | boolean
  | string
  | BigNum
  | Complex
  | MathJsonNumberObject
  | MathJsonStringObject
  | MathJsonSymbolObject
  | MathJsonFunctionObject
  | MathJsonDictionaryObject
  | readonly [MathJsonSymbol, ...ExpressionInput[]]
  | MathJsonExpression
  | Expression;

/**
 * Narrowed interface for **object** expressions — the engine's one mutable
 * value kind (a reference to a record whose stored fields can be changed in
 * place).
 *
 * Obtained via `isObject()`. The instance IS the heap record: host reference
 * identity of the expression is object identity, so every comparison tier
 * (`isSame`, `isEqual`, `isIdenticallyEqual`) answers `a === b` for objects,
 * and no code path may clone, rebuild or re-box one.
 *
 * The members below are engine-internal (they are how the property-access
 * operators and the serialization walk reach the slots); user code reads and
 * writes fields through the language's property syntax, not through these.
 *
 * Design: `docs/TYPE-SYSTEM.md`;
 * semantics: `docs/TYPE_SYSTEM_ROADMAP.md` Appendix B.
 *
 * @category Boxed Expression
 */
export interface ObjectInterface {
  /** The name of the nominal type this object was constructed with. The
   * resolved type itself is pinned on the instance and returned by `.type`;
   * this is the name that rides serialization (the `Object` provenance head
   * and `CircularReference` markers). */
  readonly typeName: string;

  /** The stored fields, in declared (insertion) order. Read-only from the
   * outside: `_store()` is the sole writer.
   * @internal */
  readonly _slots: ReadonlyMap<string, Expression>;

  /** Per-object cache currency: starts at 0 and increments on every store
   * that actually changes a slot. A cached result derived from this object's
   * fields is valid only while the counter it recorded still matches.
   * @internal */
  readonly _version: number;

  /** Per-engine construction serial, assigned once. Identity-based `hash`
   * derives from it; it never depends on contents.
   * @internal */
  readonly _serial: number;

  /** Read a stored field: a pure load of an already-evaluated value, running
   * no user code. `undefined` if the object has no such field.
   * @internal */
  _field(name: string): Expression | undefined;

  /** The DECLARED type of a stored field, from the layout pinned on this
   * instance (never re-resolved from the type registry by name), or
   * `undefined` for a name the layout does not carry. Consults the layout and
   * not the slots, so it is not a field read and records no dependency.
   * @internal */
  _fieldType(name: string): Type | undefined;

  /** The sole slot writer. Storing the identical node is a total no-op (no
   * version bump, no state event); any other store writes the slot,
   * increments `_version` and reports an `object-store` state event.
   * @internal */
  _store(name: string, value: Expression): void;
}

/** Interface for dictionary-like structures.
 * Use `isDictionary()` to check if an expression is a dictionary.
 */
export interface DictionaryInterface {
  get(key: string): Expression | undefined;
  /** True if the dictionary has an entry with the key `key`.
   *
   * This is the key test. The `has()` method of the expression is the
   * symbol test: on a dictionary it looks for a symbol in the VALUES and
   * never matches a key, because a key is a string, not a symbol. For
   * `{"a" -> u}`, `hasKey("a")` is `true`, `has("a")` is `false` and
   * `has("u")` is `true`.
   */
  hasKey(key: string): boolean;
  get keys(): string[];
  get entries(): [string, Expression][];
  get values(): Expression[];
}

/**
 * These handlers compare two expressions.
 *
 * If only one of the handlers is provided, the other is derived from it.
 *
 * Having both may be useful if comparing non-equality is faster than equality.
 *
 *  @category Definitions
 *
 */
export interface EqHandlers {
  eq: (a: Expression, b: Expression) => boolean | undefined;
  neq: (a: Expression, b: Expression) => boolean | undefined;
}
