import { activationRecordOf } from './boxed-expression/ambient-chain.js';
import { isPendingCallScope } from './pending-call-scopes.js';
import { freeNameWasMade } from './binding-unit.js';
import { noteScopeDeclaration } from './scope-declaration-count.js';
import { noteKindTypeDeclaration } from './boxed-expression/residue-class.js';
import {
  arithmeticOf,
  commitKindRegistration,
  isRegisteredKindTypeRecord,
  prepareKindRegistration,
  unregisterKind,
} from './boxed-expression/value-kinds.js';
import { noteScratchBinding, scratchRootOf } from './scratch-scopes.js';
import type {
  DeclarationOrigin,
  EffectSet,
  FunctionSignature,
  NamedElement,
  Type,
  TypeParameter,
  TypeParamsOption,
  TypeReference,
  TypeString,
} from '../common/type/types.js';
import {
  checkSameUnitRedefinition,
  isSameStatementReRegistration,
} from './declaration-origin.js';
import {
  refreshSumConformances,
  resettleTypeConformances,
} from './engine-protocols.js';
import {
  functionResult,
  hasFunctionSignature,
  isValidType,
  isValidTypeName,
  returnTypeText,
  signatureArms,
  widen,
  containsSignatureArm,
  placeholderSlotsAs,
  withParameterNamesOf,
} from '../common/type/utils.js';
import { parseType, parseTypeParameterClause } from '../common/type/parse.js';
import { clearClauseProvenance } from './clause-identity.js';
import {
  defaultedSlotsAsRequired,
  isSubtype,
  provablyDisjoint,
} from '../common/type/subtype.js';
import { isEffectSubset } from '../common/type/effects.js';
import { recordTypeProvenance } from './boxed-expression/type-provenance.js';
import {
  freeTypeVariables,
  hasFreeTypeVariables,
  isReservedTypeName,
  satisfiesTypeBound,
  substituteTypeVariables,
  TypeVariableError,
  isPolymorphicType,
  markValueVariables,
  validateValueParameters,
  valueVariableNamesOf,
} from '../common/type/instantiate.js';
import { declarationOf, forwardArities } from '../common/type/reference.js';
import { verifyVariance } from '../common/type/variance.js';
import type { VarianceResult } from '../common/type/variance.js';
import { BoxedType } from '../common/type/boxed-type.js';
import {
  resultUnderDeclaredParameters,
  whileDefining,
  withSignatureResult,
} from './boxed-expression/declared-parameter-result.js';
import {
  isLocalBinding,
  markLocalBinding,
} from './boxed-expression/declared-local.js';
import {
  assertSingleArmPolytype,
  EffectContractError,
  inferFunctionLiteralEffects,
  matchesDeclaredTypeAxes,
  storeAdmission,
  hasSignaturePlaceholder,
  presentedValueType,
  refineDeclaredPlaceholders,
  signatureEffects,
  stripArrowEffects,
  withArrowEffects,
} from './boxed-expression/effects-inference.js';
import { noteOverlapAdmitted } from './boxed-expression/store-admission.js';
import {
  constructorAssignmentError,
  declaredTypeError,
  TypeCompatibilityError,
} from './boxed-expression/type-compatibility-error.js';
import {
  provenTypeNode,
  refutingFact,
} from './boxed-expression/constraint-subject.js';
import { osaDistance } from '../common/fuzzy-string-match.js';

import { isValidSymbol, validateSymbol } from '../math-json/symbols.js';
import type { MathJsonExpression, MathJsonSymbol } from '../math-json/types.js';

import type {
  ValueDefinition,
  OperatorDefinition,
  AssignValue,
  Expression,
  ExpressionInput,
  BoxedDefinition,
  BoxedValueDefinition,
  BoxedOperatorDefinition,
  DefinitionSearchResult,
  SymbolDefinitionInput,
  IComputeEngine,
  Scope,
  DeclareOptions,
  OperatorDefinitionPatch,
  CollectionHandlers,
  FunctionInterface,
} from './global-types.js';
import { substituteDeclaredBounds } from './boxed-expression/generic-instantiation.js';

import {
  _BoxedValueDefinition,
  prepareValueWhenBoxed,
  refineConstructorPlaceholder,
  valuePresenceRefinesType,
} from './boxed-expression/boxed-value-definition.js';
import { countDeclaredHolder, uncountRemovedHolder } from './engine-scope.js';
import {
  binderBindingOf,
  callableBindingInContext,
  isParameterActivation,
} from './boxed-expression/binders.js';
import {
  assertNoParameterDefault,
  forgetConstantDeclaration,
  inDeclaringScope,
} from './boxed-expression/parameter-defaults.js';
import { markRetiredBinding } from './boxed-expression/forward-call-reference.js';
import { _removePendingSequence } from './sequence.js';
import { latestDeclaredEffectsSite } from './boxed-expression/effects-provenance.js';
import { isReplaceableOperatorShell } from './boxed-expression/definition-guards.js';
import {
  isValidOperatorDef,
  isValidValueDef,
  isValueDef,
  isOperatorDef,
  updateDef,
  defIsCallableShaped,
} from './boxed-expression/utils.js';
import {
  canonicalFunctionLiteral,
  functionLiteralDefiningScope,
  isApplicableDef,
  kindTypedFunctionLiteral,
  lookup,
} from './function-utils.js';
import {
  extendedLibraryOperator,
  hidesLibraryBinding,
  inSerializationScope,
  markLibraryExtension,
} from './library-shadowing.js';
import { isInferredTypedParameter } from './boxed-expression/inferred-annotations.js';
import {
  hasProvisionalDependents,
  provisionalLiteral,
  registerProvisionalDependents,
  repairProvisionalDependents,
  scopeOfBinding,
  setProvisionalLiteral,
} from './boxed-expression/provisional-application.js';
import {
  assertObjectLayoutIsNominalBody,
  checkTypeConstructorNamespace,
  installConstructorFunction,
  isMintedConstructor,
  loosenMintedConstructor,
  mintTypeConstructor,
} from './type-constructors.js';
import {
  adoptsForeignEngineObject,
  isDictionary,
  isExpression,
  isFunction,
  isNumber,
  isString,
  isSymbol,
} from './boxed-expression/type-guards.js';
import { paramsAreScalar } from './boxed-expression/boxed-function.js';
import {
  functionLiteralArity,
  functionLiteralDeclaredEffects,
  functionLiteralDeclaredSignature,
  functionLiteralParameters,
  functionLiteralReturnType,
  isScalarType,
  mentionsQuantifiedVariable,
  restParameterIndex,
} from './boxed-expression/function-literal.js';
import { typeToString } from '../common/type/serialize.js';
import { ConstantAssignmentError } from './constant-assignment-error.js';
import {
  isMacroDef,
  isMathJsonShape,
  macroWriteError,
  noteMacroDeclared,
} from './boxed-expression/macro.js';
import { withStandardLibraryInstall } from './boxed-expression/host-handler-changes.js';
import { hostCollectionSource } from './boxed-expression/shared-evaluation-memo.js';
import { beforeScopeWrite } from './boxed-expression/definition-restore-point.js';

export function lookupDefinition(
  ce: IComputeEngine,
  id: MathJsonSymbol
): undefined | BoxedDefinition {
  return lookup(id, ce.context.lexicalScope);
}

/** The `kind` of a definition, matching `operatorInfo()`/`symbolInfo()`
 * semantics, or `undefined` if the definition is neither. */
function definitionKind(
  def: BoxedDefinition
): DefinitionSearchResult['kind'] | undefined {
  if (isOperatorDef(def)) {
    const op = def.operator;
    return op.evaluate || op.collection ? 'function' : 'opaque';
  }
  if (isValueDef(def)) return def.value.isConstant ? 'constant' : 'variable';
  return undefined;
}

/** The description line(s) of a definition, as a list of searchable strings. */
function descriptionLines(def: BoxedDefinition): string[] {
  const d = isOperatorDef(def)
    ? def.operator.description
    : isValueDef(def)
      ? def.value.description
      : undefined;
  if (!d) return [];
  return typeof d === 'string' ? [d] : d;
}

/** The curated search keywords of a definition, as a list of searchable
 * strings. */
function keywordsOf(def: BoxedDefinition): string[] {
  const k = isOperatorDef(def)
    ? def.operator.keywords
    : isValueDef(def)
      ? def.value.keywords
      : undefined;
  return k ?? [];
}

/**
 * Reverse library search: map a plain-text concept query to a ranked list of
 * matching identifiers. See `ComputeEngine.searchDefinitions`.
 */
export function searchDefinitions(
  ce: IComputeEngine,
  query: string | string[],
  options?: { limit?: number }
): DefinitionSearchResult[] {
  // Normalize into a list of phrases (one per array element, or the whole
  // string), then a deduplicated bag of tokens. Matching is an OR over
  // tokens; ranking rewards matching more of them.
  const phrases = (typeof query === 'string' ? [query] : query)
    .map((q) => q.trim().toLowerCase().replace(/\s+/g, ' '))
    .filter((q) => q.length > 0);
  if (phrases.length === 0) return [];

  const tokens = [...new Set(phrases.flatMap((p) => p.split(' ')))];

  // Multi-word phrases also participate in tier scoring so an exact keyword
  // like "inverse cosine" ranks above token-level description matches.
  const probes = [
    ...new Set([...tokens, ...phrases.filter((p) => p.includes(' '))]),
  ];

  // Clamp limit to [1, 100], default 10.
  let limit = options?.limit ?? 10;
  if (!Number.isFinite(limit)) limit = 10;
  limit = Math.max(1, Math.min(100, Math.floor(limit)));

  // Trigger axis: name -> triggers. Degrades gracefully (no triggers) when no
  // LaTeX syntax is available or it doesn't implement `getNamedTriggers`. This
  // only augments scope-bound candidates; it never introduces new ids.
  const triggersByName = new Map<string, string[]>();
  const named = ce.latexSyntax?.getNamedTriggers?.();
  if (named)
    for (const { name, triggers } of named) triggersByName.set(name, triggers);

  type Ranked = {
    id: MathJsonSymbol;
    kind: DefinitionSearchResult['kind'];
    matched: number;
    tier: number;
  };
  const results: Ranked[] = [];
  const seen = new Set<string>();

  // Walk the lexical scope chain; nearest scope wins for duplicate names.
  let scope: Scope | null = ce.context.lexicalScope;
  while (scope) {
    for (const [name, def] of scope.bindings) {
      if (seen.has(name)) continue;
      seen.add(name);

      const kind = definitionKind(def);
      if (kind === undefined) continue;

      const idLower = name.toLowerCase();
      const triggersLower = (triggersByName.get(name) ?? []).map((t) =>
        t.toLowerCase()
      );
      const descriptions = descriptionLines(def).map((d) => d.toLowerCase());
      const keywordsLower = keywordsOf(def).map((k) => k.toLowerCase());

      const searchable = [
        idLower,
        ...triggersLower,
        ...keywordsLower,
        ...descriptions,
      ];

      // Tier of one probe string against this definition (lower is better),
      // or undefined when it matches no axis at all. An exact keyword match
      // ranks with exact triggers (tier 2) so a curated alias wins over
      // name-substring noise; keyword-substring and description matches land
      // in the last tier.
      const tierOf = (s: string): number | undefined => {
        if (idLower === s) return 0;
        if (idLower.startsWith(s)) return 1;
        if (triggersLower.some((t) => t === s)) return 2;
        if (keywordsLower.some((k) => k === s)) return 2;
        if (idLower.includes(s)) return 3;
        if (triggersLower.some((t) => t.includes(s))) return 4;
        if (searchable.some((x) => x.includes(s))) return 5;
        return undefined;
      };

      // Gate: at least one token must match (OR semantics). Ranking then
      // rewards matching more tokens, and matching them more exactly.
      const matched = tokens.filter((tok) => tierOf(tok) !== undefined).length;
      if (matched === 0) continue;

      let tier = Infinity;
      for (const probe of probes) {
        const t = tierOf(probe);
        if (t !== undefined && t < tier) tier = t;
      }

      results.push({ id: name, kind, matched, tier });
    }
    scope = scope.parent;
  }

  // Deterministic ordering: most tokens matched, then tier, then shorter id,
  // then alphabetical.
  results.sort((a, b) => {
    if (a.matched !== b.matched) return b.matched - a.matched;
    if (a.tier !== b.tier) return a.tier - b.tier;
    if (a.id.length !== b.id.length) return a.id.length - b.id.length;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });

  return results.slice(0, limit).map(({ id, kind }) => ({ id, kind }));
}

// Per-engine cache of the operator-name pool, invalidated when the definition
// generation changes.
const operatorPoolCache = new WeakMap<
  IComputeEngine,
  { generation: number; names: string[] }
>();

/**
 * The names of all operator (function) definitions visible in the current
 * scope chain — the candidate pool for `suggestOperatorName`. Nearest scope
 * wins for duplicate names. Cached per engine, invalidated by generation.
 */
function operatorNamePool(ce: IComputeEngine): string[] {
  const cached = operatorPoolCache.get(ce);
  if (cached && cached.generation === ce._anyVersion) return cached.names;

  const names: string[] = [];
  const seen = new Set<string>();
  let scope: Scope | null = ce.context.lexicalScope;
  while (scope) {
    for (const [name, def] of scope.bindings) {
      if (seen.has(name)) continue;
      seen.add(name);
      if (isOperatorDef(def)) names.push(name);
    }
    scope = scope.parent;
  }

  operatorPoolCache.set(ce, { generation: ce._anyVersion, names });
  return names;
}

/**
 * Given a name that is *not* a known operator, return the closest known
 * operator name (a "did you mean" suggestion), or `undefined` when nothing is
 * close enough. Matching is conservative and applied in priority order, the
 * first tier that yields a match wins:
 *
 *  0. curated cross-language synonyms (`split` → `StringSplit`,
 *     `push` → `Append`, `ceiling` → `Ceil`),
 *  1. case-insensitive exact match (`arg` → `Arg`),
 *  2. singular/plural (`Quartile` → `Quartiles`, or vice-versa),
 *  3. Damerau–Levenshtein distance ≤ 2 for names of length ≥ 6, ≤ 1 for
 *     length 5, never for length < 5 (short names produce junk suggestions:
 *     `vec` → `Sec`, `rand` → `And`, `print` → `Prime`),
 *  4. the name is a prefix (≥ 3 chars) of exactly one known operator.
 *
 * Within a tier, ties break to the candidate sharing the longest prefix with
 * the query (`integral` → `Integrate`, not `Interval`), then the shortest,
 * then alphabetically.
 */
/**
 * Curated cross-language synonyms: names newcomers (and LLM agents)
 * reflexively try — from Python, JavaScript, or Mathematica — that no fuzzy
 * tier can bridge. Keys are lowercase. A curated suggestion is returned only
 * when its target operator is actually visible in the current scope chain.
 */
const CURATED_SYNONYMS: Record<string, string> = {
  split: 'StringSplit',
  push: 'Append',
  ceiling: 'Ceil',
  // JavaScript Array method names.
  some: 'Any',
  every: 'All',
  // Wolfram Language names. These are SUGGESTIONS, not aliases: the operator
  // they point at is the right neighborhood, but the call shape often differs
  // (`Accumulate[xs]` vs `Scan(xs, Add)`). The namespace stays Epsil-native.
  total: 'Sum',
  select: 'Filter',
  cases: 'Filter',
  memberq: 'Contains',
  accumulate: 'Scan',
  randomreal: 'Random',
  randominteger: 'Random',
  nest: 'Iterate',
  nestlist: 'Iterate',
};

export function suggestOperatorName(
  ce: IComputeEngine,
  name: string
): string | undefined {
  if (!name) return undefined;

  const pool = operatorNamePool(ce);
  const lower = name.toLowerCase();

  // Tier 0: curated cross-language synonyms.
  const curated = CURATED_SYNONYMS[lower];
  if (curated !== undefined && curated !== name && pool.includes(curated))
    return curated;

  // Longest common prefix between the query and a candidate, case-insensitive.
  const lcp = (n: string): number => {
    const nl = n.toLowerCase();
    let i = 0;
    while (i < lower.length && i < nl.length && lower[i] === nl[i]) i += 1;
    return i;
  };

  const pick = (cands: string[]): string | undefined => {
    if (cands.length === 0) return undefined;
    return cands.sort((a, b) => {
      const pa = lcp(a);
      const pb = lcp(b);
      if (pa !== pb) return pb - pa;
      if (a.length !== b.length) return a.length - b.length;
      return a < b ? -1 : a > b ? 1 : 0;
    })[0];
  };

  // Tier 1: case-insensitive exact match (excluding identity).
  const ciExact = pool.filter((n) => n !== name && n.toLowerCase() === lower);
  if (ciExact.length > 0) return pick(ciExact);

  // Tier 2: singular/plural.
  const plural: string[] = [];
  for (const n of pool) {
    const nl = n.toLowerCase();
    if (
      nl === `${lower}s` ||
      (lower.endsWith('s') && nl === lower.slice(0, -1))
    )
      plural.push(n);
  }
  if (plural.length > 0) return pick(plural);

  // Tier 3: Damerau–Levenshtein distance.
  if (name.length >= 5) {
    const max = name.length >= 6 ? 2 : 1;
    let bestDist = max + 1;
    let ties: string[] = [];
    for (const n of pool) {
      if (n === name) continue;
      const d = osaDistance(lower, n.toLowerCase(), max);
      if (d > max) continue;
      if (d < bestDist) {
        bestDist = d;
        ties = [n];
      } else if (d === bestDist) ties.push(n);
    }
    if (ties.length > 0) return pick(ties);
  }

  // Tier 4: the name is a prefix (≥ 3 chars) of exactly one known operator.
  if (name.length >= 3) {
    const prefixed = pool.filter(
      (n) => n !== name && n.toLowerCase().startsWith(lower)
    );
    if (prefixed.length === 1) return prefixed[0];
  }

  return undefined;
}

/** Record the binding record `boxedDef` and the placeholder half that the
 * declaration constructed as scratch bindings, when `scope` is a registered
 * scratch scope or a scope created under one. Later writes to the binding
 * (an inference, an update) then advance no version that a cache outliving
 * the scratch computation keys on (`scratch-scopes.ts`). `updateDef` marks
 * the halves it constructs itself. A half that a caller supplies is never
 * marked: it is installed by identity and can be shared with a binding
 * outside the scratch scope. */
function noteScratchDeclaration(
  ce: IComputeEngine,
  scope: Scope,
  boxedDef: BoxedDefinition
): void {
  const root = scratchRootOf(ce, scope);
  if (root === undefined) return;
  noteScratchBinding(root, [boxedDef, (boxedDef as { value?: object }).value]);
}

export function declareSymbolValue(
  ce: IComputeEngine,
  name: MathJsonSymbol,
  def: Partial<ValueDefinition>,
  scope?: Scope
): BoxedDefinition {
  scope ??= ce.context.lexicalScope;

  // State event: `shadowsCallable` must be captured BEFORE the placeholder
  // install below, while the chain still shows any shadowed binding — and
  // resolved through the TARGET scope's chain, not the engine's current
  // lexical scope (an explicit `scope` argument may differ).
  const visibleBefore = lookup(name, scope);
  const shadowsCallable = defIsCallableShaped(visibleBefore);
  // Does this declaration change what a node evaluated in a frame that is
  // on the stack now reads? Read before the placeholder is installed. See
  // `changesFrameBinding()`.
  const changesBinding =
    (visibleBefore !== undefined || def.value !== undefined) &&
    changesFrameBinding(scope);

  // A FRESH declaration: the target scope held no binding of `name` before
  // this one. Read before the placeholder below is installed. See `updateDef`.
  beforeScopeWrite(ce, scope, name);
  const fresh = !scope.bindings.has(name);
  const replaced = scope.bindings.get(name);

  // Insert a placeholder in the bindings to handle recursive calls
  // (the value could be a function that references itself)
  scope.bindings.set(name, {
    value: new _BoxedValueDefinition(ce, name, {
      type: 'unknown',
      inferred: true,
    }),
  });

  const boxedDef = scope.bindings.get(name)!;
  noteScratchDeclaration(ce, scope, boxedDef);
  // When the value or its type is refused (the value throws, or does not
  // match the declared type), put back the binding that the placeholder
  // replaced, or remove the name if there was none. Otherwise the name stays
  // bound to the placeholder, a symbol of type `unknown` with no value, and a
  // binding that the failed declaration was meant to replace is lost
  // (CE-116). `updateDef` replaces the value half of the record in place and
  // can throw AFTER that (when the rebuild of a definition that waited on
  // this name fails). The new value is then committed and stays: the binding
  // is restored only while the record still holds the placeholder value half.
  const placeholderValue = isValueDef(boxedDef) ? boxedDef.value : undefined;
  try {
    // The parameter defaults of the declared type are checked and boxed in
    // `scope`, the scope that receives the declaration.
    inDeclaringScope(ce, name, scope, () =>
      updateDef(ce, name, boxedDef, def, scope, fresh)
    );
  } catch (e) {
    if (
      scope.bindings.get(name) === boxedDef &&
      isValueDef(boxedDef) &&
      boxedDef.value === placeholderValue
    ) {
      if (fresh) scope.bindings.delete(name);
      else scope.bindings.set(name, replaced!);
    }
    throw e;
  }
  // A symbol declared with a type that can hold a value of a value kind (`r:
  // residue`, `f: (integer) -> gf8`) lets an expression of the engine hold
  // such a value before any is made: the engine opens the gates of the kind
  // type that enable the recognition of its values (`residue-class.ts`).
  if (isValueDef(boxedDef))
    noteKindTypeDeclaration(ce, boxedDef.value.type.type);
  // A live frame whose scope receives the definition holds it, so the pop
  // of another frame that holds it too does not dispose it
  // (`countDeclaredHolder`, `engine-scope.ts`).
  // The definition that it replaces is uncounted (`uncountRemovedHolder`).
  if (isValueDef(boxedDef)) {
    countDeclaredHolder(ce, scope, boxedDef.value);
    if (
      replaced !== undefined &&
      isValueDef(replaced) &&
      replaced.value !== boxedDef.value
    )
      uncountRemovedHolder(ce, scope, replaced.value);
  }

  noteScopeDeclaration(scope);
  ce._noteStateEvent({
    kind: 'declare',
    callable: defIsCallableShaped(boxedDef),
    shadowsCallable,
    ...(changesBinding ? { changesFrameBinding: true } : {}),
    ...(isValueDef(boxedDef) &&
    boxedDef.value.storedValue !== undefined &&
    freeNameWasMade(ce, name) &&
    !isPendingCallScope(scope)
      ? { installsValue: true }
      : {}),
    // Keyed on the RESOLVED target scope, never on "is a scratch extent
    // running": a declaration made during one but aimed at a longer-lived
    // scope outlives it and must keep its axis advance. See `axisMaskOf`.
    ...(scratchRootOf(ce, scope) !== undefined ? { scratch: true } : {}),
    ...(isShadowedParameterDeclaration(ce, name, scope)
      ? { parameter: true }
      : {}),
    // A binding of a call, made before its frame is pushed: no type
    // computation reads it (`static-typing-view.ts`), so it does not move
    // the type version (`typeVersion`, `engine-configuration-lifecycle.ts`).
    ...(isPendingCallScope(scope) ? { activation: true } : {}),
  });

  return boxedDef;
}

/**
 * Whether a declaration into `scope` can change what a node evaluated in a
 * frame that is on the evaluation stack reads. The caller asks only when the
 * declaration installs a value or replaces a binding that the name has in
 * the chain of `scope`.
 *
 * The answer is yes for every scope except the new scope of a function call
 * that is not pushed yet (`isPendingCallScope`, `pending-call-scopes.ts`).
 * A call declares its parameters, with their values, in a new scope before
 * it pushes its frame: no frame reads that scope yet, so the results that
 * the memo of shared evaluations keeps for the frames on the stack stay
 * valid (`shared-evaluation-memo.ts`), and a recursive function whose body
 * shares nodes is evaluated in linear time. Any other scope can be in the
 * chain of a frame on the stack, the innermost one or a lower one: a host
 * handler that runs `ce.declare('x', { value: 10 })` while an expression is
 * evaluated changes what the nodes of a frame read. The test is one look-up
 * in a set, where a walk of the chain of every frame would cost a time
 * quadratic in the depth of a recursion.
 */
function changesFrameBinding(scope: Scope): boolean {
  return !isPendingCallScope(scope);
}

/**
 * Whether this declaration binds a name that a function literal or a block
 * under canonicalization shadows (`_pushShadowedParameters`: a parameter of
 * the literal, a `let` local the block hoists), into a scope strictly inside
 * the boundary that was pushed for the name: the literal's own body scope,
 * or a block nested in it. This is the auto-declaration of such a name at
 * its first reference (`createSymbolExpression`,
 * `engine-expression-entrypoints.ts`), which the shadowed-name frame routes
 * every reference of the name to, so that none resolves to an outer
 * binding. It is the one declaration that cannot change what any cached
 * value answers: see the `parameter` case of `axisMaskOf`
 * (`engine-configuration-lifecycle.ts`).
 *
 * A declaration of the same name made after the frame is popped (the
 * literal declares a parameter its body never mentions, possibly into a
 * body scope that already existed) and one aimed at or above the boundary
 * (the auto-declare target was moved up past `noAutoDeclare` scopes) are
 * not of this kind, and keep their axis advance.
 */
function isShadowedParameterDeclaration(
  ce: IComputeEngine,
  name: string,
  scope: Scope
): boolean {
  const boundary = ce._shadowedParameterBoundary(name);
  if (boundary === undefined || scope === boundary) return false;
  // Truthiness, not `!== null`: the root scope's parent is `undefined`.
  for (let s: Scope | null | undefined = scope.parent; s; s = s.parent)
    if (s === boundary) return true;
  return false;
}

export function declareSymbolOperator(
  ce: IComputeEngine,
  name: string,
  def: OperatorDefinition,
  scope?: Scope
): BoxedDefinition {
  scope ??= ce.context.lexicalScope;

  // A VALUE KIND (the `arithmetic` field) is checked BEFORE anything is
  // installed, so a refused kind leaves the previous binding as it was: the
  // result type must be a kind type, `add` requires `negate`, and the fields
  // that belong to the kind type must agree with the other live heads of the
  // type (`prepareKindRegistration()`, `boxed-expression/value-kinds.ts`).
  // The operator definition this declaration replaces in the SAME binding
  // (a redeclaration with `{ extend: true }`) loses its kind registration:
  // replaced by this one, or removed when this one has no `arithmetic`.
  const previousRecord = scope.bindings.get(name);
  const supersededOperator =
    previousRecord !== undefined && isOperatorDef(previousRecord)
      ? previousRecord.operator
      : undefined;
  const kindRegistration =
    def.arithmetic === undefined
      ? undefined
      : prepareKindRegistration(
          ce,
          name,
          declaredSignatureType(ce, def),
          def.arithmetic,
          { supersedes: supersededOperator }
        );

  // State event: capture the shadow BEFORE the placeholder install, through
  // the TARGET scope's chain.
  const visibleBefore = lookup(name, scope);
  const shadowsCallable = defIsCallableShaped(visibleBefore);
  // See `changesFrameBinding()`: an operator declared over a name that a
  // frame on the stack can read changes what that name resolves to.
  const changesBinding =
    visibleBefore !== undefined && changesFrameBinding(scope);
  // A FRESH declaration: the target scope held no binding of `name` before
  // this one. Read before the placeholder below is installed. See `updateDef`.
  beforeScopeWrite(ce, scope, name);
  const fresh = !scope.bindings.has(name);
  const replaced = scope.bindings.get(name);

  // Insert a placeholder in the bindings to handle recursive calls
  // (the function is not yet defined)
  scope.bindings.set(name, {
    value: new _BoxedValueDefinition(ce, name, { type: 'function' }),
  });

  const boxedDef = scope.bindings.get(name)!;
  noteScratchDeclaration(ce, scope, boxedDef);
  // When the operator definition constructor refuses the definition (for
  // example a `canonical` handler with the `commutative` flag), put back the
  // binding that the placeholder replaced, or remove the name if there was
  // none. Otherwise the name stays bound to the placeholder, a value of type
  // `function` with no handler, and a definition that the failed declaration
  // was meant to replace or extend is lost.
  // `updateDef` can also throw AFTER it installed the operator half (when
  // the rebuild of a definition that waited on this name fails). The new
  // definition is then committed and stays: the binding is restored only
  // while it still holds the placeholder value half.
  try {
    // The parameter defaults of the declared type are checked and boxed in
    // `scope`, the scope that receives the declaration.
    inDeclaringScope(ce, name, scope, () =>
      updateDef(ce, name, boxedDef, def, scope, fresh)
    );
  } catch (e) {
    if (!isOperatorDef(boxedDef) && scope.bindings.get(name) === boxedDef) {
      if (fresh) scope.bindings.delete(name);
      else scope.bindings.set(name, replaced!);
    }
    throw e;
  }

  // An operator declared to return a value of a value kind (`MyMod: (any,
  // any) -> residue`) lets an expression of the engine hold such a value
  // before any call of it is made: see `declareSymbolValue` above.
  if (isOperatorDef(boxedDef))
    noteKindTypeDeclaration(ce, boxedDef.operator.signature.type);

  // The value kind, checked above, is recorded now that its definition is
  // installed.
  if (isOperatorDef(boxedDef)) {
    if (kindRegistration !== undefined)
      commitKindRegistration(ce, boxedDef.operator, kindRegistration);
    else if (supersededOperator !== undefined)
      unregisterKind(ce, supersededOperator);
  }

  noteScopeDeclaration(scope);
  ce._noteStateEvent({
    kind: 'declare',
    callable: true,
    shadowsCallable,
    ...(changesBinding ? { changesFrameBinding: true } : {}),
    // A call boxed before this declaration (a free call head) applies the
    // function from now on: see `installsValue`.
    ...(freeNameWasMade(ce, name) && !isPendingCallScope(scope)
      ? { installsValue: true }
      : {}),
    // Same resolved-scope test as `declareSymbolValue` above: the two routes
    // must agree, or an operator-shaped stand-in would reintroduce the churn
    // the exemption removes.
    ...(scratchRootOf(ce, scope) !== undefined ? { scratch: true } : {}),
    ...(isPendingCallScope(scope) ? { activation: true } : {}),
  });

  return boxedDef;
}

export function getSymbolValue(
  ce: IComputeEngine,
  id: MathJsonSymbol
): Expression | undefined {
  const def = lookup(id, ce.context.lexicalScope);
  if (!def || !isValueDef(def)) return undefined;
  return def.value.value;
}

export function setSymbolValue(
  ce: IComputeEngine,
  id: MathJsonSymbol,
  value: Expression | boolean | number | undefined
): void {
  if (typeof value === 'number') value = ce.number(value);
  else if (typeof value === 'boolean') value = value ? ce.True : ce.False;

  // An object belongs to the engine that constructed it, so a binding in THIS
  // engine cannot hold one from another (`ce.assign` and every path that
  // installs a value reach this setter). The check is TRANSITIVE — a `List` or
  // dictionary holding a foreign object is not itself an object, yet binding
  // it retains the object all the same — and is gated on
  // `anyObjectExists()` inside `adoptsForeignEngineObject`, so a session that
  // has never constructed an object pays one boolean read. A host API throws
  // rather than returning an error value, matching this function's other
  // refusals below.
  if (adoptsForeignEngineObject([value as Expression], ce)) {
    throw new Error(
      `object-foreign-engine: cannot assign an object that belongs to a different engine to "${id}"`
    );
  }

  const def = lookup(id, ce.context.lexicalScope);
  if (!def) throw new Error(`Unknown symbol "${id}"`);

  if (isValueDef(def)) {
    // State event: emitted by the value SETTER below (`value-write`); the
    // extra G bump on the next line is the enumerated double-bump collapse
    // of the parity gate (design §8) — advancement-invisible, no second
    // event.
    def.value.value = value;
    // The declared-signature reconciliation paths (§6.3) store a `Function`
    // literal through here rather than through `updateDef`, so this is where a
    // function-typed value definition joins the forward-reference mechanism:
    // its own body may carry a provisional reading (register it), and `id`
    // becoming callable re-derives every body that read `id` as a
    // multiplication operand (`boxed-expression/provisional-application.ts`).
    // The repairs below re-derive only the definitions that can see this
    // binding: those made in the scope that holds it, in a scope under it,
    // or in a scope above it (a function that assigns a local of its own
    // body). `lookup()` reads the scopes in the static view inside a type
    // computation, so the record may be in no scope of the plain chain; the
    // repair then takes every waiting definition.
    const bindingScope = hasProvisionalDependents(ce, id)
      ? scopeOfBinding(
          ce.context.lexicalScope,
          id,
          (binding) => binding === def
        )
      : undefined;
    if (def.value.type.matches('function')) {
      registerProvisionalDependents(ce, value, def.value);
      // `def.value` is what was just installed for `id`: a recursive literal
      // waits on its own name, and must not be re-derived against itself.
      repairProvisionalDependents(ce, id, def.value, undefined, bindingScope);
    } else if (!def.value.type.isUnknown) {
      // A value that is not a function: a body that APPLIED `id` while it had
      // no definition is re-derived and reads the product instead (see the
      // same step in `updateDef`). A no-op when nothing waits on `id`.
      repairProvisionalDependents(ce, id, def.value, undefined, bindingScope);
    }
    return;
  }

  // Operator definition: cannot set a plain value on an operator symbol
  throw new Error(`Cannot assign a value to operator symbol "${id}"`);
}

/**
 * A2 — normalize the `typeParams` option of `ce.declareType()` into
 * {@link TypeParameter}s. Throws (before ANY mutation) on a malformed clause.
 *
 * Both spellings the option admits go through the SHARED clause parser: a
 * string is clause TEXT (`'T'`, `'T, U: number'`, or one entry of an array),
 * and an object is a pre-built `{ name, bound? }` whose bound may be a type
 * string. Names are checked for validity, reservation and duplication across
 * the whole list.
 */
function normalizeDeclaredTypeParams(
  ce: IComputeEngine,
  typeName: string,
  option: TypeParamsOption
): TypeParameter[] {
  const entries = typeof option === 'string' ? [option] : option;
  const params: TypeParameter[] = [];
  const seen = new Set<string>();

  const push = (p: TypeParameter): void => {
    if (!isValidTypeName(p.name) || isReservedTypeName(p.name))
      throw new TypeVariableError(
        isReservedTypeName(p.name)
          ? 'reserved-type-name'
          : 'unsupported-variable-position',
        `The type parameter name "${p.name}" of "${typeName}" is invalid`
      );
    if (seen.has(p.name))
      throw new TypeVariableError(
        'unsupported-variable-position',
        `The type variable \`${p.name}\` is declared more than once in the clause of "${typeName}"`
      );
    seen.add(p.name);
    params.push(p);
  };

  for (const entry of entries) {
    if (typeof entry === 'string') {
      const parsed = parseTypeParameterClause(entry, ce._typeResolver);
      if ('error' in parsed)
        throw new TypeVariableError(
          parsed.error.code === 'reserved-name'
            ? 'reserved-type-name'
            : 'unsupported-variable-position',
          `Invalid type parameter clause for "${typeName}": ${parsed.error.message}`
        );
      for (const p of parsed.params) push(p);
      continue;
    }
    const bound =
      entry.bound === undefined
        ? undefined
        : parseType(entry.bound as Type | TypeString, ce._typeResolver);
    if (bound !== undefined && hasFreeTypeVariables(bound))
      throw new TypeVariableError(
        'unsupported-variable-position',
        `The bound of the type variable \`${entry.name}\` must be a ground type`
      );
    const param: TypeParameter = { name: entry.name };
    if (bound !== undefined) param.bound = bound;
    if (entry.variance !== undefined) param.variance = entry.variance;
    // A kind already decided travels with the entry: the sum-type route
    // settles the kind of every shared parameter from all the variant bodies
    // before declaring any variant, and hands each variant its subset.
    if (entry.kind !== undefined) param.kind = entry.kind;
    push(param);
  }

  if (params.length === 0)
    throw new TypeVariableError(
      'unsupported-variable-position',
      `The type parameter clause of "${typeName}" is empty`
    );

  return params;
}

/**
 * Whether the definition `def` of the alias record `target` reaches `target`
 * under an odd number of negations, through unions, intersections, negations
 * and other transparent aliases only. A constructor (`list<…>`, `tuple<…>`, a
 * record, a function signature, …) and a nominal type stop the walk: an
 * occurrence there does not make the definition contradict itself.
 *
 * A union with an arm `any` (the top type) is `any` whatever its other arms
 * are, and an intersection with an arm `never` (the bottom type) is `never`.
 * Such a union or intersection does not depend on `target`, so the walk does
 * not look inside it: `type alias a = !a | any` has the fixed point `any`,
 * and `type alias b = !b & never` has the fixed point `never`. Only the
 * literal arms `any` and `never` count. `unknown` does not count as a top
 * type here, because it is an inference marker, not the set of all values.
 *
 * The walk visits each alias record at most once for each parity, so a cycle
 * of aliases terminates.
 */
function reachesItselfNegated(target: TypeReference, def: Type): boolean {
  const seen: [Set<TypeReference>, Set<TypeReference>] = [new Set(), new Set()];
  const walk = (t: Type, odd: boolean): boolean => {
    if (typeof t !== 'object') return false;
    if (t.kind === 'negation') return walk(t.type, !odd);
    if (t.kind === 'union' || t.kind === 'intersection') {
      const absorbing = t.kind === 'union' ? 'any' : 'never';
      if (t.types.some((x) => x === absorbing)) return false;
      return t.types.some((x) => walk(x, odd));
    }
    if (t.kind !== 'reference') return false;
    // An applied reference with arguments is a parameterized nominal type
    // (a generic alias is expanded when it is built), and it is opaque.
    if (t.args !== undefined) return false;
    const decl = declarationOf(t);
    if (decl === target) return odd;
    if (!decl.alias || decl.def === undefined) return false;
    const visited = seen[odd ? 1 : 0];
    if (visited.has(decl)) return false;
    visited.add(decl);
    return walk(decl.def, odd);
  };
  return walk(def, false);
}

export function declareType(
  ce: IComputeEngine,
  name: string,
  type: BoxedType | Type | TypeString,
  {
    alias,
    fromStatement,
    mint,
    typeParams,
    origin,
  }: {
    alias?: boolean;
    fromStatement?: boolean;
    mint?: boolean;
    typeParams?: TypeParamsOption;
    /** The declaring statement's identity, when this registration comes from
     * an Epsil `type` STATEMENT running inside a batch — the redefinition
     * discipline's runtime stamp
     * (`docs/TYPE-SYSTEM.md`). Absent on the box
     * route and on the host `ce.declareType()` API, whose records stay
     * unstamped and freely replaceable. */
    origin?: DeclarationOrigin;
  } = {}
): void {
  // `where` is a reserved word in type strings (the quantifier clause), so it
  // cannot also name a type.
  if (isReservedTypeName(name))
    throw new TypeVariableError(
      'reserved-type-name',
      `The type name "${name}" is reserved`
    );

  if (!isValidTypeName(name)) throw Error(`The type name "${name}" is invalid`);

  // P8, the no-dual-role rule, in the type-over-protocol direction: a protocol
  // name is not a type name, so a type may not claim one either. (The
  // protocol-over-type direction is enforced in `declareProtocolImpl()`.)
  if (ce._protocolRegistry[name] !== undefined)
    throw Error(
      `The type name "${name}" is already a protocol; protocols and types share no names`
    );

  // The generic clause is validated FIRST — before any namespace is touched —
  // so a malformed one leaves both halves exactly as they were.
  const params =
    typeParams === undefined
      ? undefined
      : normalizeDeclaredTypeParams(ce, name, typeParams);

  // Variance is a property of a NOMINAL declaration: it relates two
  // applications of an opaque type. A transparent alias has no such relation
  // to declare — an applied alias IS its expansion — so a marker there is
  // rejected rather than silently ignored (parameterized-nominal design §2).
  if (params !== undefined && alias === true) {
    const marked = params.find((p) => p.variance !== undefined);
    if (marked !== undefined)
      throw new TypeVariableError(
        'unsupported-variable-position',
        `The type parameter \`${marked.name}\` of the ALIAS "${name}" cannot declare a variance: an alias is transparent, so its applications are expanded rather than related`
      );
  }

  // A type declaration claims BOTH namespaces by default: the type record,
  // and a value-level constructor of the same name (decision D5 of the
  // nominal-types design, §4.1). The engine's own bootstrap declarations
  // therefore put `limits(…)`/`distribution(…)` in the system scope.
  //
  // `mint: false` is the public option that a VALUE KIND uses
  // (`ce.declareType('gf8', 'value', { mint: false })`): a kind has its own
  // head as constructor (`GF8(3)`, declared `(integer) -> gf8` with an
  // `arithmetic` field), and a minted `gf8(…)` would be a second head of the
  // kind type with no arithmetic. This changes decision D5, which said that a
  // type declaration always claims both namespaces
  // (`docs/plans/2026-10-26-value-kinds.md`, section 4.1.1). The record keeps
  // the choice in `_minted`, which the kind registration reads.
  mint ??= true;

  // A registered KIND TYPE (the result type of a head with an `arithmetic`
  // field) must stay a nominal type defined as exactly `value` with no
  // minted constructor: the subtype rule (`<: value`) and the disjointness
  // rule that protect its values from the number rules read that definition
  // (`valueKindDeclaration()`, `common/type/subtype.ts`). A replacement that
  // turns it into an alias, gives it parameters, mints a constructor for it,
  // or (checked after the body is parsed, below) defines it as anything but
  // `value` is refused here, before any namespace is touched.
  const kindRecord = ce._typeRegistry[name];
  const replacesKindType =
    kindRecord !== undefined && isRegisteredKindTypeRecord(ce, kindRecord);
  if (replacesKindType && (alias === true || mint || params !== undefined))
    throw Error(
      `The type "${name}" is the type of a value kind: it can only be declared again as a nominal type defined as exactly \`value\`, without type parameters and with \`{ mint: false }\``
    );

  // Is the type already defined? Types live in the ENGINE-LEVEL registry —
  // one namespace per engine, not lexically scoped
  // (`docs/TYPE-SYSTEM.md`).
  //
  // The VALUE half splits across two scopes:
  //
  // - The D5 collision PRE-CHECK consults the GLOBAL scope: that is where the
  //   binding an engine-wide name claim actually collides with lives. The
  //   Epsil static pre-pass canonicalizes top-level statements inside a
  //   pushed frame, and checking THAT frame's (empty) bindings would miss a
  //   genuine collision during the canonical pass while the registry half
  //   went through — breaking D5's all-or-nothing contract across the two
  //   passes. (Bootstrap declarations run before the global frame exists and
  //   fall back to the current, system, scope.)
  //
  // - The MINT targets the GLOBAL scope too — the constructor's lifetime is
  //   the type's (§3.2): a host `declareType()` under a `pushScope()` must
  //   not leave a permanently-registered type stranded without its
  //   constructor when the scope pops. The ONE exception is the static
  //   pre-pass surrogate frame (depth-guarded, unforgeable): there the mint
  //   goes to the transient frame — visible to the rest of the pre-pass,
  //   discarded with it (the registry half is rolled back by the pre-pass's
  //   registry transaction, so the two halves stay in sync).
  const surrogate =
    ce._staticTypeCheckDepth > 0 && ce.context.name === 'epsil:static-check';
  const checkScope =
    ce._evalContextStack[1]?.lexicalScope ?? ce.context.lexicalScope;
  const scope = surrogate ? ce.context.lexicalScope : checkScope;
  const registry = ce._typeRegistry;
  const existing = registry[name];

  // REDEFINITION DISCIPLINE — a second `type` statement declaring this name in
  // the SAME compilation unit is refused, while the same statement re-run in a
  // LATER unit still replaces (the notebook pattern). Checked HERE, before any
  // namespace is touched: the replacement path below re-opens the existing
  // record IN PLACE, so a rejected duplicate that had started writing would
  // damage the first declaration and every type holding its record. See
  // `docs/TYPE-SYSTEM.md`.
  if (existing !== undefined)
    checkSameUnitRedefinition('type', name, existing._declOrigin, origin);

  // SAME-STATEMENT RE-REGISTRATION IS A NO-OP. One `DeclareType` statement
  // reaches this function from both its canonical and its evaluate handler,
  // and the Epsil evaluation loop runs the two back-to-back per statement
  // (`ce.box(stmt).evaluate()` in `execute-epsil.ts`) with nothing in
  // between — so when the record already carries THIS statement's own stamp
  // and a completed definition, re-registering would rebuild, from the same
  // source text against an unchanged registry, exactly the state the record
  // already holds. It used to take the full replace path anyway, including
  // the `resettleTypeConformances` sweep over every conformance edge (~1.2 ms
  // per `type` statement, ×(N+1) for a sum) with zero redefinition anywhere.
  // The `def` guard keeps an unfulfilled forward-reference promise (stamped
  // or not, it has no `def`) on the fulfilment path below; an unstamped
  // registration (the box route, a host `ce.declareType()`) never matches, so
  // those routes keep their replace semantics.
  if (
    existing !== undefined &&
    existing.def !== undefined &&
    isSameStatementReRegistration(existing._declOrigin, origin)
  )
    return;

  // An UNRESOLVED FORWARD REFERENCE is a promise to declare, not a conflict:
  // `type json_array` inside an earlier body made `resolver.forward()` install
  // an empty record, and every type mentioning the name captured THAT object.
  // This declaration fulfills it — IN PLACE, so those captures see the
  // definition (a fresh record would leave them pointing at the empty one, and
  // mutual recursion could never close). A record with a `def` is a completed
  // declaration and still conflicts; only the empty promise is fulfillable.
  const fulfillsForwardRef =
    existing !== undefined && existing.def === undefined;

  // A forward reference is created by USE, so its arity is known only from the
  // uses that created it: each one recorded how many arguments it applied
  // (`type forest` records 0, `type forest<T>` records 1). This declaration
  // must agree with every one of them — a mismatch would leave those types
  // holding an application at the wrong arity, which matches nothing
  // (`list<type Gen>` then matched `list<tuple<integer, integer>>` as
  // `false`). Reject instead, leaving the placeholder untouched for a
  // well-formed declaration later (design §4.2).
  if (fulfillsForwardRef) {
    const declaredArity = params?.length ?? 0;
    const used = forwardArities(existing!);
    const mismatch =
      used === undefined
        ? undefined
        : [...used].find((n) => n !== declaredArity);
    if (mismatch !== undefined)
      throw new TypeVariableError(
        'generic-alias-arity',
        `The type "${name}" is declared with ${declaredArity} type parameter${declaredArity === 1 ? '' : 's'}, but an earlier forward reference applies it to ${mismatch} type argument${mismatch === 1 ? '' : 's'}`
      );
  }

  if (existing && !fulfillsForwardRef) {
    // A record this scope created from a `DeclareType` statement (marked
    // `_declaredByStatement`, mirroring the `Declare` operator handler) is
    // ours to replace: the same program may be canonicalized then evaluated,
    // or re-run in a notebook with an edited definition. Any other conflict
    // (a host `ce.declareType()`, a builtin) still throws.
    if (
      !fromStatement ||
      (existing as { _declaredByStatement?: boolean })._declaredByStatement !==
        true
    )
      throw Error(`The type "${name}" is already defined`);
  }

  // A statement replacement UPDATES THE RECORD IN PLACE, for the same reason a
  // forward-reference fulfilment does: every type that mentions the name — and
  // every applied reference `box<integer>` already built — captured THIS
  // object, and an applied reference additionally holds it through a hard
  // `decl` back-pointer (`common/type/reference.ts`). Swapping in a fresh
  // record left those captures answering from the OLD definition: a node
  // parsed before the redeclaration and one parsed after gave different
  // subtyping verdicts for the same pair of types, and a mutually recursive
  // set needed a THIRD notebook run to converge. The definition is the
  // record's, so replacing the definition means writing the record.
  const replacesInPlace = existing !== undefined && !fulfillsForwardRef;

  // D5, atomicity: the value half is checked BEFORE anything is mutated, so a
  // collision leaves neither namespace touched — not the existing type record,
  // not the recursion placeholder below. An outer-scope binding is shadowed,
  // not conflicted; an inferred (valueless, auto-declared) binding upgrades; a
  // constructor we minted earlier is ours to replace.
  // A GENERIC ALIAS mints nothing (`deriveConstructorSignature` declines a
  // parameterized body, D4b), so it makes no claim on the value namespace and
  // must not be pre-checked against one: `function Duo(x) {…}` followed by
  // `type alias Duo<T> = tuple<T, T>` is legal. (A plain→generic replacement
  // still drops the constructor the plain form minted — `mintTypeConstructor`
  // calls `removeMintedTypeConstructor` before deriving.)
  // A parameterized NOMINAL type is the opposite: it mints a `where`-quantified
  // constructor (design §5), so it does claim the value name. `alias` is not
  // yet defaulted here, so `!== true` reads "nominal".
  if (mint && (params === undefined || alias !== true))
    checkTypeConstructorNamespace(checkScope, name);

  alias ??= false; // Nominal by default

  // The state a failing replacement must put back. Unlike a forward-reference
  // fulfilment — whose rollback CLEARS the record back to an unfulfilled
  // promise — a replacement rolls back onto a type that was already working,
  // so every field it overwrites is snapshotted first. (`_declaredByStatement`
  // is in the snapshot even though the guard above proved it `true`: the
  // restore then states the whole prior record rather than re-deriving it.)
  const prior = replacesInPlace
    ? {
        def: existing!.def,
        alias: existing!.alias,
        typeParams: existing!.typeParams,
        varianceState: existing!._varianceState,
        varianceBlockedOn: existing!._varianceBlockedOn,
        declaredByStatement: (existing as { _declaredByStatement?: boolean })
          ._declaredByStatement,
      }
    : undefined;

  // First, add a placeholder record to allow recursive types. Fulfilling a
  // forward reference — or replacing a statement-declared type — REUSES the
  // record already in the scope (same object, now carrying this declaration's
  // `alias`), so the types that captured it resolve through to the definition
  // set below. Re-opening it as a placeholder (no `def`, no verified variance)
  // is what makes the body parse below behave exactly as it does for a first
  // declaration: a generic type that applies itself is detected as
  // `generic-alias-self-reference`, and the recursive occurrence in the new
  // body binds to this record rather than to the old definition.
  if (fulfillsForwardRef || replacesInPlace) {
    existing!.alias = alias;
    existing!.def = undefined;
    delete existing!.typeParams;
    delete existing!._varianceState;
    delete existing!._varianceBlockedOn;
  } else registry[name] = { kind: 'reference', name, alias, def: undefined };
  // The clause goes on the placeholder, BEFORE the body parses: a generic
  // alias that applies itself is then detected unambiguously (the record has
  // `typeParams` and no `def` yet) as `generic-alias-self-reference`.
  if (params !== undefined) registry[name].typeParams = params;
  if (fromStatement)
    (
      registry[name] as { _declaredByStatement?: boolean }
    )._declaredByStatement = true;

  /** Undo the placeholder: a declaration that failed declares nothing. */
  const rollbackTypeHalf = (): void => {
    if (prior !== undefined) {
      // A replacement restores the record's PREVIOUS definition, field by
      // field. Clearing it (the forward-reference behaviour below) would leave
      // a type that worked a moment ago undefined — and, since the record is
      // shared, would break every type that mentions it too.
      existing!.alias = prior.alias;
      existing!.def = prior.def;
      if (prior.typeParams === undefined) delete existing!.typeParams;
      else existing!.typeParams = prior.typeParams;
      if (prior.varianceState === undefined) delete existing!._varianceState;
      else existing!._varianceState = prior.varianceState;
      if (prior.varianceBlockedOn === undefined)
        delete existing!._varianceBlockedOn;
      else existing!._varianceBlockedOn = prior.varianceBlockedOn;
      if (prior.declaredByStatement === undefined)
        delete (existing as { _declaredByStatement?: boolean })
          ._declaredByStatement;
      else
        (existing as { _declaredByStatement?: boolean })._declaredByStatement =
          prior.declaredByStatement;
      return;
    }
    if (fulfillsForwardRef) {
      // The record is the forward reference's own; restoring it means putting
      // it back to the unfulfilled state, not removing it — the types holding
      // it stay as they were, still waiting for a declaration.
      existing!.alias = false;
      existing!.def = undefined;
      delete existing!.typeParams;
      // The variance verification state belongs to the DECLARATION this
      // handler was making. Left behind on the re-opened promise it would let
      // a subtype judgment read the (now absent) parameters as verified.
      delete existing!._varianceState;
      delete existing!._varianceBlockedOn;
      // `_declaredByStatement` was set on this very record before the body
      // parsed. Leaving it behind would mark a still-unfulfilled promise as
      // statement-created, and the redeclaration guard above keys on exactly
      // that flag — so a later `fromStatement` declaration would silently
      // replace a type this handler never declared.
      delete (existing as { _declaredByStatement?: boolean })
        ._declaredByStatement;
      return;
    }
    // A first declaration: the placeholder is this handler's own, so undoing it
    // is removing it. (Every case with an `existing` record is handled above —
    // both reuse it in place.)
    delete registry[name];
  };

  // Parse the type (which may reference itself). If it is malformed, leave
  // the scope as it was: a placeholder with no `def` is a dangling reference
  // that later resolves to a broken type.
  let def: Type;
  try {
    def =
      type instanceof BoxedType
        ? type.type
        : typeof type === 'string'
          ? // A2 — the clause is PRE-SEEDED into the body parse, so `T` reads
            // as a type variable rather than as an unknown type name.
            parseType(type, ce._typeResolver, params, {
              // A NOMINAL declaration is the one route that may spell an
              // `object{…}` layout. Every other parse refuses the form with
              // `object-type-not-inline`, and this parse still refuses one
              // NESTED inside the body (`type T = list<object{…}>`), which is
              // inline by the same rule. A structural ALIAS is excluded too:
              // an object type is nominal, and two aliases of one layout
              // would be interchangeable — the subtyping between object types
              // Appendix B rules out. See `docs/TYPE_SYSTEM_ROADMAP.md`
              // Appendix B, "Declaring an object type".
              allowObjectType: alias !== true,
            })
          : type;

    // The STRUCTURAL routes — a `Type` object or a `BoxedType`, which a host
    // can hand to `declareType()` — have no text to parse, so the
    // `allowObjectType` gate just above never sees them. `mintTypeConstructor`
    // applies the same rule at the mint site, but `mint: false` skips minting
    // altogether; without this call a declaration made that way installs an
    // aliased or nested `object{…}` layout unchecked.
    if (typeof type !== 'string')
      assertObjectLayoutIsNominalBody(alias === true, def);

    // A default value of a parameter (`(number, number = 2) -> number`) is
    // used only on the top-level signature of a definition, which boxes and
    // checks it. A type declaration installs no definition, so nothing would
    // use a default in its body.
    assertNoParameterDefault(`Type "${name}"`, def);
  } catch (e) {
    rollbackTypeHalf();
    throw e;
  }

  // The definition of a registered kind type must stay exactly `value` (see
  // the check of the options above).
  if (replacesKindType && def !== 'value') {
    rollbackTypeHalf();
    throw Error(
      `The type "${name}" is the type of a value kind: it can only be defined as exactly \`value\`, not as \`${typeToString(def)}\``
    );
  }

  // A body that is NOTHING BUT an application of the type being declared
  // (`type r<T> = r<T>`) defines nothing at all: erasure resolves the reference
  // to itself forever, and two such applications relate by a variance no body
  // ever justified. The generic-ALIAS form of this is caught while the body
  // parses (`generic-alias-self-reference`, `type-builder.ts`); a nominal body
  // reaches that site legitimately, because a recursive occurrence is exactly
  // what makes the feature work — so the vacuous case is recognized HERE, where
  // "top level of the body" is knowable. Recursion UNDER structure stays legal.
  if (
    alias !== true &&
    typeof def === 'object' &&
    def.kind === 'reference' &&
    def.args !== undefined &&
    declarationOf(def) === registry[name]
  ) {
    rollbackTypeHalf();
    throw new TypeVariableError(
      'generic-alias-self-reference',
      `The definition of the nominal type "${name}" cannot be just an application of itself: a recursive occurrence must appear under some structure (a tuple field, \`list<${name}<…>>\`, …)`
    );
  }

  // A transparent alias is the set of values that satisfy its definition. If
  // the definition reaches the alias again under an odd number of negations,
  // through unions, intersections and other aliases only, a value is in the
  // set exactly when it is not in it (`type alias nn = !nn`). No set
  // satisfies that, and the membership and subtype tests then give different
  // answers for the same value, so the declaration is refused. A recursive
  // occurrence inside a constructor (`type alias tree = list<tree> | integer`,
  // or `list<!t>`) stays legal: the value inside is smaller than the value
  // that holds it, so the definition decides each value from smaller ones.
  if (alias === true && reachesItselfNegated(registry[name], def)) {
    rollbackTypeHalf();
    throw new TypeVariableError(
      'alias-without-fixed-point',
      `The type alias "${name}" has no fixed point: its definition refers to "${name}" under a negation (\`!\`) that is not inside a constructor such as \`list<…>\` or \`tuple<…>\`, so no set of values satisfies it`
    );
  }

  // A phantom parameter is meaningless under either reading: transparently
  // `Tagged<integer>` and `Tagged<string>` are the same type, and opaquely
  // they are indistinguishable yet unequal. Rejected like the signature rule's
  // unused quantified variable.
  //
  // Hook A (design §4.2/§4.4): a parameterized NOMINAL type also has its
  // declared variance — the written marker, or the `out` a missing one
  // declares — VERIFIED against the body, and the same walk answers the
  // unused-parameter question, so the two checks are one call. It runs AFTER
  // the body parse returns (`parseType` prefixes "Failed to parse type" onto
  // anything thrown inside it) and BEFORE the definition feeds the mint block,
  // so a violating declaration never mints.
  // The clause's VALUE variables are decided by the finished body (kind by
  // position): a parameter used in a length slot, or given to another type's
  // value parameter, is a length. The kind is recorded on the clause entries
  // HERE, by the route that owns them — the type builder never writes a
  // pre-seeded entry, because a sum type shares one clause across its
  // variants — and a structural body (`Type`/`BoxedType`) gets the same
  // treatment as a string. The value-variable checks (integer bound, no
  // protocol slot) then run as they do for a signature's `where` clause.
  if (params !== undefined) {
    const valueNames = valueVariableNamesOf(def);
    for (const p of params)
      if (valueNames.has(p.name) && p.kind === undefined) p.kind = 'value';
    for (const p of params) if (p.kind === 'value') valueNames.add(p.name);
    def = markValueVariables(def, valueNames);
    try {
      validateValueParameters(params, valueNames);
    } catch (e) {
      rollbackTypeHalf();
      throw e;
    }
  }

  if (params !== undefined && alias !== true) {
    const verdict = verifyVariance(name, params, def);
    if (verdict.status === 'violation') {
      rollbackTypeHalf();
      throw new TypeVariableError(verdict.code, verdict.message);
    }
    const record = registry[name];
    if (verdict.status === 'deferred') {
      record._varianceState = 'deferred';
      record._varianceBlockedOn = verdict.blockedOn;
    } else {
      record._varianceState = 'verified';
      delete record._varianceBlockedOn;
    }
  } else if (params !== undefined) {
    const free = freeTypeVariables(def);
    const unused = params.filter((p) => !free.has(p.name));
    if (unused.length > 0) {
      rollbackTypeHalf();
      throw new TypeVariableError(
        'generic-alias-unused-parameter',
        `The type parameter${unused.length === 1 ? '' : 's'} \`${unused
          .map((p) => p.name)
          .join('`, `')}\` of "${name}" ${
          unused.length === 1 ? 'is' : 'are'
        } never used in its definition`
      );
    }
  }

  // Adjust the definition (the type references in the type will point to
  // the placeholder record)
  registry[name].def = def;

  // Hook B: this declaration may have fulfilled the forward reference a
  // provisionally-accepted one was waiting on. Verify every group that has
  // become complete, to a fixpoint.
  //
  // A REPLACEMENT additionally re-verifies the types that already mention this
  // record. They follow the new definition (the record is theirs too), so a
  // redeclaration that changes this type's variance can invalidate a
  // dependent's own declared variance — and that dependent, not this
  // declaration, is where the contradiction lives. Such a verdict fails THIS
  // statement, which rolls back, leaving the dependent as it was.
  let settled: TypeReference[];
  try {
    // Value-level dependents are gathered from the CURRENT frame's chain
    // (which contains `scope`), so a transient frame's own declarations are
    // covered too.
    settled = settleVarianceGroup(
      ce,
      ce.context.lexicalScope,
      name,
      replacesInPlace ? existing : undefined
    );
  } catch (e) {
    rollbackTypeHalf();
    throw e;
  }

  // Mint the value-level constructor (§4.1, D4/D4b/D10). If it cannot be
  // declared, roll BOTH halves back: the registration is atomic across the two
  // namespaces. The value half needs its own snapshot because minting is not
  // atomic internally — it drops a previously minted constructor first, then
  // `ce.declare()` installs a placeholder binding BEFORE `updateDef()` builds
  // the real definition, and that construction can throw. Without the restore
  // a failure leaves the old constructor gone and a dead placeholder bound.
  if (mint) {
    const existingBinding = scope.bindings.get(name);
    try {
      // `mintTypeConstructor` installs through `ce.declare()`, which targets
      // the CURRENT frame — enter `scope` when they differ (a host
      // `declareType()` under a pushed scope) so the constructor lands next
      // to the binding the D5 check consulted.
      if (scope === ce.context.lexicalScope)
        mintTypeConstructor(ce, scope, name, registry[name], def);
      else
        ce._inScope(scope, () =>
          mintTypeConstructor(ce, scope, name, registry[name], def)
        );
    } catch (e) {
      rollbackTypeHalf();
      if (existingBinding !== undefined)
        scope.bindings.set(name, existingBinding);
      else scope.bindings.delete(name);
      throw e;
    }

    // A declaration that minted NO constructor (a record body, a generic
    // alias — or a REPLACEMENT to one, which removed the previous local
    // constructor) may still have a minted constructor for the name visible
    // in an OUTER scope: under the pre-pass surrogate, the previous run's
    // constructor lives in the global scope while this replacement operates
    // on the transient frame. Left visible, the rest of the pre-pass would
    // canonicalize calls against a constructor that real evaluation removes
    // (a spurious arity diagnostic, or a silently-validated call). Mask it
    // with an inert value shell in the mint scope, so the pass sees the same
    // value namespace real execution will.
    if (!isMintedConstructor(scope.bindings.get(name))) {
      let outer = scope.parent;
      let inherited = false;
      while (outer !== null && outer !== undefined && !inherited) {
        if (isMintedConstructor(outer.bindings.get(name))) inherited = true;
        outer = outer.parent;
      }
      if (inherited && !scope.bindings.has(name))
        ce._declareSymbolValue(
          name,
          { type: 'unknown', inferred: true },
          scope
        );
    }
  }

  // The redefinition stamp goes on LAST, once every failure path above is
  // behind us — so a declaration that rolled back leaves the record's previous
  // origin exactly as it was. A registration that carries NO origin (the box
  // route, a host `ce.declareType()`, a bootstrap declaration) CLEARS any
  // stamp instead of keeping a stale one: an unstamped record is one no
  // statement of the current unit owns, which is what makes it replaceable
  // (the route/origin matrix's box-route rows). Mirrors how the P47 batch
  // stamp rides with the implementation it describes in
  // `declareConformance()`.
  if (origin === undefined) delete registry[name]._declOrigin;
  else registry[name]._declOrigin = origin;
  registry[name]._minted = mint;

  // A5 — replacing a type record is a context change: bump the generation so
  // the caches keyed on it (and every expression boxed AFTER this point) see
  // the new definition. Expressions already boxed keep the type they computed,
  // exactly as a value redeclaration leaves them.
  // A variance flip from provisional (`inout`-conservative) to verified is the
  // same kind of change — it widens the answers subtyping gives. In practice it
  // only ever happens on a declaration that fulfils a forward reference, so
  // `existing` is already truthy; the second disjunct is there so a future
  // unblocking route cannot silently skip the bump.
  if (existing || settled.length > 0) {
    // State event: a type redefinition (G+M+E today) — `config`-class for
    // the parity dispatch, like the type-statement rollback in `index.ts`.
    // Both rows are recorded in the design's §2 table (2b addenda).
    ce._noteStateEvent({ kind: 'config' });
    // A type REDEFINITION (statement replace, forward-ref fulfillment,
    // variance settle) changes the answers subtyping gives — a
    // global-semantics event on all three axes ('operator/type redefinition'
    // in `_worldVersion`'s contract). A FRESH declaration deliberately bumps
    // none of these beyond what `ce.declare()` did for the constructor half.

    // …and the CONFORMANCE half of the same change. A protocol's property
    // requirement can be satisfied by a stored field of a conforming object
    // type, and that verdict was taken against the layout this declaration has
    // just replaced: an accessor synthesized for a field the new layout dropped
    // would keep answering, and a field it adds would get none. Re-running
    // conformance here is the type-side mirror of what a protocol REPLACEMENT
    // already does for its own edges (`declareProtocolImpl`), and is what makes
    // `docs/TYPE_SYSTEM_ROADMAP.md` Appendix B's "replacement re-runs
    // conformance checking against that fixed layout" true of both halves.
    // Idempotent: this runs on the static pre-pass AND the evaluation pass of
    // the same `type` statement, and emits its own events only when a verdict
    // actually moved.
    resettleTypeConformances(ce);
  }
}

/** Does `name` on its own parse as a type? True for a grammar PRIMITIVE
 * (`integer`, `list`, `nothing`) as well as for a declared name — the two are
 * one question only the type parser can answer, since a primitive never
 * reaches the resolver. */
function namesAGrammarType(ce: IComputeEngine, name: string): boolean {
  try {
    parseType(name, ce._typeResolver);
    return true;
  } catch {
    return false;
  }
}

/** One arm of a sum-type declaration: the variant's name and the TYPE TEXT its
 * payload lowered to (A2 — `"nothing"` for a nullary variant, the payload type
 * itself for a single positional one, `tuple<…>` otherwise). */
export type SumTypeVariant = { name: string; payload: string };

/**
 * Declare a SUM TYPE — the N nominal variant declarations plus the transparent
 * union that names them — as ONE atomic operation
 * (`docs/plans/2026-08-12-sum-type-sugar-and-compilation.md` §A).
 *
 * The sugar adds no semantics: it is a declaration bundler, and what it
 * produces is exactly the manual desugaring pinned by
 * `test/compute-engine/sum-types.test.ts`:
 *
 * ```
 * type node = lit(num: number) | plus(op1: node, op2: node)
 *   ≡  type lit  = tuple<num: number>
 *      type plus = tuple<op1: node, op2: node>
 *      type alias node = lit | plus
 * ```
 *
 * Four things this owns that the manual form leaves to the author:
 *
 * - **A3** — the sum's name is FORWARD-REGISTERED before the variants are
 *   declared, so a payload may write `node` / `tree<T>` bare instead of the
 *   `type node` marker. The final alias fulfils the reference in place.
 * - **A4** — a generic sum's parameters are distributed to each variant BY
 *   USAGE: a variant is declared with the subset that occurs free in its
 *   parsed payload, and the alias applies each variant to its own subset
 *   (`type alias tree<T> = leaf | node<T>`).
 * - **A5** — the variant-name collision guard. A variant that already names a
 *   type, is reserved, or names a SYSTEM-scope (builtin) binding is rejected,
 *   because `type Add = tuple<…>` succeeds today while `Add(1, 2)` still
 *   evaluates the builtin — the constructor would be silently unreachable.
 * - **Atomicity** — any failure rolls both namespaces back: the type registry
 *   to its entry state, and the constructor bindings this call claimed.
 */
export function declareSumType(
  ce: IComputeEngine,
  name: string,
  variants: readonly SumTypeVariant[],
  {
    typeParams,
    fromStatement,
    origin,
  }: {
    typeParams?: TypeParamsOption;
    fromStatement?: boolean;
    /** See `declareType`'s option of the same name. ALL N+1 names this one
     * statement registers carry the SAME origin: the statement owns every name
     * it declares, so a collision on any of them is one collision, reported
     * once (`docs/TYPE-SYSTEM.md`, "the
     * generated-name rule"). */
    origin?: DeclarationOrigin;
  } = {}
): void {
  if (isReservedTypeName(name))
    throw new TypeVariableError(
      'reserved-type-name',
      `The type name "${name}" is reserved`
    );
  if (!isValidTypeName(name)) throw Error(`The type name "${name}" is invalid`);
  if (variants.length === 0)
    throw Error(`The sum type "${name}" declares no variants`);

  // The clause is validated FIRST, before any namespace is touched.
  const params =
    typeParams === undefined
      ? undefined
      : normalizeDeclaredTypeParams(ce, name, typeParams);

  // The sum itself is a transparent ALIAS, and an alias has no relation
  // between two applications to declare — so a variance marker on the sum's
  // clause has nowhere to go. Rejected rather than silently dropped or
  // silently pushed onto the variants (whose parameter subsets differ).
  const marked = params?.find((p) => p.variance !== undefined);
  if (marked !== undefined)
    throw new TypeVariableError(
      'unsupported-variable-position',
      `The type parameter \`${marked.name}\` of the sum type "${name}" cannot declare a variance: the sum is a transparent union of its variants, so its applications are expanded rather than related`
    );

  const registry = ce._typeRegistry;

  // REDEFINITION DISCIPLINE — the whole name set this statement claims (the
  // sum's own name first, then the variants) is checked against the unit's
  // existing stamps BEFORE anything is declared. Running it here, ahead of the
  // A5 variant-collision guard below, is what makes a PARTIAL collision — a
  // second sum in the same program reusing one variant name — report the
  // discipline's own `type-redefinition` rather than A5's "already names a
  // type"; and the first throw aborts the statement, so a collision is
  // reported ONCE however many of its names collide. See
  // `docs/TYPE-SYSTEM.md`.
  if (origin !== undefined)
    for (const claimed of [name, ...variants.map((v) => v.name)])
      checkSameUnitRedefinition(
        'type',
        claimed,
        registry[claimed]?._declOrigin,
        origin
      );

  // SAME-STATEMENT RE-REGISTRATION IS A NO-OP — the sum-level twin of the
  // check in `declareType` (see its comment for the mechanism: canonical and
  // evaluate handler of one statement run back-to-back, and re-registering
  // rebuilds state the records already hold). Checking the SUM name alone
  // proves the whole statement completed: the sum's own record is written
  // LAST (the union fulfilment, then `_sumVariants`), all N+1 names carry
  // this one origin, and a failure anywhere rolls the whole statement back
  // atomically — so a stamped, completed, variant-carrying sum record cannot
  // coexist with a half-declared variant set. Without this, the evaluate pass
  // re-ran N+1 `declareType` replacements, each with its
  // `resettleTypeConformances` sweep.
  const sumRecord = registry[name];
  if (
    sumRecord !== undefined &&
    sumRecord.def !== undefined &&
    sumRecord._sumVariants !== undefined &&
    isSameStatementReRegistration(sumRecord._declOrigin, origin)
  )
    return;

  const globalScope = ce._evalContextStack[1]?.lexicalScope;
  // Builtins live in the SYSTEM scope — the parent of the global one.
  const systemScope = globalScope?.parent ?? undefined;

  // A5 — the guard runs over EVERY variant before anything is declared, so a
  // collision on the last arm leaves the first ones undeclared too.
  const seen = new Set<string>();
  for (const v of variants) {
    if (!isValidTypeName(v.name))
      throw Error(`The variant name "${v.name}" is invalid`);
    if (isReservedTypeName(v.name))
      throw new TypeVariableError(
        'reserved-type-name',
        `The variant name "${v.name}" is reserved`
      );
    if (v.name === name)
      throw Error(
        `The variant "${v.name}" cannot have the same name as the sum type it belongs to`
      );
    if (seen.has(v.name))
      throw Error(
        `The variant "${v.name}" is declared twice in the sum type "${name}"`
      );
    seen.add(v.name);

    // Two exemptions, both narrower than `declareType`'s. An unfulfilled
    // forward reference (no `def`) is a promise to declare, not a conflict;
    // and a record THIS SAME SUM declared is ours to replace, which is what
    // makes re-running the statement idempotent. `declareType`'s broader
    // "any statement-declared record is replaceable" rule is deliberately NOT
    // inherited: a variant silently taking over an unrelated `type foo = …`
    // from earlier in the same program is exactly the kind of quiet capture
    // A5 exists to refuse.
    const existing = registry[v.name];
    if (
      existing !== undefined &&
      existing.def !== undefined &&
      existing._sumOf !== name
    )
      throw Error(
        `The variant "${v.name}" of the sum type "${name}" already names a type`
      );

    // A PRIMITIVE of the type grammar (`integer`, `list`, `nothing`) is never
    // a registry record, so the check above cannot see it — but the grammar
    // keeps winning, so the declaration would be inert exactly the way an
    // `Add` variant's constructor is. (`ce.declareType()` accepts
    // `type integer = …` today; the sugar refuses it rather than inherit the
    // trap.)
    if (existing === undefined && namesAGrammarType(ce, v.name))
      throw Error(
        `The variant "${v.name}" of the sum type "${name}" is the name of a built-in type`
      );

    if (systemScope?.bindings.has(v.name) === true)
      throw Error(
        `The variant "${v.name}" of the sum type "${name}" is the name of a built-in: its constructor would be unreachable, because \`${v.name}(…)\` still evaluates the builtin. Rename the variant.`
      );
  }

  // The variant list this declaration REPLACES, read before anything is
  // touched (the declarations below overwrite it).
  const priorVariants = registry[name]?._sumVariants;

  // Atomicity. The registry snapshot restores every record FIELD (records are
  // replaced in place, so captures hold the object); the binding snapshot
  // covers the constructors `declareType` mints for the names this call
  // claims. `declareType` rolls its OWN failed declaration back — this covers
  // the ones that already succeeded when a later arm fails.
  const rollbackTypes = ce._typeRegistryRollbackPoint();
  // The PROTOCOL registry needs the same snapshot: each `declareType` below
  // re-settles the conformance edges of a REPLACED name against its new layout
  // (see the call to `resettleTypeConformances`), so a later arm that throws
  // must undo the pending flags and synthesized accessors the earlier arms left
  // behind, not only their type records.
  const rollbackProtocols = ce._protocolRegistryRollbackPoint();
  const surrogate =
    ce._staticTypeCheckDepth > 0 && ce.context.name === 'epsil:static-check';
  const mintScope = surrogate
    ? ce.context.lexicalScope
    : (globalScope ?? ce.context.lexicalScope);
  const priorBindings = [name, ...variants.map((v) => v.name)].map(
    (n) => [n, mintScope.bindings.get(n)] as const
  );
  const rollback = (): void => {
    rollbackTypes();
    rollbackProtocols();
    for (const [n, binding] of priorBindings) {
      if (binding === undefined) mintScope.bindings.delete(n);
      else mintScope.bindings.set(n, binding);
    }
  };

  try {
    // A3 — the promise, made before the variants that reference it.
    const promise = ce._typeResolver.forward(name)!;
    // A GENERIC sum's promise carries its clause, so a payload may apply it
    // (`list<tree<T>>`). Without it the application is rejected outright: the
    // type builder only admits an applied reference to an undefined record
    // when the SOURCE spelled the `type tree<T>` marker, and the whole point of
    // A3 is that the sugar needs no marker. With the clause on the record the
    // application takes the ordinary opaque-nominal path, and the fulfilling
    // `type alias` below re-opens the record — every capture delegates `alias`
    // and `def` to it, so they follow.
    if (params !== undefined && promise.def === undefined)
      promise.typeParams = params;

    const subsets = new Map<string, TypeParameter[]>();
    // The variants SHARE the clause's parameter objects, and a parameter's
    // KIND (type or value/length) is decided by where the bodies use it. So
    // every payload is probed first and the kinds settled on the shared
    // objects, and only then is any variant declared: otherwise a variant
    // declared before a later payload marked `N` as a length would have been
    // built, minted and variance-checked with `N` as a type, and the outcome
    // would depend on the order of the variants.
    const probed = new Map<string, Set<string>>();
    if (params !== undefined) {
      for (const v of variants) {
        // A4 — parse the payload with the WHOLE clause seeded, then keep the
        // parameters it actually mentions. (The payload is parsed a second
        // time by `declareType`; this one only answers "which variables?".)
        const payload = parseType(v.payload, ce._typeResolver, params);
        probed.set(v.name, freeTypeVariables(payload));
        const valueNames = valueVariableNamesOf(payload);
        for (const p of params)
          if (valueNames.has(p.name) && p.kind === undefined) p.kind = 'value';
      }
    }
    for (const v of variants) {
      let subset: TypeParameter[] | undefined;
      if (params !== undefined) {
        const free = probed.get(v.name)!;
        subset = params.filter((p) => free.has(p.name));
        if (subset.length === 0) subset = undefined;
      }
      declareType(ce, v.name, v.payload, {
        fromStatement,
        typeParams: subset,
        origin,
      });
      if (subset !== undefined) subsets.set(v.name, subset);
      registry[v.name]._sumOf = name;
    }

    // The fulfilment: `type alias NAME = v₁ | v₂<T> | …`, each variant applied
    // to its own parameter subset.
    const body = variants
      .map((v) => {
        const subset = subsets.get(v.name);
        return subset === undefined
          ? v.name
          : `${v.name}<${subset.map((p) => p.name).join(', ')}>`;
      })
      .join(' | ');
    declareType(ce, name, body, {
      alias: true,
      fromStatement,
      typeParams,
      origin,
    });

    // A RE-declaration that drops a variant leaves that variant's record
    // behind — it is still a perfectly good nominal type, only its membership
    // ended. Its `_sumOf` back-pointer must go with the membership: left
    // dangling, the compile tier would keep reading it and compile the orphan's
    // constructor under the policy the NEW variant set implies (§B1), which
    // flips its representation without flipping the values already built.
    // Cleared here, inside the try, so the atomic rollback restores it.
    if (priorVariants !== undefined)
      for (const p of priorVariants)
        if (!seen.has(p.name) && registry[p.name]?._sumOf === name)
          delete registry[p.name]._sumOf;

    registry[name]._sumVariants = variants.map((v) => ({
      name: v.name,
      typeParams: (subsets.get(v.name) ?? []).map((p) => p.name),
    }));

    // A conformance declared for the SUM as a whole (`type shape is Area { … }`)
    // is one edge per variant, so a re-declaration that ADDS a variant must
    // give the new variant its edge too — the batch re-run of ruling P47 for
    // the sum spelling (user ruling of 2026-09-22). Inside the `try`, and
    // after the variant list is written, so a failure rolls the whole
    // statement back and so the re-run reads the list this declaration
    // settled.
    refreshSumConformances(
      ce,
      name,
      variants.map((v) => v.name)
    );
  } catch (e) {
    rollback();
    throw e;
  }
}

/**
 * Every mention of the declaration record `target` in `body` — `undefined` when
 * it is not mentioned at all. A BARE reference is an application at arity ZERO,
 * exactly as it is for a forward reference (`forwardArities`): it is what makes
 * a plain → generic re-declaration a mismatch (N7).
 *
 * STRUCTURAL walk: an applied reference is compared by the identity of its
 * declaration record (`declarationOf`, the `decl` back-pointer) and descended
 * into through its ARGUMENTS only — never through `def`. That is both the
 * cycle guard a recursive nominal needs (`type tree<T> = tuple<T,
 * list<tree<T>>>` closes its loop through `def`) and the right question:
 * mentioning a type is a property of the body as written, not of what the
 * mentioned type expands to. The visited set covers shared sub-structure.
 */
function mentionsOf(
  body: Type,
  target: TypeReference
): TypeReference[] | undefined {
  const seen = new Set<object>();
  let mentions: TypeReference[] | undefined;
  const visit = (t: Type | undefined): void => {
    if (t === undefined || typeof t !== 'object') return;
    if (seen.has(t)) return;
    seen.add(t);
    switch (t.kind) {
      case 'reference':
        if (declarationOf(t) === target) (mentions ??= []).push(t);
        (t.args ?? []).forEach(visit);
        return;
      case 'signature':
        (t.args ?? []).forEach((a) => visit(a.type));
        (t.optArgs ?? []).forEach((a) => visit(a.type));
        if (t.variadicArg !== undefined) visit(t.variadicArg.type);
        visit(t.result);
        return;
      case 'union':
      case 'intersection':
        t.types.forEach(visit);
        return;
      case 'negation':
        visit(t.type);
        return;
      case 'list':
      case 'set':
      case 'collection':
      case 'indexed_collection':
      case 'broadcastable':
        visit(t.elements);
        return;
      case 'dictionary':
        visit(t.values);
        return;
      case 'tuple':
        t.elements.forEach((el) => visit(el.type));
        return;
      // An `object{…}` layout is legal exactly where this walk runs — as the
      // body of a named type declaration — so its field types are a prime
      // place for a mention to hide. Without this arm `type Person =
      // object{b: Box<integer>}` reports zero mentions of `Box`, and a later
      // change to `Box`'s arity or parameter bounds skips the re-check that
      // would have caught `Person`'s now-invalid application.
      case 'object':
      case 'record':
        Object.values(t.elements).forEach(visit);
        return;
      default:
        return;
    }
  };
  visit(body);
  return mentions;
}

/**
 * Ruling C, fulfilment half: re-verify every provisionally-accepted declaration
 * in scope whose blocking forward references have since gained definitions,
 * until no further record settles.
 *
 * This terminates without a least-fixed-point search because no member's
 * variance is being SOLVED — each is verified against its own declared (or
 * default) variance, and a reference with a known definition composes with the
 * variance that declaration states. A mutually recursive pair therefore settles
 * in at most two passes.
 *
 * A late violation throws: the failing OPERATION is the fulfilling declaration
 * (which rolls back atomically, as any failing declaration does), while the
 * message is ATTRIBUTED to the original declaration and names the trigger. Any
 * record this pass already flipped is put back, so the throw leaves the scope
 * exactly as it found it.
 *
 * `replaced` is the record a statement re-declaration has just UPDATED IN
 * PLACE. Its dependents keep pointing at it, so they now read the new
 * declaration — its clause and its variance both — and every one that mentions
 * it is checked against it again: the ARITY of each mention against the new
 * type-parameter count, each argument against the new BOUNDS, and (for an
 * already-verified parameterized nominal) its own declared variance against the
 * new body. Dependents are both TYPE-level (the scope chain's type records) and
 * VALUE-level (its declared symbol types and operator signatures). That pass
 * changes no state: a dependent either still checks out (nothing to record) or
 * fails, which throws and so fails the redeclaration.
 */
function settleVarianceGroup(
  ce: IComputeEngine,
  scope: Scope,
  justDeclared: string,
  replaced?: TypeReference
): TypeReference[] {
  const flipped: TypeReference[] = [];
  const wasBlockedOn = new Map<TypeReference, string[] | undefined>();
  const undo = (): void => {
    for (const r of flipped) {
      r._varianceState = 'deferred';
      r._varianceBlockedOn = wasBlockedOn.get(r);
    }
  };

  // The dependent re-verification runs FIRST, before anything is flipped, so a
  // violation needs no undo. Deferred dependents are left to the variance
  // fixpoint below — they are re-verified there anyway, and only there can they
  // settle.
  if (replaced !== undefined) {
    const params = replaced.typeParams;
    const declaredArity = params?.length ?? 0;

    /**
     * Re-check every mention of the replaced record in `body` against the NEW
     * declaration. `subject` names the dependent in the diagnostic ("the
     * definition of \"holder\"", "the signature of \"f\""), `ownParams` is the
     * dependent's own generic clause, used to read an OPEN argument as its
     * declared bound exactly as A7's admission rule does at build time.
     */
    const recheckMentions = (
      body: Type,
      subject: string,
      ownParams: readonly TypeParameter[] | undefined
    ): void => {
      const mentions = mentionsOf(body, replaced);
      if (mentions === undefined) return;

      // ARITY first: a dependent that applies the replaced type at the old
      // arity holds an application that matches nothing, whatever anything
      // else says. Checked for EVERY dependent, alias or nominal, type-level or
      // value-level — arity is a property of the application, not of the
      // subtyping contract. Covers all three directions a clause edit can take:
      // a changed parameter count, generic → plain (`declaredArity` 0 against
      // applied uses) and plain → generic (a bare mention is arity 0, N7).
      for (const mention of mentions) {
        const arity = mention.args?.length ?? 0;
        if (arity !== declaredArity)
          throw new TypeVariableError(
            'generic-alias-arity',
            `${subject} applies "${replaced.name}" to ${arity} type argument${
              arity === 1 ? '' : 's'
            }, but "${replaced.name}" is now declared with ${declaredArity} type parameter${
              declaredArity === 1 ? '' : 's'
            } (surfaced when \`${justDeclared}\` was declared)`
          );
      }

      // BOUNDS: the arities now agree, so each argument is re-admitted against
      // the parameter it fills. A redeclaration that ADDS a bound
      // (`box<T>` → `box<T: integer>`) leaves every existing `box<string>`
      // behind it otherwise.
      if (params === undefined) return;
      for (const mention of mentions) {
        for (let i = 0; i < params.length; i++) {
          const bound = params[i].bound;
          if (bound === undefined) continue;
          const arg = mention.args![i];
          const free = freeTypeVariables(arg);
          let subjectArg = arg;
          if (free.size > 0) {
            const bindings: Record<string, Type> = Object.create(null);
            for (const v of free)
              bindings[v] =
                ownParams?.find((p) => p.name === v)?.bound ?? 'any';
            subjectArg = substituteTypeVariables(arg, bindings);
          }
          if (satisfiesTypeBound(subjectArg, bound)) continue;
          throw new TypeVariableError(
            'generic-alias-bound',
            `${subject} applies "${replaced.name}" to the type argument \`${typeToString(
              arg
            )}\`, which does not satisfy the bound \`${typeToString(bound)}\` of the parameter \`${
              params[i].name
            }\` of "${replaced.name}" (surfaced when \`${justDeclared}\` was declared)`
          );
        }
      }
    };

    // TYPE-level dependents come from the engine registry — one namespace,
    // no chain to walk.
    for (const record of Object.values(ce._typeRegistry)) {
      if (record === replaced || record.def === undefined) continue;
      recheckMentions(
        record.def,
        `The definition of "${record.name}"`,
        record.typeParams
      );

      // VARIANCE: only a parameterized nominal has one to re-verify, and a
      // still-deferred one belongs to the fixpoint below.
      if (record._varianceState !== 'verified') continue;
      if (record.typeParams === undefined) continue;
      const verdict = verifyVariance(
        record.name,
        record.typeParams,
        record.def,
        { triggeredBy: justDeclared }
      );
      if (verdict.status === 'violation')
        throw new TypeVariableError(verdict.code, verdict.message);
    }

    for (let s: Scope | null | undefined = scope; s; s = s.parent) {
      // VALUE-level dependents. A declared symbol type or operator signature
      // that mentions the record is broken by exactly the edits that break a
      // type dependent — after `type Foo<T>` replaces `type Foo`, a declared
      // `f: (Foo) -> integer` holds a bare application of a generic type, which
      // matches nothing, so `f` is uncallable with no diagnostic anywhere.
      //
      // Only DECLARED types are judged: an inferred one is the engine's own
      // running guess and is re-derived from use, not stated by an author.
      // Minted constructors are skipped too — they are derived from the type
      // records checked just above and are re-minted by the declaration running
      // right now, so within this window they are stale BY CONSTRUCTION (the
      // redeclared type's own constructor still carries the old clause).
      //
      // Out of scope, deliberately: types held by expressions that are already
      // boxed (design A5 — they keep the type they computed, exactly as a value
      // redeclaration leaves them), and CHILD scopes, which are unreachable
      // from here and, being popped by the time a later statement redeclares,
      // hold nothing a program can still use.
      for (const [bindingName, binding] of s.bindings) {
        if (isMintedConstructor(binding)) continue;
        let boxed: BoxedType | undefined;
        if (isOperatorDef(binding)) {
          if (binding.operator.inferredSignature) continue;
          boxed = binding.operator.signature;
        } else if (isValueDef(binding)) {
          if (binding.value.inferredType) continue;
          boxed = binding.value.type;
        } else continue;

        // A definition whose type cannot even be resolved is not a dependent
        // this pass can judge; leave it to whatever already reports it.
        let declared: Type;
        try {
          declared = boxed.type;
        } catch {
          continue;
        }
        const signature =
          typeof declared === 'object' && declared.kind === 'signature'
            ? declared
            : undefined;
        recheckMentions(
          declared,
          `The ${signature ? 'signature' : 'declared type'} of "${bindingName}"`,
          signature?.typeParams
        );
      }
    }
  }

  let progressed = true;
  while (progressed) {
    progressed = false;
    for (const record of Object.values(ce._typeRegistry)) {
      if (record._varianceState !== 'deferred') continue;
      if (record.typeParams === undefined || record.def === undefined) continue;
      let verdict: VarianceResult;
      try {
        verdict = verifyVariance(record.name, record.typeParams, record.def, {
          triggeredBy: justDeclared,
        });
      } catch (e) {
        undo();
        throw e;
      }
      if (verdict.status === 'violation') {
        undo();
        throw new TypeVariableError(verdict.code, verdict.message);
      }
      if (verdict.status === 'deferred') {
        record._varianceBlockedOn = verdict.blockedOn;
        continue;
      }
      wasBlockedOn.set(record, record._varianceBlockedOn);
      record._varianceState = 'verified';
      delete record._varianceBlockedOn;
      flipped.push(record);
      progressed = true;
    }
  }
  return flipped;
}

/**
 * `t` as a boxed type, or `undefined` when it is not one. This does not use
 * `instanceof BoxedType`: a plugin bundle re-bundles the engine classes, so
 * a boxed type made by the host is not an instance of the plugin's
 * `BoxedType` class, and the other way around. A boxed type is recognized by
 * its `type` field and its `matches()` method, as in
 * `normalizeSignatureField()` (`boxed-expression/boxed-operator-definition.ts`).
 */
/** The signature of the operator definition `def` as a `Type`: its
 * `signature` field (a type string, a `Type` or a `BoxedType`), or the
 * signature an operator without one gets, `(any*) -> unknown`. */
function declaredSignatureType(
  ce: IComputeEngine,
  def: OperatorDefinition
): Type {
  const sig = def.signature;
  if (sig === undefined) return parseType('(any*) -> unknown');
  return (
    asBoxedType(sig)?.type ??
    parseType(sig as Type | TypeString, ce._typeResolver)
  );
}

function asBoxedType(t: unknown): BoxedType | undefined {
  if (
    typeof t === 'object' &&
    t !== null &&
    'type' in t &&
    typeof (t as { matches?: unknown }).matches === 'function'
  )
    return t as BoxedType;
  return undefined;
}

/**
 * Build the definition that `ce.declare(id, patch, { extend: true })`
 * installs: the fields of the operator definition visible for `id` from
 * `scope`, overridden by the fields of `patch`.
 *
 * The visible definition is copied, never mutated. A cache or an expression
 * that holds the old definition object keeps a consistent view of it, as
 * with any other redeclaration.
 *
 * Copying a boxed definition copies its own enumerable properties, which
 * include engine-internal ones (their names start with `_`). The definition
 * constructor reads only these of them:
 *
 * - `_validationSignature` and `_derivedSignature`, when the definition has a
 *   `signature`. Both describe the signature that a function literal derived.
 *   When the patch changes the signature, the new one is a declared contract:
 *   `_derivedSignature` is set to `false` and `_validationSignature` is
 *   cleared, so that calls are validated against the NEW signature.
 *
 * The constructor ignores the other internal fields. Some of them are
 * computed again, and the function returned with the definition (`carry`)
 * copies the others onto the installed definition:
 *
 * - The function literal of a user function (`_lambdaLiteral`) is passed as
 *   the `evaluate` handler, so that the new definition is a user function
 *   again: it re-derives the effects of the body and keeps broadcasting over
 *   collections like the old one.
 * - The effect set is not an own property (`pure` and `effects` are getters).
 *   It survives the copy in the effect specifier of the copied `signature`.
 *   When the effects of the old definition were not declared but derived
 *   (from the body of a user function, or by the effect deriver of a
 *   protocol dispatcher), the specifier is removed from the copied
 *   signature: otherwise the new definition reads it as declared effects
 *   (`effectsDeclared`) and never derives them again.
 * - When the patch states the effects (`effects`, `pure` or `drawsRandom`),
 *   the specifier is removed from every arrow of the old signature that the
 *   new definition keeps, so that the stated effects replace the old ones.
 * - When the patch replaces the signature and states no effects, the old
 *   effect set is carried over as the `effects` field, so that an extension
 *   cannot make an impure operator pure.
 * - An explicit `commutativeMatch` is carried over for the same reason.
 * - `carry` copies the effect deriver of a protocol dispatcher
 *   (`_deriveEffects`), the skeleton of the `unknown` slots of a user
 *   function (`_signatureSkeleton`), and the history of signature changes
 *   (`_typeProvenance`), so that the new definition updates its signature
 *   and effects as the old one does.
 * - `carry` also records that the new definition extends a standard-library
 *   definition when the patch, and every earlier extension, kept its
 *   `evaluate`, `canonical`, `compile` and `derivative`, and the
 *   constructor did not remove the library `canonical` handler (it removes
 *   it when a flag that the handler assumes changes, as with
 *   `{ associative: false }` for `Add`). Such a definition does not shadow the library name (`shadowsLibraryName()`,
 *   `library-shadowing.ts`): `D`, compilation and the canonical folds keep
 *   treating the operator as the library one.
 *
 * Throws, and installs nothing, when there is no visible operator definition,
 * when the name is a value, when the function is defined by clauses (the
 * clause list belongs to the old definition object), or when the new
 * signature is not a subtype of the old one. The subtype requirement does
 * not apply when the old signature was only inferred (`inferredSignature`):
 * such a signature is not a contract, and a plain `ce.declare()` may replace
 * it too.
 */
function extendedOperatorDefinition(
  ce: IComputeEngine,
  id: string,
  patch: unknown,
  scope: Scope
): {
  def: OperatorDefinition;
  carry: (installed: BoxedOperatorDefinition) => void;
  keepsStandardLibraryCode: boolean;
} {
  if (
    patch === null ||
    typeof patch !== 'object' ||
    Array.isArray(patch) ||
    isExpression(patch) ||
    asBoxedType(patch) !== undefined
  )
    throw new Error(
      `Cannot extend "${id}": with \`{ extend: true }\`, the definition must be an object with the fields to change`
    );

  const visible = lookup(id, scope);
  if (visible === undefined)
    throw new Error(
      `Cannot extend "${id}": it has no definition to extend. Declare it first, without \`extend\``
    );
  if (!isOperatorDef(visible))
    throw new Error(
      `Cannot extend "${id}": it is declared as a value, and only an operator definition can be extended`
    );
  const old = visible.operator;
  if ((old as { _isMultiClause?: boolean })._isMultiClause)
    throw new Error(
      `Cannot extend "${id}": it is a function defined by clauses. Add a clause instead`
    );

  const { addSignature, ...fields } = patch as OperatorDefinitionPatch;
  if (addSignature !== undefined && fields.signature !== undefined)
    throw new Error(
      `Cannot extend "${id}": give either \`signature\` or \`addSignature\`, not both`
    );

  const def: OperatorDefinition = { ...old, ...fields };

  // The collection handlers of a host operator are installed wrapped
  // (`withHostCollectionHandlers`, `shared-evaluation-memo.ts`). The new
  // definition wraps the handlers that the host gave, not the wrapped ones:
  // thus a handler is wrapped one time, and the wrapper reads the purity of
  // the new definition.
  if (!('collection' in fields)) {
    const source = hostCollectionSource(old.collection);
    if (source !== undefined) def.collection = source as CollectionHandlers;
  }

  // An extension that keeps the `evaluate`, `evaluateAsync` and collection
  // handlers of an operator of a standard library runs no host code when it
  // evaluates: it is made as a definition of the standard library
  // (`withStandardLibraryInstall()`, `host-handler-changes.ts`), so that
  // the memos of evaluated results keep its results.
  const keepsStandardLibraryCode =
    old._standardLibrary &&
    !('evaluate' in fields) &&
    !('evaluateAsync' in fields) &&
    !('collection' in fields);

  // An update that states nothing about purity keeps the statement of the
  // old definition (`_purityStated`). The constructor clears it for a
  // definition that has a signature with no effects, and the copy above
  // carries the signature of the old definition.
  const keepsPurityStatement =
    fields.pure === undefined &&
    fields.drawsRandom !== true &&
    fields.effects === undefined &&
    fields.signature === undefined;

  // An explicit `commutativeMatch` is stored in a private field and read
  // through a getter, so the copy above does not carry it.
  const explicitMatch = (old as unknown as { _commutativeMatch?: boolean })
    ._commutativeMatch;
  if (!('commutativeMatch' in fields) && explicitMatch !== undefined)
    def.commutativeMatch = explicitMatch;

  // An ordering handler (`commutativeOrder`) requires the `commutative` flag.
  // When the patch removes the flag and gives no handler of its own, the
  // handler of the old definition is not copied: for example, after
  // `ce.declare('Add', { commutative: false }, { extend: true })`, the
  // library ordering of `Add` is removed and the operands keep their order.
  // This is the same as for the library `canonical` handler, which the
  // definition constructor removes when a flag that it assumes changes. A
  // patch that gives a handler together with `commutative: false` is still
  // an error.
  if (fields.commutative === false && !('commutativeOrder' in fields))
    def.commutativeOrder = undefined;

  // A user function: pass its literal as the `evaluate` handler, so that the
  // new definition is built from the literal as the old one was.
  if (!('evaluate' in fields) && old._lambdaLiteral !== undefined)
    def.evaluate = old._lambdaLiteral;
  const keepsLambda =
    old._lambdaLiteral !== undefined && def.evaluate === old._lambdaLiteral;

  //
  // The signature
  //
  const toType = (t: Type | TypeString | BoxedType): Type =>
    asBoxedType(t)?.type ?? parseType(t as Type | TypeString, ce._typeResolver);
  // An overload set is an intersection of signatures: its arms.
  const armsOf = (t: Type): Type[] =>
    typeof t === 'object' && t.kind === 'intersection' ? t.types : [t];
  const oldSignature = old.signature.type;
  // A patch that states the effects (`effects`, `pure` or `drawsRandom`)
  // replaces the effect set of the old definition. The old signature carries
  // that effect set in the effect specifier of each arrow, and the definition
  // constructor reads such a specifier as declared effects: it throws when
  // they differ from the stated ones. So every arrow of the old signature
  // that the new definition keeps loses its effect specifier.
  const statesEffects =
    fields.effects !== undefined ||
    fields.pure !== undefined ||
    fields.drawsRandom !== undefined;
  let signature: Type | undefined = undefined;
  if (fields.signature !== undefined) signature = toType(fields.signature);
  else if (addSignature !== undefined) {
    // The old arms come first: a call that matches an old arm resolves as it
    // did before.
    signature = {
      kind: 'intersection',
      types: [
        ...armsOf(oldSignature).map((arm) =>
          statesEffects ? stripArrowEffects(arm) : arm
        ),
        ...armsOf(toType(addSignature)),
      ],
    };
  }

  // The effect deriver of a protocol dispatcher does not depend on the
  // definition object, so the new definition can use it. The deriver of a
  // user function walks the old literal and writes to the old definition:
  // the new definition builds its own from the literal.
  const copiesDeriver =
    signature === undefined &&
    !statesEffects &&
    old._lambdaLiteral === undefined &&
    old._deriveEffects !== undefined;
  const copiesSkeleton =
    signature === undefined &&
    keepsLambda &&
    old._signatureSkeleton !== undefined;

  if (signature === undefined && (keepsLambda || copiesDeriver)) {
    // With a skeleton, the signature the old definition reports is derived
    // from the skeleton on each read. The stored one is the base of that
    // derivation, so it is the one to copy.
    const base = copiesSkeleton
      ? (old as unknown as { _signature: BoxedType })._signature
      : old.signature;
    // Effects that were derived, not declared, are derived again: keep them
    // out of the signature, which would otherwise declare them.
    def.signature = old.effectsDeclared
      ? base
      : ce.type(stripArrowEffects(base.type));
  }

  if (signature === undefined && statesEffects) {
    const current = asBoxedType(def.signature)?.type ?? oldSignature;
    def.signature = ce.type(
      typeof current === 'object' && current.kind === 'intersection'
        ? { ...current, types: current.types.map(stripArrowEffects) }
        : stripArrowEffects(current)
    );
  }

  if (signature !== undefined) {
    // Every call that was valid must stay valid: the new signature must be a
    // subtype of the old one (wider or equal parameters, narrower or equal
    // result). A signature that was only inferred (the `(any*) -> unknown`
    // of an operator declared without one, or the signature inferred from
    // the body of a user function) is not a contract, and is not checked.
    const newType = ce.type(signature);
    if (
      old.inferredSignature !== true &&
      !newType.matches(ce.type(oldSignature))
    )
      throw new Error(
        `Cannot extend "${id}": the signature "${newType}" is not a subtype of the current signature "${typeToString(oldSignature)}", so some calls that are valid now would become invalid`
      );
    def.signature = newType;
    def.inferredSignature = false;
    def._derivedSignature = false;
    def._validationSignature = undefined;

    // Carry the old effect set when nothing in the patch states one. A user
    // function whose effects were inferred from its body is excluded: its
    // body is inferred again.
    const reinfers = keepsLambda && !old.effectsDeclared;
    if (
      !statesEffects &&
      signatureEffects(newType.type) === undefined &&
      !reinfers &&
      (old.effectsDeclared || old.effects !== undefined)
    )
      def.effects = old.effects ?? [];
  }

  // The library definition that the new definition extends: the old one if
  // it is the definition of the system scope, where the standard library is
  // installed, or the one that the old definition extends. An extension that
  // replaces a part that code reads from the library by name is a shadow.
  const replacesLibraryPart =
    'evaluate' in fields ||
    'canonical' in fields ||
    'compile' in fields ||
    'derivative' in fields;
  const systemBinding = ce.contextStack[0]?.lexicalScope.bindings.get(id);
  const library = replacesLibraryPart
    ? undefined
    : systemBinding !== undefined &&
        isOperatorDef(systemBinding) &&
        systemBinding.operator === old
      ? old
      : extendedLibraryOperator(old);

  const carry = (installed: BoxedOperatorDefinition): void => {
    if (keepsPurityStatement) installed._purityStated = old._purityStated;
    if (copiesDeriver) installed._deriveEffects = old._deriveEffects;
    if (copiesSkeleton) installed._signatureSkeleton = old._signatureSkeleton;
    if (old._typeProvenance !== undefined)
      installed._typeProvenance = [
        ...old._typeProvenance,
        ...(installed._typeProvenance ?? []),
      ];
    // The constructor can remove a handler that the patch did not name: it
    // removes the library `canonical` handler of an arithmetic operator when
    // the patch changes one of the flags that this handler assumes
    // (`{ associative: false }` for `Add`). Such a definition no longer
    // computes the canonical form of the library operator, so it is not
    // marked as an extension of it, and it shadows the library name.
    if (
      library !== undefined &&
      installed.canonical === (library as { canonical?: unknown }).canonical
    )
      markLibraryExtension(installed, library);
  };

  return { def, carry, keepsStandardLibraryCode };
}

export function declareFn(
  ce: IComputeEngine,
  arg1:
    | string
    | {
        [id: string]: Type | TypeString | SymbolDefinitionInput;
      },
  arg2?: Type | TypeString | SymbolDefinitionInput | OperatorDefinitionPatch,
  arg3?: Scope | DeclareOptions
): IComputeEngine {
  // The third argument is a scope, or an options object. A scope always has
  // a `bindings` map, and an options object never has one.
  let scope: Scope | undefined;
  let extend = false;
  if (arg3 !== undefined && arg3 !== null) {
    if ('bindings' in arg3) scope = arg3;
    else {
      scope = arg3.scope;
      extend = arg3.extend === true;
    }
  }

  //
  // If the argument is an object literal, call `declare` for each entry
  //
  if (typeof arg1 !== 'string') {
    for (const [id, def] of Object.entries(arg1)) ce.declare(id, def);
    return ce;
  }

  const id = arg1;

  // The special id `Nothing` can never be redeclared.
  // It is also used to indicate that a symbol should be ignored,
  // so it's valid, but it doesn't do anything.
  if (id === 'Nothing') return ce;

  // Can't "undeclare" (set to `undefined`/`null`) a symbol either
  // (but its value can be set to `undefined` with `ce.assign()`)
  if (arg2 === undefined || arg2 === null)
    throw Error(`Expected a definition or type for "${id}"`);

  // Check the id is valid
  if (typeof id !== 'string' || id.length === 0 || !isValidSymbol(id)) {
    throw new Error(`Invalid symbol "${id}": ${validateSymbol(id)}`);
  }

  scope ??= ce.context.lexicalScope;

  // The binding that this declaration makes decides whether `id` is a
  // constant default, not a declaration of the scope that was canonicalized
  // earlier and has not run (`forgetConstantDeclaration()`).
  forgetConstantDeclaration(ce, id, scope);

  assertDeclarationName(ce, id, scope);

  // Extend mode replaces a binding of the same scope on purpose, so it skips
  // the "already declared" check below.
  if (extend) {
    // If the definition constructor refuses the result, the declaration
    // puts the previous binding back (`declareSymbolOperator`).
    const { def, carry, keepsStandardLibraryCode } = extendedOperatorDefinition(
      ce,
      id,
      arg2,
      scope
    );
    const installed = keepsStandardLibraryCode
      ? withStandardLibraryInstall(() =>
          ce._declareSymbolOperator(id, def, scope)
        )
      : ce._declareSymbolOperator(id, def, scope);
    if (isOperatorDef(installed)) carry(installed.operator);
    return ce;
  }

  //
  // Check the id is not already declared in the current scope.
  //
  // Tolerate re-declaring a name that was only *auto-declared* (its type or
  // signature inferred from usage, e.g. by `ce.parse('f(x)')` or
  // `ce.parse('a + 1')`). An explicit declaration is allowed to refine an
  // inferred one — that is precisely what the `inferred` flag exists for — so
  // a declare-first flow can parse cells to discover names and then declare
  // them on the same engine without throwing. Re-declaring an *explicit*
  // binding still throws. The declaration below overwrites the inferred one.
  //
  const bindings = scope.bindings;
  const existing = bindings.get(id);
  if (existing !== undefined) {
    // Only a *value-less* inferred binding is upgradable: it was auto-declared
    // from usage (e.g. a free variable or function call seen by `parse`). A
    // binding that carries a value — a function argument, or an outer explicit
    // declaration — is a genuine conflict and still throws. This mirrors the
    // upgrade rule in the `Declare` operator handler (library/core.ts).
    //
    // For an operator, `inferredSignature` alone does not show that the
    // binding came from a use: an operator that the author declared with a
    // handler but no `signature` also has an inferred signature, and so does
    // a function literal given to `ce.assign()`. Only an operator that holds
    // nothing the author gave is upgradable (`isReplaceableOperatorShell()`).
    const inferred =
      (isValueDef(existing) &&
        existing.value.inferredType &&
        existing.value.value === undefined) ||
      (isOperatorDef(existing) &&
        isReplaceableOperatorShell(existing.operator));
    if (!inferred)
      throw new Error(`The symbol "${id}" is already declared in this scope`);
  }

  //
  // Declaring a symbol or function with a definition or type
  //

  const def = arg2;

  // A macro (`macro.ts`): a value definition with the raw body, no value and
  // the type `unknown`. The body is checked to be MathJSON, and not boxed.
  if (
    typeof def === 'object' &&
    def !== null &&
    (def as { macro?: unknown }).macro !== undefined
  ) {
    const fields = Object.keys(def).filter(
      (k) => (def as Record<string, unknown>)[k] !== undefined
    );
    const body = (def as { macro?: unknown }).macro;
    const problem =
      fields.length !== 1
        ? 'A macro definition has no field other than `macro`'
        : !isMathJsonShape(body)
          ? 'The `macro` field must be a MathJSON expression'
          : undefined;
    if (problem !== undefined)
      throw Error(
        [`Invalid argument for "${id}"`, fields.join(', '), problem].join(
          '\n|   '
        )
      );
    ce._declareSymbolValue(
      id,
      { type: 'unknown', macro: body as MathJsonExpression },
      scope
    );
    noteMacroDeclared(ce, id);
    return ce;
  }

  if (isValidValueDef(def)) {
    // Phase 3 §6.3 — declared-signature reconciliation (declare-with-value and
    // `Declare(f, type, value)` evaluate paths). When declaring a function
    // literal against an explicit function signature, ascribe the declared
    // return type onto the literal (if it lacks its own) so a merely-wider body
    // inference does not trip the covariant compatibility check. Genuine
    // conflicts still throw in the value-definition constructor.
    // Effects-axis provenance (`docs/EFFECTS-MODEL.md`, "Annotation
    // provenance"): the statement lives in the TYPE — a non-empty specifier,
    // or `pure`, which builds the stated-empty `effects: []`. A bare slot
    // leaves effects on the inferred track. An explicit `effectsDeclared` on
    // the incoming definition wins.
    const effectsDeclared =
      def.effectsDeclared ?? declaredTypeStatesEffects(ce, def.type);

    let valueDef: Partial<ValueDefinition> = effectsDeclared
      ? { ...def, effectsDeclared }
      : def;
    // The default-`!scope` ceiling (`docs/EFFECTS-MODEL.md`, "Scope is
    // opt-in"): a function literal declared with no stated effects must not
    // write outside itself, in any scope, as on the declare-then-assign
    // routes. It is not enforced when the engine binds a local, such as the
    // argument of a function application (`markLocalBinding()`).
    const checksScope = !isLocalBinding(def);
    // The declared-signature reconciliation and the effect checks of a
    // function literal `value`. They give the definition to install:
    // `prepared` with the reconciled literal and, when it is refined, the
    // declared type.
    const prepare = (
      prepared: Partial<ValueDefinition>,
      value: Expression
    ): Partial<ValueDefinition> => {
      let out = prepared;
      let effectsChecked = false;
      if (def.type !== undefined && isFunction(value, 'Function')) {
        // The resolver makes engine-local type names (`(meters) -> unknown`
        // with a `type meters = number` alias) parse here, exactly as the
        // value-definition constructor's own parse does — omitting it threw
        // before that constructor was reached.
        const declaredType0 =
          def.type instanceof BoxedType
            ? def.type.type
            : parseType(def.type, ce._typeResolver);
        // Placeholder refinement, as on the assign routes (two passes — the
        // second, below, adopts the post-ascription result a pass-through body
        // only shows after reconciliation): declared `unknown` slots adopt the
        // literal's inferred slots, and the refined type is what the definition
        // installs under.
        // The body's result under the declared parameter types, as on the
        // assign routes (`resultUnderDeclaredParameters`).
        const typedResult = resultUnderDeclaredParameters(
          ce,
          value,
          declaredType0
        );
        const withTypedResult = (t: Type): Type =>
          typedResult === undefined ? t : withSignatureResult(t, typedResult);
        let declaredType = refineDeclaredPlaceholders(
          declaredType0,
          withTypedResult(value.type.type)
        );
        if (hasFunctionSignature(declaredType)) {
          // G11 (§2.4) — see the assign path. Checked FIRST, ahead of the
          // arity/effects assertions: an overload set with a generic arm is not
          // a shape one erased body can implement, so an arity diagnostic for it
          // would name the wrong problem. A SINGLE generic signature proceeds
          // through the ordinary reconciliation below, whose return step knows
          // not to ascribe a variable-mentioning result (§2.4).
          if (isPolymorphicType(declaredType))
            assertSingleArmPolytype(id, value, ce.type(declaredType));
          // The literal must be arity-compatible with the declared signature
          // (mirrors the assign path); otherwise a declared-arity call would
          // silently partial-apply.
          assertFunctionLiteralArity(
            id,
            value,
            declaredType,
            ce.type(declaredType).toString()
          );
          // The return is reconciled against the DECLARED result, not the one
          // refined from the typed result above: that result is CE's derivation,
          // not the host's contract, and ascribing it wrote a `Typed` marker into
          // the stored literal (`x ↦ a` with `a: integer` stored
          // `Typed(a, 'integer')`), which froze the result: a later retype of `a`
          // could not change the signature. The declared result is `unknown`
          // whenever there is a typed result, and `unknown` ascribes nothing.
          const reconciled = reconcileFunctionLiteralReturn(
            ce,
            ascribeDeclaredParameterTypes(
              ce,
              value,
              // As on the assign routes: a placeholder slot is not stamped
              // (`placeholderSlotsAs`).
              placeholderSlotsAs(declaredType, declaredType0, 'unknown')
            ),
            typedResult === undefined
              ? declaredType
              : withSignatureResult(declaredType, 'unknown'),
            id
          );
          if (checksScope)
            assertScopeCeiling(
              ce,
              id,
              reconciled,
              declaredType,
              effectsDeclared
            );
          else
            assertDeclaredEffects(
              id,
              reconciled,
              declaredType,
              effectsDeclared
            );
          effectsChecked = true;
          // Second refinement pass — adopt the post-ascription result.
          declaredType = refineDeclaredPlaceholders(
            declaredType,
            withTypedResult(reconciled.type.type)
          );
          out = { ...out, value: reconciled };
        }
        // A declaration with `unknown` slots installs AS WRITTEN: the value
        // definition keeps it as its signature skeleton and derives the
        // refined signature from the stored value on each read
        // (`_signatureSkeleton`). Installing the refinement instead would
        // replace the placeholders with the body's type at this moment, and a
        // head that the body calls and that is bound later could not change
        // it.
        if (
          declaredType !== declaredType0 &&
          !hasSignaturePlaceholder(declaredType0)
        )
          out = { ...out, type: ce.type(declaredType) };
      }
      // A literal with no declared signature (`{ value }`, or a type such
      // as `function`) gets the same ceiling. With no stated effects the
      // declared type is not read, so `unknown` stands for it.
      if (
        checksScope &&
        !effectsChecked &&
        !effectsDeclared &&
        isFunction(value, 'Function')
      )
        assertScopeCeiling(ce, id, value, 'unknown', false);
      return out;
    };
    // A boxed value is prepared here. Any other value (LaTeX, MathJSON, or
    // a function that makes the value) is prepared by the value-definition
    // constructor, after it converts the value: it converts it in the
    // declaring scope, after the placeholder binding that lets a recursive
    // literal refer to its own name, and with no temporary assumption in
    // force. When the preparation throws, `declareSymbolValue()` restores
    // the previous binding.
    if (isExpression(def.value)) valueDef = prepare(valueDef, def.value);
    else if (
      def.value !== undefined &&
      (def.type !== undefined || (checksScope && !effectsDeclared))
    ) {
      valueDef = { ...valueDef };
      prepareValueWhenBoxed(valueDef, prepare);
    }
    ce._declareSymbolValue(id, valueDef, scope);
    return ce;
  }

  if (isValidOperatorDef(def)) {
    ce._declareSymbolOperator(id, def, scope);
    return ce;
  }

  //
  // Declaring a symbol with a type
  // `ce.declare("f", "number -> number")`
  // `ce.declare("z", "complex")`
  // `ce.declare("n", "integer")`
  //
  {
    const type = parseType(def as Type | TypeString, ce._typeResolver);
    if (!isValidType(type)) {
      throw Error(
        [
          `Invalid argument for "${id}"`,
          JSON.stringify(def, undefined, 4),
          `Use a type, a \`OperatorDefinition\` or a \`ValueDefinition\``,
        ].join('\n|   ')
      );
    }

    ce._declareSymbolValue(
      id,
      {
        type,
        effectsDeclared: signatureEffects(type) !== undefined,
      },
      scope
    );
  }

  return ce;
}

/**
 * Remove the binding of each name in `names` from the current scope. See
 * `IComputeEngine.undeclare()` for the contract.
 *
 * Every name is checked before any binding is removed, so a refused name
 * leaves the scope unchanged.
 */
export function undeclare(
  ce: IComputeEngine,
  names: MathJsonSymbol | ReadonlyArray<MathJsonSymbol>
): void {
  const scope = ce.context.lexicalScope;
  const list = typeof names === 'string' ? [names] : [...new Set(names)];
  for (const name of list) assertUndeclarable(ce, scope, name);
  for (const name of list) removeBinding(ce, scope, name);
}

/** Throw when `undeclare()` must not remove the binding of `name` from
 * `scope`. */
function assertUndeclarable(
  ce: IComputeEngine,
  scope: Scope,
  name: unknown
): void {
  if (typeof name !== 'string' || name.length === 0)
    throw new Error(
      `Cannot undeclare ${JSON.stringify(name)}: a name must be a non-empty string`
    );
  // A library installs its definitions in the system scope (the standard
  // libraries and the libraries given to the constructor) or in the global
  // scope (`loadLibrary()`), and records each binding it installs. The
  // library is checked first, so that the message for `Sin` names the
  // library and not the scope.
  const binding = scope.bindings.get(name);
  const visible = binding ?? lookup(name, scope);
  const provenance = ce._libraryProvenance.get(name);
  if (provenance !== undefined && provenance.binding === visible)
    throw new Error(
      `Cannot undeclare "${name}": it is defined by the library "${provenance.library}"`
    );
  const systemScope = ce.contextStack[0]?.lexicalScope;
  if (visible !== undefined && systemScope?.bindings.get(name) === visible)
    throw new Error(
      `Cannot undeclare "${name}": it is defined in the system scope, which holds the standard library`
    );
  if (binding === undefined) {
    throw new Error(
      visible === undefined
        ? `Cannot undeclare "${name}": it is not declared in the current scope`
        : `Cannot undeclare "${name}": it is not declared in the current scope. Its declaration is in an enclosing scope, which \`undeclare()\` does not change`
    );
  }
  // The variable of a binder operator (a `Sum` index, a comprehension
  // index, a `D` variable) and a parameter of a function that is being
  // evaluated belong to the expression that declared them. The scope of
  // such an expression is the current scope only while it is evaluated.
  if (
    scope.binderNames?.has(name) === true ||
    binderBindingOf(ce, name, scope) !== undefined
  )
    throw new Error(
      `Cannot undeclare "${name}": it is a variable of an operator such as \`Sum\`, or a parameter of a function, and it is bound only while that expression is evaluated`
    );
}

/** Remove the binding of `name` from `scope`, and retire the removed
 * binding record. */
function removeBinding(ce: IComputeEngine, scope: Scope, name: string): void {
  const binding = scope.bindings.get(name)!;

  beforeScopeWrite(ce, scope, name);
  scope.bindings.delete(name);
  // A live frame that counted the removed definition stops counting it
  // (`uncountRemovedHolder`, `engine-scope.ts`).
  if (isValueDef(binding)) uncountRemovedHolder(ce, scope, binding.value);

  // The base cases and the recurrence assigned to the name before its
  // sequence definition is complete (`F_0 := 10` without `F_n := …`) are
  // removed with the binding. Otherwise a later declaration of the name
  // completes a sequence with the base cases of the removed declaration.
  _removePendingSequence(ce, name, scope);

  // A head that declares a value kind (the `arithmetic` field) loses its
  // dispatch entry: its values boxed before this call have no hooks any
  // more. The kind TYPE stays a kind type, with its fields, so its values
  // and its symbols stay protected from the number rules
  // (`unregisterKind()`, `value-kinds.ts`).
  if (
    isOperatorDef(binding) &&
    arithmeticOf(ce, binding.operator) !== undefined
  )
    unregisterKind(ce, binding.operator);

  retireBindingRecord(ce, scope, name, binding);
}

/**
 * Retire `binding`, the binding record of `name` that the caller removed
 * from the bindings of `scope`: `removeBinding` (`ce.undeclare()`), and the
 * `Declare` handler (`library/core.ts`) when it drops a binding that holds a
 * clause installed before the declaration ran.
 */
export function retireBindingRecord(
  ce: IComputeEngine,
  scope: Scope,
  name: string,
  binding: BoxedDefinition
): void {
  const callableBefore = defIsCallableShaped(binding);

  // An expression boxed before this call holds the record by identity. The
  // record gets an empty value definition of type `unknown` in place of its
  // definition, so that such an expression no longer reads the removed
  // definition: a call `f(2)` stays unevaluated, and reads the definition
  // of `f` that the scope chain holds at the time it is evaluated, as a call
  // boxed after this one does. When the removed
  // definition is a constant, `updateDef` also makes it stop listening to
  // configuration changes.
  updateDef(ce, name, binding, { type: 'unknown', inferred: true }, scope);
  // A call of such an expression reads the definition of the name from this
  // scope and the scopes that enclose it, and not from an unrelated scope
  // where it is evaluated (`callableBindingInContext`, `binders.ts`).
  markRetiredBinding(binding, scope);

  // The name resolves to another binding, or to none, from this scope and
  // the scopes under it. The memo of a derived signature counts the
  // declarations made in each scope of its chain.
  noteScopeDeclaration(scope);

  // Advance the same versions as an assignment of a new function to the
  // name (`redefine`), and the versions that the type and effect caches of
  // existing expressions key on (`binding-repair`). The record is no longer
  // in a scope, but a value of type `unknown` can still be applied, so the
  // record stays callable.
  const scratch = scratchRootOf(ce, scope) !== undefined;
  ce._noteStateEvent({
    kind: 'binding-repair',
    ...(scratch ? { scratch: true } : {}),
  });
  ce._noteStateEvent({ kind: 'redefine', callableBefore, callableAfter: true });
}

/**
 * Options of {@link assignFn} that the public `ce.assign()` does not take.
 */
export type AssignFnOptions = {
  /**
   * The effect contract of the assigned function literal, given by a caller
   * that replaces a whole function definition (an Epsil `function` statement
   * that replaces a lone clause, `defineFunctionClause()`). `declared` is
   * true when the literal states its effects, and `effects` is the stated
   * set (`[]` for `pure`).
   *
   * When it is given, the operator route uses this contract in place of the
   * contract of the definition in force: the incoming literal is checked
   * against it, and the installed definition carries it. Without it, the
   * route keeps the effect contract of the definition in force, which is
   * correct for a plain re-assignment to a declared name.
   */
  effectContract?: { declared: boolean; effects: EffectSet | undefined };
  /**
   * The name is a local that a `Declare` statement initializes with a
   * function value (`declareSteps()`, `library/core.ts`): as for a local
   * declared with a value, the definition is not held to the default-`!scope`
   * ceiling (`markLocalBinding()`).
   */
  bindsLocal?: boolean;
};

/**
 * True when `expr` names `id` as a symbol or as an operator. Each node is
 * read once: an expression can share a subexpression in several places
 * (`Max(e, e)` nested 30 deep has 31 distinct nodes and 2^30 paths), and
 * its serialized MathJSON, which this replaces, writes out every path and
 * ran out of memory at depth 30 (CE-594.1).
 */
function mentionsName(
  expr: Expression,
  id: string,
  read: Set<Expression> = new Set()
): boolean {
  if (isSymbol(expr)) return expr.symbol === id;
  if (read.has(expr)) return false;
  // A dictionary is not a function node (it has no operands): its values,
  // which can hold unevaluated expressions such as a self-call, are read
  // explicitly.
  if (isDictionary(expr)) {
    read.add(expr);
    return expr.keys.some((key) => mentionsName(expr.get(key)!, id, read));
  }
  if (!isFunction(expr)) return false;
  read.add(expr);
  if (expr.operator === id) return true;
  return expr.ops.some((op) => mentionsName(op, id, read));
}

/**
 * True when the name `id`, read in the body of the function literal `literal`,
 * denotes a binding outside the literal that is not the binding `id` denotes
 * here. Such a mention is not a call of the function being assigned: with
 * `h = n ↦ Block(g := z ↦ 0, z ↦ g(z) + n)`, the closure `h(1)` reads the `g`
 * of its own call of `h`, also after `g := h(1)` in another function.
 *
 * A binding that has no value and is not a local or a parameter does not count
 * (a forward reference, or a symbol that was declared when it was first read):
 * it does not define the name, so the assignment gives the mention its meaning.
 * A binding in the scope of the body of the literal does not count either: it
 * is a parameter, or a declaration that canonicalizing the body made for a name
 * that was unknown then.
 */
function readsOtherBinding(
  ce: IComputeEngine,
  literal: Expression,
  id: string
): boolean {
  if (!isFunction(literal) || !isFunction(literal.op1)) return false;
  const bodyScope = literal.op1.localScope;
  if (bodyScope === undefined || bodyScope.bindings.has(id)) return false;
  for (let scope = bodyScope.parent; scope; scope = scope.parent) {
    const found = scope.bindings.get(id);
    if (found === undefined) continue;
    if (
      isValueDef(found) &&
      found.value.value === undefined &&
      !found.value._blockLocal &&
      !isParameterActivation(found.value)
    )
      return false;
    // An outdated binding of a block that runs now stands for the binding of
    // this run (`callableBindingInContext()`): it is the same variable.
    return callableBindingInContext(ce, id, found) !== ce.lookupDefinition(id);
  }
  return false;
}

export function assignFn(
  ce: IComputeEngine,
  arg1: string | { [id: string]: AssignValue },
  arg2?: AssignValue,
  options?: AssignFnOptions
): IComputeEngine {
  //
  // If the first argument is an object literal, call `assign()` for each key
  //
  if (typeof arg1 === 'object') {
    console.assert(arg2 === undefined);
    for (const [id, def] of Object.entries(arg1)) ce.assign(id, def);
    return ce;
  }

  // While the assignment runs, the types of the value are computed when the
  // name has no value yet, and the result type of a function literal is
  // read from the type of its body. A call of the name in that body is a
  // recursive call, not a call of a function with no body
  // (`unknownCallMayBeRecursive()`, `declared-parameter-result.ts`).
  return whileDefining(ce, arg1, () =>
    assignNamedValue(ce, arg1, arg2, options)
  );
}

/**
 * `ce.assign(id, undefined)`: remove the value of the variable `id`. The
 * declaration and its type stay. A name with no definition stays
 * undeclared: there is no value to remove, and no value to infer a type
 * from. A constant, and a name defined as a function, refuse: a constant
 * keeps its value, and a function definition has no value to remove.
 */
function removeAssignedValue(ce: IComputeEngine, id: string): void {
  // As for any other value: `Nothing` keeps its value, a macro has none.
  if (id === 'Nothing') return;
  const def = ce.lookupDefinition(id);
  if (def === undefined) return;
  if (isMacroDef(def)) throw macroWriteError('assign', id);
  if (!isValueDef(def))
    throw new Error(
      `Cannot remove the value of "${id}": it is defined as a function, and a function definition has no value`
    );
  if (def.value.isConstant) throw new ConstantAssignmentError(id);
  // The same setter as for any other value, so the cache versions advance as
  // for any other write.
  setSymbolValue(ce, id, undefined);
}

/** `assignFn()` for one name `id`. */
function assignNamedValue(
  ce: IComputeEngine,
  id: string,
  arg2?: AssignValue,
  options?: AssignFnOptions
): IComputeEngine {
  // D6 — assignment FULL-REPLACES, so everything `clause-identity.ts` remembers
  // about the binding's current definition record stops being true here. The
  // clause LIST needs no such call: it hangs off the inner operator object and
  // dies when that half is swapped. The single-clause side-channels hang off
  // the OUTER record, which `updateDef()` mutates in place and which therefore
  // survives the assignment — so without this they outlive the clause they
  // describe. `f(n) = 1` then `f = x => 42` then `f(m) = 2` refused the third
  // statement as a redefinition of a clause the assignment had already thrown
  // away, and answered 42 instead of installing it.
  //
  // Deliberately NOT hooked into `updateDef()` itself, which looks like the
  // tidier choke point: `DefineFunction`'s own recursion-knot machinery
  // retypes the target through that path while a clause is being installed, so
  // clearing there wiped the stamp mid-definition and let a genuine duplicate
  // clause through. Only ASSIGNMENT means full replacement.
  //
  // `undefined` removes the value of a variable and keeps its declaration and
  // its type (the contract of `ce.assign()`). It replaces nothing, so it comes
  // before the clause provenance is cleared.
  if (arg2 === undefined) {
    removeAssignedValue(ce, id);
    return ce;
  }
  clearClauseProvenance(ce.lookupDefinition(id));

  // An object belongs to the engine that constructed it. Checked here as well
  // as in `setSymbolValue` because a first assignment to an undeclared name
  // installs its value through the declaration path instead of the setter.
  // Transitive, for the reason given there: a container holding a foreign
  // object smuggles it in.
  if (adoptsForeignEngineObject([arg2 as Expression], ce)) {
    throw new Error(
      `object-foreign-engine: cannot assign an object that belongs to a different engine to "${id}"`
    );
  }

  // Cannot set the value of 'Nothing'
  // @todo: could have a 'locked' attribute on the definition
  if (id === 'Nothing') return ce;

  // A macro has no value (`macro.ts`).
  if (isMacroDef(ce.lookupDefinition(id))) throw macroWriteError('assign', id);

  // A function literal assigned to a symbol declared with a function type
  // whose parameters have a value kind arm (`f: (real | umeasurement) -> …`)
  // has those parameters typed from the declaration before its body is
  // canonicalized, as for `ce.declare()` with a body
  // (`kindTypedFunctionLiteral()`): an untyped parameter folds `x/x` to `1`.
  {
    const declared = ce.lookupDefinition(id);
    if (
      declared !== undefined &&
      isValueDef(declared) &&
      !declared.value.inferredType
    ) {
      const typed = kindTypedFunctionLiteral(
        ce,
        arg2,
        declared.value.type.type
      );
      if (typed !== undefined) arg2 = typed as AssignValue;
    }
  }

  // §4.5b D13/D15: when `id` names a type in the CURRENT scope and its minted
  // constructor is bound, loosen the constructor's signature while the
  // assigned literal canonicalizes (both here in the knot-tying re-box and in
  // the recognition block below) — a self-call in a constructor-function body
  // must not validate against the strict pre-install signature. Restored
  // right after canonicalization; the install then replaces the definition.
  let restoreCtor: (() => void) | undefined = undefined;
  {
    const scope = ce.context.lexicalScope;
    if (
      ce._typeRegistry[id]?.def !== undefined &&
      arg2 !== null &&
      typeof arg2 === 'object'
    )
      restoreCtor = loosenMintedConstructor(ce, scope, id);
  }

  // Tie the recursion knot for a programmatic box-then-assign (mirroring the
  // `Assign` operator's canonicalization): when the assigned value is a
  // `Function` literal whose body references `id`, the literal may have been
  // canonicalized BEFORE `id` was known to be a function — its self-call is
  // then bound to a stale auto-declaration (an undeclared name types the
  // application `any`, a shell-declared one `unknown`), and every downstream
  // consumer of the body's types misfires (e.g. the compile targets'
  // collection guard fail-closes on the top-typed self-call). Pre-declare
  // `id` as function-typed, then re-canonicalize the literal from its JSON so
  // the self-reference binds and types against the real definition. A mention
  // that denotes another binding (`readsOtherBinding()`) is not a self-call,
  // and boxing the literal again in this scope would make it one.
  const ctorScope = ce.context.lexicalScope;
  const ctorType = ce._typeRegistry[id];
  let ctorLiteral: Expression | undefined = undefined;
  try {
    if (arg2 !== null && typeof arg2 === 'object') {
      const boxedFn = isFunction(arg2 as Expression, 'Function')
        ? (arg2 as Expression)
        : undefined;
      const rawFn =
        boxedFn === undefined && Array.isArray(arg2) && arg2[0] === 'Function';
      if (
        boxedFn
          ? mentionsName(boxedFn, id) && !readsOtherBinding(ce, boxedFn, id)
          : rawFn && JSON.stringify(arg2).includes(`"${id}"`)
      ) {
        if (!ce.lookupDefinition(id)) ce.symbol(id);
        const selfDef = ce.lookupDefinition(id);
        if (selfDef && isValueDef(selfDef) && selfDef.value.inferredType)
          selfDef.value._setType(() => ce.type('function'));
        // Serialize WITH `sourceOffsets` (`.json` drops them): this re-box
        // otherwise erased every recursive function body's source positions,
        // which is what the debugger's body breakpoints map statements back
        // through. NOT `toMathJson()` — that is the display serializer, and
        // its function shorthand collapses the literal (dropping the
        // parameter list).
        //
        // Only a canonical literal is boxed again. A literal that is not
        // canonical yet (the literal that `kindTypedFunctionLiteral()`
        // annotated above, or one boxed with `form: 'raw'`) is canonicalized
        // later, when the self-reference is already declared. A re-box from
        // the MathJSON would also drop the annotations that are marked as
        // inferred, and so fold `x/x` to `1` in a recursive literal over a
        // value kind.
        //
        // A valid literal is copied as a raw expression that keeps shared
        // nodes shared (`rawCopyWithSourceOffsets()`), and the copy is
        // canonicalized. Its MathJSON would be a tree, with one copy of a
        // shared node for each path: `Max(t, t)` nested 18 deep took about
        // 20 s to box again. An invalid literal is boxed again from its MathJSON
        // (see `rawCopyWithSourceOffsets()` for the reason).
        if (boxedFn?.isCanonical)
          arg2 = (
            boxedFn.isValid
              ? ce.box(rawCopyWithSourceOffsets(ce, boxedFn))
              : ce.box(jsonWithSourceOffsets(boxedFn))
          ) as AssignValue;
      }
    }

    // §4.5b D13 (nominal-types design) — constructor-function recognition. A
    // function literal assigned to a name that the engine's type registry
    // declares as a NOMINAL type is that type's constructor
    // function: recognized here, at install time, so the Epsil `function`
    // statement and the box/host routes agree by construction. Ordering falls
    // out of execution order — at Assign time the type either is already
    // declared (→ constructor) or is not (→ plain function; a LATER
    // same-scope type declaration then hits the D5 collision against a real
    // definition). An ALIAS type's same-name function is an ordinary function
    // (§4.5): it installs no constructor, but it IS licensed to replace the
    // alias's minted identity constructor (the guard carve-out below).
    if (
      ctorType?.def !== undefined &&
      arg2 !== undefined &&
      arg2 !== null &&
      typeof arg2 !== 'function' &&
      typeof arg2 !== 'boolean'
    ) {
      // Only an EXPLICIT `Function` literal is a constructor declaration —
      // `canonicalFunctionLiteral` would wrap any expression as a thunk, and
      // `point := 5` must keep hitting the constructor-assignment guard.
      const expr2 = ce.expr(arg2);
      if (isFunction(expr2, 'Function'))
        ctorLiteral = canonicalFunctionLiteral(expr2);
    }
  } finally {
    // Canonicalization is done: put the strict definition back. A nominal
    // install below replaces it wholesale; every other path (alias plain
    // function, non-literal value, error) proceeds against the real
    // definition.
    restoreCtor?.();
  }

  const def = ce.lookupDefinition(id);

  if (ctorLiteral !== undefined && ctorType !== undefined && !ctorType.alias) {
    // Same eligibility as the type declaration's own namespace claim (D5): an
    // explicit non-constructor binding in this scope is a genuine conflict.
    checkTypeConstructorNamespace(ctorScope, id, 'constructor-function');
    installConstructorFunction(ce, ctorScope, id, ctorType, ctorLiteral);
    return ce;
  }

  // Phase 3 §6.3 — declared-signature reconciliation (assign path).
  // Assigning a function literal to a symbol that carries an EXPLICIT declared
  // function signature (a non-inferred, function-typed value definition): the
  // declaration is authoritative. Ascribe its return type onto the literal (if
  // the literal lacks its own) and keep the value under the declared signature,
  // rather than dropping the signature by converting to an inferred operator
  // definition. Genuine parameter/return conflicts are still rejected.
  if (
    isValueDef(def) &&
    !def.value.isConstant &&
    !def.value.inferredType &&
    arg2 !== undefined &&
    arg2 !== null &&
    typeof arg2 !== 'function' &&
    hasFunctionSignature(def.value.type.type)
  ) {
    const literal = canonicalFunctionLiteral(ce.expr(arg2));
    if (literal !== undefined) {
      // A declared `unknown` slot is a placeholder the definition refines,
      // never a contract (ruled 2026-08-15; `refineDeclaredPlaceholders`).
      // Refined BEFORE the reconciliation pipeline so ascription, the
      // compatibility check, and call-site broadcasting all see the concrete
      // signature; persisted onto the definition after the checks pass.
      // TWO passes are required: the literal's own type is read before
      // parameter ascription, so a pass-through body (`P ↦ P` under
      // `(tuple<…>) -> unknown`) still shows an `unknown` result here — only
      // the post-ascription `reconciled` carries the sharpened result, so a
      // second pass runs below once `reconciled` exists.
      // A signature skeleton (`_signatureSkeleton`) is the contract that the
      // new literal refines. The type the definition reports is the
      // skeleton refined from the PREVIOUS value, so refining from it would
      // find no placeholder left, and a re-assignment could not re-refine.
      const skeleton = def.value._signatureSkeleton;
      const declaredType0 =
        skeleton !== undefined ? ce.type(skeleton) : def.value.type;
      // The result the body has with the DECLARED parameter types, when the
      // declared result is a placeholder: the stored literal reads its
      // scalar parameters as `unknown` (see `ascribeDeclaredParameterTypes`),
      // so its own result is wider than the declaration allows. Both
      // refinement passes read it, or the first would fix the wider result.
      const typedResult = resultUnderDeclaredParameters(
        ce,
        literal,
        declaredType0.type
      );
      const withTypedResult = (t: BoxedType): BoxedType =>
        typedResult === undefined
          ? t
          : ce.type(withSignatureResult(t.type, typedResult));
      let declaredType = refineDeclaredType(
        ce,
        declaredType0,
        withTypedResult(literal.type)
      );

      // A generic declaration DOES take a function-literal body (the
      // generic-literals milestone, §2.4): the literal installs under the
      // declared polytype and every call instantiates it. Two things still run
      // first. `canonicalFunctionLiteral` LIFTS non-literals (a function-typed
      // SYMBOL comes back as a literal), so discriminate on the ORIGINAL
      // operand: a symbol has no body to erase — it gets the honest D3
      // rejection (`Ground <: Poly` is false). And G11 rejects a generic
      // OVERLOAD SET, ahead of the arity/effects assertions below.
      if (declaredType.isPolymorphic) {
        const orig = ce.expr(arg2);
        if (isSymbol(orig)) throw declaredTypeError(id, orig, declaredType);
        assertSingleArmPolytype(id, literal, declaredType);
      }

      // The literal must be arity-compatible with the declared signature (see
      // `assertFunctionLiteralArity`); otherwise function subtyping would treat
      // an over-arity literal as assignable to a lower-arity signature, or an
      // optional/variadic declaration would let a legal call silently
      // partial-apply on the fixed-arity body.
      assertFunctionLiteralArity(
        id,
        literal,
        declaredType.type,
        declaredType.toString()
      );

      // The return is reconciled against the DECLARED result, not the one
      // refined from the typed result above: that result is CE's derivation,
      // not the host's contract, and ascribing it wrote a `Typed` marker into
      // the stored literal (`x ↦ a` with `a: integer` stored
      // `Typed(a, 'integer')`), which froze the result: a later retype of `a`
      // could not change the signature. The declared result is `unknown`
      // whenever there is a typed result, and `unknown` ascribes nothing.
      const reconciled = reconcileFunctionLiteralReturn(
        ce,
        ascribeDeclaredParameterTypes(
          ce,
          literal,
          // A placeholder slot's refined type is inferred from this very
          // literal; stamping it would make it an annotation, which the
          // application enforces at run time (`placeholderSlotsAs`).
          placeholderSlotsAs(declaredType.type, declaredType0.type, 'unknown')
        ),
        typedResult === undefined
          ? declaredType.type
          : withSignatureResult(declaredType.type, 'unknown'),
        id
      );
      const reconciledType = withTypedResult(reconciled.type);
      // Second refinement pass (see the comment above): adopt the
      // post-ascription result for any slot still `unknown`.
      declaredType = refineDeclaredType(ce, declaredType, reconciledType);
      // The effects axis is judged by its own provenance: a bare specifier is
      // the INFERRED track (the body's effects are simply re-stamped on every
      // assignment), a stated one is a contract.
      const effectsDeclared = def.value.effectsDeclared;
      assertDeclaredEffects(
        id,
        reconciled,
        declaredType.type,
        effectsDeclared,
        latestDeclaredEffectsSite(def.value),
        options?.bindsLocal ? undefined : { ce }
      );
      if (
        !matchesDeclaredTypeAxes(
          ce,
          reconciledType,
          declaredType,
          effectsDeclared,
          reconciled,
          id
        )
      )
        throw declaredTypeError(id, reconciled, declaredType);
      // With a skeleton the refined signature is derived from the stored
      // value on each read, so nothing is written: writing it would clear
      // the skeleton.
      if (declaredType !== declaredType0 && skeleton === undefined)
        def.value._setType(() => declaredType);
      ce._setSymbolValue(id, reconciled);
      return ce;
    }
  }

  if (isOperatorDef(def)) {
    // A builtin operator — owned by the system scope — is never mutated in
    // place: it is shared engine-wide (e.g. `N` is injected into every
    // lazy-broadcast marker), so overwriting it would destroy the builtin
    // for every consumer. Instead the assignment SHADOWS: declare in the
    // current scope, exactly as if there were no prior definition. A bare
    // symbol then resolves to the assigned value while `lookupApplicable`
    // still reaches the builtin in operator position. In-place conversion
    // is preserved for user-defined operators (non-system scopes) and
    // during library bootstrap (current scope IS the system scope).
    const systemScope = ce.contextStack[0]?.lexicalScope;
    const shadowBuiltin =
      systemScope !== undefined &&
      systemScope.bindings.get(id) === def &&
      ce.context.lexicalScope !== systemScope;

    // A minted type constructor is one half of a type declaration's claim on
    // BOTH namespaces (nominal-types design, D5). Every branch below replaces
    // the inner operator definition wholesale — which drops the minted marker
    // — so an in-place assignment would leave the type still resolving with
    // nothing able to build a value of it. Refuse it, in the shape of the
    // constant-reassignment error: it throws, on the host route
    // (`ce.assign`) and on the `Assign` operator route alike (user decision
    // 2026-10-18: `ce.parse('\\pi := 3').evaluate()` throws to the host). The
    // Epsil interpreter catches the throw and reports it as an `Error` value.
    // A SHADOWING assignment is fine: it binds a new name in the current
    // scope and leaves the declaration's own scope untouched.
    // Carve-outs (§4.5b D13): a NOMINAL constructor-function install returned
    // above before reaching here; an ALIAS type's same-name function literal
    // is an ordinary function that deliberately replaces the minted identity
    // constructor (the marker drops with the inner def — the binding stops
    // being ours, per §4.5).
    const aliasFunctionOverride =
      ctorLiteral !== undefined && ctorType?.alias === true;
    if (!shadowBuiltin && isMintedConstructor(def) && !aliasFunctionOverride)
      throw constructorAssignmentError(id, def.operator.signature);

    const value = assignValueAsValue(ce, arg2);
    if (value !== undefined) {
      if (shadowBuiltin) {
        ce._declareSymbolValue(id, { value });
        return ce;
      }
      // Allow converting an operator to a value.
      // Existing expressions using this symbol as a function head (e.g.
      // ["g", 2]) will produce a type error at evaluation time if the
      // new value is not callable — which is the correct semantic.
      // State event: callability LEAVES the binding (§2b). Zero-mask
      // `type-write` in the parity regime (this caller bumps nothing
      // directly; the G+M arrive via the `_setSymbolValue` value-write).
      const callableBefore = defIsCallableShaped(def);
      updateDef(ce, id, def, { value });
      ce._noteStateEvent({
        kind: 'type-write',
        callableBefore,
        callableAfter: defIsCallableShaped(def),
      });
      ce._setSymbolValue(id, value);
      return ce;
    }

    // Phase 3 §6.3 — declared-signature reconciliation (operator-slot). A
    // symbol declared with an EXPLICIT function signature and no built-in
    // evaluate handler — the object form `ce.declare(f, { signature: … })`, or
    // a symbol already carrying a reconciled user lambda — is authoritative
    // over its signature. Assigning a function literal to it must PRESERVE the
    // declared signature, exactly as the value-slot case above, instead of
    // replacing it with one inferred from the literal (which is what
    // `assignValueAsOperatorDef` + `updateDef` would otherwise do). This makes
    // the two documented declare spellings — string `"(…) -> …"` (value slot)
    // and object `{ signature: "(…) -> …" }` (operator slot) — equivalent under
    // declare-then-assign. Built-in / native operators (a defined `evaluate`
    // handler that is not a user lambda) and inferred-signature operators
    // (auto-declared from usage) keep today's replace behavior.
    if (
      !def.operator.inferredSignature &&
      (def.operator.evaluate === undefined ||
        def.operator.lambda !== undefined) &&
      arg2 !== undefined &&
      arg2 !== null &&
      typeof arg2 !== 'function' &&
      hasFunctionSignature(def.operator.signature.type)
    ) {
      const literal = canonicalFunctionLiteral(ce.expr(arg2));
      // R4 — an UNTYPED literal assigned over a DERIVED signature full-replaces
      // it (D6, "Assign always full-replaces"). A signature derived from the
      // PREVIOUS assign's annotation is a record of that literal, not a contract
      // on the name: re-assigning a bare `x ↦ 2x` must re-infer from the new
      // body, not check it against — and keep — annotations the author has
      // deleted. The boundary is provenance, not shape: a signature that came
      // from `ce.declare()` is a DECLARATION and stays sticky. And an ANNOTATED
      // re-assign still reconciles below whatever the provenance, so
      // annotated → same-annotated rebuilds identically and
      // annotated → differently-annotated still errors.
      const replacesDerived =
        def.operator._derivedSignature &&
        literal !== undefined &&
        !functionLiteralHasAnnotation(literal);
      if (literal !== undefined && !replacesDerived) {
        // Placeholder refinement, as on the value-slot route above: declared
        // `unknown` slots adopt the literal's inferred slots before the
        // pipeline, so the installed signature and the `paramsAreScalar`
        // broadcast flag below are computed from the concrete type. Two
        // passes, for the same reason as there: only the post-ascription
        // `reconciled` carries a pass-through body's sharpened result.
        // A lambda installed earlier under a declaration with `unknown`
        // slots reports a signature derived from that lambda
        // (`_signatureSkeleton`). The new literal refines the skeleton, not
        // that derived signature, which has no placeholder left.
        // A DERIVED signature types each slot that the previous literal left
        // bare from the uses of the parameter. That type is not a contract:
        // when the new literal annotates the parameter, the annotation
        // replaces it (`bareSlotsAsPlaceholders`).
        const opSkeleton = def.operator._signatureSkeleton;
        const priorType0 =
          opSkeleton !== undefined
            ? ce.type(opSkeleton)
            : def.operator._derivedSignature
              ? ce.type(
                  bareSlotsAsPlaceholders(
                    def.operator.signature.type,
                    def.operator._validationSignature,
                    literal
                  )
                )
              : def.operator.signature;
        // A caller that replaces the whole definition gives the effect
        // contract of the incoming literal (`options.effectContract`). The
        // effect specifier of the previous signature is then replaced by the
        // incoming one, or removed when the literal states no effects, so the
        // checks below and the installed signature use the incoming contract.
        // The previous definition object is not changed. Only a DERIVED
        // signature (a record of the previous literal) gives way: a signature
        // declared on the name is a contract, and the incoming literal is
        // checked against its effects as before.
        const contract = def.operator._derivedSignature
          ? options?.effectContract
          : undefined;
        const declaredType0 =
          contract === undefined
            ? priorType0
            : ce.type(
                contract.declared && contract.effects !== undefined
                  ? withArrowEffects(
                      stripArrowEffects(priorType0.type),
                      contract.effects
                    )
                  : stripArrowEffects(priorType0.type)
              );
        // The body's result under the declared parameter types, as on the
        // value-slot route above.
        const typedResult = resultUnderDeclaredParameters(
          ce,
          literal,
          declaredType0.type
        );
        const withTypedResult = (t: BoxedType): BoxedType =>
          typedResult === undefined
            ? t
            : ce.type(withSignatureResult(t.type, typedResult));
        let declaredType = refineDeclaredType(
          ce,
          declaredType0,
          withTypedResult(literal.type)
        );

        // G11 — see the value-slot route above. The literal then installs as a
        // VALUE carrying the DECLARED polytype (the same representation this
        // route already produces for a ground declared signature), so calls
        // dispatch through the polytype-aware `validateArguments` / result
        // instantiation exactly as a built-in generic operator's do.
        if (declaredType.isPolymorphic)
          assertSingleArmPolytype(id, literal, declaredType);

        // The literal must be arity-compatible with the declared signature
        // (mirrors the value-slot path); otherwise a declared-arity call would
        // silently partial-apply on the fixed-arity body.
        assertFunctionLiteralArity(
          id,
          literal,
          declaredType.type,
          declaredType.toString()
        );

        // A DERIVED signature is a record of the literal assigned before, so
        // its result is what that literal returned (inferred from its body,
        // or its own return ascription), not a contract on the name. When the
        // new literal states no return type, its inferred result replaces the
        // recorded one, as an untyped re-assign replaces the whole signature.
        // Ascribing the old result instead kept a result type the new body
        // cannot meet: after `h := (a: integer) ↦ 1`, the re-assign
        // `h := (a: integer) ↦ "s"` stored `Typed("s", 'integer')`, so `h(0)`
        // was typed `integer`, and the `Typed` evaluate handler refuses the
        // value `"s"` there. A new literal that states a return type is still
        // checked against the recorded result (a different stated type is an
        // error), and a signature declared on the name keeps its result as a
        // contract.
        const resultIsRecord =
          def.operator._derivedSignature &&
          functionLiteralReturnType(literal) === undefined &&
          functionLiteralDeclaredSignature(literal) === undefined &&
          !declaredType.isPolymorphic &&
          typeof declaredType.type === 'object' &&
          declaredType.type.kind === 'signature';
        // As on the value-slot route: reconciled against the DECLARED result.
        const reconciled = reconcileFunctionLiteralReturn(
          ce,
          ascribeDeclaredParameterTypes(
            ce,
            literal,
            // A placeholder slot's refined type is inferred from this very
            // literal; stamping it would make it an annotation, which the
            // application enforces at run time (`placeholderSlotsAs`).
            //
            // The same holds for a DERIVED signature, which is a record of
            // the literal assigned before: the type of a parameter that
            // literal left bare was inferred from its body. An Epsil
            // `function` is assigned twice, when its definition is
            // canonicalized and when it is evaluated, so the second
            // assignment stamped `p: indexed_collection<number>` on the bare
            // `p` of `function f(p, n: number) { p[1] + n }`, and the
            // application then refused an absent `p` that the body accepts.
            // A bare parameter of the new literal is not stamped
            // (`validationSignatureOf` types its slot `any`, which the
            // ascription skips).
            def.operator._derivedSignature
              ? (validationSignatureOf(literal, declaredType.type) ??
                  declaredType.type)
              : placeholderSlotsAs(
                  declaredType.type,
                  declaredType0.type,
                  'unknown'
                )
          ),
          typedResult === undefined && !resultIsRecord
            ? declaredType.type
            : withSignatureResult(declaredType.type, 'unknown'),
          id
        );
        // Second refinement pass — adopt the post-ascription result.
        const reconciledType = withTypedResult(reconciled.type);
        declaredType = refineDeclaredType(ce, declaredType, reconciledType);
        // The new literal's own result replaces a result that is only a
        // record of the previous literal (see `resultIsRecord`).
        if (resultIsRecord) {
          const result = functionResult(reconciledType.type);
          if (result !== undefined)
            declaredType = ce.type(
              withSignatureResult(declaredType.type, result)
            );
        }
        // The effects axis is judged by its own provenance. The operator
        // definition carries the bit (`effectsDeclared`), and it has to travel
        // with the value definition this route installs: the declared type
        // alone cannot record an author-written `pure`.
        // With an incoming contract, the site where the previous contract was
        // stated is not where the contract in force is stated, so it is not
        // named.
        const effectsDeclared =
          contract?.declared ?? def.operator.effectsDeclared;
        assertDeclaredEffects(
          id,
          reconciled,
          declaredType.type,
          effectsDeclared,
          contract === undefined
            ? latestDeclaredEffectsSite(def.operator)
            : undefined,
          { ce }
        );
        if (
          !matchesDeclaredTypeAxes(
            ce,
            reconciledType,
            declaredType,
            effectsDeclared,
            reconciled,
            id
          )
        )
          throw declaredTypeError(id, reconciled, declaredType);

        // The parameter names of a DERIVED signature are a record of the
        // previous literal too, and the latest literal owns them. The new
        // literal is applied to the operands in its own parameter order, so
        // a named call must match the names of the new literal. Example:
        // after `h := (x: real, factor: real) ↦ x - factor`, the re-assign
        // `h := (factor: real, x: real) ↦ x - factor` gives
        // `h(factor: 5, x: 3) = -2`. With the old names, the call puts `3` in
        // the first slot, `factor`, and gives `2`. A signature declared on
        // the name is a contract, and keeps its names.
        if (def.operator._derivedSignature)
          declaredType = ce.type(
            withParameterNamesOf(declaredType.type, reconciled.type.type)
          );

        // A definition that ALREADY carries a user lambda keeps its OPERATOR
        // representation: re-running `ce.assign('f', ⟨annotated literal⟩)` on
        // the same symbol must land where the first run did (notebook re-run
        // semantics — assign twice ≡ assign once). Migrating it to a VALUE def
        // instead dropped the operator half wholesale, and with it the derived
        // `broadcastable` flag and every `_isLambda`/`_lambdaLiteral` consumer,
        // so the second run of a cell broadcast differently from the first.
        // The DECLARED signature stays authoritative and travels onto the
        // rebuilt def — so this changes the representation only: the
        // compatibility checks above already rejected a literal that does not
        // fit. (The `evaluate === undefined` half of the guard above — a
        // declared-but-unimplemented signature — keeps installing a VALUE:
        // that is what makes the object-form `ce.declare(f, { signature })`
        // spelling observably identical to the string form.)
        // The EFFECTS specifier travels only when its provenance is
        // AUTHOR-STATED: the constructor reads ANY effect-bearing supplied
        // signature as a declared contract, so carrying an INFERRED specifier
        // over would promote it to one — a first bare assign of an effectful
        // body would silently become a contract on the second, and later valid
        // re-assigns would be checked against the previously-inferred set.
        // Strip it instead and let the body walk restamp the inference.
        if (def.operator.lambda !== undefined) {
          const lambdaDef: OperatorDefinition = {
            evaluate: reconciled,
            signature: effectsDeclared
              ? declaredType.type
              : stripArrowEffects(declaredType.type),
            broadcastable: paramsAreScalar(declaredType.type),
            // R4 — the signature's PROVENANCE travels with it: rebuilding the
            // def must not launder an assign-derived signature into a
            // declaration (nor a declaration into a derived one).
            _derivedSignature: def.operator._derivedSignature,
            // A DERIVED signature keeps enforcing only the slots the literal
            // annotates (`validationSignatureOf`), read off the literal as
            // written, before the declared types were ascribed onto its bare
            // parameters: assigning the same partly annotated literal twice
            // must validate calls as the first assignment did. A signature
            // DECLARED on the name is the author's contract on every slot.
            // Declared with placeholder slots (`(unknown) -> unknown`): the
            // refined type of a placeholder slot is inferred from the body
            // and must not refuse an argument either
            // (`placeholderSlotsAs`).
            _validationSignature: def.operator._derivedSignature
              ? validationSignatureOf(literal, declaredType.type)
              : hasSignaturePlaceholder(declaredType0.type)
                ? placeholderSlotsAs(
                    declaredType.type,
                    declaredType0.type,
                    'any'
                  )
                : undefined,
          };
          if (shadowBuiltin) ce._declareSymbolOperator(id, lambdaDef);
          else {
            const callableBefore = defIsCallableShaped(def);
            updateDef(ce, id, def, lambdaDef);
            ce._noteStateEvent({
              kind: 'redefine',
              callableBefore,
              callableAfter: true,
            });
          }
          // Keep the declaration's placeholders, so that the reported
          // signature follows the lambda (`_signatureSkeleton`). Set after
          // the install, because an explicit signature write clears it.
          if (hasSignaturePlaceholder(declaredType0.type)) {
            const installed = ce.lookupDefinition(id);
            if (installed !== undefined && isOperatorDef(installed))
              installed.operator._signatureSkeleton = declaredType0.type;
          }
          return ce;
        }

        // Store the reconciled literal as a VALUE under the declared signature
        // — the SAME representation the string-form (value-slot) declaration
        // produces. This makes the two spellings observably identical: `f(3)`
        // type-errors against the declared param. A declaration with
        // `unknown` slots installs as written, and becomes the value
        // definition's signature skeleton, as on the declare route.
        const installedType = hasSignaturePlaceholder(declaredType0.type)
          ? declaredType0.type
          : declaredType.type;
        if (shadowBuiltin) {
          ce._declareSymbolValue(id, {
            value: reconciled,
            type: installedType,
            effectsDeclared,
          });
          return ce;
        }
        {
          // State event: a value-slot reconciliation swap — zero-mask
          // `type-write` (the G+M arrive via the value-write below; the
          // updateDef-internal G via `binding-repair`).
          const callableBefore = defIsCallableShaped(def);
          updateDef(ce, id, def, {
            value: reconciled,
            type: installedType,
            effectsDeclared,
          });
          ce._noteStateEvent({
            kind: 'type-write',
            callableBefore,
            callableAfter: defIsCallableShaped(def),
          });
        }
        ce._setSymbolValue(id, reconciled);
        return ce;
      }
    }

    // Update the operator definition.
    const fnDef = assignValueAsOperatorDef(ce, arg2);
    if (!fnDef) throw Error(`Invalid definition for symbol "${id}"`);
    if (shadowBuiltin) {
      ce._declareSymbolOperator(id, fnDef);
      return ce;
    }
    {
      // Redefining an existing operator is a semantic mutation AND a
      // global-semantics event (no value-setter write happens on this path,
      // so the `redefine` event is the sole advance: semantic + world axes).
      const callableBefore = defIsCallableShaped(def);
      updateDef(ce, id, def, fnDef);
      ce._noteStateEvent({
        kind: 'redefine',
        callableBefore,
        callableAfter: true,
      });
    }
    return ce;
  }

  //
  // 1/ We were given a value
  //
  const value = assignValueAsValue(ce, arg2);
  if (value !== undefined) {
    if (!def) {
      // No previous definition: create a new one
      ce._declareSymbolValue(id, { value });
      return ce;
    }
    // The two rejections this install makes on sight of the existing
    // definition and the new value — a constant target, a value that does not
    // fit a DECLARED type — live in `assertAssignableValueDef` so the `Assign`
    // operator's destructuring route can ask the same question WITHOUT writing
    // (see `assertAssignable`).
    const verdict = assertAssignableValueDef(ce, id, def.value, value);

    // Everything from here to the value write is the DERIVE-AND-WRITE phase,
    // and it runs with the assumptions hidden. The validation above needed
    // them (a fact in force is a constraint the value must satisfy); the type
    // this phase settles on is a contract that has to stay true after
    // `forget()`, so neither the incumbent reads, the `isSubtype` branches,
    // the promotion, nor the placeholder refinement below may see a fact
    // (`docs/plans/2026-08-29-assumptions-as-facts-type.md` §2.4; the
    // closed-over variables are listed in
    // `docs/plans/2026-08-30-assumptions-write-audit.md`).
    const valueDef = def.value;
    ce._withoutFacts(() => deriveAndWriteAssignedType(ce, valueDef, value));

    // ... and set the value. A value admitted on overlap only is recorded,
    // so that each read of the symbol tests its evaluated value against the
    // declared type (`BoxedSymbol._testedRead()`).
    if (verdict === 'overlap') noteOverlapAdmitted(value);
    ce._setSymbolValue(id, value);

    return ce;
  }

  //
  // 2/ We were given an operator definition
  //
  // A definition whose value an activation holds (a local of a block, a
  // parameter, the variable of a binder) keeps its identity: the function is
  // its value in the activation of the evaluation in progress.
  if (
    def !== undefined &&
    isValueDef(def) &&
    !def.value.isConstant &&
    activationRecordOf(def.value, ce.context.lexicalScope) !== undefined
  ) {
    const literal = canonicalFunctionLiteral(ce.expr(arg2 as Expression));
    if (literal !== undefined) {
      ce._setSymbolValue(id, literal);
      return ce;
    }
  }
  const fnDef = assignValueAsOperatorDef(ce, arg2);
  if (fnDef === undefined) throw Error(`Invalid definition for symbol "${id}"`);
  if (options?.bindsLocal) markLocalBinding(fnDef);

  if (def) {
    // If we get here, the previous definition was a value definition.
    // We can update it to an operator definition.
    console.assert(isValueDef(def));
    // The refusal the value route makes on sight of a constant target
    // (`assertAssignableValueDef`), repeated here because a function literal
    // takes THIS route: without it the constant's definition was converted in
    // place — `const k = (n) => n + 1` then `k = (s) => s` replaced `k`
    // silently, and `ce.assign('Pi', (x) => 2x)` turned the engine's own
    // system-scope `Pi` into that operator. Same message on both routes, so
    // the `Assign` operator throws the same error for either shape (a value or
    // a function literal), and Epsil reports the same `Error` value.
    if (isValueDef(def) && def.value.isConstant)
      throw new ConstantAssignmentError(id);
    // updateDef removes def.value and sets def.operator — no separate
    // _setSymbolValue call needed to clear the old value.
    const callableBefore = defIsCallableShaped(def);
    updateDef(ce, id, def, fnDef);
    ce._noteStateEvent({
      kind: 'redefine',
      callableBefore,
      callableAfter: true,
    });
  } else {
    // No previous definition: create a new one
    ce.declare(id, fnDef);
  }

  return ce;
}

/**
 * Run `fn` with each name of `values` bound to the given value, and put back
 * the earlier state of each binding when `fn` returns or throws. The
 * implementation of `ce.withValues()`.
 *
 * The value is written with `ce.assign()` into the binding that is visible
 * when the function is called. Before the write, the function copies all the
 * fields of the value definition of the binding (`_fieldSnapshot()`),
 * and after `fn` it writes the copy back (`_restoreFieldSnapshot()`). So
 * every read of the name while `fn` runs gets the value: an expression boxed
 * before the call, an expression boxed inside `fn`, and also the body of a
 * function or a held value stored in another binding. Example: with
 * `f := x ↦ x + a`, `f(2)` gives `3` inside `withValues({ a: 1 }, …)`. A
 * declaration of `a` in a new scope does not reach that body, because a call
 * resolves the names of a body in the scope where the function was defined,
 * not in the scope of the caller (`bindingInContext()`,
 * `boxed-expression/binders.ts`).
 *
 * The definition objects are kept, because a boxed symbol holds its
 * definition by identity. When `fn` assigns a function to the name, the
 * binding record gets an operator definition in place of the value
 * definition (`updateDef()`), and a later assignment of a value gives it a
 * new value definition. The restore then writes the copy into the saved
 * value definition and puts that definition back on the record.
 *
 * The assignment advances the cache versions, so a cache filled before the
 * call (the unknown sign of `a + 1` with `a` valueless) is not used inside
 * `fn`. The restore advances them again, as a value write does, so a cache
 * filled inside `fn` (the positive sign of `a + 1` with `a = 3`) is not used
 * after the call. A restore that adds or removes a function arm of the type
 * also reports a type write, as `ce.assign()` does.
 *
 * The copies are made first, before a value is boxed: boxing a value such as
 * `a + 1` can narrow the inferred type of `a`, and the restore puts back the
 * type from before. Then every name and every value is checked before any
 * binding is written:
 *
 * - A name with no binding is boxed first (`ce.symbol()`), which declares it
 *   in the current scope as any use of the name does. The declaration stays
 *   after the call, with no value, as if `fn` had used the name with no
 *   value.
 * - A name bound to an operator definition, a constant, a value that is a
 *   function (a function literal or a JavaScript function), and a value that
 *   `ce.assign()` refuses for the name (`assertAssignableValueDef()`: a value
 *   outside the declared type, a value that an assumption refutes) throw.
 *   Assigning a function would replace the value definition by an operator
 *   definition (`assignFn()`), which is not a temporary value.
 * - A value that holds an object of another engine throws, as in
 *   `ce.assign()`. The test runs before the value is boxed, because boxing
 *   replaces such an object by an error expression.
 * - A name that the body of a stored function applies while the name has no
 *   definition of a function (`a` in `f(t) := a(t+1)`, with `a` not
 *   declared) throws. A value of a type that is not a function rewrites that
 *   body, which then reads `a·(t+1)` (`repairProvisionalDependents()`,
 *   called by `_setSymbolValue()`), and the restore of the name does not
 *   undo that rewrite. Declare the name first (`ce.declare('a', 'real')`).
 *   A stored function that nothing reaches any more (its scope was popped
 *   and discarded) cannot be rewritten: it stops counting once the garbage
 *   collector has freed it, so the call throws or not by the time of the
 *   last collection (`provisional-application.ts`).
 * - The value `undefined` gives the name no stored value while `fn` runs. A
 *   value that an assumption gives (`ce.assume(a = 3)`) still applies.
 *
 * Not undone: the effects of `ce.assign()` outside the definitions of the
 * names. A value that is a symbol with no value and no type takes the
 * declared type of the name (`assignFn()`), and keeps it after the call. A
 * value definition that `fn` disposes (`ce.undeclare()`) is not restored.
 *
 * A failure of the restore of one binding does not stop the restore of the
 * others. The first failure is thrown after all of them. When `fn` (or the
 * write of a value) threw too, an `AggregateError` is thrown instead: its
 * `errors` are the error of `fn` and the first restore failure, in this
 * order, and its `cause` is the error of `fn`.
 *
 * `fn` must be synchronous: the bindings are restored when `fn` returns,
 * before a promise that it returns settles.
 */
export function withValuesFn<T>(
  ce: IComputeEngine,
  values: { readonly [id: string]: AssignValue },
  fn: () => T
): T {
  const names = Object.keys(values);
  if (names.length === 0) return fn();

  const saved: WithValuesBinding[] = [];
  for (const name of names) {
    const appliedByBody = () =>
      new Error(
        `withValues(): the body of a function applies "${name}" as a function, and a value would change that body for good. Declare "${name}" first`
      );
    let record = ce.lookupDefinition(name);
    if (record === undefined) {
      // Boxing declares no name (a free name), so the name is declared
      // here, in the first scope up the chain that is not `noAutoDeclare`.
      // The test of the bodies that apply the name comes first: the
      // declaration could rewrite such a body.
      if (hasProvisionalDependents(ce, name)) throw appliedByBody();
      let scope = ce.context.lexicalScope;
      while (scope.noAutoDeclare && scope.parent) scope = scope.parent;
      ce._declareSymbolValue(name, { type: 'unknown', inferred: true }, scope);
      record = ce.lookupDefinition(name);
    }
    if (record === undefined || !isValueDef(record))
      throw new Error(
        `withValues(): "${name}" is bound to a function definition. withValues() gives a value to a variable only`
      );
    if (record.value.isConstant) throw new ConstantAssignmentError(name);
    if (isMacroDef(record)) throw macroWriteError('withValues', name);
    if (hasProvisionalDependents(ce, name)) throw appliedByBody();
    const input = values[name];
    if (
      input !== undefined &&
      adoptsForeignEngineObject([input as Expression], ce)
    )
      throw new Error(
        `object-foreign-engine: cannot assign an object that belongs to a different engine to "${name}"`
      );
    saved.push({
      name,
      record,
      def: record.value,
      snapshot: record.value._fieldSnapshot(),
    });
  }
  return runWithBindingValues(
    ce,
    saved,
    values,
    (name, _def, value) => ce.assign(name, value),
    fn
  );
}

/**
 * `withValuesFn()` for the bindings `bindings`, which the caller found: each
 * value of `values` is given to the value definition of the binding record
 * of its name, wherever that record is, and no name is looked up or declared.
 * The interpreter fallback of a compilation gives its inputs to the
 * definitions that the expression is bound to (`buildInterpreterFallback()`,
 * `compilation/compile-references.ts`). The checks and the restore are those
 * of `withValuesFn()`.
 */
export function withBindingValuesFn<T>(
  ce: IComputeEngine,
  bindings: ReadonlyArray<{
    readonly name: string;
    readonly record: BoxedDefinition;
  }>,
  values: { readonly [id: string]: AssignValue },
  fn: () => T
): T {
  if (bindings.length === 0) return fn();
  const saved: WithValuesBinding[] = [];
  for (const { name, record } of bindings) {
    if (!isValueDef(record))
      throw new Error(
        `withValues(): "${name}" is bound to a function definition. withValues() gives a value to a variable only`
      );
    if (record.value.isConstant) throw new ConstantAssignmentError(name);
    if (isMacroDef(record)) throw macroWriteError('withValues', name);
    if (hasProvisionalDependents(ce, name))
      throw new Error(
        `withValues(): the body of a function applies "${name}" as a function, and a value would change that body for good. Declare "${name}" first`
      );
    const input = values[name];
    if (
      input !== undefined &&
      adoptsForeignEngineObject([input as Expression], ce)
    )
      throw new Error(
        `object-foreign-engine: cannot assign an object that belongs to a different engine to "${name}"`
      );
    saved.push({
      name,
      record,
      def: record.value,
      snapshot: record.value._fieldSnapshot(),
    });
  }
  return runWithBindingValues(
    ce,
    saved,
    values,
    (_name, def, value, verdict) => {
      ce._withoutFacts(() => deriveAndWriteAssignedType(ce, def, value));
      if (verdict === 'overlap') noteOverlapAdmitted(value);
      def.value = value;
    },
    fn
  );
}

/**
 * The part of `withValuesFn()` after the copies of the bindings `saved`: box
 * and check every value, write them with `write`, run `fn`, and put back the
 * copies when `fn` returns or throws.
 */
function runWithBindingValues<T>(
  ce: IComputeEngine,
  saved: ReadonlyArray<WithValuesBinding>,
  values: { readonly [id: string]: AssignValue },
  write: (
    name: string,
    def: BoxedValueDefinition,
    value: Expression,
    verdict: ReturnType<typeof assertAssignableValueDef>
  ) => void,
  fn: () => T
): T {
  let threw: { error: unknown } | undefined;
  try {
    const writes: {
      name: string;
      def: BoxedValueDefinition;
      value: Expression | undefined;
      verdict?: ReturnType<typeof assertAssignableValueDef>;
    }[] = [];
    for (const { name, def } of saved) {
      const input = values[name];
      if (input === undefined) {
        writes.push({ name, def, value: undefined });
        continue;
      }
      const value = assignValueAsValue(ce, input);
      if (value === undefined)
        throw new Error(
          `withValues(): the value of "${name}" is a function. withValues() gives a value to a variable only`
        );
      const verdict = assertAssignableValueDef(ce, name, def, value);
      writes.push({ name, def, value, verdict });
    }
    for (const { name, def, value, verdict } of writes) {
      if (value === undefined) def.value = undefined;
      else write(name, def, value, verdict!);
    }
    return fn();
  } catch (error) {
    threw = { error };
    throw error;
  } finally {
    const failure = restoreWithValuesBindings(ce, saved);
    if (failure !== undefined) {
      // eslint-disable-next-line no-unsafe-finally
      if (threw === undefined) throw failure.error;
      // eslint-disable-next-line no-unsafe-finally
      throw new AggregateError(
        [threw.error, failure.error],
        'withValues(): the callback threw, and the earlier value of a symbol could not be put back',
        { cause: threw.error }
      );
    }
  }
}

/** A binding that `withValuesFn()` writes: the binding record, the value
 * definition that the record held at the call, and a copy of all the fields
 * of that value definition. */
type WithValuesBinding = {
  readonly name: string;
  readonly record: BoxedDefinition;
  readonly def: BoxedValueDefinition;
  readonly snapshot: unknown;
};

/** Write back the copies of the value definitions that `withValuesFn()`
 * made, in the reverse order of the copies, and advance the cache versions
 * as `ce.assign()` does. Return the first error that the restore of a
 * binding threw, after the restore of every other binding. */
function restoreWithValuesBindings(
  ce: IComputeEngine,
  saved: ReadonlyArray<WithValuesBinding>
): { error: unknown } | undefined {
  let failure: { error: unknown } | undefined;
  // The same test as the `value` setter of a value definition: a write is
  // `callable` when the value before or after it is, or holds as an operand,
  // a function literal, or when the type has a function arm. A type that
  // cannot be read counts as one with a function arm: the restore then
  // advances more versions than it must, which costs only a computation
  // again.
  const holdsFunctionLiteral = (v: Expression | undefined): boolean => {
    if (v === undefined) return false;
    if (isFunction(v, 'Function')) return true;
    // A store-backed list (`ce.list()`) holds numbers only, and reading its
    // operands would box every element.
    if ((v as { _numericStore?: unknown })._numericStore !== undefined)
      return false;
    return isFunction(v) && v.ops.some((op) => isFunction(op, 'Function'));
  };
  const hasFunctionArm = (def: BoxedValueDefinition): boolean => {
    try {
      return containsSignatureArm(def.type.type);
    } catch {
      return true;
    }
  };
  const declaredTypeOf = (def: BoxedValueDefinition): BoxedType | undefined => {
    try {
      return def.declaredType;
    } catch {
      return undefined;
    }
  };
  for (let i = saved.length - 1; i >= 0; i--) {
    const { name, record, def, snapshot } = saved[i];
    try {
      const installed = (record as { value?: BoxedValueDefinition }).value;
      // `ce.undeclare()` removed the binding.
      if (installed === def && def.disposed) continue;
      const valueBefore = def.storedValue;
      const armBefore = hasFunctionArm(def);
      const typeBefore = declaredTypeOf(def);
      def._restoreFieldSnapshot(snapshot);
      const armAfter = hasFunctionArm(def);
      const typeAfter = declaredTypeOf(def);
      if (installed !== def) {
        // `fn` assigned a function to the name, and maybe a value after it:
        // the record holds an operator definition or another value
        // definition. Put the value definition back, after its copy is
        // written, so that the repair of the bodies that read the name
        // (`updateDef()`) sees the restored type. The value definition needs no new
        // subscription to configuration changes: only a constant has one,
        // and a constant is refused above.
        const callableBefore =
          installed === undefined ? true : hasFunctionArm(installed);
        updateDef(ce, name, record, def);
        ce._noteStateEvent({
          kind: 'redefine',
          callableBefore,
          callableAfter: armAfter,
        });
      }
      // A write of a value moves no type version, so a restore that puts
      // another type back reports it.
      if (
        armBefore !== armAfter ||
        typeBefore === undefined ||
        typeAfter === undefined ||
        typeChanged(typeBefore, typeAfter)
      )
        ce._noteStateEvent({
          kind: 'type-write',
          callableBefore: armBefore,
          callableAfter: armAfter,
        });
      const valueAfter = def.storedValue;
      const callable =
        armBefore ||
        armAfter ||
        holdsFunctionLiteral(valueBefore) ||
        holdsFunctionLiteral(valueAfter);
      ce._noteStateEvent({
        kind: 'value-write',
        ephemeral: false,
        callable,
        typeRead:
          callable ||
          valuePresenceRefinesType(ce, def, valueBefore, valueAfter),
      });
    } catch (error) {
      failure ??= { error };
    }
  }
  return failure;
}

/**
 * The type half of an assignment onto an EXISTING value definition: widen or
 * narrow the inferred type to fit the assigned value, then re-refine a
 * declared placeholder skeleton from the value's element type.
 *
 * Called by {@link assignFn} inside its fact-blind bracket, so every read it
 * makes of the incumbent type is the DECLARED one and nothing an assumption
 * proves reaches the type it installs.
 */
function deriveAndWriteAssignedType(
  ce: IComputeEngine,
  valueDef: BoxedValueDefinition,
  value: Expression
): void {
  // We have a value definition, update the inferred type...
  //
  // A symbol DECLARED `unknown` takes this path too, even though its type
  // is not marked inferred. `unknown` is a placeholder that refines per
  // use, not a contract (`any` is the contract spelling), so the
  // declaration withheld type evidence rather than supplying it, and the
  // assignment is the first evidence there is. Without this,
  // `ce.declare('v', 'unknown')` followed by `ce.assign('v', 5)` left `v`
  // typed `unknown` while the same assignment with no prior declaration
  // settled on `integer` — so a declaration that says nothing was
  // SUPPRESSING inference rather than deferring it, and a later use had to
  // supply the type instead (arriving at the wider `number`, since a use
  // knows less than the value does). The type is marked inferred once it
  // moves, matching the no-declaration route exactly: nothing downstream
  // can then tell the two orders apart.
  const placeholderIncumbent =
    !valueDef.inferredType && valueDef.type.isUnknown;
  if (valueDef.inferredType || placeholderIncumbent) {
    const current = valueDef.type.type;
    const vt = value.type.type;
    // Normally widen the inferred type to cover the assigned value (an
    // `integer` guess refined by a `real` value widens to `real`). But when
    // the guess is genuinely incompatible with the value — widening yields a
    // union, e.g. a symbol heuristically auto-declared `function` by the
    // juxtaposition parser now given a scalar value (`number | function`) —
    // the guess was simply wrong: adopt the value's own type instead (D11),
    // promoted as a fresh declaration would be (below).
    const widened = widen(current, vt);
    const d11 = typeof widened === 'object' && widened.kind === 'union';
    // The same promotion a FRESH `v := 5` declaration applies
    // (`inferTypeFromValue`, boxed-value-definition.ts): a value's narrow
    // literal type promotes to the natural variable type. Shared by the
    // unknown-incumbent branch just below and the narrowing branch further
    // down, and by the D11 adopt: a storage position widens a literal type
    // back to its tier (`docs/TYPE-SYSTEM.md`). The last two arms carry an
    // infinite value and NaN to their own tiers: both are disjoint from `real` and from `complex`, so they reach
    // none of the finite arms, and `v := oo` must stay reassignable to `-oo`
    // without a retype.
    const promotedValueType = () =>
      value.type.matches('integer')
        ? 'integer'
        : value.type.matches('rational') || value.type.matches('real')
          ? 'real'
          : value.type.matches('complex')
            ? 'number'
            : value.type.matches('infinity')
              ? 'infinity'
              : value.type.matches('nan')
                ? 'nan'
                : vt;
    let adopted = d11 ? promotedValueType() : widened;
    // An `unknown` incumbent is an auto-declare that recorded no type
    // evidence (the symbol's uses were all type-vacuous — a bare `List`
    // sibling, a binder-body occurrence). Treat the assignment as the
    // DECLARATION it would have been had it come first: apply the literal
    // promotion, so `y_r := 5` settles on `integer` whether or not a boxing
    // auto-declared `y_r` beforehand. Without this the widen above installs
    // the value's RAW type (`integer`), and the settled type
    // depended on the boxing-vs-assignment order (observed by the Tycho
    // team's order-matrix probe at their 0.106.0 adoption). When D11 fired,
    // `adopted` is already the promoted type.
    if (!d11 && current === 'unknown') adopted = promotedValueType();
    // Assignment NARROWING (user-ruled 2026-08-13; the phase-3 question of
    // docs/TYPE-SYSTEM.md): when the
    // assigned value's type strictly REFINES a use-inferred guess (`x·v`
    // inferred `v: number`, now `v := 5`), adopt the value's promoted type
    // instead of keeping the wider guess — landing exactly where the
    // reverse site order (`v := 5` then `x·v`) already lands, so the
    // inferred type no longer depends on which site the engine saw first.
    // Sound wrt recorded uses: use-narrowing is monotone-down, so any
    // type below the current one satisfies every use that produced it.
    // A DECLARED type is never touched (this whole branch is gated on
    // `inferredType`). Three constraints bound the rewrite:
    //
    // (a) The incumbent must have come from a USE: the latest type-axis
    //     provenance entry is an inference write. An assignment-derived
    //     incumbent stays widen-only — otherwise alternating `v := 2.5`
    //     and `v := 5` would oscillate the type — and a binding whose type
    //     was only ever set by an assignment has no `'inferred'` entry at
    //     all. (This block records `'value-derived'` after it moves a
    //     type, so a second assignment after a narrow no longer narrows.)
    // (b) The D11 union-adopt above must not have fired: it has already
    //     installed the promoted type.
    // (c) The promoted type is installed only when it is itself below the
    //     incumbent; otherwise the value's raw type is (which is always
    //     sound, having just passed the strict-subtype test). Promotion
    //     can widen — `integer` promotes to `integer`, which is NOT
    //     below a `real` incumbent — and installing it would break
    //     a use that the incumbent recorded. The non-finite arms widen the
    //     same way: the `+oo` singleton promotes to `infinity`, which an
    //     incumbent of `integer | +oo` does not contain, so that assignment
    //     installs the singleton instead.
    const prov = valueDef._typeProvenance;
    let incumbentFromUse = false;
    if (prov !== undefined) {
      for (let i = prov.length - 1; i >= 0; i--) {
        if (prov[i].axis !== 'type') continue;
        incumbentFromUse = prov[i].kind === 'inferred';
        break;
      }
    }
    if (
      incumbentFromUse &&
      !d11 &&
      vt !== current &&
      isSubtype(vt, current) &&
      !isSubtype(current, vt) // strict refinement only; equal types no-op
    ) {
      const promoted = promotedValueType();
      adopted = isSubtype(promoted, current) ? promoted : vt;
    }
    const previousType = valueDef.type;
    const declaredBefore = valueDef.declaredType;
    valueDef._setType(() => ce.type(adopted));
    // State event (§2c): a write of a value moves no type version, so a
    // retype reports itself. The D11 adopt branch can also REMOVE a callable
    // arm (a `function` guess replaced by the scalar value's own type). The
    // declared types are compared: the type with the facts merged in can
    // stay the same while the declared type changes.
    if (typeChanged(declaredBefore, valueDef.declaredType))
      ce._noteStateEvent({
        kind: 'type-write',
        callableBefore: containsSignatureArm(current),
        callableAfter: containsSignatureArm(adopted),
      });
    // A placeholder that has now taken a type from its value is in exactly
    // the state the no-declaration route produces, so it must carry the
    // same marker: later uses may refine it, and `assertAssignableValueDef`
    // must keep treating it as a guess rather than a contract to hold the
    // next assignment to.
    if (placeholderIncumbent && !valueDef.type.isUnknown)
      valueDef.inferredType = true;
    // Provenance: an assignment-driven type update (widen, D11 adopt, or
    // the narrowing above) records kind 'value-derived' with the assigned
    // value as cause — activating the kind reserved for exactly this in
    // `TypeProvenanceEntry`. Recorded only when the type actually moved;
    // constructor-time promotion on a FRESH declaration stays unrecorded
    // (engine-construction cost — `inferredType === true` with a value is
    // its marker).
    if (previousType.type !== valueDef.type.type)
      recordTypeProvenance(valueDef, {
        type: valueDef.type,
        kind: 'value-derived',
        axis: 'type',
        cause: value,
      });
  }

  // A declared placeholder skeleton adopts the assigned value's ELEMENT
  // type — element only, re-computed on every assignment, and shown by
  // `typeof` (Phase 1 rulings R1-R3, 2026-08-18;
  // `refineConstructorPlaceholder`). `inferredType` stays false: the
  // refinement is declaration-flavored — argument positions must not
  // narrow it further (use-driven element inference is Phase 3).
  if (valueDef._placeholderSkeleton !== undefined) {
    const refined = refineConstructorPlaceholder(
      valueDef._placeholderSkeleton,
      value.type.type
    );
    if (refined !== valueDef.type.type) {
      const before = valueDef.declaredType;
      valueDef._setElementRefinement(ce.type(refined));
      // As above: the refinement is a retype, and reports itself.
      if (typeChanged(before, valueDef.declaredType)) {
        const arm = containsSignatureArm(valueDef.type.type);
        ce._noteStateEvent({
          kind: 'type-write',
          callableBefore: arm,
          callableAfter: arm,
        });
      }
    }
  }
}

/** True when `after` is not the type `before`: compared as objects, then
 * by their printed forms. */
function typeChanged(before: BoxedType, after: BoxedType): boolean {
  return before.type !== after.type && before.toString() !== after.toString();
}

/**
 * The rejections the value-install branch of {@link assignFn} makes on sight of
 * an existing value definition and the value being written: a `const` target,
 * and a value that does not fit a DECLARED (non-inferred) type.
 *
 * Factored out of that branch — which is its only caller on the write path — so
 * {@link assertAssignable} can ask the same question without writing anything.
 * Both routes therefore raise the identical error: same class, same message,
 * same blamed name.
 *
 * Returns `'overlap'` when the value is accepted only because its type
 * overlaps the declared type (`storeAdmission()` in `effects-inference.ts`),
 * else `'match'`. The write route records an `'overlap'` value at its store
 * (`noteOverlapAdmitted()`), so that each read of the symbol tests it.
 */
function assertAssignableValueDef(
  ce: IComputeEngine,
  id: string,
  def: BoxedValueDefinition,
  value: Expression
): 'match' | 'overlap' {
  if (def.isConstant) throw new ConstantAssignmentError(id);

  // A fact in force is a CONSTRAINT the new value has to satisfy: `assume(v >
  // 3)` refuses `assign(v, 1)`. Read from what the facts prove ON THEIR OWN,
  // because neither of the checks below sees it — an assumption writes no
  // type, and the merged type this symbol reports skips the facts entirely
  // once it holds a value (`assign u 5; assume u > 3; assign u 1`). Checked
  // BEFORE the write, so a refusal leaves the value and the type untouched.
  const proven = provenTypeNode(ce, def);
  if (proven !== undefined) {
    const provenType = ce.type(proven);
    // The constraint is asked of the type the value PRESENTS: an assumption
    // says what the symbol is when it has a value, and absence is a state
    // every type can take (ruled 2026-09-09). So the `missing` arm is removed
    // first, and a number literal held through a restriction is read back —
    // `5 {a > 0}` types `integer | missing`, which inhabits no range, while
    // the 5 it holds does. Without this, `assume(v > 3)` refused
    // `v := 5 {a > 0}` while accepting the identical ungated `5`. A value
    // whose presented type still fails is refused here exactly as the ungated
    // one is, with the same message. (2026-09-22)
    if (!presentedValueType(ce, value).matches(provenType))
      throw assumptionRefusalError(id, value, provenType, undefined);
  }

  // The type is only a summary of the facts — an equality contributes the
  // promoted TIER of its value, so `assume(x = 5)` leaves the check above
  // happy with `assign(x, 7)`. Ask the facts themselves: substitute the
  // candidate value into each one and refuse a value that makes one false.
  const refuted = refutingFact(ce, def, value);
  if (refuted !== undefined)
    throw assumptionRefusalError(id, value, def.declaredType, refuted);

  // An INFERRED type widens to cover the value (see the caller): nothing to
  // reject. When the type was DECLARED, hold the assigned value to it — the
  // same per-axis check the declare-with-value route applies in the
  // `_BoxedValueDefinition` constructor. Without it a declared type was a
  // contract only at declaration time: `ce.declare('p', 'point')` followed by
  // an assignment of a merely structurally-similar value silently installed a
  // value the `Declare(p, "point", …)` spelling rejects.
  // `matchesDeclaredTypeAxes` (rather than a bare `matches()`) keeps the
  // effects axis judged by its own provenance, so a `{scope}`-inferred closure
  // still fits a bare-specifier declared arrow.
  if (def.inferredType || def.type.isUnknown) return 'match';
  // A declared PLACEHOLDER SKELETON (`a: list` — bare constructor, elements
  // to be determined) is the contract; the stored type may carry a previous
  // assignment's element REFINEMENT (`list<integer>`), which must not
  // harden into the contract: `a = ["x"]` re-refines (Phase 1 ruling R1,
  // 2026-08-18), so compatibility is judged against the skeleton.
  const contract =
    def._placeholderSkeleton !== undefined
      ? ce.type(def._placeholderSkeleton)
      : def.type;
  // A value whose type only OVERLAPS the declared type is accepted, as a call
  // argument is, and each read of the symbol tests the evaluated value
  // (`storeAdmission()` in `effects-inference.ts`): with `a: real`, the value
  // `(-sqrt(1 - a^2), a)` (typed `tuple<complex, real>`) is stored into
  // `P: tuple<real, real>`, and a read of `P` with `a = 5` is an
  // `incompatible-type` error. A value whose type does not overlap the
  // declared type is still refused here. The verdict `'overlap'` is returned,
  // not recorded: this check writes nothing, and the store records it.
  const verdict = storeAdmission(ce, value, contract, def.effectsDeclared, id);
  if (verdict === 'refuse') throw declaredTypeError(id, value, contract);
  return verdict;
}

/**
 * The refusal an ASSUMPTION makes of an assigned value.
 *
 * Deliberately not a {@link declaredTypeError}: nothing declared `v` to be
 * greater than 3 — an assumption in force says so, and the way to lift it is
 * `forget("v")`, not a change to the declaration. The message names the fact
 * that refuses the value when there is one, and otherwise the type the facts
 * prove together.
 */
function assumptionRefusalError(
  id: string,
  value: Expression,
  requirement: BoxedType,
  fact: Expression | undefined
): TypeCompatibilityError {
  const because =
    fact !== undefined
      ? `the assumption in force "${fact.toString()}"`
      : `the assumptions in force, which require the type "${requirement}"`;
  return new TypeCompatibilityError(
    id,
    requirement,
    value.type,
    'value',
    [
      `Symbol "${id}"`,
      `The value "${value.toString()}" is refused by ${because}`,
      `Use forget("${id}") to lift the assumptions about "${id}"`,
    ].join('\n|   ')
  );
}

/**
 * Would `ce.assign(id, value)` be rejected? Answered WITHOUT writing anything,
 * so the `Assign` operator's destructuring route can validate every leaf of a
 * pattern before it writes the first one (`(a, b) := (1, 2.5)` with `b:integer`
 * must leave `a` alone). Throws exactly what the write would throw — the shared
 * {@link assertAssignableValueDef} is the single source of the verdict, so the
 * two cannot drift.
 *
 * Silent — the assignment is left to be attempted — for the cases whose
 * verdict is only reached by running the install machinery. Each is a
 * documented residual, mirroring the destructuring `let`'s pre-pass:
 * - a name with NO prior definition (the assignment creates one; there is
 *   nothing yet to conflict with);
 * - an OPERATOR-slot target: the minted-constructor guard, the
 *   declared-signature reconciliation and the builtin-shadowing choice all
 *   live inside the install;
 * - a value that installs as an operator DEFINITION rather than a value (a
 *   `Function` literal, a wildcard-bearing body): function-literal
 *   reconciliation and the effect-contract check happen there;
 * - a target carrying a DECLARED function signature: the assigned value is
 *   RECONCILED against it first (and `canonicalFunctionLiteral` lifts a
 *   non-literal, so this covers a scalar too), so judging it here could reject
 *   a value the install accepts.
 */
/** Refuse global shadowing of a library constant whose MathJSON keeps its name. */
export function assertDeclarationName(ce: IComputeEngine, id: string, scope: Scope): void {
  const systemScope = ce.contextStack[0]?.lexicalScope;
  const globalScope = ce.contextStack[1]?.lexicalScope;
  const checkingGlobal = ce._staticTypeCheckDepth > 0 &&
    ce.context.name === 'epsil:static-check' && scope.parent === globalScope;
  if (scope === globalScope || checkingGlobal) {
    const visible = lookup(id, scope);
    if (
      visible !== undefined &&
      isValueDef(visible) &&
      visible.value.isConstant &&
      (systemScope?.bindings.get(id) === visible ||
        ce._libraryProvenance.get(id)?.binding === visible)
    ) {
      const boxed = ce.symbol(id);
      if (isSymbol(boxed) && boxed.symbol === id)
        throw Error(
          `Cannot declare "${id}" in the global scope: it is a library constant (declare it in a nested scope)`
        );
    }
  }

}

export function assertAssignable(
  ce: IComputeEngine,
  id: string,
  value: Expression
): 'match' | 'overlap' | undefined {
  if (id === 'Nothing') return; // `assignFn` no-ops on it
  const def = ce.lookupDefinition(id);
  if (def === undefined || !isValueDef(def)) return;
  const v = assignValueAsValue(ce, value);
  if (v === undefined) return;
  if (
    !def.value.isConstant &&
    !def.value.inferredType &&
    hasFunctionSignature(def.value.type.type)
  )
    return;
  return assertAssignableValueDef(ce, id, def.value, v);
}

function assignValueAsValue(
  ce: IComputeEngine,
  value: AssignValue
): Expression | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === 'function') return undefined;

  if (typeof value === 'boolean') return value ? ce.True : ce.False;
  if (typeof value === 'number' || typeof value === 'bigint')
    return ce.number(value);
  const expr = ce.expr(value);
  // Explicit function expressions should always be treated as operator definitions
  if (expr.operator === 'Function') return undefined;
  if (expr.unknowns.some((s) => s.startsWith('_'))) {
    // If the expression has wildcards, it should be treated as a function
    // E.g. ["Add", "_", 1] or ["Add", "_x", 1]
    // Note: Regular unknowns (e.g., "x", "a", "b") are fine in values
    return undefined;
  }
  return expr;
}

/** Convert an assigned value into an operator definition (a function literal
 * or a JS evaluate function). Exported for the `Assign` operator's
 * CANONICAL-time constructor-function recognition (§4.5b D13): an alias
 * type's same-name function replaces the minted identity constructor at
 * canonicalization so later statements validate against the real signature. */
/**
 * The plain-structure serialization of `get json`, with each node's
 * `sourceOffsets` kept, in the object form the Epsil parser itself emits —
 * so re-boxing preserves the debugger's statement-level pause points
 * (function statements, and the bare symbol/number/string statements that
 * are Epsil's idiomatic return values).
 *
 * Deliberately NOT `toMathJson()`: that is the display serializer, whose
 * function shorthand rewrites a `Function` literal (collapsing its parameter
 * list) — the re-boxed value must be structurally faithful.
 *
 * The operands of a function node follow `serializedOperands()`
 * (`boxed-expression/box.ts`), as does `rawCopyWithSourceOffsets()` below:
 * the three must stay the same.
 */
function jsonWithSourceOffsets(expr: Expression): MathJsonExpression {
  const sourceOffsets = expr.sourceOffsets;
  if (isSymbol(expr)) {
    return sourceOffsets !== undefined
      ? { sym: expr.symbol, sourceOffsets }
      : expr.json;
  }
  if (isNumber(expr)) {
    const json = expr.json;
    if (sourceOffsets === undefined) return json;
    if (typeof json === 'number') return { num: String(json), sourceOffsets };
    if (typeof json === 'object' && json !== null && 'num' in json)
      return { ...json, sourceOffsets };
    return json; // composite numeric form (e.g. ['Complex', …])
  }
  if (isString(expr)) {
    return sourceOffsets !== undefined
      ? { str: expr.string, sourceOffsets }
      : expr.json;
  }
  if (!isFunction(expr)) return expr.json;
  // Mirror `BoxedFunction.get json`: serialize the structural form's
  // operands (sorting/flattening for associative operators, no folding).
  const structural = expr.structural;
  const ops = isFunction(structural) ? structural.ops : expr.ops;
  // A `Function` literal's parameter annotation that INFERENCE wrote is left
  // out here as it is in `BoxedFunction.get json` (`isInferredTypedParameter`):
  // the mark is keyed on the node, so an annotation carried through this
  // MathJSON and re-boxed would come back as a WRITTEN one and print as such.
  // The re-boxed literal is canonicalized in the same body scope, where the
  // inference runs again and marks the annotation again.
  const fn = [
    ...copiedHead(expr),
    ...inSerializationScope(expr.localScope, () =>
      ops.map((op, i) =>
        expr.operator === 'Function' &&
        i > 0 &&
        isInferredTypedParameter(op) &&
        isFunction(op)
          ? jsonWithSourceOffsets(op.op1)
          : jsonWithSourceOffsets(op)
      )
    ),
  ] as [MathJsonSymbol, ...MathJsonExpression[]];
  return sourceOffsets !== undefined ? { fn, sourceOffsets } : fn;
}

/**
 * The head of the copy of the call `expr` that `jsonWithSourceOffsets()` and
 * `rawCopyWithSourceOffsets()` make: the operator name, or
 * `"Apply", ["Module", name]` for a call bound to the library definition of
 * its name where a binding of the current scopes hides that definition, as
 * `BoxedFunction.get json` writes it. Without the qualifier, the copy of the
 * body of `function Floor(x) { std::floor(x) + 1 }` is boxed again by name
 * in the scope that binds the user function `Floor`, and the function calls
 * itself. The operands of a scoped node are copied inside
 * `inSerializationScope()` with its local scope, so a parameter `Floor` of
 * the literal also hides the library definition.
 */
function copiedHead(
  expr: Expression
): [MathJsonSymbol] | ['Apply', ['Module', MathJsonSymbol]] {
  const name = expr.operator;
  const def = expr.operatorDefinition;
  if (
    def !== undefined &&
    hidesLibraryBinding(expr.engine, name, def, isApplicableDef)
  )
    return ['Apply', ['Module', name]];
  return [name];
}

/**
 * The raw expression that `ce.box(jsonWithSourceOffsets(expr), { form:
 * 'raw' })` gives, built without writing the MathJSON tree: each distinct
 * node of `expr` is copied once, so a node that several parents share is
 * shared in the copy too. Work and memory are linear in the number of
 * distinct nodes, where the MathJSON has one copy of a node for each path
 * from the root (`Max(t, t)` nested 30 deep has 31 distinct nodes and 2^30
 * paths).
 *
 * Each function node is boxed from a MathJSON node whose operands are the
 * copies of its operands, with the same operator, the same operands (those
 * of the structural form, minus the parameter annotations that inference
 * wrote on a `Function` literal) and the same `sourceOffsets` as in
 * `jsonWithSourceOffsets()`. A leaf, and a `Hold` with what it holds, are
 * boxed from their MathJSON, as on that route.
 *
 * The canonical form of the copy is the canonical form of the MathJSON.
 * When one `canonical` read meets the same raw node again, it returns the
 * result of the first meeting, but only if the lexical scope is the same
 * (`_transientCanonical`, `boxed-function.ts`): an occurrence below a
 * binder is still canonicalized in the scope of the binder. That holds
 * only for a VALID copy: the `canonical` read of a raw node that holds an
 * `Error` returns the raw node, where boxing the MathJSON canonicalizes the
 * nodes around the error. The caller boxes an invalid literal from its
 * MathJSON.
 */
function rawCopyWithSourceOffsets(
  ce: IComputeEngine,
  expr: Expression
): Expression {
  const copies = new Map<Expression, Expression>();
  const copy = (node: Expression): Expression => {
    let out = copies.get(node);
    if (out !== undefined) return out;
    if (!isFunction(node) || node.operator === 'Hold')
      out = ce.box(jsonWithSourceOffsets(node), { form: 'raw' });
    else {
      // The same operands as `jsonWithSourceOffsets()`.
      const structural = node.structural;
      const ops = isFunction(structural) ? structural.ops : node.ops;
      const fn = [
        ...copiedHead(node),
        ...inSerializationScope(node.localScope, () =>
          ops.map((op, i) =>
            node.operator === 'Function' &&
            i > 0 &&
            isInferredTypedParameter(op) &&
            isFunction(op)
              ? copy(op.op1)
              : copy(op)
          )
        ),
      ] as [MathJsonSymbol, ...Expression[]];
      const sourceOffsets = node.sourceOffsets;
      out = ce.box(
        (sourceOffsets !== undefined
          ? { fn, sourceOffsets }
          : fn) as unknown as MathJsonExpression,
        { form: 'raw' }
      );
    }
    copies.set(node, out);
    return out;
  };
  return copy(expr);
}

export function assignValueAsOperatorDef(
  ce: IComputeEngine,
  value: AssignValue
): OperatorDefinition | undefined {
  if (typeof value === 'function')
    return { evaluate: value, signature: 'function' };

  if (value === undefined || value === null) return undefined;
  if (typeof value === 'boolean') return undefined;

  const body = canonicalFunctionLiteral(ce.expr(value));
  if (body === undefined) return undefined;

  // Phase 3 (§9.2): when the literal carries type annotations (an annotated
  // parameter or a return-type ascription), derive an explicit operator
  // signature from its type so that calls to the symbol validate the annotated
  // parameter types and carry the ascribed return type — exactly as the
  // `Declare(f, "(…) -> any", Function(…))` workaround does. This flips
  // `inferredSignature = false` for the operator.
  // The derived signature is INFERENCE-produced, so its arrow specifier must
  // not read as an author-stated effect contract (which would set
  // `effectsDeclared` and make the engine check its own inference against
  // itself). Strip the top-level specifier; the body walk re-derives it.
  // EXCEPT when the literal carries a full-signature return marker
  // (`docs/EFFECTS-MODEL.md`, "Epsil surface"): those effects are
  // AUTHOR-stated, so they ride onto the derived signature — which makes the
  // operator-def constructor set `effectsDeclared` and run the
  // definition-annotation check (`inferred ⊆ declared`) on its own.
  if (functionLiteralHasAnnotation(body)) {
    const stripped = stripArrowEffects(body.type.type);
    const declared = functionLiteralDeclaredEffects(body);
    return {
      evaluate: body,
      signature:
        declared === undefined
          ? stripped
          : withArrowEffects(stripped, declared),
      // The derived signature makes `inferredSignature = false`, so calls now
      // run through `validateArguments` — which admits a collection operand at
      // a scalar parameter only when the definition is `broadcastable`. Left at
      // its `false` default, a bare `ce.assign('f', ⟨annotated literal⟩)`
      // REJECTED `f([1,2,3])` with `incompatible-type` while the very same
      // literal broadcasts on the declare-then-assign VALUE route (`box.ts`
      // gates that validation on `paramsAreScalar`) and on the COMPILED path
      // (`userFunctionParamsAreScalar`, `base-compiler.ts`). Derive the flag
      // the same way, so the three routes read one gate. Polytype-aware: a
      // parameter quantified at a collection bound (`T: indexed_collection`)
      // binds its argument WHOLE and keeps the flag false.
      broadcastable: paramsAreScalar(stripped),
      // R4 — record that this pinned signature is DERIVED from the literal, not
      // declared on the NAME. A later UNTYPED assign full-replaces it (D6)
      // instead of checking the new body against the old annotation.
      _derivedSignature: true,
      // Only the ANNOTATED slots are the author's contract: a bare slot
      // admits any argument at the call (`validationSignatureOf`).
      _validationSignature: validationSignatureOf(body, stripped),
    };
  }

  // Untyped literal: don't set an explicit signature - let it be inferred from
  // the body. This ensures inferredSignature = true, which allows the return
  // type to be properly narrowed during type checking (e.g., in Add operands).
  return { evaluate: body };
}

/**
 * The signature a call of the annotated function literal `literal` validates
 * its arguments against: `signature` (the literal's derived arrow) with the
 * type of each BARE parameter replaced by `any`. `undefined` when every
 * parameter is annotated (the derived signature is then the contract as it
 * stands), when the literal is generic, or when its parameters do not pair
 * with the signature's required arguments (a trailing rest parameter is
 * paired with the signature's variadic argument and is accepted).
 *
 * A bare parameter's type in the derived signature is inferred from its uses
 * in the body (`p[1]` gives `indexed_collection<number>`). It is a reading,
 * not something the author wrote, and a function with no annotation at all
 * is not validated at its calls. So an annotation on ONE parameter must not
 * turn the inferred types of the others into contracts (user decision
 * 2026-09-30): with `fill(p, q, r, depth, acc: list<…>)`, the call
 * `fill(a, b, c, 2, xs)` with `c` typed `missing | tuple<number, number,
 * number>` was refused at the inferred slot `r`, although the interpreter
 * runs it and the same function with `acc` bare accepts it. `any`, not
 * `unknown`, because `unknown` excludes the absence markers.
 */
export function validationSignatureOf(
  literal: Expression,
  signature: Type
): Type | undefined {
  if (typeof signature !== 'object' || signature.kind !== 'signature')
    return undefined;
  if (isPolymorphicType(signature)) return undefined;
  const params = functionLiteralParameters(literal);
  const args = signature.args ?? [];
  // A rest parameter (`(n: number, p, ...rest) ↦ …`) is the last parameter
  // of the literal and the variadic argument of the signature (`any*`,
  // which already admits everything), so the literal then has one parameter
  // more than the signature has required arguments.
  // A parameter with a default value (`(x, k = 2) => …`) is an optional
  // argument of the signature, and a bare one admits any argument as a bare
  // required parameter does.
  const optArgs = signature.optArgs ?? [];
  const slots = args.length + optArgs.length;
  const hasRest =
    params.length === slots + 1 && signature.variadicArg !== undefined;
  if (params.length !== slots && !hasRest) return undefined;
  const leading = params.slice(0, slots);
  if (!leading.some((p) => p.type === undefined)) return undefined;
  const relax = (a: NamedElement, i: number): NamedElement =>
    leading[i].type === undefined ? { ...a, type: 'any' } : a;
  return {
    ...signature,
    args: args.map((a, i) => relax(a, i)),
    ...(optArgs.length > 0
      ? { optArgs: optArgs.map((a, i) => relax(a, args.length + i)) }
      : {}),
  };
}

/**
 * `signature`, the signature that a partly annotated function literal
 * derived, with the placeholder `unknown` in each slot that the literal left
 * bare and that the new literal `literal` annotates. `validation` is the
 * signature that the calls are validated against (`validationSignatureOf`):
 * it types a bare slot `any`, and an annotated slot as `signature` does.
 *
 * The type of a bare slot is inferred from the uses of the parameter: `p[1]`
 * gives `p: tuple<number>`. When a new literal that annotates the parameter
 * is assigned over the derived signature, the annotation must replace the
 * inferred type. Kept as it was, it refused calls that the new literal
 * accepts: after `k := (p, n: number) ↦ p[1] + n`, the new literal
 * `(p: indexed_collection<number>, n: number) ↦ p[1] + n` was installed with
 * `p: tuple<number>`, and `k((1, 2), 1)` was refused.
 *
 * A slot that the new literal leaves bare keeps its inferred type. That type
 * can hold evidence that the literal does not carry: the argument of a
 * self-call (`f(n: number, s) = s if n == 0 else f(n - 1, [1, 2])` types `s`
 * as `list<any>`), which the assignment of the same literal again must keep.
 *
 * `signature` is returned as it is when `validation` is `undefined` (every
 * slot is annotated) or when the signatures and the literal do not pair slot
 * by slot.
 */
export function bareSlotsAsPlaceholders(
  signature: Type,
  validation: Type | undefined,
  literal: Expression
): Type {
  if (
    validation === undefined ||
    typeof signature !== 'object' ||
    signature.kind !== 'signature' ||
    typeof validation !== 'object' ||
    validation.kind !== 'signature'
  )
    return signature;
  const args = signature.args ?? [];
  const params = functionLiteralParameters(literal);
  const bare = (validation.args ?? []).map(
    (a, i) =>
      a.type === 'any' &&
      args[i]?.type !== 'any' &&
      params[i]?.type !== undefined
  );
  if (bare.length !== args.length || !bare.some((x) => x)) return signature;
  return {
    ...signature,
    args: args.map((a, i) => (bare[i] ? { ...a, type: 'unknown' } : a)),
  };
}

/**
 * The signature that a reassignment compares a new literal against: the
 * pinned signature with every slot that the earlier literal left bare
 * replaced by a placeholder (`bareSlotsAsPlaceholders`) and then refined
 * from the new literal's own signature (`refineDeclaredPlaceholders`). The
 * Epsil static check reads it through this function, so that the check and
 * `assignFn` apply one rule, and so that the construction seam of function
 * literals (`effects-inference.ts`) keeps its reviewed set of importers.
 */
export function reassignmentBaseSignature(
  signature: Type,
  validation: Type | undefined,
  literal: Expression
): Type {
  return refineDeclaredPlaceholders(
    bareSlotsAsPlaceholders(signature, validation, literal),
    literal.type.type
  );
}

/** True if a canonical `Function` literal carries at least one type annotation
 * — an annotated parameter or a return-type ascription (the Phase-1 §4.2
 * marker). Untyped literals return `false` and keep the inferred-signature
 * behavior.
 *
 * A full-signature marker with a WIDE result (`(…) scope -> unknown`) declares
 * no return type and may annotate no parameter, yet IS an annotation: the
 * effects it states are the author's contract. */
export function functionLiteralHasAnnotation(literal: Expression): boolean {
  if (functionLiteralReturnType(literal) !== undefined) return true;
  if (functionLiteralDeclaredEffects(literal) !== undefined) return true;
  // A GENERIC literal (a whole-signature `where` marker) is the strongest
  // annotation there is, yet it declares NO return type (the result mentions a
  // variable, so `functionLiteralReturnType` joins the wide-result convention)
  // and, under erasure, no annotated parameter either. Without this arm
  // `ce.assign('f', genericLiteral)` fell to the inferred-signature path, which
  // reads the ascribed BODY type and produced the nonsense
  // `(unknown) -> (x: T) -> T where T`.
  if (isPolymorphicType(literal.type.type)) return true;
  return functionLiteralParameters(literal).some((p) => p.type !== undefined);
}

/**
 * §6.3 declared-signature reconciliation — arity guard shared by the
 * declare-with-value, `Declare(f, sig, value)` and assign paths.
 *
 * A `Function` literal defines a *fixed-arity* function of arity `L`: it can
 * only service calls of exactly arity `L` (`function-utils.ts` curries calls
 * below `L` into a partial application and throws on calls above `L`). It is
 * therefore compatible with an explicit declared signature only when that
 * signature's set of accepted call arities is exactly `{L}` — i.e. a signature
 * with no optional and no variadic arguments whose required arity is `L`.
 *
 * A signature with optional or variadic arguments, or a different fixed arity,
 * permits call arities the literal cannot handle (which would otherwise let a
 * legal call silently partial-apply or throw at runtime), so it is a genuine
 * conflict and is rejected here rather than stored. Function subtyping alone
 * does not catch this: it treats an over-arity literal as assignable to a
 * lower-arity signature.
 *
 * Does nothing when the literal is not a `Function` literal or the declared
 * type is not a plain function signature (nothing to check).
 */
function assertFunctionLiteralArity(
  id: MathJsonSymbol,
  literal: Expression,
  declaredType: Type,
  declaredDisplay: string
): void {
  if (!isFunction(literal, 'Function')) return;

  // A parameter of the declared signature with a default value is always
  // supplied when the symbol is called (the default is inserted), so the
  // literal must take it as a required parameter:
  // `(number, number = 2) -> number` accepts `(x, k) => x * k`.
  declaredType = defaultedSlotsAsRequired(declaredType);

  // Only a concrete declared *signature* constrains arity. The top `function`
  // type (`ce.declare('f', 'function')`, stored as the primitive string
  // `'function'`) is a wildcard: it promises callers nothing about arity, so a
  // fixed-arity literal is a valid implementation. Use the raw declared type
  // here rather than `hasFunctionSignature`, which is true for that wildcard
  // (it is callable) and would wrongly bring it into the arity check.
  //
  // An OVERLOAD SET (an intersection of signatures) constrains arity too, and
  // every arm has to be satisfied — the value must be callable at all of them.
  // Returning early for it let a 2-parameter literal be assigned to
  // `((integer) -> number) & ((string) -> number)`, after which every declared
  // 1-argument call would silently partial-apply.
  const arms = signatureArms(declaredType);
  if (!arms) return;

  // The arities the LITERAL accepts. A rest parameter (`(a, ...rest) => …`)
  // makes the literal accept its fixed count or more, so counting the
  // parameter operands would answer with a fixed arity the literal does not
  // have.
  // A parameter with a default value (`(x, k = 2) => …`) may be left out,
  // so such a literal accepts from `literalRequired` to `literalFixed`
  // arguments.
  const {
    fixed: literalFixed,
    variadic: literalVariadic,
    required: literalRequired,
  } = functionLiteralArity(literal);
  const literalArity = literalVariadic
    ? `${literalFixed} or more`
    : literalRequired < literalFixed
      ? `${literalRequired} to ${literalFixed}`
      : `${literalFixed}`;

  /** Whether the literal is a valid implementation of `sig`: the arm and the
   * literal must accept the SAME set of call arities. A fixed-arity literal
   * therefore needs an arm with exactly one arity, and a literal with a rest
   * parameter needs a variadic arm that starts where the rest parameter does
   * and, like the rest parameter, admits an empty tail. A literal with
   * parameters that have a default value accepts a range of arities: it is
   * a valid implementation of a fixed-arity arm whose arity is in the range,
   * and of an arm with optional parameters whose range is inside it, since
   * every call that the arm admits is a call that the literal accepts. */
  const armFits = (sig: FunctionSignature): boolean => {
    const required = sig.args?.length ?? 0;
    const optional = sig.optArgs?.length ?? 0;
    if (literalRequired < literalFixed && !literalVariadic)
      return (
        sig.variadicArg === undefined &&
        required >= literalRequired &&
        required + optional <= literalFixed
      );
    if (optional > 0) return false;
    if (literalVariadic) {
      if (sig.variadicArg === undefined) return false;
      // Both sides accept "N arguments or more", so they agree exactly when
      // the two N's agree. The arm's N is its MINIMUM call arity, which a
      // non-empty tail (`any+`) raises by one: `(any+) -> R` and
      // `(a, ...rest) => …` both accept one argument or more, while
      // `(integer, any+) -> R` needs two and `(a, ...rest) => …` cannot
      // promise that.
      return required + (sig.variadicMin ?? 0) === literalFixed;
    }
    if (sig.variadicArg !== undefined) return false;
    return required === literalFixed;
  };

  if (arms.every(armFits)) return;

  const describe = (sig: FunctionSignature): string => {
    const required = sig.args?.length ?? 0;
    const optional = sig.optArgs?.length ?? 0;
    if (sig.variadicArg !== undefined)
      return `${required + (sig.variadicMin ?? 0)} or more`;
    if (optional > 0) return `${required} to ${required + optional}`;
    return `exactly ${required}`;
  };

  // For an overload set, report every arm's accepted arity so the author can
  // see which one the literal fails — deduplicated, since arms commonly agree
  // on arity and differ only in parameter types ("exactly 1 / exactly 1").
  const accepted = [...new Set(arms.map((a) => describe(a)))].join(' / ');

  throw new Error(
    [
      `Symbol "${id}"`,
      `The function literal "${literal.toString()}" takes ${literalArity} parameter(s), but the declared signature "${declaredDisplay}" accepts ${accepted}`,
    ].join('\n|   ')
  );
}

/**
 * The default-`!scope` ceiling of `ce.declare(id, { value: literal })`.
 *
 * A literal that states its own effects (a full-signature return marker,
 * `() scope -> integer`) is a contract when the declaration states none, as on
 * the `ce.assign()` route: the effects that the walk of its body infers must be
 * a subset of the stated ones, and the default ceiling does not apply.
 * Otherwise `assertDeclaredEffects()` checks the literal against the declared
 * type, and refuses a proven escaping write when no effects are stated.
 */
function assertScopeCeiling(
  ce: IComputeEngine,
  id: MathJsonSymbol,
  literal: Expression,
  declaredType: Type,
  effectsDeclared: boolean
): void {
  if (!effectsDeclared) {
    const stated = functionLiteralDeclaredEffects(literal);
    if (stated !== undefined) {
      const inferred = inferFunctionLiteralEffects(ce, literal, {
        selfName: id,
      }).effects;
      if (!isEffectSubset(inferred, stated))
        throw new EffectContractError(id, stated, inferred);
      return;
    }
  }
  assertDeclaredEffects(id, literal, declaredType, effectsDeclared, undefined, {
    ce,
  });
}

/**
 * Whether a declaration's type STATES its arrow's effects — a non-empty
 * specifier, or the `pure` keyword, which builds the stated-empty `effects: []`
 * (ruled 2026-08-01). Either way the statement is IN the type, so this is just
 * "the arrow carries an effect set", and it reads the same off a type string
 * and off an already-boxed `BoxedType`.
 */
function declaredTypeStatesEffects(
  ce: IComputeEngine,
  declared: Type | TypeString | BoxedType | undefined
): boolean {
  if (declared === undefined) return false;
  const type =
    declared instanceof BoxedType
      ? declared.type
      : parseType(declared, ce._typeResolver);
  return signatureEffects(type) !== undefined;
}

/**
 * The definition-annotation check on the declared-signature routes
 * (`docs/EFFECTS-MODEL.md`, "Definition-annotation check"): an explicit effect
 * annotation is a contract, accepted iff `inferred ⊆ declared` — over-declaring
 * allowed.
 *
 * "Explicit" is the per-axis provenance of "Annotation provenance": any effect
 * set on the declared arrow — a non-empty specifier, or the stated-empty `[]`
 * an author-written `pure` builds (equivalently the `effects: []` field),
 * which declares the EMPTY set as a contract — or `effectsDeclared` for a
 * declaration that stated it some other way. A **bare** specifier slot states
 * nothing: effects stay on the inferred track and every assigned body is
 * accepted and re-stamped.
 *
 * Raising {@link EffectContractError} (rather than letting the generic "not
 * compatible with the type" check below fire) routes the failure through the
 * same `incompatible-type` error-value channel the `Assign` / `Declare`
 * operators use for the object-form declaration.
 */
function assertDeclaredEffects(
  id: MathJsonSymbol,
  literal: Expression,
  declaredType: Type,
  effectsDeclared: boolean,
  /** Where the contract was STATED, per the effects-axis provenance of the
   * PRIOR definition half the caller read `effectsDeclared` from —
   * `latestDeclaredEffectsSite`. Absent for a construction-stated contract
   * (which records no entry) and on the fresh-Declare path (no prior
   * half). Rendering only. */
  declaredAt?: Expression,
  /** Enforce the default-`!scope` ceiling on the BARE track (`docs/
   * EFFECTS-MODEL.md`, "Scope is opt-in"): with no stated contract, a body
   * the walk PROVES to write outside itself is refused instead of being
   * accepted-and-restamped. Passed by the declare-then-assign routes —
   * which install a GLOBAL named definition, so the ruling applies — and
   * by the declare-WITH-value route, except when the engine binds a local,
   * such as a block-local `let` whose writer closure (a closure mutating its
   * enclosing literal's local) must stay installable
   * (`markLocalBinding()`). The trigger is
   * the walk's proven-mutation bit, never the arrow's `scope` label, so
   * `{any}` conservatism from unresolved forward references stays
   * optimistic. Requires `ce`. */
  scopeDefault?: { ce: IComputeEngine }
): void {
  const declared = signatureEffects(declaredType);
  if (declared === undefined && !effectsDeclared) {
    if (scopeDefault === undefined) return;
    const inferred = inferFunctionLiteralEffects(scopeDefault.ce, literal, {
      selfName: id,
    });
    if (inferred.escapingWrite)
      throw new EffectContractError(
        id,
        undefined,
        inferred.effects,
        undefined,
        /* scopeDefault */ true
      );
    return;
  }
  const inferred = signatureEffects(literal.type.type);
  if (!isEffectSubset(inferred, declared))
    throw new EffectContractError(id, declared, inferred, declaredAt);
}

/**
 * §6.3 declared-signature reconciliation. When a `Function` literal is assigned
 * to a symbol carrying an explicit declared signature and the literal lacks its
 * own return-type ascription, the declared return type is *ascribed* onto the
 * literal (the declaration is authoritative, TypeScript-style) rather than
 * covariantly checked against weak body inference — which would otherwise throw
 * at `boxed-value-definition.ts`.
 *
 * Returns the (possibly rebuilt) literal. Genuine parameter/return conflicts
 * are left for the caller's compatibility check to reject.
 */
/**
 * BoxedType-level wrapper for {@link refineDeclaredPlaceholders}, shared by
 * the install routes: refine the DECLARED type's `unknown` placeholder slots
 * from the value's type, reboxing only when something actually moved so an
 * unchanged declaration keeps its object identity (callers compare against
 * the original to decide whether to persist).
 *
 * Called TWICE per route: once from the literal's own (pre-ascription) type
 * so parameter ascription and the arity/effects checks see the concrete
 * parameter slots, and once from the reconciled (post-ascription) type,
 * because a pass-through body (`P ↦ P` under `(tuple<…>) -> unknown`) only
 * shows its concrete RESULT after ascription re-canonicalized it — a
 * single early pass persisted `-> unknown` and re-created the very
 * placeholder-stuck call sites the refinement exists to remove.
 */
function refineDeclaredType(
  ce: IComputeEngine,
  declared: BoxedType,
  valueType: BoxedType
): BoxedType {
  const refined = refineDeclaredPlaceholders(declared.type, valueType.type);
  return refined === declared.type ? declared : ce.type(refined);
}

/**
 * The body of a function literal, for a literal that is boxed again so that
 * its body is canonicalized afresh: `body.json` when the body is invalid,
 * else the raw expression that boxing `body.json` with `form: 'raw'` gives
 * (`ce.rebind(body, { form: 'raw' })`). The raw expression keeps a node that
 * several parents share shared, and the canonicalization of the literal then
 * makes its canonical form once for each scope
 * (`rawCopyWithSourceOffsets()` says why the two routes agree, and why an
 * invalid body takes the MathJSON route). `body.json` is a tree, with one
 * copy of a shared node for each path: with the body `e_{k+1} = e_k +
 * sin(e_k)` 14 deep under a declared `(real) -> real`, the return
 * ascription took 0.7 s and made a body of 65,540 nodes for 34 distinct
 * ones.
 */
function rawBodyForRebox(
  ce: IComputeEngine,
  body: Expression
): MathJsonExpression | Expression {
  return body.isValid ? ce.rebind(body, { form: 'raw' }) : body.json;
}

/**
 * The function literal `literal` built again from the operands `ops` (its
 * body, then its parameters), canonicalized in the scope where `literal` was
 * defined, so that the new body reads the bindings that the old body reads.
 *
 * A literal that a call evaluated and returned is a function value: it
 * keeps the activation of that call (`captureNestedLocals()`,
 * `function-utils.ts`), and a symbol
 * of the body that the call bound, a parameter or a local of the call, is
 * found through that activation. The MathJSON of the body has no scope,
 * so a literal built from it in the current scope would read those symbols
 * in the scope of the declaration that stores it. With
 * `h = n ↦ Block(g := z ↦ 0, z ↦ g(z) + n)`, `Declare(q, "(real) -> real",
 * h(1))` would store a `q` whose `g` is not bound, so that `q(0)` is
 * `1 + g(0)`, not 1; and with `Declare(g, "(real) -> real", h(n))` in the
 * body of another function, the `g` of the closure would be the `g` being
 * declared, so that a call of it does not end. A literal with no body scope,
 * or one that was defined in the current scope, is built in the current
 * scope.
 *
 * The type annotations in `ops` are text. A type name in that text names the
 * same type in both scopes, because the declared types of an engine are one
 * table that does not depend on the scope (`_typeRegistry`, `index.ts`).
 */
function reboxFunctionLiteral(
  ce: IComputeEngine,
  literal: Expression,
  ops: ReadonlyArray<ExpressionInput>
): Expression {
  const build = () => ce.box(['Function', ...ops]);
  const scope = functionLiteralDefiningScope(literal);
  if (scope === undefined || scope === ce.context.lexicalScope) return build();
  return ce._inScope(scope, build);
}

/**
 * Throws when the value that the body of the function literal `literal`
 * computes has a type with no value in common with the declared result of
 * `declaredType`, as an assignment of a value to a symbol declared with a
 * type does: with `g: (x: number) -> number`, `g := t ↦ t > 0` is refused,
 * as `v := True` is with `v: number`.
 *
 * The declared result is ascribed onto a literal whose inferred result is
 * WIDER than the declaration (`x ↦ x + 1` under `(integer) -> integer` is
 * inferred `number`), because inference is not precise
 * (`reconcileFunctionLiteralReturn`). A DISJOINT inferred result is not a
 * lack of precision: no value of the body can be of the declared type, so
 * the literal is refused by the rule that refuses such a value for a
 * declared symbol. The test is `provablyDisjoint()`, which answers `true`
 * only when no value is in both types. A body type that holds `character`
 * at any depth is not tested: a call accepts a character where a string is
 * declared, at any depth (`(s: string) ↦ s[1]` under `(string) -> string`,
 * a tuple of characters under `tuple<string, string>`), while the type
 * lattice keeps the two types apart.
 *
 * A generic result is read at the declared bounds of its type variables
 * (`(x: T) -> T where T: broadcastable<number>` reads the result
 * `broadcastable<number>`), and is not tested when a variable of the result
 * has no bound. A variable that occurs only in a parameter does not stop the
 * test: `(x: T) -> boolean where T` tests the result `boolean`.
 * Not tested either: a literal with its own return ascription (the
 * signature check tests it), a body with a `Return` that leaves the
 * function (its last statement is then not the only value it can return),
 * and an inferred result that states nothing (`unknown`, `any`, `never`).
 */
function assertBodyResultNotDisjoint(
  symbol: string,
  literal: Expression & FunctionInterface,
  declaredType: Type
): void {
  if (typeof declaredType !== 'object' || declaredType.kind !== 'signature')
    return;
  const read = isPolymorphicType(declaredType)
    ? substituteDeclaredBounds(declaredType.typeParams, declaredType)
    : declaredType;
  // The result of the signature itself: `functionResult()` reads a
  // signature that keeps a type variable as `unknown`.
  const declared =
    typeof read === 'object' && read.kind === 'signature'
      ? read.result
      : undefined;
  if (declared === undefined || hasFreeTypeVariables(declared)) return;
  if (isWideResultType(declared)) return;
  if (functionLiteralReturnType(literal) !== undefined) return;
  if (functionLiteralDeclaredSignature(literal) !== undefined) return;
  const body = literal.ops[0];
  if (body === undefined || leavesFunctionEarly(body)) return;
  const inferred = functionResult(literal.type.type);
  if (inferred === undefined || hasFreeTypeVariables(inferred)) return;
  const own = withoutAcceptedResults(inferred);
  if (own === undefined || isWideResultType(own) || own === 'never') return;
  if (mentionsCharacter(own)) return;
  // A collection under a parameter that can take a collection whole may be
  // the broadcast of the result, which a call accepts: with
  // `h: (list) -> number` and `h := t ↦ 2t`, `h([1, 2])` is `[2, 4]`
  // (`conformsUnderBroadcast` in `library/core.ts`). With scalar
  // parameters, each call applies the body to scalars, also a call that
  // maps over a list, and refuses a collection.
  if (!isScalarType(own) && someParameterTakesCollectionWhole(read)) return;
  if (!provablyDisjoint(own, declared)) return;
  const ce = literal.engine;
  const reason =
    `its body computes a value of type "${typeToString(own)}", ` +
    `which has no value in common with the declared result "${typeToString(declared)}"`;
  throw new TypeCompatibilityError(
    symbol,
    ce.type(declaredType),
    literal.type,
    'value',
    [
      `Symbol "${symbol}"`,
      `The value "${literal.toString()}" of type "${literal.type}" is not compatible with the type "${ce.type(declaredType)}"`,
      `The body of "${symbol}" computes a value of type "${typeToString(own)}", which has no value in common with the declared result "${typeToString(declared)}"`,
    ].join('\n|   '),
    reason
  );
}

/**
 * Whether a parameter of the signature `sig` can receive a collection whole.
 * A parameter of a scalar type, of a `broadcastable<…>` type or of a
 * function type does not: a collection argument there maps the function
 * over its elements (a function argument is never a collection). A rest
 * parameter collects its arguments into one tuple, and a parameter whose
 * type keeps a type variable can be a collection.
 */
function someParameterTakesCollectionWhole(sig: Type): boolean {
  if (typeof sig !== 'object' || sig.kind !== 'signature') return true;
  if (sig.variadicArg !== undefined) return true;
  return [...(sig.args ?? []), ...(sig.optArgs ?? [])].some(({ type: t }) => {
    if (hasFreeTypeVariables(t)) return true;
    if (isSubtype(t, 'function')) return false;
    if (typeof t === 'object' && t.kind === 'broadcastable') return false;
    return !isScalarType(t);
  });
}

/**
 * Whether the type `t` holds `character` at any depth: in an element, a
 * union member, or the definition of a type alias (`type alias Glyph =
 * character`). The walk reads every value of the type objects, so a field
 * NAMED `character` also counts: the caller then skips its test, which
 * never refuses a program. `seen` stops the walk at a recursive alias.
 */
function mentionsCharacter(t: unknown, seen: Set<object> = new Set()): boolean {
  if (t === 'character') return true;
  if (typeof t !== 'object' || t === null || seen.has(t)) return false;
  seen.add(t);
  return Object.values(t).some((v) => mentionsCharacter(v, seen));
}

/** A result type that states nothing about the value. */
function isWideResultType(t: Type): boolean {
  return t === 'unknown' || t === 'any' || t === 'expression';
}

/** `t` without the members whose values a call accepts under every declared
 * result: `NaN`, and the absence values `Missing` and `Nothing`
 * (`docs/ERROR-MODEL.md`). `undefined` when no other member is left. */
function withoutAcceptedResults(t: Type): Type | undefined {
  const accepted = (m: Type) =>
    m === 'nan' || m === 'missing' || m === 'nothing';
  if (accepted(t)) return undefined;
  if (typeof t !== 'object' || t.kind !== 'union') return t;
  const rest = t.types.filter((m) => !accepted(m));
  if (rest.length === 0) return undefined;
  return rest.length === 1 ? rest[0] : { kind: 'union', types: rest };
}

/** Whether `e` holds a `Return` of the enclosing function: a `Return`
 * outside every nested `Function` literal. */
function leavesFunctionEarly(
  e: Expression,
  /** The nodes already read. A body can share a node among several
   * parents, and a walk of every path then reads it once per path: a chain
   * of 30 shared levels has 2^30 paths. */
  seen: Set<Expression> = new Set()
): boolean {
  if (!isFunction(e) || seen.has(e)) return false;
  seen.add(e);
  if (e.operator === 'Return') return true;
  if (e.operator === 'Function') return false;
  return e.ops.some((op) => leavesFunctionEarly(op, seen));
}

export function reconcileFunctionLiteralReturn(
  ce: IComputeEngine,
  literal: Expression,
  declaredType: Type,
  /** The symbol that receives the literal, named by the error when the body
   * contradicts the declared result (`assertBodyResultNotDisjoint`). */
  symbol?: string
): Expression {
  if (!isFunction(literal, 'Function')) return literal;
  if (symbol !== undefined)
    assertBodyResultNotDisjoint(symbol, literal, declaredType);

  // A POLYTYPE declaration ascribes its whole clause onto a marker-less literal
  // (R1): the stored value is then self-describing — `f`'s value types as the
  // polytype, not as the erased `(unknown) -> unknown` its bare parameters
  // would otherwise infer. Runs BEFORE the return-type reconciliation below,
  // which has nothing ground to ascribe under a variable-mentioning result.
  const ascribed = ascribeDeclaredPolytype(ce, literal, declaredType);
  if (ascribed !== undefined) return ascribed;

  // A declared result that MENTIONS a quantified variable has nothing ground
  // to ascribe (§2.4, G4): the body's return stays inferred and call-site
  // result types come from the INSTANTIATED signature instead. Decided BEFORE
  // `functionResult`, which hands back the honest-but-useless-here `unknown`
  // on a polytype arm. A ground result under a `where` clause
  // (`(T) -> boolean where T`) reconciles exactly as it does under a ground
  // declaration.
  if (
    typeof declaredType === 'object' &&
    declaredType.kind === 'signature' &&
    mentionsQuantifiedVariable(declaredType.result, declaredType)
  )
    return literal;

  // The declaration must be a function signature with a result type.
  const declaredResult = functionResult(declaredType);
  if (declaredResult === undefined) return literal;

  // A declared result of `unknown` is a PLACEHOLDER the definition refines,
  // never a contract to ascribe. It is what the bare `function` wildcard
  // reports, and what a `(…) -> unknown` declaration still holds when
  // `refineDeclaredPlaceholders` found nothing in the literal to adopt.
  // Ascribing it would REPLACE the body's own inferred result with `unknown`,
  // the opposite of the refinement this route exists to perform.
  //
  // The covariant test below cannot catch this by itself: `unknown` excludes
  // the absence markers, so a body result that contains `missing` or `nothing`
  // — the type an else-less `If` or a default-less `Which` produces — is not a
  // subtype of `unknown` and failed that test, while a body typing `number`
  // passed and was left alone. The symbol therefore reported `unknown` for a
  // piecewise body and the concrete type for a plain one.
  if (declaredResult === 'unknown') return literal;

  // Respect an author-supplied return ascription. A full-signature marker with
  // a wide result declares no return type but is still the author's ascription
  // — never overwrite it with the declaration's return type.
  if (functionLiteralReturnType(literal) !== undefined) return literal;
  if (functionLiteralDeclaredEffects(literal) !== undefined) return literal;

  // Only ascribe when the inferred body result would otherwise fail the
  // covariant check (e.g. inferred `number` vs declared `integer`). When it
  // already satisfies the declaration (e.g. declared `any`), leave the literal
  // untouched so the stored value is unchanged.
  const inferredResult = functionResult(literal.type.type);
  if (
    inferredResult !== undefined &&
    ce.type(inferredResult).matches(ce.type(declaredResult))
  )
    return literal;

  // Rebuild via the Phase-1 authoring form: wrap the body in a `Typed`
  // ascription and re-box so canonicalization normalizes it (§4.2 — the marker
  // moves inside the Block, wrapping the last statement). `returnTypeText`
  // keeps a signature RESULT grouped, so the marker cannot re-read as the
  // literal's own contract (`functionLiteralDeclaredSignature`). The literal
  // is built in the scope where it was defined (`reboxFunctionLiteral`).
  const rebuilt = reboxFunctionLiteral(ce, literal, [
    [
      'Typed',
      rawBodyForRebox(ce, literal.ops[0]),
      `'${returnTypeText(declaredResult)}'`,
    ],
    ...literal.ops.slice(1).map((p) => p.json),
  ]);
  return isFunction(rebuilt, 'Function') ? rebuilt : literal;
}

/**
 * §6.3 declared-signature reconciliation, PARAMETER half — the mirror of
 * {@link reconcileFunctionLiteralReturn}, which ascribes only the result.
 *
 * The declaration is authoritative for parameters for the same reason it is for
 * the return type, and without this the two halves of a compiled call disagreed
 * about what a parameter IS. `declare L : (list<real>) -> list<real>` with
 * `L(a) := a + 1` stored a literal typing `(unknown) -> list<real>` — the result
 * ascribed, the parameter dropped — so the parameter fell back to usage
 * inference, which reads `a + 1` as scalar arithmetic and infers `number`. The
 * CALL SITE then read the DECLARED signature (`userFunctionParamsAreScalar`),
 * saw a collection parameter and passed the list WHOLE, while the emitted BODY
 * had been compiled as scalar code: `_fn_L([3, 4])` evaluated `[3,4] + 1` and
 * returned the string `"3,41"` behind `success: true`, where a caller reading
 * the result as a number gets nonsense. `|a|` degraded to `NaN` the same
 * way. Ascribing the parameters makes the literal self-describing, and both
 * halves then read the same type (Tycho item 116).
 *
 * The multi-clause route calls this too, with `includeScalar` — see that option
 * below. The concern that once kept this function off that route entirely (that
 * stamping the general signature's parameter types onto a clause would make
 * `assertClauseFitsDeclared` vacuous) is answered by the skips: an ANNOTATED
 * parameter is never stamped, so every clause that actually narrows is still
 * checked positionally. Only a BARE parameter is stamped, and a bare parameter
 * narrows nothing — its arm is the declared parameter, so there was nothing for
 * the check to verify in the first place.
 *
 * Skips, each leaving the literal untouched: an author-annotated parameter (the
 * author's ascription always wins, as it does for the return type), a
 * non-symbol parameter operand (nothing to annotate — a literal clause pattern
 * such as `f(0)` lands here), a parameter whose declared type mentions a
 * quantified variable (§2.4/G4 — nothing ground to ascribe), and
 * `unknown`/`any`, which state nothing and would merely flip the literal to
 * "annotated".
 *
 * `includeScalar` stamps SCALAR declared types as well. Off by default because
 * the disagreement this function was written for (Tycho item 116) is
 * `paramsAreScalar`-shaped — only a parameter that binds a collection WHOLE can
 * be handed a value the scalar-compiled body cannot read — and because stamping
 * a scalar is not inert: it re-canonicalizes the body against a narrower
 * parameter, which changed how a tuple argument broadcasts through `x ↦ 2x`.
 * The clause route turns it ON because there the body TYPE is the point: under
 * `let fact: (integer) -> integer`, `fact(n) = n * fact(n - 1)` types `n` as
 * `unknown` without it, so `n - 1` widens to `number` and the recursive
 * self-call violates the very declaration that was written to make it check.
 * That is the declare-then-define shape §4.3a calls the prescribed form for a
 * recursive definition, so it has to work with bare parameters.
 */
export function ascribeDeclaredParameterTypes(
  ce: IComputeEngine,
  literal: Expression,
  declaredType: Type,
  options?: { includeScalar?: boolean }
): Expression {
  if (!isFunction(literal, 'Function')) return literal;
  if (typeof declaredType !== 'object' || declaredType.kind !== 'signature')
    return literal;
  // A polytype ascribes its whole clause through `ascribeDeclaredPolytype`.
  if (isPolymorphicType(declaredType)) return literal;

  const args = declaredType.args;
  if (args === undefined || args.length === 0) return literal;
  // An optional signature is not a valid declaration for any literal —
  // `assertFunctionLiteralArity` rejects it upstream. Bail rather than
  // mis-align a positional ascription.
  if ((declaredType.optArgs?.length ?? 0) > 0) return literal;

  const params = literal.ops.slice(1);
  // A declared VARIADIC tail pairs with the literal's REST parameter and with
  // nothing else: the two must be present together, and the positional
  // `args` then align with the FIXED parameters before the rest parameter.
  // The rest parameter itself is never ascribed — it takes no annotation, and
  // its argument type is the tail's, not one slot's.
  const restAt = restParameterIndex(params);
  const declarationIsVariadic = declaredType.variadicArg !== undefined;
  const literalIsVariadic = restAt >= 0;
  if (declarationIsVariadic !== literalIsVariadic) return literal;
  const fixedCount = restAt < 0 ? params.length : restAt;
  if (fixedCount !== args.length) return literal;

  let changed = false;
  const rebuilt = params.map((p, i) => {
    if (i >= fixedCount) return p.json;
    if (isFunction(p, 'Typed')) return p.json;
    if (!isSymbol(p)) return p.json;
    const t = args[i].type;
    if (t === 'unknown' || t === 'any') return p.json;
    if (mentionsQuantifiedVariable(t, declaredType)) return p.json;
    // Only a NON-SCALAR parameter is ascribed, unless the caller asks for
    // scalars too. The disagreement this repairs is `paramsAreScalar`-shaped:
    // the call site consults the DECLARED type to decide whether to pass a
    // collection argument whole, so only a parameter that binds whole can be
    // handed a value the scalar-compiled body cannot read. Stamping a scalar
    // type buys nothing there and is not inert — it re-canonicalizes the body
    // against a narrower parameter, which changed how a tuple argument
    // broadcasts through `x ↦ 2x`. The clause route needs it anyway, because
    // there the body's TYPE is what a recursive self-call is checked against
    // (see `includeScalar` in this function's contract above).
    if (isScalarType(t) && options?.includeScalar !== true) return p.json;
    // `broadcastable<T>` is not a parameter type to stamp: it is a
    // DECLARATION-level contract with its own assignment enforcement (ratified
    // 2026-08-08, item 157), and ascribing it onto the literal made a
    // consuming body satisfy a broadcastable slot that must be rejected.
    if (typeof t === 'object' && t.kind === 'broadcastable') return p.json;
    changed = true;
    return ['Typed', p.json, `'${returnTypeText(t)}'`] as MathJsonExpression;
  });
  if (!changed) return literal;

  // Rebuild from JSON, so the body is canonicalized AFRESH with the ascribed
  // parameters in place — that re-binding is the entire point: the body's
  // parameter references have to pick up the declared type. Handing the
  // already-canonical body object through instead leaves them bound at
  // whatever the pre-ascription inference chose, and the emitted code stays
  // scalar. The literal is built in the scope where it was defined
  // (`reboxFunctionLiteral`).
  const rebuiltLiteral = reboxFunctionLiteral(ce, literal, [
    rawBodyForRebox(ce, literal.ops[0]),
    ...rebuilt,
  ]);
  if (!isFunction(rebuiltLiteral, 'Function')) return literal;

  // A fresh body object orphans the literal's PROVISIONAL reading — a
  // juxtaposition frozen as multiplication, or a forward-referenced call —
  // which is recorded in a WeakMap keyed on the literal and body OBJECTS
  // (`provisional-application.ts`). `canonicalFunctionLiteral` carries that
  // record across a re-canonicalization only when it is handed the same body
  // object, which the JSON round-trip defeats, so it is re-attached here.
  // Without it the definition never registered as a dependent and the
  // forward-reference repair silently stopped firing: `g := t ↦ 2a(t)`
  // declared before `a(t) := t²` answered `6a` instead of `18`.
  const provisional =
    provisionalLiteral(literal) ?? provisionalLiteral(literal.ops[0]);
  if (provisional !== undefined) {
    setProvisionalLiteral(rebuiltLiteral, provisional);
    if (rebuiltLiteral.ops[0] !== undefined)
      setProvisionalLiteral(rebuiltLiteral.ops[0], provisional);
  }
  return rebuiltLiteral;
}

/**
 * R1 — ascribe a DECLARED POLYTYPE onto a marker-less function literal, so the
 * stored value describes itself.
 *
 * `let f: (x: T) -> T where T = x => x` installed a literal whose own type
 * was the erased `(unknown) -> unknown`: the declaration's clause lived only on
 * the definition, so `f`'s VALUE (what `evaluate()` and serialization hand back)
 * had lost it. Rebuilding through the Phase-1 authoring form — the full
 * signature as the body-slot marker — makes `functionLiteralSignatureType`
 * carry the clause VERBATIM (`effects-inference.ts`, the `isGenericSignature`
 * arm), so the value and the definition agree.
 *
 * Returns `undefined` (leave the literal alone) unless every precondition
 * holds:
 * - the declaration is a single polytype signature the E2 pre-pass accepts as a
 *   marker (a plain signature — no optional or variadic arguments — with one
 *   argument per literal parameter);
 * - the literal carries NO marker of its own (no full-signature marker, no
 *   return ascription, no declared effects) and NO parameter annotation;
 * - EVERY argument of the declaration mentions a quantified variable.
 *
 * Together those make the rebuild a pure DISPLAY fix. Erasure (G1) has nothing
 * to erase (every quantified parameter is already bare), the G9 α-agreement
 * check is trivially satisfied (the marker IS the declared type), and the
 * §2.4-rule-4 annotation-coverage check has no annotation to reject. A literal
 * that DOES carry its own marker already went through those checks and keeps
 * it.
 *
 * The last condition is not cosmetic. A GROUND argument in the clause
 * (`(x: T, n: number) -> T where T`) would become a real constraint on the
 * literal's OWN arrow, and that arrow is enforced at every direct application
 * of the stored value — notably the per-element `apply()` inside a broadcast,
 * where `n` legitimately receives a whole row. Ascribing it there turns a
 * working broadcast into `incompatible-type`. Restricting the ascription to
 * clauses whose arguments are all quantified means it can only ever RECORD the
 * `where` clause, never tighten a parameter.
 *
 * Ground declarations are deliberately out of scope: their parameter types are
 * dropped from the stored literal's arrow too (`(x) => x` under
 * `(x: integer) -> integer` types `(unknown) -> integer`), but that asymmetry
 * predates this milestone and has a far larger surface.
 */
function ascribeDeclaredPolytype(
  ce: IComputeEngine,
  literal: Expression,
  declaredType: Type
): Expression | undefined {
  if (!isFunction(literal, 'Function')) return undefined;
  if (typeof declaredType !== 'object' || declaredType.kind !== 'signature')
    return undefined;
  if ((declaredType.typeParams?.length ?? 0) === 0) return undefined;
  if (
    declaredType.optArgs !== undefined ||
    declaredType.variadicArg !== undefined
  )
    return undefined;
  if ((declaredType.args?.length ?? 0) !== literal.nops - 1) return undefined;
  if (
    !(declaredType.args ?? []).every((a) =>
      mentionsQuantifiedVariable(a.type, declaredType)
    )
  )
    return undefined;

  // Already self-describing (or carrying an author ascription we must not
  // overwrite).
  if (functionLiteralDeclaredSignature(literal) !== undefined) return undefined;
  if (functionLiteralReturnType(literal) !== undefined) return undefined;
  if (functionLiteralDeclaredEffects(literal) !== undefined) return undefined;
  if (functionLiteralParameters(literal).some((p) => p.type !== undefined))
    return undefined;

  // As in `reconcileFunctionLiteralReturn` above, and under the same constraint
  // as `desugarSignatureString`: the serialized type goes straight back into
  // `canonicalFunctionLiteralArguments`, which re-parses it with the resolver,
  // so a declared type name stays resolved. The literal is built in the scope
  // where it was defined (`reboxFunctionLiteral`), and the resolver gives the
  // same type there as in this scope.
  const rebuilt = reboxFunctionLiteral(ce, literal, [
    ['Typed', literal.ops[0].json, `'${typeToString(declaredType)}'`],
    ...literal.ops.slice(1).map((p) => p.json),
  ]);
  return isFunction(rebuilt, 'Function') ? rebuilt : undefined;
}
