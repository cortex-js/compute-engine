import type { OneOf } from '../common/one-of.js';
import type {
  EffectLabel,
  EffectSet,
  ParameterDefault,
  Type,
  TypeResolver,
  TypeString,
} from '../common/type/types.js';
import type { BoxedType } from '../common/type/boxed-type.js';
import type { LatexString } from './latex-syntax/types.js';
import type { MathJsonExpression } from '../math-json/types.js';
import type {
  ComputeEngine,
  Expression,
  ExpressionInput,
  OperatorCompileHandler,
  OperatorCompileContext,
} from './types-expression.js';
import type {
  EvaluateOptions as KernelEvaluateOptions,
  ExplainVerbosity,
  Rule as KernelRule,
  BoxedRule as KernelBoxedRule,
  BoxedRuleSet as KernelBoxedRuleSet,
  Scope as KernelScope,
} from './types-kernel-evaluation.js';
import type { EffectHandlers } from './types-effects.js';

// `ComputeEngine` (imported above) is the engine surface of the definition
// callbacks: an interface declared in `types-expression.ts` and augmented by
// `types-engine.ts` with the members of `IComputeEngine`.

type EvaluateOptions = KernelEvaluateOptions;

/**
 * The `options` argument passed to an `evaluate` / `evaluateAsync` handler.
 *
 * @category Definitions
 */
export type EvaluateHandlerOptions = Partial<EvaluateOptions> & {
  engine: ComputeEngine;

  /**
   * The canonical expression node being evaluated.
   *
   * Its `ops` are the **raw** operands: canonical and bound, but
   * **pre-numericization** — the same objects the `type` handler sees. The
   * handler's first parameter, by contrast, holds the *evaluated* operands,
   * which under `numericApproximation` have already been turned into floats.
   *
   * That makes this the handler's only access to the operands' exactness. For
   * example `Power` reads the exact rational `p/q` of its exponent from
   * `expression.op2` to decide the branch of a negative base — under `.N()`
   * the exponent it receives as an operand is a double, from which `p/q`
   * can only be guessed.
   *
   * **`expression.ops[i]` is NOT in general the provenance of `ops[i]`.** The
   * evaluated operands come from `holdMap`, which reindexes them: it FLATTENS
   * an associative operator (`f(a, f(b, c))` arrives as three operands, one
   * more than the node has), it UNWRAPS `ReleaseHold` (so `expression.ops[i]`
   * is the wrapper, not what was evaluated), and it DROPS an operand whose
   * evaluation yields nothing. The correspondence holds only for a
   * non-associative operator with no `ReleaseHold` and no dropped operand — so
   * a handler that indexes into `expression.ops` must treat
   * `expression.ops.length !== ops.length` as "no provenance" and fall back to
   * what it can compute from the evaluated operands alone.
   *
   * **On a `lazy: true` operator there is no contrast to draw**: `holdMap`
   * returns the operands unchanged, so the handler's first parameter is raw
   * and held too — and, on the box/parse routes, not even canonicalized (see
   * the lazy-operator trap in `ARCHITECTURE.md`: such a handler must canonicalize
   * each held operand it consumes).
   *
   * Read-only: do not mutate it, and do not assume it is present (a handler
   * invoked outside the evaluation driver may not receive one).
   */
  expression?: Expression;

  /**
   * The number of significant digits the caller asked for, when
   * `numericApproximation` is `true`. `undefined` when
   * `numericApproximation` is `false`: an exact evaluation has no precision.
   *
   * - Inside `N(x, p)`, it is `p` for the evaluation of `x` and of every
   *   expression evaluated inside it, also when `p` is lower than the
   *   precision of the engine (then `N` computes at the precision of the
   *   engine and rounds the result to `p` digits).
   * - Otherwise (`x.N()`, `N(x)`, `evaluate({ numericApproximation: true })`)
   *   it is `ce.precision`, the precision of the engine.
   *
   * A handler can use it to compute to the requested number of digits
   * without reading `ce.precision`. `N(x, p)` with a `p` greater than the
   * precision of the engine computes at `p` digits plus guard digits for the
   * time of the call and restores the precision of the engine after it; on
   * the asynchronous route the raised precision travels with the evaluation
   * (`EvaluateOptions._precisionWindow`).
   */
  precision?: number;

  /**
   * The host capabilities of THIS evaluation: the `ce.effects` registry as it
   * was when the evaluation started. A handler that reaches a host capability
   * reads it from here, never from `ce.effects`, so that a change of registry
   * made while the evaluation runs — or made for a different, concurrent
   * asynchronous evaluation — has no effect on it.
   *
   * A handler may use a capability only if its operator declares the
   * corresponding effect label: `options.effects.console` requires `console`
   * in the signature. A `null` handler is a denial: return
   * `ce.error(['capability-denied', '<capability>'])`.
   */
  effects: EffectHandlers;
};

type Rule = KernelRule<Expression, ExpressionInput, ComputeEngine>;
type BoxedRule = KernelBoxedRule<Expression, ComputeEngine>;
type BoxedRuleSet = KernelBoxedRuleSet<Expression, ComputeEngine>;
type Scope = KernelScope<BoxedDefinition>;

/**
 * A bound symbol (i.e. one with an associated definition) has either a type
 * (e.g. ∀ x ∈ ℝ), a value (x = 5) or both (π: value = 3.14... type = 'real').
 *
 * @category Definitions
 */
export type ValueDefinition = BaseDefinition & {
  holdUntil: 'never' | 'evaluate' | 'N';

  type: Type | TypeString | BoxedType;

  /** If true, the type is inferred, and could be adjusted later
   * as more information becomes available or if the symbol is explicitly
   * declared.
   */
  inferred: boolean;

  /** Annotation provenance on the EFFECTS axis of a function-typed
   * declaration (`docs/EFFECTS-MODEL.md`, "Annotation provenance") — the
   * effects-axis analog of `inferred`.
   *
   * True when the author STATED the arrow's effects: a non-empty specifier
   * (`(number) scope -> number`), or the `pure` keyword — which denotes the
   * same empty set a bare arrow does, so the type alone cannot tell them
   * apart. A bare arrow leaves effects on the inferred track: assigning a
   * body re-stamps them freely. A stated set is a CONTRACT: every assigned
   * body must satisfy `inferred ⊆ declared`.
   *
   * Set by `ce.declare()` from the parsed declaration; not normally written
   * by hand.
   */
  effectsDeclared: boolean;

  /** `value` can be a JS function since for some constants, such as
   * `Pi`, the actual value depends on the `precision` setting of the
   * `ComputeEngine` and possible other environment settings */
  value:
    LatexString | ExpressionInput | ((ce: ComputeEngine) => Expression | null);

  /** The raw MathJSON body of a macro: `ce.declare('A', { macro: body })`.
   *
   * A macro has no value and the type `unknown`. A name of the input
   * (MathJSON or LaTeX) that resolves to the macro where it is boxed in a
   * canonical or a structural form is replaced by the body, boxed at that
   * place, in the scope of the occurrence and in the same form. A position
   * that takes a name (a parameter, an index, the variable of `D`, the
   * target of `Assign`) is not an occurrence, and a symbol made with
   * `ce.symbol()` is not expanded. A parameter, an index or a local of the
   * same name hides the macro.
   *
   * A definition with `macro` takes no other field.
   */
  macro: MathJsonExpression;

  eq: (a: Expression) => boolean | undefined;
  neq: (a: Expression) => boolean | undefined;
  cmp: (a: Expression) => '=' | '>' | '<' | undefined;

  collection: CollectionHandlers;

  /**
   * Custom evaluation handler for subscripted expressions of this symbol.
   * Called when evaluating `Subscript(symbol, index)`.
   *
   * @param subscript - The subscript expression (already evaluated)
   * @param options - Contains the compute engine and evaluation options
   * @returns The evaluated result, or `undefined` to fall back to symbolic form
   */
  subscriptEvaluate?: (
    subscript: Expression,
    options: { engine: ComputeEngine; numericApproximation?: boolean }
  ) => Expression | undefined;
};

/**
 * Definition for a sequence declared with `ce.declareSequence()`.
 *
 * A sequence is defined by base cases and a recurrence relation.
 *
 * @example
 * ```typescript
 * // Fibonacci sequence
 * ce.declareSequence('F', {
 *   base: { 0: 0, 1: 1 },
 *   recurrence: 'F_{n-1} + F_{n-2}',
 * });
 * ce.parse('F_{10}').evaluate();  // → 55
 * ```
 *
 * @category Definitions
 */
export interface SequenceDefinition {
  /**
   * Index variable name for single-index sequences, default 'n'.
   * For multi-index sequences, use `variables` instead.
   */
  variable?: string;

  /**
   * Index variable names for multi-index sequences.
   * Example: `['n', 'k']` for Pascal's triangle `P\_{n,k}`
   *
   * If provided, this takes precedence over `variable`.
   */
  variables?: string[];

  /**
   * Base cases as index → value mapping.
   *
   * For single-index sequences, use numeric keys:
   * ```typescript
   * base: { 0: 0, 1: 1 }  // F_0 = 0, F_1 = 1
   * ```
   *
   * For multi-index sequences, use comma-separated string keys:
   * ```typescript
   * base: {
   *   '0,0': 1,    // Exact: P_{0,0} = 1
   *   'n,0': 1,    // Pattern: P_{n,0} = 1 for all n
   *   'n,n': 1,    // Pattern: P_{n,n} = 1 (diagonal)
   * }
   * ```
   *
   * Pattern keys use variable names to match any value. When the same
   * variable appears multiple times (e.g., 'n,n'), the indices must be equal.
   */
  base: Record<number | string, number | Expression>;

  /** Recurrence relation as LaTeX string or Expression */
  recurrence: string | Expression;

  /** Whether to memoize computed values (default: true) */
  memoize?: boolean;

  /**
   * Valid index domain constraints.
   *
   * For single-index sequences:
   * ```typescript
   * domain: { min: 0, max: 100 }
   * ```
   *
   * For multi-index sequences, use per-variable constraints:
   * ```typescript
   * domain: { n: { min: 0 }, k: { min: 0 } }
   * ```
   */
  domain?:
    | { min?: number; max?: number }
    | Record<string, { min?: number; max?: number }>;

  /**
   * Constraint expression for multi-index sequences.
   * The expression should evaluate to a boolean/numeric value.
   * If it evaluates to false or 0, the subscript is considered out of domain.
   *
   * Example: `'k <= n'` for Pascal's triangle (only valid when k ≤ n)
   */
  constraints?: string | Expression;
}

/**
 * Status of a sequence definition.
 * @category Definitions
 */
export interface SequenceStatus {
  /**
   * Status of the sequence:
   * - 'complete': Both base case(s) and recurrence defined
   * - 'pending': Waiting for base case(s) or recurrence
   * - 'not-a-sequence': Symbol is not a sequence
   */
  status: 'complete' | 'pending' | 'not-a-sequence';

  /** Whether at least one base case is defined */
  hasBase: boolean;

  /** Whether a recurrence relation is defined */
  hasRecurrence: boolean;

  /**
   * Keys of defined base cases.
   * For single-index: numeric indices (e.g., [0, 1])
   * For multi-index: string keys including patterns (e.g., ['0,0', 'n,0', 'n,n'])
   */
  baseIndices: (number | string)[];

  /** Index variable name if recurrence is defined (single-index) */
  variable?: string;

  /** Index variable names if recurrence is defined (multi-index) */
  variables?: string[];
}

/**
 * Information about a defined sequence for introspection.
 * @category Definitions
 */
export interface SequenceInfo {
  /** The sequence name */
  name: string;

  /** Index variable name for single-index sequences (e.g., `"n"`) */
  variable?: string;

  /** Index variable names for multi-index sequences (e.g., `["n", "k"]`) */
  variables?: string[];

  /**
   * Base case keys.
   * For single-index: numeric indices
   * For multi-index: string keys including patterns
   */
  baseIndices: (number | string)[];

  /** Whether memoization is enabled */
  memoize: boolean;

  /**
   * Domain constraints.
   * For single-index: `{ min?, max? }`
   * For multi-index: per-variable constraints
   */
  domain:
    | { min?: number; max?: number }
    | Record<string, { min?: number; max?: number }>;

  /** Number of cached values */
  cacheSize: number;

  /** Whether this is a multi-index sequence */
  isMultiIndex: boolean;
}

/**
 * Result from an OEIS lookup operation.
 * @category OEIS
 */
export interface OEISSequenceInfo {
  /** OEIS sequence ID (e.g., 'A000045') */
  id: string;

  /** Sequence name/description */
  name: string;

  /** First several terms of the sequence */
  terms: number[];

  /** Formula or recurrence (if available) — the first formula line */
  formula?: string;

  /** All free-text formula lines, as returned by OEIS (if available) */
  formulas?: string[];

  /** Comments about the sequence */
  comments?: string[];

  /** URL to the OEIS page */
  url: string;
}

/**
 * Options for OEIS operations.
 * @category OEIS
 */
export interface OEISOptions {
  /** Request timeout in milliseconds (default: 10000) */
  timeout?: number;

  /** Maximum number of results to return for lookups (default: 5) */
  maxResults?: number;
}

/**
 * An OEIS-attributed closed-form proposal produced by `ce.interpret()`.
 *
 * The `expression` has been *verified* to reproduce every extracted sample
 * exactly. Attribution (`id`, `name`, `url`, `formula`) is mandatory: OEIS data
 * is CC BY-NC, so a candidate must always carry a link back to its source.
 *
 * @category OEIS
 */
export interface OEISCandidate {
  /** The parsed and sample-verified closed-form expression. */
  expression: Expression;

  /** OEIS sequence ID (e.g., 'A000217'). */
  id: string;

  /** Sequence name/description. */
  name: string;

  /** URL to the OEIS page. */
  url: string;

  /** The free-text OEIS formula line the expression was parsed from. */
  formula: string;
}

/**
 * Result of `ce.interpret()`: the sync-recognized form of the input (the same
 * value the `Interpret` head returns), plus any OEIS-attributed candidates.
 *
 * @category OEIS
 */
export interface InterpretResult {
  /** The recognized expression, or the input unchanged when nothing fired. */
  expression: Expression;

  /** Verified, OEIS-attributed closed-form proposals (possibly empty). */
  candidates: OEISCandidate[];
}

/**
 * Definition record for a function.
 * @category Definitions
 *
 */
/**
 * A three-valued fact about an operand: `true` (provably yes), `false`
 * (provably no), `undefined` (not decidable from what the descriptor knows).
 *
 * @category Definitions
 */
export type Tri = boolean | undefined;

/**
 * The facts a `type` handler in the `'types'` shape may read about one
 * operand, beside the operand's type. Every fact is derived from pure
 * sources — the operand's type, a literal's value, a symbol's held value or
 * recorded assumptions, structural reads — never by canonicalizing,
 * declaring, or evaluating anything.
 *
 * The set is deliberately minimal: a fact earns a field only when the
 * operand's TYPE cannot carry it. Anything the type proves is read off
 * `OperandDescriptor.type` directly — an error operand's type IS `'error'`
 * (so there is no `valid` field), and a literal's value, sign, and
 * finiteness normally travel in its value-carrying type. Each field below
 * merges the type channel with the pure value channel, so a handler reads
 * ONE place and never re-derives the combination; the doc of each field
 * names the residue that justifies it.
 *
 * @category Definitions
 */
export type OperandFacts = {
  /** `true` for a `finite_*`-typed operand or a finite number literal;
   * `false` for an operand whose type is below `infinity` or `nan` — which
   * covers the signed pair `+oo | -oo`, the unsigned `~oo` and the
   * NaN marker — and for a `±∞`/`NaN` literal; `undefined` otherwise
   * (including every non-number operand). Treating a NaN operand as an
   * unknown-finiteness generic point would let a total-real-function
   * handler unsoundly claim a finite result for `f(NaN)`. */
  readonly finite: Tri;
  /** The operand's sign, from pure sources only: a number literal's value,
   * a symbol's held numeric value or recorded assumption, the sign a
   * ranged TYPE proves (`real<0..> & !0` is positive), or — for a function
   * application — its operator's `sgn` handler, a pure family by contract
   * (see `OperatorDefinition.sgn`; the audit behind the contract is
   * recorded at open item O7 of
   * `docs/plans/2026-08-22-type-handlers-on-types.md`).
   * Beyond the type: a held numeric value (`a := 5` keeps the declared
   * type `integer` — assigned symbols are checked, never narrowed), an
   * assumption whose bound no machine number represents (`assume(x > 1/3)`
   * records the sign but declines the range, leaving the type bare
   * `real`), and a compound proof through operand signs (`Divide`'s
   * handler recurses; `Sign(p)` with `assume(p > 0)` is positive). */
  readonly sgn?: Sign;
  /** The operand has no free variables (the `isConstant` structural fact —
   * never derivable from a type). */
  readonly closed: Tri;
  /** Is the operand a collection? `true` when its type proves it (a
   * collection-shaped type, `string` included) or the operand value is
   * enumerable; `false` when the type is provably disjoint from
   * `collection<any>`; `undefined` for top types and `broadcastable<T>`.
   * Beyond the type: per-instance collection capability (an operator whose
   * collection-ness is decided from its operands, or an enumerable value
   * whose type alone does not prove the shape). */
  readonly collection: Tri;
  /** Meaningful only when `collection` is not `false`. Beyond the type: a
   * value's enumerable-cardinality facet where the type carries no
   * dimensions. */
  readonly finiteCollection: Tri;
  /** Supports index-based access (`indexed_collection<any>` by type, or the
   * operand's indexed-collection capability). */
  readonly indexed: Tri;
  /** A statically known fixed shape (a dimensioned list type's dimensions).
   * Absent when no static shape is known. A computed convenience — today
   * derived from the type alone, kept as a field because the matrix-family
   * handlers read it constantly and a literal-`List` channel can join it
   * later. */
  readonly shape?: readonly number[];
  /** The element type the operand's own collection handler proves for THIS
   * instance (the `elttype` handler of its operator's `collection`
   * definition), when the operator has one and it answers. This is the
   * per-instance channel the type cannot carry: a `Range` whose endpoints
   * are all integers has `integer` elements while its static type says
   * only `real`. Absent when the operand is not an application of an
   * operator with such a handler, or the handler declines; a consumer then
   * reads the element type the TYPE proves (`collectionElementType`). */
  readonly elementType?: Type;
};

/**
 * An inert, expression-free structural view of an operand, for `type`
 * handlers in the `'types'` shape that need more than the operand's type
 * (is it a symbol? a string literal? an application of which operator?).
 * Children appear as descriptors, so a handler can recurse without ever
 * holding an expression.
 *
 * @category Definitions
 */
export type OperandStructure =
  | {
      kind: 'symbol';
      name: string;
      /** False when resolving this name in the current engine context would
       * select a different binding, or when this is a synthetic bound symbol.
       * Type handlers must then use the descriptor's own type rather than
       * derive a call or read a declaration by name. */
      lookupByName?: false;
      /** Present (`true`) when the symbol resolves to the definition the
       * engine's SYSTEM scope binds under this name — the library constant
       * or operator, not a user or local declaration that shadows it. The
       * ring arms of `At` and `Subscript` read it: `Integers[k]` is a
       * quotient-ring adjunction only for the library `Integers`. */
      system?: boolean;
      /** Present (`true`) when the symbol's recorded type was INFERRED
       * (subject to revision) rather than declared — the fact the
       * `Multiply` and `List`-fold handlers consult when deciding how much
       * to trust an operand's type. Lives on the structure node, not in
       * `OperandFacts`: it is a property of this symbol, not of a type. */
      inferred?: boolean;
      /** Present (`true`) when the symbol is a block-local binding a `Block`
       * hoisted for a `let` or a block-introducing assignment, still waiting
       * for the statement that gives it a value. Such a local is not a
       * generic value, its type is simply not known yet: the handlers that
       * ask whether an operand may hold a list read it. */
      local?: boolean;
      /** Present (`true`) when the symbol is free: it has no value, it is
       * not a constant and not a pattern wildcard (a name
       * that starts with `_`), and a scope of the current context other
       * than the system scope binds it, but not as a parameter of a
       * function literal, a local of a `Block` or the variable of a binder
       * (a `Sum` index). The `List` type handler reads a symbol of type
       * `unknown` as a number cell only when this is present: these are the
       * symbols that the canonical form of a literal list infers as
       * numbers. */
      free?: true;
      /** Present (`true`) when the body of a function literal reads the
       * symbol, and the symbol has no value and is not a parameter of the
       * literal or a `let` local of the body (`isCapturedValuelessSymbol`).
       * When the body is evaluated, the symbol reads the value that an outer
       * scope holds at that time. A call of a function literal reads such a
       * symbol of type `unknown` as an operand that may hold a list. */
      captured?: true;
    }
  | { kind: 'string'; text: string }
  | {
      kind: 'number';
      /** The tier the literal contributes to a COMPOSITE type: `integer`,
       * `rational`, `real`, `complex`, `imaginary`, `nan`, `infinity`, or
       * the signed pair `+oo | -oo`. A literal's handler-visible type
       * (`type` on the descriptor) carries its value or an enclosing range;
       * a composite built from the literal — a tuple's component, a list's
       * element, a record's field — is a stored contract and carries the
       * tier instead, so a container handler reads it here and never
       * builds the literal type only to widen it away. Read off the value
       * (`numberLiteralTierType`, `boxed-expression/literal-tier.ts`). */
      tier: Type;
      literal?: 0 | 1;
      /** The literal's exact value as a REDUCED fraction, when it is a
       * rational with no radical part: `[numerator, denominator]`, the
       * denominator positive. A literal's handler-visible type carries only
       * an outward-rounded range for a rational no double represents
       * exactly, so a handler that needs the exact terms (the parity of a
       * power's exponent denominator decides real against complex) reads
       * them here. Absent for a float, a complex, a radical, or a
       * non-finite literal. */
      rational?: readonly [bigint, bigint];
    }
  | {
      kind: 'application';
      head: string;
      /** The callable's own contract when ambient lookup would select a
       * different binding. A held literal may also supply its body structure.
       * Derive this call through Apply rather than resolving head by name. */
      callee?: OperandDescriptor;
      children: ReadonlyArray<OperandDescriptor>;
    }
  | {
      kind: 'function-literal';
      /** One entry per parameter operand, in order. `rest` marks the REST
       * parameter (`(a, ...rest) => …`): it is always the last entry, it
       * takes no annotation, and it binds a tuple of every argument from its
       * own position onwards rather than occupying one positional slot. A
       * consumer reading arity must therefore treat the entries before it as
       * the required count and admit any number after. `optional` marks a
       * parameter with a default value (`(x, k = 2) => x * k`), and
       * `default` is that value: a call may leave the parameter out, and
       * the parameter then receives its default. The parameters with a
       * default come after the required ones. */
      parameters: ReadonlyArray<{
        name: string;
        annotated?: Type;
        rest?: boolean;
        optional?: boolean;
        default?: ParameterDefault;
      }>;
      body: OperandStructure;
    }
  | {
      kind: 'tuple';
      arity: number;
      /** One descriptor per component, in order. */
      elements: ReadonlyArray<OperandDescriptor>;
    }
  | {
      kind: 'list-literal';
      shape: readonly number[];
      /** One descriptor per top-level element, in order. A nested row is
       * itself a `list-literal` structure, reachable through its
       * descriptor's `structureOf()`. */
      elements: ReadonlyArray<OperandDescriptor>;
    };

/**
 * What a `type` handler in the `'types'` shape receives in place of an
 * operand expression: the operand's handler-visible type (a number
 * literal's value-carrying type included), a set of three-valued facts,
 * and an optional on-demand structural view. Descriptors carry no
 * expression, so a handler cannot canonicalize, declare, or evaluate its
 * operands while deriving a type — which is the point of the shape: type
 * derivation must not modify engine state.
 *
 * Built by `describe()` (from a real operand) and `describeType()` (from a
 * type alone) in `boxed-expression/operand-descriptor.ts`; the design is
 * `docs/plans/2026-08-22-type-handlers-on-types.md` §5.1.
 *
 * @category Definitions
 */
export type OperandDescriptor = {
  /** The operand's handler-visible type. For a number literal this is its
   * value-carrying type (`21`, `real<0.5..0.5>`); for an absent
   * operand at a missing-stripped parameter position, the operand's
   * `missing`-stripped type. */
  readonly type: Type;
  readonly facts: OperandFacts;
  /** A structural view of the operand, or `undefined` when no structural
   * facts are available (synthetic descriptors; structure kinds not yet in
   * the vocabulary). Pure and memoized; safe to call repeatedly. */
  readonly structureOf?: () => OperandStructure | undefined;
};

/**
 * The definition view a `'types'`-shape `type` handler gets from
 * `PureEngineView.lookupDefinition`: the tagged value/operator halves with
 * every own property readonly. The shallow `Readonly` is compile-time
 * protection against the direct field writes a type handler must never
 * perform (`def.operator.signature = …`); the runtime purity guard remains
 * the dynamic enforcement for anything the type system cannot see.
 *
 * @category Definitions
 */
export type ReadonlyDefinitionView = {
  readonly value?: Readonly<BoxedValueDefinition>;
  readonly operator?: Readonly<BoxedOperatorDefinition>;
};

/**
 * The read-only slice of the engine available to a `type` handler in the
 * `'types'` shape: enough to parse and resolve types, and to look up a
 * definition — none of the mutating surface (`declare`, `assign`, `box`,
 * `parse`, `evaluate`), and the definition lookup answers a read-only view
 * ({@link ReadonlyDefinitionView}). The full `ComputeEngine` satisfies this
 * interface structurally, so the restriction is compile-time only; the
 * runtime purity guard (`CE_TYPE_PURITY_GUARD`, always on under test) is
 * what enforces it dynamically.
 *
 * @category Definitions
 */
export interface PureEngineView {
  type(type: Type | TypeString | BoxedType): BoxedType;
  readonly _typeResolver: TypeResolver;
  lookupDefinition(id: string): ReadonlyDefinitionView | undefined;
  /** The engine's numeric tolerance, a read-only configuration value a
   * membership handler consults (`Element` declines rather than refute a
   * near-match inside it). */
  readonly tolerance: number;
  /** True when the engine checks the types of operands when it boxes an
   * expression (`ComputeEngine.strict`). A handler that answers `error` for
   * an operand that the boxing check refuses reads it, so that a non-strict
   * engine keeps the unevaluated application. */
  readonly strict: boolean;
  /** The protocol registry, keyed by protocol name. Its records are typed
   * opaquely here because the record type lives in `types-engine.ts`,
   * which imports this file; the protocol readers in `engine-protocols.ts`
   * (`protocolOfName`, `protocolMemberSignature`,
   * `protocolPropertyTypeOfReceiver`) take this view and know the records'
   * real shape. Read-only from a handler. */
  readonly _protocolRegistry: Readonly<Record<string, object>>;
}

/**
 * The context argument of a `type` handler in the `'types'` shape.
 *
 * `derive(operator, operands)` is the recursive entry point a handler needs
 * to type an application it does not have in hand — the body of a mapping
 * literal over the source's element type, say. It runs the named operator's
 * own `type` handler on the given descriptors, falling back to the declared
 * (instantiated) signature result, and reads nothing but definitions and
 * types (`deriveApplicationType`, `boxed-expression/derive-application-type.ts`).
 * It answers `undefined` for an unknown operator.
 *
 * @category Definitions
 */
export type TypeHandlerContext = {
  engine: PureEngineView;
  derive: (
    operator: string,
    operands: ReadonlyArray<OperandDescriptor>
  ) => Type | undefined;
};

/**
 * The `type` handler of an operator definition: a function of operand
 * DESCRIPTORS. Such a handler never sees an operand expression, so
 * deriving a type cannot declare, canonicalize, or evaluate anything — the
 * state-purity contract of
 * `docs/plans/2026-08-22-type-handlers-on-types.md`. Under test, and with
 * `CE_TYPE_PURITY_GUARD` set elsewhere, a handler that writes engine state
 * throws.
 * Return a `BoxedType` (for example `context.engine.type('real')`), or
 * `undefined` to use the declared signature. Numeric literal cargo in a
 * boxed result is widened at the application boundary; intentional ranges
 * remain intact. Built-ins use `BoxedType.forResult()` to share that work.
 *
 * @category Definitions
 */
export type OperatorTypeHandlerOnTypes = (
  operands: ReadonlyArray<OperandDescriptor>,
  context: TypeHandlerContext
) => BoxedType | undefined;

/**
 * A handler that gives one partial derivative of an operator.
 *
 * - `ops` are the arguments of the application being differentiated, for
 *   example `[x^2, y]` for `F(x^2, y)`. They are canonical, not evaluated.
 * - `options.argument` is the 0-based index of the argument with respect
 *   to which the partial derivative is requested.
 *
 * Return the partial derivative `∂F/∂(argument number options.argument)`
 * evaluated AT `ops`, for example `2·x^2` for the first partial of
 * `F(u, v) = u^2 + v` applied to `[x^2, y]`. Do not multiply by the
 * derivative of the argument: the chain rule is applied by the caller.
 *
 * Return `undefined` when the partial derivative is not known. That
 * partial then stays symbolic, as `Apply(Derivative(F, 1, 0), x^2, y)`.
 *
 * Do not call `.simplify()` on the result: the derivative is computed
 * inside the simplification of other expressions, and calling `.simplify()`
 * there can recurse without end.
 *
 * @category Definitions
 */
export type OperatorDerivativeHandler = (
  ops: ReadonlyArray<Expression>,
  options: { engine: ComputeEngine; argument: number }
) => Expression | undefined;

/**
 * The value of the `derivative` key of an operator definition. It has one
 * of two forms:
 *
 * 1. **An array with one entry for each argument**. Entry `i` is a function
 *    literal (`["Function", body, ...parameters]`, as MathJSON or as an
 *    expression) with one parameter for each argument of the operator. It
 *    gives the partial derivative with respect to argument `i`, as a
 *    function of all the arguments. For `F(x, y) = x^2·y`:
 *
 *    ```ts
 *    derivative: [
 *      ['Function', ['Multiply', 2, 'x', 'y'], 'x', 'y'],  // ∂F/∂x
 *      ['Function', ['Power', 'x', 2], 'x', 'y'],           // ∂F/∂y
 *    ]
 *    ```
 *
 *    The array is used only for an application with as many arguments as
 *    the array has entries, and an entry is used only if its literal has
 *    one parameter for each argument. In any other case the partial
 *    derivatives stay symbolic.
 *
 * 2. **A handler**, see {@link OperatorDerivativeHandler}. Use it when the
 *    number of arguments varies, or when a partial derivative needs code.
 *
 * In both forms the derivative of `F(g₁, …, gₙ)` with respect to `v` is
 * given by the chain rule: `Σᵢ ∂ᵢF(g₁, …, gₙ) · ∂gᵢ/∂v`. A partial
 * derivative is requested only for an argument that depends on `v`.
 *
 * For an argument that is a point (a tuple or a list of tuples), the
 * product `∂ᵢF · ∂gᵢ/∂v` multiplies each coordinate. It is correct only
 * when the partial derivative is a number `c` (the Jacobian is `c·I`). When
 * the partial derivative is a point (a gradient) or is not given, the
 * derivative of the application stays unevaluated.
 *
 * @category Definitions
 */
export type OperatorDerivative =
  ReadonlyArray<ExpressionInput | Expression> | OperatorDerivativeHandler;

export type OperatorDefinition = Partial<BaseDefinition> &
  Partial<OperatorDefinitionFlags> & {
    /**
     * The type of the result (return type) as a function of the operand
     * DESCRIPTORS — their types, facts and structure, never the operand
     * expressions. See {@link OperatorTypeHandlerOnTypes}.
     *
     * Should be a subtype of the type indicated by the signature: for a
     * signature `(number) -> real` the result may be `real` or `integer`,
     * never `complex`.
     */
    type?: OperatorTypeHandlerOnTypes;

    /**
     * The function signature, describing the type of the arguments and the
     * return type.
     *
     * If a `type` handler is provided, the return type of the function should
     * be a subtype of the return type in the signature.
     *
     * **Default values.** An optional parameter can have a default value,
     * written after its type: `(x: number, factor: number = 2) -> number`.
     * A parameter with a default is optional (it is not also marked `?`).
     * The parameters with a default come after the required parameters and
     * before the optional parameters without a default.
     *
     * A default is a number (a finite number, `NaN`, `+oo` or `-oo`), a
     * string, `true` or `false`, a symbol, the empty list `[]` or the empty
     * dictionary `{}`. A symbol default is the symbol itself, not its value
     * when the operator is declared: `over: set = Integers`,
     * `mode: symbol<Auto> | symbol<Manual> = Auto`. The symbol need not be
     * declared. For another value, declare a constant and give its name.
     *
     * When the operator is declared, each default is checked against the
     * type of its parameter, and the declaration throws if it does not fit:
     * a number, a string, a boolean, `[]` or `{}` must match the type, a
     * declared symbol must be a valid argument at that parameter, and for a
     * parameter typed with literal symbol types the symbol must be one of
     * them. A default is refused in an overloaded signature (an intersection
     * of signatures), on a parameter whose type mentions a type variable, and
     * anywhere other than the parameters of the top-level signature (for
     * example in the type of a parameter that is itself a function).
     *
     * A call that leaves out a parameter with a default receives the default
     * when it is canonicalized: `Scaled(3)` is the same expression as
     * `Scaled(3, 2)`, and the `evaluate` handler, the `type` handler and the
     * compiler see two operands. The default is inserted only when every
     * required parameter has an argument. The signature prints the default.
     *
     */
    signature?: Type | TypeString | BoxedType;

    /**
     * If `true`, the `signature` is a starting point to be refined, not a
     * contract: assigning a function literal to this operator narrows the
     * signature from the literal's body, and calls type from the narrowed
     * signature.
     *
     * Declaring a `signature` normally pins it (`inferredSignature: false`),
     * which is what you want for a fixed API. Set this to `true` to vouch
     * that a name is an operator — so `f(x)` parses as an application rather
     * than a multiplication — while leaving its types to be inferred from the
     * body assigned later:
     *
     * ```js
     * ce.declare('q', { signature: '(unknown) -> unknown', inferredSignature: true });
     * ce.assign('q', ce.parse('t \\mapsto 2t+1'));
     * // signature is now `(unknown) -> number`, so `q(x) < y` types
     * // `boolean` and compiles, while `q(L) < y` over a list `L` still types
     * // `list<boolean>` and fails closed.
     * ```
     *
     * A declaration that omits `signature` entirely behaves the same way.
     */
    inferredSignature?: boolean;

    /**
     * The `signature` was DERIVED from an annotated function literal at
     * `ce.assign()` time, not written by the author as a declaration.
     *
     * Such a signature is pinned (`inferredSignature: false`) so that calls
     * validate the annotated parameter types — but it is not a contract on the
     * NAME: a later untyped `ce.assign()` full-replaces it and re-infers from
     * the new literal (D6, "Assign always full-replaces"). A signature that
     * came from `ce.declare()` is sticky and keeps constraining every
     * re-assign.
     *
     * @internal
     */
    _derivedSignature?: boolean;

    /** The signature the ARGUMENTS of a call are validated against, when it
     * differs from `signature`. Set for a function literal that annotates
     * some of its parameters and leaves others bare (`(p, acc: list<number>)
     * ↦ …`): the annotated slots are the author's contract and keep their
     * types, and each bare slot, whose type in `signature` was only inferred
     * from the uses in the body, admits any argument (`any`), exactly as
     * every slot does when nothing is annotated (user decision 2026-09-30).
     * Before, one annotation made the whole derived signature a contract,
     * so an inferred slot refused an argument the interpreter accepts (a
     * `first(…)` result typed `missing | tuple<…>` at a slot inferred
     * `indexed_collection<number>`). `signature` itself is unchanged: it is
     * what the definition reports, what result typing reads and what
     * decides broadcasting. `undefined` for every other definition.
     *
     * @internal
     */
    _validationSignature?: Type;

    /** Return the sign of the function expression.
     *
     * If the sign cannot be determined, return `undefined`.
     *
     * When determining the sign, only literal values and the values of
     * symbols, if they are literals, should be considered.
     *
     * Do not evaluate the arguments.
     *
     * However, the type and sign of the arguments can be used to determine the
     * sign.
     *
     * The handler must be a pure function of the operands — the type path
     * dispatches it while deriving an application's type. See the purity
     * contract on `OperatorDefinition.sgn`.
     */
    sgn?: (
      ops: ReadonlyArray<Expression>,
      options: { engine: ComputeEngine }
    ) => Sign | undefined;

    /** The value of this expression is > 0, same as `isGreater(0)`
     *
     * @category Numeric Expression
     */
    readonly isPositive?: boolean | undefined;

    /** The value of this expression is >= 0, same as `isGreaterEqual(0)`
     *
     * @category Numeric Expression
     */
    readonly isNonNegative?: boolean | undefined;

    /** The value of this expression is &lt; 0, same as `isLess(0)`
     *
     * @category Numeric Expression
     */
    readonly isNegative?: boolean | undefined;

    /** The  value of this expression is &lt;= 0, same as `isLessEqual(0)`
     *
     * @category Numeric Expression
     */
    readonly isNonPositive?: boolean | undefined;

    /** Return `true` if the function expression is even, `false` if it is odd
     * and `undefined` if it is neither (for example if it is not a number,
     * or if it is a complex number).
     */
    even?: (
      ops: ReadonlyArray<Expression>,
      options: { engine: ComputeEngine }
    ) => boolean | undefined;

    /**
     * A number used to order arguments.
     *
     * Argument with higher complexity are placed after arguments with
     * lower complexity when ordered canonically in commutative functions.
     *
     * - Additive functions: 1000-1999
     * - Multiplicative functions: 2000-2999
     * - Root and power functions: 3000-3999
     * - Log functions: 4000-4999
     * - Trigonometric functions: 5000-5999
     * - Hypertrigonometric functions: 6000-6999
     * - Special functions (factorial, Gamma, ...): 7000-7999
     * - Collections: 8000-8999
     * - Inert and styling:  9000-9999
     * - Logic: 10000-10999
     * - Relational: 11000-11999
     *
     * **Default**: 100,000
     */
    complexity?: number;

    /**
     * Return the canonical form of the expression with the arguments `args`.
     *
     * The arguments (`args`) may not be in canonical form. If necessary, they
     * can be put in canonical form.
     *
     * This handler should validate the type and number of the arguments
     * (arity).
     *
     * If a required argument is missing, it should be indicated with a
     * `["Error", "'missing"]` expression. If more arguments than expected
     * are present, this should be indicated with an
     * `["Error", "'unexpected-argument'"]` error expression
     *
     * If the type of an argument is not compatible, it should be indicated
     * with an `incompatible-type` error.
     *
     * `["Sequence"]` expressions are not folded and need to be handled
     *  explicitly.
     *
     * If the function is associative, idempotent or an involution,
     * this handler should account for it. Notably, if it is commutative, the
     * arguments should be sorted in canonical order.
     *
     *
     * Values of symbols should not be substituted, unless they have
     * a `holdUntil` attribute of `"never"`.
     *
     * The handler should not consider the value or any assumptions about any
     * of the arguments that are symbols or functions (i.e. `arg.is(0)`,
     * `arg.isInteger`, etc...) since those may change over time.
     *
     * The result of the handler should be a canonical expression.
     *
     * If the arguments do not match, they should be replaced with an
     * appropriate `["Error"]` expression. If the expression cannot be put in
     * canonical form, the handler should return `null`.
     *
     */
    canonical?: (
      ops: ReadonlyArray<Expression>,
      options: { engine: ComputeEngine; scope: Scope | undefined }
    ) => Expression | null;

    /**
     * Evaluate a function expression.
     *
     * When the handler is invoked, the arguments have been evaluated, except
     * if the `lazy` option is set to `true`.
     *
     * It is not necessary to further simplify or evaluate the arguments.
     *
     * If performing numerical calculations and `options.numericalApproximation`
     * is `false` return an exact numeric value, for example return a rational
     * number or a square root, rather than a floating point approximation.
     * Use `ce.number()` to create the numeric value.
     *
     * If the expression cannot be evaluated, due to the values, types, or
     * assumptions about its arguments, return `undefined` or
     * an `["Error"]` expression.
     *
     * The handler must not evaluate an expression that contains the call
     * that it evaluates, for example an expression that the host code keeps
     * in a variable. The engine does not detect this, and the result is not
     * specified. Under `evaluateAsync()` the promise of the outer evaluation
     * can never settle (see `evaluateAsync`).
     */
    evaluate?:
      | ((
          ops: ReadonlyArray<Expression>,
          options: EvaluateHandlerOptions
        ) => Expression | undefined)
      | Expression;

    /**
     * An asynchronous version of `evaluate`.
     *
     * A handler that evaluates an operand with `evaluateAsync` passes its
     * own `options` on (`x.evaluateAsync(options)`, or a copy that keeps the
     * `_effects`, `_contextStack` and `_precisionWindow` fields): they carry
     * the state of the evaluation across the handler's `await`s, among which
     * the precision window of an enclosing `N(x, p)` call. An operand
     * evaluation started with options of the handler's own inherits the
     * window in force when it starts, but a handler that awaits BEFORE it
     * evaluates its operand starts that evaluation outside the window.
     *
     * The handler must not evaluate an expression that contains the call
     * that it evaluates. If it does, the promise of the outer evaluation can
     * never settle. For example, with `g` a host operator whose handler is
     * `async () => { await node.evaluateAsync(); return ce.number(5); }`
     * and `node` the expression `Reverse(List(1, g()))`, the call
     * `node.evaluateAsync()` never settles. When `g` is declared `pure`, the
     * nested call waits for the evaluation of `node` that is in progress,
     * and that evaluation waits for the handler. Otherwise, each nested call
     * starts a new evaluation of `node`, which calls the handler again,
     * without end. The engine does not detect either case.
     */
    evaluateAsync?: (
      ops: ReadonlyArray<Expression>,
      options: EvaluateHandlerOptions
    ) => Promise<Expression | undefined>;

    /** Dimensional analysis
     * @experimental
     */
    evalDimension?: (
      args: ReadonlyArray<Expression>,
      options: Partial<EvaluateOptions> & { engine: ComputeEngine }
    ) => Expression;

    /**
     * The partial derivatives of this operator, used by `D`, `Derivative`
     * and the prime notation (`f'(x)`). See {@link OperatorDerivative} for
     * the two accepted forms.
     *
     * Without this key, the derivative of an application of an operator
     * whose `evaluate` handler does not give a formula stays symbolic:
     * `D(Sq(x), x)` is `Apply(Derivative(Sq, 1), x)`. With it, the
     * derivative is computed with the chain rule:
     *
     * ```ts
     * ce.declare('Sq', {
     *   signature: '(number) -> number',
     *   evaluate: ([x]) => (isNumber(x) ? x.mul(x) : undefined),
     *   derivative: [['Function', ['Multiply', 2, 'x'], 'x']],
     * });
     * ce.parse('\\frac{d}{dx} \\operatorname{Sq}(x^2)').evaluate();
     * // ➔ 4x^3   (that is, Sq'(x^2) · 2x = 2x^2 · 2x)
     * ```
     *
     * When the definition also has an `evaluate` handler that is a function
     * literal, this key has precedence: the derivative is computed from
     * this key, not by differentiating the body of the literal.
     *
     * An operator of the standard library keeps its own derivative rule. A
     * definition that shadows a standard library name (a user definition
     * of `Sinh`, for example) is a different operator, and its `derivative`
     * key is used.
     */
    derivative?: OperatorDerivative;

    /**
     * A custom compilation handler for this operator: emit target-language
     * source for a call to this operator. Takes precedence over the target's
     * built-in operator/function mapping and its broadcast lowering, so it can
     * override how a built-in operator compiles (e.g. a custom-tolerance `GCD`,
     * or a re-mapped `Add`/`Multiply`/`Power`/relational operator).
     *
     * It does NOT override the structural / control-flow heads, which have
     * their own bespoke lowering: `Sequence`, `Sum`, `Product`, `Function`,
     * `Declare`, `Assign`, `Return`, `Break`, `Continue`, `Loop`,
     * `Comprehension`, `If`, `Match`, `Block`. A handler
     * declared on one of those heads is ignored.
     *
     * Exception: `Which` IS overridable (it has no binding structure — its
     * operands are plain condition/value pairs a handler can compile through
     * the callback it is given). To customize how `Which` compiles while
     * keeping its stock evaluation semantics, attach the handler to the
     * engine's own definition rather than re-declaring the operator (a
     * re-declaration replaces the stock `evaluate`/`canonical` handlers):
     *
     * ```ts
     * const def = ce.lookupDefinition('Which');
     * if (def && 'operator' in def) def.operator.compile = myWhichHandler;
     * ```
     *
     * The override is per-engine (each `ComputeEngine` builds its own
     * standard-library definitions), and the decline contract applies: a
     * handler returning `undefined` falls back to the built-in `Which`
     * lowering, coercion and frame-protocol wrapping included.
     *
     * **Attaching in place is the supported route for EVERY operator the
     * engine already defines, not only `Which`.** Three things follow from
     * re-declaring instead, and all three are silent:
     *
     * - A re-declaration REPLACES the stock `evaluate`/`canonical` handlers.
     *   Spreading the captured definition (`ce.declare(op, {...orig, compile})`)
     *   is an attempt to carry them across by hand and is not equivalent —
     *   attaching to the definition `lookupDefinition` returns keeps them by
     *   construction, with nothing to carry.
     * - A re-declaration also replaces the definition's EFFECTS declaration,
     *   and that is what decides whether a compiled `Sum`/`Product` over a
     *   body mentioning the operator keeps its NaN early exit — the
     *   `if (acc !== acc) return NaN;` emitted between terms, valid because
     *   NaN absorbs `+` and `*`, so once the accumulator is NaN no later
     *   term can change the answer. An operator definition is GRANTED
     *   purity, so a re-declaration that states no effects keeps the exit.
     *   One that states any effects refuses it, since skipping terms would
     *   skip the effects too — and the lever is the effect SET, not the
     *   `pure` keyword: `pure` is a derived reading of `effects`, so
     *   `effects: ['random']` or an effect-annotated signature loses the
     *   exit exactly as `pure: false` does, while `effects: []` keeps it
     *   exactly as an unspecified definition does. For this exit, carrying
     *   a `compile` handler costs nothing by itself, whether it supplies
     *   source or declines for the target at hand: the gate reads the
     *   definition's declared effects, not who supplied the code. The one
     *   shape it cannot catch is a handler emitting effectful source under
     *   a definition that states no effects.
     *
     *   The exit this governs is the one the scalar `Sum`/`Product`
     *   lowering emits through `BaseCompiler.isEmissionSkippable`. An
     *   element-wise (collection-valued) body carries a separate,
     *   UNCONDITIONAL latch of the same spelling, emitted so that a
     *   length mismatch collapsing the fold to a scalar NaN cannot be
     *   broadcast back over the next term's shape. That latch does not
     *   consult the declared effects, so declaring effects does not buy
     *   back the later iterations of an element-wise body.
     * - Call-sharing is the one cost a handler still pays for being on a
     *   re-declared definition, and the declared effects do not govern it. A
     *   `compile` handler the engine did not install is a live-source
     *   splice the CSE harvest cannot analyse, so every node under that
     *   head is refused as a candidate and every callee body mentioning it
     *   is refused with it. A self-recursive body loses the binding that
     *   made its repeated self-call linear and compiles exponentially —
     *   measured ×4 per two levels of `R(i,x,y) = R(i-1,x,y) +
     *   0.5·S(x,y,R(i-1,x,y))`. Declaring `pure: true` on the
     *   re-declaration does NOT restore sharing. Attaching in place is
     *   exempt, because the definition is still the engine's own.
     *
     * The evaluate side is NOT symmetric with the decline contract above:
     * returning `undefined` from an `evaluate` handler leaves the expression
     * unevaluated rather than falling back, so a handler that means to
     * delegate must call the captured original explicitly.
     *
     * Return `undefined` (or an empty string) to fall back to the
     * default compilation (a `null` returned from untyped JavaScript is
     * tolerated and treated the same). See {@link OperatorCompileHandler}.
     *
     * On the `javascript` target, the code may call two runtime helpers,
     * which keep their names and behavior across releases:
     * `_SYS.atNoWrap(base, index)` reads the element at a 1-based position
     * (or the elements at a list of positions) with no wrap-around, and
     * `_SYS.atMask(base, mask)` keeps the elements where a list of booleans
     * is `true`, and reads any other index as `atNoWrap` does. The other
     * members of `_SYS` are internal and can change in any release. The
     * compile guide ("Runtime Helpers for Generated JavaScript") gives the
     * details.
     *
     * The code a caller handler writes runs only on the thread that compiled
     * it: the result is not shippable, so `broadcastAsync()` does not send
     * it to the kernel pool (`reason: 'not-shippable'`). This holds also
     * for a handler attached in place to a built-in definition. Set
     * {@link compileShippable} when the code can run on a worker.
     */
    compile?: OperatorCompileHandler;

    /**
     * Whether the code that the {@link compile} handler writes can run on
     * a worker of the kernel pool. Default: `false`.
     *
     * A worker receives the compiled code as text and has none of the
     * functions or global variables of the thread that compiled it. Set
     * `true` only when the code calls nothing but the helpers of the
     * compiled-code runtime, the operands that the handler compiled, and the
     * functions given in {@link compileHelpers}. When the code calls a
     * function of the compiling thread (`globalThis.myFn(…)`) and this flag
     * is `true`, every cell that a worker evaluates throws, and its value is
     * `NaN` (`BroadcastAsyncResult.failed` counts these cells).
     *
     * A compiled result is shippable only when every caller handler that
     * wrote part of its code has this flag.
     */
    compileShippable?: boolean;

    /**
     * Functions that the code of the {@link compile} handler calls by name.
     * The engine copies the source of each function (`fn.toString()`) into
     * the code it compiles, as `const <name> = (<source>);`, so the code
     * carries its helpers to a worker of the kernel pool and to a stored
     * result. A helper is defined only when the handler wrote code for the
     * `javascript` or `interval-javascript` target.
     *
     * Because only the source is copied, a helper must not read a variable
     * from outside its own body (a closure variable or an import). Such a
     * read throws when the compiled code runs, on every thread. A name must
     * be a JavaScript identifier that does not start with `_` (the engine
     * uses that prefix for its own names). Choose a name that a parameter of
     * a compiled function cannot shadow, for example `myLibFloorIndex`.
     * Two definitions may give a helper of the same name only with the same
     * source.
     *
     * On the `interval-javascript` target, a compiled operand comes in one
     * of two forms, and a helper must accept both: a bare enclosure
     * `{ lo, hi }` (an input such as `_.x`), or the result of an interval
     * function, `{ kind: 'interval', value: { lo, hi } }` (for example
     * `_IA.sqrt(_.x)`, or any operand in a branch of an `If` whose
     * condition narrows it). A result can also be `{ kind: 'partial',
     * value: { lo, hi }, … }`, `{ kind: 'empty' }`, `{ kind: 'entire' }`
     * or `{ kind: 'singular', … }`. A helper that reads only `x.lo` reads
     * `undefined` from the second form, with no error. A helper can return
     * either form.
     *
     * ```ts
     * ce.declare('Wrap', {
     *   signature: '(number, number) -> number',
     *   compileShippable: true,
     *   compileHelpers: {
     *     wrapIndex: (i: number, n: number) => ((i % n) + n) % n,
     *   },
     *   compile: (args, compile, { language }) =>
     *     language === 'javascript'
     *       ? `wrapIndex(${compile(args[0])}, ${compile(args[1])})`
     *       : undefined,
     * });
     * ```
     */
    compileHelpers?: Readonly<Record<string, (...args: never[]) => unknown>>;

    /**
     * Custom equality handler.
     *
     * `prover` indicates the tier of the caller: `false` for the cheap
     * arithmetic tier (`eq()` / `.isEqual()`), `true` for the prover tier
     * (`eqIdentical()` / `.isIdenticallyEqual()`), and `undefined` when the
     * caller does not distinguish (e.g. `cmp()`). A handler that does
     * prover-tier work (sampling, expand/simplify, identity questions in the
     * free variables) must decline — return `undefined` — when
     * `prover === false`.
     */
    eq?: (
      a: Expression,
      b: Expression,
      prover?: boolean
    ) => boolean | undefined;
    neq?: (a: Expression, b: Expression) => boolean | undefined;

    collection?: CollectionHandlers;

    /**
     * Declares that the values this operator constructs are a VALUE KIND:
     * values with their own arithmetic (a residue class, a measurement, an
     * element of a finite field). See {@link ArithmeticDefinition}.
     *
     * The result type of every arm of the signature must be a KIND TYPE: a
     * kind primitive (`residue`), or a nominal type whose definition is
     * exactly `value`, declared with
     * `ce.declareType(name, 'value', { mint: false })`. The marker arms
     * `nan`, `missing`, `nothing` and `error` may be added. Any other result
     * type (a number type, `boolean`, `string`, a collection, `value`,
     * `any`, `expression`, a nominal type with another definition) is
     * refused when the operator is declared. A definition that gives `add`
     * must also give `negate`.
     *
     * The fields `admittedAs`, `resultType` and `compile.type` belong to the
     * kind TYPE, not to this operator: the operators of one kind type that
     * are declared at the same time must give equal values for them (or
     * leave them out).
     */
    arithmetic?: ArithmeticDefinition;

    /**
     * For an operator that RETURNS a collection but has no `collection`
     * handlers (an EAGER producer — `Characters`, `Divisors`, `Eigenvalues`,
     * …): can `evaluate()` produce the collection's elements in the current
     * state?
     *
     * This is the operator's own decline test — the guard at the top of its
     * `evaluate` handler — exposed so the enumerability facet
     * (`isEnumerableCollection`) can answer without evaluating. Contract
     * (see `docs/COLLECTIONS-MODEL.md`):
     *
     * - MUST be O(1), evaluation-free and side-effect free. An impure
     *   producer answers from its operands' facets, consuming no draws.
     * - `false` means evaluation WOULD decline — callers stay inert without
     *   paying for the evaluation.
     * - `true` is a hard promise that evaluation produces the collection. An
     *   operator whose success is not cheaply decidable (`Solve`,
     *   `FindRoot`) must return `undefined`, never `true`.
     * - The operand seen here is the CANONICAL operand, not the evaluated
     *   one. An unevaluated compound operand (`Divisors(n + 1)`) whose value
     *   cannot be read cheaply must yield `undefined` (undecidable), not
     *   `false` — only a definitively unavailable operand (a valueless
     *   symbol, a literal of the wrong kind) yields `false`. See
     *   `canEnumerateOperand` (`collection-utils.ts`) for the shared
     *   tri-state resolution.
     *
     * Ignored (never consulted) when the definition has `collection`
     * handlers — those own enumerability via `collection.isEnumerable`.
     */
    canEnumerate?: (expr: Expression) => boolean | undefined;

    /**
     * For an operator that RETURNS a collection but has no `collection`
     * handlers (an EAGER producer — `Sort`, `Chunk`, `Ordering`, …): how many
     * elements would `evaluate()` produce?
     *
     * The `count` twin of {@link canEnumerate}, and the honest replacement for
     * the broadcast count fallback: `count` reads the operands' agreed length
     * only for a `broadcastable` operator, where agreement IS the semantics
     * (`docs/BROADCAST-MODEL.md`). A reshaping operator's length is its own
     * business, so it must say so here or report `undefined`.
     *
     * Contract, mirroring `canEnumerate`:
     *
     * - MUST be O(1), evaluation-free and side-effect free. An impure producer
     *   (`RandomShuffle`) answers from its operands' facets, consuming ZERO
     *   draws.
     * - The operands seen here are the CANONICAL ones. Anything not cheaply
     *   knowable — a non-literal shape argument, an unknown source length —
     *   must report `undefined` (decline), never a guess.
     * - A returned number is a hard promise: it must equal
     *   `expr.evaluate().count`. When evaluation would DECLINE (an infinite or
     *   unknown-length source), report `undefined` — a count nobody can walk is
     *   worse than no count (Tycho item-169 ruling).
     *
     * Consulted only when the definition has no `collection.count` handler —
     * a declared `count` owns the answer, including its `undefined`.
     */
    elementCount?: (expr: Expression) => number | undefined;

    /**
     * For an operator that RETURNS a collection but has no `collection`
     * handlers: the element at the 1-based position `index` of the
     * collection that `evaluate()` would produce, built from the operands
     * with no evaluation. `PointX(L)` at `k` is `PointX(L.at(k))`.
     *
     * The `at()` twin of {@link elementCount}. Contract:
     *
     * - Called only for a valid, pure expression whose `count` is known, with
     *   `1 ≤ index ≤ count`.
     * - MUST NOT evaluate the expression. The element it returns can be
     *   unevaluated, and its evaluation MUST equal
     *   `expr.evaluate().at(index)`: `at()` returns that evaluation.
     * - Anything not cheaply knowable must report `undefined` (decline):
     *   `at()` then evaluates the expression and reads the element of the
     *   result.
     *
     * Consulted only when the definition has no `collection.at` handler.
     */
    elementAt?: (expr: Expression, index: number) => Expression | undefined;

    /**
     * Use-driven element inference. Called when a type REQUIREMENT reaches
     * an application of this operator: its result is an operand of a typed
     * parameter (`k(xs[1])` with `k: (integer) -> integer` requires
     * `integer`) or of an arithmetic operator, which requires a scalar
     * numeric result (`xs[1] + 1` requires `real`). The handler answers the
     * type each OPERAND must have for the result to satisfy the requirement:
     * one entry per operand, `undefined` where that operand learns nothing,
     * or `undefined` for the whole call to decline.
     *
     * The engine writes each entry onto the operand through the ordinary
     * inference path, so only an operand whose type is inferred (or still
     * unknown) moves, a declared type never does, and an operand that is
     * itself an application forwards to its own operator's handler
     * (`m[1][2] + 1` reaches `m`). A `widen` never reaches the handler: it
     * carries a result possibility, not a constraint on the operands.
     *
     * Only a VALUE requirement reaches the handler: never `any`, `unknown`,
     * `value`, `nothing`, an absence marker alone, or a function type. An
     * absence arm (`real | missing`) is stripped before the call.
     *
     * An entry can also be `{ replace: t }`: the handler has combined the
     * operand's current inferred type with this requirement itself, and `t`
     * replaces that type instead of being intersected with it. This is for a
     * combination that is not an intersection, such as a tuple that gets one
     * more component. The same guards apply: a declared type never moves.
     *
     * `At` answers `dictionary<r> | indexed_collection<r>` for its base and
     * `First`/`Second`/`Third`/`Last` answer `indexed_collection<r>`. The
     * scalar reading is written on purpose: `xs[1] + 1` requires `number`
     * of the element, exactly as `x + 1` infers a bare `x` as `number`.
     * For a base that is a bare function parameter, `At` answers a
     * `replace` entry that records each index read separately (a tuple for
     * literal indices). Design and rulings: `docs/INFERENCE_ROADMAP.md` §5.
     */
    inferOperandTypes?: (
      ops: ReadonlyArray<Expression>,
      requirement: Type
    ) =>
      ReadonlyArray<Type | { readonly replace: Type } | undefined> | undefined;
  };

/**
 * Metadata common to both symbols and functions.
 *
 * @category Definitions
 *
 */
export interface BaseDefinition {
  /**
   * If a string, a short description, about one line long.
   *
   * Otherwise, a list of strings, each string a paragraph.
   *
   * May contain Markdown.
   */
  description: string | string[];

  /**
   * Search keywords (synonyms, alternate names) used by
   * `ce.searchDefinitions()`. Not shown in documentation.
   */
  keywords?: string[];

  /** A list of examples of how to use this symbol or operator.
   *
   * Each example is one line of Epsil source — `Rationalize(1.75)` — that
   * evaluates on a fresh engine to a value worth showing. A trailing `//`
   * comment is allowed and is replaced by the value the example evaluates
   * to when the standard-library page is generated
   * (`scripts/build-library-docs.ts`); that page executes every example, so
   * one that stops evaluating fails the documentation build.
   */
  examples: string | string[];

  /** A URL pointing to more information about this symbol or operator. */
  url: string;

  /**
   * A short string representing an entry in a wikibase.
   *
   * For example `"Q167"` is the [wikidata entry](https://www.wikidata.org/wiki/Q167)
   * for the `Pi` constant.
   */
  wikidata: string;

  /** If true, the value or type of the definition cannot be changed */
  readonly isConstant?: boolean;
}

/** Options for `Expression.simplify()`
 *
 * @category Boxed Expression
 */
export type SimplifyOptions = {
  /**
   * The set of rules to apply. If `null`, use no rules. If not provided,
   * use the default simplification rules.
   *
   * The rules control the symbolic rewrites only. A constant subexpression
   * (pure, with no unknowns and no assigned variable) whose evaluation is a
   * number is folded whatever this option says, `null` included: `3! + x`
   * simplifies to `6 + x` with no rules.
   */
  rules?: null | Rule | ReadonlyArray<BoxedRule | Rule> | BoxedRuleSet;

  /**
   * Use this cost function to determine if a simplification is worth it.
   *
   * If not provided, `ce.costFunction`, the cost function of the engine is
   * used.
   */
  costFunction?: (expr: Expression) => number;

  /**
   * The simplification strategy to use.
   *
   * - `'default'`: Use standard simplification rules (default)
   * - `'fu'`: Use the Fu algorithm for trigonometric simplification.
   *   This is more aggressive for trig expressions and may produce
   *   different results than the default strategy.
   *
   *   **Note:** When using the `'fu'` strategy, the `costFunction` and `rules`
   *   options are ignored. The Fu algorithm uses its own specialized cost
   *   function that prioritizes minimizing the number of trigonometric
   *   functions. Standard simplification is applied before and after the
   *   Fu transformations using the engine's default rules.
   * - `'trig'`: Rewrite exponentials of an imaginary argument to
   *   trigonometric form via Euler's formula (`e^{iθ} → cos θ + i·sin θ`),
   *   then simplify. This is the opt-in inverse of the default behavior, which
   *   keeps `e^{iθ}` in exponential form for a symbolic angle `θ`.
   */
  strategy?: 'default' | 'fu' | 'trig';
};

/** Options for `Expression.explain()`
 *
 * In addition to the `SimplifyOptions` (honored when explaining a
 * `'simplify'` operation, so that `explain('simplify', options).result`
 * matches `simplify(options)`):
 *
 * - `verbosity`: `'default'` returns the curated step chain (bookkeeping
 *   steps filtered out); `'all'` returns the raw, uncurated chain.
 * - `variable`: the unknown, for the `'solve'` and `'D'` operations. For a
 *   system of equations (`explain('solve')` on a `List`/`And`), pass the
 *   unknowns as an array, in order.
 * - `order`: for the `'D'` operation only, the order of the derivative to
 *   explain (the n-th derivative with respect to `variable`). Defaults to `1`.
 *   Ignored when the receiver is already a `D(…)` expression (which encodes
 *   its own differentiation sequence).
 *
 * @category Boxed Expression
 */
export type ExplainOptions = SimplifyOptions & {
  verbosity?: ExplainVerbosity;
  variable?: string | string[];
  order?: number;
};

/**
 * A table mapping symbols to their definition.
 *
 * Symbols should be valid MathJSON symbols. In addition, the
 * following rules are recommended:
 *
 * - Use only latin letters, digits and `-`: `/[a-zA-Z0-9-]+/`
 * - The first character should be a letter: `/^[a-zA-Z]/`
 * - Functions and symbols exported from a library should start with an uppercase letter `/^[A-Z]/`
 *
 * @category Definitions
 *
 */

export type SymbolDefinition = OneOf<[ValueDefinition, OperatorDefinition]>;

/**
 * `Partial` distributed over the {@link SymbolDefinition} union (a plain
 * `Partial<A | B>` would merge the arms into one loose object type).
 *
 * @category Definitions
 */
export type PartialSymbolDefinition<T = SymbolDefinition> = T extends unknown
  ? Partial<T>
  : never;

/**
 * A definition as `ce.declare()` accepts it: a partial definition, or the
 * boxed operator definition read back from `expr.operatorDefinition`.
 *
 * Admitting the boxed definition is what lets an operator be re-declared
 * from its existing definition with some handlers replaced:
 *
 * ```ts
 * const sqrt = ce.expr('Sqrt').operatorDefinition!;
 * ce.declare('Sqrt', {
 *   ...sqrt,
 *   evaluate: (ops, options) => sqrt.evaluate!(ops, options),
 * });
 * ```
 *
 * @category Definitions
 */
export type SymbolDefinitionInput =
  PartialSymbolDefinition | BoxedOperatorDefinition;

export type SymbolDefinitions = Readonly<{
  [id: string]: PartialSymbolDefinition;
}>;

/**
 * A library bundles symbol/operator definitions and declares dependencies on
 * other libraries. It carries no LaTeX dictionary entries: to parse or
 * serialize a new notation, pass a dictionary to the `LatexSyntax` given with
 * the `latexSyntax` constructor option, or add entries to a running engine
 * with `ce.latexSyntax.addEntries()`.
 *
 * To load a custom library on a running engine, use `ce.loadLibrary()`.
 *
 * Use with the `libraries` constructor option to load standard or custom
 * libraries:
 *
 * ```ts
 * const ce = new ComputeEngine({
 *   libraries: ['core', 'arithmetic', {
 *     name: 'custom',
 *     requires: ['arithmetic'],
 *     definitions: { G: { value: 6.674e-11, type: 'real', isConstant: true } },
 *   }],
 * });
 * ```
 *
 * @category Definitions
 */
export interface LibraryDefinition {
  /** Library identifier */
  name: string;
  /** Libraries that must be loaded before this one */
  requires?: string[];
  /** Symbol and operator definitions */
  definitions?: SymbolDefinitions | SymbolDefinitions[];
}

/**
 * When a unitless value is passed to or returned from a trigonometric function,
 * the angular unit of the value.
 *
 * | Angular Unit | Description |
 * |:--------------|:-------------|
 * | `rad` | radians, 2π radians is a full circle |
 * | `deg` | degrees, 360 degrees is a full circle |
 * | `grad` | gradians, 400 gradians is a full circle |
 * | `turn` | turns, 1 turn is a full circle |
 *
 * To change the angular unit used by the Compute Engine, use:
 *
 * ```js
 * ce.angularUnit = 'deg';
 * ```
 *
 * @category Compute Engine
 */
export type AngularUnit = 'rad' | 'deg' | 'grad' | 'turn';

/**
 * The rule that `Round` uses for a value that is exactly halfway between two
 * integers (a tie). A value that is not a tie always rounds to the nearest
 * integer.
 *
 * | Rule | `Round(2.5)` | `Round(3.5)` | `Round(-2.5)` | Description |
 * |:-----|:------------:|:------------:|:-------------:|:------------|
 * | `away-from-zero` | `3` | `4` | `-3` | the default |
 * | `to-even` | `2` | `4` | `-2` | IEEE 754, Python, NumPy and Mathematica |
 * | `toward-zero` | `2` | `3` | `-2` | |
 * | `toward-positive-infinity` | `3` | `4` | `-2` | JavaScript `Math.round` |
 * | `toward-negative-infinity` | `2` | `3` | `-3` | |
 *
 * The rule also applies to the step form `Round(x, step)`, which rounds to
 * the nearest multiple of the step: the tie is at the half of the step
 * (with the step `1/100`, `Round(0.125, 1/100)` is a tie).
 *
 * To change the rule used by the Compute Engine, use:
 *
 * ```js
 * ce.roundingTies = 'to-even';
 * ```
 *
 * @category Compute Engine
 */
export type RoundingTies =
  | 'away-from-zero'
  | 'to-even'
  | 'toward-zero'
  | 'toward-positive-infinity'
  | 'toward-negative-infinity';

/** @category Numerics */
export type Sign =
  /** The expression is equal to 0 */
  | 'zero'

  /** The expression is > 0 */
  | 'positive'

  /** The expression is < 0 */
  | 'negative'

  /** The expression is >= 0 and isPositive is either false or undefined*/
  | 'non-negative'

  /** The expression is <= 0 and isNegative is either false or undefined*/
  | 'non-positive'

  /** The expression is not equal to 0 (possibly with an imaginary part) and isPositive, isNegative, isUnsigned are all false or undefined */
  | 'not-zero'

  /** The expression has an imaginary part or is NaN */
  | 'unsigned';

/**
 * These handlers are the primitive operations that can be performed on
 * all collections, indexed or not.
 *
 *  @category Definitions
 */
export interface BaseCollectionHandlers {
  /**
   * Return an iterator that iterates over the elements of the collection.
   *
   * The order in which the elements are returned is not defined. Requesting
   * two iterators on the same collection may return the elements in a
   * different order.
   *
   * @category Definitions
   */
  iterator: (
    collection: Expression
  ) => Iterator<Expression, undefined> | undefined;

  /** Return the number of elements in the collection.
   *
   * An empty collection has a count of 0. An infinite collection has a count
   * of `Infinity`. Return `undefined` when the count cannot be determined.
   *
   * A finite count that is not a safe integer (larger than
   * `Number.MAX_SAFE_INTEGER`) cannot be held exactly by a `number`: return
   * it as a `bigint`. A handler can also return a `bigint` for a smaller
   * count: `expr.count` always converts a count that is a safe integer to a
   * `number`.
   */
  count: (collection: Expression) => number | bigint | undefined;

  /** Optional flag to quickly check if the collection is empty, without having to count exactly how may elements it has (useful for lazy evaluation). */
  isEmpty?: (collection: Expression) => boolean | undefined;

  /** Optional flag to quickly check if the collection is finite, without having to count exactly how many elements it has (useful for lazy evaluation). */
  isFinite?: (collection: Expression) => boolean | undefined;

  /**
   * Optional predicate answering whether `iterator()` will actually produce
   * this collection's elements — the cheap way to tell an EMPTY collection
   * from one that merely cannot be walked, which are otherwise
   * indistinguishable (both yield nothing).
   *
   * Return `false` when the elements have no computable value in the current
   * state: symbolic bounds (`Range(a, b)`, `Linspace(a, 1, 3)`, a symbolic
   * repeat count), or a source that is itself not enumerable. Return
   * `undefined` only when it cannot be decided without evaluating.
   *
   * Implementations must be O(1) and must NOT consult `count`, `isEmpty` or
   * `isFinite` on themselves, nor walk the collection: a wrapper answers by
   * reading its source's `isEnumerableCollection`, so a chain costs one call
   * per level. (Reading the emptiness facets instead is exponential in the
   * chain depth — each read re-enters the next `isEmpty` down.)
   *
   * Default when the handler is ABSENT: `true` (an operator with a
   * `collection` block can enumerate its elements). A handler that IS declared
   * owns all three states — returning `undefined` from it means "cannot tell
   * cheaply" and does not fall back to the default.
   */
  isEnumerable?: (collection: Expression) => boolean | undefined;

  /**
   * Optional predicate for operators whose collection-ness depends on their
   * operands, e.g. `If(cond, value)`, which is a collection exactly when
   * `value` is one.
   *
   * Returning `false` reports the expression as a scalar, as if it had no
   * collection handlers at all.
   *
   * Default: `true` (an operator with a `collection` block is a collection).
   */
  isCollection?: (collection: Expression) => boolean;

  /** Return `true` if the collection is lazy, `false` otherwise.
   * If the collection is lazy, it means that the elements are not
   * computed until they are needed, for example when iterating over the
   * collection.
   *
   * Default: `false`. A collection is eager unless its definition says
   * otherwise: the elements of a `List` are already materialized operands,
   * so nothing is deferred. Lazy collections such as `Range` or `Map` declare
   * this handler to opt in.
   */
  isLazy?: (collection: Expression) => boolean;

  /**
   * Opt this operator's instances into per-instance element memoization: a
   * complete walk of an unmodified instance is served from a cached prefix
   * on subsequent walks (`boxed-expression/collection-element-memo.ts`).
   *
   * Set it on lazy operators that evaluate a function per element (`Map`,
   * `Filter`, `Tabulate`, …), where re-deriving an element is expensive.
   * Leave it off structural reindexers (`Take`, `Reverse`, `Zip`, …), which
   * re-serve their source's elements cheaply — when the source is itself a
   * flagged instance, the source's own memo already absorbs the cost.
   *
   * Default: `false`
   */
  elementMemo?: boolean;

  /**
   * Set on a lazy operator that calls a function operand when its elements
   * are read, not when it is evaluated (`Map`, `Filter`, `Tabulate`, …).
   * An instance created during a function call keeps the evaluation
   * context of that call, and each read of the instance runs in it, so that
   * a name that the callback reads by its binding in the context (the symbol
   * default `d` of a parameter `(x, k = d) => x * k`) has the value it had in
   * the call, also when the instance is read after the call has returned
   * (`boxed-expression/lazy-view-context.ts`).
   *
   * Leave it off an operator that calls its function operand when it is
   * evaluated (`Reduce`, `Sort`), and off an operator with no function
   * operand.
   *
   * Default: `false`
   */
  callsCallbackOnRead?: boolean;

  /**
   * Return `true` if the target expression is in the collection,
   * `false` otherwise.
   *
   * Return `undefined` if the membership cannot be determined.
   */
  contains?: (
    collection: Expression,
    target: Expression
  ) => boolean | undefined;

  /**
   * Return the number of elements of the collection that are structurally
   * the same as `target` (the `isSame()` comparison), without a walk of the
   * collection. `Count(xs, v)` reads it.
   *
   * Give this handler when the collection can have more elements than a
   * walk can visit (a combinatorial generator such as `Permutations` has
   * `n!` elements): without it, `Count(xs, v)` walks every element. A count
   * that is not a safe integer is returned as a `bigint`.
   *
   * Return `undefined` when the count cannot be computed without a walk.
   * The answer must be the one a walk that compares each element with
   * `isSame()` gives.
   */
  countOf?: (
    collection: Expression,
    target: Expression
  ) => number | bigint | undefined;

  /**
   * Return `true` if all the elements of `collection` are in `other` — that
   * is, `collection` ⊆ `other`. The RECEIVER is the candidate subset, matching
   * the public `Expression.subsetOf(other, strict)` method that dispatches
   * here. Both `collection` and `other` are collections.
   *
   * If strict is `true`, the subset must be strict, that is, `other` must have
   * an element that `collection` does not.
   *
   * Return `undefined` if the subset relation cannot be determined. A handler
   * that cannot see far enough to answer must return `undefined` rather than
   * `false`: `false` is read as a proof that the relation does NOT hold.
   */
  subsetOf?: (
    collection: Expression,
    other: Expression,
    strict: boolean
  ) => boolean | undefined;

  /** Return the sign of all the elements of the collection. */
  eltsgn?: (collection: Expression) => Sign | undefined;

  /** Return the widest type of all the elements in the collection */
  elttype?: (collection: Expression) => Type | undefined;
}

/**
 * These additional collection handlers are applicable to indexed
 * collections only.
 *
 * The elements of an indexed collection can be accessed by index, and
 * the order of the elements is defined.
 *
 *  @category Definitions
 */
export interface IndexedCollectionHandlers {
  /**
   * Return the element at the specified index.
   *
   * The first element is `at(1)`, the last element is `at(-1)`.
   *
   * If the index is &lt;0, return the element at index `count() + index + 1`.
   *
   * The index can also be a string, for example for records. There is no
   * handler that enumerates the valid string keys: a handler that accepts
   * them decides which ones it recognizes, and returns `undefined` for the
   * rest.
   *
   * If the index is invalid, return `undefined`.
   */
  at: (
    collection: Expression,
    index: number | string
  ) => undefined | Expression;

  /**
   * Return the index of the first element that matches the predicate.
   *
   * If no element matches the predicate, return `undefined`.
   */
  indexWhere: (
    collection: Expression,
    predicate: (element: Expression) => boolean
  ) => number | undefined;

  /**
   * Return the element at a 1-based position given as a `bigint`.
   *
   * The position is positive. A negative position is converted before the
   * call: it counts from the end, so it is `count + index + 1`.
   *
   * `at()` takes a `number`, which cannot hold a position larger than
   * `Number.MAX_SAFE_INTEGER` exactly. Give this handler when the collection
   * can have more elements than that (its `count` can be a `bigint`): it is
   * used for such a position, and for a negative position when the count is
   * a `bigint`. Without it, these positions have no element.
   *
   * If the position is outside the collection, return `undefined`.
   */
  atBigint?: (collection: Expression, index: bigint) => undefined | Expression;

  /**
   * Return the 1-based position of the first element that is structurally
   * the same as `target` (the `isSame()` comparison), without a walk of the
   * collection. `IndexOf(xs, v)` reads it.
   *
   * Return `0` when no element is the same as `target`, and `undefined` when
   * the position cannot be computed without a walk. A position that is not a
   * safe integer is returned as a `bigint`. The answer must be the one a walk
   * that compares each element with `isSame()` gives.
   */
  indexOf?: (
    collection: Expression,
    target: Expression
  ) => number | bigint | undefined;
}

/**
 * The collection handlers are the primitive operations that can be
 * performed on collections, such as lists, sets, tuples, etc...
 *
 *  @category Definitions
 */
export type CollectionHandlers = BaseCollectionHandlers &
  Partial<IndexedCollectionHandlers>;

/**
 * The context passed to the hooks of an {@link ArithmeticDefinition}.
 *
 * @category Definitions
 */
export interface ArithmeticContext {
  readonly engine: ComputeEngine;
  /** `true` under `.N()`. The hook numericizes its own result: a kind whose
   * values are exact (a residue class) computes the exact value anyway; a
   * kind whose values carry a float (a measurement, an interval) returns the
   * numeric form. The caller does not apply `.N()` to the result. */
  readonly numericApproximation: boolean;
  /** For the `compare` hook only: the tolerance of the caller, when it
   * compares within a tolerance. `.is()` gives the `tolerance` argument of
   * the call, or `engine.tolerance` when the call has none (`.is()` is the
   * comparison within a tolerance, also for two exact values). `undefined`
   * for every other comparison (the relational operators, `isEqual()`,
   * `isLess()`, `Max`, `Min`, `Sort`, …): the hook then applies its own
   * rule, usually two exact values compared exactly and a float within
   * `engine.tolerance`. */
  readonly tolerance?: number;
}

/**
 * The operands of an `add`, `multiply` or `apply` hook of an
 * {@link ArithmeticDefinition}.
 *
 * @category Definitions
 */
export interface KindOperands {
  /** The evaluated operands. */
  readonly evaluated: ReadonlyArray<Expression>;
  /** The operands as they were written before evaluation, aligned with
   * `evaluated`. `undefined` for a value that an earlier fold made, which
   * has no written form. A kind whose rule depends on how a term was
   * written reads it here (a temperature with an offset reads `Negate(b)` in
   * `a - b`). */
  readonly written: ReadonlyArray<Expression | undefined>;
  /** The exact value of operand `i`: `evaluated[i]` outside `.N()`. Under
   * `.N()`, the operand evaluated again without the numeric approximation
   * when it is transitively pure (evaluating it again cannot repeat a side
   * effect), else `evaluated[i]`. The result is memoized. */
  exact(i: number): Expression;
  /** At an operator whose parameter is a collection type, the elements of
   * collection operand `i`, enumerated once by the engine. `undefined` for an
   * operand that is not a collection, or that was not enumerated (a
   * collection larger than `engine.maxCollectionSize`, of unknown or
   * infinite count, or whose element type cannot hold a value of a kind). */
  elements(i: number): ReadonlyArray<Expression> | undefined;
}

/**
 * One operand of a `negate`, `divide`, `power` or `compare` hook of an
 * {@link ArithmeticDefinition}. The fields have the meaning of the fields of
 * {@link KindOperands} with the same name.
 *
 * @category Definitions
 */
export type KindOperand = {
  readonly evaluated: Expression;
  readonly written: Expression | undefined;
  exact(): Expression;
};

/**
 * The result of an `add` or `multiply` hook of an
 * {@link ArithmeticDefinition}: the operands that the hook combined, by their
 * index in `ops.evaluated`, and the value they make.
 *
 * @category Definitions
 */
export interface KindFold {
  readonly value: Expression;
  readonly operands: ReadonlyArray<number>;
}

/**
 * The compiled form of a value kind (the `compile` field of an
 * {@link ArithmeticDefinition}).
 *
 * The hooks branch on `context.language`, like the `compile` handler of an
 * operator definition. `undefined` from a hook declines: the compilation
 * then fails with a diagnostic that names the kind type.
 *
 * @category Compiling
 */
export interface ArithmeticCompile {
  /** The representation of the kind TYPE and its operations. It belongs to
   * the kind type, not to one operator: the operators of one kind type that
   * are declared at the same time must give the same object (or none, and
   * then they use the one another operator gave). */
  type?: {
    /** The target representation of a free symbol of the kind's type, as
     * `freeSymbolTypes[].lowered` reports it, or `undefined` when the
     * target has none (the compilation then declines). */
    lowered(context: OperatorCompileContext): string | undefined;
    /** A sum with an operand of the kind. A number operand beside a kind
     * value is the hook's to promote. */
    add?(
      args: ReadonlyArray<Expression>,
      compile: (expr: Expression) => string,
      context: OperatorCompileContext
    ): string | undefined;
    /** A product with an operand of the kind. */
    multiply?(
      args: ReadonlyArray<Expression>,
      compile: (expr: Expression) => string,
      context: OperatorCompileContext
    ): string | undefined;
    /** The other arithmetic operators, the comparisons, and the other
     * operators with an operand of the kind. Not the structural and
     * control-flow operators (`If`, `Block`, `List`, `Tuple`, `Assign`,
     * `Hold`, a call of a user function): they treat the representation as
     * an opaque value. */
    apply?(
      operator: string,
      args: ReadonlyArray<Expression>,
      compile: (expr: Expression) => string,
      context: OperatorCompileContext
    ): string | undefined;
    /** The check, at run time, of a host value passed for a free symbol of
     * the kind's type. */
    entry(value: unknown, context: OperatorCompileContext): boolean;
    /** Whether code from this lowering may be sent to a worker as text.
     * Default `false`. A compilation result is shippable only when every
     * kind contract it uses says `true` and lists no `hostNames`, and no
     * input of the code is a value of a kind (its `entry` check is a
     * function of the host, which a worker does not have). */
    shippable?: boolean;
    /** Functions that the code of this lowering calls by name. The engine
     * copies the source of each one into the compiled code, as
     * `const <name> = (<source>);`, so the code carries them to a worker
     * and to a stored result. The rules are those of
     * `OperatorDefinition.compileHelpers`: a helper must not read a
     * variable from outside its own body, and its name is an identifier
     * that does not start with `_`. Put a helper here, not in `hostNames`,
     * when the code can carry it. */
    helpers?: Readonly<Record<string, (...args: never[]) => unknown>>;
    /** The functions of the host that the code of this lowering calls and
     * that it does not carry (they are not in `helpers`). A worker does not
     * have them, so a non-empty list makes the result not shippable,
     * whatever `shippable` says. */
    hostNames?: ReadonlyArray<string>;
  };
  /** The source of a literal value of THIS operator, in the representation of
   * the kind type. An operator without it declines a literal of its own. */
  value?(
    value: Expression,
    compile: (expr: Expression) => string,
    context: OperatorCompileContext
  ): string | undefined;
}

/**
 * The arithmetic of a VALUE KIND, given by the `arithmetic` field of the
 * operator definition of the head that constructs its values.
 *
 * The fields marked PER TYPE belong to the kind type (the result type of the
 * head), because a symbol of that type has no head to ask: `admittedAs`,
 * `resultType` and `compile.type`. The other fields belong to the head.
 *
 * Rules for a hook:
 * - The operands of `add` and `multiply` arrive in canonical order, and
 *   `multiply` must commute.
 * - A hook may build and evaluate expressions through the engine, including
 *   expressions with values of another kind. A hook never calls
 *   `.simplify()`.
 * - A hook that throws propagates the error, as an `evaluate` handler does.
 * - A fold that names an operand index out of range or twice is an error in
 *   the definition of the kind and throws.
 *
 * @category Definitions
 */
export interface ArithmeticDefinition {
  /** PER TYPE. Where a value of this kind is admitted beyond the arithmetic
   * operators and the parameters that name its type or admit `value`.
   * Default `'none'`. */
  admittedAs?: 'none' | 'real' | 'number';

  /**
   * The sum of the operands of which at least one is a value of this kind.
   * `ops` are the evaluated operands. A fold names the operands it combined,
   * by their index in `ops.evaluated`, and the value they make. A hook may
   * return several folds and must not name an operand twice. A fold may name
   * an operand of another kind only to absorb it into its own value. A
   * fold's `value` may be a value of another kind or a plain number.
   * `undefined`, or an empty list, folds nothing.
   */
  add?(
    ops: KindOperands,
    context: ArithmeticContext
  ): ReadonlyArray<KindFold> | undefined;

  /** The product of the operands of which at least one is a value of this
   * kind. The contract is the one of `add`. */
  multiply?(
    ops: KindOperands,
    context: ArithmeticContext
  ): ReadonlyArray<KindFold> | undefined;

  /** `-x`. `undefined` declines. */
  negate?(x: KindOperand, context: ArithmeticContext): Expression | undefined;

  /** `a / b`, at least one operand of this kind. `undefined` declines. */
  divide?(
    a: KindOperand,
    b: KindOperand,
    context: ArithmeticContext
  ): Expression | undefined;

  /** `base ^ exponent`, at least one operand of this kind. `Sqrt(x)` calls it
   * with the exponent `1/2`, `Root(x, n)` with `1/n`, `Square(x)` with `2`.
   * `undefined` declines. */
  power?(
    base: KindOperand,
    exponent: KindOperand,
    context: ArithmeticContext
  ): Expression | undefined;

  /**
   * The order of two values of which at least one is of this kind, for the
   * comparison operators, `Max`, `Min`, `ElementMax`, `ElementMin`, `Sort`,
   * `Clamp` and the comparison methods:
   *
   * - `-1`, `0` or `1`: the order of the two values;
   * - `'unordered'`: the two values are known and have no order (a value
   *   with a complex or `NaN` nominal). The four order operators (`Less`,
   *   `LessEqual`, `Greater`, `GreaterEqual`) answer `False`, as they do for
   *   a complex number; `Equal` and `NotEqual` ask the `eq` handler of the
   *   head definitions; `Max`, `Min` and `Sort` leave the call unevaluated;
   * - `'<='`: `a` is less than or equal to `b`, and the hook cannot say
   *   which (two enclosures that touch: `Enclosure(0, 1)` and
   *   `Enclosure(1, 2)`). `LessEqual` answers `True` and `Greater` answers
   *   `False`; `Less` and `GreaterEqual` stay unevaluated; `Equal` and
   *   `NotEqual` ask the `eq` handlers. `'>='` is the mirror answer. A
   *   reader that needs a total order (`Sort`, `Max` and `Min` without an
   *   `extremum` hook) reads them as `undefined`;
   * - `undefined`: the two values are not comparable (a value of another
   *   kind, a symbol with no value). An order comparison stays unevaluated,
   *   `Equal` and `NotEqual` ask the `eq` handlers.
   *
   * A kind without `compare` has no order.
   */
  compare?(
    a: KindOperand,
    b: KindOperand,
    context: ArithmeticContext
  ): -1 | 0 | 1 | '<=' | '>=' | 'unordered' | undefined;

  /**
   * The maximum (`which` is `'max'`) or the minimum of the operands, of
   * which at least one is a value of this kind, for `Max`, `Min`,
   * `ElementMax`, `ElementMin` and `Clamp`. The engine asks this hook
   * before it orders the operands with `compare`, so a kind whose values
   * can overlap gives a value that is not one of the operands: the maximum
   * of two enclosures is the enclosure of the larger ends
   * (`Max(Enclosure(0, 2), Enclosure(1, 3))` is `Enclosure(1, 3)`).
   * `undefined` declines, and the engine orders the operands with
   * `compare`. Absent: the engine orders the operands with `compare`.
   */
  extremum?(
    which: 'max' | 'min',
    ops: KindOperands,
    context: ArithmeticContext
  ): Expression | undefined;

  /**
   * Whether the value `value` of this kind is exact. Absent: a value
   * of the kind is exact. A measurement is never exact.
   *
   * The engine does not read this hook now. It is kept for compatibility
   * with kind definitions that declare it.
   *
   * @deprecated The engine does not read it: an exact form with no value
   * gives `NaN`, whether its operands are exact or not.
   */
  isExact?(value: Expression): boolean;

  /**
   * Whether the value `value` of this kind stands for no value, as the
   * number `NaN` does: a measurement with a `NaN` nominal, a quantity with a
   * `NaN` magnitude. Such a value follows the rule of `NaN` at `Max`, `Min`,
   * `ElementMax`, `ElementMin` and `Clamp`: `Max(Quantity(NaN, m), 2 m)` is
   * `NaN`, as `Max(NaN, 2)` is. Absent: no value of the kind is `NaN`.
   */
  isNaN?(value: Expression): boolean;

  /**
   * The number that the value `value` of this kind stands for, when the
   * values of the kind stand for a number: the nominal of a measurement.
   * The numeric accessors of the value read it: `re`, `im`, `bignumRe`,
   * `bignumIm` and `valueOf()` (`Measurement(2.5, 0.1).re` is `2.5`, and a
   * complex nominal gives its real and imaginary parts). Absent, or
   * `undefined`: those accessors answer as for any other expression that
   * is not a number (`re` is `NaN`).
   *
   * The FACT queries (`isPositive`, `sgn`, `isInteger`, `isFinite`, …) do
   * not read it: they stay `undefined` for a value of a kind, so that no
   * canonical fold of the numbers applies to it.
   */
  numericValue?(value: Expression): Expression | undefined;

  /**
   * Called in place of the `evaluate` handler of `operator` when at least one
   * operand is a value of this kind that the operator admitted only because
   * of `admittedAs`. `undefined` leaves the expression unevaluated.
   */
  apply?(
    operator: string,
    ops: KindOperands,
    context: ArithmeticContext
  ): Expression | undefined;

  /**
   * PER TYPE. The static result type of a cell of `operator` with an operand
   * of this kind's type, from the operand types without their shapes, or
   * `undefined` for the default. `operator` is the dispatched operator:
   * `'Add'` for a sum or a difference, `'Power'` for `Sqrt`, `Root` and
   * `Square`, with the type of the implied exponent among `operandTypes`.
   * A type string is parsed in the engine (`'number | uq'`).
   */
  resultType?(
    operator: string,
    operandTypes: ReadonlyArray<Type>
  ): Type | TypeString | undefined;

  /** The compiled form of the kind. Absent: every target declines an
   * expression that holds a value of the kind. */
  compile?: ArithmeticCompile;
}

/**
 * The record of one kind type in the kind registry of an engine
 * (`boxed-expression/value-kinds.ts`): the fields that belong to the type,
 * and the heads that declare a kind with this type as their result.
 *
 * @internal
 */
export interface KindTypeRecord {
  /** The admission of the type. A head that gave no `admittedAs` counts as
   * `'none'`. */
  admittedAs: 'none' | 'real' | 'number';
  /** The `resultType` hook of the type, or `undefined` when no head gave
   * one. */
  resultType: ArithmeticDefinition['resultType'];
  /** The `compile.type` contract of the type, or `undefined` when no head
   * gave one. */
  compileType: ArithmeticCompile['type'];
  /** The heads that declare a kind of this type and are still registered
   * (the LIVE heads). A head stays registered after its scope is popped,
   * because values bound to it can still exist. */
  heads: Set<BoxedOperatorDefinition>;
  /** True when the type was first registered by a library definition while
   * the engine was being constructed. A head declared later cannot give
   * such a type a `resultType` or a `compile.type` that its library heads
   * left out. */
  library: boolean;
}

/**
 * The kind registry of an engine (`boxed-expression/value-kinds.ts`). One
 * per engine, held by `IComputeEngine._kindRegistry`.
 *
 * @internal
 */
export interface KindRegistryState {
  /** The TYPE part: kind type name to its record. */
  types: Map<string, KindTypeRecord>;
  /** The DISPATCH part: a bound operator definition to its arithmetic and
   * to the kind types of its result. Keyed by the definition object, not by
   * the name of the head, so an expression keeps the hooks of the definition
   * it was bound to. */
  dispatch: Map<
    BoxedOperatorDefinition,
    {
      arithmetic: ArithmeticDefinition;
      kindTypes: ReadonlyArray<string>;
      /** The name of the head, for an expression that is not bound to a
       * definition and has only its name. */
      name: string;
    }
  >;
  /** Incremented by every registration, replacement, and removal.
   * A cache of a recognition result stores the generation it was
   * computed under. */
  generation: number;
  /** The kind types for which the engine has constructed a value. */
  withValues: Set<string>;
  /** The kind types for which a symbol of the engine was given a value. */
  withAssignedValues: Set<string>;
  /** The kind types with which a symbol or a callable of the engine was
   * declared. */
  withDeclarations: Set<string>;
}

/**
 *
 * The definition for a value, represented as a tagged object literal.
 * @category Definitions
 *
 */
export type TaggedValueDefinition = {
  value: BoxedValueDefinition;
};

/**
 *
 * The definition for an operator, represented as a tagged object literal.
 *
 * @category Definitions
 *
 */
export type TaggedOperatorDefinition = {
  operator: BoxedOperatorDefinition;
};

/**
 * A definition can be either a value or an operator.
 *
 * It is collected in a tagged object literal, instead of being a simple union
 * type, so that the type of the definition can be changed while keeping
 * references to the definition in bound expressions.
 *
 * @category Definitions
 *
 */
export type BoxedDefinition = TaggedValueDefinition | TaggedOperatorDefinition;

/**
 * One recorded write to a definition's type (or an operator definition's
 * signature): the type the write installed, the mechanism that installed it,
 * and — for writes triggered by canonicalizing an expression — that
 * expression.
 *
 * Provenance can never live on `Type`/`BoxedType` objects themselves: parsed
 * types are interned, deep-frozen, and shared across engines (the
 * `TYPE_CACHE` in `common/type/parse.ts`), so two occurrences of `boolean`
 * are the same object. The history therefore lives on the per-engine
 * definition, next to `inferredType`.
 *
 * Design: `docs/TYPE-SYSTEM.md`, phase 1.
 *
 * @category Definitions
 */
export type TypeProvenanceEntry = {
  /** The type this write installed (for inference writes, the post-fold
   * result, not the raw evidence). */
  type: BoxedType;
  /** How the type was installed:
   * - `'declared'` — an explicit declaration (reserved: declarations
   *   currently record no entry; `inferredType === false` is the marker).
   * - `'auto-declared'` — the binding was *created* as a side effect of
   *   boxing a free symbol or a function parameter, before any evidence.
   * - `'inferred'` — an `_infer()` write: narrowed from an argument use or
   *   widened from a result/value position.
   * - `'value-derived'` — reserved: a type promoted from an assigned
   *   value currently records no entry; `inferredType === true` with a
   *   value is the marker.
   *
   * There is deliberately no kind for an assumption: an assumption never
   * writes a type. It is a FACT the type READ merges into the declared type,
   * and the read heals on its own when the fact is retracted
   * (`docs/plans/2026-08-29-assumptions-as-facts-type.md` §2.5). */
  kind: 'declared' | 'auto-declared' | 'inferred' | 'value-derived';
  /** Which axis of the declaration contract the write touched. Phase 1
   * records only `'type'` (value types and operator signatures); the
   * effects axis (`effectsDeclared`) is the planned second user. */
  axis: 'type' | 'effects';
  /** The expression whose canonicalization triggered the write — the
   * enclosing `And(…)`, call, or arithmetic operation for an inference
   * write; the symbol occurrence itself for an auto-declaration. Kept as an
   * expression (not a rendered string): consumers compare it **by
   * containment** against the expression currently being canonicalized to
   * answer "was this written by the pass running now?" (first-boxing
   * binding-divergence fix, Tycho item 178). Containment, not identity: an
   * auto-declare cause is a symbol OCCURRENCE, so identity against the root
   * being canonicalized is always false — the discriminating test is "is
   * the cause a node within that tree". */
  cause?: Expression;
  /** Original-input span of the cause, when the parse that produced it
   * stamped one. Composed by the caller that knows the base offset — the
   * type parser only ever reports offsets local to the string it was
   * handed. Unset in phase 1. */
  span?: { start: number; end: number };
};

/**
 * @category Definitions
 *
 */
export interface BoxedBaseDefinition extends Partial<BaseDefinition> {
  /** The usage examples of the definition. A definition may give a single
   * string; the boxed definition always stores a list. */
  examples?: string[];

  /** If this is the definition of a collection, the set of primitive operations
   * that can be performed on this collection (counting the number of elements,
   * enumerating it, etc...).
   */
  collection?: CollectionHandlers;
}

/**
 *
 * @category Definitions
 */
export interface BoxedValueDefinition extends BoxedBaseDefinition {
  /** Release resources owned by this definition when its scope is disposed. */
  dispose(): void;

  /** True once `dispose()` has run — the scope that owned this binding has
   * been discarded, so the definition names nothing any more. An assumption
   * recorded against it is about a value that no longer exists.
   * @internal */
  disposed: boolean;

  /** Bumped on every semantic change to this definition (value write, type
   * change, disposal). Used to validate per-dependency caches.
   * @internal */
  _writeVersion: number;

  /**
    * If the symbol has a value, it is held as indicated in the table below.
    * A green checkmark indicate that the symbol is substituted.

  <div className="symbols-table">

  | Operation     | `"never"` | `"evaluate"` | `"N"` |
  | :---          | :-----:   | :----:      | :---:  |
  | `canonical()` |    (X)    |              |       |
  | `evaluate()`  |    (X)    |     (X)      |       |
  | `"N()"`       |    (X)    |     (X)      |  (X)  |

  </div>

    * Some examples:
    * - `ImaginaryUnit` has `holdUntil: 'never'`: it is substituted during canonicalization
    * - `x` has `holdUntil: 'evaluate'` (variables)
    * - `Pi` has `holdUntil: 'N'` (special numeric constant)
    *
    * **Default:** `evaluate`
    */
  holdUntil: 'never' | 'evaluate' | 'N';

  /** The raw body of a macro definition (`ce.declare(name, { macro })`),
   * `undefined` for every other value definition. A macro definition has no
   * value and the type `unknown`. */
  readonly macro?: MathJsonExpression;

  /** The current value of the symbol: the value an `assume(x = …)` puts in
   *  force for the current context if there is one, else the stored value.
   *  For constants, this is immutable.
   */
  value: Expression | undefined;

  /** The value STORED on this definition — what `assign()`, a
   *  `declare(name, { value })` or a library constant put here — with no
   *  assumed value overlaid on it. A definition is USER-VALUED when this is
   *  defined; an assumed value never lands here, so it cannot outlive the
   *  scope that assumed it.
   *  @internal */
  readonly storedValue: Expression | undefined;

  /** For a constant, its value computed again from its definition at the
   *  current precision, and not stored: the value of `Pi` at a precision
   *  that `_withTransientPrecision` set, while `storedValue` keeps the
   *  value at the precision of the engine. `undefined` for a symbol that
   *  is not a constant, and for a constant without a value. Optional so
   *  that the structural mirror of this interface in `types-expression.ts`
   *  does not need it.
   *  @internal */
  _valueAtCurrentPrecision?(): Expression | undefined;

  /**
   * True if the current value refers to the symbol itself (a degenerate
   * self-referential binding, e.g. `a := a + 1` over an unbound `a`). Such a
   * binding forms a cycle: resolving the value would re-resolve the symbol
   * forever. When set, the symbol is treated as unbound during resolution so
   * that `evaluate()`/`.N()`/collection queries stay symbolic instead of
   * overflowing the stack. Computed once when the value is assigned.
   */
  readonly isSelfReferential: boolean;

  eq?: (a: Expression) => boolean | undefined;
  neq?: (a: Expression) => boolean | undefined;
  cmp?: (a: Expression) => '=' | '>' | '<' | undefined;

  /**
   * True if the type has been inferred. An inferred type can be updated as
   * more information becomes available.
   *
   * A type that is not inferred, but has been set explicitly, cannot be updated.
   */
  inferredType: boolean;

  /** The type `declared` with the facts of the current context merged in,
   * as `type` merges them into the declared type. `memoize` is false when
   * `declared` is not the declared type of this definition (the type that a
   * binding unit reads for an occurrence, `binding-unit.ts`).
   * @internal */
  _typeWithFacts(declared: BoxedType, memoize: boolean): BoxedType;

  /** True for a block-local binding hoisted by a `Block` for a `let` or a
   * block-introducing assignment before the statement that gives it a value
   * runs. Not a free mathematical symbol: the generic-symbol fold of a list
   * literal (an unknown bare symbol is a number) does not apply to it.
   * @internal */
  _blockLocal: boolean;
  _programVariable: boolean;

  /** When the declaration's type was a bare collection constructor (`list`,
   * `set`, `dictionary`, `collection`, `indexed_collection` — the forms
   * with an open element type, which admit arbitrary contents), the declared
   * skeleton: the constructor is the
   * CONTRACT (assignments are validated against it and it never moves),
   * while `type` carries the element REFINEMENT the latest assignment
   * produced (`docs/INFERENCE_ROADMAP.md`, Phase 1, ruled 2026-08-18).
   * `undefined` for every other declaration.
   * @internal */
  _placeholderSkeleton: Type | undefined;

  /** When the declaration's type was a function signature with `unknown`
   * slots (such as `(unknown) -> unknown`), the signature as written. The
   * signature that `type` reports is then derived on each read, by refining
   * this skeleton from the current type of the stored function value, and
   * each assignment is checked against the skeleton. `undefined` for every
   * other declaration.
   * @internal */
  _signatureSkeleton: Type | undefined;

  /** True when an assignment to this binding recorded its value type at
   * canonicalization time (`joinAssignmentEvidence`, `library/core.ts`).
   * A use of a valueless binding with this flag does not narrow its type.
   * See `_BoxedValueDefinition._assignmentEvidence`.
   * @internal */
  _assignmentEvidence?: boolean;

  /** Install an element refinement of the placeholder skeleton without
   * disturbing `_placeholderSkeleton` (the public `type` setter maintains
   * the skeleton on every explicit write and would clear it).
   * @internal */
  _setElementRefinement(t: BoxedType): void;

  /** Write the declared type, deriving it inside the write's fact-blind
   * bracket: the thunk and the write both run with the assumptions hidden, so
   * neither the stored type nor the decisions that chose it can carry a fact
   * that a later `forget()` retracts. The public {@link type} setter delegates
   * here, then reports a `type-write` state event. This method reports no
   * event: internal callers report their own.
   * @internal */
  _setType(thunk: () => Type | TypeString | BoxedType): void;

  /** History of writes to this definition's type: which type each write
   * installed, by which mechanism, and — for inference writes — the
   * expression whose canonicalization triggered it. Appended only when a
   * write actually changes the type (no-op re-inferences are skipped by the
   * write sites), so the list stays short; it is capped, keeping the oldest
   * entry and the most recent ones. `undefined` until the first recorded
   * write — an explicitly declared type has no entry (its provenance is the
   * declaration itself, `inferredType === false`), and a type promoted from
   * an assigned value has none either (`inferredType === true` with a
   * value). Used by diagnostics to name the site that committed a
   * conflicting type ("inferred from its use in `And(x, y)`").
   * @internal */
  _typeProvenance: TypeProvenanceEntry[] | undefined;

  /** Annotation provenance on the EFFECTS axis — the effects-axis analog of
   * {@link inferredType} (`docs/EFFECTS-MODEL.md`, "Annotation provenance").
   *
   * True when the declaration STATED the arrow's effects (a non-empty
   * specifier, or the `pure` keyword). False for a bare arrow, which leaves
   * effects on the inferred track: an assigned body's inferred effects are
   * accepted and re-stamped, never checked against the declaration. */
  effectsDeclared: boolean;

  /** Snapshot the coupled type/value slots for an exact later restore via
   * {@link _restoreTypeSlots}. The result is OPAQUE — it captures private
   * fields, including states the public setters cannot express — so it is
   * typed `unknown` and only meaningful when handed back unchanged.
   * @internal */
  _typeSlotSnapshot(): unknown;

  /** Restore the slots captured by {@link _typeSlotSnapshot}, verbatim and
   * setter-bypassing (the `type` setter is a computed view whose `unknown`
   * write wipes the value — a faithful restore cannot go through it).
   * Bumps `_writeVersion` rather than restoring it: monotone invalidation
   * counters only advance. Phase 2a of
   * `docs/TYPE-SYSTEM.md`.
   * @internal */
  _restoreTypeSlots(snapshot: unknown): void;

  /** Snapshot EVERY mutable field of this record, so that a restore can put
   * them back IN PLACE: `ce.withValues()` (`withValuesFn`,
   * `engine-declarations.ts`). Wider than
   * {@link _typeSlotSnapshot}, which covers only the slots an inference
   * re-derivation moves. Opaque, for the same reason.
   * @internal */
  _fieldSnapshot(): unknown;

  /** Restore the fields captured by {@link _fieldSnapshot}, verbatim and
   * setter-bypassing. Never replaces the record object: live boxed
   * expressions hold it by identity.
   * @internal */
  _restoreFieldSnapshot(snapshot: unknown): void;

  /** The type known in the CURRENT state: {@link declaredType} narrowed by
   * everything the assumptions in force prove about this definition. Reading
   * it is what makes a fact visible; nothing derived from it may be STORED
   * (see {@link declaredType}). Writing it reports a `type-write` state
   * event, so cached results that read this type are computed again. */
  type: BoxedType;

  /** The type this definition DECLARES — its contract, built from the
   * declaration and the stored value alone and never from an assumption.
   * A write must read this rather than {@link type}: a type derived from a
   * fact and then stored would outlive the fact it was proved from.
   * @internal */
  readonly declaredType: BoxedType;

  /**
   * Custom evaluation handler for subscripted expressions of this symbol.
   * Called when evaluating `Subscript(symbol, index)`.
   */
  subscriptEvaluate?: (
    subscript: Expression,
    options: { engine: ComputeEngine; numericApproximation?: boolean }
  ) => Expression | undefined;
}

/**
 * A shape of operand (or result) whose broadcast handling an operator's own
 * handlers provide, exempting it from the generic broadcast machinery. See
 * {@link OperatorDefinitionFlags | OperatorDefinitionFlags.broadcastExemptions} for the meaning of
 * each label.
 * @category Definitions
 */
export type BroadcastExemption =
  | 'tensors'
  | 'tuples'
  | 'collection-result'
  | 'evaluated-operands'
  | 'whole-collection-compare'
  | 'single-collection-join'
  | 'surplus-operands';

/**
 * The role of one operand of an operator, as the `operands` handler of
 * {@link OperatorDefinitionFlags} declares it. The role says how the operand
 * is canonicalized and whether it is evaluated before the `evaluate` handler
 * of the operator runs.
 *
 * - `value`: the operand is a value, and an `Assign` or a `Declare` there is
 *   an error. In an operator that is not `lazy`, the operand is
 *   canonicalized, checked against the signature, and evaluated before the
 *   `evaluate` handler runs; this is the default role of such an operator.
 *   In a `lazy` operator, the handlers receive the operand as written and
 *   canonicalize and evaluate it themselves; only a bare `N` or `D` there is
 *   read as a variable, not as the library operator.
 * - `held`: the operand is a value that the `evaluate` handler receives as
 *   its canonicalization left it, not evaluated, so that the handler can
 *   read it as written (`Fibonacci(10^6)` in `Mod(Fibonacci(10^6), p)`) and
 *   evaluate it itself when it needs its value. Otherwise the operand is a
 *   `value`: it is canonicalized and checked against the signature, the
 *   type and the validity of the application read it, an `Assign` or a
 *   `Declare` there is an error, and a literal list there is broadcast, each
 *   element held. An operand that only its evaluation makes a list is held
 *   whole. Valid only on an operator that is not `lazy`: a `lazy` operator
 *   canonicalizes none of its operands, and its handlers receive every
 *   operand unevaluated (`raw`).
 * - `statement`: the operand is a statement that the operator runs, zero,
 *   one or several times (the body of a loop, a branch of a conditional). An
 *   `Assign` there is valid. The operand is not evaluated
 *   before the `evaluate` handler runs: the handler evaluates it when and as
 *   often as it needs to. The engine canonicalizes the operand as a branch,
 *   except in a `lazy` operator with a `canonical` handler, which receives
 *   it as written and canonicalizes it itself. In a branch, a `Declare` is
 *   the error `declaration-below-statement`, an assignment of a name that
 *   no enclosing scope declares is the error
 *   `assignment-to-undeclared-variable`, an assignment of a declared name
 *   writes that name, and a bare `Break` or `Continue` symbol is an error.
 * - `raw`: the operand is kept as written, not canonicalized and not
 *   evaluated. The default of a `lazy` operator. Valid only on a `lazy`
 *   operator.
 * - `opaque`: the operand is kept as written, and an `Assign` or a `Declare`
 *   in it is valid (the expression of `Hold` and of `Error`). Valid only on a
 *   `lazy` operator.
 * - `bound`: the operand is a bound variable of the operator, a symbol
 *   that the operator declares in its own scope (the variable of `D(f, x)`,
 *   the expansion variable of `Series`), with the type `type` (`unknown`
 *   when it is left out). A symbol held in a `Hold` is a bound variable
 *   too; any other operand declares nothing. The variable remains a free
 *   variable of the expression, as for `D`: the value of `D(x^2, x)` is a
 *   function of `x`. The operand is not evaluated before the `evaluate`
 *   handler runs; it is kept as written in a `lazy` operator, and
 *   canonicalized in the scope of the operator otherwise.
 * - `clause`: the operand is an indexing set whose index is a bound
 *   variable of the operator: `Limits(k, 1, 10)`, `Element(k, S)` (a
 *   tuple pattern `Element(Tuple(p, q), S)` binds each of its names), a
 *   tuple `Tuple(k, 1, 10)` or `Triple(k, 1, 10)`, a set `Set(k, 1, 10)`,
 *   a parenthesized tuple of the LaTeX parser, or a symbol, also held.
 *   `type` is the type of the index of a range-shaped clause. When `type`
 *   is `integer` and the bounds are integer literals, the index has the
 *   ranged type (`integer<1..10>` for `Limits(k, 1, 10)`); any other
 *   `type` is used as given. The index of an `Element` clause does not
 *   take `type`: it is `integer<a..b>` for a range `Range(a, b)` with
 *   integer literal bounds, and otherwise an inferred `unknown` that a
 *   `canonical` handler can narrow from the collection. The index is not a
 *   free variable of the expression. It is visible in its own clause, in
 *   the later clauses and in the operands before the first clause (the
 *   body), not in an earlier clause. Consecutive `clause` operands are read as the clauses of
 *   `Sum`, with the flat spelling: in `Sum(body, k, 1, 10)` the operands
 *   after the symbol `k` are its bounds, not indexes. An operand that holds
 *   no index declares nothing. The operand is not evaluated before the
 *   `evaluate` handler runs, and is canonicalized as a `bound` operand is.
 *
 * An operator whose `operands` handler gives a `bound` or a `clause` role
 * is a **binder**: it has its own scope, as with `scoped: true`, and the
 * engine declares each bound variable in that scope before it canonicalizes
 * the other operands, so that the parse, `ce.box()` and `ce.function()`
 * routes bind the same variable. The engine finds that the operator is a
 * binder when it is declared (see the `operands` handler of
 * {@link OperatorDefinitionFlags}).
 *
 * @category Definitions
 */
export type OperandRole =
  | { kind: 'value' }
  | { kind: 'held' }
  | { kind: 'statement' }
  | { kind: 'raw' }
  | { kind: 'opaque' }
  | { kind: 'bound'; type?: TypeString }
  | { kind: 'clause'; type?: TypeString };

/**
 * An operator definition can have some flags to indicate specific
 * properties of the operator.
 * @category Definitions
 */
export type OperatorDefinitionFlags = {
  /**
   * If `true`, the arguments to this operator are not automatically
   * evaluated. The default is `false` (the arguments are evaluated).
   *
   * This can be useful for example for operators that take symbolic
   * expressions as arguments, such as `Declare` or `Integrate`.
   *
   * This is also useful for operators that take an argument that is
   * potentially an infinite collection.
   *
   * It will be up to the `evaluate()` handler to evaluate the arguments as
   * needed. This is convenient to pass symbolic expressions as arguments
   * to operators without having to explicitly use a `Hold` expression.
   *
   * This also applies to the `canonical()` handler.
   *
   * To keep only a statement operand unevaluated (a body that the
   * `evaluate` handler runs), give it the `statement` role with `operands`
   * instead. To keep a value operand unevaluated and keep the checks of an
   * operator that is not lazy (signature, type, broadcast), give it the
   * `held` role.
   *
   */
  lazy: boolean;

  /**
   * The role of each operand of an application of this operator: one
   * {@link OperandRole} per operand, in operand order. The handler receives
   * the operands of the application: as written when the application is
   * canonicalized, and canonical when it is evaluated. So the roles should
   * depend only on the number of operands and on their positions. A role
   * that the handler leaves out (a shorter array) is the default role. When
   * the operator is declared, the handler is also called with zero to three
   * `Nothing` operands, so that a role that is not valid is refused then:
   * the handler must have no side effects, and an exception that it throws
   * on these operands is ignored.
   *
   * Without this handler, every operand of an operator that is not `lazy`
   * is a `value`, and every operand of a `lazy` operator is `raw`.
   *
   * An `Assign`, an `AddTo` or a `Declare` operand at a `value`, `held` or
   * `raw` position is the error `assignment-in-operand`: an assignment is a
   * statement, not a value. At a `statement` or an `opaque` position it is
   * valid.
   *
   * A `bound` or a `clause` role makes the operator a binder (see
   * {@link OperandRole}). The engine finds it from the calls with the
   * placeholder operands, so the handler must give these roles for one of
   * them, as a handler that gives one role per position does
   * (`(ops) => ops.map((_, i) => …)` with two `Nothing` operands, or a
   * fixed array). A `bound` or a `clause` role that the handler gives only
   * for the operands of an application is refused with an error. The
   * bound variables are declared before the other operands are
   * canonicalized; a `statement` operand is then canonicalized in the scope
   * of the operator, where an assignment of a bound variable writes that
   * variable.
   *
   * When the operator has no `canonical` handler, the engine canonicalizes
   * each `statement` operand as a branch (see {@link OperandRole}). When it
   * has one, a `lazy` operator's handler receives the statement operands as
   * written and canonicalizes them itself; the handler of an operator that
   * is not `lazy` receives them already canonicalized as branches.
   *
   * The `evaluate` handler of an operator that is not `lazy` receives the
   * `value` operands evaluated and the other operands canonical but not
   * evaluated. The `evaluate` handler of a `lazy` operator receives no
   * operand evaluated: a `value` operand is as written, and a `statement`
   * operand is as its canonicalization left it. This applies under
   * `evaluate()`, `N()` and `evaluateAsync()`; under `evaluateAsync()` a
   * handler that evaluates a `held` operand evaluates it synchronously.
   *
   * ```ts
   * ce.declare('Do', {
   *   signature: '(expression, integer) -> nothing',
   *   // The body is a statement, the count is a value.
   *   operands: () => [{ kind: 'statement' }, { kind: 'value' }],
   *   evaluate: ([body, n], { engine }) => {
   *     for (let i = 0; i < n.re; i++) body.evaluate();
   *     return engine.Nothing;
   *   },
   * });
   *
   * ce.declare('ModP', {
   *   signature: '(integer, integer) -> integer',
   *   // The handler reads `Fibonacci(n)` before it is evaluated, and
   *   // computes it modulo `p`.
   *   operands: () => [{ kind: 'held' }, { kind: 'value' }],
   *   evaluate: ([x, p], { engine }) => {
   *     if (x.operator === 'Fibonacci') return fibonacciMod(x.op1, p);
   *     return engine.function('Mod', [x.evaluate(), p]).evaluate();
   *   },
   * });
   *
   * ce.declare('MySum', {
   *   lazy: true,
   *   signature: '(any, any+) -> number',
   *   // The body is kept as written; each later operand is an indexing set
   *   // whose index is an integer bound in the scope of `MySum`.
   *   operands: (ops) =>
   *     ops.map((_, i) =>
   *       i === 0 ? { kind: 'raw' } : { kind: 'clause', type: 'integer' }
   *     ),
   *   evaluate: ([body, ...clauses], { engine }) =>
   *     engine.function('Sum', [body, ...clauses]).evaluate(),
   * });
   * ```
   *
   * **Default**: `undefined`
   */
  operands?: (ops: ReadonlyArray<Expression>) => ReadonlyArray<OperandRole>;

  /**
   * If `true`, the operator requires a new lexical scope when canonicalized.
   * This will allow it to declare variables that are not visible outside
   * the function expression using the operator (`Block`).
   *
   * An operator that binds variables of its operands (the index of `Sum`,
   * the variable of `D`) declares them with the `bound` and `clause` roles
   * of the `operands` handler instead: these roles give the operator a
   * scope, and `scoped` need not be given. A function (a binding-site
   * selector of an earlier version) is refused with an error.
   *
   * **Default**: `false`
   */
  scoped: boolean;

  /**  If `true`, the operator is applied element by element to lists, matrices
   * (`["List"]` or `["Tuple"]` expressions) and equations (relational
   * operators).
   *
   * **Default**: `false`
   */
  broadcastable: boolean;

  /**
   * Operand and result shapes whose broadcast handling this operator's OWN
   * handlers provide. The generic broadcast machinery — the pre- and
   * post-evaluation element-wise fan-out and the result-type lift — must not
   * apply to a shape listed here; the operator's `evaluate` and `type`
   * handlers give those operands their dedicated semantics instead.
   *
   * - `'tensors'`: tensor and matrix operands route to the operator's own
   *   tensor arms (e.g. the matrix PRODUCT for `Multiply`, not an
   *   element-wise Hadamard map).
   * - `'tuples'`: numeric tuples (points/vectors in ℝⁿ) are combined
   *   component-wise by the handler, never fanned into a `List`.
   * - `'collection-result'`: the type handler computes its own
   *   collection-shaped result types (e.g. `matrix + scalar` is a `matrix`);
   *   the generic result-type lift must not re-wrap them.
   * - `'evaluated-operands'`: the `evaluate` handler owns the element-wise
   *   treatment of operands that only become collections at evaluation; the
   *   generic post-evaluation broadcast arm must not re-map them.
   * - `'whole-collection-compare'`: two or more collection operands are
   *   compared as WHOLE values (a scalar boolean); only the
   *   collection-vs-scalar case broadcasts element-wise.
   * - `'single-collection-join'`: a lone collection operand is consumed
   *   whole by the `evaluate` handler (e.g. joined), never mapped over.
   * - `'surplus-operands'`: a call that holds more operands than the
   *   signature admits (a `canonical` handler that builds the call with
   *   `_fn` keeps every operand, for a user definition that reads the
   *   extra ones as options) is handed WHOLE to the `evaluate` handler,
   *   which refuses it with one `unexpected-argument` error; the generic
   *   broadcast never fans such a call over a surplus collection operand
   *   (`Denominator(5, [])` is the error, not `[]`). Not for an operator
   *   that is n-ary at run time beyond its declared signature, such as a
   *   chained `Equal`, which must keep broadcasting.
   *
   * **Default**: `[]` — the generic broadcast machinery applies uniformly
   * whenever `broadcastable` is `true`.
   */
  broadcastExemptions: ReadonlyArray<BroadcastExemption>;

  /**
   * Whether a CONDITIONAL VALUE in an operand — a restriction
   * `["If", condition, value]` or a piecewise `["Which", …]` whose
   * condition is not decided yet — moves out of the application:
   * `f(If(c, v))` evaluates to `If(c, f(v))`, and `f(Which(c₁, v₁, …))`
   * to `Which(c₁, f(v₁), …)`.
   *
   * A broadcastable operator already does this (except the logical
   * connectives, which are not strict). Set this flag on an operator that is
   * NOT broadcastable but reads a whole value, such as a point or a vector,
   * so that it gets the same treatment without code of its own. Without the
   * flag, the handler receives the restriction itself, which is not a point or a
   * collection, and usually answers an `incompatible-type` error.
   *
   * - `true` — every operand position threads.
   * - an array of 0-based positions — only these positions thread. Use this
   *   when another position is not a value the function is applied to: `At`
   *   threads its collection (position `0`) and not its indices, and `Norm`
   *   threads its operand and not its order.
   *
   * The engine also recognizes the form a restricted LIST takes after
   * evaluation. With the condition undecided, `If(c, [a, b])` evaluates to
   * the list of restricted cells `[If(c, a), If(c, b)]`. When every cell
   * of a `List` in a threaded position has the same condition, the list is
   * read as `If(c, [a, b])` and the condition moves out as above. A list
   * whose cells have different conditions, or only some of them a condition,
   * is given to the handler as it is: only the operator knows whether it
   * maps over the cells (a list of points) or reads the list whole (a
   * vector).
   *
   * The rules that apply are those of broadcastable operators:
   * - The type of the application, when a threaded operand can be absent as
   *   a whole (its type has a `missing` arm, as the type of a restriction does),
   *   is computed from the operand without the `missing` arm. The `missing`
   *   arm then goes to the result as for a `propagate` operator: it is kept
   *   when the result is not a number, and replaced by `NaN` when it is. For
   *   a `handle` operator the result keeps a `missing` arm: the handler is
   *   expected to answer `Missing` for an absent operand, as `At` and
   *   `First` do.
   * - When the condition is decided, nothing threads: the operand is its
   *   value, or `Missing`, and `missingBehavior` decides what an absent
   *   operand gives. Declare `missingBehavior` too (`propagate` or
   *   `handle`): with the default for a signature that is not all-numeric,
   *   an absent operand is an `incompatible-type` error.
   * - A `Which` distributes over at most 16 combinations of branches;
   *   past that the application is given to the handler unchanged.
   * - A `Which` that has a list of conditions selects at each position, so
   *   its value is a list, and it does not distribute: when it cannot be
   *   evaluated to a list, the handler receives it unchanged. With `foo`
   *   undeclared, `Length(Which([True, False], foo(L), True, 0))` stays held.
   *
   * For example, with `t` free, `PointX(If(0 < t, (1, 2)))` is
   * `If(0 < t, 1)`, which is `1` when `t = 2` and `NaN` (the marker of the
   * numeric coordinate) when `t = -1`.
   *
   * **Default**: `false`
   */
  threadsConditionals: boolean | number[];

  /**
   * If `true`, this operator's `evaluate` handler runs even when the
   * expression is **invalid** — that is, when an operand is, or embeds, an
   * `Error` value.
   *
   * These are the non-strict *observers* of the error-propagation design
   * (`docs/LANGUAGE-MODEL.md`): operators that
   * INSPECT their operands (`Match`, `Type`, `IsError`) or that are
   * application plumbing deciding what to do with an error operand (`Apply`,
   * `Pipe`). Every other operator freezes to its inert self when an operand
   * carries an error, which is what stops an error at the first strict
   * consumer.
   *
   * **Default**: `false`
   */
  inspectsErrors: boolean;

  /**
   * If `true`, this operator DECIDES AT EVALUATION which of its held operands
   * to evaluate — `If` takes one arm, `Which` takes one clause, `And`/`Or`
   * stop at the decisive operand, `Coalesce` stops at the first present one.
   *
   * **Only valid on a `lazy` operator** (asserted in
   * `_BoxedOperatorDefinition`). A strict operator's operands are all
   * evaluated before its handler runs, so there is nothing left for it to
   * select, and the deferred absorption this flag turns on would only stop
   * its operand errors from bubbling.
   *
   * The consequence for the error model: an `Error` in an operand such an
   * operator does not choose is DEAD CODE, so it must not make the
   * application fail. `If(True, 5, <error>)` evaluates to `5`
   * (`docs/ERROR-MODEL.md` §3, the demanded-operands rule). Absorption is
   * therefore deferred past the handler for these operators instead of
   * happening before it, and an error the handler DID demand still bubbles,
   * because it comes back embedded in the handler's result.
   *
   * The obligation this places on the handler: an operand it demands and
   * finds to be an error must be RETURNED, not thrown on and not swallowed.
   * `If` and `Which` answer their condition's error explicitly for that
   * reason. Do not set this flag on an operator that demands all of its
   * operands — pre-absorption is both correct and cheaper there — and do not
   * set it on an operator whose handler quietly answers something else (a
   * `Nothing`, a rebuilt node) when an operand it demanded is unusable.
   *
   * **Default**: `false`
   */
  selectsOperands: boolean;

  /**
   * If `true`, this `lazy` operator's `evaluate` handler only EVALUATES its
   * held operands (with the options it receives) and reads nothing else of
   * their structure, so the asynchronous route may evaluate them for it.
   *
   * **Only valid on a `lazy` operator** (asserted in
   * `_BoxedOperatorDefinition`). A lazy operator with a synchronous handler
   * and no `evaluateAsync` runs its operands to the end under
   * `evaluateAsync()`: `Less(Sum(1/k^2, k, 1, 400000), 2)` neither yields
   * nor honors an abort signal. With this flag, the asynchronous route
   * awaits each held operand with `evaluateAsync()`, in operand order, and
   * then runs the synchronous handler on the values, so the sum yields.
   *
   * The contract on the handler: it demands every operand and evaluates it,
   * and does nothing else with the operand as written. A handler that reads
   * the structure of an operand (`Numerator`, `Interpret`, `IsSame`), or that
   * treats an evaluated operand differently from the one as written, must
   * not set it. A handler that stops before it has evaluated every operand
   * (a chain `a < b < c` that stops at the first `False` pair) must not set
   * it either: the route evaluates all of them first. Such an operator
   * declares an `evaluateAsync` handler instead (the four chainable
   * relations do). On this route a handler that answers `undefined` ("leave
   * the expression as it is") leaves the operator over the VALUES of its
   * operands, where the synchronous route leaves it over the operands as
   * written: a handler that sets the flag must answer the same on both
   * routes, as an inert comparison does (`inertRelation`). An operand whose
   * value is absent (`Missing`) is handed to the handler as written, since
   * what the absence means depends on the declared type of that operand.
   * Two further limits, for now: an operator that is `selectsOperands`,
   * `scoped` or `holdClass: 'quote'` never takes this route, and the route
   * is skipped under a numeric evaluation (`N()`), where a handler may need
   * the exact operand to decide a tie.
   *
   * **Default**: `false`
   */
  evaluatesOperands: boolean;

  /**
   * Whether every argument of an application MUST be written with its
   * parameter's name (`Person(firstName: "Alan", age: 42)`).
   *
   * A positional call to such an operator is rejected with
   * `argument-names-required`, naming the parameters in order so the author
   * can add the names. Names make the call order-free, so a named call may
   * list the arguments in any order.
   *
   * The one operator class that sets it today is the object-type constructor:
   * an object type's fields are often several of the same type (`Person` has
   * two adjacent `string` fields), and a positional call that transposed two
   * of them would be accepted silently and produce a wrong object with no
   * error anywhere (`docs/TYPE_SYSTEM_ROADMAP.md` Appendix B, "Declaring an
   * object type", ruling B11).
   *
   * The check runs in the canonicalization seam that normalizes named
   * arguments (`box.ts`), because that is the last point at which named and
   * positional calls are still distinguishable: normalization rewrites a
   * named call into declaration order, after which the handlers see the same
   * operands either way.
   *
   * **Default**: `false`
   */
  namedArgumentsRequired: boolean;

  /**
   * How this operator treats an absent (`Missing`) operand, per the
   * missing-value typing design
   * (`docs/TYPE-SYSTEM.md`). The
   * declarable states are:
   *
   * - `'propagate'` — the signature is implicitly lifted `(A) -> B` to
   *   `(A | missing) -> B`; an absent operand cell yields `NaN` in the
   *   corresponding numeric result cell (arithmetic, transcendentals,
   *   `Power`/`Root`).
   * - `'handle'` — the operator owns its `Missing` result and runtime (`At`,
   *   the reducers, `Coalesce`, `IsMissing`, `Equal`).
   * - `'reject'` — an absent operand is an error, enforced in both strict and
   *   non-strict modes.
   *
   * If undeclared, the *resolved* behavior is `'propagate'` when the signature
   * is declared (not inferred) and every parameter type is numeric, otherwise
   * `'pass-through'` (no strip, ordinary validation). See
   * {@link BoxedOperatorDefinition.resolvedMissingBehavior}.
   */
  missingBehavior?: 'reject' | 'propagate' | 'handle';

  /**
   * Which parameter positions strip a `missing` arm before validation (§3.A).
   * `'all'` (the default where the resolved behavior is `propagate`/`handle`)
   * strips every position; a `number[]` strips only the listed 0-based
   * positions. Consumed identically by validation, typing, and the runtime
   * gate.
   */
  missingStrip: 'all' | number[];

  /**
   * How this operator treats a `NaN` argument, per Contract B of
   * `docs/ERROR-MODEL.md` §4 (ratified 2026-08-27). Symmetric with
   * `missingBehavior`:
   *
   * - `'propagate'` — a `NaN` in the slot makes the application evaluate to
   *   `NaN`.
   * - `'handle'` — the handler sees the `NaN` and answers in its own
   *   codomain (membership predicates: `IsPrime(NaN)` → `False`). Always an
   *   explicit opt-in — a boolean codomain never implies the handler
   *   understands `NaN`.
   * - `'reject'` — a `NaN` in the slot is a contract violation → `Error`
   *   (an index, a digit count, a dimension).
   *
   * A single value applies to every parameter slot; an array gives per-slot
   * values (a hole falls back to the derived default).
   *
   * If undeclared, the *resolved* per-slot policy is derived mechanically
   * from the signature — see
   * {@link BoxedOperatorDefinition.resolvedNanBehaviorAt}. While the slot's
   * declared carrier still ADMITS `nan` (bare `number`, `any`, a union with
   * `nan`), the policy channel is inert: `NaN` is an ordinary domain member
   * there and the handler owns it, which is the status quo for every
   * operator that has not yet migrated to a precise Contract B carrier.
   */
  nanBehavior?:
    | 'reject'
    | 'propagate'
    | 'handle'
    | ReadonlyArray<'reject' | 'propagate' | 'handle' | undefined>;

  /**
   * The partiality declaration of Contract B (`docs/ERROR-MODEL.md` §4):
   * does membership in the carrier types prove success?
   *
   * - `'total'` — every argument inside the carriers has a successful
   *   result, on the numeric route as well (the value's float image is
   *   representable). A strong claim; opt in only when it is true.
   * - `'may-marker'` — a domain or numeric-route failure is possible
   *   without naming the condition. **The default when omitted** — the
   *   sound assumption for every operator.
   *
   * An operator that can NAME its domain condition declares `definedWhen`
   * instead; declaring both `partiality: 'total'` and `definedWhen` is a
   * definition error.
   */
  partiality?: 'total' | 'may-marker';

  /**
   * The named *mathematical* domain condition of Contract B: the arguments
   * for which this operator has a value (`Mod`: the divisor is not zero).
   * `false` routes to the codomain marker channel (rule 4 of
   * `docs/ERROR-MODEL.md` §2), never to `Error`; `undefined` means the
   * condition cannot be decided for these arguments (unbound symbols).
   * Declaring it supersedes `partiality` (the partiality IS this
   * predicate).
   *
   * CONTRACT: the predicate runs inside the cached `.type` derivation as
   * well as at evaluation, so it must be PURE — no engine-state writes, no
   * evaluation of its operands — and must decide from the operands'
   * canonical structure and static types alone (it receives CANONICAL,
   * unevaluated operands; answer `undefined` for anything it cannot read
   * that way). A thrown exception is treated as `undefined`, never
   * propagated.
   */
  definedWhen?: (ops: ReadonlyArray<Expression>) => boolean | undefined;

  /**
   * A *contract* precondition of Contract B: a well-formedness requirement
   * on the arguments that is not a mathematical domain condition
   * (`MatrixMultiply`: the inner dimensions agree; an option value in
   * range). `false` routes to the `Error` channel (rule 6 of
   * `docs/ERROR-MODEL.md` §2); `undefined` means undecidable for these
   * arguments. The purity contract of `definedWhen` applies to this
   * predicate identically.
   */
  requires?: (ops: ReadonlyArray<Expression>) => boolean | undefined;

  /** If `true`, `["f", ["f", a], b]` simplifies to `["f", a, b]`
   *
   * **Default**: `false`
   */
  associative: boolean;

  /** If `true`, `["f", a, b]` equals `["f", b, a]`. The canonical
   * version of the function will order the arguments.
   *
   * **Default**: `false`
   */
  commutative: boolean;

  /**
   * If `commutative` is `true`, the order of the arguments is determined by
   * this function.
   *
   * If the function is not provided, the arguments are ordered by the
   * default order of the arguments.
   *
   */
  commutativeOrder: ((a: Expression, b: Expression) => number) | undefined;

  /**
   * If `true`, `match()` tries permutations of the operands when a pattern
   * uses this operator — WITHOUT the canonical operand sort that
   * `commutative` implies. For an operator whose VALUE is commutative but
   * whose operand ORDER is part of the program (the short-circuit
   * `And`/`Or`: evaluation is left-to-right and the canonical form
   * preserves written order), this restores permutation matching on its
   * own, so a rule pattern `p ∧ ¬p` still hits `¬p ∧ p`.
   *
   * **Default**: the value of `commutative`.
   */
  commutativeMatch: boolean;

  /** If `true`, when the operator is univariate, `["f", ["Multiply", x, c]]`
   * simplifies to `["Multiply", ["f", x], c]` where `c` is constant
   *
   * When the operator is multivariate, multiplicativity is considered only on
   * the first argument: `["f", ["Multiply", x, y], z]` simplifies to
   * `["Multiply", ["f", x, z], ["f", y, z]]`
   *
   * Default: `false`
   */

  /** If `true`, `["f", ["f", x]]` simplifies to `["f", x]`.
   *
   * **Default**: `false`
   */
  idempotent: boolean;

  /** If `true`, `["f", ["f", x]]` simplifies to `x`.
   *
   * **Default**: `false`
   */
  involution: boolean;

  /** If `true`, the value of this operator is always the same for a given
   * set of arguments and it has no side effects.
   *
   * An expression using this operator is pure if the operator and all its
   * arguments are pure.
   *
   * For example `Sin` is pure, `Random` isn't.
   *
   * This information may be used to cache the value of expressions. For an
   * operator that the host declares (with `ce.declare()`, in a library
   * passed to the constructor, with `ce.loadLibrary()`, or a JavaScript
   * function assigned with `ce.assign()`), a value is cached only when the
   * declaration states its purity: `pure: true` (or `pure: false`),
   * `drawsRandom: true`, an `effects` set, or an effect specifier on the
   * signature; `drawsRandom: false` alone states nothing. An extension
   * (`ce.declare(name, patch, { extend: true })`) that states nothing about
   * purity keeps the statement of the operator that it extends.
   *
   * An operator that states nothing is pure by default for the effects
   * model, but it is evaluated at each occurrence, on the synchronous and
   * the asynchronous routes, and each call of one of its collection
   * handlers (`at`, `iterator` and each step of the iterator, `count`, …)
   * is host code too. So is each call of a host callback of a protocol
   * implementation, of a `subscriptEvaluate` handler that the host gives,
   * and of a host `evaluateAsync` handler of a user function on the
   * asynchronous route. No memo of the engine keeps a result computed while
   * such host code ran: the shared subexpressions, the applications of a
   * function literal, the lazy collection and inert values, the collection
   * elements, the `count`/`isEmpty`/`isFinite` of a collection, the value
   * that `at()` reads for a function expression with no collection
   * handlers, the bounds of a slice, the values of symbols, the terms of
   * sequences, the exact zeros and parts of the series and residue code, the
   * approximations of the comparisons, the compiled probes of `Limit`, the
   * compiled functions of `Map`, and the source values that the finiteness
   * test of a lazy view shares with its operand step. The compiler does not skip the calls of
   * its `compile` handler. A handler of a host operator that changes state
   * (an assignment, also from a collection handler) stops these memos too,
   * even when the operator states `pure: true`. The other hooks of a
   * definition (`canonical`, `type`, `sgn`, `eq`, `neq`, `even`,
   * `canEnumerate`, `elementCount`, `elementAt`, `derivative`, `compile`,
   * and the collection handlers `isCollection`, `isLazy`, `isEnumerable`,
   * `eltsgn` and `elttype`) describe the operator and are not counted.
   *
   * **Default:** `true`
   *
   * As an **authoring input** this flag is sugar for an effect set, translated
   * once at registration (see the `effects` flag of {@link OperatorDefinitionFlags} and the
   * truth table in `docs/EFFECTS-MODEL.md`, "One source of truth"). As
   * **readable state on a boxed definition** it is a *derived* getter: "no
   * impurity label is present in the operator's effect set".
   */
  pure: boolean;

  /**
   * The latent effects of applying this operator — the precise surface the
   * `pure` / `drawsRandom` flags are sugar for. See `docs/EFFECTS-MODEL.md`.
   *
   * `'any'` is the top ("unknown effects"); an array of labels is a finite
   * set; absent means **pure** (the empty set). May equivalently be written in
   * the specifier slot of a signature string —
   * `'(integer) random -> integer'`.
   *
   * Giving both this field (or an effect-annotated signature) and legacy
   * `pure` / `drawsRandom` flags that disagree is a **registration error**,
   * never silent precedence.
   */
  effects: EffectSet | undefined;

  /**
   * Annotation provenance (`docs/EFFECTS-MODEL.md`, "Annotation provenance"):
   * `true` when the AUTHOR supplied the `effects` flag of {@link OperatorDefinitionFlags} or
   * an effect-bearing signature specifier, `false` when the effect set came
   * from the body inference.
   *
   * A **declared** set is a contract: a user function's inferred effects must
   * be a subset of it, or the definition is not installed. An inferred set is
   * not checked against itself. The legacy `pure` / `drawsRandom` flags do NOT
   * set this — they are an override, not a contract.
   *
   * The bit lives on the definition, not in the type AST, which keeps its
   * single optional `effects` field ("absent = pure").
   */
  effectsDeclared: boolean;

  /**
   * The **frame protocol** this operator delimits — the runtime role that is
   * NOT an effect of its own (a delimiter absorbs the effects of its body
   * rather than emitting them). Kind-valued, not boolean: `'seed'` — the
   * random-stream frame delimited by `WithRandomSeed` — is the only kind
   * today, and a future `WithClock` would name its own.
   *
   * Consumed by the frame kind's obligation protocol (for `'seed'`: the
   * pending-draw walk in `library/core.ts`), and by the derived
   * `drawsRandom` getter of {@link OperatorDefinitionFlags}.
   *
   * **Default:** none
   */
  frameProtocol: 'seed' | undefined;

  /**
   * Which operand positions may **invoke** a function-valued operand
   * (`docs/EFFECTS-MODEL.md`, "Projection and discharge"). A position that
   * does not invoke merely *stores* or *selects* the value, so it contributes
   * only the effects of *producing* the operand, never the operand's latent
   * (arrow) effects — `List(randomF)` is pure to build, and the effect
   * surfaces at whatever application later invokes an element.
   *
   * Two spellings, mirroring {@link discharges}' operand-index-map convention:
   *
   * - a **boolean**, uniform over every position: `false` for the pure
   *   containers and constructors (`List`, `Tuple`, the structural
   *   constructors), for the storing writers (`Assign`, `Declare`) and for the
   *   selecting conditionals (`If`, `Which`);
   * - a **map** from 0-based operand index to a boolean, for an operator that
   *   invokes at some positions and stores at others. **Missing indices
   *   default to `true`** — the conservative answer.
   *
   * **Default:** `true`
   */
  invokes: boolean | { readonly [operandIndex: number]: boolean };

  /**
   * The effects this operator **absorbs** rather than re-emits, per operand
   * position: a map from 0-based operand index to the labels discharged at
   * that position (`docs/EFFECTS-MODEL.md`, "Projection and discharge").
   *
   * `WithRandomSeed` is the canonical discharger: `{ 1: ['random'] }` on its
   * held body position, so `WithRandomSeed(42, Random())` computes the empty
   * set while `WithRandomSeed(42, Block(Assign(x, 1), Random()))` computes
   * `{scope}`.
   *
   * The discharge set must be a subset of the position's accepted-effects
   * **bound** — a function parameter's signature arrow, or (for a held
   * position) a declared bound on the held evaluation, which defaults to
   * `{any}`, making every finite discharge admissible today.
   *
   * What is discharged, and what is not: only the **latent** set of an eager
   * function-valued operand (the effects that fire if the operator invokes it)
   * and the effects of a **held, may-evaluate** operand — evaluation that
   * happens *under* the operator. The effects of *producing* an eager operand
   * are never dischargeable: they fire when the operand is evaluated,
   * whatever the operator then does with the result.
   *
   * Discharging from an operand whose effects are `'any'` yields an internal
   * **co-finite** value ¬D (see `common/type/effects.ts`).
   *
   * **Default:** discharge nothing — propagation is the sound default.
   */
  discharges:
    { readonly [operandIndex: number]: readonly EffectLabel[] } | undefined;

  /**
   * How a **held** (`lazy`) operand position is treated by the projection rule
   * (`docs/EFFECTS-MODEL.md`, "Projection and discharge", the held-operand
   * clause):
   *
   * - `'evaluate'` (the default for `lazy` positions) — **may-evaluate**: the
   *   operand is not evaluated at application time, but the operator may
   *   evaluate it *under* itself (a `Sum` body, the `WithRandomSeed` body), so
   *   it contributes its own effects, minus whatever the position discharges.
   * - `'quote'` — the operator **never** evaluates the content (`Hold`):
   *   contribution ∅, so `Hold(Random())` is pure.
   * - `'release'` — the operator **forces** a quote (`ReleaseHold`): the
   *   projection strips one quote layer and recurses into the content, which
   *   is where the effects `Hold` deferred resurface. A symbol operand is
   *   resolved through its current binding.
   *
   * **Default:** `'evaluate'`
   */
  holdClass: 'evaluate' | 'quote' | 'release';

  /** If `true`, evaluating this operator consumes draws from the engine's
   * random stream (`Random`, `RandomShuffle`, …, and `WithRandomSeed`, which
   * manages the stream's frame).
   *
   * Narrower than `pure: false`, which also covers side effects with no
   * randomness (`Assign`, `Declare`, `Assume`). `WithRandomSeed` consults it
   * to decide whether a partially-evaluated body still OWES draws to its
   * seed frame — a surviving `Assign` is impure but owes nothing to the
   * stream.
   *
   * **Default:** `false`
   *
   * As an **authoring input** this flag is sugar for the `random` effect
   * label. As **readable state on a boxed definition** it is a *derived*
   * getter: `random ∈ effects ∨ frameProtocol === 'seed'`.
   */
  drawsRandom: boolean;

  /** If `true`, evaluating this operator READS the engine's random frame
   * without consuming any of its indices — the stochastic estimators
   * (Monte-Carlo integration), which sample through a derived sub-stream
   * (`ce._substream`).
   *
   * Orthogonal to `drawsRandom`, and both are consulted by `WithRandomSeed`'s
   * pending gate: an estimator that could NOT finish (a bound or parameter is
   * still unbound) must keep the seed frame, or the deferred completion
   * samples live — the same silent seeded→unseeded conversion `drawsRandom`
   * prevents for `Random`. It must not be spelled `drawsRandom: true`, which
   * would additionally make the estimator consume frame indices and shift
   * every sibling draw.
   *
   * A **peer runtime field, untouched by the effect-flag migration**: an
   * estimator's nondeterminism is confined below its reported error bound, so
   * it is approximation error, not an effect (the noise-floor convention). It
   * is neither translated to a label nor derived from one.
   *
   * An estimator that COMPLETED owes the frame nothing; its node is gone, so
   * the gate never sees it.
   *
   * **Default:** `false`
   */
  readsRandomFrame: boolean;
};

/**
 * A traversable, public view of a user-defined function literal
 * (`f(x) := …`, `x ↦ …`, or `ce.assign('f', lambda)`): its parameters and
 * its body as a boxed expression. Returned by
 * {@link BoxedOperatorDefinition.lambda}.
 *
 * @category Definitions
 */
export type LambdaDefinition = {
  /** The declared parameters, in order. `type` is `undefined` for a bare
   * (unannotated) parameter such as the `x` in `f(x) := x^2`. `optional`
   * marks a parameter with a default value, such as the `k` in
   * `(x, k = 2) => x * k`, and `default` is that value: a call may leave
   * the parameter out, and the parameter then receives its default. */
  parameters: ReadonlyArray<{
    name: string;
    type: Type | undefined;
    optional?: boolean;
    default?: ParameterDefault;
  }>;

  /** The body of the function as a boxed expression, ready to traverse. This
   * is the canonical (scoped `Block`) body; any return-type ascription is
   * included. */
  body: Expression;
};

/**
 *
 * The definition includes information specific about an operator, such as
 * handlers to canonicalize or evaluate a function expression with this
 * operator.
 *
 * @category Definitions
 *
 */
export interface BoxedOperatorDefinition
  extends BoxedBaseDefinition, OperatorDefinitionFlags {
  /** `true` when the operator creates a lexical scope: it was declared
   * `scoped: true`, or it is a binder, whose `operands` handler gives a
   * `bound` or a `clause` role. */
  scoped: boolean;

  /** The binding sites of a binder among the operands `ops` of an
   * application: the path to each bound variable, its type, and whether it
   * belongs to a clause. `undefined` for an operator that is not a binder.
   * @internal */
  bindingSites?: (
    ops: ReadonlyArray<Expression>,
    phase: 'pre' | 'post'
  ) => readonly {
    path: readonly number[];
    type?: TypeString;
    clauseLocal?: boolean;
  }[];

  complexity: number;

  /** If true, the signature was inferred from usage and may be modified
   * as more information becomes available.
   */
  inferredSignature: boolean;

  /** History of writes to this definition's signature — the operator-side
   * analog of {@link BoxedValueDefinition._typeProvenance}, with the same
   * append-on-change and capping rules.
   * @internal */
  _typeProvenance: TypeProvenanceEntry[] | undefined;

  /** See {@link OperatorDefinition._derivedSignature}: the pinned signature
   * came from an annotated function literal at assign time, not from an
   * author's declaration.
   * @internal */
  _derivedSignature: boolean;
  /** See {@link OperatorDefinition._validationSignature}: the signature a
   * call's arguments are validated against, when it differs from
   * `signature`.
   * @internal */
  _validationSignature: Type | undefined;

  /** When a user lambda was assigned under a declared signature with
   * `unknown` slots, that signature as written. The reported `signature` is
   * then derived on each read from the lambda's current type. `undefined`
   * for every other definition.
   * @internal */
  _signatureSkeleton: Type | undefined;

  /** The type of the arguments and return value of this function */
  signature: BoxedType;

  /** A counter that increases at each change of this definition in place
   * (an update, a signature write, a snapshot restore). A call of a user
   * function compares it with the value it recorded when it was boxed, to
   * know whether it must be checked again.
   * @internal */
  _writeVersion: number;

  /** True when the definition stated its effects in any spelling (`pure`,
   * `drawsRandom`, `effects`, an effect specifier on the signature). A memo
   * keeps the result of an operator that the host declared only when this
   * is true and the operator is pure (ROADMAP CE-601).
   * @internal */
  _purityStated: boolean;

  /** True when a standard library made this definition: it is library
   * code, not host code (ROADMAP CE-601).
   * @internal */
  readonly _standardLibrary: boolean;

  /** Write the signature, deriving it inside the write's fact-blind bracket:
   * the thunk and the write both run with the assumptions hidden, so a stored
   * arrow never encodes a proof the next `forget()` retracts. The public
   * {@link signature} setter delegates here, then reports a `type-write`
   * state event. This method reports no event: internal callers report
   * their own.
   * @internal */
  _setSignature(thunk: () => BoxedType): void;

  /**
   * The *resolved* missing-value behavior (§3.A of the missing-value typing
   * design): the declared `missingBehavior` flag of {@link OperatorDefinitionFlags}
   * when present, otherwise
   * `'propagate'` for a declared all-numeric signature and `'pass-through'`
   * for everything else. Recomputed from the current signature — never cached
   * across a signature mutation.
   */
  readonly resolvedMissingBehavior:
    'reject' | 'propagate' | 'handle' | 'pass-through';

  /** True if a `missing` arm is stripped from parameter position `i` before
   * validation (§3.A). Only `propagate`/`handle` operators strip; `missingStrip`
   * selects the positions. */
  stripsMissingAt(i: number): boolean;

  /** The declared type of parameter position `i` (0-based: the required
   * parameters, then the optional ones, then the variadic one for every
   * later position), or `undefined` for an overload set or a position past a
   * non-variadic signature. */
  declaredParameterTypeAt(i: number): Type | undefined;

  /** True when an absent scalar operand (`Missing`) at position
   * `i` is refused at evaluation with an `incompatible-type` error naming the
   * parameter's type: a declared `reject`, or the default for an operator
   * with no absence behavior of its own whose parameter at `i` excludes
   * absence and is read as data (not a number, a collection, a function,
   * `expression`, `symbol`, `any` or `unknown`). User decision P2 of
   * `docs/plans/2026-10-21-presence-contracts-and-assertion.md`
   * (2026-10-21). */
  refusesAbsentOperandAt(i: number): boolean;

  /** True for a function literal whose parameter annotations are enforced at
   * a call (at least one annotated parameter). Such a function admits an
   * argument typed `missing | T` at boxing, and answers an
   * `incompatible-type` error when the value is absent at a parameter whose
   * annotation has no `missing` member. */
  readonly enforcesParameterAnnotations: boolean;

  /** True if the `threadsConditionals` flag of
   * {@link OperatorDefinitionFlags} selects operand position `i`: a
   * conditional value (a restriction, `Which`) there moves out of the application at
   * evaluation. A broadcastable operator threads every position whatever this
   * answers. */
  threadsConditionalsAt(i: number): boolean;

  /** The kind of the role of each operand of `ops`, the operands of an
   * application of this operator, as the `operands` handler of
   * {@link OperatorDefinitionFlags} declares them, with the default role
   * (`value`, or `raw` for a `lazy` operator) for a position that the
   * handler leaves out. One entry per operand. `undefined` when the
   * definition has no `operands` handler: every operand then has the
   * default role. */
  operandRoles(
    ops: ReadonlyArray<Expression>
  ): ReadonlyArray<OperandRole['kind']> | undefined;

  /**
   * The *resolved* NaN policy for parameter position `i` (Contract B,
   * `docs/ERROR-MODEL.md` §4). For a user-defined callable the answer is
   * always `'inert'` — the higher-order conservative floor, absolute even
   * over an explicit declaration (see `isUserFunctionDefinition`).
   * Otherwise an explicit `nanBehavior` declaration wins.
   * Otherwise, while the slot's declared carrier admits `nan` (bare
   * `number`, an inferred signature, a union with `nan`) the answer is
   * `'inert'` — `NaN` is an ordinary domain member and the handler owns
   * it. For a precise carrier that excludes `nan`, the derived default is
   * `'propagate'` when the carrier is a subtype of `complex` that is not a
   * subtype of `integer` and the result type is numeric, `'reject'`
   * otherwise. Recomputed from the current signature — never cached.
   */
  resolvedNanBehaviorAt(
    i: number,
    /** The resolved overload arm to derive from, when the caller has one:
     * per-arm carriers give per-arm derived policies. Explicit
     * `nanBehavior` declarations remain operator-level. */
    armSignature?: Type
  ): 'reject' | 'propagate' | 'handle' | 'inert';

  /**
   * The *resolved* partiality of the declaration (Contract B): the
   * declared `partiality`, `'defined-when'` when a `definedWhen` predicate
   * is declared, and the sound `'may-marker'` default when nothing is.
   */
  readonly resolvedPartiality: 'total' | 'may-marker' | 'defined-when';

  /** True for a USER-DEFINED callable — a lambda, or an unscoped strict
   * multi-clause definition. The sanctioned opt-out of the Contract B
   * machinery: its own application machinery owns every exceptional
   * operand, and the higher-order conservative floor
   * (`docs/ERROR-MODEL.md` §4) caps what a consumer may assume about it
   * at `may-marker` with unknown NaN behavior. */
  readonly isUserFunctionDefinition: boolean;

  /**
   * The Contract B adjustment to a derived application result type for
   * these arguments (`docs/ERROR-MODEL.md` §4): `'is-marker'` when the
   * declared `definedWhen` is provably false — the value IS the codomain
   * marker (§2 rule 4: `NaN` for a numeric codomain, `Missing` for a
   * settled non-numeric one); `'widen-marker'` when a DECLARED partiality
   * is undischarged (`definedWhen` undecided, or an explicit
   * `may-marker`) — every cell of the result gains its marker arm;
   * `'is-nan'` when a scalar argument in a `propagate` slot is a proven
   * `NaN` — the value of the whole application is `NaN`, whatever the
   * codomain's shape; `'widen-nan'` when such an argument may be `NaN` —
   * the application gains a top-level `| nan` arm; `'widen-nan-cells'`
   * when the NaN evidence rides in the cells of a broadcast lift — the
   * lifted result's numeric cells gain `| nan`; `'none'` otherwise. The
   * omitted `may-marker` default contributes no arm (see
   * the implementation note in `boxed-operator-definition.ts`).
   */
  contractBResultAdjustment(
    ops: ReadonlyArray<Expression>,
    /** The resolved overload arm, when the caller has one — the NaN
     * evidence derives per-slot policies from its carriers. */
    armSignature?: Type
  ):
    | 'none'
    | 'is-nan'
    | 'widen-nan'
    | 'widen-nan-cells'
    | 'widen-marker'
    | 'is-marker';

  /** True if operand position `i` may INVOKE a function-valued operand — the
   * per-position reader for the `invokes` flag of {@link OperatorDefinitionFlags}.
   * Missing
   * map indices default to `true`. Every consumer of the metadata goes
   * through this accessor (or {@link invokesNone}), never the raw field. */
  invokesAt(i: number): boolean;

  /** True when NO operand position invokes — the cheap operator-level
   * pre-gate for the latent half of the projection rule. */
  readonly invokesNone: boolean;

  /** If this operator definition was created from a user-defined function
   * literal (`f(x) := …`, `x ↦ …`, `ce.assign('f', lambda)`), a structured
   * view of it for traversal and classification: the parameters and the body
   * as a boxed expression. `undefined` for built-in operators.
   *
   * The return shape and per-argument types are also available via
   * {@link signature}; this accessor additionally exposes the body so a
   * consumer can resolve a function reference structurally — without
   * re-parsing or textually inlining its source.
   */
  readonly lambda: LambdaDefinition | undefined;

  /** The `Function` literal this definition was created from, verbatim —
   * `undefined` for a built-in operator, which has no body. Where
   * {@link lambda} is a canonicalized, structured VIEW for consumers, this is
   * the literal itself, the input the effects walk
   * (`inferFunctionLiteralEffects`) takes: re-deriving a definition's effect
   * set outside this module (the conformance-widening guard in
   * `engine-protocols.ts`) means re-running that walk over exactly the same
   * expression the install ran it over.
   * @internal */
  _lambdaLiteral?: Expression;

  /** If present, this handler determines the result type more precisely
   * than the signature, from the operand DESCRIPTORS (types, facts and
   * structure — never the operand expressions).
   */
  type?: OperatorTypeHandlerOnTypes;

  /** If present, this handler can be used to determine the sign of the
   *  return value of the function, based on the sign and type of its
   *  arguments.
   *
   * The arguments themselves should *not* be evaluated, only their types and
   * sign should be used.
   *
   * This can be used in some case for example to determine when certain
   * simplifications are valid.
   *
   * The handler MUST be a pure function of the operands: no evaluation
   * (`.evaluate()`, `.N()` — including indirectly, through helpers that
   * numericize a bound or probe a collection element), no canonicalization
   * of new expressions, no declarations. The type path dispatches `sgn`
   * handlers while deriving an application's type (the `sgn` operand fact),
   * so a handler that changes engine state invalidates the very caches the
   * derivation is filling. Audit record: open item O7 of
   * `docs/plans/2026-08-22-type-handlers-on-types.md`.
   */
  sgn?: (
    ops: ReadonlyArray<Expression>,
    options: { engine: ComputeEngine }
  ) => Sign | undefined;

  /** See `OperatorDefinition.eq` for the meaning of `prover`. */
  eq?: (a: Expression, b: Expression, prover?: boolean) => boolean | undefined;
  neq?: (a: Expression, b: Expression) => boolean | undefined;

  /** The eager producer's enumerability precondition — see the
   * `canEnumerate` contract on {@link OperatorDefinition}. */
  canEnumerate?: (expr: Expression) => boolean | undefined;

  /** The eager producer's element count — see the `elementCount` contract on
   * {@link OperatorDefinition}. */
  elementCount?: (expr: Expression) => number | undefined;

  /** The eager producer's element read — see the `elementAt` contract on
   * {@link OperatorDefinition}. */
  elementAt?: (expr: Expression, index: number) => Expression | undefined;

  /** Use-driven element inference — see the `inferOperandTypes` contract on
   * {@link OperatorDefinition}. */
  inferOperandTypes?: (
    ops: ReadonlyArray<Expression>,
    requirement: Type
  ) => ReadonlyArray<Type | { readonly replace: Type } | undefined> | undefined;

  canonical?: (
    ops: ReadonlyArray<Expression>,
    options: { engine: ComputeEngine; scope: Scope | undefined }
  ) => Expression | null;

  evaluate?: (
    ops: ReadonlyArray<Expression>,
    options: EvaluateHandlerOptions
  ) => Expression | undefined;

  evaluateAsync?: (
    ops: ReadonlyArray<Expression>,
    options: EvaluateHandlerOptions
  ) => Promise<Expression | undefined>;

  evalDimension?: (
    ops: ReadonlyArray<Expression>,
    options: Partial<EvaluateOptions> & { engine: ComputeEngine }
  ) => Expression;

  /** The partial derivatives of the operator, as given by the `derivative`
   * key of its definition. See {@link OperatorDerivative}. */
  derivative?: OperatorDerivative;

  compile?: OperatorCompileHandler;

  /** See `OperatorDefinition.compileShippable`. */
  compileShippable?: boolean;

  /** See `OperatorDefinition.compileHelpers`. */
  compileHelpers?: Readonly<Record<string, (...args: never[]) => unknown>>;

  /** The arithmetic of the value kind this operator constructs, as given by
   * the `arithmetic` field of its definition. See
   * {@link ArithmeticDefinition}. */
  arithmetic?: ArithmeticDefinition;

  /** @internal */
  _update(def: OperatorDefinition): void;

  /** Re-attach the definition's effect set to its signature after the
   * signature object was REPLACED by type inference. The two are one source of
   * truth and must never disagree.
   * @internal */
  _resyncEffects(): void;

  /** A lazily-evaluated override of this definition's effect set, or
   * `undefined` when the set is simply what was declared or inferred at
   * install time.
   *
   * Installed on protocol DISPATCHERS — whose effect set is the union of the
   * inferred effects of the registered conforming implementations of a BARE
   * requirement, and therefore changes as conformances register
   * (`docs/TYPE_SYSTEM_ROADMAP.md`, Appendix B, "Changing a field is an
   * effect") — and on lambda-backed definitions whose body inference
   * consulted such a union. The closure owns its own memoization and
   * re-entrancy guard; the `effects` / `pure` / `drawsRandom` / `signature`
   * accessors consult it before answering.
   * @internal */
  _deriveEffects: (() => EffectSet | undefined) | undefined;

  /** Opaque snapshot of every field a provisional re-derivation
   * (`installRebuiltLiteral` calling `_update({ evaluate })` on a
   * pre-existing definition) can mutate, for an exact restore (the
   * failure leg of a repair, `DefinitionRestorePoint`) — see
   * {@link _restoreRederivationSnapshot}. The result captures private
   * fields, so peeking or constructing one outside the implementation is
   * meaningless.
   * @internal */
  _rederivationSnapshot(): unknown;

  /** Restore the fields captured by {@link _rederivationSnapshot},
   * verbatim and identity-preserving (no effect re-sync: the captured
   * signature/effect pair was consistent when snapshotted).
   * @internal */
  _restoreRederivationSnapshot(snapshot: unknown): void;
}
