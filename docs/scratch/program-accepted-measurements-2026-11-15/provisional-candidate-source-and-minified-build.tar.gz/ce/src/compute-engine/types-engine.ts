import type { BigDecimal } from '../big-decimal/index.js';
import type { Complex } from 'complex.js';
import type { OneOf } from '../common/one-of.js';
import type { KernelPool } from './kernel-pool-types.js';
import type { MathJsonSymbol, MathJsonNumberObject } from '../math-json.js';
import type {
  DeclarationOrigin,
  Type,
  TypeString,
  TypeResolver,
  TypeReference,
  TypeParameter,
  TypeParamsOption,
} from '../common/type/types.js';
import type { BoxedType } from '../common/type/boxed-type.js';
import type { ConfigurationChangeListener } from '../common/configuration-change.js';
import type { StateEvent } from './engine-configuration-lifecycle.js';
import type { DeadlineFrame } from '../common/interruptible.js';
import type { JsProfileSwitch } from './js-profile-switch.js';
import type { MapAutoCompileStats } from './map-auto-compile-stats.js';
import type { CacheStatsControl } from '../common/cache-stats.js';
export type { MapAutoCompileStats } from './map-auto-compile-stats.js';
import type {
  LatexDictionaryEntry,
  ParseLatexOptions,
  SerializeLatexOptions,
  SymbolResolution,
} from './latex-syntax/types.js';
import type {
  ExactNumericValueData,
  NumericValue,
  NumericValueData,
  NumericValueFactory,
} from './numeric-value/types.js';
import type { BigNum, Rational } from './numerics/types.js';
import type { RandomSeedFrame, RandomSubstream } from './numerics/random.js';
import type {
  EffectHandlerOverrides,
  EffectHandlers,
} from './types-effects.js';
import type { EngineBoxingState } from './engine-boxing-state.js';
import type { UnitEnvironment } from './binding-unit.js';

import type { Expression, ExpressionInput } from './types-expression.js';
import type { FunctionProperties } from './function-properties/types.js';
import type { ContourInput, ContourIntegralResult } from './types-contour.js';
export type * from './types-contour.js';
export type {
  FunctionProperties,
  FunctionPropertyRecord,
} from './function-properties/types.js';
import type {
  Metadata,
  CanonicalOptions,
  FormOption,
  BoxedSubstitution,
} from './types-serialization.js';
import type {
  AngularUnit,
  RoundingTies,
  SymbolDefinitionInput,
  OperatorDefinition,
  ValueDefinition,
  BoxedDefinition,
  SequenceDefinition,
  SequenceStatus,
  SequenceInfo,
  OEISSequenceInfo,
  OEISOptions,
  InterpretResult,
  BoxedValueDefinition,
  BoxedOperatorDefinition,
  LibraryDefinition,
  KindRegistryState,
} from './types-definitions.js';
import type {
  AssumeResult,
  Rule as KernelRule,
  BoxedRule as KernelBoxedRule,
  BoxedRuleSet as KernelBoxedRuleSet,
  RulePurpose,
  RuleStep as KernelRuleStep,
  AssignValue as KernelAssignValue,
  Scope as KernelScope,
  InspectableScope as KernelInspectableScope,
  NarrowingSink as KernelNarrowingSink,
  EvalContext as KernelEvalContext,
  EvaluateOptions as KernelEvaluateOptions,
} from './types-kernel-evaluation.js';
import type {
  LanguageTarget,
  CompilationResult,
  IntervalJsCompilationTarget,
  JavaScriptCompilationTarget,
} from './compilation/types.js';

export type { RulePurpose } from './types-kernel-evaluation.js';

type Rule = KernelRule<Expression, ExpressionInput, IComputeEngine>;
type BoxedRule = KernelBoxedRule<Expression, IComputeEngine>;
type BoxedRuleSet = KernelBoxedRuleSet<Expression, IComputeEngine>;
type RuleStep = KernelRuleStep<Expression>;
type AssignValue = KernelAssignValue<
  Expression,
  ExpressionInput,
  IComputeEngine
>;
type Scope = KernelScope<BoxedDefinition>;
type InspectableScope = KernelInspectableScope<BoxedDefinition>;
type NarrowingSink = KernelNarrowingSink<BoxedDefinition>;
type EvalContext = KernelEvalContext<
  Expression,
  BoxedDefinition,
  BoxedValueDefinition
>;

/** Minimal interface for a LaTeX parser/serializer.
 *  Structurally compatible with `LatexSyntax` without importing it. */
export interface ILatexSyntax {
  parse(
    latex: string,
    options?: Partial<ParseLatexOptions>
  ): import('../math-json/types.js').MathJsonExpression | null;
  serialize(
    expr: import('../math-json/types.js').MathJsonExpression,
    options?: Record<string, unknown>
  ): string;

  /** Named dictionary entries with their LaTeX trigger strings, for reverse
   *  library search (`ce.searchDefinitions()`). Optional: MathJSON-only
   *  builds and minimal injected syntaxes may not implement it. */
  getNamedTriggers?(): ReadonlyArray<{ name: string; triggers: string[] }>;

  /** Add LaTeX dictionary entries. The next parse or serialization uses
   *  them. Optional: `LatexSyntax` implements it, a minimal injected syntax
   *  may not. If the same instance is used by several engines, the entries
   *  apply to all of them. See `LatexSyntax.addEntries()`. */
  addEntries?(entries: ReadonlyArray<Partial<LatexDictionaryEntry>>): void;

  /** The dictionary entries, including the entries added with
   *  `addEntries()`. A call to `addEntries()` gives a new array, so a
   *  different array means a different dictionary. Rule strings are parsed
   *  with these entries plus the rule entries. Optional: a minimal injected
   *  syntax may not have it, and then rule strings are parsed with the
   *  default dictionary. See `LatexSyntax.dictionary`. */
  readonly dictionary?: ReadonlyArray<Partial<LatexDictionaryEntry>>;
}

export type OperatorInfo = {
  kind: 'function' | 'opaque';
  signature?: BoxedType;

  /**
   * `true` when the operator's definition provides an evaluation rule — an
   * `evaluate` handler or a `collection` handler — so that applying it can
   * produce a computed result. `false` for a registered-but-inert head that
   * only parses/serializes (e.g. `Triangle`), which is returned unchanged by
   * `evaluate()`.
   *
   * This is a "has an evaluation rule" signal, **not** a guarantee that the
   * head computes. A few common heads reduce only through a `canonical`
   * rewrite to a different operator and therefore report `false` even though
   * they do compute: `Exp` (→ `Power`), `Square` (→ `Power`), `Complex`,
   * and `Greater` (→ `Less`). Equivalent to `kind === 'function'`.
   *
   * Conversely, this is a per-operator capability, not per-call inertness:
   * a head can report `true` yet return typical applications unevaluated —
   * e.g. `Element` and `ForAll` have `evaluate` handlers but stay symbolic
   * unless the proposition can be decided (`Element(x, RealNumbers)` echoes
   * back when nothing is known about `x`).
   */
  canEvaluate: boolean;
};

export type SymbolInfo = {
  kind: 'constant' | 'variable';
  type: BoxedType;
};

/** One result of `ce.searchDefinitions()`. */
export type DefinitionSearchResult = {
  /** The canonical identifier, e.g. `'GCD'`. Always resolvable via
   * `ce.lookupDefinition(id)`. */
  id: MathJsonSymbol;

  /** The kind of definition, using the same semantics as
   * `operatorInfo()`/`symbolInfo()`:
   * - `'function'` — an operator with an `evaluate` or `collection` handler
   * - `'opaque'` — a registered-but-inert operator head
   * - `'constant'` — a constant value symbol (e.g. `Pi`)
   * - `'variable'` — a declared, non-constant value symbol
   */
  kind: 'function' | 'opaque' | 'constant' | 'variable';
};

/** @internal */
/** A symbolic-integration provider: given an integrand and the integration
 * variable, returns a closed-form antiderivative (an expression in `variable`),
 * or `null` when it cannot integrate it. See `IComputeEngine._integrationProvider`.
 *
 * When an optional `trace` accumulator is passed (by `expr.explain('Integrate')`),
 * the provider appends a curated, whole-state step chain describing how the
 * antiderivative was found. The argument is backward-compatible: the plain
 * `Integrate` evaluator calls the provider with two arguments and never traces. */
export type IntegrationProvider = (
  integrand: Expression,
  variable: string,
  trace?: RuleStep[]
) => Expression | null;

//
// ── Protocols (`docs/TYPE_SYSTEM_ROADMAP.md` Appendix A) ─────────────────────
//
// A protocol is a set of function and property REQUIREMENTS a type may declare
// itself to satisfy (`type string is Hashable`). Protocol records live in the
// engine-level `_protocolRegistry` and, like type records, mutate IN PLACE
// (captured references must see the update).
//

/** One requirement of a protocol. A `function` member's signature is stored
 * VERBATIM, with `Self` unsubstituted: `Self` is a textual substitution token
 * (ruling P12), never a type the registry can resolve. */
export type ProtocolMember =
  | { kind: 'function'; signature: string }
  | { kind: 'readonly' | 'readwrite'; type: string };

/**
 * One write of inference evidence onto a definition, as delivered to
 * `IComputeEngine._noteInferenceWrite` — the single emission point whose
 * subscribers are the provenance history, the fresh-inference set, and the
 * narrowing sink. See `docs/TYPE-SYSTEM.md`
 * (phase 1).
 */
export type InferenceWriteEvent = {
  /** The symbol whose binding was written. */
  name: string;
  /** The binding wrapper, as the narrowing sink consumes it. */
  binding: BoxedDefinition;
  /** The definition object the write landed on — the carrier of the
   * `_typeProvenance` history. Exactly one of the two definition shapes. */
  target: BoxedValueDefinition | BoxedOperatorDefinition;
  /** The value definition written, when the write was on a value binding —
   * what the fresh-inference set (`_freshlyInferred`) tracks. Omitted for
   * signature writes on operator definitions. */
  valueDef?: BoxedValueDefinition;
  /** The type before the write. */
  from: BoxedType;
  /** The type the write installed. */
  to: BoxedType;
  /** `'inferred'` for `_infer()` writes. The only kind: an assumption never
   * writes a type, so it never reports one here. */
  kind: 'inferred';
};

/**
 * The ambient canonicalization context recorded as the `cause` of provenance
 * entries: the operator expression being canonicalized when an inference
 * write fires. Kept as the operator name + the operand array as the
 * canonicalizer received it (possibly raw MathJSON — canonicalization has
 * not run yet); `expr` is the non-canonical materialization, built lazily on
 * the first write that records it (writes are rare — building an expression
 * per canonicalization would not be).
 */
export type InferenceCauseContext = {
  operator: string;
  ops: ReadonlyArray<ExpressionInput>;
  expr?: Expression;
};

/** What the uses of a parameter of a function literal required while the
 * literal is boxed (decision D18 of
 * `docs/plans/2026-11-11-bound-once-spec.md`): the type that a read of the
 * parameter gives, and the cause of the use that last changed it, recorded
 * as the provenance of the type when it is written on the definition. */
export type ParameterRequirement = {
  type: BoxedType;
  cause?: InferenceCauseContext;
  /** True when a type recorded for the parameter in this boxing was a
   * number type and every use that required a number maps over a
   * collection; false when one such use does not map (`Range(n)`). A final
   * type that is not a number type after `true` makes the literal box its
   * body once more (`canonicalFunctionLiteralArguments()`): a node built
   * while the parameter read as a number kept that reading. */
  numeric?: boolean;
};

/** The record of a function literal while it is boxed: the requirement of
 * each parameter, keyed by its value definition, and the environment of the
 * literal, which holds the entries that the uses of its parameters write
 * (outside a trial) and that a later use reads. The environment is made with
 * the record: a read of it is recorded only by the caches whose computation
 * started after that (`collectorDepth`, `objectDepCollectorDepth()`), as a
 * computation that started before boxes the literal again. */
export type ParameterRecord = {
  requirements: Map<BoxedValueDefinition, ParameterRequirement>;
  env: UnitEnvironment;
  collectorDepth: number;
  /** `sharedEvaluationStarts()` when the record was made: the end of the
   * boxing sends its narrowing as one that keeps the memo of shared
   * evaluations when no evaluation that keeps a result started since. */
  memoStarts: number;
  /** The parameter definitions that the literal's frame declared at the
   * first reference of their name. A binding that existed before the frame
   * (a local of an earlier boxing of the same scope) is held by nodes that
   * this boxing did not make. */
  created: Set<BoxedValueDefinition>;
};

/** A HOST (JavaScript) implementation of a protocol member. A callback carries
 * no type information the engine can read, so — like a host-declared operator
 * handler — it is TRUSTED: only member-name coverage is checked, never its
 * signature. Boxed in a wrapper so it stays distinguishable from an Epsil
 * function literal (design P10). */
export type JSImplementation = {
  /** The host callback. */
  host: ProtocolHostHandler;
};

/** A host callback implementing one protocol member. Its arguments arrive as
 * boxed engine values (the receiver first, per P1); its result is boxed by the
 * engine. The engine cannot type-check it — that is what "trusted" means
 * here. */
export type ProtocolHostHandler = (...args: Expression[]) => unknown;

/** One conformance edge: "this target type conforms to this protocol".
 * Conformances are add-only (monotone); only their implementations replace. */
export type ConformanceRecord = {
  /** The conforming type — named and ground (Appendix A "Conformance
   * targets"). */
  target: Type;
  /** The target's canonical serialization: the dedup/replace key. For a
   * CONDITIONAL edge it also carries the clause, so two different conditions on
   * one head are two keys (and collide under the one-per-head rule) rather than
   * one silently replacing the other. */
  targetKey: string;
  /** CONDITIONAL conformance (Appendix A "Conditional Conformance"): the
   * variables the trailing `where` clause binds, with their bounds and `is`
   * entries. When present, {@link ConformanceRecord.target} is a HEAD PATTERN
   * (`list<T>`) rather than a ground type, and the edge applies to exactly
   * those instantiations whose arguments satisfy the clause. */
  where?: TypeParameter[];
  /** Member name → implementation: an Epsil function literal, or a
   * {@link JSImplementation} wrapper for a host callback. Property handlers
   * ride under the mangled keys `__get__<name>` / `__set__<name>`. Validated
   * against the protocol's requirements before it is stored (P17).
   *
   * This is the MERGED map dispatch reads: it holds the author's entries
   * ({@link ConformanceRecord._authored}) plus any accessors the engine
   * synthesized for property requirements the target's stored fields satisfy
   * (`docs/TYPE_SYSTEM_ROADMAP.md` Appendix B, "Objects and protocols"). */
  impl?: Record<string, Expression | JSImplementation>;
  /** The implementation block as the AUTHOR wrote it — the statement's `is P
   * { … }` block, or the host API's three flattened buckets — before the
   * engine merged its synthesized field-backed accessors into
   * {@link ConformanceRecord.impl}.
   *
   * Stored rather than derived from `impl`, because the two questions the
   * engine asks of it cannot be answered by inspecting the merged map: an
   * author's EMPTY block (`type P is Nameable { }`) and no block at all both
   * leave the merged map holding nothing but synthesized accessors, yet an
   * empty block still claims the edge — a second implementation of it is
   * `protocol-implementation-duplicate`, and it does not inherit a
   * supertype's implementation, while a block-less edge does both. */
  _authored?: Record<string, Expression | JSImplementation>;
  /** Where {@link ConformanceRecord.impl} came from, when it was installed
   * from INSIDE an Epsil batch (ruling P47): the batch id
   * (`IComputeEngine._epsilBatchId`) and the identity of the
   * implementation BLOCK expression that installed it. A second, DIFFERENT
   * block for the same (type, protocol) pair in the SAME batch is
   * `protocol-implementation-duplicate`; a re-implementation in a later batch
   * replaces. The block identity is what tells a genuine second block from
   * the SAME statement re-registering — one statement installs its block up
   * to three times per batch (the static pre-pass canonicalizes it, then the
   * evaluation loop canonicalizes and evaluates it), each time rebuilding the
   * record around the very same block expression.
   *
   * Absent for an implementation installed outside any batch (a box-route
   * `DeclareConformance`) or by the host, both of which replace without
   * error. */
  _implOrigin?: { batch: number; block?: Expression };
  /** No implementation yet: an end-of-batch `protocol-implementation-pending`
   * warning (ruling P3). A SEMANTIC protocol (no members) is never pending. */
  pending: boolean;
  /** WHY {@link ConformanceRecord.pending} is set, when the edge was left
   * pending by a RE-SETTLEMENT rather than by never having been implemented:
   * a protocol replacement, or a redefinition of the target type. Without it
   * the end-of-batch warning names only the pair, which for a re-settled edge
   * is the least informative half of the story — an edge that read fine in the
   * previous cell is now pending, and the reason is the requirement or the
   * layout that moved under it. Carries the `implementationProblem` message,
   * or a description of what the target's new layout no longer satisfies.
   *
   * Absent on an edge that is not pending, and on one pending only because no
   * implementation has been written yet. */
  _pendingReason?: string;
  /** The STATEMENT PROTOCOL that installed this edge's part, when that
   * protocol is not the edge's own protocol: `FloorRing` on the
   * `PartialOrder` edge that `type Money is FloorRing { compare … }`
   * registered, because `FloorRing` extends `PartialOrder`.
   *
   * Every conformance with an implementation block sets it on each edge its
   * expansion over the protocol's ancestors installs (created, filled, or
   * replaced), including a block-less edge it derives for an ancestor whose
   * part of the block is empty. A block whose protocol is the edge's own
   * protocol (`type Money is PartialOrder { compare }`) deletes it, and a
   * block-less conformance never sets or clears it. A protocol replacement
   * that adds an ancestor stamps the edges it derives with the replaced
   * protocol's name.
   *
   * Read by a later conformance with a block, for the same target and the
   * same statement protocol: it replaces every AUTHORED edge stamped with
   * that protocol with its new part, even an empty one, so a member that an
   * edited notebook cell dropped is reported as missing. An edge with no
   * stamp, or with the stamp of another statement protocol, is only checked
   * as an existing conformance, never replaced.
   *
   * Source: `docs/plans/2026-10-31-protocol-refinement.md`, rule R4(e). */
  _via?: string;
  /** Set on an edge that the expansion of a conformance to an extending
   * protocol registered on an ancestor that the author did not write, with
   * or without an implementation block: `type list<T> is FloorRing where T
   * is FloorRing` registers `list<T> is PartialOrder where T is FloorRing`
   * with this flag. A protocol replacement that adds an ancestor sets it on
   * the edges it derives for that ancestor.
   *
   * A written statement that claims the edge (it fills the edge with a
   * block, or restates it block-less) clears the flag: from then on the edge
   * counts as hand-written.
   *
   * A later wider conditional conformance to the ancestor (`type list<T> is
   * PartialOrder where T is PartialOrder { compare … }`) replaces an edge
   * that has this flag and no authored part. The replacement reads this flag
   * only, not `_via`, which only a conformance with a block sets, so it also
   * applies after a block-less conformance.
   *
   * Source: `docs/plans/2026-10-31-protocol-refinement.md`, rule R7. */
  _derived?: true;
  declaredByStatement: boolean;
};

/** A whole-SUM conformance, as the author wrote it: `type shape is Area { … }`
 * where `shape` is a sum type (user ruling of 2026-09-22).
 *
 * The statement itself registers one ordinary edge per variant — a sum names a
 * transparent alias of its variants, and an alias cannot conform — so this
 * record is bookkeeping, not an edge: it is what lets a variant the sum gains
 * in a LATER batch receive the same implementation block. The block is kept as
 * the author wrote it, BEFORE `Self` is bound: each variant's edge substitutes
 * `Self` with its own target, so the substituted block of one variant is the
 * wrong body for another. */
export type SumConformanceRecord = {
  /** The sum type the statement named. */
  sum: string;
  /** The implementation block, ungrounded; absent for a block-less
   * conformance declaration. */
  impl?: Record<string, Expression | JSImplementation>;
  /** The block expression's identity, threaded to the duplicate rule of
   * {@link ConformanceRecord._implOrigin} when the block is re-applied. */
  block?: Expression;
};

/** A protocol declaration and every conformance registered against it. */
export type ProtocolRecord = {
  name: string;
  members: Record<string, ProtocolMember>;
  /** The PARENTS of this protocol, in the order the declaration wrote them
   * (`protocol FloorRing extends LinearOrder, Ring, FloorOrder`). Empty when
   * the protocol extends nothing.
   *
   * A type that conforms to this protocol conforms to every protocol of its
   * CLOSURE (the parents, their parents, and so on), because a conformance
   * registers one ordinary edge on each protocol of the closure that the type
   * does not already conform to. Each parent is a declared protocol, the
   * closure contains no cycle, and no member name is declared by two
   * protocols of one closure. A replacement of the protocol may add parents
   * but may not remove a protocol from the closure. */
  extends: string[];
  conformances: ConformanceRecord[];
  declaredByStatement: boolean;
  /** The whole-SUM conformance statements registered against this protocol,
   * one entry per sum type. Written by the desugaring of `type <sum> is P`,
   * and read when that sum gains a variant, so the new variant gets the same
   * implementation. Absent while no sum conforms to this protocol. */
  _sumConformances?: SumConformanceRecord[];
  /** REDEFINITION DISCIPLINE — which compilation unit and which declaring
   * STATEMENT this record came from
   * (`docs/TYPE-SYSTEM.md`). The DECLARATION-level
   * counterpart of {@link ConformanceRecord._implOrigin}, which stamps
   * implementation blocks: a second `protocol` statement for this name in the
   * same batch is `protocol-redefinition`, while a later batch replaces.
   * Absent on a box-route or host-API declaration, which replace freely. */
  _declOrigin?: DeclarationOrigin;
};

/** The host-API shape of a protocol's requirements. A flat
 * `Record<string, string>` cannot represent properties, hence the three
 * buckets (Appendix A "Host API"). */
export type ProtocolMembersInput = {
  functions?: Record<string, string>;
  readonly?: Record<string, string>;
  readwrite?: Record<string, string>;
};

/** The host-API shape of an IMPLEMENTATION block. Property handlers are given
 * under their surface names (`getters.hash`), not under the internal
 * `__get__hash` mangling (Appendix A "Properties": the mangling is an
 * implementation detail, not part of the public surface). */
export type ProtocolImplementationInput = {
  functions?: Record<string, ProtocolHostHandler>;
  getters?: Record<string, ProtocolHostHandler>;
  setters?: Record<string, ProtocolHostHandler>;
};

/**
 * The options of `ce.declare(id, def, options)`.
 *
 * - `scope`: the scope the declaration is installed in. The default is the
 *   current lexical scope.
 * - `extend`: when `true`, `def` is a PATCH applied to the operator definition
 *   currently visible for `id`, not a new definition. See
 *   {@link OperatorDefinitionPatch}.
 *
 * @category Definitions
 */
export type DeclareOptions = {
  scope?: Scope;
  extend?: boolean;
};

/**
 * The result of `ce.infer()`.
 *
 * - `declared`: each name that `ce.infer()` declared in its home scope, or
 *   whose inferred definition it narrowed there, with the type it has now.
 * - `skipped`: each symbol of the expressions that it did not change, with
 *   the reason:
 *   - `'conflict'`: the expressions require types that have no common
 *     subtype (`x + 1` and `x(3)`), or a type that has none in common with
 *     the inferred definition of the name;
 *   - `'untyped'`: no use requires a type of the name (`q` in `[q]`), or the
 *     requirements give the type `unknown`;
 *   - `'defined'`: the home scope holds a definition of the name with a
 *     declared type (`ce.declare('x', 'real')`). A definition with the
 *     declared type `unknown` states no type: `ce.infer()` gives it the type
 *     that the uses require;
 *   - `'out-of-scope'`: the home scope is not the current scope or one of its
 *     ancestors (it was popped).
 *
 * A symbol whose type is already the type that the uses require, a symbol
 * of the library (`Pi`), a parameter of a function literal, the variable of
 * a binder (the index of a `Sum`) and a symbol declared in a scope that was
 * popped are in neither list.
 *
 * Each list is sorted by name, then by the depth of the scope.
 *
 * @category Definitions
 */
export type InferResult = {
  declared: { name: string; scope: Scope; type: Type }[];
  skipped: {
    name: string;
    scope: Scope;
    reason: 'conflict' | 'untyped' | 'defined' | 'out-of-scope';
  }[];
};

/**
 * The patch `ce.declare(id, patch, { extend: true })` applies to the operator
 * definition currently visible for `id`.
 *
 * The engine builds a NEW definition from the fields of the visible one and
 * the fields of the patch, and installs it in the target scope. A field the
 * patch does not name keeps its value. A field the patch names replaces the
 * old value: when two extensions give the same handler (two `evaluate`
 * handlers, for example), the later one wins. The visible definition is not
 * changed, so an expression boxed before the extension keeps using it.
 *
 * - `signature` replaces the signature.
 * - `addSignature` adds an overload: the new signature is the intersection
 *   `old & addSignature`. A call that matches both arms resolves to the old
 *   arm first.
 *
 * In both cases the new signature must be a subtype of the old one, so that
 * every call that was valid stays valid. For example `(value, value*) -> set`
 * can replace `(set<any>, value*) -> set`, but `(any*) -> any` cannot replace
 * `(value+) -> value`. This does not apply when the old signature was only
 * inferred (`inferredSignature` is `true`: an operator declared without a
 * signature, or a function whose signature is inferred from its body),
 * since such a signature is not a contract.
 *
 * Extending a standard-library operator without replacing its `evaluate`,
 * `canonical`, `compile` or `derivative` handler (for example, to add a
 * description or a wider signature) keeps it a library operator: `D`,
 * compilation and the numeric evaluation of the library still apply to it.
 * An extension that replaces one of these handlers is treated as a user
 * definition with the same name, as a plain `ce.declare()` is.
 *
 * @category Definitions
 */
export type OperatorDefinitionPatch = OperatorDefinition & {
  addSignature?: Type | TypeString;
};

export interface IComputeEngine {
  /** The LatexSyntax instance used for LaTeX parsing/serialization.
   *  `undefined` when no LatexSyntax was provided to the constructor and
   *  the entry point has no LaTeX support (the core-only bundle).
   *
   *  To add a notation to a running engine, call
   *  `ce.latexSyntax.addEntries([...])`: later parses and serializations use
   *  the new entries. An engine created without the `latexSyntax` option
   *  has its own instance, so the change applies to that engine only. An
   *  instance given to several engines with the `latexSyntax` option is
   *  shared: the change applies to all of them.
   */
  readonly latexSyntax: ILatexSyntax | undefined;

  /** @internal Returns the LatexSyntax instance or throws if unavailable. */
  _requireLatexSyntax(): ILatexSyntax;

  /** @internal An optional symbolic-integration provider. When set, the
   * `Integrate` evaluator consults it for an indefinite antiderivative before
   * falling back to the built-in `antiderivative()`. Returns a closed-form
   * antiderivative (an expression in `variable`), or `null`/an inert
   * `Integrate` when it cannot integrate the integrand. This is the slot the
   * opt-in `loadIntegrationRules()` (Rubi rule driver) registers into. */
  _integrationProvider?: IntegrationProvider;

  /** Engine-wide LaTeX parse/serialize options (e.g. `decimalSeparator`).
   *  Merged into every `parse()` and `toLatex()` call between LatexSyntax
   *  defaults and per-call overrides. */
  latexOptions: Partial<ParseLatexOptions & SerializeLatexOptions>;

  // Common symbols
  readonly True: Expression;
  readonly False: Expression;
  readonly Pi: Expression;
  readonly E: Expression;
  readonly Nothing: Expression;
  /** The `Missing` symbol: an absent value whose position is preserved. */
  readonly Missing: Expression;

  readonly Zero: Expression;
  readonly One: Expression;
  readonly Half: Expression;
  readonly NegativeOne: Expression;
  readonly Two: Expression;
  /** ImaginaryUnit */
  readonly I: Expression;
  readonly NaN: Expression;
  readonly PositiveInfinity: Expression;
  readonly NegativeInfinity: Expression;
  readonly ComplexInfinity: Expression;

  readonly context: EvalContext;
  contextStack: ReadonlyArray<EvalContext>;

  /** @internal */
  _evalContextStack: EvalContext[];

  /** @internal */
  _isVerifying: boolean;

  /** @internal */
  readonly isVerifying: boolean;

  /** @internal */
  readonly _typeResolver: TypeResolver;

  /** The engine-level type registry: one namespace of declared types per
   * engine, world state alongside symbol assignment. Types are NOT lexically
   * scoped — a name means the same thing everywhere in the engine, for the
   * engine's lifetime (see `docs/TYPE-SYSTEM.md`).
   * All reads and writes go through `_typeResolver` / `declareType()`.
   * @internal */
  readonly _typeRegistry: Record<string, TypeReference>;

  /** Capture the type registry's state; the returned thunk restores it.
   * Used by the Epsil static pre-pass to discard its canonicalization-time
   * type registrations (see `ComputeEngine._typeRegistryRollbackPoint`).
   * @internal */
  _typeRegistryRollbackPoint(): () => void;

  /** The engine-level PROTOCOL registry — the second kind of registry entry
   * the global-type-registry design pre-writes (its §5), not a second scoping
   * regime. Protocols are engine-global, like types: a protocol name means the
   * same thing everywhere in the engine, for the engine's lifetime.
   *
   * Protocol names are NOT types (ruling P8): they never enter
   * `_typeRegistry`, `knownTypeNames` or the type resolver.
   * @internal */
  readonly _protocolRegistry: Record<string, ProtocolRecord>;

  /** Capture the protocol registry's state; the returned thunk restores it.
   * The protocol mirror of {@link _typeRegistryRollbackPoint}, invoked by the
   * Epsil static pre-pass alongside it.
   * @internal */
  _protocolRegistryRollbackPoint(): () => void;

  /** The names of the protocols whose closure MAY declare one member name
   * twice, recorded when a protocol replacement creates such a conflict for
   * a protocol that extends it. A replacement does not refuse that case,
   * because the program that resolves it (it removes the member from the
   * extending protocol, too) re-declares the extending protocol AFTER the
   * replacement. The end of every Epsil batch checks each recorded name
   * again, reports `protocol-extends-member-conflict` for each conflict still
   * present, and removes the names whose conflict is gone. The set is not
   * restored by the registry rollback point: a name recorded by a rolled-back
   * replacement is checked again and dropped.
   * @internal */
  readonly _protocolExtendsConflicts: Set<string>;

  /** The engine-level KIND registry: the value kinds declared by the
   * `arithmetic` field of operator definitions. Engine-level like the type
   * registry: a head declared with a kind in a nested scope registers its
   * type for the engine, and popping the scope does not unregister it. Read
   * and written through `boxed-expression/value-kinds.ts` only.
   * @internal */
  readonly _kindRegistry: KindRegistryState;

  /** A monotone counter that advances on every mutation of the protocol /
   * conformance registry — a protocol declaration or re-declaration, a
   * conformance edge, an implementation block, and the static pre-pass's
   * registry rollback.
   *
   * It is the cache key of the DERIVED dispatcher effect unions
   * (`docs/TYPE_SYSTEM_ROADMAP.md`, Appendix B, "Changing a field is an
   * effect"): a protocol function requirement with a BARE specifier imposes
   * no effect bound, and the dispatcher's effect set is the union of the
   * inferred effects of the registered conforming implementations. That union
   * is recomputed lazily, and — per that section's implementation note, "the
   * effects cache's key must include the conformance registry among its
   * axes" — a memo of it is valid only while both this counter and
   * {@link _callableVersion} are unchanged.
   *
   * READ-ONLY: advanced only through
   * {@link _noteConformanceRegistryChange}.
   * @internal */
  readonly _conformanceVersion: number;

  /** Advance {@link _conformanceVersion}. Called at every protocol /
   * conformance registry mutation site, adjacent to the `config` state event
   * those sites already report.
   * @internal */
  _noteConformanceRegistryChange(): void;

  /** True while a result computed now may be thrown away: the Epsil static
   * check runs (it reads its own declarations, and puts back the
   * definitions it wrote without moving every version a cache keys on), or
   * the trial of an overload arm is in progress (a read takes the entry of
   * the trial environment first, `EngineBoxingState.withTrial()`). A cache
   * does not store a result then.
   * @internal */
  _resultMayBeDiscarded(): boolean;

  /** How many `evaluateAsync` calls are in flight, including ones suspended
   * at an `await`. A suspended async evaluation holds its eval context across
   * the suspension and hands control back to the host, so — unlike a
   * synchronous one — it is NOT visible as eval-context stack depth.
   * @internal */
  _inFlightAsyncEvaluations: number;

  /** How many function-expression evaluations are on the host call stack.
   * Nonzero means an evaluation is in progress, which no other engine signal
   * reports: a plain `evaluate` handler pushes no eval context.
   * @internal */
  _evaluationDepth: number;


  _delegatedEvaluations: number;

  /** The `ce.effects` registry captured by the synchronous evaluation that is
   * running now, or `undefined` when none is running. It is set when a
   * top-level `evaluate()` starts and cleared when it returns, so every
   * operator handler inside one evaluation receives the same registry even if
   * `ce.effects` is assigned while the evaluation runs. The asynchronous
   * evaluation driver also sets it around each synchronous handler call, to
   * the registry that asynchronous evaluation captured, so that nested
   * synchronous evaluations inherit it.
   * @internal */
  _evaluationEffects: EffectHandlers | undefined;

  /** The number of significant digits requested by the `N(x, p)` call that
   * is running now, or `undefined` when none is running. `N(x, p)` sets it
   * to `p` for the duration of the evaluation of `x` and restores the
   * previous value after, so a nested `N(y, q)` applies to `y` only. An
   * `evaluate` handler receives it as `options.precision` when
   * `numericApproximation` is `true`; when it is `undefined`, the handler
   * receives `ce.precision` instead. It is an engine slot, not an evaluate
   * option, so that it also reaches the evaluations that a handler starts
   * without passing its own options along.
   * @internal */
  _requestedPrecision: number | undefined;

  /** `true` while the innermost evaluation of a function expression that
   * is running now was asked for a numeric approximation (`.N()`), `false`
   * otherwise. `BoxedFunction.evaluate()` sets it from its
   * `numericApproximation` option for the duration of the evaluation and
   * restores the previous value after, so a nested exact evaluation reads
   * `false`. The asynchronous driver (`BoxedFunction.evaluateAsync()`) sets
   * it the same way around the synchronous part of each handler call, and
   * restores it before the `await`: an asynchronous evaluation that is
   * suspended does not hold the slot, so another evaluation that runs in
   * the meantime does not read its request. The collection handlers have
   * no evaluation options, and read the numeric request of the evaluation
   * that calls them here: the handlers of a list literal with an element
   * that may evaluate to `Nothing` then resolve only that element, and
   * leave the other elements for the caller to approximate
   * (`erasedLiteralValue`, `collection-utils.ts`).
   * @internal */
  _numericRequest: boolean;

  /**
   * Incremented on every mutable-object field store — the one engine write
   * that advances no engine-wide cache axis (`object-store` in
   * `axisMaskOf`: field-derived caches carry per-object versions instead).
   * Together with `_semanticVersion` it stamps the pure-application memo,
   * whose entries have no object to carry a version for; see
   * `_applicationMemo`.
   * @internal */
  _objectStoreEpoch: number;

  /**
   * Results of applying a PURE user-function literal to number-literal
   * arguments, keyed by the literal and the arguments (`function-utils.ts`,
   * `makeLambda`). A recursive definition such as
   * `R(i,x,y) = R(i-1,x,y) + S(x,y,R(i-1,x,y))` applies itself twice per
   * level, so an evaluation at depth 20 ran the body 2^20 times where 20
   * distinct applications exist; the memo answers the repeats.
   *
   * The memo lives for the ENGINE's lifetime, not one top-level
   * evaluation's: the elements of a lazy collection are pulled by later,
   * separate top-level evaluations, and `[P(i) for i in 0..n]` over a
   * self-recursive `P` must find `P(i-1)` computed by the previous
   * element's pull, or every element re-runs the recursion from the bottom
   * (n(n+1)/2 step calls where n suffice — Tycho's D-264 point chain). Each
   * literal's result map is bounded (`MAX_APPLICATION_MEMO_RESULTS`,
   * emptied when full), and the literal keys a `WeakMap`, so the memo never
   * outgrows the live literals. A numerically requested application also
   * stores its exact result under the exact key: a recursive body applies
   * itself through the exact route, so that is the entry the next element
   * looks up. A handler-backed function (`ce.declare` with an `evaluate`
   * handler) that reads host state outside the engine MUST declare an
   * effect in its signature, or a body that calls it is memoized as pure.
   *
   * This memo takes no part in the object-dependency channel of
   * `object-deps.ts` (no per-entry object dependencies, no merge into open
   * collectors on a hit, no `containsObject` refusal at the store), and
   * that rests on two refusals made elsewhere: the dependency snapshot
   * answers `undefined` for a literal that can reach an object
   * (`snapshotMemoDeps`), so a body that reads a field is never stored
   * here and re-reads the field inside every enclosing cache-backed
   * computation; and constructing an object is a `state` effect, so a body
   * that returns a fresh object is impure and never memoized. Relaxing
   * either refusal requires wiring this memo into that channel first, or an
   * enclosing cache entry would serve a stale field-derived value after a
   * store (`recursive-application-memo-across-evaluations.test.ts` pins
   * both).
   *
   * An entry is valid only while `_worldVersion`
   * and `_objectStoreEpoch` are both unchanged AND the literal's dependency
   * snapshot still validates (`snapshotMemoDeps` / `memoDepsStillValid`,
   * `collection-element-memo.ts` — one `_writeVersion` per value definition
   * the body reads, plus the re-resolution of every free name). The WORLD
   * axis is the right engine-wide guard here: it moves on a redefinition, an
   * assumption, a configuration change and a signature inference, and never
   * on a plain value write (`axisMaskOf`,
   * `engine-configuration-lifecycle.ts`). Value writes are caught per
   * definition by the snapshot's `_writeVersion` check instead, which is
   * what an entry needs: a pure body may read an assigned free symbol or the
   * INDEX of an enclosing binder, and `Σ_i` applying `n ↦ i·n` writes `i`
   * ephemerally, so without the snapshot iteration 1's results were served
   * to every later iteration. A coarser stamp would empty the memo for a
   * write the entry does not depend on — an assignment made between two
   * element pulls of a lazy collection restarts the whole recursion. The
   * memoized body's own parameter bindings advance neither axis, so the
   * recursion the memo exists for cannot defeat its own stamp. This mirrors
   * the element memo and `BoxedFunction._memoizedFacet`, which key on the
   * same axis. `deps` is the element memo's `MemoDeps`, typed opaquely here
   * to keep this interface free of that module.
   * @internal */
  _applicationMemo:
    | WeakMap<
        Expression,
        {
          worldVersion: number;
          objectStoreEpoch: number;
          deps: unknown;
          results: Map<string, Expression>;
        }
      >
    | undefined;

  /**
   * Run `fn` inside one boxing-pass window (the `_inferenceTxDepth` /
   * `_freshlyInferred` lifecycle that `box()` and `parse()` open around
   * themselves). For a caller — the Epsil static checking pass — whose
   * boxing spans several `box()` calls: the per-statement `box()` windows
   * nest inside it.
   * @internal */
  _withBoxingPassWindow<T>(fn: () => T): T;

  /** Declare a protocol (Appendix A "Host API"). Throws on error, including
   * on re-declaration — the Epsil statement route replaces instead (P5).
   *
   * `options.extends` lists the PARENTS of the protocol, protocols that must
   * already be declared:
   *
   * ```js
   * ce.declareProtocol('PartialOrder', {
   *   functions: { compare: '(self: Self, other: Self) -> integer' },
   * });
   * ce.declareProtocol('LinearOrder', {}, { extends: ['PartialOrder'] });
   * ```
   *
   * A type that conforms to `LinearOrder` then conforms to `PartialOrder`
   * too: a conformance to a protocol registers a conformance to each of its
   * ancestors that the type does not already conform to, and the
   * implementation given to `declareProtocolImplementation` may implement
   * the members of every ancestor. A protocol may not declare a member that
   * one of its ancestors declares (`protocol-member-inherited`), and two
   * parents whose ancestors declare the same member name cannot be extended
   * together (`protocol-extends-member-conflict`). An `extends` value that is
   * not an array of strings, or that lists a name twice, throws
   * `invalid-protocol-declaration`; a name that is not a declared protocol
   * throws `protocol-unknown`. */
  declareProtocol(
    name: string,
    members: ProtocolMembersInput,
    options?: { extends?: readonly string[] }
  ): void;

  /** Implement `protocol` for `type`, declaring the conformance edge if it is
   * not already registered (Appendix A "Host API").
   *
   * THROWS on every error — the host channel; the Epsil statement route
   * returns error VALUES instead. A second host implementation of the same
   * (type, protocol) pair throws rather than replacing (P5).
   *
   * The callbacks are JavaScript functions, so they carry no signature the
   * engine can check: they are trusted like host-declared operator handlers,
   * and only member-name coverage, unknown members and a `set` handler on a
   * `readonly` property are validated.
   *
   * `options.where` declares a CONDITIONAL conformance: `type` is then a HEAD
   * PATTERN naming the variables (`'list<T>'`) and `where` is the clause SOURCE
   * that binds them (`'where T is Comparable'`; the `where` word may be
   * omitted). A malformed clause, or a head variable the clause does not bind,
   * throws. */
  declareProtocolImplementation(
    type: string,
    protocol: string,
    impl: ProtocolImplementationInput,
    options?: { where?: string }
  ): void;

  /**
   * Whether `type` conforms to `protocol`, answered without calling any of
   * the protocol's members. An unknown protocol answers `false`.
   *
   * Inheritance included: a conformance registered for a supertype answers
   * for its subtypes. A CONDITIONAL conformance (`list<T> is P where T is
   * P`) recurses, deciding itself against `type`'s own arguments.
   *
   * `type` may be a `TypeString`, parsed the way {@link IComputeEngine.type}
   * parses one.
   */
  conformsTo(type: Type | TypeString, protocol: string): boolean;

  /** Depth of enclosing static type-check passes (the Epsil pre-pass).
   * Non-zero while `staticDiagnostics` canonicalizes a program under its
   * 'epsil:static-check' frame; the `DeclareType` top-level surrogate check
   * requires BOTH the frame name and this counter, so a host `pushScope`
   * with the same name cannot forge the surrogate.
   * @internal */
  _staticTypeCheckDepth: number;

  /** The id of the Epsil BATCH currently executing — one `executeEpsil` run,
   * spanning BOTH its static pre-pass and its evaluation loop — or
   * `undefined` outside any batch. Set by `executeEpsil` (the same posture as
   * {@link IComputeEngine._staticTypeCheckDepth}: a batch is an `src/epsil`
   * notion, the engine only holds the flag) and read by the protocol
   * registry, which stamps every implementation it installs inside a batch so
   * that a SECOND implementation block for the same (type, protocol) pair in
   * one batch is `protocol-implementation-duplicate`, while a
   * re-implementation in a later batch replaces (ruling P47).
   * @internal */
  _epsilBatchId: number | undefined;

  /** Remove the iteration limit of this engine, unless a host has assigned
   * `iterationLimit` (an assigned limit is kept). Called by `executeEpsil`
   * before a program runs: a loop written by the author of a program runs
   * until it ends, and the host's time budget is the bound. The limit is not
   * put back after the run, because the value of a program can be a lazy
   * collection that the host enumerates later, and that walk must not stop
   * at a limit the program itself did not have.
   * @internal */
  _liftDefaultIterationLimit(): void;

  /** Assignment EVIDENCE the Epsil static pre-pass established, keyed by the
   * symbol's value-definition record. Set (and restored) only by
   * `staticDiagnostics`: when the pass applies the type effect of a
   * top-level assignment (`x = g()` ⇒ `x : number`, statically, nothing
   * evaluated), it records the right-hand side's RAW type here so that
   * argument validation's evidence-beats-requirement guard can treat the
   * symbol as ASSIGNED — a later use then CHECKS against this evidence
   * (raw, not widened, for the same reason the runtime guard checks the
   * held VALUE's type: widening stores a `Complex` under `number`, which a
   * `complex` parameter must still admit). `undefined` outside the pass.
   * @internal */



  /** `true` only while the Epsil interpreter is canonicalizing or evaluating a
   * top-level statement whose AST head is `DeclareType`, `DeclareSumType` or
   * `DeclareProtocol` — the REDEFINITION DISCIPLINE's statement-route marker
   * (`docs/TYPE-SYSTEM.md`).
   *
   * {@link IComputeEngine._epsilBatchId} alone cannot play this part: it is
   * ambient for the WHOLE `executeEpsil` extent, so a `ce.box(["DeclareType",
   * …]).evaluate()` performed re-entrantly from a host operator's evaluate
   * handler would run with a batch live and be mistaken for a statement of the
   * program — after which the program's own declaration of that name would
   * falsely report `type-redefinition`. The marker says WHICH ROUTE is
   * declaring; the batch id says which unit.
   *
   * Set by `src/epsil/execute-epsil.ts` and `src/epsil/static-diagnostics.ts`
   * around the statement they process, and SAVED AND CLEARED by each
   * `Declare*` handler for the duration of its own body, so a declaration made
   * re-entrantly from inside one sees no marker. It is not consumed by being
   * read: one statement registers up to three times per batch (pre-pass
   * canonicalize, eval-loop canonicalize, evaluate) and all three must be
   * stamped, or the statement's own re-registration looks like a duplicate.
   * @internal */
  _epsilDeclarationRoute: boolean;

  /** Independent Epsil time limit per Program statement, in milliseconds.
   * @internal */
  _epsilStatementTimeLimitMs: number | undefined;

  /** Called with each statement and its value, after the statement
   * evaluated: a statement of a statement list (a `Block` body, a function
   * body, an `if` branch, a loop body) that carries `sourceOffsets`, that
   * is, a statement written in Epsil source. Called by `evaluateStatements`
   * and `evaluateStatementsAsync` (`function-utils.ts`), at the same place
   * as the debugger's statement-result hook.
   *
   * Also called with the collection of each `Element` clause of a `Loop` or
   * a `Comprehension` that carries `sourceOffsets` (a loop or comprehension
   * header written in Epsil source) and its value, each time the clause
   * evaluates it (`runNested`, `library/control-structures.ts`).
   *
   * A top-level Program statement also supplies its canonical index and any
   * caught failure. Nested statements and collection headers omit the index.
   * Set by `executeEpsil` for the duration of Program evaluation, so that
   * a nested statement whose value is discarded and holds an error (an
   * `Error` cell in a list built in a loop) is reported as a diagnostic, as
   * a top-level statement is. `undefined` (the default) outside a run.
   *
   * This is a field of the engine, and not a module-global hook such as
   * the debugger's, because the engine code that calls it and the Epsil
   * code that sets it can be in two different bundles (a host may load two
   * copies of the engine, for example two package versions), and each bundle
   * then has its own copy of a module variable. The engine object is the one
   * value both bundles share.
   * @internal */
  _epsilStatementResultHook:
    ((statement: Expression, result: Expression, programIndex?: number, error?: unknown) => void) | undefined;

  /** Absolute time (`Date.now()` epoch ms) beyond which evaluation should
   * not proceed, or `undefined` when no time limit is active. A derived view
   * of `_deadlineFrame` (which adds attribution); prefer passing
   * `_deadlineFrame` to `checkDeadline`. Read-only: a deadline is armed only
   * by a `withTimeLimit` span.
   * @internal
   */
  readonly _deadline?: number | undefined;

  /** The full deadline frame (effective deadline plus attribution).
   * @internal
   */
  _deadlineFrame?: DeadlineFrame | undefined;

  /** Whether a definition of `id` (a LaTeX assignment `\sin(x) \coloneq 5`, an
   * Epsil definition `Sin(x) := 5`) would replace a function of a library of
   * the engine for every later computation. A function that the host or an
   * earlier program defined in its place is not a library function.
   * @internal
   */
  _isLibraryFunction(id: MathJsonSymbol): boolean;

  /** The innermost active `WithRandomSeed` frame (see
   * `withRandomSeedFrame`), or `undefined` when random draws are live.
   * @internal
   */
  _randomFrame?: RandomSeedFrame | undefined;

  /** Time remaining before _deadline
   * @internal
   */
  _timeRemaining: number;

  /** Instrumentation counters for the auto-compilation of lazy-`Map` element
   * lambdas on numeric drains: how many compile attempts were made, how many
   * elements a compiled function served, how many dependency re-validations,
   * recompiles, per-element interpreter fallbacks and NaN double-checks
   * occurred. This is the only surface that says whether a given `Map` drain
   * compiled, re-validated or fell back.
   *
   * ## Read the counters BEFORE stringifying anything
   *
   * The instrument has several ways of handing a careful reader numbers that
   * look right and are not. None throws or warns, so start with the one that
   * fires on the most reflexive debugging action there is — printing the
   * value:
   *
   * ```ts
   * const before = { ...ce._mapAutoCompileStats };
   * const r = ce.parse(MAP).N();
   * console.log(r.evaluate().toString());        // ← "just looking at it"
   * const d = delta(before, ce._mapAutoCompileStats);  // attempts 1, hits 10
   * ```
   *
   * That reads as "`evaluate()` compiles 10 elements". It does not:
   * `evaluate()` compiles NOTHING, and `toString()` is the consumer.
   * Serializing a lazy result materializes a fixed 10-element preview
   * regardless of the drain size, so stringifying inside a measured region
   * both does work and RELOCATES the attribution onto whatever call preceded
   * it. The reader ends up with a coherent, wrong causal picture in which
   * nothing looks off.
   *
   * ## Three gates, all of which fail as zeros
   *
   * The counters move only when all three hold, and a zero means "the
   * instrument was inert", not "the path did not run":
   *
   * 1. `ce.precision === 'machine'`. At the default bignum-preferred
   *    precision the float tier never attempts — correctly, since at bignum
   *    the interpreter produces digits float64 cannot match.
   * 2. A numeric route: `.N()`, or `.evaluate()` on a body marked with
   *    `NumericApproximation(…)` or `N(…)`. A bare `.evaluate()` reports zero
   *    at any drain size.
   * 3. The lazy result must actually be CONSUMED. `.N()` on a `Map` returns a
   *    lazy collection; if nothing iterates it, nothing compiles.
   *
   * "Consumed" is narrower than "touched" — measured one call at a time at
   * n = 2000, machine precision, `Range`-sourced, as `attempts`/`compiledHits`:
   *
   * ```text
   *   .N()          0 / 0      builds the lazy collection, compiles nothing
   *   .evaluate()   0 / 0      compiles NOTHING
   *   .toString()   1 / 10     serializing materializes a 10-element preview
   *   [...each()]   1 / 2000   the whole drain
   *   .at(1500)     1 / 1      exactly one element
   *   .count        0 / 0      answers structurally
   *   .json         0 / 0      answers structurally
   * ```
   *
   * ## Scope: the counters and the cache do not match
   *
   * The counters are process-global and cumulative, not per-engine — every
   * engine returns the same object and `new ComputeEngine()` does not reset
   * it — so absolute reads are meaningless and a multi-engine process
   * aggregates. Always take DELTAS across the region you are measuring.
   *
   * The compile CACHE has a different scope from the counters, which is worth
   * stating side by side because the natural assumption is that they match:
   * the cache keys on the expression SHAPE (re-parsing does not defeat it) and
   * is PER-ENGINE, while the counters are MODULE-WIDE. So a second measurement
   * of the same `Map` shape in the same engine reads 0/0. Comparing routes by
   * running them in sequence — the natural way to build the table above —
   * gives a real number for the first route and zeros for the rest, which
   * reads as "only `each()` compiles". Measure each route in a FRESH engine,
   * and still take deltas.
   *
   * One more source-shape property that is not a defect: `iterationLimit`
   * never gates the counters, but it does bound the DRAIN for a
   * COMPREHENSION-sourced collection, because the limit is spent materializing
   * the comprehension before the `Map` ever drains. A `Range`-sourced
   * collection is lazy and costs no iterations. So an instrument sourced from
   * a comprehension must raise `iterationLimit` above the element count.
   *
   * Reachable at runtime with no stability promise, like the other
   * `_`-prefixed members: the shape and the counter set may change.
   * @internal
   */
  readonly _mapAutoCompileStats: MapAutoCompileStats;

  /** The statistics of the engine's memoization caches: for each cache
   * class (the type, sign and effects caches of a function expression, the
   * lazy-collection value cache, the stored value of a symbol, the element
   * memo of a collection, the type-parse cache), how many reads were hits,
   * and why each miss happened.
   *
   * Recording is off by default and costs one branch per cache read. Set
   * `enabled` to `true` to start it:
   *
   * ```ts
   * ce._cacheStats.reset();
   * ce._cacheStats.enabled = true;
   * ce.parse('\\sum_{n=1}^{10} n^2').evaluate();
   * ce._cacheStats.enabled = false;
   * console.log(ce._cacheStats.report());
   * ```
   *
   * The counters are process-global, not per-engine: every engine returns
   * the same object. Take the difference of two `snapshot()` results, or call
   * `reset()` before the region to measure.
   *
   * Reachable at runtime with no stability promise, like the other
   * `_`-prefixed members: the shape and the counter set may change.
   * @internal
   */
  readonly _cacheStats: CacheStatsControl;

  /** Names defined by a library that was NOT one of the engine's standard
   * libraries, i.e. a `LibraryDefinition` object supplied by the caller to the
   * constructor's `libraries` option. Caller-supplied libraries are installed
   * into the SYSTEM scope (bootstrap runs between `pushScope('system')` and
   * `pushScope('global')`), so scope identity alone cannot tell an
   * engine-authored definition from a caller-authored one; this set records the
   * provenance. Populated once, at bootstrap: `loadLibrary()` installs into
   * the GLOBAL scope, where comparing with the system-scope binding already
   * tells a caller definition from a built-in one, and does not add to it.
   * @internal */
  readonly _customLibraryOperators: Set<string>;

  /** For each name a library defined — standard or caller, at construction
   * or with `loadLibrary()` — the library name and the binding it
   * installed. `libraryOf()` answers the library name only while the name
   * still resolves to that binding.
   * @internal */
  readonly _libraryProvenance: Map<
    string,
    { library: string; binding: BoxedDefinition }
  >;

  /** The libraries loaded on this engine, by name, in load order: at
   * construction, then by `loadLibrary()`. A `requires` entry of a library
   * given to `loadLibrary()` must name one of them.
   * @internal */
  readonly _loadedLibraries: Map<string, LibraryDefinition>;

  /** The `any` invalidation axis (read-only; advanced only through
   * `_noteStateEvent`). @internal */
  readonly _anyVersion: number;

  /** The version that keys the type cache: the `any` axis without the
   * events of a call of a function literal (`typeVersion`,
   * `engine-configuration-lifecycle.ts`). @internal */
  readonly _typeVersion: number;

  /** Semantic-mutation counter (see `ComputeEngine._semanticVersion`).
   * @internal */
  readonly _semanticVersion: number;

  /** Rarely-bumped global-semantics counter (see
   * `ComputeEngine._worldVersion`).
   * @internal */
  readonly _worldVersion: number;

  /** The `callable` invalidation axis (read-only; advanced only through
   * `_noteStateEvent`) — keys `BoxedFunction._effects`. @internal */
  readonly _callableVersion: number;

  /** Advanced when an existing definition changes (a retype, or a change
   * of a callable other than a declaration); see
   * `EngineConfigurationLifecycle.definitionVersion`. @internal */
  readonly _definitionVersion: number;

  /** Advanced by every state event that can change the value a node
   * evaluates to in an evaluation frame that is still on the stack; see
   * `EngineConfigurationLifecycle.evaluationVersion`. @internal */
  readonly _evaluationVersion: number;

  /** `_evaluationVersion` less the ephemeral value writes; see
   * `EngineConfigurationLifecycle.persistentEvaluationVersion`. @internal */
  readonly _persistentEvaluationVersion: number;

  /** When > 0, value writes are ephemeral loop-index writes.
   * @internal */
  _ephemeralWriteDepth: number;

  /** When > 0, the assumptions store reads as EMPTY to every consumer that
   * QUERIES it through `contextAssumptions()`, so a computation bracketed by
   * this depth answers as if no assumption were in force. Sites that COPY or
   * SNAPSHOT the store (a scope push) are exempt and keep
   * reading `ce.context.assumptions` directly.
   * @internal */
  _factSuppressionDepth: number;

  /** Run `thunk` with the assumptions hidden — the bracket every routine that
   * WRITES a type, a signature or a definition puts around its whole
   * derive-and-write phase, so that what it stores is a function of the
   * declarations and the stored values alone and stays true when a fact is
   * retracted.
   *
   * Re-entrant (the depth is a counter) and restored on the way out, an
   * exception included. SYNCHRONOUS ONLY: a thunk that returns a promise
   * throws, because its work would resume after the bracket closed. `assume()`
   * and `forget()` throw inside the bracket — mutating the fact store from a
   * computation that cannot see it is a program error.
   * @internal */
  _withoutFacts<T>(thunk: () => T): T;

  /** Is a fact-blind bracket hiding anything RIGHT NOW — that is, is
   * `_factSuppressionDepth` above zero AND does the current context actually
   * hold an assumption or an assumed value?
   *
   * The second half matters: with an empty store the accessors answer the same
   * on both sides of a bracket, so the bracket is observationally a no-op and
   * must not split a memo into two cells. Splitting it anyway costs an
   * assumption-free engine a second derivation of every node a write reads —
   * and worse, it leaves the LIVE cell of such a node cold, which takes away
   * the previous value a self-referential derivation terminates on.
   *
   * Every memo that carries the suppression state — the composite generation
   * below, and the `factsHidden` fields listed in
   * `docs/plans/2026-08-30-assumptions-memo-inventory.md` — asks this rather
   * than reading the depth, so they all agree on when the two sides differ.
   * A fact MUTATION is refused on the raw depth instead: `assume()` inside a
   * bracket is a program error whether or not anything is assumed yet.
   * @internal */
  _factsHidden(): boolean;

  /** The composite key every generation-keyed memo uses: the `any`
   * invalidation axis in the high bits, and whether the assumptions are
   * hidden right now in the low bit — `_anyVersion * 2 + (_factsHidden() ? 1 : 0)`.
   *
   * A computation that runs while the facts are hidden derives a DIFFERENT
   * answer from the same node, so its result must not be served to a read
   * that can see the facts, and the other way round. The suppression state
   * cannot be carried by an axis bump instead: a bump inside a scope makes
   * the pop of that scope permanently dirty. Mixing the state into the memo
   * key leaves every axis where it is.
   *
   * A VALUE SHIELD (`simplifyValueBlind` in `boxed-expression/simplify.ts`,
   * `withValueShield` in `boxed-expression/utils.ts`) is the other state
   * that changes the answer of a node: while it is on the stack, a symbol
   * that has an assigned value reads no value, and EXISTING expressions are
   * affected too, because a symbol reads its VALUE by name through the
   * current scope chain (`valueDefinitionInContext`, `binders.ts`), so a
   * sign, and a type that depends on a value or a sign, differ inside the
   * shield. So inside a shield the high bits are a key of that shield
   * extent (`_withValueShieldKey()`), a negative integer that no value of
   * the `any` axis can equal, minted again whenever the axis moves inside
   * the shield: an answer derived outside the shield, from the value, is
   * not served inside it, an answer derived inside, blind to the value, is
   * not served outside, a write inside the shield still retires what was
   * cached earlier in it, and the pop restores the outer key, so the caches
   * computed outside stay valid across the shield. A node read on both sides
   * is computed once on each side (the shield key selects the same cell as
   * the outer key, so the entry is overwritten); that is the cost of a
   * shield, and it is bounded by the nodes the shield reads, where an axis
   * advance retired every node in the engine.
   * @internal */
  _cacheGeneration(): number;

  /** The key of the type cache of a function expression
   * (`BoxedFunction.type`): `_typeVersion` in place of the `any` axis, with
   * the same facts bit. Only the type cache uses it, so its
   * values never meet a key of `_cacheGeneration()` in one cell. Inside a
   * value shield it is the shield key, which moves with the `any` axis and
   * is negative, so it never equals a key made from `_typeVersion`.
   * @internal */
  _typeCacheGeneration(): number;

  /** The key of the type cache of a function expression whose type
   * computation read an answer that depends on the computations in
   * progress, not only on the bindings: a cycle of type or effect reads
   * answered provisionally, or a derivation of the result of a call
   * declined because the same function literal was already being derived.
   * Such a type is kept under the `any` axis (`_cacheGeneration()`), which
   * every call advances, never under `_typeCacheGeneration()`. Outside a
   * value shield, its values never equal those of `_typeCacheGeneration()`.
   * Inside a value shield, both can be the key of the shield (they are,
   * except while the static view of a type computation diverges,
   * `staticViewDiverges()`): the type version does not key the cache there,
   * so the two kinds of type are kept under the same key.
   * @internal */
  _typeCacheFallbackGeneration(): number;

  /** Run `f` as a value shield for the cache: `_cacheGeneration()` answers a
   * key of this shield extent while `f` runs, and the outer key again after
   * (see `_cacheGeneration()`). Called by the two value shields around their
   * shadow declarations and the shielded work; nested shields stack.
   * @internal */
  _withValueShieldKey<T>(f: () => T): T;

  /** The functions whose clause body is being canonicalized under the
   * recursion knot of `DefineFunction` (`library/core.ts`), by name: the
   * placeholder binding the knot declared for the name, and the number of
   * nested definitions of that name in flight (only the outermost exit
   * removes the entry). A call to such a name that still resolves to the
   * placeholder binding types `unknown` while the knot is open: the knot
   * declares the target as a bare `function`, and a call to a bare
   * `function` with a collection argument is otherwise typed as a
   * broadcast (`list<unknown>`, `broadcastable<unknown>`), a guess that a
   * list-building recursion (`out = f(n - 1, out)`) contradicts; joined into
   * the local's assignment evidence, the guess widened the local past the
   * list its spread gives and the compiled route declined the spread (row
   * 339 of the Tycho ledger, `tycho/docs/COMPUTE_ENGINE.md`). An
   * `unknown`-typed value records no evidence, so the local keeps the type
   * of its other assignments, which is the function's own result once the
   * clause is installed.
   * @internal */
  readonly _recursionKnots: Map<string, { depth: number; binding: object }>;

  /** Allocate the next assumption-record id. Each `assume()` insertion takes
   * one, so two assertions of the same normalized fact stay distinguishable.
   * @internal */
  _nextFactId(): number;

  /** Scopes that a computation currently on the stack registered as SCRATCH
   * and discards when it returns. The only registrar is `withScratchScope`
   * (`scratch-scopes.ts`), which pushes the scope before the computation and
   * removes it in a `finally`.
   *
   * A binding whose scope is one of these, or a scope created under one, is
   * a scratch binding: it dies with the computation. Three events on it are
   * flagged `scratch`: its `declare` (`declareSymbolValue`,
   * `declareSymbolOperator`), its `binding-repair` (`updateDef`), and an
   * `inference` of its type or signature. None of them advances the
   * `semantic` or `world` version or the definition version, which caches
   * that outlive the computation key on. A scratch `binding-repair` or
   * `inference` still advances `any` and `callable`, for the caches of the
   * computation's own expressions; a scratch `declare` advances neither. A
   * write to a binding in any other scope keeps its advances, even when made
   * while the computation runs. See "Scratch events" in the documentation of
   * `axisMaskOf`. @internal */
  readonly _scratchDeclarationScopes: object[];

  /** The number of advances of `_anyVersion` that scratch events made (a
   * `declare`, `binding-repair` or `inference` on a binding under a scratch
   * scope). The purity check of type handlers subtracts it, so that the
   * version advances of a scratch event (a parameter narrowed while a
   * signature derivation, which a type read can reach, boxes a function
   * body) are not reported (`EngineConfigurationLifecycle.scratchAnyAdvances`).
   * @internal */
  readonly _scratchAnyAdvances: number;

  /** The number of advances of `_callableVersion` that scratch events made;
   * see `_scratchAnyAdvances`. @internal */
  readonly _scratchCallableAdvances: number;

  /** Run `fn` with the precision of the engine and of the big decimals set
   * to `digits`, and restore both afterwards, also when `fn` throws. There
   * is no reset: the tolerance (an `'auto'` tolerance is not recomputed
   * for the transient precision), the cached values (the value of `Pi`) and
   * the cache axes do not change, so a value cached before the call keeps
   * its previous precision. Used by the exact ordering to compare two
   * constants at a higher precision (`exactOrder` in `compare.ts`).
   * @internal */
  _withTransientPrecision<T>(digits: number, fn: () => T): T;

  /** True while `_withTransientPrecision` runs a function. The value of a
   * constant is then computed again at the current precision on each read,
   * and not stored.
   * @internal */
  readonly _atTransientPrecision: boolean;

  /** Run `fn` with the angular unit `unit`, then restore the previous unit,
   * without a reset of the engine. The symbolic integrator runs its radian
   * rules this way in another unit. A value computed inside `fn` is not
   * stored (see `_atTransientConfiguration`).
   * @internal */
  _withTransientAngularUnit<T>(unit: AngularUnit, fn: () => T): T;

  /** True while `_withTransientPrecision` or `_withTransientAngularUnit`
   * runs a function. The memos of evaluated values are then bypassed, so
   * that a value computed at the transient precision or in the transient
   * angular unit is not served afterwards.
   * @internal */
  readonly _atTransientConfiguration: boolean;

  /** The state-event choke point
   * (`docs/EFFECTS-MODEL.md` §3): write
   * sites report what happened; the lifecycle's dispatch table
   * (`axisMaskOf`) decides which invalidation axes advance. Since the
   * step-2b cutover this is the SOLE writer of the axes — the axis members
   * below are read-only.
   * @internal */
  _noteStateEvent(event: StateEvent): void;

  /** Depth of nested top-level boxing operations (see
   * `beginInferenceTransaction` in `box.ts`).
   * @internal */
  _inferenceTxDepth: number;

  /** Set once an operator with only an `evaluateAsync` handler has been
   * defined on this engine. Until then the asynchronous route has no
   * asynchronous-only application to await inside a held operand and skips
   * that walk (`awaitAsyncOnlyDescendants`, `boxed-function.ts`).
   * @internal */
  _hasAsyncOnlyOperator: boolean;

  /** Per-engine state for construction-local boxing repairs.
   * @internal */
  readonly _boxingState: EngineBoxingState<Scope>;

  /** When true, a discarded scope tombstones its value definitions and the
   * symbol resolution sites throw on a use of a dead binding
   * (`boxed-expression/binding-tombstone.ts`). Defaults from the
   * `CE_DEBUG_BINDINGS` environment variable.
   * @internal */
  _debugBindings: boolean;

  /** When set, `implicitCompile()` tries the profile `ir` of the
   * JavaScript target first, for the consumers in `consumers` (all of them
   * when it is absent), and uses the existing compiler when the profile
   * declines (`js-profile-switch.ts`). Off (`undefined`) by default; the
   * initial value comes from the `CE_JS_PROFILE` and
   * `CE_JS_PROFILE_CONSUMERS` environment variables.
   * @internal */
  _jsProfile: JsProfileSwitch | undefined;

  /** When `'ir'`, each compilation for the `javascript` target that asks
   * for no profile also compiles the expression with the profile `ir`,
   * discards that result and counts its outcome (the shadow measure,
   * `js-profile-switch.ts`). Off (`false`) by default; the initial value
   * comes from the `CE_JS_PROFILE_SHADOW` environment variable.
   * @internal */
  _jsProfileShadow: false | 'ir';

  /** True when an operation (`evaluate()`, `simplify()`, `compile()`, …)
   * that starts now opens an environment of its own (rule 8 of
   * `docs/plans/2026-11-09-binding-units-slice-1-spec.md`): no operation
   * is in progress, or the operation in progress is an Epsil program (rule 10). An operation
   * nested in an operation that is not a program opens none: it reads and
   * writes in the environment of the operation that encloses it, so the
   * symbols of its result read the requirements that it wrote. In the
   * environment of a program, an evaluation (`evaluation` true:
   * `evaluate()` and `N()`) inside the evaluation of a statement by the run
   * driver opens none: it writes in the environment of the program.
   *
   * An operation method starts with
   * `if (ce._opensOperation(…)) return ce._withOperation(this, () => <the
   * same call>)`: the call made again runs in the new environment, and its
   * own `_opensOperation()` call is false.
   * @internal */
  _opensOperation(evaluation: boolean): boolean;

  /** Run `fn`, an operation on `input`, in a new operation environment
   * whose parents are the environments of the occurrences of `input`
   * (rule 8). In an operation that is not a program, `fn()`: it runs in
   * the environment of that operation. The environment in progress before
   * is put back at the end, also on a throw.
   * @internal */
  _withOperation<T>(input: unknown, fn: () => T): T;

  /** Give the asynchronous
   * evaluation `evaluation`, which starts now on `input`, its operation
   * environment (`AsyncEvaluation.operation`), when it has none: a new
   * environment when an operation starts now (`_opensOperation()`), else
   * the environment in progress (rule 8 of
   * `docs/plans/2026-11-09-binding-units-slice-1-spec.md`). Each synchronous
   * part of the evaluation puts it in place (`runWithEvaluationEffects()`,
   * `effects-registry.ts`).
   * @internal */
  _captureAsyncOperation(
    evaluation: { operation?: unknown },
    input: unknown
  ): void;

  /** Run `fn`, an Epsil run or an
   * Epsil static check, in a program environment (rule 10). Every outermost
   * boxing during `fn` joins it. The environment is discarded at the end.
   * @internal */
  _withProgramEnvironment<T>(fn: () => T): T;

  /** Value definitions whose type was first inferred (unknown → concrete)
   * during the current top-level boxing operation — the forward-computed
   * provenance for `repairFreshMatrixInference`'s eligibility. Lazily
   * allocated; `null` when empty or no boxing is in progress.
   * @internal */
  _freshlyInferred: Set<BoxedValueDefinition> | null;

  /** The single emission point for a write of inference evidence onto a
   * definition's type (or an operator definition's signature). Every
   * subscriber of "a definition's type was changed by inference" hangs off
   * this call: the provenance history (`_typeProvenance`), the
   * fresh-inference set (`_freshlyInferred`), and the narrowing sink
   * (`_narrowingSink`). Callers emit only for writes that actually changed
   * the type — no-op re-inferences are skipped at the write site. This is
   * deliberately NOT `_noteStateEvent`: that channel is the sole writer of
   * the cache-invalidation axes and stays payload-free; this one is passive
   * data recording with no invalidation effects.
   * @internal */
  _noteInferenceWrite(event: InferenceWriteEvent): void;

  /** The expression whose canonicalization is currently running — the
   * ambient `cause` recorded by `_noteInferenceWrite` into provenance
   * entries. Installed (saved/restored, so nesting resolves to the
   * innermost) around operator canonicalization; `null` outside. Stored as
   * operator + operands and materialized into a non-canonical expression
   * only when a write actually records it, so the hot path pays two field
   * writes and nothing else.
   * @internal */
  _inferenceCause: InferenceCauseContext | null;

  /** The head of the library call that is being boxed by
   * `_libraryCall()`: its name and the definition of the name in the
   * system scope. While it is set, the node of the call, and each node of
   * the name that the `canonical` handler of the library operator builds
   * with `ce._fn()` or `new BoxedFunction()`, is bound to this definition,
   * and the name is not shadowed for the tests of the boxing. Every other
   * boxing of a function node (`ce.function()`, `ce.box()`), the boxing of
   * each operand among them, starts with this field cleared, and restores
   * it at its end. So an operand is boxed in the current scope: a call of a
   * user function of the same name in an operand stays a call of the user
   * function. A node of the name that the `canonical` handler builds with
   * `ce.function()` is also bound to the user definition. A raw operand of
   * the name (not boxed yet) is read as a call of the user definition by
   * the rules that fold an operand by its name
   * (`shadowsLibraryNameInOperand()`, `isLibraryOperator()`).
   * `undefined` outside such a boxing.
   * @internal */
  _qualifiedHead: { name: string; definition: BoxedDefinition } | undefined;

  /** The names that were declared as a macro on this engine
   * (`ce.declare(name, { macro })`), in any scope. The set never shrinks: a
   * name stays in it after the scope of its declaration is popped, and after
   * a later declaration of the name that is not a macro. So a name that is
   * not in the set is not a macro in any scope, and a name that is in the set
   * may be one: `ce.lookupDefinition(name)` gives the definition that the
   * current scope reads. The set of an engine with no macro is empty. */
  readonly macroNames: ReadonlySet<string>;

  /** The number of macro definitions declared on this engine
   * (`ce.declare(name, { macro })`, `boxed-expression/macro.ts`). Zero means
   * that no name can resolve to a macro, and boxing skips every macro test.
   * It is never decremented, and a declaration raises it, so it is also the
   * version of `_macroNames`.
   * @internal */
  _macroCount: number;

  /** The names of the macro definitions declared on this engine, in any
   * scope: a symbol whose name is not in the set is not a macro name, and
   * the macro tests skip it before any lookup. Never shrinks.
   * @internal */
  readonly _macroNames: Set<string>;

  /** How many raw nodes that can hold a macro name the boxing has made or
   * taken as they are: a raw symbol whose name is in `_macroNames`, and a
   * boxed raw node that is not known to hold none. A boxing of raw operands
   * that does not raise it gives operands with no macro name
   * (`boxRawOperands()`, `boxed-expression/box.ts`). Raised only while
   * `_macroCount` is not zero.
   * @internal */
  _macroSuspects: number;

  /**
   * Run `fn` with at most `ms` milliseconds (numeric form) or `limit.ms`
   * (object form, which also accepts an attribution `label`). A tighter
   * enclosing span preempts this limit; use the label and
   * `CancellationError.attribution`/`spans` to tell which limit fired.
   *
   * **⚠️ `fn` MUST be synchronous.** The span is restored in a synchronous
   * `finally`, so a `Promise`-returning (`async`) callback hands control back
   * at its first `await` while the span is still open: work that resumes after
   * that point runs **outside** the deadline and is never cancelled (see
   * `docs/TIMEOUT-MODEL.md` §6.4). An `expr.evaluateAsync()` call that `fn`
   * makes before its first `await` is the exception: the evaluation keeps
   * the span's deadline until it ends
   * (`ce.withTimeLimit(20, () => { p = expr.evaluateAsync(); })`). For
   * cancellation that is not a time limit, use
   * `expr.evaluateAsync({ signal })` with an `AbortSignal`.
   */
  withTimeLimit<T>(
    limit: number | { ms: number; label?: string },
    fn: () => T extends Promise<unknown> ? never : T
  ): T;

  /**
   * Run `fn` with at most `limit.steps` steps of engine work: a hang guard
   * that fires at the same point on every machine, unlike a wall-clock
   * limit. A step is one of the engine's cooperative cancellation checks —
   * an opaque unit, deterministic for one computation on one engine state,
   * but not a measure of cost and not comparable across engine versions;
   * tune the budget empirically and keep a `withTimeLimit` span outside it.
   * A spent budget throws a `CancellationError` with `cause: 'step-budget'`
   * and the span's `label` as its `attribution`.
   *
   * **⚠️ `fn` MUST be synchronous**, as for `withTimeLimit`.
   */
  withStepBudget<T>(
    limit: { steps: number; label?: string },
    fn: () => T extends Promise<unknown> ? never : T
  ): T;

  /**
   * The number of milliseconds left before the earliest deadline of the
   * active `withTimeLimit` spans (an enclosing span preempts a later inner
   * limit), and `0` or less once that deadline has passed. `Infinity` when
   * no active span has a time limit, which includes a `withStepBudget` span
   * with no `withTimeLimit` around it.
   *
   * This value and {@link stepBudgetSpent} describe the span that is active
   * in the current synchronous code. Code that runs after an `await`, even
   * inside `withTimeLimit` or an `evaluateAsync()` call, is outside the
   * span: it reads `Infinity` and `false`.
   *
   * The engine checks its deadline only inside its own work (evaluation,
   * canonicalization). A host loop that runs inside a span and does work of
   * its own (walking expressions, building a list) reads this value to stop
   * on time: `if (ce.timeRemaining <= 0) break;`.
   *
   * A spent step budget does not change this value; read
   * {@link stepBudgetSpent} for it.
   */
  readonly timeRemaining: number;

  /**
   * True inside a `withStepBudget` span (or a span nested in one) when a
   * step budget of the current span or of an enclosing one is spent; false
   * otherwise, and always false outside any span.
   *
   * When a budget is spent, the engine throws a `CancellationError`, but
   * code between the throw and the end of the span can catch it and return
   * a value. Such a value is partial. A host that stores values in a cache
   * reads this before a write, so that it does not keep a partial value.
   */
  readonly stepBudgetSpent: boolean;

  /**
   * The number of steps left in the budget of the innermost
   * `withStepBudget` span, or `undefined` when no such span is active.
   * It is negative once that budget is spent: after the throw that spends
   * it, each later check still counts one step, so `steps - ce.stepsLeft`
   * is the number of steps used only while the budget is not spent. A
   * `withTimeLimit` span nested in a step-budget span does not change it,
   * nor does a budget the engine opens for its own search: host code that
   * the engine calls during that search reads the host's budget.
   *
   * Read inside the callback of `withStepBudget`, it tells the two things
   * {@link stepBudgetSpent} cannot: how many steps the span has used
   * (`steps - ce.stepsLeft`), and whether THIS span's budget is spent
   * (`ce.stepsLeft < 0`) rather than the budget of an enclosing span. A
   * step is an opaque unit: compare counts only on one engine version.
   * Like {@link timeRemaining}, it describes the span of the current
   * synchronous code.
   */
  readonly stepsLeft: number | undefined;

  /**
   * Run `fn` in a span with a wall-clock limit (`ms`), a step budget
   * (`steps`), or both. A step budget bounds an internal search on every
   * machine at the same point, so its result does not depend on the speed or
   * the load of the machine. A spent budget throws a timeout
   * `CancellationError` with the span's `label` as its attribution. With
   * `ruleSteps`, each rule that `replace()` tries is a step of this budget
   * too (see `StepBudget` in `common/interruptible.ts`).
   * @internal
   */
  _withBudget<T>(
    limit: {
      ms?: number;
      steps?: number;
      label?: string;
      ruleSteps?: boolean;
      /** Set by `withStepBudget` only: see `StepBudget.host`. */
      host?: true;
    },
    fn: () => T
  ): T;

  /**
   * The host capabilities of this engine: the handlers the library operators
   * use to reach the host. `Print` and `Input` use `effects.console`.
   *
   * The registry is an immutable object. Reading returns the registry that a
   * new evaluation would use. Assigning installs a new registry: the assigned
   * object is a COMPLETE description — a handler it does not mention returns
   * to its default, so `ce.effects = {}` restores every default. A `null`
   * handler denies the capability: an operator that needs it evaluates to an
   * `Error("capability-denied", …)` value.
   *
   * ```ts
   * const lines: string[] = [];
   * ce.effects = {
   *   console: { log: (line) => lines.push(line), readLine: () => undefined },
   * };
   * ```
   *
   * Each evaluation (`evaluate()`, `N()`, `evaluateAsync()`) uses the registry
   * that was installed when it started. An assignment does not change the
   * handlers of an evaluation that is already running.
   *
   * For a change that must last for one block of code only, use
   * {@linkcode withEffects}.
   */
  get effects(): EffectHandlers;
  set effects(handlers: EffectHandlerOverrides);

  /**
   * Run `fn` with some host capabilities replaced or denied, then put the
   * previous ones back. Evaluations that START inside `fn` use the changed
   * registry.
   *
   * `overrides` is applied on top of the registry in effect when
   * `withEffects` is called, so calls nest: a capability an inner call does
   * not mention keeps the handler of the outer call. A `null` value denies the
   * capability, even if it has a default handler — this is how to evaluate an
   * expression that is not trusted:
   *
   * ```ts
   * const result = ce.withEffects({ console: null }, () => expr.evaluate());
   * ```
   *
   * The previous registry is put back when `fn` returns or throws. If `fn`
   * returns a promise, it is put back when that promise settles (fulfilled or
   * rejected), and `withEffects` returns a promise that settles the same way.
   *
   * An asynchronous evaluation keeps the registry it started with, so an
   * evaluation that started BEFORE `withEffects` was called is not changed by
   * it. But while the promise of an asynchronous `fn` is pending, the changed
   * registry is the installed one: an unrelated evaluation that starts during
   * that time, from other code, also uses it. Start such evaluations before
   * calling `withEffects`, or use a separate engine.
   */
  withEffects<T>(overrides: EffectHandlerOverrides, fn: () => T): T;

  /**
   * Run the synchronous `fn` in the evaluation context that `options`
   * carries, then put the previous context back, and return the result of
   * `fn`.
   *
   * For an `evaluateAsync` handler. The handler receives `options`, which
   * carry the evaluation context of the evaluation that called it: the host
   * capability registry, and the lexical scopes of the scoped operators that
   * the evaluation is inside (the scope of the index of a `Sum`, for
   * example). While the handler is suspended at an `await`, other code can
   * run on the same engine, so the engine does not keep that context
   * installed for the handler. Before the first `await`, the context is in
   * place. After it, synchronous work that reads the scope — canonicalizing
   * a held operand (`x.canonical`), `ce.box()`, `ce.parse()`, `evaluate()`,
   * `ce.assign()` — sees the global scope unless it runs inside `fn`. An
   * index of an enclosing `Sum` then stays symbolic, and a new global
   * symbol with its name is declared.
   *
   * ```ts
   * ce.declare('Late', {
   *   signature: '(integer) -> integer',
   *   lazy: true,
   *   evaluateAsync: async ([x], options) => {
   *     await delay(1);
   *     return ce
   *       .withEvaluationContext(options, () => x.canonical)
   *       .evaluateAsync(options);
   *   },
   * });
   * ```
   *
   * A nested `evaluateAsync(options)` call does not need it: the options
   * carry the context to that evaluation.
   *
   * If `fn` returns a promise, only the synchronous part of `fn`, up to its
   * first `await`, runs in the context.
   */
  withEvaluationContext<T>(
    options: Partial<KernelEvaluateOptions> | undefined,
    fn: () => T
  ): T;

  iterationLimit: number;

  recursionLimit: number;

  maxCollectionSize: number;

  chop(n: number): number;
  chop(n: BigNum): BigNum | 0;
  chop(n: number | BigNum): number | BigNum;

  bignum: (a: string | number | bigint | BigNum) => BigNum;

  complex: (a: number | Complex, b?: number) => Complex;

  /** @internal */
  _numericValue(
    value:
      | number
      | bigint
      | OneOf<[BigNum | NumericValueData | ExactNumericValueData]>
  ): NumericValue;

  /** @internal The factory of the inexact (float) numeric values of the
   * engine: a big decimal value above machine precision, a machine value
   * at machine precision. It reads the precision of the engine at each
   * call, so an exact numeric value that keeps it as its factory follows
   * a later change of the precision. */
  readonly _inexactNumericValue: NumericValueFactory;

  set precision(p: number | 'machine' | 'auto');
  get precision(): number;

  /** The absolute tolerance of the comparisons that involve a float, and of
   * `chop()`. A number is kept as set; `'auto'` is `10^(-precision + 2)`,
   * recomputed at each precision change. */
  set tolerance(v: number | 'auto');
  get tolerance(): number;

  /** @internal The tolerance as an exact big decimal. In `'auto'` mode above
   * 325 digits it holds the value that the float `tolerance` cannot
   * (`1e-398` at 400 digits). */
  readonly _bignumTolerance: BigDecimal;

  /** @internal Draw the next uniform in [0, 1) — from the innermost
   *  `WithRandomSeed` frame when one is active, otherwise from the `entropy`
   *  handler of the host capability registry (`effects.entropy`; a denied
   *  handler throws `CapabilityDeniedError`). */
  _random(): number;

  /** @internal A live uniform in [0, 1) from the `entropy` handler, with no
   *  regard to any `WithRandomSeed` frame (a denied handler throws
   *  `CapabilityDeniedError`). For the compiled integrals, which sample live
   *  inside a frame by ruling. */
  _liveRandom(): number;

  /** @internal A private stream for the stochastic ESTIMATORS, derived from
   *  the ambient `WithRandomSeed` frame but consuming NO indices from it.
   *  `tag` (a structural hash) selects which sub-stream. Outside a frame each
   *  draw comes from the `entropy` handler. See `docs/RANDOMNESS-MODEL.md`. */
  _substream(tag: number): RandomSubstream;

  angularUnit: AngularUnit;

  /** The rule that `Round` uses for a value halfway between two integers.
   *  See {@link RoundingTies}. Default: `'away-from-zero'`. */
  roundingTies: RoundingTies;

  costFunction: (expr: Expression) => number;

  /** The rules used by `.simplify()` when no explicit `rules` option is passed.
   *  Initialized to the built-in simplification rules.
   *  Users can `push()` additional rules or replace the entire array. */
  simplificationRules: Rule[];

  /** The rules used by `solve()` to find roots of univariate expressions.
   *  Each rule matches a normalized equation `f(_x) = 0` — the unknown is
   *  the wildcard `_x` — and `replace` produces a root expression.
   *  Conditions should reject matches where other wildcards capture `_x`.
   *  Candidate roots are validated against the original equation, so an
   *  over-eager template degrades to a no-op rather than a wrong answer.
   *  Initialized to the built-in root-finding rules; `push()` to extend,
   *  assign to replace. */
  solveRules: Rule[];

  /** The rules used by `solve()` to transform an equation into equivalent,
   *  easier-to-solve forms before root-finding (e.g. `ln f(x) → f(x) - 1`).
   *  Same conventions and extension pattern as `solveRules`. */
  harmonizationRules: Rule[];

  strict: boolean;

  /** Whether the engine may implicitly generate and execute compiled code as
   * a performance optimization (auto-compiled `Map` drains, compiled numeric
   * quadrature/limit kernels). `'auto'` (default) attempts implicit
   * compilation and latches to `'off'` engine-wide on the first CSP
   * `EvalError`; `'off'` never attempts it. Explicit `compile()` is exempt.
   */
  jit: 'auto' | 'off';

  /**
   * The worker pool that `broadcastAsync()` of a compiled result uses, built
   * by the host with `createKernelPool()`. The engine creates no worker on
   * its own: with no pool every batch runs on the calling thread. One pool
   * can serve several engines, and it is read at each call.
   */
  workers: KernelPool | undefined;

  expr(
    expr: NumericValue | ExpressionInput,
    options?: {
      form?: FormOption;
      scope?: Scope;
    }
  ): Expression;

  /** @deprecated Use `expr()` instead. */
  box(
    expr: NumericValue | ExpressionInput,
    options?: {
      form?: FormOption;
      scope?: Scope;
    }
  ): Expression;

  /**
   * Rebuild `expr` as if `ce.expr(expr.json, { form, scope })` had been
   * called — every symbol resolves afresh in `scope` (or the current scope)
   * — without serializing `expr` to MathJSON.
   *
   * `ce.expr(expr, { scope })` on an already-boxed expression keeps the
   * bindings the expression was boxed with; it never re-resolves a symbol.
   * This is the operation that does. Use it when an expression built under
   * one set of declarations must be read under another: a body boxed in a
   * shadow scope, a row re-classified after a declaration changed.
   *
   * For the canonical and partial forms the MathJSON is built as a DAG — one
   * array per DISTINCT function node, shared by every parent that reads it
   * (a leaf contributes its own constant-size MathJSON) — where
   * `expr.json` writes a tree, one copy of a shared node per path. That
   * MathJSON is then boxed by the ordinary route, so the result matches
   * `ce.expr(expr.json, …)` by construction, including for an expression
   * that already holds an `Error` node. Canonical boxing still visits every
   * path, as it does for any MathJSON. The raw and structural forms
   * canonicalize nothing, so each distinct node is rebuilt once and a shared
   * sub-expression stays shared in the result as well.
   *
   * - `form`: `'canonical'` (default), `'structural'`, `'raw'`, or a
   *   partial form such as `['Flatten', 'Order']`.
   * - `scope`: the lexical scope the rebuild resolves and declares in.
   *
   * Verbatim LaTeX and source positions are dropped, as the MathJSON route
   * drops them. A mutable object is rebuilt as its record snapshot, as that
   * route boxes it.
   *
   * To give a name a value for one evaluation, or to hide its value, use
   * `withValues()`, not a declaration in a pushed scope followed by
   * `rebind()`: a stored function that the expression calls reads the names
   * of the scope it was defined in, which a pushed scope does not change.
   */
  rebind(
    expr: Expression,
    options?: {
      form?: FormOption;
      scope?: Scope;
    }
  ): Expression;

  /**
   * Parse a LaTeX string and return a boxed expression.
   *
   * This is a convenience method equivalent to `ce.expr(parse(latex))`,
   * but uses the engine's symbol definitions for better parsing accuracy.
   *
   * `options.scope` RECEIVES the parse's writes: the whole parse runs with
   * that scope as the current lexical scope, so name resolution (including
   * the parser's symbol oracle) walks `scope → parents`, and every
   * declaration and inference made while it runs lands rooted there. Boxing
   * itself declares no name. Discarding the scope discards the writes. Use `ce.createScope()` to make one that can be read
   * back.
   *
   * `options.speculative` leaves NO trace in the engine's type state: the
   * parse runs inside a transient scope (declarations and inferences land
   * there and are discarded with it), and every ambient symbol whose type is currently
   * inferred is shadowed in that scope with its current type — so a
   * narrowing use in `latex` refines the discarded shadow instead of
   * persistently narrowing the ambient symbol. Use it for derive-style
   * parses that only READ the result (its type, structure, or
   * serialization): the result's bindings refer to the discarded scope, so
   * do not retain, evaluate, or compare it against later expressions.
   * Mutually exclusive with `scope`.
   */
  parse(
    latex: string,
    options?: Partial<ParseLatexOptions> & {
      form?: FormOption;
      scope?: Scope;
      speculative?: boolean;
    }
  ): Expression;
  parse(
    latex: string | null,
    options?: Partial<ParseLatexOptions> & {
      form?: FormOption;
      scope?: Scope;
      speculative?: boolean;
    }
  ): Expression | null;

  /**
   * The symbols that appear in function-application syntax `f(…)` in `latex`
   * but are not defined as functions in the current scope (so they parse as
   * implicit multiplication or are left unresolved). Scope-aware and
   * side-effect-free. Intended to flag calls to undefined functions in tools
   * such as notebooks; intersect with {@link Expression.freeVariables}
   * to drop deliberate multiplication of defined values.
   *
   * Only parenthesized-group application is detected: a symbol juxtaposed
   * with a matrix environment (`\mathrm{Eigenvalues}\begin{pmatrix}…`) is
   * not reported, since a matrix never reaches the symbol-with-delimiter
   * juxtaposition analysis.
   */
  appliedNonFunctions(latex: string): string[];

  function(
    name: string,
    ops: ReadonlyArray<ExpressionInput>,
    options?: {
      metadata?: Metadata;
      form?: FormOption;
      scope?: Scope;
    }
  ): Expression;

  /**
   * This is a primitive to create a boxed function.
   *
   * In general, consider using `ce.expr()` or `ce.function()` or
   * `canonicalXXX()` instead.
   *
   * The caller must ensure that the arguments are in canonical form:
   * - arguments are `canonical()`
   * - arguments are sorted
   * - arguments are flattened and desequenced
   *
   * @internal
   */
  _fn(
    name: string,
    ops: ReadonlyArray<Expression>,
    options?: {
      metadata?: Metadata;
      canonical?: boolean;
      scope?: Scope;
    }
  ): Expression;

  /**
   * Construct an **object** — the engine's mutable value kind — of the
   * nominal type named `typeName`, with the given stored fields (insertion
   * order is the declared field order).
   *
   * The nominal type is resolved once and PINNED on the instance, a fresh
   * identity is minted for every call, and the result is always canonical and
   * always already evaluated.
   *
   * This is the ONLY construction path for objects until the user-facing
   * named-argument constructor lands: `box()`/`parse()` never mint one, which
   * is what makes "a parsed snapshot is a record under the `Object`
   * provenance head, never an object" true by construction.
   *
   * Throws when a field value is an object belonging to a different engine
   * (`object-foreign-engine`).
   *
   * @internal
   */
  _object(
    typeName: string,
    slots: Iterable<readonly [string, Expression]> | Record<string, Expression>,
    metadata?: Metadata,
    /** The resolved nominal type to PIN on the instance, when the caller has
     * it. Required for a PARAMETERIZED object type, whose name alone resolves
     * to the bare declaration record: `Cell<integer>` — the applied reference
     * the call site solved for — is what the constructed value's type must be.
     * Ignored unless it names `typeName`. */
    pinnedType?: BoxedType
  ): Expression;

  /** @internal Compile a boxed expression. */
  _compile(
    expr: Expression,
    options?: Record<string, unknown>
  ): CompilationResult;

  /**
   * @internal Get a registered compilation target by name.
   *
   * The two built-in executable targets are typed concretely so their compiled
   * `run` needs no cast: `interval-js` accepts `number | Interval` variables
   * and returns `IntervalResult`; `javascript` accepts
   * `number | boolean | string | ComplexResult | RunnerListInput` variables
   * (plain reals, booleans, strings, complex domain-coloring inputs, or a
   * list for a symbol that the code reads as a list) and returns a
   * `CompiledValue`. Any other name (source-only or custom targets)
   * falls back to the generic `LanguageTarget<Expression>`.
   */
  _getCompilationTarget(
    name: 'interval-js'
  ): IntervalJsCompilationTarget<Expression> | undefined;
  _getCompilationTarget(
    name: 'javascript'
  ): JavaScriptCompilationTarget<Expression> | undefined;
  _getCompilationTarget(name: string): LanguageTarget<Expression> | undefined;

  /** @internal Return the names of all registered compilation targets. */
  _listCompilationTargets(): string[];

  /**
   * Register a compilation target under `name`, so that
   * `compile(expr, { to: name })` resolves it. A later registration under the
   * same name replaces the earlier target. Throws when `name` is empty or the
   * target lacks one of `getOperators()`, `getFunctions()`, `createTarget()`
   * and `compile()`.
   *
   * Every engine has `javascript` and `interval-js`. Every engine also has
   * `glsl` once the full package entry,
   * `@cortex-js/compute-engine/epsil` or the CLI has been loaded anywhere in
   * the program, whichever entry made the engine and in whichever order. A
   * program that loads only `@cortex-js/compute-engine/core` has the two
   * built-in targets: import `GLSLTarget`
   * from `@cortex-js/compute-engine/compile` and register it here.
   */
  registerCompilationTarget(
    name: string,
    target: LanguageTarget<Expression>
  ): void;

  /** @internal The pre-2026-10-26 spelling of `registerCompilationTarget`. */
  _registerCompilationTarget(
    name: string,
    target: LanguageTarget<Expression>
  ): void;

  /** Remove the compilation target registered under `name`. A name that is
   * not registered is ignored. */
  unregisterCompilationTarget(name: string): void;

  /** @internal The pre-2026-10-26 spelling of `unregisterCompilationTarget`. */
  _unregisterCompilationTarget(name: string): void;

  /** @internal Fu trigonometric simplification algorithm */
  _fuAlgorithm(
    expr: Expression,
    options?: Record<string, unknown>
  ): RuleStep | undefined;

  /**
   * Create a complex number from its real part and its imaginary part, each
   * a JavaScript `number` or a `BigDecimal`.
   *
   * When the engine works above machine precision (`ce.precision` greater
   * than 15), a `BigDecimal` part is kept at the precision it holds: a part
   * too small or too large for a double (`1e-800`, `1e800`) or with more
   * than 16 significant digits is not rounded to a double. This is the
   * lossless alternative to `ce.number(ce.complex(re, im))`: `ce.complex()`
   * returns a `Complex` object, whose parts are always doubles. At machine
   * precision, both parts are rounded to doubles: there
   * `{ re: ce.bignum('1e-800'), im: ce.bignum(2) }` gives `2i`.
   *
   * When the imaginary part is zero (a `number` or a `BigDecimal`), the
   * result is a real number.
   *
   * When both parts are integers, the result is the EXACT Gaussian integer,
   * as `ce.number(2)` is the exact `2`: a part is an integer when it is a
   * `number` that is a safe integer, or an integer-valued `BigDecimal` whose
   * exponent is at most `10^6` (also at machine precision, and also outside
   * the double range). When a part has a fraction, is a `number` past the
   * safe integers, or is a `BigDecimal` with a larger exponent (`1e2000000`),
   * the result is a float. A `Complex` given to `ce.number()` or `ce.box()`
   * does not follow this rule: it holds two doubles, so it is always a
   * float (`ce.number(new Complex(2, 3))` is the float `2.0 + 3.0i`).
   *
   * ```js
   * ce.precision = 30;
   * ce.number({ re: ce.bignum('1e-800'), im: ce.bignum(2) });
   * // ➔ a complex number with the real part 1e-800 and the imaginary part 2
   * ce.number({ re: 1, im: 0 });
   * // ➔ 1
   * ce.number({ re: 2, im: 3 }).isExact;
   * // ➔ true
   * ce.number({ re: 2.5, im: 3 }).isExact;
   * // ➔ false
   * ```
   */
  number(
    value: { re: number | BigNum; im: number | BigNum },
    options?: { metadata?: Metadata; canonical?: CanonicalOptions }
  ): Expression;
  number(
    value:
      | number
      | bigint
      | string
      | NumericValue
      | MathJsonNumberObject
      | BigNum
      | Complex
      | Rational,
    options?: { metadata?: Metadata; canonical?: CanonicalOptions }
  ): Expression;

  symbol(
    sym: string,
    options?: {
      canonical?: CanonicalOptions;
      metadata?: Metadata;
      autoDeclare?: boolean;
    }
  ): Expression;

  string(s: string, metadata?: Metadata): Expression;

  /**
   * Create a boxed character — one user-perceived character.
   *
   * `s` must be exactly one grapheme cluster after NFC normalization; use the
   * `CharacterFrom` operator when the content is not known to satisfy that, as
   * it reports a diagnostic instead.
   */
  character(s: string, metadata?: Metadata): Expression;

  error(message: string | string[], where?: string): Expression;

  typeError(
    expectedType: Type,
    actualType: undefined | Type | BoxedType,
    where?: ExpressionInput
  ): Expression;

  hold(expr: ExpressionInput): Expression;

  tuple(...elements: ReadonlyArray<number>): Expression;
  tuple(...elements: ReadonlyArray<Expression>): Expression;

  /**
   * A `List` of numbers, built without boxing each element.
   *
   * The elements are copied into a frozen array of machine numbers that the
   * list keeps as its store: `count`, `at`, `type`, `isSame` and `array`
   * answer from it, and the boxed operands are built only if `ops` is read.
   * The result is an ordinary canonical `List` in every other respect.
   *
   * `values` may be a `number[]`, a `Float64Array` or any array-like of
   * numbers. Its `length` must be a non-negative safe integer and each
   * element a JS number; anything else throws a `TypeError`. `-0` is stored
   * as `+0`.
   *
   * Use it to hand a large numeric list to the engine cheaply, and read it
   * back with `expr.array`.
   */
  list(values: ArrayLike<number>): Expression;

  /** @internal A `List` in a numeric store, as `list()` builds it; with
   * `floats`, its integer-valued elements are floats (see
   * `FunctionInterface._numericStoreFloats`). */
  _list(values: ArrayLike<number>, floats: boolean): Expression;

  type(type: Type | TypeString | BoxedType): BoxedType;

  rules(
    rules:
      Rule | ReadonlyArray<Rule | BoxedRule> | BoxedRuleSet | undefined | null,
    options?: {
      canonical?: boolean;
      /** Default purpose applied to any rule in the set that doesn't carry
       *  its own `purpose` tag (a per-rule tag takes precedence). */
      purpose?: RulePurpose;
    }
  ): BoxedRuleSet;

  getRuleSet(
    id?: 'harmonization' | 'solve-univariate' | 'standard-simplification'
  ): BoxedRuleSet | undefined;

  pushScope(scope?: Scope, name?: string): void;
  popScope(): void;

  createScope(
    bindings?: Record<string, Type | TypeString | BoxedDefinition>,
    parent?: Scope
  ): InspectableScope;

  /**
   *
   * When a new eval context is created, it has slots for the local variables
   * from the current lexical scope. It also copies the current set of
   * assumptions.
   *
   * Need a pointer to the current lexical scope (may have a scope chain without an evaluation context). Each lexical scope includes a pointer to the parent scope (it's a DAG).
   *
   * If a function is "scoped" (has a `scoped` flag), create a new lexical scope
   * when the function is canonicalized, store the scope with the function
   * definition (if the function has a lazy flag, and a canonical handler, it
   * can behave like a scoped function, but a scoped flag is convenient,
   * it would still evaluate the arguments).
   *
   * Note: if an expression is not canonical, evaluating it return itself.
   * This is important to support arguments that are just symbol names
   * (they are not canonicalized).
   *
   * When the function expression is evaluated, if it is "scoped", push the
   * scope associated with the function (maybe not?) and a matching eval
   * context, including all the symbols in the lexical scope (including
   * constants). Need some way to indicate that a symbol maps to an argument
   * (in value definition?).
   *
   * When searching the value of a symbol, start with the current
   * eval context, then the previous one.
   *
   * When looking for a definition, start with the lexical scope of the
   * current eval context, then the parent lexical context.
   *
   * @internal */
  _pushEvalContext(scope: Scope, name?: string): void;

  /** @internal */
  _popEvalContext(): void;

  /**
   * Remove one specific evaluation context, wherever it currently sits on the
   * stack — used by the asynchronous path, whose frame may not be on top by
   * the time it unwinds.
   * @internal */
  _removeEvalContext(context: EvalContext): void;

  /**
   * Temporarily sets the lexical scope to the provided scope, then
   * executes the function `f` in that scope and returns the result.
   * @internal */
  _inScope<T>(scope: Scope | undefined, f: () => T): T;

  /**
   * The canonical form of the held stage of a pipe `topic |> stage`, for the
   * Epsil static pass (`src/epsil/static-diagnostics.ts`). `Pipe` holds its
   * stage unbound until it is evaluated, so the canonical form of the pipe
   * does not contain the errors of the stage. A stage that gets the piped
   * value as an implicit argument is returned as the canonical call with
   * `topic` in the slot that evaluation selects, at the 0-based position
   * `topicAt` (`xs |> Filter("a")` is `Filter(xs, "a")`); any other stage is
   * canonicalized alone. `written` is the call before canonicalization, which
   * `topicAt` counts in: canonicalization can rename the call and reorder its
   * operands. Nothing is evaluated. `undefined` when the stage is already
   * canonical. See `pipeStageAsCall` in `library/core.ts`.
   * @internal */
  _pipeStageAsCall(
    topic: Expression,
    stage: Expression
  ): { call: Expression; topicAt?: number; written?: Expression } | undefined;

  /**
   * Execute `f` in a **resolve-only** region: while it runs, boxing a symbol
   * resolves the name against the scope chain as usual, but a name that
   * resolves to nothing stays UNBOUND instead of being auto-declared into the
   * current scope. Partial canonical forms (`canonical: ['Number']`) run this
   * way — their output is not fully canonical, so they follow the structural
   * symbol contract and write nothing to the caller's scope.
   * See `docs/SCOPING-MODEL.md` A1.
   * @internal */
  _resolveOnly<T>(f: () => T): T;

  /** Depth of the enclosing {@link _resolveOnly} regions; auto-declaration is
   * suppressed while it is positive.
   * @internal */
  _resolveOnlyDepth: number;

  /**
   * Where `_infer()` routes the narrowings it performs while a parse/box runs
   * against a `createScope()` product. `undefined` — the normal case — is the
   * gate that keeps the capture off.
   * @internal */
  _narrowingSink: NarrowingSink | undefined;

  /**
   * For internal use. Use `ce.declare()` instead.
   * @internal */
  _declareSymbolValue(
    name: MathJsonSymbol,
    def: Partial<ValueDefinition>,
    scope?: Scope
  ): BoxedDefinition;

  /**
   * For internal use. Use `ce.declare()` instead.
   * @internal */
  _declareSymbolOperator(
    name: string,
    def: OperatorDefinition,
    scope?: Scope
  ): BoxedDefinition;

  /**
   * The symbol denoting `scope`'s OWN binding for `name` — how a binder's
   * variable (a `Function` parameter, a `Sum` index, `D`'s variable) is built.
   *
   * Unlike `symbol()`, which resolves a NAME through the scope chain and
   * short-circuits to the interned constant for `Pi`, `e`, `i`, ..., this reads
   * the scope's bindings map, which is the authority for what a binder binds.
   * `undefined` when the scope has no value binding for the name.
   * @internal */
  _bindingSymbol(name: MathJsonSymbol, scope: Scope): Expression | undefined;

  /**
   * The symbol `name` bound to its definition in the system scope (the
   * standard library and the libraries of the constructor's `libraries`
   * option), whatever definition the current scope resolves the name to: the
   * canonical form of `["Module", name]`. `undefined` when the system scope
   * does not define `name`.
   * @internal */
  _librarySymbol(name: MathJsonSymbol): Expression | undefined;

  /**
   * The canonical call `name(…ops)` bound to the operator definition of
   * `name` in the system scope, whatever definition the current scope
   * resolves the name to: the canonical form of the qualified call
   * `["Apply", ["Module", name], …ops]` where a binding of the program
   * shadows `name`. The operands are boxed in the current scope, and the
   * library operator reads them as its rules say. An operand that is not
   * canonical yet (MathJSON, or a raw boxed expression) is given as written:
   * a lazy operator holds it, and a binder binds its variable. An operand
   * that is canonical already was canonicalized by the caller, in the scope
   * of the caller, so a binder cannot bind its variable. The `Apply`
   * canonical handler (`library/core.ts`), whose operands are canonical,
   * calls this function only for an operator that does not hold or bind an
   * operand. `undefined`
   * when the system scope does not define `name` as an operator.
   * @internal */
  _libraryCall(
    name: MathJsonSymbol,
    ops: ReadonlyArray<ExpressionInput>,
    options?: { metadata?: Metadata; scope?: Scope }
  ): Expression | undefined;

  /**
   * The canonical call `name(…ops)` with its head bound to exactly `def`
   * (`_qualifiedHead`), not to the definition that `name` resolves to in the
   * current scope. The operands are boxed in the current scope. Unlike
   * `_libraryCall()`, `def` can be any definition, and the call is not
   * marked as a library call. A boxed call whose free head is read again
   * (`BoxedFunction._reboxedForFreeHead()`) uses it.
   * @internal */
  _callBoundTo(
    name: MathJsonSymbol,
    ops: ReadonlyArray<ExpressionInput>,
    def: BoxedDefinition
  ): Expression;

  /**
   * Push a set of parameter names that, while canonicalizing a function body,
   * shadow any same-named constant (`i`, `e`, ...) so they resolve as ordinary
   * local variables. Balanced with `_popShadowedParameters`. Optional `types`
   * carry declared types for annotated parameters so the auto-declaration
   * during body canonicalization uses the declared (non-inferred) type.
   * Optional `inferredTypes` carry types a caller inferred for BARE
   * parameters (a fold's accumulator): the auto-declaration binds such a
   * parameter with that type as an inferred type, which a use may widen and
   * which is not enforced at apply time.
   * Optional `boundary` is the scope that encloses the construct that
   * declares the names (`_shadowedParameterBoundary`). By default it is the
   * current lexical scope, which is correct when the frame is pushed before
   * the construct's own scope is entered.
   * Optional `functionLiteral` is true when the names are the parameters of a
   * function literal (false for the locals of a `Block`): the binding of each
   * one is then recorded as a parameter binding when it is cached
   * (`markFunctionLiteralParameter()`, `boxed-expression/function-literal.ts`).
   * Optional `liftedBody` is true when the function literal stands for a body
   * with bound variables (the integrand of `Integrate`, the body of a
   * `Limit`), not for a literal the user wrote (`_isLiftedBodyParameter`).
   * @internal */
  _pushShadowedParameters(
    names: ReadonlyArray<string>,
    types?: ReadonlyMap<string, Type>,
    inferredTypes?: ReadonlyMap<string, Type>,
    boundary?: Scope,
    functionLiteral?: boolean,
    liftedBody?: boolean
  ): void;
  /** The inferred type a caller supplied for an active bare shadowed
   * parameter, if any. @internal */
  _shadowedParameterInferredType(name: string): Type | undefined;
  /** @internal */
  _popShadowedParameters(): void;
  /** Canonicalize the operands of a `Function` literal, `[body, ...params]`,
   * as the `Function` operator's `canonical` handler does, with each BARE
   * parameter named in `inferredParamTypes` pre-declared at that type as an
   * INFERRED type: a use may widen it, nothing is enforced at apply time, and
   * the printed literal is unchanged. A parameter not in the map starts
   * `unknown` and is narrowed by its use. `undefined` when the operands do
   * not form a literal. This is `canonicalFunctionLiteralOperands`
   * (`function-utils.ts`), reachable from a module that cannot import it
   * without a dependency cycle (`collection-utils.ts`, for the mapping
   * literal of a lazy broadcast). @internal */
  _canonicalFunctionLiteralOperands(
    ops: ReadonlyArray<Expression>,
    options?: { inferredParamTypes?: ReadonlyMap<string, Type> }
  ): Expression | undefined;
  /** True while `_pushShadowedParameters` has registered `name`. @internal */
  _isShadowedParameter(name: string): boolean;
  /** True when the innermost construct that shadows `name` in the current
   * scope is a function literal whose parameter is `name`, not a `Block`
   * that declares `name` as a local. @internal */
  _isFunctionLiteralParameter(name: string): boolean;
  /** True when the innermost construct that shadows `name` in the current
   * scope is a function literal that stands for a body with bound variables
   * (the integrand of `Integrate`, the body of a `Limit`), not a literal
   * written with `Function` or `\mapsto`. @internal */
  _isLiftedBodyParameter(name: string): boolean;
  /** True while any construct has pushed names with
   * `_pushShadowedParameters`, even no name: a function literal or a `Block`
   * is being canonicalized. False at the top level of a canonicalization.
   * @internal */
  _hasShadowedParameterFrame(): boolean;
  /** Run `f` with no shadowed-parameter frame, and restore the frames after.
   * For a computation whose result must not depend on the canonicalization
   * in progress, such as the derivation of a stored function's signature:
   * it boxes the function's body again in the function's own scope, where
   * the names of the construct being canonicalized do not shadow anything.
   * @internal */
  _withoutShadowedParameters<T>(f: () => T): T;
  /**
   * The `resolveSymbol` handler of the `ce.parse()` call in progress — the
   * caller's per-call handler, else the engine-wide one — or `undefined`
   * outside a parse or when the call has none. The handler supplements the
   * scope for the parser; the canonicalization that `ce.parse()` runs on its
   * result consults it here for the same question the scope answers, whether
   * a symbol is a value (`invisible-operator.ts`, the reading of `s(x+1)`).
   * Outside a parse the engine-wide `latexOptions.resolveSymbol` is read in
   * its place (`oracleHeadType`, `invisible-operator.ts`), so a result parsed
   * without canonicalization and canonicalized later reads as a canonical
   * parse does.
   * @internal
   */
  _activeSymbolOracle:
    ((symbol: MathJsonSymbol) => SymbolResolution | undefined) | undefined;
  /** The declared type of an active shadowed parameter, if any. @internal */
  _shadowedParameterType(name: string): Type | undefined;
  /** The scope enclosing the construct that shadows `name` — the scope a
   * function literal whose parameter is `name` is written in, or the scope
   * enclosing a `Block` that declares `name`. A resolution of `name` must stop
   * before reaching this scope: anything found at or above it belongs to the
   * enclosing context, which the parameter (or block local) shadows.
   * `undefined` when `name` is not an active shadowed parameter. @internal */
  _shadowedParameterBoundary(name: string): Scope | undefined;
  /** The binding already auto-declared for an active shadowed parameter during
   * the current body's canonicalization, if any. @internal */
  _shadowedParameterDef(name: string): BoxedDefinition | undefined;
  /** Cache the binding auto-declared for an active shadowed parameter so later
   * references reuse it. `created` is true when the caller declared the
   * binding now, false when it reuses a binding that existed before.
   * @internal */
  _setShadowedParameterDef(
    name: string,
    def: BoxedDefinition,
    created?: boolean
  ): void;
  /** The bindings cached on the TOP shadowed-parameter frame — read just
   * before popping it so a literal's parameter declarations can adopt the
   * binding the body's references accumulated type evidence on. @internal */
  _currentShadowedParameterDefs(): ReadonlyMap<string, BoxedDefinition>;

  /** The record of the function literal being boxed that declared the
   * parameter whose value definition is `def` (decision D18 of
   * `docs/plans/2026-11-11-bound-once-spec.md`); `undefined` when no literal
   * that is being boxed declared `def`. @internal */
  _parameterRecord(def: BoxedValueDefinition): ParameterRecord | undefined;

  /** The record of the top shadowed-parameter frame, read just before it is
   * popped; `undefined` for the frame of a `Block`. @internal */
  _currentParameterRecord(): ParameterRecord | undefined;

  /** Save the requirements of each function literal being boxed; the
   * result puts them back. @internal */
  _saveParameterRequirements(): () => void;

  /** Run `f`, a step of the boxing of a function literal after its
   * shadowed-parameter frame is popped (the rebinding of its body), with
   * the uses of the parameter definitions `params` recording their
   * requirements in `record` (`_parameterRecord()`). @internal */
  _withClosingLiteral<T>(
    params: ReadonlySet<BoxedValueDefinition>,
    record: ParameterRecord,
    f: () => T
  ): T;

  /** Enter a user-function application, throwing a `CancellationError`
   * (`cause: 'recursion-depth-exceeded'`) when `recursionLimit` is exceeded
   * or the JavaScript stack is nearly full. Returns the depth before the
   * entry. Balanced with `_exitRecursion`. @internal */
  _enterRecursion(): number;
  /** Leave a user-function application: `depth` is the value that the
   * balancing `_enterRecursion()` returned. @internal */
  _exitRecursion(depth: number): void;

  /**
   * Use `ce.expr(id)` instead
   * @internal */
  _getSymbolValue(id: MathJsonSymbol): Expression | undefined;
  /**
   * Use `ce.assign(id, value)` instead.
   * @internal */
  _setSymbolValue(
    id: MathJsonSymbol,
    value: Expression | boolean | number | undefined
  ): void;

  /** A list of the function calls to the current evaluation context */
  trace: ReadonlyArray<string>;

  lookupDefinition(id: MathJsonSymbol): undefined | BoxedDefinition;

  assign(ids: { [id: MathJsonSymbol]: AssignValue }): IComputeEngine;
  assign(id: MathJsonSymbol, value: AssignValue): IComputeEngine;
  assign(
    arg1: MathJsonSymbol | { [id: MathJsonSymbol]: AssignValue },
    arg2?: AssignValue
  ): IComputeEngine;

  /** Run `fn` with each symbol of `values` bound to the given value, and
   * put back the earlier value and type of each symbol when `fn` returns or
   * throws. `fn` must be synchronous. */
  withValues<T>(
    values: { readonly [id: MathJsonSymbol]: AssignValue },
    fn: () => T
  ): T;

  declareType(
    name: string,
    type: Type | TypeString | BoxedType,
    options?: {
      alias?: boolean;
      fromStatement?: boolean;
      /** Whether the declaration also declares a value-level constructor
       * of the same name (`point(1, 2)` for `type point = tuple<…>`). Default
       * `true`. A VALUE KIND uses `false`: its type is a nominal type defined
       * as exactly `value` (`ce.declareType('gf8', 'value', { mint: false })`),
       * and its values are made by the head that declares its arithmetic
       * (`GF8(3)`), so a second constructor with no arithmetic must not
       * exist. See the `arithmetic` field of `OperatorDefinition`. */
      mint?: boolean;
      typeParams?: TypeParamsOption;
    }
  ): void;

  declare(symbols: {
    [id: MathJsonSymbol]: Type | TypeString | SymbolDefinitionInput;
  }): IComputeEngine;
  // The type and the definition are separate overloads on purpose, so an
  // inline `type: (ops) => …` handler is contextually typed against the
  // definition alone and its parameters are never implicitly `any`.
  declare(
    id: MathJsonSymbol,
    type: Type | TypeString,
    scope?: Scope | (DeclareOptions & { extend?: false })
  ): IComputeEngine;
  // Extend mode: `patch` is applied to the visible operator definition (see
  // `OperatorDefinitionPatch`). Listed before the plain definition overload so
  // that a call with `{ extend: true }` accepts the `addSignature` field.
  declare(
    id: MathJsonSymbol,
    patch: OperatorDefinitionPatch,
    options: DeclareOptions & { extend: true }
  ): IComputeEngine;
  declare(
    id: MathJsonSymbol,
    def: SymbolDefinitionInput,
    scope?: Scope | (DeclareOptions & { extend?: false })
  ): IComputeEngine;
  declare(
    arg1:
      | MathJsonSymbol
      | {
          [id: MathJsonSymbol]: Type | TypeString | SymbolDefinitionInput;
        },
    arg2?: Type | TypeString | SymbolDefinitionInput | OperatorDefinitionPatch,
    arg3?: Scope | DeclareOptions
  ): IComputeEngine;

  /**
   * Load a library on an engine that is already constructed. Its
   * definitions are declared in the global scope, as with `ce.declare()`,
   * and its name is recorded (see `libraryOf()`). Each library in its
   * `requires` list must already be loaded.
   */
  loadLibrary(library: LibraryDefinition): IComputeEngine;

  /**
   * The name of the library whose definition `name` resolves to in the
   * current scope (`'trigonometry'` for `Sin`), or `undefined` for a name
   * that no library defines or that a declaration shadows.
   */
  libraryOf(name: MathJsonSymbol): string | undefined;

  assume(predicate: Expression | string): AssumeResult;

  /**
   * Declare the names that `exprs` use, with the types that their uses
   * require.
   *
   * Each name is declared, marked as inferred, in its home scope: the scope
   * that a declaration of the name would go in when the expression that uses
   * it was boxed. When the home scope already holds an inferred definition
   * of the name, that definition is narrowed instead. The type is the meet of
   * the types that the uses in `exprs` require, met with the type of that
   * inferred definition. The order of `exprs` does not change the result.
   *
   * A name is not changed, and is reported in `skipped`, when the uses
   * require types that have no common subtype (`x + 1` and `x(3)`), when
   * they require no type, when the home scope holds a definition of the name
   * that is not inferred, and when the home scope is not the current scope
   * or one of its ancestors. Each expression then keeps the type that its
   * own uses require.
   *
   * A library name used as a value (`N` in `N + 1`) is declared as a
   * variable, which shadows the library definition in the home scope. A
   * call head (`f` in `f(x)`) is declared with a function type.
   *
   * @experimental
   */
  infer(exprs: ReadonlyArray<Expression>): InferResult;

  /**
   * Declare a sequence with a recurrence relation.
   *
   * @example
   * ```typescript
   * // Fibonacci sequence
   * ce.declareSequence('F', {
   *   base: { 0: 0, 1: 1 },
   *   recurrence: 'F_{n-1} + F_{n-2}',
   * });
   * ce.parse('F_{10}').evaluate();  // → 55
   * ```
   */
  declareSequence(name: string, def: SequenceDefinition): IComputeEngine;

  /**
   * Get the status of a sequence definition.
   *
   * @example
   * ```typescript
   * ce.parse('F_0 := 0').evaluate();
   * ce.getSequenceStatus('F');
   * // → { status: 'pending', hasBase: true, hasRecurrence: false, baseIndices: [0] }
   * ```
   */
  getSequenceStatus(name: string): SequenceStatus;

  /**
   * Get information about a defined sequence.
   * Returns `undefined` if the symbol is not a sequence.
   */
  getSequence(name: string): SequenceInfo | undefined;

  /**
   * List all defined sequences.
   * Returns an array of sequence names.
   *
   * A name is listed when the definition it has in the current scope is a
   * sequence, as for `isSequence()`.
   */
  listSequences(): string[];

  /**
   * Check if a symbol is a defined sequence.
   *
   * The answer is for the definition that the name has in the current
   * scope. A sequence declared in an enclosing scope is a sequence. A
   * sequence is no longer one after the scope that declared it is popped,
   * or after `undeclare()`.
   */
  isSequence(name: string): boolean;

  /**
   * Clear the memoization cache for a sequence.
   * If no name is provided, clears caches for all sequences.
   */
  clearSequenceCache(name?: string): void;

  /**
   * Get the memoization cache for a sequence.
   * Returns a Map of index → value, or `undefined` if not a sequence or memoization is disabled.
   *
   * For single-index sequences, keys are numbers.
   * For multi-index sequences, keys are comma-separated strings (e.g., '5,2').
   */
  getSequenceCache(name: string): Map<number | string, Expression> | undefined;

  /**
   * Generate a list of sequence terms from start to end (inclusive).
   *
   * @param name - The sequence name
   * @param start - Starting index (inclusive)
   * @param end - Ending index (inclusive)
   * @param step - Step size (default: 1)
   * @returns Array of BoxedExpressions, or undefined if not a sequence
   * or if a term in the range has no value. Each term is its value under
   * `evaluate()`: a number, or an exact expression such as `1 + 3√2`.
   *
   * @example
   * ```typescript
   * ce.declareSequence('F', { base: { 0: 0, 1: 1 }, recurrence: 'F_{n-1} + F_{n-2}' });
   * ce.getSequenceTerms('F', 0, 10);
   * // → [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
   * ```
   */
  getSequenceTerms(
    name: string,
    start: number,
    end: number,
    step?: number
  ): Expression[] | undefined;

  /**
   * Look up sequences in OEIS by their terms.
   *
   * @param terms - Array of sequence terms to search for
   * @param options - Optional configuration (timeout, maxResults)
   * @returns Promise resolving to array of matching sequences
   *
   * @example
   * ```typescript
   * const results = await ce.lookupOEIS([0, 1, 1, 2, 3, 5, 8, 13]);
   * // → [{ id: 'A000045', name: 'Fibonacci numbers', ... }]
   * ```
   */
  lookupOEIS(
    terms: (number | Expression)[],
    options?: OEISOptions
  ): Promise<OEISSequenceInfo[]>;

  /**
   * Check if a defined sequence matches an OEIS sequence.
   *
   * @param name - Name of the defined sequence
   * @param count - Number of terms to check (default: 10)
   * @param options - Optional configuration
   * @returns Promise with match results including OEIS matches and generated terms
   *
   * @example
   * ```typescript
   * ce.declareSequence('F', { base: { 0: 0, 1: 1 }, recurrence: 'F_{n-1} + F_{n-2}' });
   * const result = await ce.checkSequenceOEIS('F', 10);
   * // → { matches: [{ id: 'A000045', name: 'Fibonacci numbers', ... }], terms: [0, 1, 1, ...] }
   * ```
   */
  checkSequenceOEIS(
    name: string,
    count?: number,
    options?: OEISOptions
  ): Promise<{ matches: OEISSequenceInfo[]; terms: number[] }>;

  /**
   * Interpret a notational expression, then propose OEIS-attributed closed
   * forms for it (the async v4 of the `Interpret` ladder).
   *
   * `result.expression` is exactly what the synchronous `Interpret` head
   * returns (a `Sum`/`Product`, or the input unchanged); `result.candidates`
   * are OEIS-attributed closed forms, each verified to reproduce every
   * extracted sample exactly. This is the only interpretation path that
   * performs a network lookup. Too few samples, being offline, a timeout, or an
   * empty result all yield an empty candidate list rather than a rejection.
   *
   * @param expr - The (typically inert, continuation-bearing) expression
   * @param options - OEIS request options (timeout, maxResults)
   *
   * @example
   * ```typescript
   * const { expression, candidates } = await ce.interpret(
   *   ce.parse('1 + 3 + 6 + 10 + \\cdots + n')
   * );
   * ```
   */
  interpret(expr: Expression, options?: OEISOptions): Promise<InterpretResult>;

  forget(symbol?: MathJsonSymbol | MathJsonSymbol[]): void;

  /**
   * Remove the binding of one or more names from the current scope.
   *
   * The binding goes whatever it holds: a value, a function given with
   * `ce.assign()` or `ce.declare()`, or a function defined by one or more
   * clauses (`f(x) := …`, `DefineFunction`). This is different from
   * `forget()`, which removes assumptions and keeps the declaration.
   *
   * After the call, the name is not declared in the current scope:
   *
   * - When an enclosing scope declares the name, that declaration applies
   *   again. `undeclare()` does not change an enclosing scope.
   * - Otherwise, the name is a free symbol: `f(2)` stays unevaluated as
   *   `["f", 2]`, and `x + 1` stays symbolic.
   * - A later `ce.declare()`, `ce.assign()`, `f(x) := …` or `DefineFunction`
   *   of the name is a new declaration, and is accepted.
   *
   * An expression boxed before the call does not use the removed binding
   * either. A symbol reads the value that the scope chain holds when the
   * expression is evaluated. A call such as `f(2)` boxed before the call
   * evaluates to `["f", 2]`, and after a new definition of `f` in the same
   * scope it uses the new definition, as for a function given again with
   * `ce.assign()`.
   *
   * Assumptions about the name are not removed: an assumption applies to
   * the name, and so to a new declaration of it. Use `forget()` to remove
   * them.
   *
   * @throws if a name is not declared in the current scope. A name declared
   * only in an enclosing scope is not declared in the current scope. To
   * remove a name only when it is declared, test
   * `ce.context.lexicalScope.bindings.has(name)` first.
   *
   * @throws if a name is defined by a library: a standard library, a library
   * given to the constructor, or a library loaded with `ce.loadLibrary()`.
   * Also throws for any name of the system scope, which holds the standard
   * library.
   *
   * @throws if a name is the variable of an operator such as `Sum`, or a
   * parameter of a function, while that expression is evaluated.
   *
   * When one name of a list is refused, no binding is removed.
   *
   * ```ts
   * ce.pushScope();
   * ce.parse('f(n) := n + 1').evaluate();
   * ce.parse('f(2)').evaluate();   // 3
   * ce.undeclare('f');
   * ce.parse('f(2)').evaluate();   // f(2)
   * ```
   */
  undeclare(names: MathJsonSymbol | ReadonlyArray<MathJsonSymbol>): void;

  ask(pattern: Expression): BoxedSubstitution[];

  verify(query: Expression | string): boolean | undefined;

  /** @internal */
  _shouldContinueExecution(): boolean;

  /** @internal */
  _checkContinueExecution(): void;

  /** @internal */
  _cache<T>(name: string, build: () => T, purge?: (t: T) => T | undefined): T;

  /** @internal */
  _reset(): void;

  /** @internal */
  _listenToConfigurationChange(
    tracker: ConfigurationChangeListener
  ): () => void;

  /**
   * Introspect a registered operator head.
   *
   * Returns `undefined` if no definition is registered in this engine.
   * Otherwise returns `{ kind, signature? }` where `kind` is `'function'`
   * when the operator has an `evaluate` or `collection` handler, and
   * `'opaque'` when it is declared as a typed-but-opaque node (e.g.,
   * `Triangle`, `Sphere`).
   *
   * Use this to classify heads encountered in parsed MathJSON without
   * maintaining a parallel list of "known" operators.
   */
  operatorInfo(head: string): OperatorInfo | undefined;

  /**
   * Convert a LaTeX identifier string to its canonical MathJSON name without
   * declaring the symbol in the engine scope.
   *
   * Examples:
   * - `'R_{3}'` → `'R_3'`
   * - `'\\theta_x'` → `'theta_x'`
   * - `'\\alpha'` → `'alpha'`
   * - `'1 + 2'` → `''` (not an identifier)
   *
   * Use this instead of `ce.parse(latex).symbol` when you need the canonical
   * name without the side-effect of auto-declaring the symbol.
   */
  normalizeIdentifier(latex: string): string;

  /**
   * Return introspection metadata for a symbol (value definition) in the
   * current scope chain.
   *
   * - `kind: 'constant'` when the symbol is a CE-registered constant
   *   (e.g. `Pi`, `True`, `ExponentialE`).
   * - `kind: 'variable'` for declared but non-constant value symbols
   *   (e.g. after `ce.declare('a', 'real')`).
   *
   * Returns `undefined` for unknown names and for names that resolve to
   * operator/function definitions (use `operatorInfo()` for those — the
   * two methods are non-overlapping).
   */
  symbolInfo(name: string): SymbolInfo | undefined;

  /**
   * Reverse library search: map plain-text concept keywords to a ranked list
   * of matching identifiers in the current scope chain (standard library plus
   * any user declarations).
   *
   * The query is a string (tokenized on whitespace) or an array of strings;
   * tokens are OR-ed — a definition matches when **any** token matches — and
   * definitions matching more tokens, or matching them more exactly, rank
   * higher.
   *
   * Every returned `id` resolves via `ce.lookupDefinition(id)`; chain that
   * call for full detail.
   */
  searchDefinitions(
    query: string | string[],
    options?: { limit?: number }
  ): DefinitionSearchResult[];

  /**
   * Given a `name` that is **not** a known operator, return the closest known
   * operator name — a "did you mean" suggestion — or `undefined` when nothing
   * is close enough. Powers the Epsil `unknown-function` diagnostic.
   *
   * Matching is conservative and applied in priority order (first match wins):
   * case-insensitive exact match, singular/plural, Damerau–Levenshtein
   * distance (≤ 2 for names of length ≥ 6, ≤ 1 for length 5, never for
   * shorter names), then a prefix match against exactly one operator. Ties
   * prefer the candidate sharing the longest prefix with the query.
   *
   * ```ts
   * ce.suggestOperatorName('Quartile'); // → 'Quartiles'
   * ce.suggestOperatorName('foo');      // → undefined
   * ```
   */
  suggestOperatorName(name: string): string | undefined;

  /**
   * Return a name for a temporary symbol: `<hint>_tmp<n>`, with `n` the
   * smallest integer from 1 such that the name
   * - has no definition that `ce.lookupDefinition()` finds from the current
   *   scope, and
   * - is not a name of `avoid`, and does not occur in an expression of
   *   `avoid`, as a symbol (free or bound) or as the operator of a call.
   *
   * Each item of `avoid` is a boxed expression, a string (one name, not text
   * to search) or a set of names. An array throws: an array of strings is
   * also a MathJSON call, so box it or pass the set of its names. An
   * expression is walked as it is written, each shared subtree once; the
   * walk does not enter the values or the bodies of the names it reads.
   *
   * Pass in `avoid` every expression that the name will be put in or
   * combined with, the bodies and stored values that the computation reads,
   * and the names returned by earlier calls that are not declared yet: two
   * calls in a row with the same hint return the same name otherwise. A name
   * that an expression uses with no definition is not seen by the lookup.
   *
   * The hint is cleaned: the `_` at its start and at its end are removed and
   * each `__` becomes `_`; `tmp` is used if nothing is left. A hint that is
   * not a valid symbol name, or for which `<hint>_tmp1` is not one (an
   * emoji), throws.
   *
   * The function keeps no state and declares nothing: the same call in the
   * same state returns the same name. The caller declares the name if it
   * needs a definition, and the definition ends with its scope.
   *
   * A name that ends with `_tmp` and a positive integer is reserved for this
   * function. The engine does not enforce it. A host can remove
   * `/_tmp[1-9]\d*$/` from the name to get the hint.
   *
   * ```ts
   * ce.temporaryName('t');                                // → 't_tmp1'
   * ce.temporaryName('t', ce.box(['Add', 't_tmp1', 'x'])); // → 't_tmp2'
   * ce.temporaryName('s', new Set(['s_tmp1']));           // → 's_tmp2'
   * ce.temporaryName('_x');                               // → 'x_tmp1'
   * ```
   */
  temporaryName(
    hint: string,
    ...avoid: (Expression | string | ReadonlySet<string>)[]
  ): string;

  /**
   * Return the known analytic properties of an operator — poles, zeros, branch
   * points/cuts, residues, holomorphic/meromorphic domains — drawn from the
   * Fungrim-derived metadata store, or `undefined` if none are recorded.
   *
   * ```ts
   * ce.functionProperties('Gamma')?.poles?.toString(); // 'NonPositiveIntegers'
   * ```
   *
   * The set-valued accessors (`poles`, `zeros`, ...) return a boxed set for the
   * unconditional record of that kind; parametric / conditional records (e.g.
   * residues that depend on parameters) are available via `entries`.
   */
  functionProperties(name: string): FunctionProperties | undefined;

  /** Integrate over a circle, simple polygon, or the entire real line by the
   * residue theorem. Real-line contours also accept an explicit principal value.
   * Returns pole classifications, residues, their sum, and the integral.
   * Unsupported or undecidable inputs have no value; boundary poles have
   * status `pole-on-contour`. See {@link ContourInput} for contour forms. */
  contourIntegrate(
    integrand: ExpressionInput,
    variable: string,
    contour: ContourInput
  ): ContourIntegralResult;

  /** Debug representation, e.g. for `JSON.stringify()`. */
  toJSON(): string;

  /** Print the evaluation-context stack to the console.
   * @internal */
  _printStack(options?: { details?: boolean; maxDepth?: number }): void;
}

declare module './types-expression.js' {
  // eslint-disable-next-line @typescript-eslint/no-empty-object-type
  interface ComputeEngine extends IComputeEngine {}
}
